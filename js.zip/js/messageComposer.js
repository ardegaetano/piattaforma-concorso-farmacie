function componiDichiarazione(testoDichiarazione,cognome,nome,sesso)
{
	var testoFinale=testoDichiarazione.replace("cognome",cognome);
	testoFinale=testoFinale.replace("nome",nome);
	
	if(sesso=="M")
	{
		testoFinale=testoFinale.replace("Il/La Signor/a","Il Signor");
	}
	else if(sesso=="F")
	{
		testoFinale=testoFinale.replace("Il/La Signor/a","La Signora");
	}
	
	document.write(testoFinale);
}