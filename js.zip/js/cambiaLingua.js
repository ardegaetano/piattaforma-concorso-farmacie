function cambiaLingua(lingua){

	if (lingua == '' ){
//		alert('Bando Regionale ');
		document.form_action.ACTION_METHOD.value = "CaricoBandoRegione";    	
		document.form_action.ID_REGIONE.value=idRegione;
		document.form_action.submit();
	}
	
//  alert('REgione '+ idRegione + ' - ' + coloreRegione );
}
		