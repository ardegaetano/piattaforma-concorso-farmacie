// contrScarti.js

// newFunction
function newFunction() {
}

function inoltraChiamataAction(action_method,bottonName) {
	var flusso = "";
	if (document.forms[0].CODFLUSSO)
		flusso = document.forms[0].CODFLUSSO.value;
	if (bottonName == "ricerca" || bottonName == "indietro_ricerca" || bottonName == "indietro_XSD_ricerca") { // controllo delle date
		if (document.forms[0].datainvioda) {
			if ( (document.forms[0].datainvioda.value != "" && document.forms[0].datainvioa.value == "") ||
				(document.forms[0].datainvioda.value == "" && document.forms[0].datainvioa.value != "") ){
				alert("Inserire entrambe le date");
				return false;
			}
		}
		document.forms[0].ACTION_NAME.value = 'ElencoErroriRicercaAction';
		document.forms[0].ACTION_METHOD.value = action_method;
		document.forms[0].submit();
	} else if (bottonName == "ricerca_mds" || bottonName == "indietro_mds" || bottonName == "indietro_XSD_mds" ) { // controllo delle date
		if (document.forms[0].datainvioda) {
			if ( (document.forms[0].datainvioda.value != "" && document.forms[0].datainvioa.value == "") ||
				(document.forms[0].datainvioda.value == "" && document.forms[0].datainvioa.value != "") ){
				alert("Inserire entrambe le date");
				return false;
			}
		}
		document.forms[0].ACTION_NAME.value = 'ElencoErroriRicercaPerMdsAction';
		document.forms[0].ACTION_METHOD.value = action_method;
		document.forms[0].submit();
	} else if (bottonName == 'visualizza') {
		if (flusso == 'BMA' || flusso == 'AIB' || flusso == 'CMA' || flusso == 'CIB') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriRigaMovAzAction';
		} else if (flusso == 'BSF' || flusso == 'CSF') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriRigaSfridiAction';
		} else if (flusso == 'BMI' || flusso == 'CMI') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriRigaIPZSAction';
		} else if (flusso == 'BMV' || flusso == 'AIV' || flusso == 'CIV' || flusso == 'CMV') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriRigaSSNAction';
		}
	} else if (bottonName == 'download') {
		if (flusso == 'BMA' || flusso == 'AIB' || flusso == 'CMA' || flusso == 'CIB') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriDownloadMovAzAction';
		} else if (flusso == 'BSF' || flusso == 'CSF') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriDownloadSfridiAction';
		} else if (flusso == 'BMI' || flusso == 'CMI') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriDownloadIPZSAction';
		} else if (flusso == 'BMV' || flusso == 'AIV' || flusso == 'CIV' || flusso == 'CMV') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriDownloadSSNAction';
		}
	} else if (bottonName == 'cerca' || bottonName == 'indietro') {
		if (flusso == 'BMA' || flusso == 'AIB' || flusso == 'CMA' || flusso == 'CIB') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriDettaglioMovAzAction';
		} else if (flusso == 'BSF' || flusso == 'CSF') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriDettaglioSfridiAction';
		} else if (flusso == 'BMI' || flusso == 'CMI') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriDettaglioIPZSAction';
		} else if (flusso == 'BMV' || flusso == 'AIV' || flusso == 'CIV' || flusso == 'CMV') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriDettaglioSSNAction';
		}
	} else if (bottonName == 'scarti') {
		if (document.forms[0].ACTION_METHOD.value == 'BMA' || 
			document.forms[0].ACTION_METHOD.value == 'AIB' ||
			document.forms[0].ACTION_METHOD.value == 'CMA' ||
			document.forms[0].ACTION_METHOD.value == 'CIB') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriFiltroMovAzAction';
		} else if (document.forms[0].ACTION_METHOD.value == 'BSF' ||
					document.forms[0].ACTION_METHOD.value == 'CSF') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriFiltroSfridiAction';
		} else if (document.forms[0].ACTION_METHOD.value == 'BMI' ||
					document.forms[0].ACTION_METHOD.value == 'CMI') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriFiltroIPZSAction';
		} else if (document.forms[0].ACTION_METHOD.value == 'BMV' || 
					document.forms[0].ACTION_METHOD.value == 'AIV' ||
					document.forms[0].ACTION_METHOD.value == 'CIV' ||
					document.forms[0].ACTION_METHOD.value == 'CMV') {
			document.forms[0].ACTION_NAME.value = 'ElencoErroriFiltroSSNAction';
		}
		
	}else if (bottonName == 'erroriXSD') {
		document.forms[0].ACTION_NAME.value = 'ErroriXSDVisualizza';
	}

	document.forms[0].ACTION_METHOD.value = action_method;
	document.forms[0].submit();	
}
// elencoRecordRicerca
function selezionaRecordRicerca(nomeCampo, indexRow, isScarto, tipoFlusso, dataInvioMills) {
	if (isScarto == '1' && dataInvioMills>document.getElementById("DATA_DISP_SCARTI_ID").value){
		document.forms[0].scarti.disabled = false;
		document.forms[0].erroriXSD.disabled = true;
	}
	else if (isScarto=='2'){
		document.forms[0].scarti.disabled = true;
		document.forms[0].erroriXSD.disabled = false;
	}
	else {
		document.forms[0].scarti.disabled = true;
		document.forms[0].erroriXSD.disabled = true;
	}
	

	document.getElementById("LIST_PRIMARY_KEY").value = document.getElementById(nomeCampo+"_"+(indexRow)).value;
	document.forms[0].ACTION_METHOD.value = tipoFlusso;
	document.getElementById("CODFLUSSO").value = document.getElementById("FLUSSO_"+(indexRow)).value;
}
// elencoErroriFiltro
function selezionaRecord(nomeCampo, indexRow) {
	document.getElementById("LIST_PRIMARY_KEY").value = document.getElementById(nomeCampo+"_"+(indexRow)).value;
	if (document.forms[0].CODERRORE)
		document.forms[0].CODERRORE.value = "";
		
	if (nomeCampo == 'RIGA')
		document.forms[0].visualizza.disabled=false;
	else
		document.forms[0].visualizza.disabled=true;
}
