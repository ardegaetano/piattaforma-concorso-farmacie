function sendRegion(idRegione, coloreRegione){
//	if (coloreRegione == 'G' ){
//		alert('Bando Regionale non ancora disponibile ');
//	}
//	if (coloreRegione == 'R' ){
//		alert('Bando Regionale Scaduto ');
//	}
//	if (coloreRegione == 'V' || coloreRegione == 'Y' ){
	if (coloreRegione != 'G' ){
//		alert('Bando Regionale ');
		document.form_action.ACTION_METHOD.value = "CaricoBandoRegione";    	
		document.form_action.ID_REGIONE.value=idRegione;
		document.form_action.submit();
	}
	
//  alert('REgione '+ idRegione + ' - ' + coloreRegione );
}
		