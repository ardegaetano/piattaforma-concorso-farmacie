package com.accenture.CCFarm.controller;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;
import com.engiweb.framework.base.SourceBean;
import com.engiweb.framework.configuration.ConfigSingleton;
//import com.engiweb.security.SecurityContext;
//import com.engiweb.security.SecurityContextSAML;
//import com.engiweb.security.SecurityFWException;
//import common.utils.Res;


//>>>> Migrazione new SAA: Import delle nuove librerie 
import com.mds.nsaa.rest.model.SecurityContext;
import com.mds.nsaa.rest.exception.SecurityFWException;


@SuppressWarnings("serial")
public class LoginRegioni extends HttpServlet{
	
	Logger logger =CommonLogger.getLogger("LoginRegioni");
	
	private static final String CODE = "CODE";
	private static final String NAME = "NAME";
	private static final String SURNAME = "SURNAME";
			
    @SuppressWarnings("deprecation")
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {	
    	try {
	    	HttpSession session = request.getSession(true);
	    	UtenteRegioni user = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	    	SourceBean applicationSourceBean =(SourceBean) ConfigSingleton.getInstance().getAttribute("SECURITY.APPLICATION");
	    	
	    	logger.info("LoginRegioni:service - Applicazione : "+applicationSourceBean.getCharacters());
	
	    	if (com.accenture.CCFarm.utility.GenericConstants.SERVER_ABSOLUTE_PATH.equals(""))
	   		{
	            String url = request.getHeader("Referer");
	            String hostName = null;
	            String appName = null;
	            int countToken = 1;
	            StringTokenizer st = new StringTokenizer(url,"/");
	            while(st.hasMoreTokens()){
	            	String token = st.nextToken();
	            	if(countToken == 2)
	            		hostName = token;
	            	if(token.startsWith(request.getSession().getServletContext().getServletContextName().toUpperCase())){
	            		appName = token;
	            		break;
	            	}
	            	countToken++;
	            }
	            if(appName==null) appName = AppProperties.getAppProperties().getProperty("app_Name");
	            
	            url = url.substring(0, url.indexOf(hostName)+hostName.length());
	            url += "/"+appName;
	            System.out.println("url context path : "+url);
	            com.accenture.CCFarm.utility.GenericConstants.SERVER_ABSOLUTE_PATH = url;
	            logger.info("LoginRegioni:service - SERVER_ABSOLUTE_PATH "+ GenericConstants.SERVER_ABSOLUTE_PATH);
	
	   		}
	    	logger.info("LoginRegioni:service - autenticazione con il tokenSAML");
			String tokenSAML = (String) request.getParameter("tokenSAML");
			if(user == null)
			if (tokenSAML != null && !tokenSAML.equals("")) 
			{
				try 
				{
					SecurityContext secCtx = createSecurityCtxTam(tokenSAML);// mod andrea
					user = new UtenteRegioni();					
					createUser(secCtx, user);						
					logger.info("LoginRegioni:service - tokenSAML: OK");
				} 
				catch (Exception e) 
				{						
					logger.info("LoginRegioni:service - ERROR_PROFILE : " + e);
					session.setAttribute("ERROR_PROFILE", "L\' utenza inserita non pu� accedere all\'applicazione");
					return;
				}
			}
			else 
			{
				logger.info("LoginRegioni:service - Non � presente il tokenSAML dell\'utente");
				session.setAttribute("ERROR_PROFILE","Non � presente il tokenSAML dell\'utente");
				return;
			}
			
	   		session.setAttribute(RepositorySession.UTENTE_NSIS, user);
	   		//Gestione per Area Documentale
	   		session.setAttribute(RepositorySession.UTENTE_ID_NSIS, user.getUserId());
	   		session.setAttribute(RepositorySession.TOKEN_SAML_NSIS, tokenSAML);
	   		session.setAttribute(RepositorySession.NOME_APPLICAZIONE_NSIS, AppProperties.getAppProperties().getProperty("NomeApplicazioneAreaDocumentale"));
	   		session.setAttribute(RepositorySession.BOXI_LINK_NSIS, AppProperties.getAppProperties().getProperty("UrlAreaDocumentale"));
	   		logger.info("LoginRegioni:service - Parametri in sessione");
	   		
	   		//Gestione parametri BO
	   		if(user.isAbilitataAreaBO()){
	   			session.setAttribute("USER_NAME", GenericConstants.UTENZA_BO);
		   		session.setAttribute("BO_XI_LINK", GenericConstants.LINK_BO);
	   		}
	   		
	   		response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/homeRegioni.jsf");
	   		System.out.println("url context path dopo la redirect : "+GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/homeRegioni.jsf");
    	} catch (Exception e) {
			logger.error("LoginRegioni: " + e);
			response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/errorPage.jsf");
		}
    }
    
	@SuppressWarnings("deprecation")
	private SecurityContext createSecurityCtxTam(String token) throws Exception {
		SecurityContext secCtx = null;
		String reame =	(String) ConfigSingleton.getInstance().getAttribute("SECURITY.ENGIWEBPM.realm");
		String nomeApplicazione =(String) ConfigSingleton.getInstance().getCharacters("SECURITY.APPLICATION");

		if (nomeApplicazione != null) {
			try {
				Properties prop = getProperties();
				secCtx = new SecurityContext(prop);
				if ((secCtx != null) && (reame != null)) {
					secCtx.loginSAML_1_0(token, reame, nomeApplicazione);
				}
				secCtx.setCurrentApplication(nomeApplicazione);
				
			} catch (SecurityFWException e) {
				logger.info("LoginRegioni:createSecurityCtxTam - [StartUpAction] createSecurityCtxTam->SecurityFWException: "+ e.getMessage());
			}
		}

		return secCtx;
	}

	private Properties getProperties() throws Exception {
		Properties prop = new Properties();
		SourceBean applicationSourceBean =(SourceBean) ConfigSingleton.getInstance().getAttribute("SECURITY.ENGIWEBPM");
		String providerUrl =(String) (applicationSourceBean).getAttribute("urlProvider");
		String initialFactory =(String) (applicationSourceBean).getAttribute("ctxInitialFactory");
		String providerUrlNewSAA =(String) (applicationSourceBean).getAttribute("PROVIDER_URL");
		if ((providerUrl != null) && (initialFactory != null)) {
			prop.setProperty("DEBUG", "NO");
			prop.setProperty("java.naming.provider.url", providerUrl);
			prop.setProperty("java.naming.factory.initial", initialFactory);
			prop.setProperty("PROVIDER_URL",providerUrlNewSAA);
		}
		return prop;
	}
    	
	private void createUser (SecurityContext secCtx, UtenteRegioni user) throws Exception
	{		
		user.setUserId((String)secCtx.getUserParameter(CODE));
		user.setNome((String)secCtx.getUserParameter(NAME));
		user.setCognome((String)secCtx.getUserParameter(SURNAME));
		user.setUOName(secCtx.getCurrentOUParameter(NAME));
		String identificativo = secCtx.getCurrentOUCODE();
		IdentificativoProfileManager(user, identificativo);
		ArrayList<String> profili = (ArrayList<String>) secCtx.getRoles();
		Iterator iterRuoli = profili.iterator();
		while(iterRuoli.hasNext()){
			String sRuolo = (String)iterRuoli.next();
			//TEST PER BO
			if(sRuolo.contains(GenericConstants.RUOLO_UT_BO) && user.getCodRegione().equalsIgnoreCase("MDS"))
				user.setAbilitataAreaBO(true);
			//TEST PER AREA DOCUMENTALE
			if(sRuolo.contains(GenericConstants.RUOLO_UT_AREA_DOCUMENTALE))
				user.setAbilitataAreaDocumentale(true);
			//UTENTE REGIONALE
			if(sRuolo.contains(GenericConstants.RUOLO_UT_REGIONALE)&& !user.getCodRegione().equalsIgnoreCase("MDS"))
				user.setRegione(true);
			//UTENTE COMMISSIONE
			if(sRuolo.contains(GenericConstants.RUOLO_UT_COMMISSIONE)&& !user.getCodRegione().equalsIgnoreCase("MDS"))
				user.setCommissione(true);
		}
		
		logger.info("LoginRegioni: createUser");
		
	}
    	
	@SuppressWarnings("unused")
	private void IdentificativoProfileManager(UtenteRegioni user, String identificativo) 
	{
		String codReame;
		String codDominio;
		String codRegione;

		try 
		{
			codReame = trim(identificativo.substring(0, 4), '*');
			codDominio = trim(identificativo.substring(4, 9), '*');
			codRegione = trim(identificativo.substring(9, 12), '*');
			
			if (codDominio != null && codDominio.equalsIgnoreCase("MDS")){
				user.setCodRegione("MDS");
			} else{
				user.setCodRegione(codRegione);	
			}
			
			
			//user.setMdS((codDominio != null && codDominio.equalsIgnoreCase("MDS")));
			//user.setRegione(codTipoUnOrg != null && codTipoUnOrg.equalsIgnoreCase("G"));
		} 
		catch (Exception e) 
		{
			logger.info("LoginRegioni:IdentificativoProfileManager - [IdentificativoProfileManager] Exception-> " + e.getMessage());
		}	
	}
    	
	private String trim(String valueToTrim, char charForTrim) throws Exception
	{
		String trimmedValue = valueToTrim;
		if ((valueToTrim != null) && (valueToTrim.indexOf(charForTrim) != -1)) 
		{
			int indexCharForTrim = valueToTrim.indexOf(charForTrim);
			if (indexCharForTrim > 0) 
				trimmedValue = valueToTrim.substring(0, indexCharForTrim);
			else 
						trimmedValue = null;
		}
		return trimmedValue;
	}

}
