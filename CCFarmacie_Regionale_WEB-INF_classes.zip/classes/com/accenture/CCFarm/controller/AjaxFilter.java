package com.accenture.CCFarm.controller;

import javax.faces.context.ExternalContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.servlet.http.HttpServletRequest;


public class AjaxFilter implements PhaseListener{

	@Override
	public void afterPhase(PhaseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beforePhase(PhaseEvent event) {
		// TODO Auto-generated method stub
		if(event.getFacesContext().getCurrentInstance().getPartialViewContext().isAjaxRequest()){
			ExternalContext ectx = event.getFacesContext().getExternalContext();
			HttpServletRequest req = (HttpServletRequest) ectx.getRequest();
		}
		
		
	}

	@Override
	public PhaseId getPhaseId() {
		// TODO Auto-generated method stub
		return PhaseId.APPLY_REQUEST_VALUES;
	}

	

}
