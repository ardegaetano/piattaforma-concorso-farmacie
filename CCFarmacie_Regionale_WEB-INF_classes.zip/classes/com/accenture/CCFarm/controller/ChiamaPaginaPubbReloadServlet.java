package com.accenture.CCFarm.controller;



import java.io.IOException;
import java.util.StringTokenizer;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.pageBean.ElaboraGraduatoria;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.RepositorySession;
import com.engiweb.framework.base.SourceBean;
import com.engiweb.framework.configuration.ConfigSingleton;

/**
 * Servlet implementation class CaricoBandoRegione
 */
@SuppressWarnings("serial")
public class ChiamaPaginaPubbReloadServlet extends HttpServlet {
//	private static final long serialVersionUID = 1L;
	Logger logger = CommonLogger.getLogger("ChiamaPaginaServlet");
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChiamaPaginaPubbReloadServlet() {
        super();
        // 
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// 
		super.init();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//		doPost(request, response);
//	}
//
//	/**
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//
//	
//	}



	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {	
		String pageJSF = null;
    	try {
	    	HttpSession session = request.getSession(true);
//	    	UtenteRegioni user = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	    	SourceBean applicationSourceBean =(SourceBean) ConfigSingleton.getInstance().getAttribute("SECURITY.APPLICATION");
	    	
	    	pageJSF = (String) request.getParameter("PAGE_SEND");
    		if (pageJSF==null) pageJSF="errorPage.jsf";
    		
	    	logger.info("ChiamaPaginaServlet:service - Applicazione : "+applicationSourceBean.getCharacters());
	
	    	if (com.accenture.CCFarm.utility.GenericConstants.SERVER_ABSOLUTE_PATH.equals(""))
	   		{
	            String url = request.getHeader("Referer");
	            String hostName = null;
	            String appName = null;
	            int countToken = 1;
	            StringTokenizer st = new StringTokenizer(url,"/");
	            while(st.hasMoreTokens()){
	            	String token = st.nextToken();
	            	if(countToken == 2)
	            		hostName = token;
	            	if(token.startsWith(request.getSession().getServletContext().getServletContextName().toUpperCase())){
	            		appName = token;
	            		break;
	            	}
	            	countToken++;
	            }
	            if(appName==null) appName = AppProperties.getAppProperties().getProperty("app_Name");
	            
	            url = url.substring(0, url.indexOf(hostName)+hostName.length());
	            url += "/"+appName;
	            
	            com.accenture.CCFarm.utility.GenericConstants.SERVER_ABSOLUTE_PATH = url;
	            logger.info("LoginRegioni:service - SERVER_ABSOLUTE_PATH "+ GenericConstants.SERVER_ABSOLUTE_PATH);
	
	   		}
	    	logger.info("ChiamaPaginaServlet:service - autenticazione con il tokenSAML");
	   
	    	
	    	//Pubblica graduatoria
	    	if (pageJSF.equalsIgnoreCase("pubblicaGraduatoria.jsf")){
	    		    request.getSession().removeAttribute("pubblicaGraduatoriaBean");
	    	//RETTIFICA DOMANDA
	    	}
	    	
	    	response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/"+ pageJSF);
	   		
    	} catch (Exception e) {
			logger.error("ChiamaPaginaServlet: "+ pageJSF+ "  " + e);
			response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/errorPage.jsf");
		}
    }
	
	
}
