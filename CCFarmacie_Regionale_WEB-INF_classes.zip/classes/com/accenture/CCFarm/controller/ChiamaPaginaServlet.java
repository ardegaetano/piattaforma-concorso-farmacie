package com.accenture.CCFarm.controller;



import java.io.IOException;
import java.util.StringTokenizer;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.pageBean.Bando;
import com.accenture.CCFarm.pageBean.ElaboraGraduatoria;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.RepositorySession;
import com.engiweb.framework.base.SourceBean;
import com.engiweb.framework.configuration.ConfigSingleton;

/**
 * Servlet implementation class CaricoBandoRegione
 */
@SuppressWarnings("serial")
public class ChiamaPaginaServlet extends HttpServlet {
//	private static final long serialVersionUID = 1L;
	Logger logger = CommonLogger.getLogger("ChiamaPaginaServlet");
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChiamaPaginaServlet() {
        super();
        // 
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// 
		super.init();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//		doPost(request, response);
//	}
//
//	/**
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//
//	
//	}



	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {	
		String pageJSF = null;
    	try {
	    	HttpSession session = request.getSession(true);
//	    	UtenteRegioni user = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	    	SourceBean applicationSourceBean =(SourceBean) ConfigSingleton.getInstance().getAttribute("SECURITY.APPLICATION");
	    	
	    	pageJSF = (String) request.getParameter("PAGE_SEND");
    		if (pageJSF==null) pageJSF="errorPage.jsf";
    		
    		Bando bando = (Bando)request.getSession().getAttribute("bando");
    		//bando.sedibandoDB();
    		if(bando!=null){
    			bando.getBandoRegionale().setListFarm(null);
    		}	
    		
	    	logger.info("ChiamaPaginaServlet:service - Applicazione : "+applicationSourceBean.getCharacters());
	
	    	if (com.accenture.CCFarm.utility.GenericConstants.SERVER_ABSOLUTE_PATH.equals(""))
	   		{
	            String url = request.getHeader("Referer");
	            String hostName = null;
	            String appName = null;
	            int countToken = 1;
	            StringTokenizer st = new StringTokenizer(url,"/");
	            while(st.hasMoreTokens()){
	            	String token = st.nextToken();
	            	if(countToken == 2)
	            		hostName = token;
	            	if(token.startsWith(request.getSession().getServletContext().getServletContextName().toUpperCase())){
	            		appName = token;
	            		break;
	            	}
	            	countToken++;
	            }
	            if(appName==null) appName = AppProperties.getAppProperties().getProperty("app_Name");
	            
	            url = url.substring(0, url.indexOf(hostName)+hostName.length());
	            url += "/"+appName;
	            
	            com.accenture.CCFarm.utility.GenericConstants.SERVER_ABSOLUTE_PATH = url;
	            logger.info("LoginRegioni:service - SERVER_ABSOLUTE_PATH "+ GenericConstants.SERVER_ABSOLUTE_PATH);
	
	   		}
	    	logger.info("ChiamaPaginaServlet:service - autenticazione con il tokenSAML");
	   
	    	//STAMPA ELENCO CANDIDATI
	    	if (pageJSF.equalsIgnoreCase("stampaElencoCandidati.jsf")){
//	    		StampaCandidatiBean stampaCandidatiBean= (StampaCandidatiBean) GetSessionUtility.getSessionAttribute("stampaCandidatiBean");
//	    		StampaCandidatiBean stampaCandidatiBean= (StampaCandidatiBean) request.getSession().getAttribute("stampaCandidatiBean");
//	    		if (stampaCandidatiBean!=null){
//	    			stampaCandidatiBean.init();
//	    		}
	    		request.getSession().removeAttribute("stampaCandidatiBean");
	    		
	    	//RICERCA CANDIDATURE
	    	} else if (pageJSF.equalsIgnoreCase("ricercaCandidatureDom.jsf")){
	    			//RicercaCandidati ricercaCandidati = (RicercaCandidati) GetSessionUtility.getSessionAttribute("ricercaCandidati");
//	    			RicercaCandidati ricercaCandidati = (RicercaCandidati) request.getSession().getAttribute("ricercaCandidati");
//	    			if (ricercaCandidati!=null){
//	    				ricercaCandidati.initInizializzazione();
//	    			}
	    	    	request.getSession().removeAttribute("ricercaCandidati");
	    	//Pubblica graduatoria
	    	} else if (pageJSF.equalsIgnoreCase("pubblicaGraduatoria.jsf")){
	    		    session.setAttribute(RepositorySession.TIPO_GRAD_RELOAD, "0");
	    		    request.getSession().removeAttribute("pubblicaGraduatoriaBean");
	    	//RETTIFICA DOMANDA
	    	} else if (pageJSF.equalsIgnoreCase("compilaDomanda.jsf")){
	    		String idUtente = (String) request.getParameter("ID_UTENTE");
	    		String pageReturn = (String) request.getParameter("PAGE_RETURN");
	    		if(pageReturn!=null) //Si arriva da RicercaCandidature
	    			session.setAttribute(RepositorySession.PAGE_RETURN, pageReturn);
	    		
	    		session.setAttribute(RepositorySession.ID_UTENTE_RETTIFICA, idUtente);
	    		
	    		request.getSession().removeAttribute("domanda");
	    	
    		} 
	    	//INDIETRO DA DOMANDA
	    	else if(pageJSF.equalsIgnoreCase("ReturncompilaDomanda.jsf")) {
	    		//DA RICERCA CANDIDATI
	    		String sRet = (String)session.getAttribute(RepositorySession.PAGE_RETURN);
	    		if(sRet!=null) {
	    			//pageJSF = sRet;
	    			pageJSF = "homeRegioni.jsf";
	    			
	    			if(sRet.equalsIgnoreCase("elaboraGraduatoria.jsf")) {
		    			//DA ELABORA GRADUATORIA
		    			ElaboraGraduatoria elaboraGraduatoria=(ElaboraGraduatoria)session.getAttribute("elaboraGraduatoria");
		    			if(elaboraGraduatoria==null)
		    			{
		    				elaboraGraduatoria = new ElaboraGraduatoria();
		    				session.setAttribute("elaboraGraduatoria",elaboraGraduatoria);
		    			}
		    			
		    			elaboraGraduatoria.aggiornaTabDaVisualizzare();
		    			
		    		}
	    		}
	    	}
	    	else if(pageJSF.equalsIgnoreCase("homeRegioni.jsf")) {
	    		String sRet = (String)session.getAttribute(RepositorySession.PAGE_RETURN);
	    		String pageRet = (String) request.getParameter("PAGE_RETURN");
	    		//BACK DA ELABORA GRADUATORIA
	    		if(pageRet!=null && pageRet.equalsIgnoreCase("elaboraGraduatoria.jsf")) {
	    			request.getSession().removeAttribute("elaboraGraduatoria");
	    			request.getSession().removeAttribute(RepositorySession.DATI_BANDO);
	    		}
	    		//BACK DA CONTROLLA DOMANDA
	    		else if(pageRet!=null && pageRet.equalsIgnoreCase("ricercaCandidatureDom.jsf"))
	    			request.getSession().removeAttribute(RepositorySession.DATI_BANDO);
	    		request.getSession().removeAttribute("homeRegioneBean");
	    	}
	    	else if(pageJSF.equalsIgnoreCase("consultaGraduatoria.jsf")) {
	    		
	    			request.getSession().removeAttribute("ricercaStoricoGraduatoria");
	    	}
	    	
	    	else{
    			pageJSF="errorPage.jsf";
    		}
    	
	    	response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/"+ pageJSF);
	   		
    	} catch (Exception e) {
			logger.error("ChiamaPaginaServlet: "+ pageJSF+ "  " + e);
			response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/errorPage.jsf");
		}
    }
	
	
}
