package com.accenture.CCFarm.controller;

import java.io.IOException;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


@SuppressWarnings("serial")
public class LoginRegioniTest extends HttpServlet{
	
	Logger logger =CommonLogger.getLogger("LoginRegioniTest");
    @SuppressWarnings("deprecation")
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {	
    	try {
	    	HttpSession session = request.getSession(true);
	    	UtenteRegioni user = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	    	if(user==null) {
	    		user = new UtenteRegioni();
	    		createUser(user);
	    	}
	    	if (GenericConstants.SERVER_ABSOLUTE_PATH.equals(""))
	   		{
	            String url = request.getHeader("Referer");
	            String hostName = null;
	            String appName = null;
	            int countToken = 1;
	            StringTokenizer st = new StringTokenizer(url,"/");
	            while(st.hasMoreTokens()){
	            	String token = st.nextToken();
	            	if(countToken == 2)
	            		hostName = token;
	            	if(token.startsWith(request.getSession().getServletContext().getServletContextName().toUpperCase())){
	            		appName = token;
	            		break;
	            	}
	            	countToken++;
	            }
	            
	            if(appName==null) appName = AppProperties.getAppProperties().getProperty("app_Name");;
	            url = url.substring(0, url.indexOf(hostName)+hostName.length());
	            url += "/"+appName;
	            
	            GenericConstants.SERVER_ABSOLUTE_PATH = url;
	            logger.info("LoginRegioniTest:service - SERVER_ABSOLUTE_PATH "+ GenericConstants.SERVER_ABSOLUTE_PATH);
	
	   		}
	    	logger.info("LoginRegioniTest:service - autenticazione formazione");
	   		session.setAttribute(RepositorySession.UTENTE_NSIS, user);
	   		
	   		//Gestione per Area Documentale
	   		session.setAttribute(RepositorySession.UTENTE_ID_NSIS, user.getUserId());
	   		session.setAttribute(RepositorySession.TOKEN_SAML_NSIS, "");
	   		session.setAttribute(RepositorySession.NOME_APPLICAZIONE_NSIS, AppProperties.getAppProperties().getProperty("NomeApplicazioneAreaDocumentale"));
	   		session.setAttribute(RepositorySession.BOXI_LINK_NSIS, AppProperties.getAppProperties().getProperty("UrlAreaDocumentale"));
	   				
	   		logger.info("LoginRegioniTest:service - parametri in Sessione");
	   		
	   		response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/homeRegioni.jsf");
	   		
	    } catch (Exception e) {
			logger.error("LoginRegioniTest: " + e);
			response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/errorPage.jsf");
		}
   		
   		
    }
    	private void createUser (UtenteRegioni user) throws Exception
    	{		
    		user.setUserId("UserPP");
    		user.setNome("Gian Domenico");
    		user.setCognome("Bianchi");
    		//user.setUOName("Formazione");
    		user.setRegione(true);
    		user.setCommissione(true);
//    		user.setProfilo("AMMINISTRATOREGRANDIAPP");
//    		user.setProfilo("COMMISSIONE");
			user.setCodRegione("090");
//    		user.setCodRegione("MDS");
			user.setAbilitataAreaDocumentale(true);
    	}
}
