package com.accenture.CCFarm.utility;

import org.apache.commons.beanutils.Converter;

public class SQLDateToUtilDateConverter implements Converter
{
	public Object convert(Class type,Object value)
	{
		if (value != null && (value instanceof java.sql.Date) && (type == java.util.Date.class)) 
		{
			java.sql.Date dataSql = (java.sql.Date) value;
	    	java.util.Date dataUtil = new  java.util.Date(dataSql.getTime());
	    	return (dataUtil);
	    }
		return value;
	}
}
