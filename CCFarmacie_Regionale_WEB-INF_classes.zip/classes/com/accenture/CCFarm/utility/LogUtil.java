package com.accenture.CCFarm.utility;

import java.io.PrintWriter;
import java.io.StringWriter;

public class LogUtil {
	public static String printException(Exception e)
	{
		String ret = "";
		try{
			StringWriter sw = new StringWriter();					
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			ret = sw.toString();
		}catch(Exception exc){
			ret = "Exception in LogUtil";
		}
		return ret;
	}
	
}