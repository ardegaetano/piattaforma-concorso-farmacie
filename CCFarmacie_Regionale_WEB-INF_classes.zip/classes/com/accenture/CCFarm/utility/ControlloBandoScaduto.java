package com.accenture.CCFarm.utility;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.exception.GestioneErroriException;

public class ControlloBandoScaduto {
	SimpleDateFormat fs  = new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss");
		
	
	public ControlloBandoScaduto() {
	
	}
	
	public boolean controllaScadenza(String codiceRegione) throws GestioneErroriException{
//		controllo se la registrazione avviene dopo la data chiusura bando
		Date sysDate = new Date (System.currentTimeMillis());
	    int sysDataInt = trasformaData(sysDate);
	    int sysOraInt = recuperaOra(sysDate);
	    
	    DatiBando datiBando =new DatiBando();
	    DatiBandoHome datiBandoHome = new DatiBandoHome();
	    datiBando=datiBandoHome.findById(codiceRegione);
	    if (datiBando!=null)
	    {
	    	//nel caso in cui siano presenti i dati del bando, ma la data di scadenza non sia stata ancora inserita
	    	if(datiBando.getDataFineBando()==null)
	    	{
	    		//considera il bando ancora in essere
	    		return true;
	    	}
	    	
	    	int dataFin = trasformaData(datiBando.getDataFineBando());
	    	int oraFinInt = recuperaOra(datiBando.getDataFineBando());
	    	if (sysDataInt>dataFin){
//	        	bando scaduto
	        	return false;
	        } else {
	        	if (sysDataInt==dataFin){
	        		if (sysOraInt>oraFinInt){
//	    	        	bando scaduto
	    	        	return false;
	        		} else{
//			        	bando in essere
			        	return true;	
	        		}
	        	} else {
//		        	bando in essere
		        	return true;	
	        	}
	        }
	    }
	    else
	    {
	    	//nel caso in cui non siano disponibili i dati del bando, consideralo scaduto
	    	return false;
	    }
	}

	private int trasformaData(java.util.Date data){
		String dataString = fs.format(data);
		String dataConfert = dataString.substring(6, dataString.length())  +
							 dataString.substring(3, 5)  +
				             dataString.substring(0, 2)  ;
		return Integer.parseInt(dataConfert);
	}
	
	private int recuperaOra(Date data){
		String dataString = StringUtil.dateToString(data,sdf);
		String dataConfert = dataString.substring(13, 15)  +
							 dataString.substring(16, 18)  +
				             dataString.substring(19, 21)  ;
		return Integer.parseInt(dataConfert);
	}
	private int trasformaDataSting(String data){
//		String dataString = fs.format(data);
		String dataConfert = data.substring(6, 10)  +
							 data.substring(3, 5)  +
				             data.substring(0, 2)  ;
		return Integer.parseInt(dataConfert);
	}

	
	private int calcolaData(Date data){
		
		String dataGregorian = StringUtil.dateToStringDDMMYYYY(data);

		Calendar cal = Calendar.getInstance();
		String result = "";
		try { 
			cal.setTime(data);
			cal.add(Calendar.DATE, -2);
			result = StringUtil.dateToStringDDMMYYYY(cal.getTime()); 
		}
		catch (Exception e)
		{}			
	
		return trasformaDataSting(result);
	}
	
}
