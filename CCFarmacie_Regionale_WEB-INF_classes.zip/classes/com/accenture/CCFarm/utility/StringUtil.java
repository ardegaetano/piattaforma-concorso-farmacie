package com.accenture.CCFarm.utility;

import java.io.BufferedReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Clob;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.ResourceBundle;

import com.accenture.CCFarm.exception.GestioneErroriException;

public class StringUtil 
{   
	
	private static SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	
	public static String dateToStringDDMMYYYY(Date data){
		
		try
		{
			if(data==null)
				return null;
			
			return df.format(data);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static Date StringDDMMYYYYToDate(String s){
	
		try
		{
			if(s==null)
				return null;
			
			return (Date)df.parse(s);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	public static String dateToString(Date date, SimpleDateFormat dateFormat)
	{
		try
		{
			if(date==null || dateFormat==null)
				return null;
			return dateFormat.format(date);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static String generateString(Random rng, String characters, int length)
	{
		String aesKey = "C09385B0E84A2B072D64AC3B35433D5C";
	    char[] text = new char[length];
	    for (int i = 0; i < length; i++)
	    {
	        text[i] = characters.charAt(rng.nextInt(characters.length()));
	    }
	    String daCriptare = new String(text);
	    String pedCriptata = CriptDecriptUtil.criptToken(daCriptare, aesKey);
	    return pedCriptata;
	}
	
	public static String eliminaLode(String sCampo) {
		
		sCampo = sCampo.toUpperCase();
		if(sCampo.indexOf('E')>0)
			sCampo = sCampo.substring(0, sCampo.indexOf('E'));
		if(sCampo.indexOf('L')>0)
			sCampo = sCampo.substring(0, sCampo.indexOf('L'));
		sCampo = sCampo.trim();
		
		return sCampo;
	}
	
	public static boolean bIsLode(String sCampo) {
		
		boolean bRet = false;
		sCampo = sCampo.toUpperCase();
		if((sCampo.indexOf('E')>0) || (sCampo.indexOf('L')>0))
			bRet = true;
		return bRet;
	}
	
	//trova la stringa corrispondente alla chiave specificata, all'interno del message bundle dell'applicazione (linguaggio selezionabile)
	public static String getPropertyMessage(String propertyKey,String language)
	{
		try
		{
			String messageBundleName=JSFUtility.getFacesContext().getApplication().getMessageBundle();
			
			ResourceBundle messageBundle=ResourceBundle.getBundle(messageBundleName,new Locale(language));
		
			return messageBundle.getString(propertyKey);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	//cerca il nome che pi� si "avvicina" a quello inserito
	public static String trovaSuggerimento(String name,List<String> existingNames)
	{
		if(name==null || existingNames==null)
			return name;
		
		try
		{
			name=name.toUpperCase();
			String closerMatch=null;
			int distance=0;
			int minDistance=Integer.MAX_VALUE;
			for(String currentName : existingNames)
			{
				distance=StringUtil.levenshtein_distance(name,currentName);
				
				if(distance<minDistance)
				{
					minDistance=distance;
					closerMatch=currentName;
				}
			}
			
			return closerMatch;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	//restituisce una "misura" della similitudine tra 2 stringhe
	public static int levenshtein_distance(String x,String y)
	{
	    int m=x.length();
	    int n=y.length();
	 
	    int i,j;
	    
	    int distance;
	    
	    int d[][]=new int[m+1][n+1];
	    
	    for(i=0;i<=m;i++)
	        d[i][0]=i;
	 
	    for(j=1;j<=n;j++)
	        d[0][j]=j;
	 
	    for(i=1;i<=m;i++)
	    {
	        for(j=1;j<=n;j++)
	        {
	            if(x.charAt(i-1)!=y.charAt(j-1))
	            {
	                int k=minimum(d[i][j-1],d[i-1][j],d[i-1][j-1]);
	                d[i][j]=k+1;
	            }
	            else
	            {
	                d[i][j]=d[i-1][j-1];
	            }
	        }
	    }
	    
	    distance=d[m][n];
	    
	    return distance;
	}	
	

	//restituisce il minimo tra 3 interi
	private static int minimum(int a,int b,int c)
	{
		int min=a;
 
        if(b<min)
        	min=b;
 
        if(c<min)
        	min=c;
        
        return min;
	}
	
	public String bigDecimalToString(BigDecimal number){
		
		
		return number.toString().replace(".", ",");
		
	}
	
	
	
	
	
	public static Date stringToDate(String date,String format)
	{
		//DateUtil.utilDateToSQLDate(StringUtil.stringToDate("19-04-2009","dd-MM-yyyy"));
		try
		{
			if(date==null || format==null)
				return null;
			
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			
			return (Date)sdf.parse(date);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static String convertClob(Clob cl) throws GestioneErroriException{

		try{
		Reader stream = cl.getCharacterStream();
		BufferedReader reader = new BufferedReader(stream);
		StringBuffer sb = new StringBuffer();
		String line = null;
		while ((line=reader.readLine())!=null){
			   sb.append(line+"\r\n");
			  }
		stream.close();
		
		if (sb.length()>0){
			   return sb.toString();
			  }
		
		}catch(Exception e){
			e.printStackTrace();
		}
		  
		   
		  return "";
	}
	
	public static String addZeriTesta(String s, int lenMax) {
		String campo = s;
		while(campo.length()<lenMax){
			campo = "0"+campo;
		}
		return campo;
	}
	
}


	

 