package com.accenture.CCFarm.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.accenture.CCFarm.Bean.Osservazione;
import com.accenture.CCFarm.Bean.Ruolo;
import com.accenture.CCFarm.DAO.ValoriCodice;
import com.accenture.CCFarm.DAO.ValoriCodiceHome;
import com.accenture.CCFarm.exception.GestioneErroriException;

public class CaricaOsservazioni {

	private static List<Osservazione> osservazioni = new ArrayList<Osservazione>(); 
	private static HashMap<String,String> decodificaOsservazioni = new HashMap<String,String>(); 
	
	public static List<Osservazione> getOsservazioni() throws GestioneErroriException
	{
		Osservazione osservazione = null;
		if(osservazioni==null || osservazioni.isEmpty())
		{
			ValoriCodiceHome valoriCodiceHome = new ValoriCodiceHome();
		    ValoriCodice valoriCodice = new ValoriCodice();
		    valoriCodice.setTipoCodice("TIPO_OSSERVAZIONI");
		    List<ValoriCodice> valoriCodiceList = valoriCodiceHome.findByExample(valoriCodice);
			for (int i =0; i<valoriCodiceList.size(); i++){
				valoriCodice = valoriCodiceList.get(i);
				osservazione = new Osservazione();
				osservazione.setCodice(valoriCodice.getIdKey().getCodice());
				osservazione.setDescrizione(valoriCodice.getDescrizione());
				osservazioni.add(osservazione);
				decodificaOsservazioni.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizione());
			}
		}
     return osservazioni;
	}
	
	public static String decodificaosservazione(String codice) throws GestioneErroriException
	{
		String decodifica = null;
		if(osservazioni==null || osservazioni.isEmpty())
		{
			getOsservazioni();
		}
		if (codice!=null) codice = codice.trim();
		decodifica = decodificaOsservazioni.get(codice);
		return decodifica;
	}
	
}
