package com.accenture.CCFarm.utility;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.accenture.CCFarm.DAO.CriteriPunteggi;
import com.accenture.CCFarm.DAO.CriteriPunteggiHome;
import com.accenture.CCFarm.exception.GestioneErroriException;



public class DecodoficaVoti {

	public static HashMap<String,BigDecimal> decodificaVotiLaurea;
	public static List<CriteriPunteggi> listaCriteriPunteggi;
	
	public static HashMap<String,BigDecimal> decodificaVotiAbilitazione;
	
	public static HashMap<String,BigDecimal> getCriteriPunteggiLaurea(String idRegione)
	throws GestioneErroriException{
		
try {
			
			decodificaVotiLaurea = new HashMap();
			
			listaCriteriPunteggi = new ArrayList();
			
			CriteriPunteggiHome criteriPunteggiHome = new CriteriPunteggiHome();
			CriteriPunteggi criteriPunteggi = new CriteriPunteggi();
		
			criteriPunteggi.setIdRegione(idRegione);
			criteriPunteggi.setTipoTitolo("1");
			
			listaCriteriPunteggi = criteriPunteggiHome.findByExample(criteriPunteggi);
			if(listaCriteriPunteggi.size()>0){
			for(CriteriPunteggi criterio : listaCriteriPunteggi){
				decodificaVotiLaurea.put(criterio.getId().getVoto(), criterio.getPunteggio());
			}
			}else
				throw new GestioneErroriException("Tabella decodifica voti laurea non presente");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new GestioneErroriException("Tabella decodifica voti laurea non presente");
		}
		
		return decodificaVotiLaurea;
	}
	
	
	
	public static HashMap<String,BigDecimal> getCriteriPunteggiVotoAbilitazione(String idRegione)throws GestioneErroriException{
		
		try{
			decodificaVotiAbilitazione = new HashMap();
			
			listaCriteriPunteggi = new ArrayList();
			
			CriteriPunteggiHome criteriPunteggiHome = new CriteriPunteggiHome();
			CriteriPunteggi criteriPunteggi = new CriteriPunteggi();
			
			criteriPunteggi.setIdRegione(idRegione);
			criteriPunteggi.setTipoTitolo("2");
			
			listaCriteriPunteggi = criteriPunteggiHome.findByExample(criteriPunteggi);
			
			if(listaCriteriPunteggi.size()>0){
				for(CriteriPunteggi criterio : listaCriteriPunteggi){
					decodificaVotiAbilitazione.put(criterio.getId().getVoto(), criterio.getPunteggio());
				}
			}else{
				throw new GestioneErroriException("Tabella decodifica voti abilitazione non presente");
			}
			
			criteriPunteggi.setIdRegione(idRegione);
			criteriPunteggi.setTipoTitolo("2");
			
		}catch(Exception e){
			e.printStackTrace();
			throw new GestioneErroriException("Tabella decodifica voti abilitazione non presente");
		}
		return decodificaVotiAbilitazione;
	}
	
}
