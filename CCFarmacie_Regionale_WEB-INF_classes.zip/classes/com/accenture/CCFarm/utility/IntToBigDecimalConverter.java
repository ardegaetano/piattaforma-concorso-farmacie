package com.accenture.CCFarm.utility;

import java.math.BigDecimal;

import org.apache.commons.beanutils.Converter;

public class IntToBigDecimalConverter implements Converter
{
	public Object convert(Class type,Object value)
	{
		if(value!=null && (value instanceof Integer) && (type == BigDecimal.class))
		{
			Integer  integ = (Integer) value;
	    	String intStr = integ.toString();
	    	BigDecimal bigDec = new BigDecimal(intStr);
	    	return (bigDec);
		}
		return value; 
	}
}
