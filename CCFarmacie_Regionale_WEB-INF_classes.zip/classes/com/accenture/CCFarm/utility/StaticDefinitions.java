package com.accenture.CCFarm.utility;

import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;


public class StaticDefinitions {

	public static String BASE_PATH = null;
	public static Properties MAIL_PROPERTIES = null;
	private static final Logger log = CommonLogger.getLogger("StaticDefinitions");


	public static Properties getAppProperties() throws Exception{ 

		if(MAIL_PROPERTIES != null){
			return MAIL_PROPERTIES;
		}else{	
			MAIL_PROPERTIES = new Properties();

			try{
				InputStream is = StaticDefinitions.class.getClassLoader().getResourceAsStream("resources/mailProperties.properties");// new FileInputStream(url.getPath());
				MAIL_PROPERTIES.load(is);
			}catch (Exception ex){
				throw ex;
			}			
			return MAIL_PROPERTIES;
		}	
	}

}

