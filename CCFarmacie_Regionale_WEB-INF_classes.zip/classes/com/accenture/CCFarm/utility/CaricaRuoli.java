package com.accenture.CCFarm.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.accenture.CCFarm.Bean.Ruolo;
import com.accenture.CCFarm.DAO.ValoriCodice;
import com.accenture.CCFarm.DAO.ValoriCodiceHome;
import com.accenture.CCFarm.exception.GestioneErroriException;

public class CaricaRuoli {

	private static List<Ruolo> ruoli = new ArrayList<Ruolo>(); 
	private static HashMap<String,String> decodificaRuoli = new HashMap<String,String>(); 
	
	public static List<Ruolo> getRuoli() throws GestioneErroriException
	{
		Ruolo ruolo = null;
		if(ruoli==null || ruoli.isEmpty())
		{
			ValoriCodiceHome valoriCodiceHome = new ValoriCodiceHome();
		    ValoriCodice valoriCodice = new ValoriCodice();
		    valoriCodice.setTipoCodice("TIPO_RUOLO");
		    List<ValoriCodice> valoriCodiceList = valoriCodiceHome.findByExample(valoriCodice);
			for (int i =0; i<valoriCodiceList.size(); i++){
				valoriCodice = valoriCodiceList.get(i);
				ruolo = new Ruolo();
				ruolo.setCodice(valoriCodice.getIdKey().getCodice());
				ruolo.setDescrizione(valoriCodice.getDescrizione());
				ruoli.add(ruolo);
				decodificaRuoli.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizione());
			}
		}
     return ruoli;
	}
	
	public static String decodificaruolo(String codice)
	{
		String decodifica = null;
		decodifica = decodificaRuoli.get(codice);
		return decodifica;
	}
	
}
