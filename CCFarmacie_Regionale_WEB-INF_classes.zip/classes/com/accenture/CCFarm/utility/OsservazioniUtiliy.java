package com.accenture.CCFarm.utility;

import java.sql.Date;
import java.text.SimpleDateFormat;

import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.CandidaturaReg;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.RequisitiMinimiReg;
import com.accenture.CCFarm.DAO.RequisitiMinimiRegHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.exception.GestioneErroriException;

public class OsservazioniUtiliy {
	SimpleDateFormat fs  = new SimpleDateFormat("dd-MM-yyyy");
	RequisitiMinimiReg requisitiMinimiReg = new RequisitiMinimiReg();
	RequisitiMinimiRegHome requisitiMinimiRegHome = new RequisitiMinimiRegHome();
		
	
	public OsservazioniUtiliy() {
	
	}
	
	public boolean isOssProvIscAlbo(String id_utente) throws GestioneErroriException{
	    
		requisitiMinimiReg = requisitiMinimiRegHome.findById(id_utente);
//controllo Attuale provincia d�iscrizione all�albo non valorizzata";
		if (requisitiMinimiReg.getIdDomandaReq()!=null && requisitiMinimiReg.getPrvAttualeAlbo()==null){
			return true;
		} else{
			return false;
		}
		
	}
	public boolean isOssDAlboDAbil(String id_utente) throws GestioneErroriException{
		
		requisitiMinimiReg = requisitiMinimiRegHome.findById(id_utente);
//controllo Data prima iscrizione all�albo precedente all�anno di abilitazione
		if (requisitiMinimiReg.getIdDomandaReq()!=null && requisitiMinimiReg.getDataAlbo()!=null && requisitiMinimiReg.getAnnoAbilitazione()!=null){
			int annoIscrizione = trasformaData(requisitiMinimiReg.getDataAlbo());
			int annoAbilitazione = Integer.parseInt(requisitiMinimiReg.getAnnoAbilitazione().toString());
			if (annoIscrizione < annoAbilitazione){
				return true;	
			} else {
				return false;
			}
		} else{
			return false;
		}
			
		
	}

	public boolean isOssDDocDNasc(String dataNasc, String dataDoc) throws GestioneErroriException{
		
//controllo Data rilascio doc. di riconoscimento uguale alla data di nascita
		if (dataNasc.equals(dataDoc)){
			return true;
		} else{
			return false;
		}
		
	}
	
	private int trasformaData(java.util.Date data){
		String dataString = fs.format(data);
//		String dataConfert = dataString.substring(6, dataString.length())  +
//				 dataString.substring(3, 5)  +
//	             dataString.substring(0, 2)  ;
		String dataConfert = dataString.substring(6, dataString.length()) ;
		return Integer.parseInt(dataConfert);
	}

	
}
