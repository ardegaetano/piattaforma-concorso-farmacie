package com.accenture.CCFarm.utility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.accenture.CCFarm.Bean.ComuneSelect;
import com.accenture.CCFarm.Bean.NazioneSelect;
import com.accenture.CCFarm.Bean.ProvinciaSelect;
import com.accenture.CCFarm.Bean.RegioneSelect;
import com.accenture.CCFarm.DAO.Comune;
import com.accenture.CCFarm.DAO.ComuneHome;
import com.accenture.CCFarm.DAO.Nazione;
import com.accenture.CCFarm.DAO.NazioneHome;
import com.accenture.CCFarm.DAO.Provincia;
import com.accenture.CCFarm.DAO.ProvinciaHome;
import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.exception.GestioneErroriException;



public class Localita {

	private static List regioni = null;
	private static List province = null;
	private static List comuni = null;
	private static List<NazioneSelect> nazioniSelect = null;
	private static List<NazioneSelect> nazioniSEESelect = null;
	private static List<RegioneSelect> regioniSelect = null;
	private static List<ProvinciaSelect> provinceSelect = null;
	private static List<ComuneSelect> comuniSelect = null;
	private static HashMap<String, ArrayList<ProvinciaSelect>> provinceMap = new HashMap<String, ArrayList<ProvinciaSelect>>();
	private static HashMap<String, ArrayList<ComuneSelect>> comuniMap = new HashMap<String, ArrayList<ComuneSelect>>();
	private static HashMap<String, String> decodificaNazioniMap = null;
	private static HashMap<String, String> decodificaRegioniMap = null;
	private static HashMap<String, String> decodificaProvinceMap = null;
	private static HashMap<String, String> decodificaSiglaProvinceMap = null;
	private static HashMap<String, String> decodificaComuniMap = null;
	
	public static List<NazioneSelect> getNazioni() throws GestioneErroriException
	{
		if(nazioniSelect==null)	{
			 List<Nazione> nazioni = null;
			//recupero tramite l'apposita home tutte le nazioni dal db
			NazioneSelect nazioneSelect;
			NazioneHome nazionehome = new NazioneHome();
			Nazione nazione = new Nazione();
			nazioni = nazionehome.findByExample(nazione);
			
			//popola lista delle nazioni
			nazioniSelect=new ArrayList<NazioneSelect>();
			
			Iterator it=nazioni.iterator();
			while(it.hasNext())
			{
				nazione=(Nazione)(it.next());
				
					nazioneSelect = new NazioneSelect();
					nazioneSelect.setCodice(nazione.getCodIsoNazione());
					nazioneSelect.setDescrizione(nazione.getDscIsoNazione());
					nazioniSelect.add(nazioneSelect);
			}
			Collections.sort(nazioniSelect);
			
		}
		return nazioniSelect;
	}
	
	public static List<NazioneSelect> getNazioniEuropee() throws GestioneErroriException
	{
		if(nazioniSEESelect==null)	{
			 List<Nazione> nazioni = null;
			//recupero tramite l'apposita home tutte le nazioni dal db
			NazioneSelect nazioneSelect;
			NazioneHome nazionehome = new NazioneHome();
			Nazione nazione = new Nazione();
			nazioni = nazionehome.findByExample(nazione);
			
			//popola lista delle nazioni
			nazioniSEESelect=new ArrayList<NazioneSelect>();
			
			Iterator it=nazioni.iterator();
			while(it.hasNext())
			{
				nazione=(Nazione)(it.next());
				int flagUe=Integer.parseInt(nazione.getFlagStatoUe());
				if(flagUe>0)
				{
					nazioneSelect = new NazioneSelect();
					nazioneSelect.setCodice(nazione.getCodIsoNazione());
					nazioneSelect.setDescrizione(nazione.getDscIsoNazione());
					nazioniSEESelect.add(nazioneSelect);
				}
			}
			
			Collections.sort(nazioniSEESelect);
			
		}
		return nazioniSEESelect;
	}

	
	public static List<RegioneSelect> getRegioni() 
	{
		
		if(regioniSelect==null)
		{
			RegioneHome regioneHome = new RegioneHome();
			Regione regione = new Regione();
			regioni = regioneHome.findByExample(regione);
			
			//popola lista delle nazioni
			RegioneSelect regioneSelect = null;
			regioniSelect= new ArrayList<RegioneSelect>();
						
			Iterator it=regioni.iterator();
			while(it.hasNext())
			{
				regione=(Regione)(it.next());
				regioneSelect = new RegioneSelect();
				regioneSelect.setDescrizione(regione.getDenominazioneReg());
				regioneSelect.setCodice(regione.getCodReg());
				regioniSelect.add(regioneSelect);
			}
			
			Collections.sort(regioniSelect);	
		}
		return regioniSelect;
	}
	
	public static HashMap<String, ArrayList<ProvinciaSelect>> getProvince(String codiceRegione) throws GestioneErroriException{
		List<ProvinciaSelect> provinceSelect=new ArrayList<ProvinciaSelect>();
		ArrayList<ProvinciaSelect> listaProvince = new ArrayList<ProvinciaSelect>();
		
			listaProvince = provinceMap.get(codiceRegione);
			
				if(listaProvince==null)	{
					ProvinciaHome provinciaHome = new ProvinciaHome();
					Provincia provincia = new Provincia();
					if(province==null){
						province = provinciaHome.findByExample(provincia);
					}
					
					
				   //popola lista delle province
				   ProvinciaSelect provinciaSelect=null;
				
					Iterator it=province.iterator();
					while(it.hasNext())
					{
						provincia=(Provincia)(it.next());
						if(!codiceRegione.equals("0")){
							//lista province dipendente dalla regione
								if(provincia.getCodiceRegione().equals(codiceRegione)){
										provinciaSelect=new ProvinciaSelect();
										provinciaSelect.setCodice(provincia.getCodiceProvincia());
										provinciaSelect.setDescrizione(provincia.getDenominazioneProvincia());
										provinceSelect.add(provinciaSelect);
								}
							
								Collections.sort(provinceSelect);	
								provinceMap.put(codiceRegione, (ArrayList<ProvinciaSelect>) provinceSelect);
								
							}
							//lista provincie indioendente dalla regione
							else{
								provinciaSelect=new ProvinciaSelect();
								provinciaSelect.setCodice(provincia.getCodiceProvincia());
								provinciaSelect.setDescrizione(provincia.getDenominazioneProvincia());
								provinceSelect.add(provinciaSelect);
									
								Collections.sort(provinceSelect);
								provinceMap.put("0", (ArrayList<ProvinciaSelect>) provinceSelect);
							}
						
						}
				}
		return provinceMap;
	}
	
	public static HashMap<String, ArrayList<ComuneSelect>> getComuni(String codiceProvincia) throws GestioneErroriException{
		List<ComuneSelect> comuniSelect=new ArrayList<ComuneSelect>();
		ArrayList<ComuneSelect> lista = new ArrayList<ComuneSelect>();
		
			
		lista = comuniMap.get(codiceProvincia);
		
		if(lista==null)	{
			ComuneHome comuneHome = new ComuneHome();
			Comune comune = new Comune();
			comune.setCodiceProvincia(codiceProvincia);
			comuni = comuneHome.findByExample(comune);
			
		
		
		//popola lista dei comuni
		ComuneSelect comuneSelect=null;
		
		Iterator it=comuni.iterator();
		while(it.hasNext())
		{
			comune=(Comune)(it.next());
						
			if(comune.getCodiceProvincia().equals(codiceProvincia)){
				comuneSelect = new ComuneSelect();
				comuneSelect.setCodice(comune.getCodiceComune());
				comuneSelect.setDescrizione(comune.getDenominazione());
				comuniSelect.add(comuneSelect);
				}
			
			Collections.sort(comuniSelect);
			
						
			}
		comuniMap.put(codiceProvincia, (ArrayList<ComuneSelect>) comuniSelect);
		
		
		}
		
		return comuniMap;
	}
	
	//--------------------------------------------------------------------
	
	public static HashMap<String, String> getDecodificaNazioniMap(){
		
		if(decodificaNazioniMap==null||decodificaNazioniMap.isEmpty())
		{
			if(nazioniSelect==null||nazioniSelect.isEmpty()){
				try {
					nazioniSelect=getNazioni();
				} catch (GestioneErroriException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				decodificaNazioniMap = new HashMap<String, String>();
				for(int i=0;i<nazioniSelect.size();i++){
					decodificaNazioniMap.put(nazioniSelect.get(i).getCodice(), nazioniSelect.get(i).getDescrizione());
				}
		}
		return decodificaNazioniMap;
	}
	
	public static HashMap<String, String> getDecodificaRegioniMap(){
			
		if(decodificaRegioniMap==null||decodificaRegioniMap.isEmpty())
		{
			if(regioniSelect==null||regioniSelect.isEmpty()){
				try {
					regioniSelect=getRegioni();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			decodificaRegioniMap = new HashMap<String, String>();
				for(int i=0;i<regioniSelect.size();i++){
					String reg =regioniSelect.get(i).getCodice();
					String reg2 = regioniSelect.get(i).getDescrizione();
					decodificaRegioniMap.put(reg, reg2);
				}
		}
		return decodificaRegioniMap;
	}
	
	public static HashMap<String, String> getDecodificaProvinceMap() throws GestioneErroriException{
		
		if(decodificaProvinceMap==null||decodificaProvinceMap.isEmpty()){
			
			decodificaProvinceMap = new HashMap<String, String>();
			provinceSelect = new ArrayList<ProvinciaSelect>();
			ProvinciaSelect provinciaSelect = new ProvinciaSelect();
			
			ProvinciaHome provinciaHome = new ProvinciaHome();
			Provincia provincia = new Provincia();
			province = provinciaHome.findByExample(provincia);
			
			Iterator it=province.iterator();
			while(it.hasNext())
			{
				provincia=(Provincia)(it.next());
				provinciaSelect = new ProvinciaSelect();
				provinciaSelect.setDescrizione(provincia.getDenominazioneProvincia());
				provinciaSelect.setCodice(provincia.getCodiceProvincia());
				provinceSelect.add(provinciaSelect);
			}
			
			Collections.sort(provinceSelect);	
				for(int i=0;i<provinceSelect.size();i++){
					decodificaProvinceMap.put(provinceSelect.get(i).getCodice(), provinceSelect.get(i).getDescrizione());
					}
		}
					
			return decodificaProvinceMap;
	}
	
	public static HashMap<String, String> getDecodificaSiglaProvinceMap() throws GestioneErroriException{
		
		if(decodificaSiglaProvinceMap==null||decodificaSiglaProvinceMap.isEmpty()){
			
			decodificaSiglaProvinceMap = new HashMap<String, String>();
			provinceSelect = new ArrayList<ProvinciaSelect>();
			ProvinciaSelect provinciaSelect = new ProvinciaSelect();
			
			ProvinciaHome provinciaHome = new ProvinciaHome();
			Provincia provincia = new Provincia();
			province = provinciaHome.findByExample(provincia);
			
			Iterator it=province.iterator();
			while(it.hasNext())
			{
				provincia=(Provincia)(it.next());
				provinciaSelect = new ProvinciaSelect();
				provinciaSelect.setDescrizione(provincia.getDenominazioneProvincia());
				provinciaSelect.setSigla(provincia.getSiglaAutomobilistica());
				provinciaSelect.setCodice(provincia.getCodiceProvincia());
				provinceSelect.add(provinciaSelect);
			}
			
			Collections.sort(provinceSelect);	
				for(int i=0;i<provinceSelect.size();i++){
					decodificaSiglaProvinceMap.put(provinceSelect.get(i).getCodice(), provinceSelect.get(i).getSigla());
					}
		}
					
			return decodificaProvinceMap;
	}
	
	public static HashMap<String, String> getDecodificaComuniMap() throws GestioneErroriException{
			
		if(decodificaComuniMap==null||decodificaComuniMap.isEmpty()){
			
			decodificaComuniMap = new HashMap<String, String>();
			comuniSelect = new ArrayList<ComuneSelect>();
			ComuneSelect comuneSelect = new ComuneSelect();
			
			ComuneHome comuneHome = new ComuneHome();
			Comune comune = new Comune();
			comuni = comuneHome.findByExample(comune);
			
			Iterator it=comuni.iterator();
			while(it.hasNext())
			{
				comune=(Comune)(it.next());
				comuneSelect = new ComuneSelect();
				comuneSelect.setDescrizione(comune.getDenominazione());
				comuneSelect.setCodice(comune.getCodiceComune());
				comuniSelect.add(comuneSelect);
			}
			
			Collections.sort(comuniSelect);	
				for(int i=0;i<comuniSelect.size();i++){
					decodificaComuniMap.put(comuniSelect.get(i).getCodice(), comuniSelect.get(i).getDescrizione());
					}
			}
					
			return decodificaComuniMap;
	}
	
	//--------------------------------------------------------------------
	
	public static String getDenominazioneNazione(String codice){
		
		String denominazioneNazioneString ="";
		
		if(decodificaNazioniMap==null||decodificaNazioniMap.isEmpty()){
			getDecodificaNazioniMap();
		}
		
		denominazioneNazioneString = decodificaNazioniMap.get(codice);
		
		return denominazioneNazioneString;
	}
	
	public static String getDenominazioneRegione(String codice){
		
		String denominazioneRegioneString ="";
		
		if(decodificaRegioniMap==null||decodificaRegioniMap.isEmpty()){
			getDecodificaRegioniMap();
		}
		
		denominazioneRegioneString = decodificaRegioniMap.get(codice);
		
		return denominazioneRegioneString;
	}
	
	public static String getDenominazioneProvincia(String codice){
		
		String denominazioneProvinciaString ="";
		
		if(decodificaProvinceMap==null||decodificaProvinceMap.isEmpty()){
			try {
				getDecodificaProvinceMap();
			} catch (GestioneErroriException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		denominazioneProvinciaString = decodificaProvinceMap.get(codice);
		
		return denominazioneProvinciaString;
	}
	
	public static String getDenominazioneSiglaProvincia(String codice){
		
		String denominazioneSiglaProvinciaString ="";
		
		if(decodificaSiglaProvinceMap==null||decodificaSiglaProvinceMap.isEmpty()){
			try {
				getDecodificaSiglaProvinceMap();
			} catch (GestioneErroriException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		denominazioneSiglaProvinciaString = decodificaSiglaProvinceMap.get(codice);
		
		return denominazioneSiglaProvinciaString;
	}
	
	public static String getDenominazioneComune(String codice){
		
		String denominazioneComuneString ="";
		
		if(decodificaComuniMap==null||decodificaComuniMap.isEmpty()){
			try {
				getDecodificaComuniMap();
			} catch (GestioneErroriException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		denominazioneComuneString = decodificaComuniMap.get(codice);
		
		return denominazioneComuneString;
	}
		
}
