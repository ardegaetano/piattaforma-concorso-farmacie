package com.accenture.CCFarm.utility;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Date;

public class DateUtil
{
	
	//converte una data util in un timestamp sql
	public static java.sql.Timestamp utilDateToSqlTimestamp(java.util.Date utilDate)
	{
		if(utilDate != null)
			return new java.sql.Timestamp(utilDate.getTime());
		else
			return null;
	}
	
	//converte un timestamp sql in una data util
	public static java.util.Date sqlTimestampToUtilDate(java.sql.Timestamp sqlTimestamp)
	{
		if(sqlTimestamp != null)
			return new java.util.Date(sqlTimestamp.getTime());
		else
			return null;
	}
		
	//converte una data util in una sql
	public static java.sql.Date utilDateToSQLDate(java.util.Date utilDate)
	{
		if(utilDate!=null)
			return new java.sql.Date(utilDate.getTime());
		else 
			return null;
	}
	
	//converte una data sql in una util
	public static java.util.Date sqlDateToUtilDate(java.sql.Date sqlDate)
	{	
    	if(sqlDate!=null)
    		return new java.util.Date(sqlDate.getTime());
    	else 
    		return null;
	}
	
	public static int getYearFromDate(java.util.Date date)
	{
		if(date!=null)
		{
			Calendar calendar=Calendar.getInstance();
	        calendar.setTime(date);
	        return calendar.get(Calendar.YEAR);
		}
		return 0;
	}
	
	//ricava timestamp (sql) dell'istante corrente
	public static java.sql.Timestamp getCurrentTimestamp()
	{
		return new java.sql.Timestamp(new java.util.Date().getTime());
	}
	
	public static BigDecimal getEtaMedia(java.util.Date d1 , java.util.Date dtRiff){
		
		double differenzaGiorni= (dtRiff.getTime() - d1.getTime());
		differenzaGiorni = differenzaGiorni / 1000;
		differenzaGiorni = differenzaGiorni / (60 * 60);
		differenzaGiorni = differenzaGiorni / 24;
		differenzaGiorni = differenzaGiorni / 365;
		MathContext MC =new MathContext(6,RoundingMode.HALF_UP);
		BigDecimal etaMediaUtente =new BigDecimal(differenzaGiorni,MC);

		return etaMediaUtente ;
	}
	
	//restituisce l'oggetto data che rappresenta la data odierna
    public static Date dataOdierna() {
    	
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date(System.currentTimeMillis()));
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
    }
	
    public static int calcolaDifferenzaDate(Date dataInizio, Date dataFine) {
    	
    	if(dataInizio == null || dataFine == null)
    		return 0;
    	
    	return (int) ((dataFine.getTime() - dataInizio.getTime()) / (24 * 60 * 60 * 1000.0));
    }
    
	public static java.util.Date getDataEstremoIntervallo(java.util.Date dataIniziale, int numeroGiorni, int orario) {
		
		if(dataIniziale == null)
			return null;
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dataIniziale);
		calendar.add(Calendar.DATE, numeroGiorni);
		calendar.set(Calendar.HOUR_OF_DAY, orario);
		return calendar.getTime();
	}
	
	//restituisce la data specificata con l'orario impostato secondo parametro
    public static Date setOrarioData(Date date, int hour) {
    	
    	if(date == null)
    		return null;
    	
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
    }
    
    public static boolean isSunday(Date dataInizio) {
		Calendar c = Calendar.getInstance();
		c.setTime(dataInizio);
	    return (c.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY); 
	}
}
