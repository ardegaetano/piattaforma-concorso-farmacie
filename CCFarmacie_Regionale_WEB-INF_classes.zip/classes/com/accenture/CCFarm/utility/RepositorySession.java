package com.accenture.CCFarm.utility;

import java.util.List;

import com.accenture.CCFarm.Bean.UtenteTitoli;


public class RepositorySession {

	public final static String ID_REGIONE = "ID_REGIONE"; 
	public final static String DATI_BANDO  = "DATI_BANDO"; 
	public final static String FILE_BANDO  = "FILE_BANDO"; 
	public final static String REGIONI_DATI_BANDO = "REGIONI_DATI_BANDO"; 
	
	// STATO_BANDO_REGIONE  = G = grigio
//							  V = verde
//						      Y = giallo
//						      R = rosso
	public final static String STATO_BANDO_REGIONE = "STATO_BANDO_REGIONE"; 
	public final static String ID_UTENTE = "ID_UTENTE"; 
	public final static String NOME_UTENTE = "NOME_UTENTE"; 
	public final static String COGNOME_UTENTE = "COGNOME_UTENTE"; 
	public final static String MAP_REGIONE = "MAP_REGIONE"; 
	public final static String USER_SESSION = "USER_SESSION"; 
	public final static String PASSWORD_SESSION = "PASSWORD_SESSION"; 
	public final static String UTENTE_NSIS = "USER"; 
	public final static String UTENTE_ID_NSIS = "USER_ID"; 
	public final static String TOKEN_SAML_NSIS = "tokenSAML"; 
	public final static String NOME_APPLICAZIONE_NSIS = "nomeApplicazione"; 
	public final static String BOXI_LINK_NSIS = "BOXI_LINK"; 
	
	public final static String IDMSG_ERROR_LOGIN = "IDMSG_ERROR_LOGIN"; 
	public final static String RETURN_ERROR_LOGIN = "RETURN_ERROR_LOGIN"; 
	public final static String CANDIDATURA = "CANDIDATURA"; 
	public final static String PRIMO_ACCESSO = "PRIMO_ACCESSO"; 
	public final static String CHIAMO_STAMPA_DA_FUORI = "CHIAMO_STAMPA_DA_FUORI";
	
	public final static String ID_UTENTE_RETTIFICA = "ID_UTENTE_RETTIFICA";
	public final static String PAGE_SEND = "PAGE_SEND";
	public final static String PAGE_RETURN = "PAGE_RETURN";
	public final static String ID_CANDIDATURA = "ID_CANDIDATURA";
	public final static String UTENTE_TITOLI_LIST = "UTENTE_TITOLI_LIST";
	
	public final static String TOTALE_TITOLI = "TOTALE_TITOLI";
	public final static String TOTALE_ESP_PROF = "TOTALE_ESP_PROF";
	public final static String TOTALE_PUNTEGGIO = "TOTALE_PUNTEGGIO";
	
	public final static String TIPO_GRADUATORIA = "TIPO_GRADUATORIA"; 
	public final static String TIPO_GRAD_RELOAD= "TIPO_GRAD_RELOAD"; 
	public final static String FILE_ATTO_ABBINISTRATIVO = "FILE_ATTO_ABBINISTRATIVO"; 
//	public final static String  = ""; 
//	public final static String  = ""; 
//	public final static String  = ""; 
	
	
	
	
}
