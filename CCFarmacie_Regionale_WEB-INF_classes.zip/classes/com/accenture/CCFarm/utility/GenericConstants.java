package com.accenture.CCFarm.utility;

import java.util.HashMap;
import java.util.Map;

public class GenericConstants {

	public static String SERVER_ABSOLUTE_PATH = ""; //viene impostato dalla StartUpAction
	
	//Ruoli NSIS
	public static String RUOLO_UT_REGIONALE = "UTENTE_REGIONALE_CONCORSO";
	public static String RUOLO_UT_COMMISSIONE = "UTENTE_COMMISSIONE_CONCORSO";
	public static String RUOLO_UT_AREA_DOCUMENTALE = "AREA_DOCUMENTALE_CONCFARMA";
	public static String RUOLO_UT_BO = "BO_CONCFARMA";
	
	public static String TIPO_PUNTEGGI_LAUREA = "1";
	public static String TIPO_PUNTEGGI_ABILITAZIONE = "2";
	
	// Parametri BO
	//////////////////////////
	public static final String LINK_BO = "https://nsis.sanita.it/BOXI/InfoViewApp/logon-CCFarm.jsp";
	public static final String UTENZA_BO = "CCFARM";
	//////////////////////////
		
	private static Map<String,String> mpRegioni = null;
	
	private static Map<String,String> getMappaRegioni(){
		
		if(mpRegioni==null){
			mpRegioni = new HashMap<String,String>(); 
	//		Codici Regioni
			mpRegioni.put("010", "PIEMONTE");
			mpRegioni.put("020", "VALLE D'AOSTA");
			mpRegioni.put("030", "LOMBARDIA");
			mpRegioni.put("041", "PROVINCIA AUTONOMA BOLZANO");
			mpRegioni.put("042", "PROVINCIA AUTONOMA TRENTO");
			mpRegioni.put("050", "VENETO");
			mpRegioni.put("060", "FRIULI VENEZIA GIULIA");
			mpRegioni.put("070", "LIGURIA");
			mpRegioni.put("080", "EMILIA ROMAGNA");
			mpRegioni.put("090", "TOSCANA");
			mpRegioni.put("100", "UMBRIA");
			mpRegioni.put("110", "MARCHE");
			mpRegioni.put("120", "LAZIO");
			mpRegioni.put("130", "ABRUZZO");
			mpRegioni.put("140", "MOLISE");
			mpRegioni.put("150", "CAMPANIA");
			mpRegioni.put("160", "PUGLIA");
			mpRegioni.put("170", "BASILICATA");
			mpRegioni.put("180", "CALABRIA");
			mpRegioni.put("190", "SICILIA");
			mpRegioni.put("200", "SARDEGNA");
		}	
		return 	mpRegioni;
	}
	
	public static String getDescrRegioneByCod(String cod){
		
		return getMappaRegioni().get(cod);
	}
	
}
