package com.accenture.CCFarm.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import com.accenture.CCFarm.Bean.DocumentoIdentita;
import com.accenture.CCFarm.DAO.ValoriCodice;
import com.accenture.CCFarm.DAO.ValoriCodiceHome;
import com.accenture.CCFarm.exception.GestioneErroriException;

public class TabellaDecodifica extends Hashtable {
	
	private static TabellaDecodifica tabella = null ;
	private static List<DocumentoIdentita> documentiIdentita = new ArrayList<DocumentoIdentita>(); 
	private static HashMap<String,String> decodificaDocumentiIdentita = new HashMap<String,String>(); 
	
	private TabellaDecodifica(){
		
	}
	
	public static TabellaDecodifica getTabellaDecodifica() throws GestioneErroriException {
		
		if(tabella== null){
			ValoriCodiceHome valoriCodiceHome = new ValoriCodiceHome();
			ValoriCodice valoriCodice = new ValoriCodice();
			List lista = valoriCodiceHome.findByExample(valoriCodice);
			tabella = new TabellaDecodifica();
			for (int i=0; i< lista.size(); i++){
				valoriCodice =(ValoriCodice) lista.get(i);
				tabella.put(valoriCodice.getIdKey().getCodice() + "_" + valoriCodice.getIdKey().getTipoCodice() , valoriCodice.getDescrizione());
			}
			return tabella;
		}else{
			return tabella;
		}
		
	}
	
	public static List<DocumentoIdentita> getDocumentoIdentita() throws GestioneErroriException
	{
		DocumentoIdentita documentoIdentita = null;
		if(documentiIdentita==null || documentiIdentita.isEmpty())
		{
			ValoriCodiceHome valoriCodiceHome = new ValoriCodiceHome();
		    ValoriCodice valoriCodice = new ValoriCodice();
		    valoriCodice.setTipoCodice("TIPO_DOC_RICONOSCIMENTO");
		    List<ValoriCodice> valoriCodiceList = valoriCodiceHome.findByExample(valoriCodice);
			for (int i =0; i<valoriCodiceList.size(); i++){
				valoriCodice = valoriCodiceList.get(i);
				documentoIdentita = new DocumentoIdentita();
				documentoIdentita.setCodice(valoriCodice.getIdKey().getCodice());
				documentoIdentita.setDescrizione(valoriCodice.getDescrizione());
				documentiIdentita.add(documentoIdentita);
				decodificaDocumentiIdentita.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizione());
			}
		}
     return documentiIdentita;
	}
	
	public static String decodificaDocumentoIdentita(String codice)
	{
		if(decodificaDocumentiIdentita!=null && !decodificaDocumentiIdentita.isEmpty())
		{
			return decodificaDocumentiIdentita.get(codice);
		}
		return null;
	}
}
