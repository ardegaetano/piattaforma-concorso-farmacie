package com.accenture.CCFarm.utility;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;


public class AppProperties extends Properties {
	
	private static AppProperties appProperties = null;
	

	private AppProperties(){
		
		//URL url = AppProperties.class.getResource("/resources/application.properties");
		
		InputStream is  = AppProperties.class.getClassLoader().getResourceAsStream("resources/application.properties");
	    
		try{
			//InputStream is = new FileInputStream(url.getPath());
			load(is);
		}catch (Exception ex){
				
		}			
        
	}
	
	public static AppProperties getAppProperties(){ 
		
		if(appProperties != null){
		 return appProperties;
		}else{	
			appProperties = new AppProperties();
			return appProperties;
		}	
	}

}
