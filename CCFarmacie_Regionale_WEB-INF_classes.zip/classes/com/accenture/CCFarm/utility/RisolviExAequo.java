package com.accenture.CCFarm.utility;


import java.math.BigDecimal;
import java.util.List;

import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.exception.GestioneErroriException;


public class RisolviExAequo {

	/*private HashMap<String, String> exAequoRisolti;
	private HashMap<String, String> exAequoNoRisolti;
	
	
	public void risolviexAequo(List<Graduatoria> listaGraduatoria) {
		exAequoRisolti = new HashMap<String, String>();
		exAequoNoRisolti = new HashMap<String, String>();
		String keyRisolti;
		String keyNoRisolti;
		for (int i = 0; i < listaGraduatoria.size() - 1; i++) {
			
			if(i==0){
				keyRisolti= listaGraduatoria.get(0).getPunteggio().toString().replace(".", ",");
				keyNoRisolti = listaGraduatoria.get(0).getPunteggio().toString().replace(".", ",")+"_"+listaGraduatoria.get(i).getEtaMedia().toString().replace(".", ",");
				exAequoNoRisolti.put(keyNoRisolti, "");
				exAequoRisolti.put(keyRisolti, "");
				Graduatoria primoUtente = listaGraduatoria.get(i);
				Graduatoria secondoUtente = listaGraduatoria.get(i + 1);
				
				if (primoUtente.getPunteggio().compareTo(secondoUtente.getPunteggio()) == 0) {
					primoUtente.setExAequo("T");
					primoUtente.setColor("red");
					
					//secondoUtente.setExAequo("T");
					//secondoUtente.setColor("red");
					if (primoUtente.getEtaMedia().compareTo(secondoUtente.getEtaMedia()) == 0) {
						primoUtente.setExAequoRisolto("F");
						//secondoUtente.setExAequoRisolto("F");
						
					} else {
						
						primoUtente.setExAequoRisolto("T");
						primoUtente.setColor("green");
						
						//secondoUtente.setExAequoRisolto("T");
						//secondoUtente.setColor("green");
						
					}

				}
			}else{
				keyRisolti= listaGraduatoria.get(i).getPunteggio().toString().replace(".", ",");
				keyNoRisolti = listaGraduatoria.get(i).getPunteggio().toString().replace(".", ",")+"_"+listaGraduatoria.get(i).getEtaMedia().toString().replace(".", ",");
				
				if(exAequoNoRisolti.containsKey(keyNoRisolti)){
					listaGraduatoria.get(i).setExAequo("T");
					listaGraduatoria.get(i).setExAequoRisolto("F");
					listaGraduatoria.get(i).setColor("red");
					exAequoNoRisolti.put(keyNoRisolti, "");
				}else if(exAequoRisolti.containsKey(keyRisolti)){
					listaGraduatoria.get(i).setExAequo("T");
					listaGraduatoria.get(i).setExAequoRisolto("T");
					listaGraduatoria.get(i).setColor("green");
					exAequoRisolti.put(keyRisolti, "");
				}
				
				
			}
			
			
			exAequoNoRisolti.put(keyNoRisolti, "");
			exAequoRisolti.put(keyRisolti, "");
		}
	

	}*/
	
	
	

public void risolviexAequoSuGraduatoria(List<Graduatoria> listaGraduatoria) throws GestioneErroriException {

	
		
		
		int posizione = 0;
		int j=1;
		
		
		
/*		for (int i=0;i < listaGraduatoria.size() - 1; i++){
			Graduatoria grad= listaGraduatoria.get(i);
			
			for(int j=0;j<listaGraduatoria.size();j++){     
				//if(grad.getIdCandidatura()!=listaGraduatoria.get(j).getIdCandidatura()){
				
				if(i!=j){
					if(listaGraduatoria.get(j).getExAequoRisolto()==null)
						if(grad.getPunteggio().compareTo(listaGraduatoria.get(j).getPunteggio()) == 0){
							listaGraduatoria.get(j).setExAequo("T");
							listaGraduatoria.get(j).setColor("red");
							//listaGraduatoria.get(j).setExAequo("T");
							//listaGraduatoria.get(j).setColor("green");

							if(grad.getEtaMedia().compareTo(listaGraduatoria.get(j).getEtaMedia())==0){
								listaGraduatoria.get(j).setExAequoRisolto("F");
								//listaGraduatoria.get(j).setExAequoRisolto("F");
								if((listaGraduatoria.get(j).getRettifica()!=null && grad.getRettifica().equalsIgnoreCase("true")) || (listaGraduatoria.get(j).getRettifica()!=null && listaGraduatoria.get(j).getRettifica().equalsIgnoreCase("true"))){
									for(Graduatoria g :graduatoriaListExAequoRisolti){
										if(listaGraduatoria.get(j).getRettifica().equalsIgnoreCase("true")){
											if(listaGraduatoria.get(j).getPunteggio().compareTo(g.getPunteggio())==0 && grad.getEtaMedia().compareTo(g.getEtaMedia())==0){
												g.setExAequoRisolto("F");
												grad.setRettifica("false");
											}
											
										}else{
											if(listaGraduatoria.get(j).getPunteggio().compareTo(g.getPunteggio())==0 && listaGraduatoria.get(j).getEtaMedia().compareTo(g.getEtaMedia())==0){
												g.setExAequoRisolto("F");
												
											}
										}
									}
									
									
								}
							
							}else {
								listaGraduatoria.get(j).setExAequoRisolto("T");
								listaGraduatoria.get(j).setColor("green");
								//listaGraduatoria.get(j).setExAequoRisolto("T");
								//listaGraduatoria.get(j).setColor("green");
								
							}
							
						}
					
				}
		
				//}
				
			}
			
		}*/
/*	for (int i = 0; i < listaGraduatoria.size() - 1; i++) {
			Graduatoria primoUtente = listaGraduatoria.get(i);
			Graduatoria secondoUtente = listaGraduatoria.get(i + 1);
		if(primoUtente.getColor()!=null && primoUtente.getColor().equalsIgnoreCase("blue") || secondoUtente.getColor()!=null && secondoUtente.getColor().equalsIgnoreCase("blue")){
			
		}else{
			if (primoUtente.getPunteggio().compareTo(secondoUtente.getPunteggio()) == 0) {
				if(primoUtente.getExAequoRisolto()!=null && primoUtente.getExAequoRisolto().equalsIgnoreCase("F") ){
					secondoUtente.setExAequo("T");
					secondoUtente.setExAequoRisolto("T");
					secondoUtente.setColor("green");
				}else{
					primoUtente.setExAequo("T");
					primoUtente.setColor("green");
					primoUtente.setExAequoRisolto("T");
					secondoUtente.setExAequo("T");
					secondoUtente.setExAequoRisolto("T");
					secondoUtente.setColor("green");
				}
				
				
				
				if (primoUtente.getEtaMedia().compareTo(secondoUtente.getEtaMedia()) == 0) {
					primoUtente.setColor("red");
					primoUtente.setExAequoRisolto("F");
					secondoUtente.setExAequoRisolto("F");
					secondoUtente.setColor("red");
					if((primoUtente.getRettifica()!=null && primoUtente.getRettifica().equalsIgnoreCase("true")) || (secondoUtente.getRettifica()!=null && secondoUtente.getRettifica().equalsIgnoreCase("true"))){
						for(Graduatoria g :graduatoriaListExAequoRisolti){
							if(primoUtente.getRettifica().equalsIgnoreCase("true")){
								if(primoUtente.getPunteggio().compareTo(g.getPunteggio())==0 && primoUtente.getEtaMedia().compareTo(g.getEtaMedia())==0){
									g.setExAequoRisolto("F");
									primoUtente.setRettifica("false");
								}
								
							}else if(secondoUtente.getPunteggio().compareTo(g.getPunteggio())==0 && secondoUtente.getEtaMedia().compareTo(g.getEtaMedia())==0){
									g.setExAequoRisolto("F");
									secondoUtente.setRettifica("false");
								}
							}
						}
						
						
					}
					
				} 
		}


			}

		}
	}*/

	for (int i = 0; i < listaGraduatoria.size() - 1; i++) {
			posizione++;
			Graduatoria primoUtente = listaGraduatoria.get(i);
			Graduatoria secondoUtente = listaGraduatoria.get(i+1);
			//primoUtente.setPosizione(posizione);
			//secondoUtente.setPosizione(posizione+1);
			//primoUtente.setIndiceTotale(new BigDecimal(posizione));
			//secondoUtente.setIndiceTotale(new BigDecimal(posizione+1));
		if(!((primoUtente.getColor()!=null && primoUtente.getColor().equalsIgnoreCase("blue")))){
			if (primoUtente.getPunteggio().compareTo(secondoUtente.getPunteggio()) == 0) {
				if(primoUtente.getExAequoRisolto()!=null && primoUtente.getExAequoRisolto().equalsIgnoreCase("F")){
					secondoUtente.setExAequo("T");
					secondoUtente.setExAequoRisolto("T");
					secondoUtente.setColor("green");
					secondoUtente.setIndiceTotale(new BigDecimal(posizione+1));
				}else if(!(secondoUtente.getColor()!=null && secondoUtente.getColor().equalsIgnoreCase("blue"))){
					primoUtente.setExAequo("T");
					primoUtente.setColor("green");
					primoUtente.setExAequoRisolto("T");
					secondoUtente.setExAequo("T");
					secondoUtente.setExAequoRisolto("T");
					secondoUtente.setColor("green");
				
					primoUtente.setIndiceTotale(new BigDecimal(posizione));
					secondoUtente.setIndiceTotale(new BigDecimal(posizione+1));
					j = posizione;
				}else{
					primoUtente.setExAequo("T");
					primoUtente.setColor("green");
					primoUtente.setExAequoRisolto("T");
					primoUtente.setIndiceTotale(new BigDecimal(posizione));
				}
				
				
				
				if (primoUtente.getEtaMedia().compareTo(secondoUtente.getEtaMedia()) == 0) {
					primoUtente.setColor("red");
					primoUtente.setExAequo("T");
					primoUtente.setExAequoRisolto("F");
					secondoUtente.setExAequoRisolto("F");
					secondoUtente.setExAequo("T");
					secondoUtente.setColor("red");
					
					primoUtente.setIndiceTotale(new BigDecimal(j));
					secondoUtente.setIndiceTotale(new BigDecimal(j));
		/*			if((primoUtente.getRettifica()!=null && primoUtente.getRettifica().equalsIgnoreCase("true")) || (secondoUtente.getRettifica()!=null && secondoUtente.getRettifica().equalsIgnoreCase("true"))){
						for(Graduatoria g :graduatoriaListExAequoRisolti){
							if(primoUtente.getRettifica().equalsIgnoreCase("true")){
								if(primoUtente.getPunteggio().compareTo(g.getPunteggio())==0 && primoUtente.getEtaMedia().compareTo(g.getEtaMedia())==0){
									g.setExAequoRisolto("F");
									primoUtente.setRettifica("false");
								}
								
							}else if(secondoUtente.getPunteggio().compareTo(g.getPunteggio())==0 && secondoUtente.getEtaMedia().compareTo(g.getEtaMedia())==0){
									g.setExAequoRisolto("F");
									secondoUtente.setRettifica("false");
								}
							}
						}*/
						
						
					}
				
			}else{
					
				if(primoUtente.getColor()!=null && primoUtente.getColor().equalsIgnoreCase("red")){
						//secondoUtente.setPosizione(posizione+1);
						secondoUtente.setIndiceTotale(new BigDecimal(posizione+1));
						j = posizione+1;
					}else{
						
						primoUtente.setIndiceTotale(new BigDecimal(posizione));
						secondoUtente.setIndiceTotale(new BigDecimal(posizione+1));
						//primoUtente.setPosizione(posizione);
						//secondoUtente.setPosizione(posizione+1);
						j = posizione+1;
					}
					
				}
			
		}else if(secondoUtente.getColor()!=null&&secondoUtente.getColor().equalsIgnoreCase("blue")){
			primoUtente.setIndiceTotale(new BigDecimal(posizione));
			secondoUtente.setIndiceTotale(new BigDecimal(posizione+1));
			//primoUtente.setPosizione(posizione);
			//secondoUtente.setPosizione(posizione+1);
			j = posizione;
		}
		
	}
	
}

}
		
		


			
