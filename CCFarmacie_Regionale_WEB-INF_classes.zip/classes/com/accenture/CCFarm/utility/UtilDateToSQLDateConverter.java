package com.accenture.CCFarm.utility;

import org.apache.commons.beanutils.Converter;

public class UtilDateToSQLDateConverter implements Converter
{
	public Object convert(Class type,Object value)
	{
		if (value != null && (value instanceof java.util.Date) && (type == java.sql.Date.class)) 
		{
			java.util.Date data = (java.util.Date)  value;
	    	java.sql.Date dataSql = new  java.sql.Date(data.getTime());
	    	return (dataSql);
	    }
		return value;
	}
}
