package com.accenture.CCFarm.utility;

import org.apache.commons.beanutils.ConvertUtils;

public class Convertitore {

	
	public static void  registraConvertitori (){
		
		//inizializza convertitori di tipo
		SQLDateToUtilDateConverter sqlDateToUtilDateConverter=new SQLDateToUtilDateConverter();
		UtilDateToSQLDateConverter utilDateToSqlDateConverter=new UtilDateToSQLDateConverter();
		//campi Check
		BooleanToStringCheckConverter booleanToStringCheckConverter = new BooleanToStringCheckConverter();
		StringToBooleanCheckConverter stringToBooleanCheckConverter = new StringToBooleanCheckConverter();
		
		ConvertUtils.register(sqlDateToUtilDateConverter,java.util.Date.class);
		ConvertUtils.register(utilDateToSqlDateConverter,java.sql.Date.class);
		
		ConvertUtils.register(booleanToStringCheckConverter, String.class);
		ConvertUtils.register(stringToBooleanCheckConverter, Boolean.class);
	}
	
}
