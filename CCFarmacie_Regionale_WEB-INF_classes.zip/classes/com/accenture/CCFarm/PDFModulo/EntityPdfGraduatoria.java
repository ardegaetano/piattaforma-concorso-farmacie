package com.accenture.CCFarm.PDFModulo;

public class EntityPdfGraduatoria {
	
	private String posizione;
	
	private String nome;
	
	private String cognome;
	
	private String punteggio;
	private String etaMedia;
	
	private String numeroProtocollo;
	
	private String color;
	private String exAequo;

	public String getPosizione() {
		return posizione;
	}

	public void setPosizione(String posizione) {
		this.posizione = posizione;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getPunteggio() {
		return punteggio;
	}

	public void setPunteggio(String punteggio) {
		this.punteggio = punteggio;
	}

	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}

	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getEtaMedia() {
		return etaMedia;
	}

	public void setEtaMedia(String etaMedia) {
		this.etaMedia = etaMedia;
	}

	public String getExAequo() {
		return exAequo;
	}

	public void setExAequo(String exAequo) {
		this.exAequo = exAequo;
	}
	
	
	

}
