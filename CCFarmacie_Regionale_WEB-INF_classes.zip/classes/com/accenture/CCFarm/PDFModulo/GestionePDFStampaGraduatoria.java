package com.accenture.CCFarm.PDFModulo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class GestionePDFStampaGraduatoria {	

	final static Font fonts12_bold = new Font(FontFamily.HELVETICA, 12, Font.BOLD);
	final static Font fonts10_normal = new Font(FontFamily.HELVETICA, 10, Font.NORMAL);
	final static Font fonts10_bold = new Font(FontFamily.HELVETICA, 10, Font.BOLD);
	final static Font fonts6_italic = new Font(FontFamily.HELVETICA, 6, Font.BOLD + Font.ITALIC);
	final static Font fonts6_normal = new Font(FontFamily.HELVETICA, 6, Font.NORMAL);
	final static Font fonts8_normal = new Font(FontFamily.HELVETICA, 8, Font.NORMAL);
	final static Font fonts8_bold = new Font(FontFamily.HELVETICA, 8, Font.BOLD);
	
	private  String dateInvio = "";
	private byte[] graduatoriaPDF;
	private String idRegioneIntestazione;
	private static final int IMG_WIDTH = 100;
	private static final int IMG_HEIGHT = 100;
	private static final int LIMITE_SALTO_PAGINA = 120;
	private static final int POS_RIGA_SALTO_PAGINA = 25;
	private static final int LIMITE_LISTA=40;
	public  int nriga_posizione = 840;
	private  Properties bodyRicevuta = new Properties();
	private  EntityPdfGraduatoria entityPDFGraduatoria = new EntityPdfGraduatoria();
	public  List<EntityPdfGraduatoria> listaEntityPDFGraduatoria = new ArrayList<EntityPdfGraduatoria>();
	public  int totale_pagine = 0;
	public  boolean contaLepagine = true;
	public  int totale_pagine_stampate = 0;
	public  boolean seOggetto = true;
	public  boolean seLabelColumn = true;
	private  Document documentoPDF = new Document();
	private  Regione regione = new Regione();
	private  RegioneHome regioneDAO = new RegioneHome();
	private  UtenteCandidaturaReg uteCandi = new UtenteCandidaturaReg();
	private  CandidaturaHome candidaturaHome = new CandidaturaHome();
	
	public byte[] getGraduatoriaPDF() {
		return graduatoriaPDF;
	}

	public  void setGraduatoriaPDF(byte[] graduatoriaPDF) {
		this.graduatoriaPDF = graduatoriaPDF;
	}

	
	public EntityPdfGraduatoria getEntityPDFGraduatoria() {
		return entityPDFGraduatoria;
	}

	public void setEntityPDFGraduatoria(EntityPdfGraduatoria entityPDFGraduatoria) {
		this.entityPDFGraduatoria = entityPDFGraduatoria;
	}

	public List<EntityPdfGraduatoria> getListaEntityPDFGraduatoria() {
		return listaEntityPDFGraduatoria;
	}

	public void setListaEntityPDFGraduatoria(
			List<EntityPdfGraduatoria> listaEntityPDFGraduatoria) {
		this.listaEntityPDFGraduatoria = listaEntityPDFGraduatoria;
	}

	public String getDateInvio() {
		return dateInvio;
	}

	public void setDateInvio(String dateInvio) {
		this.dateInvio = dateInvio;
	}

	public int getNriga_posizione() {
		return nriga_posizione;
	}

	public void setNriga_posizione(int nriga_posizione) {
		this.nriga_posizione = nriga_posizione;
	}

	public int getTotale_pagine() {
		return totale_pagine;
	}

	public void setTotale_pagine(int totale_pagine) {
		this.totale_pagine = totale_pagine;
	}

	public boolean isContaLepagine() {
		return contaLepagine;
	}

	public void setContaLepagine(boolean contaLepagine) {
		this.contaLepagine = contaLepagine;
	}

	public int getTotale_pagine_stampate() {
		return totale_pagine_stampate;
	}

	public void setTotale_pagine_stampate(int totale_pagine_stampate) {
		this.totale_pagine_stampate = totale_pagine_stampate;
	}

	public boolean isSeOggetto() {
		return seOggetto;
	}

	public void setSeOggetto(boolean seOggetto) {
		this.seOggetto = seOggetto;
	}

	public Document getDocumentoPDF() {
		return documentoPDF;
	}

	public void setDocumentoPDF(Document documentoPDF) {
		this.documentoPDF = documentoPDF;
	}

	public Regione getRegione() {
		return regione;
	}

	public void setRegione(Regione regione) {
		this.regione = regione;
	}

	public RegioneHome getRegioneDAO() {
		return regioneDAO;
	}

	public void setRegioneDAO(RegioneHome regioneDAO) {
		this.regioneDAO = regioneDAO;
	}

	public UtenteCandidaturaReg getUteCandi() {
		return uteCandi;
	}

	public void setUteCandi(UtenteCandidaturaReg uteCandi) {
		this.uteCandi = uteCandi;
	}

	public CandidaturaHome getCandidaturaHome() {
		return candidaturaHome;
	}

	public void setCandidaturaHome(CandidaturaHome candidaturaHome) {
		this.candidaturaHome = candidaturaHome;
	}

	public static Font getFonts12Bold() {
		return fonts12_bold;
	}

	public static Font getFonts10Normal() {
		return fonts10_normal;
	}

	public static Font getFonts10Bold() {
		return fonts10_bold;
	}

	public static Font getFonts6Italic() {
		return fonts6_italic;
	}

	public static Font getFonts6Normal() {
		return fonts6_normal;
	}

	public static Font getFonts8Normal() {
		return fonts8_normal;
	}

	public static Font getFonts8Bold() {
		return fonts8_bold;
	}

	public static int getImgWidth() {
		return IMG_WIDTH;
	}

	public static int getImgHeight() {
		return IMG_HEIGHT;
	}

	public static int getLimiteSaltoPagina() {
		return LIMITE_SALTO_PAGINA;
	}

	public static int getPosRigaSaltoPagina() {
		return POS_RIGA_SALTO_PAGINA;
	}

	public String getIdRegioneIntestazione() {
		return idRegioneIntestazione;
	}

	public void setIdRegioneIntestazione(String idRegioneIntestazione) {
		this.idRegioneIntestazione = idRegioneIntestazione;
	}

	public GestionePDFStampaGraduatoria()  // Costruttore 
	{
	}
	
	/**
	 * @param args
	 */
	
     
    public  PdfPTable createBoxOggettoText(String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	
    try {
       PdfPCell cell = new PdfPCell();
       Paragraph w_testo = new Paragraph(testo,fonts12_bold);
       PdfContentByte canvas = pdfWrite.getDirectContent();
       w_testo.setAlignment(Element.ALIGN_CENTER);
       cell.addElement(w_testo); 
       table.addCell(cell);
       table.setTotalWidth(550);
       table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
		} catch (Exception e) {
			e.printStackTrace();
		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 20);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}      
    	
        return table;
    } 
    public boolean ristampaRicevutaIdUtentePDF(String id_utente)
   	{	
   		boolean result = false;
		try
		{
			CandidaturaHome candidaturaDAO = new CandidaturaHome();
			UtenteCandidaturaReg utenteCandidatura = null;
			utenteCandidatura = candidaturaDAO.findByUserId(id_utente);
			RicevuteHome ricevuteDAO = new RicevuteHome();
			Ricevute ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
			if (ricevuta!=null)
			{
				setGraduatoriaPDF(ricevuta.getContenutoFile());
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 		
   		return result;
   		
   	}  
    
    public boolean caricaDatiDaGraduatoriaEntityPDF(String id_regione)
   	{	
    	
    	boolean result = false;
		try
		{   
			setIdRegioneIntestazione(id_regione);
			Graduatoria graduatoria = new Graduatoria();
			graduatoria.setCodRegione(id_regione);
			List<Graduatoria> listaGrad = new ArrayList<Graduatoria>();
			GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
			int maxElement = graduatoriaHome.searchCount(id_regione);
			listaGrad = graduatoriaHome.findLazyListGradJoinGradDefin(id_regione, 0, maxElement+1);
			for (Graduatoria w_graduatoria : listaGrad)
			{
				initEntityPDFromEntity(w_graduatoria);
				getListaEntityPDFGraduatoria().add(getEntityPDFGraduatoria());
			}
			
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 		
   		return result;
   		
   	}     

	public static String formattaDataTOString(Date w_date, String formatOra)
	{
		Calendar cal = Calendar.getInstance();
		String result = "";
		if (w_date!=null)
		{
			try { 
				cal.setTime(w_date);
				// Set time fields to zero  
				cal.set(Calendar.HOUR_OF_DAY, 0);  
				cal.set(Calendar.MINUTE, 0);  
				cal.set(Calendar.SECOND, 0);  
				cal.set(Calendar.MILLISECOND, 0);	
				SimpleDateFormat formatterOut = null;
				if (formatOra!=null)
				{	
					formatterOut = new SimpleDateFormat("dd-MM-yyyy" + " " + formatOra);
				}
				else
				{	
					formatterOut = new SimpleDateFormat("dd-MM-yyyy");
				}
					
					  
				result = formatterOut.format(cal.getTime()); 
			}
			catch (Exception e)
			{}			

		}
		return result;

	}
    
    public  void initEntityPDFromEntity(Graduatoria  graduatoria)
    {
    	try
    	 {
    		/* inizializzazione strutture di prelievo dati */
	    	entityPDFGraduatoria = new EntityPdfGraduatoria();
	    	int posizione = 0;
	    	if (graduatoria.getIndiceTotale()!=null){
	    		posizione= graduatoria.getIndiceTotale().intValue();
	    	}
	    	entityPDFGraduatoria.setPosizione(""+posizione);
	    	entityPDFGraduatoria.setCognome(graduatoria.getCognome());
	    	entityPDFGraduatoria.setNome(graduatoria.getNome());
	    	entityPDFGraduatoria.setNumeroProtocollo(graduatoria.getNumeroProtocollo());
	    	String punteggio = ""+graduatoria.getPunteggio();
	    	entityPDFGraduatoria.setPunteggio(punteggio.replace(".", ","));
	    	String etaMedia = ""+graduatoria.getEtaMedia();
	    	entityPDFGraduatoria.setEtaMedia(etaMedia.replace(".", ","));
	    	entityPDFGraduatoria.setColor(graduatoria.getColor());
	    	entityPDFGraduatoria.setExAequo(graduatoria.getExAequo());
	    	
    	 }
		catch (Exception e)
		{
			e.printStackTrace();
		} 		    	
	}
    
    public  PdfPTable createBoxSecondaLaureaTextF(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();        
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setPaddingLeft(-50);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            	
            }
            if (idx==3)
            {
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }
            if (idx==4)
            {
                cell7.setPaddingLeft(-50);
                cell7.setBorder(Rectangle.NO_BORDER);            	
            	cell7.addElement(w_testo);
            	
            }
            if (idx==5)
            {
                cell8.setBorder(Rectangle.NO_BORDER);            	
            	cell8.addElement(w_testo);
            	
            }          
        }
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);
        table2.addCell(cell6);
        table2.addCell(cell7);
        table2.addCell(cell8);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPagina(table, pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}  
         return table;
    }     
    
      
    public  PdfPTable createBoxVuotoText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
        try {
            PdfPCell cell = new PdfPCell();
            Paragraph w_testo = new Paragraph(testo,fonts8_normal);
            PdfContentByte canvas = pdfWrite.getDirectContent();
            w_testo.setAlignment(Element.ALIGN_RIGHT);
            cell.addElement(w_testo);             
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);
            table.setTotalWidth(700);
            table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
     		} catch (Exception e) {
     			// TODO Auto-generated catch block
     			e.printStackTrace();
     		}
             return table;
    }    
    public  PdfPTable createBoxPaginazioneText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
        try {
            PdfPCell cell = new PdfPCell();
            Paragraph w_testo = new Paragraph(testo,fonts6_normal);
            PdfContentByte canvas = pdfWrite.getDirectContent();
            w_testo.setAlignment(Element.ALIGN_RIGHT);
            cell.addElement(w_testo);             
            cell.setBorder(Rectangle.NO_BORDER);
            
            table.addCell(cell);
            table.setTotalWidth(550);
            table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
     		} catch (Exception e) {
     			// TODO Auto-generated catch block
     			e.printStackTrace();
     		}
             return table;
    }
    
    public  PdfPTable createBoxPieDiPagina(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
        try {
            PdfPCell cell = new PdfPCell();
            Paragraph w_testo = new Paragraph(testo,fonts8_bold);
            PdfContentByte canvas = pdfWrite.getDirectContent();
            w_testo.setAlignment(Element.ALIGN_LEFT);
            cell.addElement(w_testo);             
            cell.setBorder(Rectangle.NO_BORDER);
            
            table.addCell(cell);
            table.setTotalWidth(550);
            table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
     		} catch (Exception e) {
     			// TODO Auto-generated catch block
     			e.printStackTrace();
     		}
             return table;
    }
   
    public  PdfPTable createBoxElencoCandidati(List<EntityPdfGraduatoria> entity,PdfWriter pdfWrite ) {
    
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(5);
    	int[] widths = {5, 35, 40, 20, 30};
//    	int[] widths = {15, 25, 25, 15, 30};
//veri 	int[] widths = {15, 25, 30, 15, 15};
//colo 	int[] widths = {15, 25, 30, 15, 17};

    try {
        PdfPCell cell = new PdfPCell();
        PdfContentByte canvas = pdfWrite.getDirectContent();
       
        PdfPCell cell2 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT + Rectangle.TOP);
        Paragraph w_testo = null;

        
        
        
        for (EntityPdfGraduatoria idx_entity : entity)
        {
//        	for di entity nome cogno cf data
        	
        	PdfPCell cell3 = new PdfPCell();
            PdfPCell cell4 = new PdfPCell();
            PdfPCell cell5 = new PdfPCell();
            PdfPCell cell6 = new PdfPCell();
            PdfPCell cell7 = new PdfPCell();
          
//Gestrione dei colori delle riche            
//            BaseColor backgroundColor = null;
//            boolean cellColor = false;
//            if (idx_entity.getColor()!=null&&!idx_entity.getColor().equals("")){
//            	if (idx_entity.getColor().equalsIgnoreCase("green")){
//            		backgroundColor =new BaseColor(143, 211, 166);
//            		cellColor = true;
//            	}
//            	if (idx_entity.getColor().equalsIgnoreCase("red")){
//            		backgroundColor =new BaseColor( 249, 19, 7);
//            		cellColor = true;
//            	}
//            	if (idx_entity.getColor().equalsIgnoreCase("blue")){
//            		backgroundColor =new BaseColor( 153, 203, 255);
//            		cellColor = true;
//            	}
//            }
            String posizione = "";
            int lunghezzaString = idx_entity.getPosizione().trim().length();
            
            if (idx_entity.getExAequo()!=null&&idx_entity.getExAequo().equalsIgnoreCase("T")){
            	posizione= "*";
            }
            
            while (true) {
				if (posizione.length()+lunghezzaString==6){
					posizione =posizione+idx_entity.getPosizione().trim();
					break;					
				} else{
					posizione = posizione+" ";
				}
				

			}
            
//            w_testo = new Paragraph(idx_entity.getPosizione(),fonts8_normal);
            w_testo = new Paragraph(posizione,fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_CENTER);  
            cell3.setPaddingLeft(-50);
//            if (cellColor) cell3.setBackgroundColor(backgroundColor);
            cell3.setBorder(Rectangle.NO_BORDER);            	
        	cell3.addElement(w_testo);

          	w_testo = new Paragraph(idx_entity.getNumeroProtocollo(),fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            cell4.setBorder(Rectangle.NO_BORDER);            	
        	cell4.addElement(w_testo);

          	w_testo = new Paragraph(idx_entity.getCognome()+" "+idx_entity.getNome(),fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            cell5.setBorder(Rectangle.NO_BORDER); 
            cell5.setNoWrap(false);
        	cell5.addElement(w_testo);

//        	w_testo = new Paragraph(formattaDataTOString(idx_entity.getDataNasc(), ""),fonts8_normal);
        	w_testo = new Paragraph(idx_entity.getPunteggio(),fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            cell6.setBorder(Rectangle.NO_BORDER);            	
        	cell6.addElement(w_testo);

        	w_testo = new Paragraph(idx_entity.getEtaMedia(),fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            cell7.setBorder(Rectangle.NO_BORDER);            	
        	cell7.addElement(w_testo);
        	
        	table2.addCell(cell3);
            table2.addCell(cell4);
            table2.addCell(cell5);
            table2.addCell(cell6);
            table2.addCell(cell7);
            table2.setWidths(widths);



           
        }

        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        if (nriga_posizione != 0)
    	{	
    		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
    	}
    	else
    	{	
    		nriga_posizione = 790;
    	}         
        //saltoPagina(table,pdfWrite);
 		} catch (Exception e) {
 	
 			e.printStackTrace();
 		}
         return table;
    } 
    
    
   
    
       
    public  PdfPTable saltoPaginaForzata(PdfPTable table,PdfWriter pdfWrite,PdfContentByte canvas,PdfPCell cell2)
    {
    	if (
    				(LIMITE_SALTO_PAGINA >= (nriga_posizione - (int)table.getTotalHeight())) ||
    				((LIMITE_SALTO_PAGINA + 20) >= (nriga_posizione - (int)table.getTotalHeight()))
    			)	
    		{
    			table.setTotalWidth(550);
    			table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);
				documentoPDF.newPage();
				pdfWrite.setPageEmpty(false);
				nriga_posizione = 840;
//				w_testo = getBodyRicevuta().getProperty("headerpagina");
//				w_testo = setTextParamatriHeader(w_testo);
				w_testo="";
				nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
				table = null;	
    		}
    		return table;

    }
    
    
    
    public  void saltoPaginaUltimo(PdfPTable table,PdfWriter pdfWrite)
    {
    			nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);

    }    
    
    
    public  void saltoPagina(PdfPTable table,PdfWriter pdfWrite)
    {
    		if (LIMITE_SALTO_PAGINA >= (nriga_posizione - (int)table.getTotalHeight()))
    		{
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);
				documentoPDF.newPage();
				pdfWrite.setPageEmpty(false);
				nriga_posizione = 840;
//				w_testo = getBodyRicevuta().getProperty("headerpagina");
				w_testo = "";
				nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
				nriga_posizione = 0;
    		}

    }
    
    
    public  void saltoPaginaPdf(PdfWriter pdfWrite)
    {
    		if (LIMITE_SALTO_PAGINA >= nriga_posizione)
    		{
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);
				documentoPDF.newPage();
				pdfWrite.setPageEmpty(false);
				nriga_posizione = 840;
//				w_testo = getBodyRicevuta().getProperty("headerpagina");
				w_testo = "";
			//	nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
				nriga_posizione = 780;
				seLabelColumn = true;
    		}

    }
    
       
    
    public  PdfPTable createBoxHeaderText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.NO_BORDER);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        cell2.setBorder(Rectangle.NO_BORDER);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts6_italic);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            }  
            if (idx==3)
            {
                cell6.setPaddingLeft(-50);
                cell6.setColspan(2);
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }            
        }
    	table2.addCell(cell3);
    	table2.addCell(cell4);
    	table2.addCell(cell5);
    	table2.addCell(cell6);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
         return table;
    }  
    
    public  PdfPTable createBoxLabelColumn(String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(5);
    	int[] widths = {5, 35, 40, 20, 30};
    	int[] widths_de = {5, 28, 39, 25, 40};
    	
    try {
        PdfPCell cell = new PdfPCell();
        PdfContentByte canvas = pdfWrite.getDirectContent();
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        Paragraph w_testo = null;
        
        String header_Posizione = "POSIZIONE";
        if (idRegioneIntestazione.equals("041"))
        	header_Posizione = header_Posizione + "\nPOSITION";
        w_testo = new Paragraph(header_Posizione,fonts10_bold);
	    w_testo.setAlignment(Element.ALIGN_LEFT);  

        cell3.setPaddingLeft(-50);
        cell3.setBorder(Rectangle.NO_BORDER);            	
        cell3.addElement(w_testo);

        String header_Protocollo = "PROTOCOLLO";
        if (idRegioneIntestazione.equals("041"))
        	header_Protocollo = header_Protocollo + "\nPROTOKOLLNR.";
        w_testo = new Paragraph(header_Protocollo,fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  

        cell4.setBorder(Rectangle.NO_BORDER);            	
        cell4.addElement(w_testo);

        String header_Nome = "NOMINATIVO";
        if (idRegioneIntestazione.equals("041"))
        	header_Nome = header_Nome + "\nNAME";
        w_testo = new Paragraph(header_Nome,fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  
            	

        cell5.setBorder(Rectangle.NO_BORDER);            	
        cell5.addElement(w_testo);

        String header_Punteggio = "PUNTEGGIO";
        if (idRegioneIntestazione.equals("041"))
        	header_Punteggio = header_Punteggio + "\nPUNKTEZAHL";
        w_testo = new Paragraph(header_Punteggio,fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  
            	
         	
        cell6.setBorder(Rectangle.NO_BORDER);            	
        cell6.addElement(w_testo);

        String header_Eta = "ETA' MEDIA";
        if (idRegioneIntestazione.equals("041"))
        	header_Eta = header_Eta + "\nDURCHSCHNITTSALTER";
        w_testo = new Paragraph(header_Eta,fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  
            	
         	
        cell7.setBorder(Rectangle.NO_BORDER);            	
        cell7.addElement(w_testo);
            	
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);
        table2.addCell(cell6);
        table2.addCell(cell7);  
        
        if(idRegioneIntestazione.equals("041"))
        	table2.setWidths(widths_de);
    	else
    		table2.setWidths(widths);
        
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.completeRow();
        table.setTotalWidth(550);
        table.setLockedWidth(true);      
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);       
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		
    
         return table;
    }     
    
    public  Document creaRicevuta(PdfWriter pdfWrite)
    {
    	       // Carica Logo Ministero
			//BufferedImage img = ImageIO.read(new FileInputStream(currentDir.getAbsolutePath() + "//WebContent//images//layout//logo_ministero.png"));
			try {
				java.io.File currentDir = new java.io.File("");
				/*
				Image img = null;
				img = Image.getInstance(currentDir.getAbsolutePath() + "//WebContent//images//layout//logo_ministero.png");
				img.setAlignment(Image.LEFT | Image.TEXTWRAP);
				img.setBorder(Image.BOX);
				img.setBorderWidth(0);      
				documento.add(img);
				*/	
				String testo = "";
								
				if (seOggetto)
				{
					nriga_posizione = 800;
					String intestazione="";
					if (idRegioneIntestazione!=null){
						Regione regione = new Regione();
						regione.setCodReg(getIdRegioneIntestazione());
						RegioneHome home = new RegioneHome();
						regione= home.findById(getIdRegioneIntestazione());
						if (idRegioneIntestazione.equals("041") || idRegioneIntestazione.equals("042")){
							intestazione = regione.getDenominazioneReg();
						} else{
							intestazione = "Regione "+regione.getDenominazioneReg();
						}
							
					}
					testo = "Lista graduatoria per la "+intestazione+" \n";
					
					//Testo in Tedesco per Bolzano
					if (idRegioneIntestazione.equals("041")) {
						testo =  testo + "Rangliste f�r die Region "+intestazione+" \n";
					}
					
//					testo = "Lista candidature per la Regione \n";
					createBoxOggettoText(testo,pdfWrite); 	 					
				}
				else
				{
					nriga_posizione = POS_RIGA_SALTO_PAGINA; 
					String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
					createBoxPaginazioneText("",w_testo,pdfWrite);
					nriga_posizione = 840;
					//w_testo = getBodyRicevuta().getProperty("headerpagina");
					w_testo = "";
					nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
					nriga_posizione = 790;
				}
				nriga_posizione = 770;
				
				if (idRegioneIntestazione.equals("041"))
					nriga_posizione = 760;
					
				List<EntityPdfGraduatoria> listApp = new ArrayList<EntityPdfGraduatoria>(); 
				int conta=0;
				for (EntityPdfGraduatoria entityPdfGraduatoria: getListaEntityPDFGraduatoria()) {
					
					if (seLabelColumn)
					{
						createBoxLabelColumn("",pdfWrite); 	
						seLabelColumn = false;
					}     	
					conta++;
					listApp.add(entityPdfGraduatoria);
					if ((conta%LIMITE_LISTA)==0){
						saltoPaginaPdf(pdfWrite);
						if (seLabelColumn)
						{
							createBoxLabelColumn("",pdfWrite); 	
							seLabelColumn = false;
						}  						
						nriga_posizione = nriga_posizione - 10;
						createBoxElencoCandidati(listApp, pdfWrite);
						listApp.clear();
					}
				}
				if ((conta%LIMITE_LISTA)!=0)
				{
					saltoPaginaPdf(pdfWrite);
					if (seLabelColumn)
					{
						createBoxLabelColumn("",pdfWrite); 	
						seLabelColumn = false;
					} 					
					nriga_posizione = nriga_posizione - 10;
					createBoxElencoCandidati(listApp, pdfWrite);
					listApp.clear();
					
					String pieDiPagina = "Nota: l'asterisco a fianco dell'ordine di graduatoria contraddistingue gli ex-aequo";
					createBoxPieDiPagina("", pieDiPagina, pdfWrite);
					nriga_posizione = POS_RIGA_SALTO_PAGINA; 
					String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
					createBoxPaginazioneText("",w_testo,pdfWrite);
				}
				else{
					String pieDiPagina = "Nota: l'asterisco a fianco dell'ordine di graduatoria contraddistingue gli ex-aequo";
					createBoxPieDiPagina("", pieDiPagina, pdfWrite);
					nriga_posizione = POS_RIGA_SALTO_PAGINA; 
					String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
					createBoxPaginazioneText("",w_testo,pdfWrite);
				}
				
				
					/* --- NUOVA PAGINA 5 PDF --*/	
				
				if (totale_pagine == 0)
				{					
					totale_pagine = (int)pdfWrite.getPageNumber();
				}	
				if (contaLepagine)
				{	
					totale_pagine_stampate = totale_pagine_stampate + totale_pagine;
				}
				
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				return documentoPDF;	
			}
    }
    
    public  Properties getBodyRicevuta() {
		return bodyRicevuta;
	}
	public void setBodyRicevuta(Properties bodyRicevuta) {
		this.bodyRicevuta = bodyRicevuta;
	}
	public  Date formatStrToDate(String strData)
	{
		Date date = null;
		if ( (strData!=null) && (!strData.equals("")))
		{
			try
			{
			 DateFormat formatter ; 
			 formatter = new SimpleDateFormat("dd-MM-yyyy");
			 date = (Date)formatter.parse(strData);  
			} catch (ParseException e)
			  {e.printStackTrace();}
			
		}
		return date; 
	}
	
	public  void creaGraduatoriaPDF() throws Exception{ 
		
//		
		  try 
		  { 
			  documentoPDF = new Document();				  
//scrivi su file 
//		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
//scrivi su download
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	
		  	  documentoPDF.open();
		  
			  seOggetto = true;		 
			  creaRicevuta(pdfWrite);				   		
			  if (seOggetto)
			  {
				  seOggetto = false;
			  }
			  
			  totale_pagine_stampate = pdfWrite.getPageNumber();
			  documentoPDF.close();
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }
		  contaLepagine = false;
		  try 
		  { 
			 // File f = new File("c:\\output.pdf");
			 // f.delete();		  
			  documentoPDF = new Document();	
//scrivi su file 
//		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
//scrivi su download
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;	
			  seLabelColumn = true;
			  creaRicevuta(pdfWrite);				   		
			  if (seOggetto)
			  {
				  seOggetto = false;
			  }
			  if (seLabelColumn){
				  seLabelColumn = false;
			  }
			  documentoPDF.close();
			  if (getGraduatoriaPDF()==null)
			  {
				  graduatoriaPDF = docBufferPDF.toByteArray();
			  } 
			  
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }		  
	
    }
    
    
    public  void downloadFile()
    {
    	byte[] pdfData = getGraduatoriaPDF();
    	try
    	{
            FacesContext facesContext = FacesContext.getCurrentInstance(); 
            ExternalContext externalContext = facesContext.getExternalContext(); 
            HttpServletResponse response = (HttpServletResponse) externalContext.getResponse(); 
            ServletContext servletContext = (ServletContext) externalContext.getContext(); 
            response.reset(); 
            response.setContentType(servletContext.getMimeType("elencoCandidati.pdf")); 
            response.setContentLength((int) pdfData.length); 
            response.setHeader("Content-disposition", "attachment; filename=\"elencoCandidati.pdf\"");
            ByteArrayInputStream in = null;             
            BufferedInputStream input = null; 
            BufferedOutputStream output = null; 
            final int buffersize = (int) pdfData.length; 
            try 
            { 
            	in = new ByteArrayInputStream(pdfData);
            	input = new BufferedInputStream(in); 
            	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
            	byte[] buffer = new byte[buffersize]; 
            	for (int length; (length = input.read(buffer)) > 0;) 
            	{	 
            		output.write(buffer, 0, length); 
            	}            	
            } 
            finally 
            { 
            	if (input != null) 
            		try 
            		{ 
            			input.close(); 
            			output.close();
            		} 
            		catch (IOException e) 
            		{ 
            			e.printStackTrace(); 
            		} 
            } 
            facesContext.responseComplete();                             		
    	}
    	catch (IOException e)
    	{
    		e.printStackTrace();
    	}
    }
    
    
    public  void findUtenteCandidaDAO()
    {
    	uteCandi = new UtenteCandidaturaReg();
    	String IdUtente = "145";
    	try {
	    	candidaturaHome = new CandidaturaHome();
	    	uteCandi = candidaturaHome.findByUserId(IdUtente);
    	}
    	catch (Exception e) {
			e.printStackTrace();
		} 
    	System.out.println("ciccio");
    }
}
