package com.accenture.CCFarm.PDFModulo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;

import com.accenture.CCFarm.Bean.Ruolo;
import com.accenture.CCFarm.Bean.UtenteEspProf;
import com.accenture.CCFarm.Bean.UtenteTitoli;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.RicevuteId;
import com.accenture.CCFarm.DAO.Titoli;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.captcha.CaptchaGenerator;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.SchedaValutazioneBean;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CCFarmLogger;
import com.accenture.CCFarm.utility.CaricaRuoli;
import com.accenture.CCFarm.utility.RecuperaProtocollo;
import com.accenture.punteggi.esperienze.RisultatiValutazioneEsperienze;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class GestionePDFRiepilogoValutazione {	

	final static Font fonts12_bold = new Font(FontFamily.HELVETICA, 12, Font.BOLD);
	final static Font fonts10_normal = new Font(FontFamily.HELVETICA, 10, Font.NORMAL);
	final static Font fonts10_bold = new Font(FontFamily.HELVETICA, 10, Font.BOLD);
	final static Font fonts6_italic = new Font(FontFamily.HELVETICA, 6, Font.BOLD + Font.ITALIC);
	final static Font fonts6_normal = new Font(FontFamily.HELVETICA, 6, Font.NORMAL);
	final static Font fonts8_normal = new Font(FontFamily.HELVETICA, 8, Font.NORMAL);
	final static Font fonts8_bold = new Font(FontFamily.HELVETICA, 8, Font.BOLD);
	
	private  String dateInvio = "";
	private byte[] imgStampaElencoPDF;
	private byte[] imgRicevutaPDF;
	private String idRegioneIntestazione;
	private static final int IMG_WIDTH = 100;
	private static final int IMG_HEIGHT = 100;
	private static final int LIMITE_SALTO_PAGINA = 120;
	private static final int POS_RIGA_SALTO_PAGINA = 25;
	private static final int LIMITE_LISTA=40;
	private static final int LIMITE_LISTA_NOTE_FROM_PAGE=30;
	public  int nriga_posizione = 840;
	private  Properties bodyRicevuta = new Properties();
	private  EntityPDFRiepilogoValutazione entityPDFRiepilogoValutazione = new EntityPDFRiepilogoValutazione();
	private  String id_ricevuta_inserito = "";
	private  RicevuteId ricevuteId = new RicevuteId();
	public  int totale_pagine = 0;
	public  boolean contaLepagine = true;
	public  int totale_pagine_stampate = 0;
	public  boolean seOggetto = true;
	public  boolean seLabelColumn = true;
	private  Document documentoPDF = new Document();
	private  Regione regione = new Regione();
	private  RegioneHome regioneDAO = new RegioneHome();
	private  UtenteCandidaturaReg uteCandi = new UtenteCandidaturaReg();
	private  CandidaturaHome candidaturaHome = new CandidaturaHome();
	private  Ricevute ricevute = new Ricevute();
	
	private int countForPage = 0; 
	private int ultimoUtente = 0;
	private int utenteCorrente=0;
	private int conta=0;
	
	
	public byte[] getImgStampaElencoPDF() {
		return imgStampaElencoPDF;
	}

	public  void setImgStampaElencoPDF(byte[] imgStampaElencoPDF) {
		this.imgStampaElencoPDF = imgStampaElencoPDF;
	}

	public EntityPDFRiepilogoValutazione getEntityPDFRiepilogoValutazione() {
		return entityPDFRiepilogoValutazione;
	}

	public void setEntityPDFRiepilogoValutazione(
			EntityPDFRiepilogoValutazione entityPDFRiepilogoValutazione) {
		this.entityPDFRiepilogoValutazione = entityPDFRiepilogoValutazione;
	}

	public String getDateInvio() {
		return dateInvio;
	}

	public void setDateInvio(String dateInvio) {
		this.dateInvio = dateInvio;
	}

	public int getNriga_posizione() {
		return nriga_posizione;
	}

	public void setNriga_posizione(int nriga_posizione) {
		this.nriga_posizione = nriga_posizione;
	}

	public int getTotale_pagine() {
		return totale_pagine;
	}

	public void setTotale_pagine(int totale_pagine) {
		this.totale_pagine = totale_pagine;
	}

	public boolean isContaLepagine() {
		return contaLepagine;
	}

	public void setContaLepagine(boolean contaLepagine) {
		this.contaLepagine = contaLepagine;
	}

	public int getTotale_pagine_stampate() {
		return totale_pagine_stampate;
	}

	public void setTotale_pagine_stampate(int totale_pagine_stampate) {
		this.totale_pagine_stampate = totale_pagine_stampate;
	}

	public boolean isSeOggetto() {
		return seOggetto;
	}

	public void setSeOggetto(boolean seOggetto) {
		this.seOggetto = seOggetto;
	}

	public Document getDocumentoPDF() {
		return documentoPDF;
	}

	public void setDocumentoPDF(Document documentoPDF) {
		this.documentoPDF = documentoPDF;
	}

	public Regione getRegione() {
		return regione;
	}

	public void setRegione(Regione regione) {
		this.regione = regione;
	}

	public RegioneHome getRegioneDAO() {
		return regioneDAO;
	}

	public void setRegioneDAO(RegioneHome regioneDAO) {
		this.regioneDAO = regioneDAO;
	}

	public UtenteCandidaturaReg getUteCandi() {
		return uteCandi;
	}

	public void setUteCandi(UtenteCandidaturaReg uteCandi) {
		this.uteCandi = uteCandi;
	}

	public CandidaturaHome getCandidaturaHome() {
		return candidaturaHome;
	}

	public void setCandidaturaHome(CandidaturaHome candidaturaHome) {
		this.candidaturaHome = candidaturaHome;
	}

	public static Font getFonts12Bold() {
		return fonts12_bold;
	}

	public static Font getFonts10Normal() {
		return fonts10_normal;
	}

	public static Font getFonts10Bold() {
		return fonts10_bold;
	}

	public static Font getFonts6Italic() {
		return fonts6_italic;
	}

	public static Font getFonts6Normal() {
		return fonts6_normal;
	}

	public static Font getFonts8Normal() {
		return fonts8_normal;
	}

	public static Font getFonts8Bold() {
		return fonts8_bold;
	}

	public static int getImgWidth() {
		return IMG_WIDTH;
	}

	public static int getImgHeight() {
		return IMG_HEIGHT;
	}

	public static int getLimiteSaltoPagina() {
		return LIMITE_SALTO_PAGINA;
	}

	public static int getPosRigaSaltoPagina() {
		return POS_RIGA_SALTO_PAGINA;
	}

	public String getIdRegioneIntestazione() {
		return idRegioneIntestazione;
	}

	public void setIdRegioneIntestazione(String idRegioneIntestazione) {
		this.idRegioneIntestazione = idRegioneIntestazione;
	}
	
	

	public byte[] getImgRicevutaPDF() {
		return imgRicevutaPDF;
	}

	public void setImgRicevutaPDF(byte[] imgRicevutaPDF) {
		this.imgRicevutaPDF = imgRicevutaPDF;
	}
	
	

	public Ricevute getRicevute() {
		return ricevute;
	}

	public void setRicevute(Ricevute ricevute) {
		this.ricevute = ricevute;
	}
	
	

	public String getId_ricevuta_inserito() {
		return id_ricevuta_inserito;
	}

	public void setId_ricevuta_inserito(String id_ricevuta_inserito) {
		this.id_ricevuta_inserito = id_ricevuta_inserito;
	}

	public RicevuteId getRicevuteId() {
		return ricevuteId;
	}

	public void setRicevuteId(RicevuteId ricevuteId) {
		this.ricevuteId = ricevuteId;
	}

	
	public int getCountForPage() {
		return countForPage;
	}

	public void setCountForPage(int countForPage) {
		this.countForPage = countForPage;
	}
	
	public GestionePDFRiepilogoValutazione()  // Costruttore 
	
	{
		try {		
				//URL url = CaptchaGenerator.class.getResource("/resources/ricevutapdf.properties");
				//String currentDir = "C://Documents and Settings//Administrator//workspace//CCFarmacie//src//resources//ricevutapdf.properties";			
				//.load(new FileInputStream(currentDir));
				//String nfile = url.getFile();
				//nfile = nfile.replaceAll("%20", " ");
			    InputStream is  = AppProperties.class.getClassLoader().getResourceAsStream("resources/ricevutapdf.properties");
				bodyRicevuta.load(is);
			} catch (IOException e) {
				CCFarmLogger.log("File Properties 'ricevutapdf' non trovato..", Level.ERROR_INT,
						CandidaturaHome.class);
			}
	}
	
	/**
	 * @param args
	 */
	
     
    public  PdfPTable createBoxOggettoText(String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	
    try {
       PdfPCell cell = new PdfPCell();
       Paragraph w_testo = new Paragraph(testo,fonts12_bold);
       PdfContentByte canvas = pdfWrite.getDirectContent();
       w_testo.setAlignment(Element.ALIGN_CENTER);
       cell.addElement(w_testo); 
       table.addCell(cell);
       table.setTotalWidth(550);
       table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 20);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}      
    	
        return table;
    } 
//    public boolean ristampaRicevutaIdUtentePDF(String id_utente)
//   	{	
//   		boolean result = false;
//		try
//		{
//			CandidaturaHome candidaturaDAO = new CandidaturaHome();
//			UtenteCandidatura utenteCandidatura = null;
//			utenteCandidatura = candidaturaDAO.findByUserId(id_utente);
//			RicevuteHome ricevuteDAO = new RicevuteHome();
//			Ricevute ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
//			if (ricevuta!=null)
//			{
//				setImgStampaElencoPDF(ricevuta.getContenutoFile());
//			}
//		}
//		catch (Exception e)
//		{
//			e.printStackTrace();
//		} 		
//   		return result;
//   		
    
    public boolean caricaDatiPerEntityPDF(SchedaValutazioneBean schedaValutazioneBean)
   	{	
    	
    	boolean result = false;
		String totale = "";
		String totaleTitoli = "";
		String totaleEsperienze = "";
    	
    	try
		{   
			entityPDFRiepilogoValutazione = new EntityPDFRiepilogoValutazione();
			
			// cerco l'utente e i suoi associati
			
			String numeroProtocollo = "";
			RecuperaProtocollo recuperaProtocollo = new RecuperaProtocollo();
			
			numeroProtocollo = recuperaProtocollo.getProtocolloRegionale(schedaValutazioneBean.getUtenteCandidaturaList().get(0).getCandidatura().getIdCandidatura());
			
			String referente = null;
			String flagReferente=null;
			for(UtenteCandidaturaReg utenteCandidatura : schedaValutazioneBean.getUtenteCandidaturaList())
			{
				flagReferente=utenteCandidatura.getCandidatura().getReferenteDomanda();
				if(flagReferente!=null && flagReferente.equalsIgnoreCase("Y"))
				{
					referente=utenteCandidatura.getNomeUtente().charAt(0)+". "+utenteCandidatura.getCognomeUtente();
				}
			}
			
			entityPDFRiepilogoValutazione.setReferente(referente); 
			entityPDFRiepilogoValutazione.setListaUtentiTitoli(schedaValutazioneBean.getUtenteTitoliList());
			entityPDFRiepilogoValutazione.setIntestazione(referente);
			entityPDFRiepilogoValutazione.setNumeroProtocollo(numeroProtocollo);
			entityPDFRiepilogoValutazione.setListaUtentiEsperienza(schedaValutazioneBean.getUtenteEspProfList());
			entityPDFRiepilogoValutazione.setPunteggioTotale ((schedaValutazioneBean.getTotaleScheda()==null)?"0":schedaValutazioneBean.getTotaleScheda());
			entityPDFRiepilogoValutazione.setPunteggioTotaleEsperienze((schedaValutazioneBean.getTotaleEspProf()==null)?"0":schedaValutazioneBean.getTotaleEspProf());
			entityPDFRiepilogoValutazione.setPunteggioTotaleTitoli((schedaValutazioneBean.getTotaleTitoli()==null)?"0":schedaValutazioneBean.getTotaleTitoli());
		    
			if (schedaValutazioneBean.getNote()==null || schedaValutazioneBean.getNote().equals("")){
		    	schedaValutazioneBean.setNote("Nessuna");
		    }
		    String note = schedaValutazioneBean.getNote()==null?"":schedaValutazioneBean.getNote();
		    note=note.replaceAll("#", "\r\n");
		    note=note.replaceAll("L'utente ", "");
			entityPDFRiepilogoValutazione.setNote(note);
			
			
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 		
   		return result;
   		
   	}     

//   	}  
    
//    public boolean caricaDati2PerEntityPDF(String idCandidatura)
//   	{	
//    	
//    	boolean result = false;
//		String totale = "";
//		String totaleTitoli = "";
//		String totaleEsperienze = "";
//    	
//    	try
//		{   
//			entityPDFRiepilogoValutazione = new EntityPDFRiepilogoValutazione();
//			
//			// cerco l'utente e i suoi associati
//			
//			UtenteCandidatura utenteCandidatura = new UtenteCandidatura();
//			UtenteCandidaturaHome utenteCandidaturaHome = new UtenteCandidaturaHome();
//			ArrayList<UtenteCandidatura> candidature = new ArrayList<UtenteCandidatura>();
//			Graduatoria graduatoria = new Graduatoria();
//			GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
//			
//			graduatoria = graduatoriaHome.findById(idCandidatura);
//			candidature = (ArrayList<UtenteCandidatura>) utenteCandidaturaHome.findUtenteCandidaturaByQuery(idCandidatura);
//						
//			// popolo l'entityValutazione per ogni utente
//			
//			ArrayList<Titoli> titoliList = new ArrayList<Titoli>();
//			
//			
//			for (UtenteCandidatura utente: candidature){
//			
//				Titoli titoli = new Titoli();
//				
//				String idUtente = utente.getIdUtente();
//				String idCandidaturaTitoli = utente.getCandidatura().getIdCandidatura();
//				
//				titoli = popolaTitoliPerUtente(idUtente, idCandidaturaTitoli);
//				
//				titoli.setNome(utente.getNomeUtente());
//				titoli.setCognome(utente.getCognomeUtente());
//			
//				//referente
//				if(idUtente.equals(idCandidatura)){
//					
//					titoli.setReferente(utente.getNomeUtente()+" "+utente.getCognomeUtente());
//				}
//				titoliList.add(titoli);
//								
//			}
//			
//			entityPDFRiepilogoValutazione.setReferente(graduatoria.getNome()+" "+graduatoria.getCognome()); 
//			entityPDFRiepilogoValutazione.setTitoli(titoliList);
//			entityPDFRiepilogoValutazione.setIntestazione(graduatoria.getNome()+" "+graduatoria.getCognome());
//			entityPDFRiepilogoValutazione.setNumeroProtocollo((graduatoria.getNumeroProtocollo()==null)?"0":graduatoria.getNumeroProtocollo());
//			entityPDFRiepilogoValutazione.setPunteggioTotale((graduatoria.getPunteggio()==null)?"0":graduatoria.getPunteggio().toString());
//			entityPDFRiepilogoValutazione.setPunteggioTotaleEsperienze((graduatoria.getPunteggioEsperienza()==null)?"0":graduatoria.getPunteggioEsperienza().toString());
//			entityPDFRiepilogoValutazione.setPunteggioTotaleTitoli((graduatoria.getPunteggioTitolo()==null)?"0":graduatoria.getPunteggioTitolo().toString());
//		    
//			
//			
//			
//		}
//		catch (Exception e)
//		{
//			e.printStackTrace();
//		} 		
//   		return result;
//   		
//   	}     

	public static String formattaDataTOString(Date w_date, String formatOra)
	{
		Calendar cal = Calendar.getInstance();
		String result = "";
		if (w_date!=null)
		{
			try { 
				cal.setTime(w_date);
				// Set time fields to zero  
				cal.set(Calendar.HOUR_OF_DAY, 0);  
				cal.set(Calendar.MINUTE, 0);  
				cal.set(Calendar.SECOND, 0);  
				cal.set(Calendar.MILLISECOND, 0);	
				SimpleDateFormat formatterOut = null;
				if (formatOra!=null)
				{	
					formatterOut = new SimpleDateFormat("dd-MM-yyyy" + " " + formatOra);
				}
				else
				{	
					formatterOut = new SimpleDateFormat("dd-MM-yyyy");
				}
					
					  
				result = formatterOut.format(cal.getTime()); 
			}
			catch (Exception e)
			{}			

		}
		return result;

	}
    
      
    public  PdfPTable createBoxSecondaLaureaTextF(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();        
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setPaddingLeft(-50);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            	
            }
            if (idx==3)
            {
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }
            if (idx==4)
            {
                cell7.setPaddingLeft(-50);
                cell7.setBorder(Rectangle.NO_BORDER);            	
            	cell7.addElement(w_testo);
            	
            }
            if (idx==5)
            {
                cell8.setBorder(Rectangle.NO_BORDER);            	
            	cell8.addElement(w_testo);
            	
            }          
        }
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);
        table2.addCell(cell6);
        table2.addCell(cell7);
        table2.addCell(cell8);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPagina(table, pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}  
         return table;
    }     
    
      
    public  PdfPTable createBoxVuotoText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
        try {
            PdfPCell cell = new PdfPCell();
            Paragraph w_testo = new Paragraph(testo,fonts8_normal);
            PdfContentByte canvas = pdfWrite.getDirectContent();
            w_testo.setAlignment(Element.ALIGN_RIGHT);
            cell.addElement(w_testo);             
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);
            table.setTotalWidth(700);
            table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
     		} catch (Exception e) {
     			// TODO Auto-generated catch block
     			e.printStackTrace();
     		}
             return table;
    }    
    public  PdfPTable createBoxPaginazioneText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
        try {
            PdfPCell cell = new PdfPCell();
            Paragraph w_testo = new Paragraph(testo,fonts6_normal);
            PdfContentByte canvas = pdfWrite.getDirectContent();
            w_testo.setAlignment(Element.ALIGN_RIGHT);
            cell.addElement(w_testo);             
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);
            table.setTotalWidth(550);
            table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
     		} catch (Exception e) {
     			// TODO Auto-generated catch block
     			e.printStackTrace();
     		}
             return table;
    }
    
   
    public  PdfPTable createBoxElencoCandidati(List<EntityPDFRicevuta> entity,PdfWriter pdfWrite ) {
    
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(5);
    	int[] widths = {15, 25, 25, 15, 30};
//veri 	int[] widths = {15, 25, 30, 15, 15};
//colo 	int[] widths = {15, 25, 30, 15, 17};

    try {
        PdfPCell cell = new PdfPCell();
        PdfContentByte canvas = pdfWrite.getDirectContent();
       
        PdfPCell cell2 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT + Rectangle.TOP);
        Paragraph w_testo = null;

        
        
        
        for (EntityPDFRicevuta idx_entity : entity)
        {
//        	for di entity nome cogno cf data
        	
        	PdfPCell cell3 = new PdfPCell();
            PdfPCell cell4 = new PdfPCell();
            PdfPCell cell5 = new PdfPCell();
            PdfPCell cell6 = new PdfPCell();
            PdfPCell cell7 = new PdfPCell();
          
           
            w_testo = new Paragraph(idx_entity.getCognome(),fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  

                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);

            	w_testo = new Paragraph(idx_entity.getNome(),fonts8_normal);
                w_testo.setAlignment(Element.ALIGN_LEFT);  

                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);

            	w_testo = new Paragraph(idx_entity.getCodFiscale(),fonts8_normal);
                w_testo.setAlignment(Element.ALIGN_LEFT);  
            	

                cell5.setBorder(Rectangle.NO_BORDER); 
                cell5.setNoWrap(false);
            	cell5.addElement(w_testo);

            	w_testo = new Paragraph(formattaDataTOString(idx_entity.getDataNasc(), ""),fonts8_normal);
                w_testo.setAlignment(Element.ALIGN_LEFT);  
            	
         	
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);

            	w_testo = new Paragraph(idx_entity.getLuogoNasc(),fonts8_normal);
                w_testo.setAlignment(Element.ALIGN_LEFT);  
            	
         	
                cell7.setBorder(Rectangle.NO_BORDER);            	
            	cell7.addElement(w_testo);
            	
            	table2.addCell(cell3);
                table2.addCell(cell4);
                table2.addCell(cell5);
                table2.addCell(cell6);
                table2.addCell(cell7);
                table2.setWidths(widths);



           
        }

        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        if (nriga_posizione != 0)
    	{	
    		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
    	}
    	else
    	{	
    		nriga_posizione = 790;
    	}         
        //saltoPagina(table,pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
         return table;
    } 
    
    
   
    
       
    public  PdfPTable saltoPaginaForzata(PdfPTable table,PdfWriter pdfWrite,PdfContentByte canvas,PdfPCell cell2)
    {
    	if (
    				(LIMITE_SALTO_PAGINA >= (nriga_posizione - (int)table.getTotalHeight())) ||
    				((LIMITE_SALTO_PAGINA + 20) >= (nriga_posizione - (int)table.getTotalHeight()))
    			)	
    		{
    			table.setTotalWidth(550);
    			table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);
				documentoPDF.newPage();
				pdfWrite.setPageEmpty(false);
				nriga_posizione = 840;
//				w_testo = getBodyRicevuta().getProperty("headerpagina");
//				w_testo = setTextParamatriHeader(w_testo);
				w_testo="";
//				nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
				nriga_posizione = 780;
				table = null;	
    		}
    		return table;

    }
    
    
    
    public  void saltoPaginaUltimo(PdfPTable table,PdfWriter pdfWrite)
    {
    			nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);

    }    
    
    
    public  void saltoPagina(PdfPTable table,PdfWriter pdfWrite)
    {
    		if (LIMITE_SALTO_PAGINA >= (nriga_posizione - (int)table.getTotalHeight()))
    		{
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);
				documentoPDF.newPage();
				pdfWrite.setPageEmpty(false);
				nriga_posizione = 840;
//				w_testo = getBodyRicevuta().getProperty("headerpagina");
				w_testo = "";
//				nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
				nriga_posizione = 780;
				nriga_posizione = 0;
    		}

    }
    
    
    public  void saltoPaginaPdf(PdfWriter pdfWrite)
    {
    		if (LIMITE_SALTO_PAGINA >= nriga_posizione)
    		{
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);
				documentoPDF.newPage();
				pdfWrite.setPageEmpty(false);
				nriga_posizione = 840;
//				w_testo = getBodyRicevuta().getProperty("headerpagina");
				w_testo = "";
			//	nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
				nriga_posizione = 780;
				seLabelColumn = true;
    		}

    }
    
    
    public  void saltoPaginaNote(PdfWriter pdfWrite)
    {
			nriga_posizione = POS_RIGA_SALTO_PAGINA; 
			String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
			createBoxPaginazioneText("",w_testo,pdfWrite);
			documentoPDF.newPage();
			pdfWrite.setPageEmpty(false);
			nriga_posizione = 840;
//				w_testo = getBodyRicevuta().getProperty("headerpagina");
			w_testo = "";
//				nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
			nriga_posizione = 780;
			nriga_posizione = 0;
	

    }
    
    public  String setTextParamatriDatiInvio(String testo)
    {
    
    	testo = testo.replace("<?-&1-?>","");
    	testo = testo.replace("<?-&2-?>",(getEntityPDFRiepilogoValutazione().getPunteggioTotaleTitoli())==null?"0":getEntityPDFRiepilogoValutazione().getPunteggioTotaleTitoli());
    	testo = testo.replace("<?-&3-?>", "");
    	testo = testo.replace("<?-&4-?>",(getEntityPDFRiepilogoValutazione().getPunteggioTotaleEsperienze())==null?"0":getEntityPDFRiepilogoValutazione().getPunteggioTotaleEsperienze());
    	testo = testo.replace("<?-&5-?>", "");
    	testo = testo.replace("<?-&6-?>", (getEntityPDFRiepilogoValutazione().getPunteggioTotale())==null?"0":getEntityPDFRiepilogoValutazione().getPunteggioTotale());
    	
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	
    	return testo;
    }
    
    public  String setTextParamatriNote(String testo)
    {
        
    	testo = testo.replace("<?-&1-?>", entityPDFRiepilogoValutazione.getNote()==null?"Nessuna":entityPDFRiepilogoValutazione.getNote()) ;
//    	testo = testo.replace("<?-&2-?>",(getEntityPDFRiepilogoValutazione().getPunteggioTotaleTitoli())==null?"0":getEntityPDFRiepilogoValutazione().getPunteggioTotaleTitoli());
    	
//    	while (testo.indexOf("<?-n-?>") > 0)
//    	{
//    		testo = testo.replace("<?-n-?>", "\r\n");
//    	}
    	
    	return testo;
    }
    
	public  PdfPTable createBoxDatiInvioText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();
       
       
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
            	cell4.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
            	cell4.addElement(w_testo);
                
            } 
           
            if (idx==2)
            {
                cell5.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);            	
            	cell5.addElement(w_testo);
            	
            }
            if (idx==3)
            {
            	cell6.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
            	cell6.addElement(w_testo);
                
            }       
            if (idx==4)
            {
            	cell7.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT+Rectangle.BOTTOM);
            	cell7.addElement(w_testo);
                
            }         
            if (idx==5)
            {
            	cell8.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT+Rectangle.BOTTOM);            	
            	cell8.addElement(w_testo);
            }     
            
          
        }
    	table2.addCell(cell3);
        table2.addCell(cell4);             	
    	table2.addCell(cell5);
    	table2.addCell(cell6);
        table2.addCell(cell7);             	
    	table2.addCell(cell8);
    	cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);       
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		
    
         return table;
    }     
	
	public  PdfPTable createBoxNoteCandidaturaText_old(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	
    	PdfPTable table = new PdfPTable(1);
//    	PdfPTable table2 = new PdfPTable(2);
    	PdfPTable table2 = new PdfPTable(1);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = null;
//        PdfPCell cell4 = new PdfPCell();
//        PdfPCell cell5 = new PdfPCell();
//        PdfPCell cell6 = new PdfPCell();
//        PdfPCell cell7 = new PdfPCell();
//        PdfPCell cell8 = new PdfPCell();
       
       
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            cell3 = new PdfPCell();
        	w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
//            if (idx==0)
//            {
                cell3.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);            	
            	cell3.addElement(w_testo);
            	
//            }
         	table2.addCell(cell3);
        }
//    	table2.addCell(cell3);
//        table2.addCell(cell4);             	
//    	table2.addCell(cell5);
//    	table2.addCell(cell6);
//        table2.addCell(cell7);             	
//    	table2.addCell(cell8);
    	cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);       
//        saltoPagina(table, pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		
    
         return table;
    }     
	
	
	public  PdfPTable createBoxNoteCandidaturaText(String etichetta,String testo, List<String> ww_testi_riga , PdfWriter pdfWrite ,String saltoPagina ) {
    	// a table with three columns
    	
    	PdfPTable table = new PdfPTable(1);
//    	PdfPTable table2 = new PdfPTable(2);
    	PdfPTable table2 = new PdfPTable(1);
    	
//    salto pagina
   
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = null;      
       
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
    	for (int idx=0;idx<ww_testi_riga.size();idx++)
            {
            cell3 = new PdfPCell();
          	w_testo = new Paragraph(ww_testi_riga.get(idx),fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            
            if (ww_testi_riga.size()==1){
                cell3.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.BOTTOM+ Rectangle.RIGHT);            	
            } else {
            	 if (ww_testi_riga.size()==2){
            		 if (idx==0){
                         cell3.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);            	
                     } else{
                         cell3.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
                     } 
                 } else {
                	  if (idx==0){
                          cell3.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);            	
                      } else{
                           if(idx+1==ww_testi_riga.size()){
                     	   	  cell3.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);  
                     	   } else {
                     		 cell3.setBorder(Rectangle.LEFT + Rectangle.RIGHT); 
                     	   }
                      }
                 }
                
            }
            
            	
        	cell3.addElement(w_testo);
            
         	table2.addCell(cell3);
        }

    	cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);   
//        if ((conta%LIMITE_LISTA_NOTE_FROM_PAGE)==0){
        if (saltoPagina.equalsIgnoreCase("SI")){
        	saltoPaginaNote(pdfWrite);
        }
        
		
    	} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		
    
         return table;
    }     
	
	
    
    
    
	
	
	 public  PdfPTable createBoxNotaText(String etichetta,String testo,PdfWriter pdfWrite ) {
	    	// a table with three columns
	    	PdfPTable table = new PdfPTable(1);
	    	
	    try {
	       PdfPCell cell = new PdfPCell();
	       //testo = "NOTA" +  "\n" + testo + "\n";fff
	       Paragraph w_etichetta = new Paragraph(etichetta,fonts10_bold);
	       Paragraph w_testo = new Paragraph(testo,fonts10_bold);
	       w_etichetta.add(w_testo);
	       PdfContentByte canvas = pdfWrite.getDirectContent();
	       w_testo.setAlignment(Element.ALIGN_LEFT + Element.ALIGN_JUSTIFIED);
	       cell.addElement(w_etichetta); 
	       table.addCell(cell);
	       table.setTotalWidth(550);
	       table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   	if (nriga_posizione != 0)
		   	{	
		   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		   	}
		   	else
		   	{	
		   		nriga_posizione = 790;
		   	}      
	        return table;
	    } 

	 public  String setTextParamatriPunteggioTitoli(String testo, Titoli titoli)
	    {
/*	    	BigDecimal punteggioSecondaLaurea = new BigDecimal(0);
	    	BigDecimal punteggioSpec = new BigDecimal(0);
	    	BigDecimal punteggioPubbl = new BigDecimal(0);
	    	BigDecimal punteggioidoneita = new BigDecimal(0);
	    	BigDecimal punteggioIdoneitaNaz = new BigDecimal(0);
	    	BigDecimal punteggioAltraLaurea = new BigDecimal(0);
	    	BigDecimal punteggioLaurea = new BigDecimal(0);
	    	BigDecimal punteggioAbilitazione = new BigDecimal(0);
	    	
	    	
	    	//calcolo punteggio altrelauree
	    	
	    	if(titoli.getAltraLaureaBisReg()!=null && !titoli.getAltraLaureaBisReg().isEmpty()){
	    		
	    		punteggioSecondaLaurea = new BigDecimal(titoli.getAltraLaureaBisReg().get(0).getPunteggio().toString().replace(",", "."));
	    	}

	        if(titoli.getRequisitiMinimiReg()!=null && titoli.getRequisitiMinimiReg().size()>0){
	        	for(RequisitiMinimiReg requisitiMInimiReg : titoli.getRequisitiMinimiReg()){
	        	
	        		punteggioLaurea = punteggioLaurea.add(requisitiMInimiReg.getPunteggioLaurea() == null ? new BigDecimal(0) : requisitiMInimiReg.getPunteggioLaurea());
	        		punteggioAbilitazione = punteggioAbilitazione.add(requisitiMInimiReg.getPunteggioAbilitazione()==null ? new BigDecimal(0) : requisitiMInimiReg.getPunteggioAbilitazione());
	        	}
	        }
	        
	            	
	    	//calcolo punteggio spec-dott-borse
	    	if(titoli.getSpecializzazioneReg()!= null  && !titoli.getSpecializzazioneReg().isEmpty()){
	    		for (SpecializzazioneReg specializzazioneReg :titoli.getSpecializzazioneReg()){
		    		
		    		punteggioSpec = punteggioSpec.add(specializzazioneReg.getPunteggio() == null ? new BigDecimal(0):specializzazioneReg.getPunteggio());
		    	}
	    	}
	    	
	    	if(titoli.getDottoratoReg()!=null && !titoli.getDottoratoReg().isEmpty()){
	    		for (DottoratoReg dottoratoReg :titoli.getDottoratoReg()){
		    		
		    		punteggioSpec = punteggioSpec.add(dottoratoReg.getPunteggio()== null ? new BigDecimal(0):dottoratoReg.getPunteggio());
		    	}
	    	}
	    	
	    	if(titoli.getBorsaStudioReg()!=null && !titoli.getBorsaStudioReg().isEmpty()){
	    		for (BorsaStudioReg borsaStudioReg :titoli.getBorsaStudioReg()){
		    		
		    		punteggioSpec = punteggioSpec.add(borsaStudioReg.getPunteggio() == null ? new BigDecimal(0):borsaStudioReg.getPunteggio());
		    	}
	    	}
	    	
	    	
	    	if(punteggioSpec.compareTo(new BigDecimal(2)) >= 1){
	    		
	    		punteggioSpec = new BigDecimal(2);
	    		
	    	}
	    	
	    	//calcolo punteggio pubbl
	    	if(titoli.getPubblicazioneReg()!=null && !titoli.getPubblicazioneReg().isEmpty()){
	    		for(PubblicazioneReg pubblicazioneReg : titoli.getPubblicazioneReg()){
		    		
		    		punteggioPubbl = punteggioPubbl.add(pubblicazioneReg.getPunteggio() == null ? new BigDecimal(0):pubblicazioneReg.getPunteggio());
		    	}
	    	}
	    	
	    	
	    	if(punteggioPubbl.compareTo(new BigDecimal(2)) >= 1){
	    		
	    		punteggioPubbl = new BigDecimal(2);
	    		
	    	}
	    	
	    	if(titoli.getAltraLaureaReg()!=null && !titoli.getAltraLaureaReg().isEmpty()){
	    	
	    		punteggioAltraLaurea = new BigDecimal(3.5);
	    	}
	    	
//	      CALCOLA VOTO IDONEITA E ABILITAZIONE  �
	    	if(titoli.getIdoneitaReg()!=null && !titoli.getIdoneitaReg().isEmpty()){
	    		for (IdoneitaReg idoneitaReg : titoli.getIdoneitaReg()){
		        	
		    		if(idoneitaReg.getRifIdoneitaNazionale()!=null && !idoneitaReg.getRifIdoneitaNazionale().equals("")){
		    			
		    			punteggioIdoneitaNaz = punteggioIdoneitaNaz.add(new BigDecimal(1));
		    		}
		    		
		    		if(idoneitaReg.getEstremiIdoneita()!=null && !idoneitaReg.getEstremiIdoneita().equals("")){
		    			
		    			punteggioidoneita = punteggioidoneita.add(new BigDecimal(1));
		    		}
		        	
		        }
	    	}
	    	*/
	    	
	    	
	    	testo = testo.replace("<?-&1-?>","");
	    	testo = testo.replace("<?-&2-?>", "");
	    	testo = testo.replace("<?-&3-?>",""); 
	    	testo = testo.replace("<?-&4-?>", titoli.parzialeTitolo[0]);
	    	testo = testo.replace("<?-&5-?>","");
	    	testo = testo.replace("<?-&6-?>", titoli.parzialeTitolo[1]);
	    	testo = testo.replace("<?-&7-?>","");
	    	testo = testo.replace("<?-&8-?>", titoli.parzialeTitolo[2]);
	    	testo = testo.replace("<?-&9-?>","");
	    	testo = testo.replace("<?-&10-?>", titoli.parzialeTitolo[3]);
	    	testo = testo.replace("<?-&11-?>","");
	    	testo = testo.replace("<?-&12-?>", titoli.parzialeTitolo[4]);
	    	testo = testo.replace("<?-&13-?>","");
	    	testo = testo.replace("<?-&14-?>",titoli.parzialeTitolo[5]);
	    	testo = testo.replace("<?-&15-?>","");
	    	testo = testo.replace("<?-&16-?>", titoli.parzialeTitolo[6]);
	    	testo = testo.replace("<?-&17-?>","");
	    	testo = testo.replace("<?-&18-?>",titoli.parzialeTitolo[7]);
	    	

	    	
	    	while (testo.indexOf("<?-n-?>") > 0)
	    	{
	    		testo = testo.replace("<?-n-?>", "\r\n");
	    	}
	    	return testo;
	    }   
	 
	 
	 public  String setTextParamatriPunteggioTitoliAssociati(String testo, Titoli titoli)  {
			
		int result =0;
    	testo = testo.replace("<?-&1-?>","");
    	testo = testo.replace("<?-&2-?>", "");
    	testo = testo.replace("<?-&21-?>", "");
    	testo = testo.replace("<?-&3-?>",""); 
//A-Laurea principale    	
    	BigDecimal campoA = new BigDecimal(titoli.parzialeTitolo[0].replaceAll(",", "."));
    	result = campoA.compareTo(new BigDecimal("5"));
		if (result==1){ campoA=new BigDecimal("5"); }
		testo = testo.replace("<?-&4-?>", titoli.parzialeTitolo[0]);
    	testo = testo.replace("<?-&41-?>", campoA.toString().replace(".", ","));
		
    	testo = testo.replace("<?-&5-?>","");
//D-Seconda laurea in farmacia o CTF    	
    	BigDecimal campoD = new BigDecimal(titoli.parzialeTitolo[1].replaceAll(",", "."));
    	result = campoD.compareTo(new BigDecimal("1.5"));
		if (result==1){ campoD=new BigDecimal("1.5"); }
		testo = testo.replace("<?-&6-?>", titoli.parzialeTitolo[1]);
    	testo = testo.replace("<?-&61-?>", campoD.toString().replace(".", ","));

    	testo = testo.replace("<?-&7-?>","");
//B-Altre Lauree   	
    	BigDecimal campoB = new BigDecimal(titoli.parzialeTitolo[2].replaceAll(",", "."));
    	result = campoB.compareTo(new BigDecimal("3.5"));
		if (result==1){ campoB=new BigDecimal("3.5"); }
		testo = testo.replace("<?-&8-?>", titoli.parzialeTitolo[2]);
    	testo = testo.replace("<?-&81-?>", campoB.toString().replace(".", ","));

    	testo = testo.replace("<?-&9-?>","");
//C-Specializzazioni-Borse di studio o di ricerca 
    	BigDecimal campoC = new BigDecimal(titoli.parzialeTitolo[3].replaceAll(",", "."));
    	result = campoC.compareTo(new BigDecimal("2"));
		if (result==1){ campoC=new BigDecimal("2"); }
		testo = testo.replace("<?-&10-?>", titoli.parzialeTitolo[3]);
    	testo = testo.replace("<?-&101-?>", campoC.toString().replace(".", ","));
    	
    	testo = testo.replace("<?-&11-?>","");
//E-Pubblicazioni Scientifiche   	
    	BigDecimal campoE = new BigDecimal(titoli.parzialeTitolo[4].replaceAll(",", "."));
    	result = campoE.compareTo(new BigDecimal("1"));
		if (result==1){ campoE=new BigDecimal("1"); }
		testo = testo.replace("<?-&12-?>", titoli.parzialeTitolo[4]);
    	testo = testo.replace("<?-&121-?>", campoE.toString().replace(".", ","));

    	testo = testo.replace("<?-&13-?>","");
//F-Idoneit� precedente concorso   	
    	BigDecimal campoF = new BigDecimal(titoli.parzialeTitolo[5].replaceAll(",", "."));
    	result = campoF.compareTo(new BigDecimal("1"));
		if (result==1){ campoF=new BigDecimal("1"); }
		testo = testo.replace("<?-&14-?>", titoli.parzialeTitolo[5]);
    	testo = testo.replace("<?-&141-?>",campoF.toString().replace(".", ","));
    	
    	testo = testo.replace("<?-&15-?>","");
//G-Idoneit� nazionale farmacista dirigente
    	BigDecimal campoG = new BigDecimal(titoli.parzialeTitolo[6].replaceAll(",", "."));
    	result = campoG.compareTo(new BigDecimal("1"));
		if (result==1){ campoG=new BigDecimal("1"); }
		testo = testo.replace("<?-&16-?>", titoli.parzialeTitolo[6]);
    	testo = testo.replace("<?-&161-?>", campoG.toString().replace(".", ","));
    	
    	testo = testo.replace("<?-&17-?>","");
//H-Voto di abilitazione e corsi di aggiornamento
    	BigDecimal campoH = new BigDecimal(titoli.parzialeTitolo[7].replaceAll(",", "."));
    	result = campoH.compareTo(new BigDecimal("0.5"));
		if (result==1){ campoH=new BigDecimal("0.5"); }
		testo = testo.replace("<?-&18-?>", titoli.parzialeTitolo[7]);
    	testo = testo.replace("<?-&181-?>", campoH.toString().replace(".", ","));
    	

    	
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
}   

	 
	 public  String setPunteggioTitoliMAX(String testo)
	    {
	    	
			HashMap hmParmetri  = new HashMap();
			hmParmetri = setTextParamatriGrigliaTotale(testo);
			
			HashMap<String, List<String>> grigliaTitoli = new HashMap<String, List<String>>();
			grigliaTitoli= (HashMap<String, List<String>>) hmParmetri.get("grigliaTitoli");
			
			String[] intestazioneTitoli = null;
			intestazioneTitoli = (String[]) hmParmetri.get("intestazioneTitoli");
			
			HashMap<String, BigDecimal>  totaliTitoli = (HashMap<String, BigDecimal >) hmParmetri.get("totaliTitoli");
			
	
//			idx[0] "Titoli", 
//			idx[2] "A-Laurea principale"
//			idx[4] "D-Seconda laurea in farmacia o CTF"
//			idx[6] "B-Altre Lauree", listAltreLaure);
//			idx[8] "C-Specializzazioni-Borse di studio o di ricerca"
//			idx[10] "E-Pubblicazioni Scientifiche"
//			idx[12] "F-Idoneit� precedente concorso"
//			idx[14] "G-Idoneit� nazionale farmacista dirigente"
//			idx[16] "H-Voto di abilitaz0069one e corsi di aggiornamento"
			
//			List<String> listTitoli =  grigliaTitoli.get(intestazioneTitoli[0]);
			List<String> listLaurea =  grigliaTitoli.get(intestazioneTitoli[2]);
			List<String> listSecondaLaurea =  grigliaTitoli.get(intestazioneTitoli[4]);
			List<String> listAltreLaure = grigliaTitoli.get(intestazioneTitoli[6]);
			List<String> listSpecializ = grigliaTitoli.get(intestazioneTitoli[8]);
			List<String> listPubblicaz = grigliaTitoli.get(intestazioneTitoli[10]);
			List<String> listIdonetaPrec = grigliaTitoli.get(intestazioneTitoli[12]);
			List<String> listIdonetaNaz = grigliaTitoli.get(intestazioneTitoli[14]);
			List<String> listVotoAbb = grigliaTitoli.get(intestazioneTitoli[16]);

	        BigDecimal totaleMAXatt = new BigDecimal("0");
			totaleMAXatt = totaleMAXatt.add(new BigDecimal(listLaurea.get(listLaurea.size()-1).replace(",", ".")))
									   .add(new BigDecimal(listSecondaLaurea.get(listSecondaLaurea.size()-1).replace(",", ".")))
					                   .add(new BigDecimal(listAltreLaure.get(listAltreLaure.size()-1).replace(",", ".")))
									   .add(new BigDecimal(listSpecializ.get(listSpecializ.size()-1).replace(",", ".")))
									   .add(new BigDecimal(listPubblicaz.get(listPubblicaz.size()-1).replace(",", ".")))
									   .add(new BigDecimal(listIdonetaPrec.get(listIdonetaPrec.size()-1).replace(",", ".")))
									   .add(new BigDecimal(listIdonetaNaz.get(listIdonetaNaz.size()-1).replace(",", ".")))
									   .add(new BigDecimal(listVotoAbb.get(listVotoAbb.size()-1).replace(",", ".")));
			int result = 0;
			result = totaleMAXatt.compareTo(new BigDecimal("15"));
			if (result==1) totaleMAXatt = new BigDecimal("15");
		 
	    	testo = testo.replace("<?-&1-?>","");
	    	testo = testo.replace("<?-&2-?>", "");
	    	testo = testo.replace("<?-&21-?>", "");
	    	testo = testo.replace("<?-&3-?>",""); 
	    	testo = testo.replace("<?-&4-?>",  totaliTitoli.get(intestazioneTitoli[2]).toString().replace(".", ","));
	    	testo = testo.replace("<?-&41-?>", listLaurea.get(listLaurea.size()-1));
	    	testo = testo.replace("<?-&5-?>","");
	    	testo = testo.replace("<?-&6-?>",  totaliTitoli.get(intestazioneTitoli[4]).toString().replace(".", ","));
	    	testo = testo.replace("<?-&61-?>", listSecondaLaurea.get(listSecondaLaurea.size()-1));
	    	testo = testo.replace("<?-&7-?>","");
	    	testo = testo.replace("<?-&8-?>",  totaliTitoli.get(intestazioneTitoli[6]).toString().replace(".", ","));
	    	testo = testo.replace("<?-&81-?>", listAltreLaure.get(listAltreLaure.size()-1));
	    	testo = testo.replace("<?-&9-?>","");
	    	testo = testo.replace("<?-&10-?>",  totaliTitoli.get(intestazioneTitoli[8]).toString().replace(".", ","));
	    	testo = testo.replace("<?-&101-?>", listSpecializ.get(listSpecializ.size()-1));
	    	testo = testo.replace("<?-&11-?>","");
	    	testo = testo.replace("<?-&12-?>",  totaliTitoli.get(intestazioneTitoli[10]).toString().replace(".", ","));
	    	testo = testo.replace("<?-&121-?>", listPubblicaz.get(listPubblicaz.size()-1));
	    	testo = testo.replace("<?-&13-?>","");
	    	testo = testo.replace("<?-&14-?>",  totaliTitoli.get(intestazioneTitoli[12]).toString().replace(".", ","));
	    	testo = testo.replace("<?-&141-?>", listIdonetaPrec.get(listIdonetaPrec.size()-1));
	    	testo = testo.replace("<?-&15-?>","");
	    	testo = testo.replace("<?-&16-?>",  totaliTitoli.get(intestazioneTitoli[14]).toString().replace(".", ","));
	    	testo = testo.replace("<?-&161-?>", listIdonetaNaz.get(listIdonetaNaz.size()-1));
	    	testo = testo.replace("<?-&17-?>","");
	    	testo = testo.replace("<?-&18-?>",  totaliTitoli.get(intestazioneTitoli[16]).toString().replace(".", ","));
	    	testo = testo.replace("<?-&181-?>", listVotoAbb.get(listVotoAbb.size()-1));
	    	testo = testo.replace("<?-&19-?>","");
	    	testo = testo.replace("<?-&20-?>", totaliTitoli.get("totaliSommatoria").toString().replace(".", ","));
	    	testo = testo.replace("<?-&201-?>", totaleMAXatt.toString().replace(".", ","));
	    	
	    	
	    	while (testo.indexOf("<?-n-?>") > 0)
	    	{
	    		testo = testo.replace("<?-n-?>", "\r\n");
	    	}
	    	return testo;
	    }   
	 
	 
	 public  String setTextParamatriTitoli(String testo)
	    {
	    	
	    	
	    	testo = testo.replace("<?-&1-?>","");
	    	testo = testo.replace("<?-&2-?>", "");
	    	testo = testo.replace("<?-&3-?>",""); 
	    	testo = testo.replace("<?-&4-?>", "");
	    	testo = testo.replace("<?-&5-?>","");
	    	testo = testo.replace("<?-&6-?>", "");
	    	testo = testo.replace("<?-&7-?>","");
	    	testo = testo.replace("<?-&8-?>", "");
	    	testo = testo.replace("<?-&9-?>","");
	    	testo = testo.replace("<?-&10-?>", "");
	    	testo = testo.replace("<?-&11-?>","");
	    	testo = testo.replace("<?-&12-?>", "");
	    	testo = testo.replace("<?-&13-?>","");
	    	testo = testo.replace("<?-&14-?>", "");
	    	testo = testo.replace("<?-&15-?>","");
	    	testo = testo.replace("<?-&16-?>", "");
	    	testo = testo.replace("<?-&17-?>","");
	    	testo = testo.replace("<?-&18-?>", "");
	    	

	    	
	    	while (testo.indexOf("<?-n-?>") > 0)
	    	{
	    		testo = testo.replace("<?-n-?>", "\r\n");
	    	}
	    	return testo;
	    }   

	 public  HashMap setTextParamatriGrigliaTotale(String testo)
	    {
	    	HashMap hmParametri = new HashMap();
		    
	    	List<String> listTitoli = new ArrayList<String>();
			List<String> listLaurea = new ArrayList<String>();
			List<String> listSecondaLaurea = new ArrayList<String>();
			List<String> listAltreLaure = new ArrayList<String>();
			List<String> listSpecializ = new ArrayList<String>();
			List<String> listPubblicaz = new ArrayList<String>();
			List<String> listIdonetaPrec = new ArrayList<String>();
			List<String> listIdonetaNaz = new ArrayList<String>();
			List<String> listVotoAbb = new ArrayList<String>();
			
			
			testo = getBodyRicevuta().getProperty("dettagliovalutazioneCandidato");    //EX DATI ANAGRAFICI  --> � LA TABELLA DI DETTAGLIO DEL CANDIDATO
			testo = setTextParamatriTitoli(testo);
			String[] intestazioneTitoli = testo.split("#");
			
			HashMap<String, List<String>> grigliaTitoli = new HashMap<String, List<String>>();
//			idx[0] "Titoli", 
//			idx[2] "A-Laurea principale"
//			idx[4] "D-Seconda laurea in farmacia o CTF"
//			idx[6] "B-Altre Lauree", listAltreLaure);
//			idx[8] "C-Specializzazioni-Borse di studio o di ricerca"
//			idx[10] "E-Pubblicazioni Scientifiche"
//			idx[12] "F-Idoneit� precedente concorso"
//			idx[14] "G-Idoneit� nazionale farmacista dirigente"
//			idx[16] "H-Voto di abilitaz0069one e corsi di aggiornamento"
			
			grigliaTitoli.put(intestazioneTitoli[0],  listTitoli);
			grigliaTitoli.put(intestazioneTitoli[2],  listLaurea);
			grigliaTitoli.put(intestazioneTitoli[4],  listSecondaLaurea);
			grigliaTitoli.put(intestazioneTitoli[6],  listAltreLaure);
			grigliaTitoli.put(intestazioneTitoli[8],  listSpecializ);
			grigliaTitoli.put(intestazioneTitoli[10], listPubblicaz);
			grigliaTitoli.put(intestazioneTitoli[12], listIdonetaPrec);
			grigliaTitoli.put(intestazioneTitoli[14], listIdonetaNaz);
			grigliaTitoli.put(intestazioneTitoli[16], listVotoAbb);

//Elemento di 0 intestazione di collonne
			listTitoli        .add(intestazioneTitoli[0]);
			listLaurea        .add(intestazioneTitoli[2]);
			listSecondaLaurea .add(intestazioneTitoli[4]);
			listAltreLaure    .add(intestazioneTitoli[6]);
			listSpecializ     .add(intestazioneTitoli[8]);
			listPubblicaz     .add(intestazioneTitoli[10]);
			listIdonetaPrec   .add(intestazioneTitoli[12]);
			listIdonetaNaz    .add(intestazioneTitoli[14]);
			listVotoAbb       .add(intestazioneTitoli[16]);
			
			BigDecimal tLaurea = new BigDecimal("0");
			BigDecimal tSecondaLaurea = new BigDecimal("0");
			BigDecimal tAltreLaure = new BigDecimal("0");
			BigDecimal tSpecializ = new BigDecimal("0");
			BigDecimal tPubblicaz = new BigDecimal("0");
			BigDecimal tIdonetaPrec	 = new BigDecimal("0");
			BigDecimal tIdonetaNaz = new BigDecimal("0");
			BigDecimal tVotoAbb	 = new BigDecimal("0");
			
			for(UtenteTitoli u : entityPDFRiepilogoValutazione.getListaUtentiTitoli()){
				testo = getBodyRicevuta().getProperty("dettagliovalutazioneCandidato");    //EX DATI ANAGRAFICI  --> � LA TABELLA DI DETTAGLIO DEL CANDIDATO
				testo = setTextParamatriPunteggioTitoli(testo, u.getTitoli());								
				String[] valori = testo.split("#");
//listTitoli c'� anche nome e cognome della persona
//Valorei relativi alle colonne						
				listTitoli			.add(u.getUtente().getCognomeUtente()+ " "+u.getUtente().getNomeUtente());
				listLaurea			.add(valori[3]);
				listSecondaLaurea	.add(valori[5]);
				listAltreLaure		.add(valori[7]);
				listSpecializ		.add(valori[9]);
				listPubblicaz		.add(valori[11]);
				listIdonetaPrec		.add(valori[13]);
				listIdonetaNaz		.add(valori[15]);
				listVotoAbb			.add(valori[17]);
				
				tLaurea       =tLaurea				.add(new BigDecimal(valori[3].replace(",", ".")));
				tSecondaLaurea=tSecondaLaurea		.add(new BigDecimal(valori[5].replace(",", ".")));
				tAltreLaure   =tAltreLaure			.add(new BigDecimal(valori[7].replace(",", ".")));
				tSpecializ    =tSpecializ			.add(new BigDecimal(valori[9].replace(",", ".")));
				tPubblicaz    =tPubblicaz			.add(new BigDecimal(valori[11].replace(",", ".")));
				tIdonetaPrec  =tIdonetaPrec			.add(new BigDecimal(valori[13].replace(",", ".")));
				tIdonetaNaz   =tIdonetaNaz			.add(new BigDecimal(valori[15].replace(",", ".")));
				tVotoAbb      =tVotoAbb				.add(new BigDecimal(valori[17].replace(",", ".")));
			}
			 
			HashMap<String, BigDecimal> totaliTitoli = new HashMap<String, BigDecimal>();

			totaliTitoli.put(intestazioneTitoli[2],  new BigDecimal(tLaurea.toString()));
			totaliTitoli.put(intestazioneTitoli[4],  new BigDecimal(tSecondaLaurea.toString()));
			totaliTitoli.put(intestazioneTitoli[6],  new BigDecimal(tAltreLaure.toString()));
			totaliTitoli.put(intestazioneTitoli[8],  new BigDecimal(tSpecializ.toString()));
			totaliTitoli.put(intestazioneTitoli[10], new BigDecimal(tPubblicaz.toString()));
			totaliTitoli.put(intestazioneTitoli[12], new BigDecimal(tIdonetaPrec.toString()));
			totaliTitoli.put(intestazioneTitoli[14], new BigDecimal(tIdonetaNaz.toString()));
			totaliTitoli.put(intestazioneTitoli[16], new BigDecimal(tVotoAbb.toString()));
			BigDecimal totaliSommatoria = new BigDecimal("0");
			totaliSommatoria =  totaliSommatoria.add(tLaurea).add(tSecondaLaurea).add(tAltreLaure).add(tSpecializ).add(tPubblicaz).add(tIdonetaPrec).add(tIdonetaNaz).add(tVotoAbb);
			totaliTitoli.put("totaliSommatoria", new BigDecimal(totaliSommatoria.toString()));
				
//Totali
			listTitoli.add("Totali");
		
			int result =0;
			result = tLaurea.compareTo(new BigDecimal("5"));
			if (result==1){ tLaurea=new BigDecimal("5"); }
			listLaurea.add(tLaurea.toString().replace(".", ","));
			
			result = tSecondaLaurea.compareTo(new BigDecimal("1.5"));
			if (result==1){ tSecondaLaurea=new BigDecimal("1.5"); }
			listSecondaLaurea.add(tSecondaLaurea.toString().replace(".", ","));
			
			result = tAltreLaure.compareTo(new BigDecimal("3.5"));
			if (result==1){ tAltreLaure=new BigDecimal("3.5"); }
			listAltreLaure.add(tAltreLaure.toString().replace(".", ","));
		
			result = tSpecializ.compareTo(new BigDecimal("2"));
			if (result==1){ tSpecializ=new BigDecimal("2"); }
			listSpecializ.add(tSpecializ.toString().replace(".", ","));
		
			result = tPubblicaz.compareTo(new BigDecimal("1"));
			if (result==1){ tPubblicaz=new BigDecimal("1"); }
			listPubblicaz.add(tPubblicaz.toString().replace(".", ","));
		
			result = tIdonetaPrec.compareTo(new BigDecimal("1"));
			if (result==1){ tIdonetaPrec=new BigDecimal("1"); }
			listIdonetaPrec.add(tIdonetaPrec.toString().replace(".", ","));
		
			result = tIdonetaNaz.compareTo(new BigDecimal("1"));
			if (result==1){ tIdonetaNaz=new BigDecimal("1"); }
			listIdonetaNaz.add(tIdonetaNaz.toString().replace(".", ","));
		
			result = tVotoAbb.compareTo(new BigDecimal("0.5"));
			if (result==1){ tVotoAbb=new BigDecimal("0.5"); }
			listVotoAbb.add(tVotoAbb.toString().replace(".", ","));
			
			
			hmParametri.put("grigliaTitoli", grigliaTitoli);
			hmParametri.put("intestazioneTitoli", intestazioneTitoli);
			hmParametri.put("totaliTitoli", totaliTitoli);
			
			
	    	
	    	return hmParametri;
	    }   

	 
	 
	 public  PdfPTable createBoxPunteggioTitoli(String etichetta,String testo,PdfWriter pdfWrite ) {
	    	// a table with three columns
	    	PdfPTable table = new PdfPTable(1);
	    	PdfPTable table2 = new PdfPTable(2);
	    	
	    try {
	        PdfPCell cell = new PdfPCell();
	        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
	        //w_etichetta.add(w_testo);
	        PdfContentByte canvas = pdfWrite.getDirectContent();
	        w_etichetta.setAlignment(Element.ALIGN_LEFT);
	        cell.addElement(w_etichetta); 
	        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
	        table.addCell(cell);
	        
	        PdfPCell cell2 = new PdfPCell();
	        PdfPCell cell3 = new PdfPCell();
	        PdfPCell cell4 = new PdfPCell();
	        PdfPCell cell5 = new PdfPCell();
	        PdfPCell cell6 = new PdfPCell();
	        PdfPCell cell7 = new PdfPCell();
	        PdfPCell cell8 = new PdfPCell();
	        PdfPCell cell9 = new PdfPCell();
	        PdfPCell cell10 = new PdfPCell();
	        PdfPCell cell11 = new PdfPCell();
	        PdfPCell cell12 = new PdfPCell();
	        PdfPCell cell13 = new PdfPCell();
	        PdfPCell cell14 = new PdfPCell();
	        PdfPCell cell15 = new PdfPCell();
	        PdfPCell cell16 = new PdfPCell();
	        PdfPCell cell17 = new PdfPCell();
	        PdfPCell cell18 = new PdfPCell();
	        PdfPCell cell19 = new PdfPCell();
	        PdfPCell cell20 = new PdfPCell();
	        
	        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
	        String[] ww_testi = testo.split("#");
	        Paragraph w_testo = null;
	        for (int idx=0;idx<ww_testi.length;idx++)
	        {
	            w_testo = new Paragraph(ww_testi[idx],fonts10_bold);
	            w_testo.setAlignment(Element.ALIGN_LEFT);
	            if (idx==0)
	            {
	                cell3.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell3.addElement(w_testo);
	            	
	            }
	            if (idx==1)
	            {
	            	cell4.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
	            	cell4.addElement(w_testo);
	                
	            } 
	            
	            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
	            w_testo.setAlignment(Element.ALIGN_LEFT);
	            if (idx==2)
	            {
	                cell5.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell5.addElement(w_testo);
	            }  
	            if (idx==3)
	            {
	                cell6.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell6.addElement(w_testo);
	            }  
	            
	            if (idx==4)
	            {
	            	cell7.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);      
	               	cell7.addElement(w_testo);
	            } 
	            if (idx==5)
	            {            	
	                cell8.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);     
	               	cell8.addElement(w_testo);
	            } 
	            
	            if (idx==6)
	            {
	            	cell9.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);   
	                cell9.addElement(w_testo);
	            }    
	            if (idx==7)
	            {
	                cell10.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell10.addElement(w_testo);
	            } 
	            if (idx==8)
	            {
	                cell11.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell11.addElement(w_testo);
	            	
	            }
	            if (idx==9)
	            {
	            	cell12.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
	            	cell12.addElement(w_testo);
	                
	            }            
	            if (idx==10)
	            {
	                cell13.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell13.addElement(w_testo);
	            }  
	            if (idx==11)
	            {
	                cell14.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell14.addElement(w_testo);
	            }  
	            
	            if (idx==12)
	            {
	            	cell15.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);      
	               	cell15.addElement(w_testo);
	            } 
	            if (idx==13)
	            {            	
	                cell16.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);     
	               	cell16.addElement(w_testo);
	            } 
	            
	            if (idx==14)
	            {
	            	cell17.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);   
	                cell17.addElement(w_testo);
	            }    
	            if (idx==15)
	            {
	                cell18.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell18.addElement(w_testo);
	            } 
	            if (idx==16)
	            {
	            	cell19.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);   
	                cell19.addElement(w_testo);
	            }    
	            if (idx==17)
	            {
	                cell20.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell20.addElement(w_testo);
	            } 
	          
	        
	        }
	    	table2.addCell(cell3);
	        table2.addCell(cell4);             	
	    	table2.addCell(cell5); 
	    	table2.addCell(cell6);  
	    	table2.addCell(cell7);
	    	table2.addCell(cell8);
	    	table2.addCell(cell9);
	    	table2.addCell(cell10);
	    	table2.addCell(cell11);
	        table2.addCell(cell12);             	
	    	table2.addCell(cell13); 
	    	table2.addCell(cell14);  
	    	table2.addCell(cell15);
	    	table2.addCell(cell16);
	    	table2.addCell(cell17);
	    	table2.addCell(cell18);
	    	table2.addCell(cell19);
	    	table2.addCell(cell20);
	    	cell2.addElement(table2); 
	        table.addCell(cell2);
	        table.setTotalWidth(550);
	        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
	 		} catch (Exception e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}
			if (nriga_posizione != 0)
			{	
				nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
			}
			else
			{	
				nriga_posizione = 790;
			}    		

	         return table;
	    }   
	 
	 public  PdfPTable createBoxPunteggioTitoliAssociata(String etichetta,String testo,PdfWriter pdfWrite ) {
	    	// a table with three columns
	    	PdfPTable table = new PdfPTable(1);
	    	PdfPTable table2 = new PdfPTable(3);
	    	
	    try {
	        PdfPCell cell = new PdfPCell();
	        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
	        //w_etichetta.add(w_testo);
	        PdfContentByte canvas = pdfWrite.getDirectContent();
	        w_etichetta.setAlignment(Element.ALIGN_LEFT);
	        cell.addElement(w_etichetta); 
	        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
	        table.addCell(cell);
	        
	        PdfPCell cell2 = new PdfPCell();
	        PdfPCell cell3 = new PdfPCell();
	        PdfPCell cell4 = new PdfPCell();
	        PdfPCell cell5 = new PdfPCell();
	        PdfPCell cell6 = new PdfPCell();
	        PdfPCell cell7 = new PdfPCell();
	        PdfPCell cell8 = new PdfPCell();
	        PdfPCell cell9 = new PdfPCell();
	        PdfPCell cell10 = new PdfPCell();
	        PdfPCell cell11 = new PdfPCell();
	        PdfPCell cell12 = new PdfPCell();
	        PdfPCell cell13 = new PdfPCell();
	        PdfPCell cell14 = new PdfPCell();
	        PdfPCell cell15 = new PdfPCell();
	        PdfPCell cell16 = new PdfPCell();
	        PdfPCell cell17 = new PdfPCell();
	        PdfPCell cell18 = new PdfPCell();
	        PdfPCell cell19 = new PdfPCell();
	        PdfPCell cell20 = new PdfPCell();
	        PdfPCell cell21 = new PdfPCell();
	        PdfPCell cell22 = new PdfPCell();
	        PdfPCell cell23 = new PdfPCell();
	        PdfPCell cell24 = new PdfPCell();
	        PdfPCell cell25 = new PdfPCell();
	        PdfPCell cell26 = new PdfPCell();
	        PdfPCell cell27 = new PdfPCell();
	        PdfPCell cell28= new PdfPCell();
	        PdfPCell cell29 = new PdfPCell();
	        
	        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
	        String[] ww_testi = testo.split("#");
	        Paragraph w_testo = null;
	        for (int idx=0;idx<ww_testi.length;idx++)
	        {
	            w_testo = new Paragraph(ww_testi[idx],fonts10_bold);
	            w_testo.setAlignment(Element.ALIGN_LEFT);
	            if (idx==0)
	            {
//	colonna titolo
	            	cell3.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);     
	            	cell3.addElement(w_testo);
	            	
	            }
	            if (idx==1)
	            {
//	 colonna punteggi dei titoli valutati
	            	cell4.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
	            	cell4.addElement(w_testo);
	                
	            } 
	            if (idx==2)
	            {
//	 colonna Punteggi massimi attribuibili a ciascuna categoria
	                cell5.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	                cell5.addElement(w_testo);
	            }

//	Valori collonne             
	            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
	            w_testo.setAlignment(Element.ALIGN_LEFT);
	              
	            if (idx==3)
	            {
	                cell6.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell6.addElement(w_testo);
	            }  
	            
	            if (idx==4)
	            {
	            	cell7.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);      
	            	cell7.addElement(w_testo);
	            } 
	            if (idx==5)
	            {            	
	                cell8.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);     
	               	cell8.addElement(w_testo);
	            } 
	            
	            if (idx==6)
	            {
	            	cell9.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);   
	            	cell9.addElement(w_testo);
	            }    
	            if (idx==7)
	            {
	                cell10.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	                cell10.addElement(w_testo);
	            } 
	            if (idx==8)
	            {
	                cell11.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell11.addElement(w_testo);
	            	
	            }
	            if (idx==9)
	            {
	            	cell12.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
	            	cell12.addElement(w_testo);
	                
	            }            
	            if (idx==10)
	            {
	                cell13.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell13.addElement(w_testo);
	            }  
	            if (idx==11)
	            {
	                cell14.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell14.addElement(w_testo);
	            }  
	            
	            if (idx==12)
	            {
	            	cell15.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);      
	               	cell15.addElement(w_testo);
	            } 
	            if (idx==13)
	            {            	
	                cell16.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);     
	               	cell16.addElement(w_testo);
	            } 
	            
	            if (idx==14)
	            {
	            	cell17.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);   
	                cell17.addElement(w_testo);
	            }    
	            if (idx==15)
	            {
	                cell18.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell18.addElement(w_testo);
	            } 
	            if (idx==16)
	            {
	            	cell19.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);   
	                cell19.addElement(w_testo);
	            }    
	            if (idx==17)
	            {
	                cell20.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell20.addElement(w_testo);
	            } 
	            if (idx==18)
	            {
	                cell21.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell21.addElement(w_testo);
	            } 
	            if (idx==19)
	            {
	                cell22.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell22.addElement(w_testo);
	            } 
	            if (idx==20)
	            {
	                cell23.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell23.addElement(w_testo);
	            } 
	            if (idx==21)
	            {
	                cell24.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell24.addElement(w_testo);
	            } 
	            if (idx==22)
	            {
	                cell25.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell25.addElement(w_testo);
	            } 
	            if (idx==23)
	            {
	                cell26.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell26.addElement(w_testo);
	            } 
	            if (idx==24)
	            {
	                cell27.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell27.addElement(w_testo);
	            } 
	            if (idx==25)
	            {
	                cell28.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell28.addElement(w_testo);
	            } 
	            if (idx==26)
	            {
	                cell29.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell29.addElement(w_testo);
	            } 
	          
	            
	        
	        }
	    	table2.addCell(cell3);
	        table2.addCell(cell4);             	
	    	table2.addCell(cell5); 
	    	table2.addCell(cell6);  
	    	table2.addCell(cell7);
	    	table2.addCell(cell8);
	    	table2.addCell(cell9);
	    	table2.addCell(cell10);
	    	table2.addCell(cell11);
	        table2.addCell(cell12);             	
	    	table2.addCell(cell13); 
	    	table2.addCell(cell14);  
	    	table2.addCell(cell15);
	    	table2.addCell(cell16);
	    	table2.addCell(cell17);
	    	table2.addCell(cell18);
	    	table2.addCell(cell19);
	    	table2.addCell(cell20);
	    	table2.addCell(cell21);
	    	table2.addCell(cell22);
	    	table2.addCell(cell23);
	    	table2.addCell(cell24);
	    	table2.addCell(cell25);
	    	table2.addCell(cell26);
	    	table2.addCell(cell27);
	    	table2.addCell(cell28);
	    	table2.addCell(cell29);
	    	cell2.addElement(table2); 
	        table.addCell(cell2);
	        table.setTotalWidth(550);
	        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
	 		} catch (Exception e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}
			if (nriga_posizione != 0)
			{	
				nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
			}
			else
			{	
				nriga_posizione = 790;
			}    		

	         return table;
	    }   

	 public  PdfPTable createBoxPunteggioTitoliMAX(String etichetta,String testo,PdfWriter pdfWrite ) {
	    	// a table with three columns
	    	PdfPTable table = new PdfPTable(1);
	    	PdfPTable table2 = new PdfPTable(3);
	    	
	    try {
	        PdfPCell cell = new PdfPCell();
	        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
	        //w_etichetta.add(w_testo);
	        PdfContentByte canvas = pdfWrite.getDirectContent();
	        w_etichetta.setAlignment(Element.ALIGN_LEFT);
	        cell.addElement(w_etichetta); 
	        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
	        table.addCell(cell);
	        
	        PdfPCell cell2 = new PdfPCell();
	        PdfPCell cell3 = new PdfPCell();
	        PdfPCell cell4 = new PdfPCell();
	        PdfPCell cell5 = new PdfPCell();
	        PdfPCell cell6 = new PdfPCell();
	        PdfPCell cell7 = new PdfPCell();
	        PdfPCell cell8 = new PdfPCell();
	        PdfPCell cell9 = new PdfPCell();
	        PdfPCell cell10 = new PdfPCell();
	        PdfPCell cell11 = new PdfPCell();
	        PdfPCell cell12 = new PdfPCell();
	        PdfPCell cell13 = new PdfPCell();
	        PdfPCell cell14 = new PdfPCell();
	        PdfPCell cell15 = new PdfPCell();
	        PdfPCell cell16 = new PdfPCell();
	        PdfPCell cell17 = new PdfPCell();
	        PdfPCell cell18 = new PdfPCell();
	        PdfPCell cell19 = new PdfPCell();
	        PdfPCell cell20 = new PdfPCell();
	        PdfPCell cell21 = new PdfPCell();
	        PdfPCell cell22 = new PdfPCell();
	        PdfPCell cell23 = new PdfPCell();
	        PdfPCell cell24 = new PdfPCell();
	        PdfPCell cell25 = new PdfPCell();
	        PdfPCell cell26 = new PdfPCell();
	        PdfPCell cell27 = new PdfPCell();
	        PdfPCell cell28 = new PdfPCell();
	        PdfPCell cell29 = new PdfPCell();
	        PdfPCell cell30 = new PdfPCell();
	        PdfPCell cell31 = new PdfPCell();
	        PdfPCell cell32 = new PdfPCell();
	        
	        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
	        String[] ww_testi = testo.split("#");
	        Paragraph w_testo = null;
	        for (int idx=0;idx<ww_testi.length;idx++)
	        {
	            w_testo = new Paragraph(ww_testi[idx],fonts10_bold);
	            w_testo.setAlignment(Element.ALIGN_LEFT);
	            if (idx==0)
	            {
	                cell3.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);     
	            	cell3.addElement(w_testo);
	            	
	            }
	            if (idx==1)
	            {
	            	cell4.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
	            	cell4.addElement(w_testo);
	                
	            }
	            if (idx==2)
	            {
	                cell5.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	                cell5.addElement(w_testo);
	            }
	            
	            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
	            w_testo.setAlignment(Element.ALIGN_LEFT);
	              
	            if (idx==3)
	            {
	                cell6.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell6.addElement(w_testo);
	            }  
	            
	            if (idx==4)
	            {
	            	cell7.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);      
	            	cell7.addElement(w_testo);
	            } 
	            if (idx==5)
	            {            	
	                cell8.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);     
	               	cell8.addElement(w_testo);
	            } 
	            
	            if (idx==6)
	            {
	            	cell9.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);   
	            	cell9.addElement(w_testo);
	            }    
	            if (idx==7)
	            {
	                cell10.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	                cell10.addElement(w_testo);
	            } 
	            if (idx==8)
	            {
	                cell11.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell11.addElement(w_testo);
	            	
	            }
	            if (idx==9)
	            {
	            	cell12.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
	            	cell12.addElement(w_testo);
	                
	            }            
	            if (idx==10)
	            {
	                cell13.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell13.addElement(w_testo);
	            }  
	            if (idx==11)
	            {
	                cell14.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell14.addElement(w_testo);
	            }  
	            
	            if (idx==12)
	            {
	            	cell15.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);      
	               	cell15.addElement(w_testo);
	            } 
	            if (idx==13)
	            {            	
	                cell16.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);     
	               	cell16.addElement(w_testo);
	            } 
	            
	            if (idx==14)
	            {
	            	cell17.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);   
	                cell17.addElement(w_testo);
	            }    
	            if (idx==15)
	            {
	                cell18.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell18.addElement(w_testo);
	            } 
	            if (idx==16)
	            {
	            	cell19.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);   
	                cell19.addElement(w_testo);
	            }    
	            if (idx==17)
	            {
	                cell20.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell20.addElement(w_testo);
	            } 
	            if (idx==18)
	            {
	                cell21.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell21.addElement(w_testo);
	            } 
	            if (idx==19)
	            {
	                cell22.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell22.addElement(w_testo);
	            }
	            if (idx==20)
	            {
	                cell23.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell23.addElement(w_testo);
	            }
	            if (idx==21)
	            {
	                cell24.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell24.addElement(w_testo);
	            }
	            if (idx==22)
	            {
	                cell25.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell25.addElement(w_testo);
	            }
	            if (idx==23)
	            {
	                cell26.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell26.addElement(w_testo);
	            }
	            if (idx==24)
	            {
	                cell27.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell27.addElement(w_testo);
	            }
	            if (idx==25)
	            {
	                cell28.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell28.addElement(w_testo);
	            }
	            if (idx==26)
	            {
	                cell29.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell29.addElement(w_testo);
	            }
	            if (idx==27)
	            {
	                cell30.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell30.addElement(w_testo);
	            }
	            if (idx==28)
	            {
	                cell31.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell31.addElement(w_testo);
	            }
	            if (idx==29)
	            {
	                cell32.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
	            	cell32.addElement(w_testo);
	            }
	        
	        }
	    	table2.addCell(cell3);
	        table2.addCell(cell4);             	
	    	table2.addCell(cell5); 
	    	table2.addCell(cell6);  
	    	table2.addCell(cell7);
	    	table2.addCell(cell8);
	    	table2.addCell(cell9);
	    	table2.addCell(cell10);
	    	table2.addCell(cell11);
	        table2.addCell(cell12);             	
	    	table2.addCell(cell13); 
	    	table2.addCell(cell14);  
	    	table2.addCell(cell15);
	    	table2.addCell(cell16);
	    	table2.addCell(cell17);
	    	table2.addCell(cell18);
	    	table2.addCell(cell19);
	    	table2.addCell(cell20);
	    	table2.addCell(cell21);
	    	table2.addCell(cell22);
	    	table2.addCell(cell23);
	    	table2.addCell(cell24);
	    	table2.addCell(cell25);
	    	table2.addCell(cell26);
	    	table2.addCell(cell27);
	    	table2.addCell(cell28);
	    	table2.addCell(cell29);
	    	table2.addCell(cell30);
	    	table2.addCell(cell31);
	    	table2.addCell(cell32);
	    	cell2.addElement(table2); 
	        table.addCell(cell2);
	        table.setTotalWidth(550);
	        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
	        saltoPaginaNote(pdfWrite);
	 		} catch (Exception e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}
			if (nriga_posizione != 0)
			{	
				nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
			}
			else
			{	
				nriga_posizione = 790;
			}    		

	         return table;
	    }   

	 public  PdfPTable createBoxGrigliaTitoli(String etichetta,HashMap<String, List<String>> grigliaTitoli, String[] intestazioneTitoli,PdfWriter pdfWrite ) {
	    	// a table with three columns
	    	PdfPTable table = new PdfPTable(1);
//	    	PdfPTable table2 = new PdfPTable(2);
	    	List<String> listTitoli =  grigliaTitoli.get(intestazioneTitoli[0]);
			List<String> listLaurea =  grigliaTitoli.get(intestazioneTitoli[2]);
			List<String> listSecondaLaurea =  grigliaTitoli.get(intestazioneTitoli[4]);
			List<String> listAltreLaure = grigliaTitoli.get(intestazioneTitoli[6]);
			List<String> listSpecializ = grigliaTitoli.get(intestazioneTitoli[8]);
			List<String> listPubblicaz = grigliaTitoli.get(intestazioneTitoli[10]);
			List<String> listIdonetaPrec = grigliaTitoli.get(intestazioneTitoli[12]);
			List<String> listIdonetaNaz = grigliaTitoli.get(intestazioneTitoli[14]);
			List<String> listVotoAbb = grigliaTitoli.get(intestazioneTitoli[16]);
	    	int colonne = listTitoli.size();
	    	PdfPTable table2 = new PdfPTable(colonne);
	    	

	    try {
	        PdfPCell cell = new PdfPCell();
	        Paragraph w_etichetta = new Paragraph(etichetta,fonts10_bold);
	        //w_etichetta.add(w_testo);
	        PdfContentByte canvas = pdfWrite.getDirectContent();
	        w_etichetta.setAlignment(Element.ALIGN_LEFT);
	        cell.addElement(w_etichetta); 
	        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
	        table.addCell(cell);
	        
	        PdfPCell cell2 = new PdfPCell();
	        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
	        Paragraph w_testo = null;

//"Titoli", 
	        for (String element : listTitoli) {
	        	w_testo = new Paragraph(element,fonts8_bold);
	        	int el = listTitoli.indexOf(element);

	        	PdfPCell cellSingol = new PdfPCell();
	        	cellSingol.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
         	cellSingol.addElement(w_testo);
         	table2.addCell(cellSingol);
			}

//"A-Laurea principale"
	        for (String element : listLaurea) {
	        	int el = listLaurea.indexOf(element);
             w_testo = new Paragraph(element,fonts8_normal);
             
	        	PdfPCell cellSingol = new PdfPCell();
	        	cellSingol.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
         	cellSingol.addElement(w_testo);
         	table2.addCell(cellSingol);
			}

//"D-Seconda laurea in farmacia o CTF"
	        for (String element : listSecondaLaurea) {
	        	int el = listSecondaLaurea.indexOf(element);
	        	w_testo = new Paragraph(element,fonts8_normal);
	        	
	        	PdfPCell cellSingol = new PdfPCell();
	        	cellSingol.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
         	cellSingol.addElement(w_testo);
         	table2.addCell(cellSingol);
			}
	        
//"B-Altre Lauree"
	        for (String element : listAltreLaure) {
	        	int el = listAltreLaure.indexOf(element);
	        	w_testo = new Paragraph(element,fonts8_normal);
	        
	        	PdfPCell cellSingol = new PdfPCell();
	        	cellSingol.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
         	cellSingol.addElement(w_testo);
         	table2.addCell(cellSingol);
			}
	       
//"C-Specializzazioni-Borse di studio o di ricerca"
	        for (String element : listSpecializ) {
	        	int el = listSpecializ.indexOf(element);
	        	w_testo = new Paragraph(element,fonts8_normal);
     
	        	PdfPCell cellSingol = new PdfPCell();
	        	cellSingol.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
         	cellSingol.addElement(w_testo);
         	table2.addCell(cellSingol);
			}
	        
//"E-Pubblicazioni Scientifiche"
	        for (String element : listPubblicaz) {
	        	int el = listPubblicaz.indexOf(element);
	        	w_testo = new Paragraph(element,fonts8_normal);
     
	        	PdfPCell cellSingol = new PdfPCell();
	        	cellSingol.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
         	cellSingol.addElement(w_testo);
         	table2.addCell(cellSingol);
			}
	       
//"F-Idoneit� precedente concorso"
	        for (String element : listIdonetaPrec) {
	        	int el = listIdonetaPrec.indexOf(element);
	        	w_testo = new Paragraph(element,fonts8_normal);
 
	        	PdfPCell cellSingol = new PdfPCell();
	        	cellSingol.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
         	cellSingol.addElement(w_testo);
         	table2.addCell(cellSingol);
			}
	        
//"G-Idoneit� nazionale farmacista dirigente"
	        for (String element : listIdonetaNaz) {
	        	int el = listIdonetaNaz.indexOf(element);
	        	w_testo = new Paragraph(element,fonts8_normal);
     
	        	PdfPCell cellSingol = new PdfPCell();
	        	cellSingol.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
         	cellSingol.addElement(w_testo);
         	table2.addCell(cellSingol);
			}

//"H-Voto di abilitaz0069one e corsi di aggiornamento"
	        for (String element : listVotoAbb) {
	        	int el = listVotoAbb.indexOf(element);
	        	w_testo = new Paragraph(element,fonts8_normal);
     
	        	PdfPCell cellSingol = new PdfPCell();
	        	cellSingol.setBorder(Rectangle.TOP+Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
         	cellSingol.addElement(w_testo);
         	table2.addCell(cellSingol);
			}

	        cell2.addElement(table2); 
	        table.addCell(cell2);
	        table.setTotalWidth(550);
	        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
	 		} catch (Exception e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}
			if (nriga_posizione != 0)
			{	
				nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
			}
			else
			{	
				nriga_posizione = 790;
			}    		

	         return table;
	    }   
	 
	 
	 
	 public String setTextParamatriDichiarazione(String testo)
	    {
	    	testo = testo.replace("<cognome>",getEntityPDFRiepilogoValutazione().getReferente());
	    	testo = testo.replace("<nome>",getEntityPDFRiepilogoValutazione().getReferente());
	    	
	    	
	    	return testo;
	    }
	    
	 
	 public  PdfPTable createBoxSecondaDichiarazione(String testo,PdfWriter pdfWrite ) {
	    	
	    	PdfPTable table = new PdfPTable(1);
	    	
	    try {
	       PdfPCell cell = new PdfPCell();
	       
	       Paragraph w_testo = new Paragraph(testo,fonts12_bold);
	       PdfContentByte canvas = pdfWrite.getDirectContent();
	       w_testo.setAlignment(Element.ALIGN_LEFT);
	       
	       cell.addElement(w_testo); 
	       table.addCell(cell);
	       
	       table.setTotalWidth(550);
	       table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
	       saltoPaginaUltimo(table,pdfWrite);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   	if (nriga_posizione != 0)
		   	{	
		   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		   	}
		   	else
		   	{	
		   		nriga_posizione = 790;
		   	}      
	    	
	        return table;
	    }
	 
	 
	 
	   
    
    public  PdfPTable createBoxHeaderText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.NO_BORDER);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        cell2.setBorder(Rectangle.NO_BORDER);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts6_italic);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            }  
            if (idx==3)
            {
                cell6.setPaddingLeft(-50);
                cell6.setColspan(2);
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }            
        }
    	table2.addCell(cell3);
    	table2.addCell(cell4);
    	table2.addCell(cell5);
    	table2.addCell(cell6);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
         return table;
    }  
    
    public  PdfPTable createBoxLabelColumn(String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(5);
    	int[] widths = {15, 25, 25, 15, 30};
//    	int[] widths = {15, 25, 30, 15, 17};

    	
    	
    try {
        PdfPCell cell = new PdfPCell();
        PdfContentByte canvas = pdfWrite.getDirectContent();
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        Paragraph w_testo = null;
        w_testo = new Paragraph("COGNOME",fonts10_bold);
	    w_testo.setAlignment(Element.ALIGN_LEFT);  

        cell3.setPaddingLeft(-50);
        cell3.setBorder(Rectangle.NO_BORDER);            	
        cell3.addElement(w_testo);


        w_testo = new Paragraph("NOME",fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  

        cell4.setBorder(Rectangle.NO_BORDER);            	
        cell4.addElement(w_testo);

        w_testo = new Paragraph("CODICE FISCALE",fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  
            	

        cell5.setBorder(Rectangle.NO_BORDER);            	
        cell5.addElement(w_testo);


        w_testo = new Paragraph("DATA NASCITA",fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  
            	
         	
        cell6.setBorder(Rectangle.NO_BORDER);            	
        cell6.addElement(w_testo);

        w_testo = new Paragraph("LUOGO NASCITA",fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  
            	
         	
        cell7.setBorder(Rectangle.NO_BORDER);            	
        cell7.addElement(w_testo);
            	
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);
        table2.addCell(cell6);
        table2.addCell(cell7);  
        table2.setWidths(widths);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.completeRow();
        table.setTotalWidth(550);
        table.setLockedWidth(true);      
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);       
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		
    
         return table;
    } 
    
    public  String setTextParamatriIntestazione(String testo)
    {
    	
    	  
    	testo = testo.replace("<?-&1-?>", "\r\n" + ((getEntityPDFRiepilogoValutazione().getReferente()!=null)?"Referente: "+ getEntityPDFRiepilogoValutazione().getReferente()+" - ":"") +
    									 "Numero Protocollo: "+getEntityPDFRiepilogoValutazione().getNumeroProtocollo());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    public  String setTextParamatriOggetto(String testo, UtenteCandidaturaReg utente)
    {
    	
    	testo = testo.replace("<?-&1-?>", utente.getNomeUtente()+" "+utente.getCognomeUtente());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    public  String setTextParamatriHeader(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRiepilogoValutazione().getReferente());
//    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getDataInvio());
//    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getModoPartecipa());
//    	testo = testo.replace("<?-&4-?>", getEntityPDFRicevuta().getNumeroProtocollo());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    } 
    
    
    public  String setTextParamatriDatiEsperienza(String testo, RisultatiValutazioneEsperienze risultatiValutazioneEsperienze)
    {
    	testo = testo.replace("<?-&1-?>","");
    	testo = testo.replace("<?-&2-?>", "");
    	testo = testo.replace("<?-&3-?>","");
    	testo = testo.replace("<?-&4-?>", (risultatiValutazioneEsperienze.getVotoPrimi10Anni()==null)?"0":risultatiValutazioneEsperienze.getVotoPrimi10Anni());
    	testo = testo.replace("<?-&5-?>","");
    	testo = testo.replace("<?-&6-?>", (risultatiValutazioneEsperienze.getVotoSecondi10Anni()==null)?"0":risultatiValutazioneEsperienze.getVotoSecondi10Anni());
    	testo = testo.replace("<?-&7-?>","");
    	testo = testo.replace("<?-&8-?>", (risultatiValutazioneEsperienze.getVotoMaggiorazioneFormatted()==null)?"0":risultatiValutazioneEsperienze.getVotoMaggiorazioneFormatted());
    	
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }   
    
    public  PdfPTable createBoxDatiEsperienza(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();
        PdfPCell cell9 = new PdfPCell();
        PdfPCell cell10 = new PdfPCell();
        
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts10_bold);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
               
                cell3.setBorder(Rectangle.TOP +Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
            	
            	cell4.setBorder(Rectangle.TOP +Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
            	cell4.addElement(w_testo);
                
            }
            
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==2)
            {
               
                cell5.setBorder(Rectangle.TOP +Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
            	cell5.addElement(w_testo);
            	
            }
            if (idx==3)
            {
            	
            	cell6.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
            	cell6.addElement(w_testo);
                
            }   
            if (idx==4)
            {
               
                cell7.setBorder(Rectangle.TOP +Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
            	cell7.addElement(w_testo);
            	
            }
            if (idx==5)
            {
            	
            	cell8.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
            	cell8.addElement(w_testo);
                
            }          
            if (idx==6)
            {
            	
            	cell9.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
            	cell9.addElement(w_testo);
                
            }
            if (idx==7)
            {
            	
            	cell10.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
            	cell10.addElement(w_testo);
                
            }  
          

        }
    	table2.addCell(cell3);
        table2.addCell(cell4); 
        table2.addCell(cell5);
        table2.addCell(cell6);
        table2.addCell(cell7);
        table2.addCell(cell8);
        table2.addCell(cell9);
        table2.addCell(cell10);
    	cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPaginaNote(pdfWrite);	
//        if (countForPage==1){
//        	saltoPaginaNote(pdfWrite);	
//        	countForPage=0;
//        } else {
//        	if (utenteCorrente+1==ultimoUtente){
//        		saltoPaginaNote(pdfWrite);	
//        	}
//        }
  		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		

         return table;
    }    

    public  PdfPTable createBoxDatiNoEsperienza(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        w_testo = new Paragraph(ww_testi[0],fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);
               
          cell3.setBorder(Rectangle.TOP +Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);            	
          cell3.addElement(w_testo);

          table2.addCell(cell3);
    	cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        if (countForPage==2){
        	saltoPagina(table, pdfWrite);	
        	countForPage=0;
        } else {
        	if (utenteCorrente+1==ultimoUtente){
        		saltoPaginaNote(pdfWrite);	
        	}
        }
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		

         return table;
    }    

    
    
    public  String setTextParamatriFineRicevuta(String testo)
    {
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }    

    public  PdfPTable createBoxFineRicevutaText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.NO_BORDER);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        cell2.setBorder(Rectangle.NO_BORDER);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            if (idx==0)
            {
            	w_testo.setAlignment(Element.ALIGN_LEFT);  
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
            	w_testo.setAlignment(Element.ALIGN_LEFT);  
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            }   
        }
        table2.addCell(cell3);
        table2.addCell(cell4);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
         return table;
    }    
   
    
    
    
    public  Document creaRicevuta(PdfWriter pdfWrite)
    {
           
			try {
				java.io.File currentDir = new java.io.File("");
				
				String testo = "";
				
				if(seOggetto)
				{
										
					nriga_posizione = 800;
					testo = getBodyRicevuta().getProperty("intestazione").toUpperCase();

					testo = setTextParamatriIntestazione(testo);			
					createBoxOggettoText(testo,pdfWrite);
					
				}
				else
				{
					nriga_posizione = POS_RIGA_SALTO_PAGINA; 
					String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
					createBoxPaginazioneText("",w_testo,pdfWrite);
					nriga_posizione = 840;
					w_testo = getBodyRicevuta().getProperty("headerpagina");
					w_testo = setTextParamatriHeader(w_testo);
					nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
					nriga_posizione = 790;
				}
				
//riepilogo totali grenerali								
				testo = getBodyRicevuta().getProperty("punteggioTotale");  
				testo = setTextParamatriDatiInvio(testo);								
				createBoxDatiInvioText("TOTALE PUNTEGGIO PER CANDIDATURA \n",testo,pdfWrite); 
//Totali Max per Titolo		
//	Candidatura associa
				if (entityPDFRiepilogoValutazione.getReferente()!=null && !entityPDFRiepilogoValutazione.getReferente().equals("")){
					testo = getBodyRicevuta().getProperty("dettaglioValutazioneGeneraleM");    
					testo = setPunteggioTitoliMAX(testo);								
					createBoxPunteggioTitoliMAX("DETTAGLIO PUNTEGGI  MASSIMI ATTRIBUIBULI PER TITOLI DI STUDIO E CARRIERA DELLA CANDIDATURA\n",testo,pdfWrite); 
				}
				
				//ciclo per utenti appartenenti alla candidatura..
				
				countForPage=0;
				ultimoUtente = entityPDFRiepilogoValutazione.getListaUtentiTitoli().size();
				utenteCorrente=0;
				for(UtenteTitoli u : entityPDFRiepilogoValutazione.getListaUtentiTitoli()){
				    
					countForPage++;
					utenteCorrente= entityPDFRiepilogoValutazione.getListaUtentiTitoli().indexOf(u);
					
					testo = getBodyRicevuta().getProperty("dettaglioRiepilogo");   
					testo = setTextParamatriOggetto(testo, u.getUtente());
					createBoxNotaText("",testo,pdfWrite);
					
//					if (entityPDFRiepilogoValutazione.getReferente()!=null && !entityPDFRiepilogoValutazione.getReferente().equals("")){
////	Candidatura associa
						testo = getBodyRicevuta().getProperty("dettaglioValutazioneCandidatoAssociato");    
						testo = setTextParamatriPunteggioTitoliAssociati(testo, u.getTitoli());								
						createBoxPunteggioTitoliAssociata("DETTAGLIO PUNTEGGI PER TITOLI DI STUDIO E CARRIERA DEL CANDIDATO\n",testo,pdfWrite); 
//					} else{
////	Candidatura Singola 
//						testo = getBodyRicevuta().getProperty("dettagliovalutazioneCandidato");    
//						testo = setTextParamatriPunteggioTitoli(testo, u.getTitoli());								
//						createBoxPunteggioTitoli("DETTAGLIO VALUTAZIONE TITOLI CANDIDATO\n",testo,pdfWrite);
//					}
					
					if (entityPDFRiepilogoValutazione.getListaUtentiEsperienza()!=null && entityPDFRiepilogoValutazione.getListaUtentiEsperienza().size()>0){
						String esperienzeTrovate= "NO";
						for (UtenteEspProf utenteEspProf :entityPDFRiepilogoValutazione.getListaUtentiEsperienza()){
							if(u.getUtente().getIdUtente().equals(utenteEspProf.getUtente().getIdUtente())){
								testo = getBodyRicevuta().getProperty("dettaglioEsperienze");    //EX DATI ANAGRAFICI  --> � LA TABELLA DI DETTAGLIO DEL CANDIDATO
								testo = setTextParamatriDatiEsperienza(testo, utenteEspProf.getRisultato());
								esperienzeTrovate= "SI";
							}
						}												
						if (esperienzeTrovate.equalsIgnoreCase("SI")){
							createBoxDatiEsperienza("DETTAGLIO PUNTEGGI  ESPERIENZE PROFESSIONALI CANDIDATO\n",testo,pdfWrite); 
						} else {
							createBoxDatiNoEsperienza("DETTAGLIO PUNTEGGI  ESPERIENZE PROFESSIONALI CANDIDATO  : Nessuna\n","Nessuna", pdfWrite); 
						}
					} else {
						createBoxDatiNoEsperienza("DETTAGLIO PUNTEGGI  ESPERIENZE PROFESSIONALI CANDIDATO  : Nessuna\n","Nessuna", pdfWrite); 
					}
					
				}
				
//	Area note      
				testo = getBodyRicevuta().getProperty("noteCandidatura");  
				testo = setTextParamatriNote(testo);								
//				testo = setTextParamatriDatiInvio(testo, entityPDFRiepilogoValutazione.getNote());	
				String[] ww_testi_riga = testo.split("\r\n");
				List<String> listRiga = new ArrayList<String>();
		        conta =0;
		        int charMaxRiga =100;
		        int charBlocco=0;
		        int rowNumber=0;
		        int rowCountByte = 0;
		        int rowCountMaxByte= 3400;
		        for (int idx=0;idx<ww_testi_riga.length;idx++){
//		    		conta++;
		        	rowCountByte = rowCountByte + ww_testi_riga[idx].length();
		        	charBlocco = ww_testi_riga[idx].length();
		    		if(charBlocco>0){
			    		rowNumber= charBlocco / charMaxRiga;
						int remainderInt= 0;
						    remainderInt = ww_testi_riga[idx].length() % charMaxRiga;
						if (remainderInt>0){
							rowNumber++;
						}
		    		} else {
		    			rowNumber=1;
		    			rowCountByte = rowCountByte + charMaxRiga;
		    		}
					conta = conta + rowNumber;
					if (rowCountByte==rowCountMaxByte || rowCountByte>rowCountMaxByte){
						conta= LIMITE_LISTA_NOTE_FROM_PAGE;
						rowCountByte=0;
					}
		    		listRiga.add(ww_testi_riga[idx]);
//		    		if ((conta%LIMITE_LISTA_NOTE_FROM_PAGE)==0){
		    		if (conta==LIMITE_LISTA_NOTE_FROM_PAGE||conta>LIMITE_LISTA_NOTE_FROM_PAGE){
			    		createBoxNoteCandidaturaText("NOTE: ",testo,listRiga,pdfWrite, "SI"); 
		    			listRiga.clear();
		    			countForPage=1;
		    			conta=0;
		    			rowCountByte=0;
					}
		    		
		        }
//		    	if ((conta%LIMITE_LISTA_NOTE_FROM_PAGE)!=0){
		    	if (listRiga.size()>0){
		        	createBoxNoteCandidaturaText("NOTE: ",testo,listRiga,pdfWrite, "NO"); 
	    			listRiga.clear();
	    			countForPage=1;
				} 
		    	
//Griglia riepilocativa solo per le associazioni per ora non si festisce
//				if (entityPDFRiepilogoValutazione.getReferente()!=null && !entityPDFRiepilogoValutazione.getReferente().equals("")){
//				
//					HashMap hmParmetri  = new HashMap();
//					hmParmetri = setTextParamatriGrigliaTotale(testo);
//					
//					HashMap<String, List<String>> grigliaTitoli = new HashMap<String, List<String>>();
//					grigliaTitoli= (HashMap<String, List<String>>) hmParmetri.get("grigliaTitoli");
//					
//					String[] intestazioneTitoli = null;
//					intestazioneTitoli = (String[]) hmParmetri.get("intestazioneTitoli");
//					
//					createBoxGrigliaTitoli("Riepilogo \n",grigliaTitoli,intestazioneTitoli,pdfWrite); 
//				}	

				
//Da Stampare a fine documento Fine documento 	
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);		

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				return documentoPDF;	
			}
    }
    
    public  Properties getBodyRicevuta() {
		return bodyRicevuta;
	}
	public void setBodyRicevuta(Properties bodyRicevuta) {
		this.bodyRicevuta = bodyRicevuta;
	}
	public  Date formatStrToDate(String strData)
	{
		Date date = null;
		if ( (strData!=null) && (!strData.equals("")))
		{
			try
			{
			 DateFormat formatter ; 
			 formatter = new SimpleDateFormat("dd-MM-yyyy");
			 date = (Date)formatter.parse(strData);  
			} catch (ParseException e)
			  {e.printStackTrace();}
			
		}
		return date; 
	}
	
	public  void creaRicevutaPDF() throws Exception{ 
		
//		
		  try 
		  { 
			  documentoPDF = new Document();				  
//		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;		 
			  creaRicevuta(pdfWrite);				   		
			  if (seOggetto)
			  {
				  seOggetto = false;
			  }
			  
			  totale_pagine_stampate = pdfWrite.getPageNumber();
			  documentoPDF.close();
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }
		  contaLepagine = false;
		  try 
		  { 
			 // File f = new File("c:\\output.pdf");
			 // f.delete();		  
			  documentoPDF = new Document();	
//		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));�
		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;	
			  seLabelColumn = true;
			  creaRicevuta(pdfWrite);
			 // salvaRicevutaPDF(ricevutaPDF);
			  if (seOggetto)
			  {
				  seOggetto = false;
			  }
			  if (seLabelColumn){
				  seLabelColumn = false;
			  }
			  documentoPDF.close();
			  if (getImgStampaElencoPDF()==null)
			  {
				  imgStampaElencoPDF = docBufferPDF.toByteArray();
			  } 
			  
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }		  
	
    }
    
    
    public  void downloadFile()
    {
    	byte[] pdfData = getImgStampaElencoPDF();
    	try
    	{
            FacesContext facesContext = FacesContext.getCurrentInstance(); 
            ExternalContext externalContext = facesContext.getExternalContext(); 
            HttpServletResponse response = (HttpServletResponse) externalContext.getResponse(); 
            ServletContext servletContext = (ServletContext) externalContext.getContext(); 
            response.reset(); 
            response.setContentType(servletContext.getMimeType("elencoCandidati.pdf")); 
            response.setContentLength((int) pdfData.length); 
            response.setHeader("Content-disposition", "attachment; filename=\"elencoCandidati.pdf\"");
            ByteArrayInputStream in = null;             
            BufferedInputStream input = null; 
            BufferedOutputStream output = null; 
            final int buffersize = (int) pdfData.length; 
            try 
            { 
            	in = new ByteArrayInputStream(pdfData);
            	input = new BufferedInputStream(in); 
            	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
            	byte[] buffer = new byte[buffersize]; 
            	for (int length; (length = input.read(buffer)) > 0;) 
            	{	 
            		output.write(buffer, 0, length); 
            	}            	
            } 
            finally 
            { 
            	if (input != null) 
            		try 
            		{ 
            			input.close(); 
            			output.close();
            		} 
            		catch (IOException e) 
            		{ 
            			e.printStackTrace(); 
            		} 
            } 
            facesContext.responseComplete();                             		
    	}
    	catch (IOException e)
    	{
    		e.printStackTrace();
    	}
    }
    
    
    public  void findUtenteCandidaDAO()
    {
    	uteCandi = new UtenteCandidaturaReg();
    	String IdUtente = "145";
    	try {
	    	candidaturaHome = new CandidaturaHome();
	    	uteCandi = candidaturaHome.findByUserId(IdUtente);
    	}
    	catch (Exception e) {
			e.printStackTrace();
		} 
    	System.out.println("ciccio");
    }
    
    
//    public Titoli popolaTitoliPerUtente (String idUtente, String idCandidatura){
//    	
//    	Titoli titoli = new Titoli();
//    	RequisitiMinimiReg requisitiMinimiReg = new RequisitiMinimiReg();
//		AltraLaureaReg altraLaureaReg = new AltraLaureaReg();
//		ArrayList<AltraLaureaBisReg> altraLaureaBisList;
//		AltraLaureaBisReg altraLaureaBisReg = new AltraLaureaBisReg();
//		ArrayList<AltroTitoloReg> altroTitoloList;
//		AltroTitoloReg altroTitoloReg = new AltroTitoloReg();
//		ArrayList<BorsaStudioReg> borsaStudioList;
//		BorsaStudioReg borsaStudioReg = new BorsaStudioReg();
//		ArrayList<CorsoAggiornamentoReg> corsoAggiornamentoList;
//		CorsoAggiornamentoReg corsoAggiornamentoReg = new CorsoAggiornamentoReg();
//		ArrayList<DottoratoReg> dottoratoList;
//		DottoratoReg dottoratoReg = new DottoratoReg();
//		ArrayList<IdoneitaReg> idoneitaList = new ArrayList<IdoneitaReg>();
//		IdoneitaReg idoneitaReg = new IdoneitaReg();
//		ArrayList<PubblicazioneReg> pubblicazioneList;
//		PubblicazioneReg pubblicazioneReg = new PubblicazioneReg();
//		ArrayList<SpecializzazioneReg> specializzazioneList;
//		SpecializzazioneReg specializzazioneReg = new SpecializzazioneReg();
//		RequisitiMinimiRegHome reqMinimiRegHome = new RequisitiMinimiRegHome();
//		AltraLaureaRegHome altraLaureaRegHome = new AltraLaureaRegHome();
//		AltraLaureaBisRegHome altraLaureaBisRegHome = new AltraLaureaBisRegHome();
//		AltroTitoloRegHome altroTitoloRegHome = new AltroTitoloRegHome();
//		BorsaStudioRegHome borsaStudioRegHome = new BorsaStudioRegHome();
//		CorsoAggiornamentoRegHome corsoAggiornamentoRegHome = new CorsoAggiornamentoRegHome();
//		DottoratoRegHome dottoratoRegHome = new DottoratoRegHome();
//		IdoneitaRegHome idoneitaRegHome = new IdoneitaRegHome();
//		PubblicazioneRegHome pubblicazioneRegHome = new PubblicazioneRegHome();
//		SpecializzazioneRegHome specializzazioneRegHome = new SpecializzazioneRegHome();
//		
//		try{
//		
//			titoli.setIdUtente(idUtente);
//			titoli.setIdCandidatura(idCandidatura);
//			
//			requisitiMinimiReg = reqMinimiRegHome.findById(idUtente);
//			titoli.setRequisitiMinimi(requisitiMinimiReg);
//			
//			altraLaureaReg = altraLaureaRegHome.findById(idUtente);
//			titoli.setAltraLaurea(altraLaureaReg);
//			
//			altraLaureaBisReg.setIdDomandaLaureaBis(idUtente);
//			altraLaureaBisList = (ArrayList<AltraLaureaBisReg>) altraLaureaBisRegHome.findByExample(altraLaureaBisReg);
//			titoli.setAltraLaureaBisList(altraLaureaBisList);
//			
//			altroTitoloReg.setIdDomandaTitolo(idUtente);
//			altroTitoloList = (ArrayList<AltroTitoloReg>) altroTitoloRegHome.findByExample(altroTitoloReg);
//		    titoli.setAltroTitoloList(altroTitoloList);
//		    
//		    borsaStudioReg.setIdDomandaBorsaStudio(idUtente);
//		    borsaStudioList = (ArrayList<BorsaStudioReg>) borsaStudioRegHome.findByExample(borsaStudioReg);
//			titoli.setBorsaStudioList(borsaStudioList);
//			
//			corsoAggiornamentoReg.setIdDomandaAgg(idUtente);
//			corsoAggiornamentoList = (ArrayList<CorsoAggiornamentoReg>) corsoAggiornamentoRegHome.findByExample(corsoAggiornamentoReg);
//			titoli.setCorsoAggiornamentoList(corsoAggiornamentoList);
//			
//			dottoratoReg.setIdDomandaDottorato(idUtente);
//			dottoratoList = (ArrayList<DottoratoReg>) dottoratoRegHome.findByExample(dottoratoReg);
//			titoli.setDottoratoList(dottoratoList);
//			
//			idoneitaReg = idoneitaRegHome.findById(idUtente);
//			idoneitaList.add(idoneitaReg);
//			titoli.setIdoneitaList(idoneitaList);
//			
//			pubblicazioneReg.setIdDomandaPubbl(idUtente);
//			pubblicazioneList = (ArrayList<PubblicazioneReg>) pubblicazioneRegHome.findByExample(pubblicazioneReg);
//			titoli.setPubblicazioneList(pubblicazioneList);
//			
//			specializzazioneReg.setIdDomandaSpec(idUtente);
//			specializzazioneList = (ArrayList<SpecializzazioneReg>) specializzazioneRegHome.findByExample(specializzazioneReg);
//			titoli.setSpecializzazioneList(specializzazioneList);
//			
//			//-------------------------------------  valutazione esperienza  -------------------------------------------
//			
//			RisultatiValutazioneEsperienze risultato = new RisultatiValutazioneEsperienze();
//			HashMap hmRuoli= null;
//			
//			if (hmRuoli==null) hmRuoli= recuperaRuoli();
//			EsercizioProfReg  esercizioProfReg = new EsercizioProfReg(); 
//			EsercizioProfRegHome esercizioProfRegHome = new EsercizioProfRegHome();
//			List<EsercizioProfReg> listEsercizio = new ArrayList<EsercizioProfReg>();
//			esercizioProfReg.setIdDomandaEs(idUtente);
//			listEsercizio = esercizioProfRegHome.findByExample(esercizioProfReg);
//			ArrayList<EsperienzaOriginal> listEsp = new ArrayList<EsperienzaOriginal>();
//			
//			
//			//		ciclo per il calcolo delle esperienze professionali
//			for (EsercizioProfReg esercizio : listEsercizio) {
//				
//				EsperienzaOriginal espOr = new EsperienzaOriginal();
//			
//				String descRuolo = (String) hmRuoli.get(esercizio.getCodRuoloEs());
//				
//				String codiceCategoria =  descRuolo.substring(5, 6);
//				espOr.setCodiceCategoria(codiceCategoria);
//				
//				if(esercizio.getCodModalitaEs().equals("0"))
//					espOr.setCodiceModalita("P");
//				else
//					espOr.setCodiceModalita("F");
//				if(esercizio.getFlagFarmRurale().equals("Si"))
//					espOr.setRurale(true);
//				else
//					espOr.setRurale(false);
//				espOr.setDataInizio(esercizio.getDataInizioEs());
//				espOr.setDataFine(esercizio.getDataFineEs());
//				
//				String ruoloStringa =  descRuolo.substring(7,descRuolo.length() );
//				espOr.setRuolo(ruoloStringa);
//				
//				listEsp.add(espOr);
//				
//			
//			}
//			if(!listEsp.isEmpty()){
//	
//				//calcolo del punteggio delle esperienze professionali 			
//				try {
//					
//					risultato = com.accenture.punteggi.esperienze.CalcoloPunteggi.calcola(listEsp);
//					
//					titoli.setVotoPrimi10Anni(risultato.getVotoPrimi10Anni());
//					titoli.setVotoSecondi10Anni(risultato.getVotoSecondi10Anni());
//				} catch (Exception e) {
//					throw new GestioneErroriException("Simulazione calcolo errato");
//				}
//			
//			}
//			
//			
//		}
//		 catch (Exception e){
//			
//			
//		}
//		
//		return titoli;
//    }
//			
	
	
			

		
	private HashMap recuperaRuoli() throws GestioneErroriException{
		 List<Ruolo> ruoli;
		 HashMap hmRuoli= null;
		
		 ruoli = CaricaRuoli.getRuoli();
		 hmRuoli= new HashMap();
			
			for (int i = 0; i < ruoli.size(); i++) {
				Ruolo ruolo = new Ruolo();
				ruolo = ruoli.get(i);
				hmRuoli.put(ruolo.getCodice(), ruolo.getDescrizione());
			}
			
			return hmRuoli;
		}
	
	  public  void creaRicevutaPDFRecovery(String id_utente) throws Exception{ 
			
		
		  /*
		  entityPDFRicevuta = initUteCandRicev();
		  getListaEntityPDFRicevuta().add(entityPDFRicevuta);
		  getListaEntityPDFRicevuta().add(entityPDFRicevuta);
		  getListaEntityPDFRicevuta().add(entityPDFRicevuta);
		  */
		/* Obbligatorio chiamare due volte perche' 
		 * la prima volta simula per contare totale pagine
		 */
		  try 
		  { 
			 
			  //File f = new File("c:\\output.pdf");
			  //f.delete();		  
			  documentoPDF = new Document();				  
		  	  //PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;		 
			  int conta = 1;
//			  for (EntityPDFRicevuta w_entity : getEntityPDFRiepilogoValutazione())
//			  { 	
//				  setEntityPDFRiepilogoValutazione(w_entity);
				  if (entityPDFRiepilogoValutazione!=null)
				  {
//					  w_entity.setNumeroProtocollo(numero_protocollo_ricevuta);
					  creaRicevuta(pdfWrite);				   		
					  if (seOggetto)
					  {
						  seOggetto = false;
					  }
				  }	 
//				  if (conta < getListaEntityPDFRicevuta().size())
//				  {
//					  documentoPDF.newPage();
//					  pdfWrite.setPageEmpty(false);
//				  }  
//				  conta++;
//			  }
			  totale_pagine_stampate = pdfWrite.getPageNumber();
			  documentoPDF.close();
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }
		  contaLepagine = false;
//		  rigeneraNumeroProtocolloByIdUtente(id_utente);
//		  salvaRicevutaPDF(null);		 
		  ricevute = null;		  
		  try 
		  { 
			 // File f = new File("c:\\output.pdf");
			 // f.delete();		  
			  documentoPDF = new Document();	
		  	  //PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;		 
			  int conta = 1;
//			  for (EntityPDFRicevuta w_entity : getListaEntityPDFRicevuta())
//			  { 	
//				  setEntityPDFRicevuta(w_entity);
				  if (entityPDFRiepilogoValutazione!=null)
				  {
//					  w_entity.setNumeroProtocollo(numero_protocollo_ricevuta);
					  creaRicevuta(pdfWrite);				   		
					  if (seOggetto)
					  {
						  seOggetto = false;
					  }
				  }	 
//				  if (conta < getListaEntityPDFRicevuta().size())
//				  {
//					  documentoPDF.newPage();
//					  pdfWrite.setPageEmpty(false);
//				  }  
				  conta++;
//			  }			  
			  documentoPDF.close();
			  if (getImgRicevutaPDF()==null)
			  {
				  imgRicevutaPDF = docBufferPDF.toByteArray();
			  }
			
//			  salvaRicevutaPDF(imgRicevutaPDF);		
//			  ristampaRicevutaIdUtentePDFRecovery(id_utente);
//			  modificaRicevutaPDF(getImgRicevutaPDF());
			  
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }		  
	
  }
	  
	  public boolean ristampaRicevutaIdUtentePDFRecovery(String id_utente)
	   	{	
	   		boolean result = false;
			try
			{
				CandidaturaHome candidaturaDAO = new CandidaturaHome();
				UtenteCandidaturaReg utenteCandidatura = null;
				utenteCandidatura = candidaturaDAO.findByUserId(id_utente);
				RicevuteHome ricevuteDAO = new RicevuteHome();
				Ricevute ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
				ricevute = ricevuta;
			}
			catch (Exception e)
			{
				e.printStackTrace();
			} 		
	   		return result;
	   		
	   	}  
	  
	  public  boolean modificaRicevutaPDF(byte[] ricevutaPDF) throws Exception{
			boolean result = false;		
			
			try
			{
				RicevuteHome ricevuteDAO = new RicevuteHome();	        
		        ricevute.setContenutoFile(ricevutaPDF);	        
		        ricevuteDAO.modifyBLOB(ricevute);
		        result = true;
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			return result;

	 /*
	        session.save(avatar);
	 
	        //Get image from database
	        Avatar avatar2 = (Avatar)session.get(Avatar.class, avatar.getAvatarId());
	        byte[] bAvatar = avatar2.getImage();
	 
	        try{
	            FileOutputStream fos = new FileOutputStream("C:\\test.gif"); 
	            fos.write(bAvatar);
	            fos.close();
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	 
	        session.getTransaction().commit();		
			return result;
			*/
		}	
	  
	  public  boolean salvaRicevutaPDF(byte[] ricevutaPDF) throws Exception{
			boolean result = false;		
			
			try		
			{
				RicevuteHome ricevuteDAO = new RicevuteHome();
				id_ricevuta_inserito = "000";   //metti un id--> sequence
				ricevuteId = new RicevuteId();
				ricevuteId.setIdCandidatura("808"); 
				ricevuteId.setIdRicevuta(id_ricevuta_inserito);
				ricevuteId.setIdRegione("");
		        ricevute = new Ricevute();
		        ricevute.setId(ricevuteId);
		        ricevute.setContenutoFile(ricevutaPDF);
		        ricevute.setFlagInvio("N");
		        ricevute.setDataInvio(formatStrToDate(dateInvio));
		        ricevuteDAO.insertRicevute(ricevute);
//		        numero_protocollo_ricevuta = id_ricevuta_inserito + " - " + dateInvio +  " - " + "070";
		        result = true;
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			return result;

}
}