package com.accenture.CCFarm.PDFModulo;

import java.util.Date;

public class EntityCSVCandidati {

 
	   private String cognome;
	   private String nome;
	   private String codFiscale;
	   private String codFiscaleRiferimento;
	   private String modalitaCandidatura;
	   private Date   dataNasc;
	   private String dataNascString;
		   
	   private String luogoNasc;
	   private String regione;
	
	   
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCodFiscale() {
		return codFiscale;
	}
	public void setCodFiscale(String codFiscale) {
		this.codFiscale = codFiscale;
	}
	public String getCodFiscaleRiferimento() {
		return codFiscaleRiferimento;
	}
	public void setCodFiscaleRiferimento(String codFiscaleRiferimento) {
		this.codFiscaleRiferimento = codFiscaleRiferimento;
	}
	public String getModalitaCandidatura() {
		return modalitaCandidatura;
	}
	public void setModalitaCandidatura(String modalitaCandidatura) {
		this.modalitaCandidatura = modalitaCandidatura;
	}
	public Date getDataNasc() {
		return dataNasc;
	}
	public void setDataNasc(Date dataNasc) {
		this.dataNasc = dataNasc;
	}
	public String getLuogoNasc() {
		return luogoNasc;
	}
	public void setLuogoNasc(String luogoNasc) {
		this.luogoNasc = luogoNasc;
	}
	public String getRegione() {
		return regione;
	}
	public void setRegione(String regione) {
		this.regione = regione;
	}
	public String getDataNascString() {
		return dataNascString;
	}
	public void setDataNascString(String dataNascString) {
		this.dataNascString = dataNascString;
	}
	   
	   
	    
	   
	   

	
	   
}
