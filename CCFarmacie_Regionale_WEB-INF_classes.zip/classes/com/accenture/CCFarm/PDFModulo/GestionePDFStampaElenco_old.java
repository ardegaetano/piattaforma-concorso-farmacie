package com.accenture.CCFarm.PDFModulo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.UtenteReg;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.DAO.UtenteRegHome;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class GestionePDFStampaElenco_old {	

	final static Font fonts12_bold = new Font(FontFamily.HELVETICA, 12, Font.BOLD);
	final static Font fonts10_normal = new Font(FontFamily.HELVETICA, 10, Font.NORMAL);
	final static Font fonts10_bold = new Font(FontFamily.HELVETICA, 10, Font.BOLD);
	final static Font fonts6_italic = new Font(FontFamily.HELVETICA, 6, Font.BOLD + Font.ITALIC);
	final static Font fonts6_normal = new Font(FontFamily.HELVETICA, 6, Font.NORMAL);
	final static Font fonts8_normal = new Font(FontFamily.HELVETICA, 8, Font.NORMAL);
	final static Font fonts8_bold = new Font(FontFamily.HELVETICA, 8, Font.BOLD);
	
	private  String dateInvio = "";
	private byte[] imgStampaElencoPDF;
	private String idRegioneIntestazione;
	private static final int IMG_WIDTH = 100;
	private static final int IMG_HEIGHT = 100;
	private static final int LIMITE_SALTO_PAGINA = 120;
	private static final int POS_RIGA_SALTO_PAGINA = 25;
	public  int nriga_posizione = 840;
	private  Properties bodyRicevuta = new Properties();
	private  EntityPDFRicevuta entityPDFRicevuta = new EntityPDFRicevuta();
	public  List<EntityPDFRicevuta> listaEntityPDFRicevuta = new ArrayList<EntityPDFRicevuta>();
	public  int totale_pagine = 0;
	public  boolean contaLepagine = true;
	public  int totale_pagine_stampate = 0;
	public  boolean seOggetto = true;
	public  boolean seLabelColumn = true;
	private  Document documentoPDF = new Document();
	private  Regione regione = new Regione();
	private  RegioneHome regioneDAO = new RegioneHome();
	private  UtenteCandidaturaReg uteCandi = new UtenteCandidaturaReg();
	private  CandidaturaHome candidaturaHome = new CandidaturaHome();
	
	public byte[] getImgStampaElencoPDF() {
		return imgStampaElencoPDF;
	}

	public  void setImgStampaElencoPDF(byte[] imgStampaElencoPDF) {
		this.imgStampaElencoPDF = imgStampaElencoPDF;
	}

	public  List<EntityPDFRicevuta> getListaEntityPDFRicevuta() {
		return listaEntityPDFRicevuta;
	}

	public void setListaEntityPDFRicevuta(
			List<EntityPDFRicevuta> listaEntityPDFRicevuta) {
		this.listaEntityPDFRicevuta = listaEntityPDFRicevuta;
	}

	public  EntityPDFRicevuta getEntityPDFRicevuta() {
		return entityPDFRicevuta;
	}

	public String getDateInvio() {
		return dateInvio;
	}

	public void setDateInvio(String dateInvio) {
		this.dateInvio = dateInvio;
	}

	public int getNriga_posizione() {
		return nriga_posizione;
	}

	public void setNriga_posizione(int nriga_posizione) {
		this.nriga_posizione = nriga_posizione;
	}

	public int getTotale_pagine() {
		return totale_pagine;
	}

	public void setTotale_pagine(int totale_pagine) {
		this.totale_pagine = totale_pagine;
	}

	public boolean isContaLepagine() {
		return contaLepagine;
	}

	public void setContaLepagine(boolean contaLepagine) {
		this.contaLepagine = contaLepagine;
	}

	public int getTotale_pagine_stampate() {
		return totale_pagine_stampate;
	}

	public void setTotale_pagine_stampate(int totale_pagine_stampate) {
		this.totale_pagine_stampate = totale_pagine_stampate;
	}

	public boolean isSeOggetto() {
		return seOggetto;
	}

	public void setSeOggetto(boolean seOggetto) {
		this.seOggetto = seOggetto;
	}

	public Document getDocumentoPDF() {
		return documentoPDF;
	}

	public void setDocumentoPDF(Document documentoPDF) {
		this.documentoPDF = documentoPDF;
	}

	public Regione getRegione() {
		return regione;
	}

	public void setRegione(Regione regione) {
		this.regione = regione;
	}

	public RegioneHome getRegioneDAO() {
		return regioneDAO;
	}

	public void setRegioneDAO(RegioneHome regioneDAO) {
		this.regioneDAO = regioneDAO;
	}

	public UtenteCandidaturaReg getUteCandi() {
		return uteCandi;
	}

	public void setUteCandi(UtenteCandidaturaReg uteCandi) {
		this.uteCandi = uteCandi;
	}

	public CandidaturaHome getCandidaturaHome() {
		return candidaturaHome;
	}

	public void setCandidaturaHome(CandidaturaHome candidaturaHome) {
		this.candidaturaHome = candidaturaHome;
	}

	public static Font getFonts12Bold() {
		return fonts12_bold;
	}

	public static Font getFonts10Normal() {
		return fonts10_normal;
	}

	public static Font getFonts10Bold() {
		return fonts10_bold;
	}

	public static Font getFonts6Italic() {
		return fonts6_italic;
	}

	public static Font getFonts6Normal() {
		return fonts6_normal;
	}

	public static Font getFonts8Normal() {
		return fonts8_normal;
	}

	public static Font getFonts8Bold() {
		return fonts8_bold;
	}

	public static int getImgWidth() {
		return IMG_WIDTH;
	}

	public static int getImgHeight() {
		return IMG_HEIGHT;
	}

	public static int getLimiteSaltoPagina() {
		return LIMITE_SALTO_PAGINA;
	}

	public static int getPosRigaSaltoPagina() {
		return POS_RIGA_SALTO_PAGINA;
	}

	public void setEntityPDFRicevuta(EntityPDFRicevuta entityPDFRicevuta) {
		this.entityPDFRicevuta = entityPDFRicevuta;
	}
	

	public String getIdRegioneIntestazione() {
		return idRegioneIntestazione;
	}

	public void setIdRegioneIntestazione(String idRegioneIntestazione) {
		this.idRegioneIntestazione = idRegioneIntestazione;
	}

	public GestionePDFStampaElenco_old()  // Costruttore 
	{
	}
	
	/**
	 * @param args
	 */
	
     
    public  PdfPTable createBoxOggettoText(String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	
    try {
       PdfPCell cell = new PdfPCell();
       Paragraph w_testo = new Paragraph(testo,fonts12_bold);
       PdfContentByte canvas = pdfWrite.getDirectContent();
       w_testo.setAlignment(Element.ALIGN_CENTER);
       cell.addElement(w_testo); 
       table.addCell(cell);
       table.setTotalWidth(550);
       table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 20);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}      
    	
        return table;
    } 
    public boolean ristampaRicevutaIdUtentePDF(String id_utente)
   	{	
   		boolean result = false;
		try
		{
			CandidaturaHome candidaturaDAO = new CandidaturaHome();
			UtenteCandidaturaReg utenteCandidatura = null;
			utenteCandidatura = candidaturaDAO.findByUserId(id_utente);
			RicevuteHome ricevuteDAO = new RicevuteHome();
			Ricevute ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
			if (ricevuta!=null)
			{
				setImgStampaElencoPDF(ricevuta.getContenutoFile());
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 		
   		return result;
   		
   	}  
    
    public boolean caricaDatiDaUtentePerEntityPDF(String id_regione)
   	{	
    	
    	boolean result = false;
		try
		{   
			setIdRegioneIntestazione(id_regione);
			UtenteRegHome utenteHome = new UtenteRegHome();
			UtenteReg utente = new UtenteReg();
			utente.setCodRegUtente(id_regione);
			List<UtenteReg> listaUtente = new ArrayList<UtenteReg>();				
			listaUtente = utenteHome.findByElencoCandidati(id_regione);
//			listaUtente = utenteHome.findByExample(utente);
			for (UtenteReg w_utente : listaUtente)
			{
				initEntityPDFromEntityUtente(w_utente);
				getListaEntityPDFRicevuta().add(getEntityPDFRicevuta());
			}
			for (UtenteReg w_utente : listaUtente)
			{
				initEntityPDFromEntityUtente(w_utente);
				getListaEntityPDFRicevuta().add(getEntityPDFRicevuta());
			}
			for (UtenteReg w_utente : listaUtente)
			{
				initEntityPDFromEntityUtente(w_utente);
				getListaEntityPDFRicevuta().add(getEntityPDFRicevuta());
			}
			for (UtenteReg w_utente : listaUtente)
			{
				initEntityPDFromEntityUtente(w_utente);
				getListaEntityPDFRicevuta().add(getEntityPDFRicevuta());
			}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 		
   		return result;
   		
   	}     

	public static String formattaDataTOString(Date w_date, String formatOra)
	{
		Calendar cal = Calendar.getInstance();
		String result = "";
		if (w_date!=null)
		{
			try { 
				cal.setTime(w_date);
				// Set time fields to zero  
				cal.set(Calendar.HOUR_OF_DAY, 0);  
				cal.set(Calendar.MINUTE, 0);  
				cal.set(Calendar.SECOND, 0);  
				cal.set(Calendar.MILLISECOND, 0);	
				SimpleDateFormat formatterOut = null;
				if (formatOra!=null)
				{	
					formatterOut = new SimpleDateFormat("dd-MM-yyyy" + " " + formatOra);
				}
				else
				{	
					formatterOut = new SimpleDateFormat("dd-MM-yyyy");
				}
					
					  
				result = formatterOut.format(cal.getTime()); 
			}
			catch (Exception e)
			{}			

		}
		return result;

	}
    
    public  void initEntityPDFromEntityUtente(UtenteReg utente)
    {
    	try
    	 {
    		/* inizializzazione strutture di prelievo dati */
	    	entityPDFRicevuta = new EntityPDFRicevuta(); 
	    	entityPDFRicevuta.setCognome(utente.getCognomeUtente());
	    	entityPDFRicevuta.setNome(utente.getNomeUtente());
	    	entityPDFRicevuta.setCodFiscale(utente.getCodiceFiscaleUtente());
	    	entityPDFRicevuta.setDataNasc(utente.getDataNascitaUtente());
	    	entityPDFRicevuta.setLuogoNasc(utente.getLuogoNascitaUtente());
	    	
    	 }
		catch (Exception e)
		{
			e.printStackTrace();
		} 		    	
	}
    
    public  PdfPTable createBoxSecondaLaureaTextF(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();        
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setPaddingLeft(-50);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            	
            }
            if (idx==3)
            {
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }
            if (idx==4)
            {
                cell7.setPaddingLeft(-50);
                cell7.setBorder(Rectangle.NO_BORDER);            	
            	cell7.addElement(w_testo);
            	
            }
            if (idx==5)
            {
                cell8.setBorder(Rectangle.NO_BORDER);            	
            	cell8.addElement(w_testo);
            	
            }          
        }
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);
        table2.addCell(cell6);
        table2.addCell(cell7);
        table2.addCell(cell8);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPagina(table, pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}  
         return table;
    }     
    
      
    public  PdfPTable createBoxVuotoText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
        try {
            PdfPCell cell = new PdfPCell();
            Paragraph w_testo = new Paragraph(testo,fonts8_normal);
            PdfContentByte canvas = pdfWrite.getDirectContent();
            w_testo.setAlignment(Element.ALIGN_RIGHT);
            cell.addElement(w_testo);             
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);
            table.setTotalWidth(700);
            table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
     		} catch (Exception e) {
     			// TODO Auto-generated catch block
     			e.printStackTrace();
     		}
             return table;
    }    
    public  PdfPTable createBoxPaginazioneText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
        try {
            PdfPCell cell = new PdfPCell();
            Paragraph w_testo = new Paragraph(testo,fonts6_normal);
            PdfContentByte canvas = pdfWrite.getDirectContent();
            w_testo.setAlignment(Element.ALIGN_RIGHT);
            cell.addElement(w_testo);             
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);
            table.setTotalWidth(550);
            table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
     		} catch (Exception e) {
     			// TODO Auto-generated catch block
     			e.printStackTrace();
     		}
             return table;
    }
    
   
    public  PdfPTable createBoxElencoCandidati(PdfWriter pdfWrite ) {
    
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(5);
    	int[] widths = {15, 25, 30, 15, 15};
    try {
        PdfPCell cell = new PdfPCell();
        PdfContentByte canvas = pdfWrite.getDirectContent();
       
        PdfPCell cell2 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT + Rectangle.TOP);
        Paragraph w_testo = null;

        int saltoPag = 0;
        
        for (EntityPDFRicevuta idx_entity : getListaEntityPDFRicevuta())
        {
//        	for di entity nome cogno cf data
        	
        	PdfPCell cell3 = new PdfPCell();
            PdfPCell cell4 = new PdfPCell();
            PdfPCell cell5 = new PdfPCell();
            PdfPCell cell6 = new PdfPCell();
            PdfPCell cell7 = new PdfPCell();
          
           
            w_testo = new Paragraph(idx_entity.getCognome(),fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  

                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);

            	w_testo = new Paragraph(idx_entity.getNome(),fonts8_normal);
                w_testo.setAlignment(Element.ALIGN_LEFT);  

                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);

            	w_testo = new Paragraph(idx_entity.getCodFiscale(),fonts8_normal);
                w_testo.setAlignment(Element.ALIGN_LEFT);  
            	

                cell5.setBorder(Rectangle.NO_BORDER); 
                cell5.setNoWrap(false);
            	cell5.addElement(w_testo);

            	w_testo = new Paragraph(formattaDataTOString(idx_entity.getDataNasc(), ""),fonts8_normal);
                w_testo.setAlignment(Element.ALIGN_LEFT);  
            	
         	
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);

            	w_testo = new Paragraph(idx_entity.getLuogoNasc(),fonts8_normal);
                w_testo.setAlignment(Element.ALIGN_LEFT);  
            	
         	
                cell7.setBorder(Rectangle.NO_BORDER);            	
            	cell7.addElement(w_testo);
            	
            	table2.addCell(cell3);
                table2.addCell(cell4);
                table2.addCell(cell5);
                table2.addCell(cell6);
                table2.addCell(cell7);
                table2.setWidths(widths);
                
                saltoPag++;
//                if (saltoPag==10){
//                	saltoPag=0;
//                	cell2.addElement(table2); 
//                    table.addCell(cell2);
//                    table.setTotalWidth(550);
//                    table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
//                    saltoPagina(table2,pdfWrite);
//                }
                
                
                /*
                saltoPagina(table2,pdfWrite);
        
                if (nriga_posizione != 0)
            	{	
            		nriga_posizione = nriga_posizione - (int)(table2.getTotalHeight() + 5);
            	}
            	else
            	{	
            		nriga_posizione = 790;
            	} 
            	*/   
           
        }

        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        //saltoPagina(table,pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
    	if (nriga_posizione != 0)
    	{	
    		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
    	}
    	else
    	{	
    		nriga_posizione = 790;
    	}    
         return table;
    } 
    
    
   
    
       
    public  PdfPTable saltoPaginaForzata(PdfPTable table,PdfWriter pdfWrite,PdfContentByte canvas,PdfPCell cell2)
    {
    	if (
    				(LIMITE_SALTO_PAGINA >= (nriga_posizione - (int)table.getTotalHeight())) ||
    				((LIMITE_SALTO_PAGINA + 20) >= (nriga_posizione - (int)table.getTotalHeight()))
    			)	
    		{
    			table.setTotalWidth(550);
    			table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);
				documentoPDF.newPage();
				pdfWrite.setPageEmpty(false);
				nriga_posizione = 840;
//				w_testo = getBodyRicevuta().getProperty("headerpagina");
//				w_testo = setTextParamatriHeader(w_testo);
				w_testo="";
				nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
				table = null;	
    		}
    		return table;

    }
    
    
    
    public  void saltoPaginaUltimo(PdfPTable table,PdfWriter pdfWrite)
    {
    			nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);

    }    
    
    
    public  void saltoPagina(PdfPTable table,PdfWriter pdfWrite)
    {
    		if (LIMITE_SALTO_PAGINA >= (nriga_posizione - (int)table.getTotalHeight()))
    		{
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);
				documentoPDF.newPage();
				pdfWrite.setPageEmpty(false);
				nriga_posizione = 840;
//				w_testo = getBodyRicevuta().getProperty("headerpagina");
				w_testo = "";
				nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
				nriga_posizione = 0;
    		}

    }
    
    
       
    
    public  PdfPTable createBoxHeaderText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.NO_BORDER);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        cell2.setBorder(Rectangle.NO_BORDER);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts6_italic);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            }  
            if (idx==3)
            {
                cell6.setPaddingLeft(-50);
                cell6.setColspan(2);
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }            
        }
    	table2.addCell(cell3);
    	table2.addCell(cell4);
    	table2.addCell(cell5);
    	table2.addCell(cell6);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
         return table;
    }  
    
    public  PdfPTable createBoxLabelColumn(String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(5);
    	int[] widths = {15, 25, 30, 15, 17};

    	
    	
    try {
        PdfPCell cell = new PdfPCell();
        PdfContentByte canvas = pdfWrite.getDirectContent();
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        Paragraph w_testo = null;
        w_testo = new Paragraph("COGNOME",fonts10_bold);
	    w_testo.setAlignment(Element.ALIGN_LEFT);  

        cell3.setPaddingLeft(-50);
        cell3.setBorder(Rectangle.NO_BORDER);            	
        cell3.addElement(w_testo);


        w_testo = new Paragraph("NOME",fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  

        cell4.setBorder(Rectangle.NO_BORDER);            	
        cell4.addElement(w_testo);

        w_testo = new Paragraph("C.FISCALE",fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  
            	

        cell5.setBorder(Rectangle.NO_BORDER);            	
        cell5.addElement(w_testo);


        w_testo = new Paragraph("DATA NASC",fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  
            	
         	
        cell6.setBorder(Rectangle.NO_BORDER);            	
        cell6.addElement(w_testo);

        w_testo = new Paragraph("LUOGO NASC",fonts10_bold);
        w_testo.setAlignment(Element.ALIGN_LEFT);  
            	
         	
        cell7.setBorder(Rectangle.NO_BORDER);            	
        cell7.addElement(w_testo);
            	
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);
        table2.addCell(cell6);
        table2.addCell(cell7);  
        table2.setWidths(widths);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.completeRow();
        table.setTotalWidth(550);
        table.setLockedWidth(true);      
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);       
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		
    
         return table;
    }     
    public  Document creaRicevuta(PdfWriter pdfWrite)
    {
    	       // Carica Logo Ministero
			//BufferedImage img = ImageIO.read(new FileInputStream(currentDir.getAbsolutePath() + "//WebContent//images//layout//logo_ministero.png"));
			try {
				java.io.File currentDir = new java.io.File("");
				/*
				Image img = null;
				img = Image.getInstance(currentDir.getAbsolutePath() + "//WebContent//images//layout//logo_ministero.png");
				img.setAlignment(Image.LEFT | Image.TEXTWRAP);
				img.setBorder(Image.BOX);
				img.setBorderWidth(0);      
				documento.add(img);
				*/	
				String testo = "";
								
				if (seOggetto)
				{
					nriga_posizione = 800;
					String intestazione="";
//					if (idRegioneIntestazione!=null){
//						Regione regione = new Regione();
//						regione.setCodReg(getIdRegioneIntestazione());
//						RegioneHome home = new RegioneHome();
//						regione= home.findById(getIdRegioneIntestazione());
//						if (idRegioneIntestazione.equals("041") || idRegioneIntestazione.equals("042")){
//							intestazione = "la "+regione.getDenominazioneReg();
//						} else{
//							intestazione = "la Regione "+regione.getDenominazioneReg();
//						}
//							
//					}
					testo = "Lista candidature per "+intestazione+" \n";
					createBoxOggettoText(testo,pdfWrite); 	 					
				}
				else
				{
					nriga_posizione = POS_RIGA_SALTO_PAGINA; 
					String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
					createBoxPaginazioneText("",w_testo,pdfWrite);
					nriga_posizione = 840;
					//w_testo = getBodyRicevuta().getProperty("headerpagina");
					w_testo = "";
					nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
					nriga_posizione = 790;
				}			
				nriga_posizione = 770;
				if (seLabelColumn)
				{
					createBoxLabelColumn("",pdfWrite); 	
					seLabelColumn = false;					
				}
				nriga_posizione = nriga_posizione - 10;
				createBoxElencoCandidati(pdfWrite);
					/* --- NUOVA PAGINA 5 PDF --*/	
				
				if (totale_pagine == 0)
				{					
					totale_pagine = (int)pdfWrite.getPageNumber();
				}	
				if (contaLepagine)
				{	
					totale_pagine_stampate = totale_pagine_stampate + totale_pagine;
				}
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				return documentoPDF;	
			}
    }
    
    public  Properties getBodyRicevuta() {
		return bodyRicevuta;
	}
	public void setBodyRicevuta(Properties bodyRicevuta) {
		this.bodyRicevuta = bodyRicevuta;
	}
	public  Date formatStrToDate(String strData)
	{
		Date date = null;
		if ( (strData!=null) && (!strData.equals("")))
		{
			try
			{
			 DateFormat formatter ; 
			 formatter = new SimpleDateFormat("dd-MM-yyyy");
			 date = (Date)formatter.parse(strData);  
			} catch (ParseException e)
			  {e.printStackTrace();}
			
		}
		return date; 
	}
	
	public  void creaRicevutaPDF() throws Exception{ 
		
//		
		  try 
		  { 
//			  documentoPDF = new Document();				  
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
		  	  //ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
		  	  //PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;		 
			  creaRicevuta(pdfWrite);				   		
			  if (seOggetto)
			  {
				  seOggetto = false;
			  }
			  
			  totale_pagine_stampate = pdfWrite.getPageNumber();
			  documentoPDF.close();
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }
		  contaLepagine = false;
		  try 
		  { 
			 // File f = new File("c:\\output.pdf");
			 // f.delete();		  
			  documentoPDF = new Document();	
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
//		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
//		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;	
			  seLabelColumn = true;
			  creaRicevuta(pdfWrite);				   		
			  if (seOggetto)
			  {
				  seOggetto = false;
			  }
			  if (seLabelColumn){
				  seLabelColumn = false;
			  }
			  documentoPDF.close();
//			  if (getImgStampaElencoPDF()==null)
//			  {
//				  imgStampaElencoPDF = docBufferPDF.toByteArray();
//			  } 
			  
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }		  
	
    }
    
    
    public  void downloadFile()
    {
    	byte[] pdfData = getImgStampaElencoPDF();
    	try
    	{
            FacesContext facesContext = FacesContext.getCurrentInstance(); 
            ExternalContext externalContext = facesContext.getExternalContext(); 
            HttpServletResponse response = (HttpServletResponse) externalContext.getResponse(); 
            ServletContext servletContext = (ServletContext) externalContext.getContext(); 
            response.reset(); 
            response.setContentType(servletContext.getMimeType("elencoCandidati.pdf")); 
            response.setContentLength((int) pdfData.length); 
            response.setHeader("Content-disposition", "attachment; filename=\"ricevutaDomanda.pdf\"");
            ByteArrayInputStream in = null;             
            BufferedInputStream input = null; 
            BufferedOutputStream output = null; 
            final int buffersize = (int) pdfData.length; 
            try 
            { 
            	in = new ByteArrayInputStream(pdfData);
            	input = new BufferedInputStream(in); 
            	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
            	byte[] buffer = new byte[buffersize]; 
            	for (int length; (length = input.read(buffer)) > 0;) 
            	{	 
            		output.write(buffer, 0, length); 
            	}            	
            } 
            finally 
            { 
            	if (input != null) 
            		try 
            		{ 
            			input.close(); 
            			output.close();
            		} 
            		catch (IOException e) 
            		{ 
            			e.printStackTrace(); 
            		} 
            } 
            facesContext.responseComplete();                             		
    	}
    	catch (IOException e)
    	{
    		e.printStackTrace();
    	}
    }
    
    
    public  void findUtenteCandidaDAO()
    {
    	uteCandi = new UtenteCandidaturaReg();
    	String IdUtente = "145";
    	try {
	    	candidaturaHome = new CandidaturaHome();
	    	uteCandi = candidaturaHome.findByUserId(IdUtente);
    	}
    	catch (Exception e) {
			e.printStackTrace();
		} 
    	System.out.println("ciccio");
    }
}
