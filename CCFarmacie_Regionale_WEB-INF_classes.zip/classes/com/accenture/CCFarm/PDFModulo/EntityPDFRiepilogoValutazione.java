package com.accenture.CCFarm.PDFModulo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.accenture.CCFarm.Bean.UtenteEspProf;
import com.accenture.CCFarm.Bean.UtenteTitoli;
import com.accenture.CCFarm.DAO.Titoli;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;


public class EntityPDFRiepilogoValutazione {

 //punteggio totale della candidatura
	//dati della candidatura

 private String referente;
 private String punteggioTotale;
 private String punteggioTotaleEsperienze;
 private String punteggioTotaleTitoli;
 private String numeroProtocollo;
 private String espPrimiAnni;
 private String espAnniSucc;
 private List<UtenteTitoli> listaUtentiTitoli;
 private List<UtenteEspProf> listaUtentiEsperienza;
 private String intestazione;
 private String note;

 
public String getEspPrimiAnni() {
	return espPrimiAnni;
}
public void setEspPrimiAnni(String espPrimiAnni) {
	this.espPrimiAnni = espPrimiAnni;
}
public String getEspAnniSucc() {
	return espAnniSucc;
}
public void setEspAnniSucc(String espAnniSucc) {
	this.espAnniSucc = espAnniSucc;
}
public String getIntestazione() {
	return intestazione;
}
public void setIntestazione(String intestazione) {
	this.intestazione = intestazione;
}
public String getReferente() {
	return referente;
}
public void setReferente(String referente) {
	this.referente = referente;
}
public String getPunteggioTotale() {
	return punteggioTotale;
}
public void setPunteggioTotale(String punteggioTotale) {
	this.punteggioTotale = punteggioTotale;
}
public String getPunteggioTotaleEsperienze() {
	return punteggioTotaleEsperienze;
}
public void setPunteggioTotaleEsperienze(String punteggioTotaleEsperienze) {
	this.punteggioTotaleEsperienze = punteggioTotaleEsperienze;
}
public String getPunteggioTotaleTitoli() {
	return punteggioTotaleTitoli;
}
public void setPunteggioTotaleTitoli(String punteggioTotaleTitoli) {
	this.punteggioTotaleTitoli = punteggioTotaleTitoli;
}
public String getNumeroProtocollo() {
	return numeroProtocollo;
}
public void setNumeroProtocollo(String numeroProtocollo) {
	this.numeroProtocollo = numeroProtocollo;
}
public List<UtenteTitoli> getListaUtentiTitoli() {
	return listaUtentiTitoli;
}
public void setListaUtentiTitoli(List<UtenteTitoli> listaUtentiTitoli) {
	this.listaUtentiTitoli = listaUtentiTitoli;
}
public List<UtenteEspProf> getListaUtentiEsperienza() {
	return listaUtentiEsperienza;
}
public void setListaUtentiEsperienza(List<UtenteEspProf> listaUtentiEsperienza) {
	this.listaUtentiEsperienza = listaUtentiEsperienza;
}
public String getNote() {
	return note;
}
public void setNote(String note) {
	this.note = note;
}

	   
	   
}
