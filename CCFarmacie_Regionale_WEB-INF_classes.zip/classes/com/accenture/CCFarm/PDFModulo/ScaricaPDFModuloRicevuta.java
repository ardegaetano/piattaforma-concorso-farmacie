package com.accenture.CCFarm.PDFModulo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;


public class ScaricaPDFModuloRicevuta {	

	private byte[] imgRicevutaPDF;


    public boolean ristampaRiRcevutaIdUtentePDF(String id_utente, String tipo_ricevuta) throws GestioneErroriException
   	{	
   		boolean result = false;
		try
		{
			CandidaturaHome candidaturaDAO = new CandidaturaHome();
			UtenteCandidaturaReg utenteCandidatura = null;
			utenteCandidatura = candidaturaDAO.findByUserId(id_utente);
			RicevuteHome ricevuteDAO = new RicevuteHome();
			Ricevute ricevuta = ricevuteDAO.findByCandidaturaTipoRicevuta(utenteCandidatura.getCandidatura().getIdCandidatura(), tipo_ricevuta);
			if (ricevuta!=null)
			{
				setImgRicevutaPDF(ricevuta.getContenutoFile());
			}
		}
		catch (Exception e)
		{
			throw new GestioneErroriException("CandidaturaHome - findByUserId: errore nell' findByUserId della candidatura:");
//			e.printStackTrace();
		} 		
   		return result;
   		
   	}  
    
    
    
    public  void downloadFile()
    {
    	byte[] pdfData = getImgRicevutaPDF();
    	try
    	{
            FacesContext facesContext = FacesContext.getCurrentInstance(); 
            ExternalContext externalContext = facesContext.getExternalContext(); 
            HttpServletResponse response = (HttpServletResponse) externalContext.getResponse(); 
            ServletContext servletContext = (ServletContext) externalContext.getContext(); 
            response.reset(); 
            response.setContentType(servletContext.getMimeType("ricevutaDomanda.pdf")); 
            response.setContentLength((int) pdfData.length); 
            response.setHeader("Content-disposition", "attachment; filename=\"ricevutaDomanda.pdf\"");
            ByteArrayInputStream in = null;             
            BufferedInputStream input = null; 
            BufferedOutputStream output = null; 
            final int buffersize = (int) pdfData.length; 
            try 
            { 
            	in = new ByteArrayInputStream(pdfData);
            	input = new BufferedInputStream(in); 
            	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
            	byte[] buffer = new byte[buffersize]; 
            	for (int length; (length = input.read(buffer)) > 0;) 
            	{	 
            		output.write(buffer, 0, length); 
            	}            	
            } 
            finally 
            { 
            	if (input != null) 
            		try 
            		{ 
            			input.close(); 
            			output.close();
            		} 
            		catch (IOException e) 
            		{ 
            			e.printStackTrace(); 
            		} 
            } 
            facesContext.responseComplete();                             		
    	}
    	catch (IOException e)
    	{
    		e.printStackTrace();
    	}
    }



	public byte[] getImgRicevutaPDF() {
		return imgRicevutaPDF;
	}



	public void setImgRicevutaPDF(byte[] imgRicevutaPDF) {
		this.imgRicevutaPDF = imgRicevutaPDF;
	}
    

}
