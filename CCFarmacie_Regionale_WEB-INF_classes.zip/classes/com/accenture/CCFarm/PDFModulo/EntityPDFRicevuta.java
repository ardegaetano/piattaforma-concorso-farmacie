package com.accenture.CCFarm.PDFModulo;

import java.util.Date;

public class EntityPDFRicevuta {

 
	   private String cognome;
	   private String nome;
	   private String codFiscale;
	   private Date   dataNasc;
	   private String luogoNasc;
	   
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCodFiscale() {
		return codFiscale;
	}
	public void setCodFiscale(String codFiscale) {
		this.codFiscale = codFiscale;
	}
	public Date getDataNasc() {
		return dataNasc;
	}
	public void setDataNasc(Date dataNasc) {
		this.dataNasc = dataNasc;
	}
	public String getLuogoNasc() {
		return luogoNasc;
	}
	public void setLuogoNasc(String luogoNasc) {
		this.luogoNasc = luogoNasc;
	}
	   	
	   
	   
	   
}
