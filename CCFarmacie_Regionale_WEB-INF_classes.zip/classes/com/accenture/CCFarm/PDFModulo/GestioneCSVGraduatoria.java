package com.accenture.CCFarm.PDFModulo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import com.accenture.CCFarm.Bean.UtenteBean;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.UtenteReg;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.DAO.UtenteRegHome;
import com.accenture.CCFarm.action.RicercaCandidatoAction;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class GestioneCSVGraduatoria {	
	
	private  String dateInvio = "";
	private byte[] imgStampaElencoPDF;
	private String idRegioneIntestazione;
	//	private  EntityPDFRicevuta entityPDFRicevuta = new EntityPDFRicevuta();
//	public  List<EntityPDFRicevuta> listaEntityPDFRicevuta = new ArrayList<EntityPDFRicevuta>();
	private EntityCSVGraduatoria entityCsvGraduatoria= new EntityCSVGraduatoria();
	private List<EntityCSVGraduatoria> listaEntityCSVGraduatoria = new ArrayList<EntityCSVGraduatoria>();
	private String recordAll;
	
	
	public GestioneCSVGraduatoria()  // Costruttore 
	{
	}
	public byte[] getImgStampaElencoPDF() {
		return imgStampaElencoPDF;
	}

	public  void setImgStampaElencoPDF(byte[] imgStampaElencoPDF) {
		this.imgStampaElencoPDF = imgStampaElencoPDF;
	}

	public List<EntityCSVGraduatoria> getListaEntityCSVGraduatoria() {
		return listaEntityCSVGraduatoria;
	}
	public void setListaEntityCSVGraduatoria(
			List<EntityCSVGraduatoria> listaEntityCSVGraduatoria) {
		this.listaEntityCSVGraduatoria = listaEntityCSVGraduatoria;
	}
	public String getDateInvio() {
		return dateInvio;
	}

	public void setDateInvio(String dateInvio) {
		this.dateInvio = dateInvio;
	}

	public EntityCSVGraduatoria getEntityCsvGraduatoria() {
		return entityCsvGraduatoria;
	}
	public void setEntityCsvGraduatoria(EntityCSVGraduatoria entityCsvGraduatoria) {
		this.entityCsvGraduatoria = entityCsvGraduatoria;
	}
	public String getRecordAll() {
		return recordAll;
	}
	public void setRecordAll(String recordAll) {
		this.recordAll = recordAll;
	}
    
	 public String getIdRegioneIntestazione() {
		return idRegioneIntestazione;
	}
	public void setIdRegioneIntestazione(String idRegioneIntestazione) {
		this.idRegioneIntestazione = idRegioneIntestazione;
	}
	public boolean caricaDatiDaGraduatoriaEntityCSV(String id_regione)
	   	{	
	    	
	    	boolean result = false;
			try
			{   
				setIdRegioneIntestazione(id_regione);
				Graduatoria graduatoria = new Graduatoria();
				graduatoria.setCodRegione(id_regione);
				List<Graduatoria> listaGrad = new ArrayList<Graduatoria>();
				GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
				int maxElement = graduatoriaHome.searchCount(id_regione);
				listaGrad = graduatoriaHome.findLazyListGradJoinGradDefin(id_regione, 0, maxElement+1);
				for (Graduatoria w_graduatoria : listaGrad)
				{
					initEntityCSVfromEntityUtente(w_graduatoria);
					getListaEntityCSVGraduatoria().add(getEntityCsvGraduatoria());
				}
				
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			} 		
	   		return result;
	   		
	   	}     
	
	
    


	 
	 public  void initEntityCSVfromEntityUtente(Graduatoria  graduatoria)
	    {
	    	try
	    	 {
	    		entityCsvGraduatoria = new EntityCSVGraduatoria();
	    		int posizione = 0;
	    		if (graduatoria.getIndiceTotale()!=null){
		    		posizione= graduatoria.getIndiceTotale().intValue();
		    	}
	    		
	    		entityCsvGraduatoria.setPosizione(""+posizione);
	    		String exaequo = graduatoria.getExAequo();
	    		entityCsvGraduatoria.setExAequo(exaequo==null ? "": "*");
	    		entityCsvGraduatoria.setCognome(graduatoria.getCognome());
	    		entityCsvGraduatoria.setNome(graduatoria.getNome());
	    		entityCsvGraduatoria.setNumeroProtocollo(graduatoria.getNumeroProtocollo());
		    	String punteggio = ""+graduatoria.getPunteggio();
		    	entityCsvGraduatoria.setPunteggio(punteggio.replace(".", ","));
		    	String etaMedia = ""+graduatoria.getEtaMedia();
		    	entityCsvGraduatoria.setEtaMedia(etaMedia.replace(".", ","));
		    	
	    		
	    		
		    	
	    	 }
			catch (Exception e)
			{
				e.printStackTrace();
			} 		    	
		}
	    
	    

   
    public  Document creaRicevuta()
    {
		return null;
    	   
    }
    
    
	
	public  void creaFileCSV() throws Exception{ 

		recordAll="";
		recordAll="EXAEQUO"+"|"+
				  "POSIZIONE"+"|"+  
				  "NUMERO PROTOCOLLO"+"|"+
				  "COGNOME"+"|"+
			      "NOME"+"|"+
			      "PUNTEGGIO"+"|"+
			      "ETA MEDIA"+
				 " \r\n ";;
		for (int i = 0; i < listaEntityCSVGraduatoria.size(); i++) {
			EntityCSVGraduatoria graduatoria = new EntityCSVGraduatoria();
			graduatoria= listaEntityCSVGraduatoria.get(i);
			
			recordAll += graduatoria.getExAequo().trim().toUpperCase()+"|"+
						 graduatoria.getPosizione().trim().toUpperCase()+"|"+
					     graduatoria.getNumeroProtocollo().trim().toUpperCase()+"|"+
					     graduatoria.getCognome().trim().toUpperCase()+"|"+
					     graduatoria.getNome().trim().toUpperCase()+"|"+
					     graduatoria.getPunteggio().trim().toUpperCase()+"|"+
					     graduatoria.getEtaMedia()+
						 " \r\n ";
			
		} 
		
		
    }
    
    
   
}
