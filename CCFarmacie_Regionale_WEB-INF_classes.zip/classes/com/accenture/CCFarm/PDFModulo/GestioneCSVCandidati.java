package com.accenture.CCFarm.PDFModulo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import com.accenture.CCFarm.Bean.UtenteBean;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.UtenteReg;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.DAO.UtenteRegHome;
import com.accenture.CCFarm.action.RicercaCandidatoAction;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class GestioneCSVCandidati {	
	
	private  String dateInvio = "";
	private byte[] imgStampaElencoPDF;
	//	private  EntityPDFRicevuta entityPDFRicevuta = new EntityPDFRicevuta();
//	public  List<EntityPDFRicevuta> listaEntityPDFRicevuta = new ArrayList<EntityPDFRicevuta>();
	private EntityCSVCandidati entityCsvCandidati= new EntityCSVCandidati();
	private List<EntityCSVCandidati> listaEntityCSVCandidati = new ArrayList<EntityCSVCandidati>();
	private String recordAll;
	
	
	public GestioneCSVCandidati()  // Costruttore 
	{
	}
	public byte[] getImgStampaElencoPDF() {
		return imgStampaElencoPDF;
	}

	public  void setImgStampaElencoPDF(byte[] imgStampaElencoPDF) {
		this.imgStampaElencoPDF = imgStampaElencoPDF;
	}
	
	public List<EntityCSVCandidati> getListaEntityCSVCandidati() {
		return listaEntityCSVCandidati;
	}

	public void setListaEntityCSVCandidati(
			List<EntityCSVCandidati> listaEntityCSVCandidati) {
		this.listaEntityCSVCandidati = listaEntityCSVCandidati;
	}

	public String getDateInvio() {
		return dateInvio;
	}

	public void setDateInvio(String dateInvio) {
		this.dateInvio = dateInvio;
	}
	
	public EntityCSVCandidati getEntityCsvCandidati() {
		return entityCsvCandidati;
	}

	public void setEntityCsvCandidati(EntityCSVCandidati entityCsvCandidati) {
		this.entityCsvCandidati = entityCsvCandidati;
	}

	public String getRecordAll() {
		return recordAll;
	}
	public void setRecordAll(String recordAll) {
		this.recordAll = recordAll;
	}

    public boolean caricaDatiDaUtentePerEntityCSV(String id_regione)
   	{	
    	
    	boolean result = true;
		try
		{   
//			setIdRegioneIntestazione(id_regione);
			RicercaCandidatoAction ricercaCandidatoAction = new RicercaCandidatoAction();
			List<UtenteBean> listaUtente = new ArrayList<UtenteBean>();				
			listaUtente = ricercaCandidatoAction.listaCandidatiCSV(id_regione);
			for (UtenteBean w_utente : listaUtente)
			{
				initEntityCSVfromEntityUtente(w_utente);
				getListaEntityCSVCandidati().add(getEntityCsvCandidati());
					
			}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 		
   		return result;
   		
   	}     


	 
	 public  void initEntityCSVfromEntityUtente(UtenteBean utente)
	    {
	    	try
	    	 {
	    		/* inizializzazione strutture di prelievo dati */
	    		entityCsvCandidati = new EntityCSVCandidati(); 
	    		entityCsvCandidati.setCognome(utente.getCognomeUtente());
	    		entityCsvCandidati.setNome(utente.getNomeUtente());
	    		entityCsvCandidati.setCodFiscale(utente.getCodiceFiscaleUtente());
	    		entityCsvCandidati.setCodFiscaleRiferimento(utente.getCodiceFiscaleRefCand());
	    		entityCsvCandidati.setModalitaCandidatura(utente.getModalitaCandidatura());
	    		entityCsvCandidati.setDataNascString(utente.getDataNascitaString());
	    		
	    		String luogoDiNascita ="";
	    		if(utente.getLuogoNascitaEsteraUtente()!=null && !utente.getLuogoNascitaEsteraUtente().equals("")){
	    			luogoDiNascita =  "Localit� Estera ("+utente.getLuogoNascitaEsteraUtente()+")";
	    		} else
	    			luogoDiNascita = utente.getLuogoNascitaUtente()+"("+utente.getProvinciaNascitaUtente()+")";
	    			
	    		entityCsvCandidati.setLuogoNasc(luogoDiNascita);
	    		
	    		entityCsvCandidati.setRegione(utente.getCodiceRegione());
		    	
	    	 }
			catch (Exception e)
			{
				e.printStackTrace();
			} 		    	
		}
	    
	    

   
    public  Document creaRicevuta()
    {
		return null;
    	   
    }
    
    
	
	public  void creaFileCSV() throws Exception{ 

		recordAll="";
		recordAll="COGNOME"+"|"+
				 "NOME"+"|"+
			     "CODICE FISCALE"+"|"+
			     "DATA DI NASCITA"+"|"+
			     "LUOGO DI NASCITA"+"|"+
			     "TIPO CANDIDATURA"+"|"+
				 "CF DI RIFERIMENTO"+"|"+
				 "REGIONE"+
				 " \r\n ";;
		for (int i = 0; i < listaEntityCSVCandidati.size(); i++) {
			EntityCSVCandidati candidati = new EntityCSVCandidati();
			candidati= listaEntityCSVCandidati.get(i);
			
			recordAll += candidati.getCognome().trim().toUpperCase()+"|"+
						 candidati.getNome().trim().toUpperCase()+"|"+
					     candidati.getCodFiscale().trim().toUpperCase()+"|"+
						 candidati.getDataNascString()+"|"+
					     candidati.getLuogoNasc().toUpperCase()+"|"+
					     candidati.getModalitaCandidatura().trim().toUpperCase()+"|"+
						 candidati.getCodFiscaleRiferimento().trim().toUpperCase()+"|"+
					     candidati.getRegione()+
						 " \r\n ";
			
		} 
		
		
    }
    
    
   
}
