package com.accenture.CCFarm.PDFModulo;

import java.sql.Clob;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.accenture.CCFarm.DAO.AnagraficaFarmInterpelli;
import com.accenture.CCFarm.DAO.AnagraficaFarmInterpelliHome;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.ConsultaSediListBean;
import com.accenture.CCFarm.utility.StringUtil;


public class GestioneCSVSedi {	
	
	private AnagraficaFarmInterpelliHome anagFarmInterpelloHome;
	private InterpelloHome interpelloHome;
	private List<ConsultaSediListBean> listaSedi;
	private String recordAll;
		
	public GestioneCSVSedi(){}
	
	public boolean caricaDatiSedi(String codRegione)
   	{	
    	boolean result = false;
		try
		{   
			interpelloHome = new InterpelloHome();
			Interpello interpello = interpelloHome.determinaInterpelloCorrente(codRegione);
			anagFarmInterpelloHome = new AnagraficaFarmInterpelliHome();
			listaSedi = setListaSediBean(anagFarmInterpelloHome.getSediNonAssegnate(codRegione, interpello.getId().getIdInterpello()));
			result = true;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 		
   		return result;
   		
   	}     
    
	public  void creaFileCSV(String codRegione) throws Exception{ 

		recordAll="Codice Istat Provincia|Descrizione Provincia|Codice Istat Comune|"+
				 "Descrizione Comune|N. progressivo all'interno del comune della sede  farmaceutica|Descrizione della sede farmaceutica|"+
				 "Tipo sede della sede farmaceutica |Criterio topografico della sede farmaceutica|Indennita' di avviamento";
				 
		if(codRegione.equals("041"))
			 recordAll += " |Descrizione della sede farmaceutica de ";
																							
		recordAll += "\r\n";;
		 
				 
		if(listaSedi.size()>0){	 
			for (int i = 0; i < listaSedi.size(); i++) {
				ConsultaSediListBean sede = listaSedi.get(i);
				
				recordAll += sede.getCodIstatProv().trim()+"|"+sede.getDesProv().trim()+"|"+sede.getCodIstatComu().trim()+"|"+
						sede.getDesComu().trim()+"|"+sede.getnProgCom().trim()+"|"+sede.getDesSede().trim()+"|"+
						sede.getTipoSede().trim()+"|"+sede.getCritTopo().trim()+"|"+sede.getIndennitaAvviamento().trim();
				
				if(codRegione.equals("041"))
					 recordAll += "|"+sede.getDesSedeDe().trim();
				
				recordAll += "\r\n";
			} 
		} 
    }

	public String getRecordAll() {
		return recordAll;
	}

	public void setRecordAll(String recordAll) {
		this.recordAll = recordAll;
	}
	
	private List<ConsultaSediListBean> setListaSediBean(List<AnagraficaFarmInterpelli> listaAnagFarm) throws GestioneErroriException {
		List<ConsultaSediListBean> listaSedi = new ArrayList<ConsultaSediListBean>();
		ConsultaSediListBean anagFarm = null;
		for (Iterator iterator = listaAnagFarm.iterator(); iterator.hasNext();) {
			anagFarm = new ConsultaSediListBean();
			Object[] row = (Object[]) iterator.next(); 
			anagFarm.setCodIstatProv(StringUtil.addZeriTesta((String)row[0], 3));// row[0] codIstatProv
			anagFarm.setDesProv((String)row[1]);//1 desProv
			anagFarm.setCodIstatComu((String)row[2]);//2 codIstatComu
			anagFarm.setDesComu((String)row[3]);//3 desComu
			anagFarm.setnProgCom((String)row[4]);//4 nProgCom
			Clob cDesSede = (Clob)row[5];
			anagFarm.setDesSede(cDesSede!=null ? StringUtil.convertClob(cDesSede) : "");//5 desSede //CLOB
			Clob cDesSedeDe = (Clob)row[6];
			anagFarm.setDesSedeDe(cDesSedeDe!=null ? StringUtil.convertClob(cDesSedeDe) : "");//6 desSedeDe //CLOB
			anagFarm.setTipoSede((String)row[7]);//7 tipoSede
			anagFarm.setCritTopo((String)row[8]);//8 critTopo
			String[] sIndennita = ((String)row[9]).split(";");
			anagFarm.setIndennitaAvviamento(sIndennita[0]);//9 indennitaAvviamento
			
			listaSedi.add(anagFarm);
		}
		return listaSedi;
	}
   
}
