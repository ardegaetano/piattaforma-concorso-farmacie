package com.accenture.CCFarm.audit;

import java.util.Date;

@SuppressWarnings("serial")
public class Audit implements java.io.Serializable{
	
	private String id;
	private String action;
	private String codReg;
	private Date createdDate;
	private String userId;
	private String idUtente;
	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCodReg() {
		return codReg;
	}
	public void setCodReg(String codReg) {
		this.codReg = codReg;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getIdUtente() {
		return idUtente;
	}
	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	

	
	

}
