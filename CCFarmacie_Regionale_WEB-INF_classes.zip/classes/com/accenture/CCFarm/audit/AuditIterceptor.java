package com.accenture.CCFarm.audit;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.faces.component.UICommand;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;

@SuppressWarnings("serial")
public class AuditIterceptor implements PhaseListener{

    final Logger logger = CommonLogger.getLogger("AuditIterceptor");
	FacesContext context =  null;
	    
	private static final Map<String,String> operazioni = new HashMap<String, String>();
	
	static{
		operazioni.put("pubblica-graduatoria", "#{pubblicaGraduatoriaBean.pubblicaGraduatoriaAll}");
		operazioni.put("salva-scheda", "#{elaboraGraduatoria.schedaValutazioneBean.updateGraduatoria}");
		operazioni.put("conferma-graduatoria", "#{elaboraGraduatoria.ricercaSchedeValutazione.confermaGraduatoria}");
		operazioni.put("controlla-domanda", "#{domanda.salvaDomanda}");
		operazioni.put("escludi-domanda", "#{domanda.escludiDomanda}");
		operazioni.put("ammesso-si-no", "#{ricercaCandidati.salvaCandidature}");
		operazioni.put("carica-sedi", "#{bando.salvaDatiSedi}");
		operazioni.put("valida-graduatoria", "#{graduatoriaExAequoBean.validaExAequoStorico}");
		operazioni.put("salvataggio-criteri-punteggi-laurea", "#{criteriPunteggiBean.salvaCriteriLaurea}");
		operazioni.put("validazione-criteri-punteggi-laurea", "#{criteriPunteggiBean.validaCriteriLaurea}");
		operazioni.put("salvataggio-criteri-punteggi-abilitazione", "#{criteriPunteggiBean.salvaCriteriAbilitazione}");
		operazioni.put("validazione-criteri-punteggi-abilitazione", "#{criteriPunteggiBean.validaCriteriAbilitazione}");
	}
	
	    
	@SuppressWarnings("static-access")
	@Override
	public void afterPhase(PhaseEvent afterPhase) {
		try{
			String utente = "";
			String methodExpression="";
			String action="";
			PhaseId phaseId = afterPhase.getPhaseId();
			if(phaseId ==PhaseId.RENDER_RESPONSE){
				context = afterPhase.getFacesContext().getCurrentInstance();
				//HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
				UtenteRegioni user = (UtenteRegioni)GetSessionUtility.getSessionAttribute(RepositorySession.UTENTE_NSIS);
				
				if (context.isPostback()) {
			        UICommand component = findInvokedCommandComponent(context);

			        if (component != null) {
			        	if(component.getActionExpression()!=null){
			        	methodExpression = component.getActionExpression().getExpressionString(); 
			        	if(operazioni.containsValue(methodExpression)){
			        		//crea AUdit
			        		action = getKeyByValue(operazioni,methodExpression);
			        		if(action.equalsIgnoreCase("salva-scheda")){
			        			utente = (String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_UTENTE);
			        		}else if(action.equalsIgnoreCase("escludi-domanda")||action.equalsIgnoreCase("controlla-domanda")){
			        			utente = (String) GetSessionUtility.getSessionAttribute(RepositorySession.ID_UTENTE_RETTIFICA);
			        		}
			        	
			        		AuditLogUtil.logIt(createAudit(action,user,utente));
			        		
			        		
			        	}
			        	}
			           
			        }
			    }
				
			}
			
		}catch(Exception e){
			logger.error("INTERCEPTOR FAILED",e);
		}
		
		
	}

	@Override
	public void beforePhase(PhaseEvent beforePhase) {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public PhaseId getPhaseId() {
		// TODO Auto-generated method stub
		return PhaseId.RENDER_RESPONSE;
	}
	
	private UICommand findInvokedCommandComponent(FacesContext context) {
	    UIViewRoot view = context.getViewRoot();
	    Map<String, String> params = context.getExternalContext().getRequestParameterMap();

	    if (context.getPartialViewContext().isAjaxRequest()) {
	    	if(view.findComponent(params.get("javax.faces.source"))instanceof org.primefaces.component.commandbutton.CommandButton)
	        return (UICommand) view.findComponent(params.get("javax.faces.source"));
	    } else {
	        for (String clientId : params.keySet()) {
	            UIComponent component = view.findComponent(clientId);

	            if (component instanceof UICommand) {
	                return (UICommand) component;
	            }
	        }
	    }

	    return null;
	}
	
	public boolean checkOpeartion(String operation){
		return false;
	}
	
	private Audit createAudit(String action,UtenteRegioni user,String utente) {
		Audit audit = new Audit();
		audit.setCreatedDate(new Date(System.currentTimeMillis()));
		audit.setUserId(user.getUserId());
		audit.setAction(action);
		audit.setIdUtente(utente);
		audit.setCodReg(user.getCodRegione());
		return audit;
	}
	
	public static <T, E> T getKeyByValue(Map<T, E> map, E value) {
	    for (Entry<T, E> entry : map.entrySet()) {
	        if (value.equals(entry.getValue())) {
	            return entry.getKey(); 
	        }
	    }
	    return null;
	}
	/*public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
		
		if (!isResourcesUri(request)) {
			String risultato = Audit.RISULTATO_OK;
			String messaggio = null;
			if ((request.getAttribute("exception")!=null) && (request.getAttribute("exception") instanceof Exception)) {
				 risultato = Audit.RISULTATO_KO;
				Exception e = ((Exception)request.getAttribute("exception"));
				messaggio = e.getMessage();
			} 
			Audit audit = createAudit(request, Audit.AFTER_COMPLETITION, risultato);
			audit.setMessaggioErrore(messaggio);
			logger.info(auditJacksonObjectMapper.writeValueAsString(audit));
		}

	}*/

}
