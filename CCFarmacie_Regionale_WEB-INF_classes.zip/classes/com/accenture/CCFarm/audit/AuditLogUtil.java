package com.accenture.CCFarm.audit;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

public class AuditLogUtil {
	
	private static final Logger log = CommonLogger.getLogger("AuditLogUtil");
	
	public static void logIt(Audit audit) {
		
		Session session = null;
		Transaction tx = null;
		
		try {
			
			session = HibernateUtil.openSession();
			audit.setId(getSequenceIdAudit(session));
			tx = session.beginTransaction();
			session.saveOrUpdate(audit);
			tx.commit();
		}
		catch(Exception e) {
			
			if(tx != null)
				tx.rollback();
			log.error("AuditLogUtil - logIt() failed", e);
		}
		finally {
			
			if(session != null)
				session.close();
		}
		
	}
	
	public static String getSequenceIdAudit(Session session) throws GestioneErroriException {
		
		try {
			
			String sqlString = "SELECT ID_AUDIT.nextval as id FROM dual";
			Query query = session.createSQLQuery(sqlString);
			BigDecimal idAudit = (BigDecimal) query.uniqueResult();
			
			return idAudit.toString();
		}
		catch (Exception e) {
			
			log.error("AuditLogUtil - getSequenceIdAudit() failed", e);
			throw new GestioneErroriException("AuditLogUtil - getSequenceIdAudit() failed");
		}
	}

}
