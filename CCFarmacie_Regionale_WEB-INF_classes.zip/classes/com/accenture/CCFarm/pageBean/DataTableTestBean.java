package com.accenture.CCFarm.pageBean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

@ManagedBean
@ApplicationScoped
public class DataTableTestBean 
{
	private List<String> resultList = new ArrayList<String>();
	
	private String selectedRow;
	
	public DataTableTestBean() 
	{	
		for(int i=0;i<100;i++)
		{
			resultList.add("Colonna: " + i);
		}
	}
	
	public String getSelectedRow() {
		return selectedRow;
	}

	public void setSelectedRow(String selectedRow) {
		this.selectedRow = selectedRow;
	}


	
	public List<String> getResultList() {
		System.out.println(new Date().getTime() + " getResultList");
		return resultList;
	}

	public void setResultList(List<String> resultList) {
		this.resultList = resultList;
	}	

	
}
