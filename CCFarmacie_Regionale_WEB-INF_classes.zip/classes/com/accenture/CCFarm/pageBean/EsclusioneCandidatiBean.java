package com.accenture.CCFarm.pageBean;

import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.DatiCandidato;
import com.accenture.CCFarm.action.EsclusioneCandidatiAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;

@ManagedBean(name="esclusioneCandidatiBean")
@ViewScoped
public class EsclusioneCandidatiBean {
	
	private static final Logger logger = CommonLogger.getLogger("EsclusioneCandidatiBean");
	private static final String pageError = "errorPage.jsf";
	
	//filtri di ricerca
	private DatiCandidato datiCandidato;
	private String idCandidatura;
	private String motivoRinuncia;
	private String codReg;
	private List<DatiCandidato> elencoCandidature;
	private boolean mostraElencoCandidatiTrovati;
	private EsclusioneCandidatiAction esclusioneCandidatiAction;
	
	
	public EsclusioneCandidatiBean() throws GestioneErroriException {
	
		try {
			init();
		}
		catch(Exception e) {
			logger.error("EsclusioneCandidatiBean - costruzione del bean fallita", e);
			throw new GestioneErroriException("EsclusioneCandidatiBean - costruzione del bean fallita");
		}
	}
	
	public void init() throws GestioneErroriException {  
    	
		HttpSession session = (HttpSession) JSFUtility.getFacesContext().getExternalContext().getSession(false);
		UtenteRegioni utente = (UtenteRegioni) session.getAttribute(RepositorySession.UTENTE_NSIS);
		esclusioneCandidatiAction = new EsclusioneCandidatiAction();
		datiCandidato = new DatiCandidato();
		datiCandidato.setCodRegione(utente.getCodRegione());
		setCodReg(utente.getCodRegione());
	}
	
	//ricerca tutti i candidati che possono corrispondere ai criteri impostati
	public void ricercaCandidati() {
		
		try {
			List<DatiCandidato> elencoCandidature = esclusioneCandidatiAction.ricercaUtentiCandidati(datiCandidato);
			setElencoCandidature(elencoCandidature);
			setMostraElencoCandidatiTrovati(true);
		}
		catch(Exception e) {
			logger.error("EsclusioneCandidatiBean - ricerca candidati fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void escludiCandidato() {
		
		try {
			if(esclusioneCandidatiAction.isCandidatoInterpellato(codReg, idCandidatura)) {
				JSFUtility.addWarningMessage("", "Esclusione non consentita: il candidato risulta associato ad un interpello");
			}
			else {
				esclusioneCandidatiAction.escludiCandidato(idCandidatura, motivoRinuncia);
				JSFUtility.addInfoMessage("", "Il candidato e' stato escluso correttamente");
				JSFUtility.executeScript("dlgConfermaEsclusione.hide()");
				ricercaCandidati();
				JSFUtility.update("pannelloRisultatiRicerca");
			}		
		}
		catch(Exception e) {
			logger.error("EsclusioneCandidatiBean - esclusione candidato fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void impostaCandidato() {
		try {
			Map<String,String> requestParameters = JSFUtility.getFacesContext().getExternalContext().getRequestParameterMap();
		    String idUtenteSelezionato = requestParameters.get("idCandidatoSelezionato");
		    setIdCandidatura(idUtenteSelezionato);
		    setMotivoRinuncia("");
		    JSFUtility.update("dlgConfermaEsclusione");
		}
		catch(Exception e) {
			logger.error("EsclusioneCandidatiBean - impostazione candidato fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public String getIdCandidatura() {
		return idCandidatura;
	}

	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}

	public List<DatiCandidato> getElencoCandidature() {
		return elencoCandidature;
	}

	public void setElencoCandidature(List<DatiCandidato> elencoCandidature) {
		this.elencoCandidature = elencoCandidature;
	}

	public boolean isMostraElencoCandidatiTrovati() {
		return mostraElencoCandidatiTrovati;
	}

	public void setMostraElencoCandidatiTrovati(boolean mostraElencoCandidatiTrovati) {
		this.mostraElencoCandidatiTrovati = mostraElencoCandidatiTrovati;
	}

	public DatiCandidato getDatiCandidato() {
		return datiCandidato;
	}

	public void setDatiCandidato(DatiCandidato datiCandidato) {
		this.datiCandidato = datiCandidato;
	}

	public String getCodReg() {
		return codReg;
	}

	public void setCodReg(String codReg) {
		this.codReg = codReg;
	}

	public String getMotivoRinuncia() {
		return motivoRinuncia;
	}

	public void setMotivoRinuncia(String motivoRinuncia) {
		this.motivoRinuncia = motivoRinuncia;
	}
	
}
