package com.accenture.CCFarm.pageBean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import com.accenture.CCFarm.DAO.StoricoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.action.RicercaStoricoGraduatoriaAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.UtenteRegioni;


@ManagedBean
@SessionScoped
public class RicercaStoricoGraduatoria
{	
	private String numeroPosInizialeString ;
	private String numeroPosFinaleString;
	private String numeroProtocollo;
	private String cognome;
	private String nome;
	private int codiceGraduatoria;
	private String tipoGraduatoria;
	private String codRegione;
	private BigDecimal etaMedia;
	private BigDecimal punteggio;
	private String dataNascita;
	private Date dataValidazione;
	private String dataValidazioneString;
	private String dataValidazioneString_show;
	private String dataPublicazioneString;
	private BigDecimal indiceTotale;
	private BigDecimal indiceRelativo;
	private BigDecimal indiceRettificato;
	private BigDecimal indicePrimoInterpello;
	private BigDecimal indiceSecondoInterpello;
	
	private boolean mostraRisultatiRicerca;
	private boolean abilitaRicerca;
	private String[]listaHelp;
	
	
	
	private int rowBlock= 20;
	private int rowIniBlock= 0;
	private int rowFinBlock= 0;
	private int rowNumerUltimo= 0;
	private int numeroCandidati= 0;
	private int totaleCandidatiInt=0;
	private int totalePagine=0;
	private int paginaCorrente=0;
	private String pulsantePagIndietro= "true";
	private String pulsantePagAvanti= "true";
	private int startPage;
	private int maxPerPage;
	
	private int indexTipoGrad = -1;
	
	private int totaleSchede;

	List<StoricoGraduatoria> listaStoricoGraduatoria;
	List<StoricoGraduatoria> listaGraduatoria;
	List<TipoGraduatoria> listaTipologiaGraduatoria;
	
	RicercaStoricoGraduatoriaAction ricercaStoricoGraduatoriaAction;
		
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
    UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	String codReg = utenteReg.getCodRegione();
	 
	private Logger logger = CommonLogger.getLogger("RicercaStoricoGraduatoria");
	private final static String pageError = "errorPage.jsf";
	
	public RicercaStoricoGraduatoria() 
	{	
	    init();
	}	
	
	public RicercaStoricoGraduatoria(String noInit){}
	
	public void init()
	{
		try
		{
			
			codiceGraduatoria=-1;
			ricercaStoricoGraduatoriaAction=new RicercaStoricoGraduatoriaAction();
			
			setListaHelp(Help.caricaHelpStoricoGraduatoria());
			
			listaTipologiaGraduatoria = ricercaStoricoGraduatoriaAction.findTipologieGraduatorie(codReg);

			totaleSchede = ricercaStoricoGraduatoriaAction.findCount(codReg, "1","","","");
			
			listaStoricoGraduatoria = null;
			
			indexTipoGrad = 0;
			
				if (totaleSchede>=0 ){
					abilitaRicerca=true;
				}
				else {
					abilitaRicerca=false;
					mostraRisultatiRicerca = false;
				}
				
				mostraRisultatiRicerca=false;
				//JSFUtility.update("consultaGraduatoria");
			
		}
		catch (GestioneErroriException e)
		{
			logger.error("Eccezione in Ricerca Storico Graduatoria: " + e.getMessage());
		}
		abilitaRicerca=true;
	}
	

	
	public void cercaSchede()
	{
		try {
			
			if (!(((getNumeroPosInizialeString()!=null && !getNumeroPosInizialeString().equalsIgnoreCase(""))
					&& (getNumeroPosFinaleString()==null || getNumeroPosFinaleString().equalsIgnoreCase("")))
				||((getNumeroPosFinaleString()!=null && !getNumeroPosFinaleString().equalsIgnoreCase(""))
					&& (getNumeroPosInizialeString()==null || getNumeroPosInizialeString().equalsIgnoreCase("")))) &&
					!((getNumeroPosInizialeString()!=null && !getNumeroPosInizialeString().equalsIgnoreCase("")) && 
							(getNumeroPosFinaleString()!=null && !getNumeroPosFinaleString().equalsIgnoreCase("")) && 
							(Integer.parseInt(getNumeroPosInizialeString())> Integer.parseInt(getNumeroPosFinaleString())))
					){
			
				//forse non serve???  --> sostituisco con 0 perche prendo l'�unico elemento della lista
				   if (codiceGraduatoria!=-1){		
					   
					    indexTipoGrad = getIndexGraduatoriaByProgressivo(codiceGraduatoria);
						
						if (this.getDataValidazione()!=null){
							dataValidazioneString = StringUtil.dateToStringDDMMYYYY(this.getDataValidazione());
							dataValidazioneString_show = dataValidazioneString;
						}
						else dataValidazioneString_show = StringUtil.dateToStringDDMMYYYY(listaTipologiaGraduatoria.get(indexTipoGrad).getDataValutazione());
						
						
						if (listaTipologiaGraduatoria.get(indexTipoGrad).getStatoGraduatoria().equalsIgnoreCase("P")){
							dataPublicazioneString = StringUtil.dateToStringDDMMYYYY(listaTipologiaGraduatoria.get(indexTipoGrad).getDataPublicazione());
						}else if (listaTipologiaGraduatoria.get(indexTipoGrad).getStatoGraduatoria().equalsIgnoreCase("V")){
							dataPublicazioneString = "Graduatoria non ancora pubblicata";
						}
						
						rowBlock = 20;
						
						tipoGraduatoria = listaTipologiaGraduatoria.get(indexTipoGrad).getDescrizione();
					    totaleSchede = ricercaStoricoGraduatoriaAction.findCount(codReg, ""+codiceGraduatoria,numeroPosInizialeString,numeroPosFinaleString,dataValidazioneString);
					    totaleCandidatiInt = totaleSchede;
						
						setMostraRisultatiRicerca(true);	
						
						
						
						if(totaleCandidatiInt>0) {
							paginaCorrente=1;
							if (totaleCandidatiInt>rowBlock){
								totalePagine= totaleCandidatiInt / rowBlock;
								int remainderInt= 0;
								    remainderInt = totaleCandidatiInt % rowBlock;
								if (remainderInt>0){
									totalePagine++;
								}			
							} else {
								totalePagine=1;
							}
							setRowIniBlock(0);
							setRowFinBlock(rowBlock);
							if (totaleCandidatiInt<rowBlock){
								rowBlock=totaleCandidatiInt;
								setRowFinBlock(rowBlock);
							}
							setNumeroCandidati(totaleCandidatiInt);
						    if (numeroCandidati==rowBlock || numeroCandidati<rowBlock ){
						    	setPulsantePagAvanti("true");
						    	setPulsantePagIndietro("true");
						    } else {
						    	setPulsantePagAvanti("false");
						    	setPulsantePagIndietro("true");
						    }
						    	
							mostraRisultatiRicerca=true;						   
						}
						else{
						totalePagine=1;
						}
						this.primaPagina();
//						else if(totaleCandidatiInt==0) {
//							totalePagine=1;
//							mostraRisultatiRicerca=true;
////							setPulsantePagAvanti("true");
//						}
						if(totaleCandidatiInt==0) {
							
							setPulsantePagAvanti("true");
						}
						dataValidazioneString="";
						JSFUtility.update("graduatorie");
						
				   }
				   else {
						JSFUtility.addWarningMessage("Selezionare una tipologia di graduatoria", "");
						JSFUtility.scrollTo("msgs");
					}
						
						
			}
			else {
				JSFUtility.addWarningMessage("Valorizzare correttamente i campi di ricerca relativi alle posizioni", "");
				JSFUtility.scrollTo("msgs");
			}
		}
		
		catch (NumberFormatException e)
	    {	    	
			JSFUtility.addWarningMessage("","Inserire caratteri numerici nei campi relativi agli indici di posizione");
			JSFUtility.scrollTo("msgs");
		}
		
		catch (Exception e)
	    {
	    	logger.error("Eccezione in Ricerca Graduatoria: " + e.getMessage());
			JSFUtility.addWarningMessage("","Errore durante la ricerca della graduatoria");
			JSFUtility.scrollTo("msgs");
		}
		
		
		
	}
	

	// ****************   metodi per paginazione  **************************** //
    // *********************************************************************** //
	
	
	public String paginaInizio() {
		
		try{
			startPage=0;
			maxPerPage=rowBlock;
			rowNumerUltimo=maxPerPage;
			listaStoricoGraduatoria = ricercaStoricoGraduatoriaAction.getPageStoricoGraduatoria(this, this.startPage, this.maxPerPage, codReg);
			
		} catch (GestioneErroriException e) {
			logger.error("StoricoGraduatoria- paginaInizio : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
			
		return null;
	}	
	
	
	public String paginaAvanti() {
		
		setRowIniBlock(getRowNumerUltimo());		
		setRowFinBlock(getRowIniBlock()+getRowBlock());		
		
		paginaCorrente++;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowFinBlock()== getNumeroCandidati() || getRowFinBlock()>getNumeroCandidati()){
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");

		}
		
		startPage=getRowNumerUltimo();
		maxPerPage=rowBlock;
		if (rowNumerUltimo<rowBlock) startPage=0;
		try {
			listaStoricoGraduatoria = ricercaStoricoGraduatoriaAction.getPageStoricoGraduatoria(this, this.startPage, this.maxPerPage, codReg);
			setRowNumerUltimo(getRowNumerUltimo() + 20);
		} catch (GestioneErroriException e) {
			logger.error("StoricoGraduatoria - paginaAvanti : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		
			
		return null;
	}
	
	
	
	public String paginaIndietro() {
		rowIniBlock=rowIniBlock-rowBlock;
		setRowFinBlock(getRowIniBlock()+getRowBlock());

		paginaCorrente--;
//		if (paginaCorrente==0) paginaCorrente=1;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowIniBlock()== 0 || getRowIniBlock()<0){
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
	    	setPulsantePagIndietro("true");
		}
		
		startPage=startPage-rowBlock;
		maxPerPage=rowBlock;
		if(startPage<0)startPage=0;
		try {
			listaStoricoGraduatoria = ricercaStoricoGraduatoriaAction.getPageStoricoGraduatoria(this, this.startPage, this.maxPerPage, codReg );
			if(paginaCorrente==1){
				setRowNumerUltimo(20);
			}else
			setRowNumerUltimo(getRowNumerUltimo() - 20);
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaExAequoBean - paginaIndietro : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		return null;
	}
	
	
	
	public String ultimaPagina() {
		rowFinBlock=getNumeroCandidati();
		setRowIniBlock(getRowFinBlock()-getRowBlock());
		
		paginaCorrente=totalePagine;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

    	if (getRowFinBlock()== getNumeroCandidati() || getRowFinBlock()>getNumeroCandidati()){
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");
    	}
		
		startPage=totaleCandidatiInt-rowBlock+1;
		maxPerPage=rowBlock;
		rowNumerUltimo=totaleCandidatiInt;
		try {
			listaStoricoGraduatoria = ricercaStoricoGraduatoriaAction.getPageStoricoGraduatoria(this, this.startPage, this.maxPerPage, codReg);
			
		} catch (GestioneErroriException e) {
			logger.error("StoricoGraduatoria - ultimaPagina : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		
		return null;
	}

	
	
	public String primaPagina() {
		rowIniBlock=0;
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente=1;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowIniBlock()== 0 || getRowIniBlock()<0){
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
	    	setPulsantePagIndietro("true");

		}	
		
		paginaInizio();
		return null;
	}
	
	
	
	
	
	
	
	


	public int getNumeroCandidati() {
		return numeroCandidati;
	}

	public void setNumeroCandidati(int numeroCandidati) {
		this.numeroCandidati = numeroCandidati;
	}

	public String getPulsantePagIndietro() {
		return pulsantePagIndietro;
	}

	public void setPulsantePagIndietro(String pulsantePagIndietro) {
		this.pulsantePagIndietro = pulsantePagIndietro;
	}

	public String getPulsantePagAvanti() {
		return pulsantePagAvanti;
	}

	public void setPulsantePagAvanti(String pulsantePagAvanti) {
		this.pulsantePagAvanti = pulsantePagAvanti;
	}

	public int getRowBlock() {
		return rowBlock;
	}

	public void setRowBlock(int rowBlock) {
		this.rowBlock = rowBlock;
	}

	public int getRowIniBlock() {
		return rowIniBlock;
	}

	public void setRowIniBlock(int rowIniBlock) {
		this.rowIniBlock = rowIniBlock;
	}

	public int getRowFinBlock() {
		return rowFinBlock;
	}

	public void setRowFinBlock(int rowFinBlock) {
		this.rowFinBlock = rowFinBlock;
	}

	public int getRowNumerUltimo() {
		return rowNumerUltimo;
	}

	public void setRowNumerUltimo(int rowNumerUltimo) {
		this.rowNumerUltimo = rowNumerUltimo;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getMaxPerPage() {
		return maxPerPage;
	}

	public void setMaxPerPage(int maxPerPage) {
		this.maxPerPage = maxPerPage;
	}

	public String getNumeroPosInizialeString() {
		return numeroPosInizialeString;
	}

	public void setNumeroPosInizialeString(String numeroPosInizialeString) {
		this.numeroPosInizialeString = numeroPosInizialeString;
	}


	public String getNumeroPosFinaleString() {
		return numeroPosFinaleString;
	}

	public void setNumeroPosFinaleString(String numeroPosFinaleString) {
		this.numeroPosFinaleString = numeroPosFinaleString;
	}

	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}

	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipoGraduatoria() {
		return tipoGraduatoria;
	}

	public void setTipoGraduatoria(String tipoGraduatoria) {
		this.tipoGraduatoria = tipoGraduatoria;
	}

	public String getCodRegione() {
		return codRegione;
	}


	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}

	public BigDecimal getEtaMedia() {
		return etaMedia;
	}

	public void setEtaMedia(BigDecimal etaMedia) {
		this.etaMedia = etaMedia;
	}

	public BigDecimal getPunteggio() {
		return punteggio;
	}

	public void setPunteggio(BigDecimal punteggio) {
		this.punteggio = punteggio;
	}


	public Date getDataValidazione() {
		return dataValidazione;
	}

	public void setDataValidazione(Date dataValidazione) {
		this.dataValidazione = dataValidazione;
	}

	public String getDataValidazioneString() {
		return dataValidazioneString;
	}

	public void setDataValidazioneString(String dataValidazioneString) {
		this.dataValidazioneString = dataValidazioneString;
	}

	public BigDecimal getIndiceTotale() {
		return indiceTotale;
	}

	public String getDataPublicazioneString() {
		return dataPublicazioneString;
	}

	public void setDataPublicazioneString(String dataPublicazioneString) {
		this.dataPublicazioneString = dataPublicazioneString;
	}

	public void setIndiceTotale(BigDecimal indiceTotale) {
		this.indiceTotale = indiceTotale;
	}

	public BigDecimal getIndiceRettificato() {
		return indiceRettificato;
	}

	public void setIndiceRettificato(BigDecimal indiceRettificato) {
		this.indiceRettificato = indiceRettificato;
	}

	public BigDecimal getIndicePrimoInterpello() {
		return indicePrimoInterpello;
	}

	public void setIndicePrimoInterpello(BigDecimal indicePrimoInterpello) {
		this.indicePrimoInterpello = indicePrimoInterpello;
	}

	public BigDecimal getIndiceSecondoInterpello() {
		return indiceSecondoInterpello;
	}

	public void setIndiceSecondoInterpello(BigDecimal indiceSecondoInterpello) {
		this.indiceSecondoInterpello = indiceSecondoInterpello;
	}
	
	public boolean isMostraRisultatiRicerca() {
		return mostraRisultatiRicerca;
	}

	public void setMostraRisultatiRicerca(boolean mostraRisultatiRicerca) {
		this.mostraRisultatiRicerca = mostraRisultatiRicerca;
	}

	public String[] getListaHelp() {
		return listaHelp;
	}

	public void setListaHelp(String[] listaHelp) {
		this.listaHelp = listaHelp;
	}


	

	public String getCodReg() {
		return codReg;
	}

	public void setCodReg(String codReg) {
		this.codReg = codReg;
	}

	public int getTotaleSchede() {
		return totaleSchede;
	}

	public void setTotaleSchede(int totaleSchede) {
		this.totaleSchede = totaleSchede;
	}

	

	public List<StoricoGraduatoria> getListaGraduatoria() {
		return listaGraduatoria;
	}

	public void setListaGraduatoria(List<StoricoGraduatoria> listaGraduatoria) {
		this.listaGraduatoria = listaGraduatoria;
	}
	
	public List<TipoGraduatoria> getListaTipologiaGraduatoria() {
		return listaTipologiaGraduatoria;
	}

	public void setListaTipologiaGraduatoria(
			List<TipoGraduatoria> listaTipologiaGraduatoria) {
		this.listaTipologiaGraduatoria = listaTipologiaGraduatoria;
	}

	public boolean isAbilitaRicerca() {
		return abilitaRicerca;
	}

	public void setAbilitaRicerca(boolean abilitaRicerca) {
		this.abilitaRicerca = abilitaRicerca;
	}
		
	public int getCodiceGraduatoria() {
		return codiceGraduatoria;
	}

	public void setCodiceGraduatoria(int codiceGraduatoria) {
		this.codiceGraduatoria = codiceGraduatoria;
	}

	public BigDecimal getIndiceRelativo() {
		return indiceRelativo;
	}

	public void setIndiceRelativo(BigDecimal indiceRelativo) {
		this.indiceRelativo = indiceRelativo;
	}

	public String getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}
	
	public String getDataValidazioneString_show() {
		return dataValidazioneString_show;
	}
	
	public void setDataValidazioneString_show(String dataValidazioneString_show) {
		this.dataValidazioneString_show = dataValidazioneString_show;
	}

	public List<StoricoGraduatoria> getListaStoricoGraduatoria() {
		return listaStoricoGraduatoria;
	}

	public void setListaStoricoGraduatoria(
			List<StoricoGraduatoria> listaStoricoGraduatoria) {
		this.listaStoricoGraduatoria = listaStoricoGraduatoria;
	}

	public RicercaStoricoGraduatoriaAction getRicercaStoricoGraduatoriaAction() {
		return ricercaStoricoGraduatoriaAction;
	}

	public void setRicercaStoricoGraduatoriaAction(
			RicercaStoricoGraduatoriaAction ricercaStoricoGraduatoriaAction) {
		this.ricercaStoricoGraduatoriaAction = ricercaStoricoGraduatoriaAction;
	}

	public int getPaginaCorrente() {
		return paginaCorrente;
	}

	public void setPaginaCorrente(int paginaCorrente) {
		this.paginaCorrente = paginaCorrente;
	}

//	public LazyDataModel<StoricoGraduatoria> getStoricoGraduatoriaList() throws GestioneErroriException{
//		
//		try
//		{
//			if(graduatorie==null){
//				if (this.numeroPosInizialeString!=null && !this.numeroPosInizialeString.equalsIgnoreCase("") && 
//						this.numeroPosFinaleString!=null && !this.numeroPosFinaleString.equalsIgnoreCase("") &&	this.codiceGraduatoria!=-1 
//						){
//					graduatorie = new StoricoGraduatoriaLazyList(cod_reg,Integer.parseInt(this.numeroPosInizialeString),Integer.parseInt(this.numeroPosFinaleString),""+this.codiceGraduatoria,totaleSchede,dataValidazioneString);
//				}
//				else {				
//					graduatorie = new StoricoGraduatoriaLazyList(cod_reg,1,totaleSchede,""+codiceGraduatoria,totaleSchede,dataValidazioneString);
//				}				
//				
//			}
//	
//		}
//		catch(Exception e)
//		{
//			logger.error("Eccezione in SchedaValutazioneBean - updateGraduatoria: " + e.getMessage());
//			JSFUtility.addWarningMessage("", "Errore durante la visualizzazione della graduatoria");
//			JSFUtility.scrollTo("msgs");
//		
//		}
//			
//		
//		return graduatorie;
//		
//	}

	public int getTotaleCandidatiInt() {
		return totaleCandidatiInt;
	}

	public void setTotaleCandidatiInt(int totaleCandidatiInt) {
		this.totaleCandidatiInt = totaleCandidatiInt;
	}

	public int getTotalePagine() {
		return totalePagine;
	}

	public void setTotalePagine(int totalePagine) {
		this.totalePagine = totalePagine;
	}
	
	public int getIndexTipoGrad() {
		return indexTipoGrad;
	}

	public void setIndexTipoGrad(int indexTipoGrad) {
		this.indexTipoGrad = indexTipoGrad;
	}

	private int getIndexGraduatoriaByProgressivo(int progGraduatoria) {
		int index = 0;
		for(int i=0; i<listaTipologiaGraduatoria.size(); i++){
			TipoGraduatoria tGrad = listaTipologiaGraduatoria.get(i);
			if(tGrad.getProgressivo()!=null && tGrad.getProgressivo().intValue() == progGraduatoria){
				index = i;
				break;
			}
		}
		return index;
	}
	
	
	
}