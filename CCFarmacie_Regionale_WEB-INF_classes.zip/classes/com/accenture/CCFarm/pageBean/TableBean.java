package com.accenture.CCFarm.pageBean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

@ManagedBean
@ApplicationScoped
public class TableBean  implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<String> cars;
	
	public List<String> getCars() {
		return cars;
	}

	public void setCars(List<String> cars) {
		this.cars = cars;
	}

	public TableBean()
	{
		cars = new ArrayList<String>();
		cars.add("1");
		cars.add("2");
		cars.add("3");
		cars.add("4");
	}
}
