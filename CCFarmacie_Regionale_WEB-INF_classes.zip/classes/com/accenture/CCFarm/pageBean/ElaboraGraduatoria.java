package com.accenture.CCFarm.pageBean;

import java.sql.Timestamp;
import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.log4j.Logger;
import org.primefaces.component.tabview.TabView;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


@ManagedBean
@SessionScoped
public class ElaboraGraduatoria
{
	
	private String idUtente;
	private String codRegioneUtente;
	
	private String tabDaVisualizzare="0";
	private String tabDaVisualizzareGraduatoria="0";
	
	
	private CalcolaPunteggiAutomatici calcolaPunteggiAutomatici;
	private RicercaSchedeValutazione ricercaSchedeValutazione;
	private SchedaValutazioneBean schedaValutazioneBean;
	private GraduatoriaExAequoBean graduatoriaExAequoBean;
	private RicercaStoricoGraduatoria ricercaStoricoGraduatoria;
	
	private Logger logger = CommonLogger.getLogger("ElaboraGraduatoria");
	private final static String pageError = "errorPage.jsf";
	
	private String abilitaTabGestioneValutazioni = "true";
	private String abilitaTabGestisciGraduatoria = "true";
	private static final String msg  = AppProperties.getAppProperties().getProperty("msg.interpello.in.corso.elabora.graduatoria");
	
	public ElaboraGraduatoria() 
	{
		
	    init();
	}
	
	public ElaboraGraduatoria(String noInit){}
	
	private boolean trovaDatiUtente()
	{
		UtenteRegioni utenteReg=(UtenteRegioni)GetSessionUtility.getSessionAttribute(RepositorySession.UTENTE_NSIS);
		if(utenteReg==null)
			return false;
		
		idUtente=utenteReg.getUserId();
		codRegioneUtente=utenteReg.getCodRegione();
		
		return true;
	}
	
	public void init()
	{
		calcolaPunteggiAutomatici=new CalcolaPunteggiAutomatici();
////		ricercaSchedeValutazione=new RicercaSchedeValutazione("noInit");
		ricercaSchedeValutazione=new RicercaSchedeValutazione();
		schedaValutazioneBean=new SchedaValutazioneBean();
////		ricercaStoricoGraduatoria = new RicercaStoricoGraduatoria("noInit");
		//ricercaStoricoGraduatoria = new RicercaStoricoGraduatoria();
////		graduatoriaExAequoBean = new GraduatoriaExAequoBean("noInit");
//		graduatoriaExAequoBean = new GraduatoriaExAequoBean();
		
		
		trovaDatiUtente();
		DatiBando datiBando = new  DatiBando();
		DatiBandoHome datiBandoHome = new DatiBandoHome();
		
		try {
			datiBando = datiBandoHome.findById(codRegioneUtente);
			if (datiBando!=null){
				if (datiBando.getFlgScarti()!= null && datiBando.getFlgScarti().equalsIgnoreCase("true")){
					abilitaTabGestioneValutazioni = "true";
				} else{
					abilitaTabGestioneValutazioni = "false";
				}
				if (datiBando.getFlgAbilitaGrad()!=null && datiBando.getFlgAbilitaGrad().equalsIgnoreCase("true")){
					abilitaTabGestisciGraduatoria = "false";
				} else {
					abilitaTabGestisciGraduatoria = "true";
				}
				//Controllo Interpello in corso
				if(isFaseInterpelloAttiva(codRegioneUtente)){
					JSFUtility.addWarningMessage("Attenzione!!", msg);
				}
				
			} else {
				abilitaTabGestioneValutazioni = "true";
				abilitaTabGestisciGraduatoria = "true";
			}
		} catch (GestioneErroriException e) {
			e.printStackTrace();
			JSFUtility.redirect("errorPage.jsf");
		}
		
		
				
				
		
	}
	
	public void handleTabGraduatoria()
	{
		
		TabView tabView = (TabView) JSFUtility.findComponent(JSFUtility.getUIViewRoot(), "viewsGraduatoria");
		int currentTab= tabView.getActiveIndex();
		JSFUtility.update("msgs");	
		
		try {
			if(currentTab==0)
			{   
	//			setCalcolaPunteggiAutomatici((CalcolaPunteggiAutomatici) GetSessionUtility.getSessionAttribute("calcolaPunteggiAutomatici"));
				
				calcolaPunteggiAutomatici.init();
				JSFUtility.update("calcolaPunteggi");
				JSFUtility.update("msgs");
				
				
			}
			
			if(currentTab==1)
			{
	//			setRicercaSchedeValutazione((RicercaSchedeValutazione) GetSessionUtility.getSessionAttribute("ricercaSchedeValutazione"));
				ricercaSchedeValutazione.init();
				
				JSFUtility.update("candidature");
				JSFUtility.update("Salva");
				JSFUtility.update("msgs");
			}
			
			if(currentTab==2)
			{
	//			GetSessionUtility.removeSessionAttribute("graduatoriaExAequoBean");
				setGraduatoriaExAequoBean((GraduatoriaExAequoBean) GetSessionUtility.getSessionAttribute("graduatoriaExAequoBean"));
				graduatoriaExAequoBean.init();
				
				
				JSFUtility.update("tabGradExAequo");
				JSFUtility.update("salva");
				JSFUtility.update("valida");
				JSFUtility.update("msgs");
				JSFUtility.update("linkPDF");
				JSFUtility.update("linkCSV");
			}
			
			//Controllo Interpello in corso
			if(isFaseInterpelloAttiva(codRegioneUtente)){
				JSFUtility.addWarningMessage("Attenzione!!", msg);
			}
			
		} catch (GestioneErroriException e) {
			e.printStackTrace();
			JSFUtility.redirect("errorPage.jsf");
		}
	}
	
	/*public void handleTabGestisciGraduatoria()
	{
		TabView tabView = (TabView) JSFUtility.findComponent(JSFUtility.getUIViewRoot(), "viewsGraduatoriaDefinitiva");
		int currentTab= tabView.getActiveIndex();
		JSFUtility.update("msgs");	
		
		if(currentTab==0)
		{
			setGraduatoriaExAequoBean((GraduatoriaExAequoBean) GetSessionUtility.getSessionAttribute("graduatoriaExAequoBean"));
			graduatoriaExAequoBean.init();
			JSFUtility.update("tabGradExAequo");
			JSFUtility.update("salva");
			JSFUtility.update("valida");
			JSFUtility.update("msgs");	
		}
		
		if(currentTab==1)
		{
//			setRicercaStoricoGraduatoria((RicercaStoricoGraduatoria) GetSessionUtility.getSessionAttribute("ricercaStoricoGraduatoria"));
			ricercaStoricoGraduatoria.init();
			JSFUtility.update("tipoGraduatoria");
			JSFUtility.update("msgs");	
		}

	}*/
	
	
	public String indietro()
	{
		//JSFUtility.redirect("homeRegioni.jsf");
		return "homeRegioni";
	}
	
	public void aggiornaTabDaVisualizzare(){
		this.setTabDaVisualizzare("1");
//		ricercaSchedeValutazione.setMostraRisultatiRicerca(false);
		ricercaSchedeValutazione.setMostraRisultatiRicerca(true);	
		
		DatiBando datiBando = null;//new  DatiBando();
		DatiBandoHome datiBandoHome = new DatiBandoHome();
		
		try {
			datiBando = datiBandoHome.findById(codRegioneUtente);
			if (datiBando!=null){
				if (datiBando.getFlgScarti()!= null && datiBando.getFlgScarti().equalsIgnoreCase("true")){
					abilitaTabGestioneValutazioni = "true";
				} else{
					abilitaTabGestioneValutazioni = "false";
				}
				if (datiBando.getFlgAbilitaGrad()!=null && datiBando.getFlgAbilitaGrad().equalsIgnoreCase("true")){
					abilitaTabGestisciGraduatoria = "false";
				} else {
					abilitaTabGestisciGraduatoria = "true";
				}
			} else {
				abilitaTabGestioneValutazioni = "true";
				abilitaTabGestisciGraduatoria = "true";
			}
		} catch (GestioneErroriException e) {
		
		}
		JSFUtility.update("formGraduatoria");
		
	}
	
	public void aggiornaTabDaVisualizzareGraduatoria(){
		this.setTabDaVisualizzareGraduatoria("1");
		graduatoriaExAequoBean.setMostraRisultatiRicerca(false);
	}
	
	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}
	
	public String getCodRegioneUtente() {
		return codRegioneUtente;
	}

	public void setCodRegioneUtente(String codRegioneUtente) {
		this.codRegioneUtente = codRegioneUtente;
	}
	
	public CalcolaPunteggiAutomatici getCalcolaPunteggiAutomatici() {
		return calcolaPunteggiAutomatici;
	}

	public void setCalcolaPunteggiAutomatici(
			CalcolaPunteggiAutomatici calcolaPunteggiAutomatici) {
		this.calcolaPunteggiAutomatici = calcolaPunteggiAutomatici;
	}

	public RicercaSchedeValutazione getRicercaSchedeValutazione() {
		return ricercaSchedeValutazione;
	}

	public void setRicercaSchedeValutazione(
			RicercaSchedeValutazione ricercaSchedeValutazione) {
		this.ricercaSchedeValutazione = ricercaSchedeValutazione;
	}
	
	public SchedaValutazioneBean getSchedaValutazioneBean() {
		return schedaValutazioneBean;
	}
	
	public void setSchedaValutazioneBean(SchedaValutazioneBean schedaValutazioneBean) {
		this.schedaValutazioneBean = schedaValutazioneBean;
	}
	
	public String getTabDaVisualizzare() {
		return tabDaVisualizzare;
	}

	public void setTabDaVisualizzare(String tabDaVisualizzare) {
		this.tabDaVisualizzare = tabDaVisualizzare;
	}

	public String getTabDaVisualizzareGraduatoria() {
		return tabDaVisualizzareGraduatoria;
	}

	public void setTabDaVisualizzareGraduatoria(String tabDaVisualizzareGraduatoria) {
		this.tabDaVisualizzareGraduatoria = tabDaVisualizzareGraduatoria;
	}

	public GraduatoriaExAequoBean getGraduatoriaExAequoBean() {
		return graduatoriaExAequoBean;
	}

	public void setGraduatoriaExAequoBean(
			GraduatoriaExAequoBean graduatoriaExAequoBean) {
		this.graduatoriaExAequoBean = graduatoriaExAequoBean;
	}

	public RicercaStoricoGraduatoria getRicercaStoricoGraduatoria() {
		return ricercaStoricoGraduatoria;
	}

	public void setRicercaStoricoGraduatoria(
			RicercaStoricoGraduatoria ricercaStoricoGraduatoria) {
		this.ricercaStoricoGraduatoria = ricercaStoricoGraduatoria;
	}

	public String getAbilitaTabGestioneValutazioni() {
		return abilitaTabGestioneValutazioni;
	}

	public void setAbilitaTabGestioneValutazioni(
			String abilitaTabGestioneValutazioni) {
		this.abilitaTabGestioneValutazioni = abilitaTabGestioneValutazioni;
	}

	public String getAbilitaTabGestisciGraduatoria() {
		return abilitaTabGestisciGraduatoria;
	}

	public void setAbilitaTabGestisciGraduatoria(
			String abilitaTabGestisciGraduatoria) {
		this.abilitaTabGestisciGraduatoria = abilitaTabGestisciGraduatoria;
	}
	
	private boolean isFaseInterpelloAttiva(String codReg) throws GestioneErroriException{

		boolean bRet = false;
	    InterpelloHome interpelloHome = new  InterpelloHome();
	    Interpello interpello = interpelloHome.determinaInterpelloCorrentePubblicatoChiuso(codReg);
	    if(interpello!=null) {
		   /* Date dataInizio = (Timestamp)interpello.getDataInizio();
		    Date dataFine = (Timestamp)interpello.getDataFineAccettazione();
		    
		    //se data sistema >= dataInizio e data fine non valorizzata oppure data sistema <= dataFine
		    if((!new Date().before(dataInizio)) && (dataFine==null || (!new Date().after(dataFine))))*/
		    	bRet = true;
	    }
		return bRet;
	}
	
	
	
}