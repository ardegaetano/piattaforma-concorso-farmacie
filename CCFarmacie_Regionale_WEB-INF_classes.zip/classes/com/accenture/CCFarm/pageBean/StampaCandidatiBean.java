package com.accenture.CCFarm.pageBean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.UtenteBean;
import com.accenture.CCFarm.PDFModulo.GestionePDFStampaElenco;
import com.accenture.CCFarm.action.RicercaCandidatoAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


@ManagedBean
@SessionScoped
public class StampaCandidatiBean
{
	private String nomeRicerca="";
	private String cognomeRicerca="";
	private String codiceFiscaleRicerca="";
	private String codRegioneRicerca;
	private boolean mostraRisultatiRicerca = true;
	private String pulsantePagIndietro= "true";
	private String pulsantePagAvanti= "true";
	String pageError = "errorPage.jsf";
	
 	
	
//	UtenteBean utenteSelezionato;
	private List<String>  idCandidatiList;
	private List<UtenteBean> listaCandidature;
	private int rowBlock= 20;
	private int rowIniBlock= 0;
	private int rowFinBlock= 0;
	private int rowNumerUltimo= 0;
	private int numeroCandidati= 0;
	private int numeroPatine= 0;
	private String totaleCandidati="";
	private int totaleCandidatiInt=0;
	private int totalePagine=0;
	private int paginaCorrente=0;
	
	RicercaCandidatoAction ricercaCandidatoAction;
	UtenteRegioni utenteReg = new UtenteRegioni();
	private SimpleDateFormat sdf = new SimpleDateFormat();
     
	Logger logger = CommonLogger.getLogger("StampaCandidatiBean");
	
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	public StampaCandidatiBean() 
	{
		this.init();
		
	}
	public void init(){

//		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
//	    utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
//		
		
		//ExternalContext exContext =  FacesContext.getCurrentInstance().getExternalContext();
		//HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	    utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	    String sessionPrima = (String) session.getAttribute(RepositorySession.CHIAMO_STAMPA_DA_FUORI);
//	    if (sessionPrima.equalsIgnoreCase("SI")){
//	    	session.setAttribute(RepositorySession.CHIAMO_STAMPA_DA_FUORI, "NO");
    
	    try {	
			listaCandidature = new ArrayList<UtenteBean>();
			ricercaCandidatoAction=new RicercaCandidatoAction();	
			RicercaCandidati ricercaCandidato =new RicercaCandidati("non eseguo INIT");
	//ricerca per codice regione
			ricercaCandidato.setCodReg(utenteReg.getCodRegione());
//			listaCandidature = ricercaCandidatoAction.ricercaCandidati(ricercaCandidato);
			
			idCandidatiList= ricercaCandidatoAction.ricIdCandidatiAll(this);
			setTotaleCandidati(""+idCandidatiList.size());
			totaleCandidatiInt = Integer.parseInt(totaleCandidati);
			
			if(idCandidatiList.size()>0) {
				paginaCorrente=1;
				if (totaleCandidatiInt>rowBlock){
					totalePagine= totaleCandidatiInt / rowBlock;
					int remainderInt= 0;
					    remainderInt = totaleCandidatiInt % rowBlock;
					if (remainderInt>0){
						totalePagine++;
					}
	//				
				} else {
					totalePagine=1;
				}
				setRowIniBlock(0);
				setRowFinBlock(rowBlock);
				if (idCandidatiList.size()<rowBlock){
					rowBlock=idCandidatiList.size();
					setRowFinBlock(rowBlock);
				}
				setNumeroCandidati(idCandidatiList.size());
			    if (numeroCandidati==rowBlock || numeroCandidati<rowBlock ){
			    	setPulsantePagAvanti("true");
			    	setPulsantePagIndietro("true");
			    } else {
			    	setPulsantePagAvanti("false");
			    	setPulsantePagIndietro("true");
			    }
			    	
				mostraRisultatiRicerca=true;
			    paginaInizio();
			}
	    
	    } catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
//	    }
	}

	public String paginaInizio() {
		
		try {
//			listaCandidature = new ArrayList<UtenteBean>();
			listaCandidature = ricercaCandidatoAction.paginazioneCandidati(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaInizio : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		return null;
	}
	public String paginaAvanti() {
		setRowIniBlock(getRowFinBlock());
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
//		int skipCandidati = getRowIniBlock();
//		
//		skipCandidati=skipCandidati+rowBlock;
		paginaCorrente++;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowFinBlock()== getNumeroCandidati() || getRowFinBlock()>getNumeroCandidati()){
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");

		}
		
//		setRowNumer(skipCandidati);
		
		try {
//			listaCandidature = new ArrayList<UtenteBean>();
			listaCandidature = ricercaCandidatoAction.paginazioneCandidati(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
			
		return null;
	}
	
	public String ultimaPagina() {
		rowFinBlock=getNumeroCandidati();
		setRowIniBlock(getRowFinBlock()-getRowBlock());
		
		paginaCorrente=totalePagine;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

    	if (getRowFinBlock()== getNumeroCandidati() || getRowFinBlock()>getNumeroCandidati()){
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");
    	}
		
		try {
			listaCandidature = ricercaCandidatoAction.paginazioneCandidati(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		return null;
	}
	
	public String pirmaPagina() {
		rowIniBlock=0;
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente=1;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowIniBlock()== 0 || getRowIniBlock()<0){
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
	    	setPulsantePagIndietro("true");

		}
		
		try {
			listaCandidature = ricercaCandidatoAction.paginazioneCandidati(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		return null;
	}
	
	
	public String paginaIndietro() {
		rowIniBlock=rowIniBlock-rowBlock;
//		setRowIniBlock(getRowFinBlock()-getRowBlock());
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
//		int skipCandidati = getRowIniBlock();
//		
//		skipCandidati=skipCandidati+rowBlock;
		paginaCorrente--;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowIniBlock()== 0 || getRowIniBlock()<0){
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
	    	setPulsantePagIndietro("true");

		}
		
		try {
//			listaCandidature = new ArrayList<UtenteBean>();
			listaCandidature = ricercaCandidatoAction.paginazioneCandidati(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		return null;
	}
	public String indietro() {
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		session.setAttribute(RepositorySession.CHIAMO_STAMPA_DA_FUORI, "NO");
		
		//JSFUtility.redirect("homeRegioni.jsf");
		return "homeRegioni";
	}
	public String esportaInPDF() {
		
		//JSFUtility.redirect("../scaricaElencoCandidatiServlet?idRegione="+utenteReg.getCodRegione());
		String url = "../scaricaElencoCandidatiServlet";
		return url;
	}
	public String esportaInCSV() {
		JSFUtility.redirect("../scaricaElencoCandidatiCSVServlet?idRegione="+utenteReg.getCodRegione());
		return null;
	}
	public String avvioStampa() {
		try
		{ 
			GestionePDFStampaElenco gestionePDFStampaElenco = new GestionePDFStampaElenco();
			gestionePDFStampaElenco.caricaDatiDaUtentePerEntityPDF(utenteReg.getCodRegione());
			gestionePDFStampaElenco.creaRicevutaPDF();
			gestionePDFStampaElenco.downloadFile();
			/*
			byte[] ricevutaPDF = gestionePDFModuloRicevuta.getImgRicevutaPDF();
			gestionePDFModuloRicevuta.salvaRicevutaPDF(ricevutaPDF);
			*/
		} catch (Exception e) { 
			
		}
		return null;
	}
	public String paginaNumero() {
		return null;
	}

	
	public String getNomeRicerca() {
		return nomeRicerca;
	}




	public void setNomeRicerca(String nomeRicerca) {
		this.nomeRicerca = nomeRicerca;
	}




	public String getCognomeRicerca() {
		return cognomeRicerca;
	}




	public void setCognomeRicerca(String cognomeRicerca) {
		this.cognomeRicerca = cognomeRicerca;
	}




	public String getCodiceFiscaleRicerca() {
		return codiceFiscaleRicerca;
	}




	public void setCodiceFiscaleRicerca(String codiceFiscaleRicerca) {
		this.codiceFiscaleRicerca = codiceFiscaleRicerca;
	}




	public String getCodRegioneRicerca() {
		return codRegioneRicerca;
	}




	public void setCodRegioneRicerca(String codRegioneRicerca) {
		this.codRegioneRicerca = codRegioneRicerca;
	}


	public List<UtenteBean> getListaCandidature() {
		return listaCandidature;
	}




	public void setListaCandidature(List<UtenteBean> listaCandidature) {
		this.listaCandidature = listaCandidature;
	}




	public boolean isMostraRisultatiRicerca() {
		return mostraRisultatiRicerca;
	}




	public void setMostraRisultatiRicerca(boolean mostraRisultatiRicerca) {
		this.mostraRisultatiRicerca = mostraRisultatiRicerca;
	}
	public List<String> getIdCandidatiList() {
		return idCandidatiList;
	}
	public void setIdCandidatiList(List<String> idCandidatiList) {
		this.idCandidatiList = idCandidatiList;
	}
	
	public int getRowIniBlock() {
		return rowIniBlock;
	}
	public void setRowIniBlock(int rowIniBlock) {
		this.rowIniBlock = rowIniBlock;
	}
	public int getRowFinBlock() {
		return rowFinBlock;
	}
	public void setRowFinBlock(int rowFinBlock) {
		this.rowFinBlock = rowFinBlock;
	}
	public int getNumeroCandidati() {
		return numeroCandidati;
	}
	public void setNumeroCandidati(int numeroCandidati) {
		this.numeroCandidati = numeroCandidati;
	}
	public int getNumeroPatine() {
		return numeroPatine;
	}
	public void setNumeroPatine(int numeroPatine) {
		this.numeroPatine = numeroPatine;
	}
	public UtenteRegioni getUtenteReg() {
		return utenteReg;
	}
	public void setUtenteReg(UtenteRegioni utenteReg) {
		this.utenteReg = utenteReg;
	}
	public String getPulsantePagIndietro() {
		return pulsantePagIndietro;
	}
	public void setPulsantePagIndietro(String pulsantePagIndietro) {
		this.pulsantePagIndietro = pulsantePagIndietro;
	}
	public String getPulsantePagAvanti() {
		return pulsantePagAvanti;
	}
	public void setPulsantePagAvanti(String pulsantePagAvanti) {
		this.pulsantePagAvanti = pulsantePagAvanti;
	}
	public int getRowNumerUltimo() {
		return rowNumerUltimo;
	}
	public void setRowNumerUltimo(int rowNumerUltimo) {
		this.rowNumerUltimo = rowNumerUltimo;
	}
	public int getRowBlock() {
		return rowBlock;
	}
	public void setRowBlock(int rowBlock) {
		this.rowBlock = rowBlock;
	}
	public String getTotaleCandidati() {
		return totaleCandidati;
	}
	public void setTotaleCandidati(String totaleCandidati) {
		this.totaleCandidati = totaleCandidati;
	}
	public int getTotalePagine() {
		return totalePagine;
	}
	public void setTotalePagine(int totalePagine) {
		this.totalePagine = totalePagine;
	}
	public int getPaginaCorrente() {
		return paginaCorrente;
	}
	public void setPaginaCorrente(int paginaCorrente) {
		this.paginaCorrente = paginaCorrente;
	}
	public int getTotaleCandidatiInt() {
		return totaleCandidatiInt;
	}
	public void setTotaleCandidatiInt(int totaleCandidatiInt) {
		this.totaleCandidatiInt = totaleCandidatiInt;
	}

	
	

	 
	 
	

}