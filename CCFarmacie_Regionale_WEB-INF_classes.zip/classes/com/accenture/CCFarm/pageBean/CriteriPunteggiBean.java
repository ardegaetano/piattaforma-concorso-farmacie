package com.accenture.CCFarm.pageBean;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.event.FlowEvent;
import org.primefaces.model.UploadedFile;

import com.accenture.CCFarm.action.CriteriPunteggiAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.JSFUtility;


@ManagedBean
@SessionScoped
public class CriteriPunteggiBean {

	Logger logger = CommonLogger.getLogger("CriteriPunteggi");
	CriteriPunteggiAction criteriPunteggi = null;
	String pageError = "errorPage.jsf";
	//Gestione UpLoad
  	private UploadedFile filePunteggiLaurea;
  	private UploadedFile filePunteggiAbilitazione;
  	List<CriteriPunteggiListBean> listCriteriPunteggiLaurea = null;
  	List<CriteriPunteggiListBean> listCriteriPunteggiAbilitazione = null;
	private boolean bCaricaCSV_Laurea = false;
	//private boolean bCSVValido_Laurea = true;
	private boolean bCaricaCSV_Abilitazione = false;
	//private boolean bCSVValido_Abilitazione = true;
	
	private String msgErroreCSV_Laurea = null;
	private String msgErroreCSV_Abilitazione = null;
	
	private boolean bStato = false;
	private boolean bStatoA = false;
			
	private String oldWizardStep;
	private String nextWizardStep;
	
	public CriteriPunteggiBean(){
		criteriPunteggi = new CriteriPunteggiAction();
	}
	
	//Funzioni Bean 
	public void init() {  
		try{
			criteriPunteggi.loadPaginaInserimento(this);
		} catch (GestioneErroriException e) {
			logger.error("CriteriPunteggi - init: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public String back()
	{	
		return "homeRegioni";
		//JSFUtility.redirect("homeRegioni.jsf");
	}
	
	public void uploadCSVLaurea(FileUploadEvent event)
	{	
		try{
			criteriPunteggi.uploadCSV(event, this, GenericConstants.TIPO_PUNTEGGI_LAUREA);
			String sMsg = getMsgErroreCSV_Laurea();
			if(sMsg!=null)
				addMessageError(sMsg);
		} catch (GestioneErroriException e) {
			logger.error("CriteriPunteggi - uploadCSVLaurea: " + e.getMessage(), e);
			JSFUtility.redirect(pageError); 
		}		
	}
	
	public void uploadCSVAbilitazione(FileUploadEvent event)
	{	
		try{
			criteriPunteggi.uploadCSV(event, this, GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE);
			String sMsg = getMsgErroreCSV_Abilitazione();
			if(sMsg!=null)
				addMessageError(sMsg);
		} catch (GestioneErroriException e) {
			logger.error("CriteriPunteggi - uploadCSVAbilitazione: " + e.getMessage(), e);
			JSFUtility.redirect(pageError); 
		}		
	}
	
	public void salvaCriteriLaurea()
	{	
		try{
			String sMsg = criteriPunteggi.salva(this, GenericConstants.TIPO_PUNTEGGI_LAUREA);
			if(sMsg!=null  && !sMsg.equalsIgnoreCase("")){
				addMessageError(sMsg);
			}	
			else {
				addMessage(null, "Salvataggio avvenuto con successo");
				//JSFUtility.redirect("definisciCriteri.jsf");
			}
		} catch (GestioneErroriException e) {
			logger.error("CriteriPunteggi - salvaCriteriLaurea: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void salvaCriteriAbilitazione()
	{	
		try{
			String sMsg = criteriPunteggi.salva(this, GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE);
			if(sMsg!=null  && !sMsg.equalsIgnoreCase("")){
				addMessageError(sMsg);
			}	
			else {
				addMessage(null, "Salvataggio avvenuto con successo");
				//JSFUtility.redirect("definisciCriteri.jsf");
			}
		} catch (GestioneErroriException e) {
			logger.error("CriteriPunteggi - salvaCriteriAbilitazione: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void validaCriteriLaurea()
	{	
		try{
			String sMsg = criteriPunteggi.valida(this, GenericConstants.TIPO_PUNTEGGI_LAUREA);
			if(sMsg!=null  && !sMsg.equalsIgnoreCase("")){
				addMessageError(sMsg);
			}	
			else {
				addMessage(null, "Validazione avvenuta con successo");
				//JSFUtility.redirect("definisciCriteri.jsf");
			}
		} catch (GestioneErroriException e) {
			logger.error("CriteriPunteggi - validaCriteriLaurea: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void validaCriteriAbilitazione()
	{	
		try{
			String sMsg = criteriPunteggi.valida(this, GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE);
			if(sMsg!=null  && !sMsg.equalsIgnoreCase("")){
				addMessageError(sMsg);
			}	
			else {
				addMessage(null, "Validazione avvenuta con successo");
				//JSFUtility.redirect("definisciCriteri.jsf");
			}
		} catch (GestioneErroriException e) {
			logger.error("CriteriPunteggi - validaCriteriAbilitazione: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}
	}
	
	// gestisce il passaggio tra un tab e l'altro del wizard
	public String handleFlow(FlowEvent event)
	{
		oldWizardStep = event.getOldStep();
		nextWizardStep = event.getNewStep();

		return nextWizardStep;
	}
	
	public void addMessage(String Intestazione, String summary) throws GestioneErroriException {
		
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,Intestazione, summary);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
	public void addMessageError(String summary) throws GestioneErroriException {
		
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN,"ATTENZIONE", summary);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}

	public UploadedFile getFilePunteggiLaurea() {
		return filePunteggiLaurea;
	}

	public void setFilePunteggiLaurea(UploadedFile filePunteggiLaurea) {
		this.filePunteggiLaurea = filePunteggiLaurea;
	}

	public UploadedFile getFilePunteggiAbilitazione() {
		return filePunteggiAbilitazione;
	}

	public void setFilePunteggiAbilitazione(UploadedFile filePunteggiAbilitazione) {
		this.filePunteggiAbilitazione = filePunteggiAbilitazione;
	}

	public List<CriteriPunteggiListBean> getListCriteriPunteggiLaurea() {
		return listCriteriPunteggiLaurea;
	}

	public void setListCriteriPunteggiLaurea(
			List<CriteriPunteggiListBean> listCriteriPunteggiLaurea) {
		this.listCriteriPunteggiLaurea = listCriteriPunteggiLaurea;
	}

	public List<CriteriPunteggiListBean> getListCriteriPunteggiAbilitazione() {
		return listCriteriPunteggiAbilitazione;
	}

	public void setListCriteriPunteggiAbilitazione(
			List<CriteriPunteggiListBean> listCriteriPunteggiAbilitazione) {
		this.listCriteriPunteggiAbilitazione = listCriteriPunteggiAbilitazione;
	}

	public boolean isbCaricaCSV_Laurea() {
		return bCaricaCSV_Laurea;
	}

	public void setbCaricaCSV_Laurea(boolean bCaricaCSV_Laurea) {
		this.bCaricaCSV_Laurea = bCaricaCSV_Laurea;
	}

	/*public boolean isbCSVValido_Laurea() {
		return bCSVValido_Laurea;
	}

	public void setbCSVValido_Laurea(boolean bCSVValido_Laurea) {
		this.bCSVValido_Laurea = bCSVValido_Laurea;
	}*/

	public boolean isbCaricaCSV_Abilitazione() {
		return bCaricaCSV_Abilitazione;
	}

	public void setbCaricaCSV_Abilitazione(boolean bCaricaCSV_Abilitazione) {
		this.bCaricaCSV_Abilitazione = bCaricaCSV_Abilitazione;
	}

	/*public boolean isbCSVValido_Abilitazione() {
		return bCSVValido_Abilitazione;
	}

	public void setbCSVValido_Abilitazione(boolean bCSVValido_Abilitazione) {
		this.bCSVValido_Abilitazione = bCSVValido_Abilitazione;
	}*/
	
	public String getMsgErroreCSV_Laurea() {
		return msgErroreCSV_Laurea;
	}

	public void setMsgErroreCSV_Laurea(String msgErroreCSV_Laurea) {
		this.msgErroreCSV_Laurea = msgErroreCSV_Laurea;
	}

	public String getMsgErroreCSV_Abilitazione() {
		return msgErroreCSV_Abilitazione;
	}

	public void setMsgErroreCSV_Abilitazione(String msgErroreCSV_Abilitazione) {
		this.msgErroreCSV_Abilitazione = msgErroreCSV_Abilitazione;
	}

	public boolean isbStato() {
		return bStato;
	}

	public void setbStato(boolean bStato) {
		this.bStato = bStato;
	}

	public boolean isbStatoA() {
		return bStatoA;
	}

	public void setbStatoA(boolean bStatoA) {
		this.bStatoA = bStatoA;
	}
	
}
