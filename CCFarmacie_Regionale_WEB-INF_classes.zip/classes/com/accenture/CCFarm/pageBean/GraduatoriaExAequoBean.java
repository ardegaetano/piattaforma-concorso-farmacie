package com.accenture.CCFarm.pageBean;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import org.primefaces.model.LazyDataModel;

import com.accenture.CCFarm.Bean.GraduatoriaDefinitivaLazyList;
import com.accenture.CCFarm.Bean.GraduatoriaDefinitivaListBean;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaDefinitiva;
import com.accenture.CCFarm.action.GraduatoriaExAequoAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


@ManagedBean
@SessionScoped
public class GraduatoriaExAequoBean
{
	private boolean mostraRisultatiRicerca=false;
	
	
	private Logger logger = CommonLogger.getLogger("ElaboraGraduatoria");
	private final static String pageError = "errorPage.jsf";
	
	private List<GraduatoriaDefinitiva> listGradDefin= null;
	//lista data table	listGradDefinBean
	private List<GraduatoriaDefinitivaListBean> listGradDefinBean= null;
	private List<GraduatoriaDefinitivaListBean> salvaExAequoList= null;
	
	private LazyDataModel<GraduatoriaDefinitivaListBean> graduatorieLazy = null;

	private List<Graduatoria> grdauatoria = null;
	
	private String color[];
	private String abilitaSalva= "false";
	private String abilitaValidazione= "false";
	private String abilitaPulsanteValidazione= "false";
	private String abilitaEsportaPDF= "false";
	
	
	private List<String>  idCandidatiList;
	private int rowBlock= 20;
	private int rowIniBlock= 0;
	private int rowFinBlock= 0;
	private int rowNumerUltimo= 0;
	private int numeroCandidati= 0;
	private int numeroPatine= 0;
	private String totaleCandidati="";
	private int totaleCandidatiInt=0;
	private int totalePagine=0;
	private int paginaCorrente=0;
	private String pulsantePagIndietro= "true";
	private String pulsantePagAvanti= "true";
	private String msgError;
	
	private String pulsanteVaiAexequo= "true";
	private String pulsanteVaiAexequoDisplay= "none";
	
	
	private int startPage;
	private int maxPerPage;
	private int numeroExAequoNonRisolti;
	private String numeroExAequo = "";
	private String validaMessage="";
	
	private String protocolloExaequo="";
	
	private String cognomeExaequo="";
	
	private boolean exAequo;
	UtenteRegioni utenteReg =null ;
	private String codReg = null;
	HttpSession session= null;
	
	GraduatoriaExAequoAction graduatoriaExAequoAction = null;
	public GraduatoriaExAequoBean() 
	{
	    init();
	}
	
	public GraduatoriaExAequoBean(String noInit){}
	
	

//	public void init()
//	{  System.out.println("da togliere");
//	} 
	public void init()
	{
		session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	    utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	    codReg = utenteReg.getCodRegione();
		
		graduatoriaExAequoAction = new GraduatoriaExAequoAction();
		try {
	
			totaleCandidatiInt = graduatoriaExAequoAction.getCountGraduatoria(codReg);
			setTotaleCandidati(""+totaleCandidatiInt);
//			totaleCandidatiInt = Integer.parseInt(totaleCandidati);
			numeroExAequoNonRisolti= graduatoriaExAequoAction.getCountExAequoNonRisolti(codReg);
			if (numeroExAequoNonRisolti>0){
				numeroExAequo="  -   Ci sono "+numeroExAequoNonRisolti+" candidarute in ExAequo non risolti ";
				pulsanteVaiAexequo= "false";
				pulsanteVaiAexequoDisplay= "block";
			} else {
				numeroExAequo="";
				pulsanteVaiAexequo= "true";
				pulsanteVaiAexequoDisplay= "none";
			}
			
			abilitaSalva="true";
	//		abilitaValidazione= "true";
			abilitaValidazione= graduatoriaExAequoAction.abilitaValidaGraduatorXStorico(this);
			abilitaPulsanteValidazione = graduatoriaExAequoAction.abilitaPulsanteValidaGradXStorico(this);
			if (abilitaSalva.equalsIgnoreCase("true") && abilitaPulsanteValidazione.equalsIgnoreCase("true")){
				abilitaEsportaPDF = "false";
			} else {
				abilitaEsportaPDF= "true";
			}
			
			if(totaleCandidatiInt>0) {
				paginaCorrente=1;
				if (totaleCandidatiInt>rowBlock){
					totalePagine= totaleCandidatiInt / rowBlock;
					int remainderInt= 0;
					    remainderInt = totaleCandidatiInt % rowBlock;
					if (remainderInt>0){
						totalePagine++;
					}
	//				
				} else {
					totalePagine=1;
				}
				setRowIniBlock(0);
				setRowFinBlock(rowBlock);
				if (totaleCandidatiInt<rowBlock){
					rowBlock=totaleCandidatiInt;
					setRowFinBlock(rowBlock);
				}
				setNumeroCandidati(totaleCandidatiInt);
			    if (numeroCandidati==rowBlock || numeroCandidati<rowBlock ){
			    	setPulsantePagAvanti("true");
			    	setPulsantePagIndietro("true");
			    } else {
			    	setPulsantePagAvanti("false");
			    	setPulsantePagIndietro("true");
			    }
			    	
				mostraRisultatiRicerca=true;
//			    paginaInizio();
				primaPaginaDaSalvare();
			    
			}
			
		} catch (GestioneErroriException e) {

			JSFUtility.redirect(pageError);
		}
		
		
	}
	
	public String primaPaginaDaSalvare() {
		
		try{
			startPage=0;
			maxPerPage=rowBlock;
			rowNumerUltimo=0;
//			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoriDefin(this, this.startPage, this.maxPerPage, "paginaAvanti");
			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoria(this, this.startPage, this.maxPerPage, "paginaAvanti");
//			Collections.sort(listGradDefinBean);
			if (abilitaSalva.equalsIgnoreCase("true") && abilitaValidazione.equalsIgnoreCase("true")){
				if (!graduatoriaExAequoAction.getRettificati(this)){
					while (true) {
						paginaAvanti();
						if (abilitaSalva.equalsIgnoreCase("false")){
							break;
						}
					}
				}
			}
			if (abilitaSalva.equalsIgnoreCase("true") && abilitaPulsanteValidazione.equalsIgnoreCase("true")){
				abilitaEsportaPDF = "false";
			} else {
				abilitaEsportaPDF= "true";
			}
//			JSFUtility.update("linkPDF");
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaExAequoBean- paginaInizio : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
			
		return null;
	}
	
	
	
	public String vaiProssimoExAequo() {
		setRowIniBlock(getRowNumerUltimo());
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente++;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowFinBlock()== getNumeroCandidati() || getRowFinBlock()>getNumeroCandidati()){
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");

		}

		
		startPage=getRowNumerUltimo()+1;
		maxPerPage=rowBlock;
		if (rowNumerUltimo<rowBlock) startPage=0;
		try {
			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoria(this, this.startPage, this.maxPerPage, "paginaAvanti");
			if (abilitaSalva.equalsIgnoreCase("true") && abilitaValidazione.equalsIgnoreCase("true")){
				if (!graduatoriaExAequoAction.getRettificati(this)){
					while (true) {
						int numRow = startPage + maxPerPage;
						if (numRow > totaleCandidatiInt){
							init();
						} else{
							paginaAvanti();	
						}
						if (abilitaSalva.equalsIgnoreCase("false")){
							break;
						}
					}
				}
			}
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaExAequoBean - paginaAvanti : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		
			
		return null;
	}
	

	
	public String paginaInizio() {
		
		try{
			startPage=0;
			maxPerPage=rowBlock;
			rowNumerUltimo=0;
//			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoriDefin(this, this.startPage, this.maxPerPage, "paginaAvanti");
			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoria(this, this.startPage, this.maxPerPage, "paginaAvanti");
//			Collections.sort(listGradDefinBean);
			
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaExAequoBean- paginaInizio : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
			
		return null;
	}	
	
	
	public String paginaAvanti() {
		setRowIniBlock(getRowNumerUltimo());
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente++;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowFinBlock()== getNumeroCandidati() || getRowFinBlock()>getNumeroCandidati()){
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");

		}

		
		startPage=getRowNumerUltimo()+1;
		maxPerPage=rowBlock;
		if (rowNumerUltimo<rowBlock) startPage=0;
		try {
//			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoriDefin(this, this.startPage, this.maxPerPage, "paginaAvanti");
			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoria(this, this.startPage, this.maxPerPage, "paginaAvanti");
//			Collections.sort(listGradDefinBean);
			
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaExAequoBean - paginaAvanti : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		
			
		return null;
	}
	
	public String ultimaPagina() {
		rowFinBlock=getNumeroCandidati();
		setRowIniBlock(getRowFinBlock()-getRowBlock());
		
		paginaCorrente=totalePagine;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

    	if (getRowFinBlock()== getNumeroCandidati() || getRowFinBlock()>getNumeroCandidati()){
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");
    	}
		
		startPage=totaleCandidatiInt-rowBlock+1;
		maxPerPage=rowBlock;
		rowNumerUltimo=totaleCandidatiInt;
		try {
//			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoriDefin(this, this.startPage, this.maxPerPage, "paginaAvanti");
			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoria(this, this.startPage, this.maxPerPage, "paginaAvanti");
//			Collections.sort(listGradDefinBean);
			
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaExAequoBean - ultimaPagina : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		
		return null;
	}

	
	
	public String pirmaPagina() {
		rowIniBlock=0;
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente=1;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowIniBlock()== 0 || getRowIniBlock()<0){
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
	    	setPulsantePagIndietro("true");

		}
		
		paginaInizio();
		return null;
	}
	
	
	public String paginaIndietro() {
		rowIniBlock=rowIniBlock-rowBlock;
//		setRowIniBlock(getRowFinBlock()-getRowBlock());
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
//		int skipCandidati = getRowIniBlock();
//		
//		skipCandidati=skipCandidati+rowBlock;
		paginaCorrente--;
		if (paginaCorrente==0) paginaCorrente=1;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowIniBlock()== 0 || getRowIniBlock()<0){
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
	    	setPulsantePagIndietro("true");
		}
		
		startPage=startPage-rowBlock;
		maxPerPage=rowBlock;
		if(startPage<0)startPage=0;
		try {
//			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoriDefin(this, this.startPage, this.maxPerPage, "paginaIndietro" );
			listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoria(this, this.startPage, this.maxPerPage, "paginaIndietro" );
//			Collections.sort(listGradDefinBean);
			
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaExAequoBean - paginaIndietro : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		return null;
	}
	
	
	
	public String getTipoGraduatoria (){
		try {
			graduatoriaExAequoAction.getTipoGraduatoriaMessage(this);
//			JSFUtility.executeScript("dlg3.show()");
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaExAequoBean - getTipoGraduatoria : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		
		return null;
		
	}
	
	
	
	
	
		
	public String salvaExAequo()
	{
		
		try {
//			boolean esito=graduatoriaExAequoAction.risolviExAequo(this);
			msgError= "";
			boolean esito=graduatoriaExAequoAction.risolviExAequoDB(this);
			 
			 if (esito){
//				 listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoriDefin(this, this.startPage, this.maxPerPage, "aggiornaLista" );
				 listGradDefinBean = graduatoriaExAequoAction.getPageGraduatoria(this, this.startPage, this.maxPerPage, "aggiornaLista" );
//				 Collections.sort(listGradDefinBean);
					
				 abilitaValidazione= graduatoriaExAequoAction.abilitaValidaGraduatorXStorico(this);
				 abilitaPulsanteValidazione = graduatoriaExAequoAction.abilitaPulsanteValidaGradXStorico(this);
				 if (abilitaSalva.equalsIgnoreCase("false") && abilitaPulsanteValidazione.equalsIgnoreCase("true")){
				 	abilitaEsportaPDF = "false";
				 } else {
				 	abilitaEsportaPDF= "true";
				 }
				 numeroExAequoNonRisolti= graduatoriaExAequoAction.getCountExAequoNonRisolti(codReg);
				 if (numeroExAequoNonRisolti>0){
			  		numeroExAequo="  - Esistono ExAequo n�"+numeroExAequoNonRisolti+" non risolti ";
			  		pulsanteVaiAexequo= "false";
			  		pulsanteVaiAexequoDisplay= "block";
				 } else {
			 		numeroExAequo="";
			 		pulsanteVaiAexequo= "true";
			 		pulsanteVaiAexequoDisplay= "none";
				 }	
				 JSFUtility.addInfoMessage("","Salvataggio avvenuto con successo.");
			 } else{
				 if (msgError.equalsIgnoreCase("M01")){
					 JSFUtility.addWarningMessage("", "Non � possibile assegnare una stessa posizione a pi� candidature.");
				 }
				 if (msgError.equalsIgnoreCase("M02")){
					 JSFUtility.addWarningMessage("", "Non � possibile assegnare una posizione fuori dall'intervallo previsto dall'Ex Aequo.");	 
				 }
				 if (msgError.equalsIgnoreCase("M03")){
					 JSFUtility.addWarningMessage("", "Non � possibile assegnare una posizione gi� occupata da un'altra candidatura.");	 
				 }	 
				 	 
			 }
			 
//			 graduatoriaExAequoAction.getGraduatoriaDefinitiva(this);
			 JSFUtility.update("linkPDF");
			 
		} catch (GestioneErroriException e) {
			//JSFUtility.redirect(pageError);
			return pageError;	
		}
		
		
		return null;
	}
	
	public String validaExAequo()
	{
		
		try {
			graduatoriaExAequoAction.validaGraduatorXStoricoProva(this); 
			JSFUtility.addInfoMessage("","Validazione avvenuta con successo.");
				 
		} catch (GestioneErroriException e) {
			//JSFUtility.redirect(pageError);
			return pageError;	}
		
		return null;
	}
	
	
	public String validaExAequoStorico()
	{
		
		try {
			graduatoriaExAequoAction.validaGraduatorXStorico(this); 
			abilitaPulsanteValidazione = graduatoriaExAequoAction.abilitaPulsanteValidaGradXStorico(this);
//			if (abilitaValidazione.equalsIgnoreCase("ture") && abilitaPulsanteValidazione.equalsIgnoreCase("true")){
			if (abilitaSalva.equalsIgnoreCase("true") && abilitaPulsanteValidazione.equalsIgnoreCase("true")){
				abilitaEsportaPDF = "false";
			} else {
				abilitaEsportaPDF= "true";
			}
			JSFUtility.addInfoMessage("","Validazione avvenuta con successo.");
				 
		} catch (GestioneErroriException e) {
			//JSFUtility.redirect(pageError);
			return pageError;	}
		JSFUtility.update("linkPDF");
		return null;
	}
	
	public String cerca(){
		
		try {
			grdauatoria = new ArrayList<Graduatoria>();
			GraduatoriaDefinitivaListBean graduatoriaDefinitivaListBean;
			if(!this.getProtocolloExaequo().equalsIgnoreCase("")||!this.getCognomeExaequo().equalsIgnoreCase("")||this.exAequo){
				if(!this.getProtocolloExaequo().equalsIgnoreCase("")&&this.getProtocolloExaequo().length()<5){
					JSFUtility.addWarningMessage("", "Il numero minimo di caratteri per il Numero protocollo � pari a 5");
				}else{
					grdauatoria = graduatoriaExAequoAction.cerca(this);
					listGradDefinBean = new ArrayList<GraduatoriaDefinitivaListBean>();
					for(Graduatoria g : grdauatoria ){
					    graduatoriaDefinitivaListBean = new GraduatoriaDefinitivaListBean();
						if(isExAequo()){
							graduatoriaDefinitivaListBean.setIndiceSpinner("true");
							graduatoriaDefinitivaListBean.setIndiceView("false");
							graduatoriaDefinitivaListBean.setColorRow("red");
						}
						graduatoriaDefinitivaListBean.setIndiceSave(g.getIndiceTotale());
						PropertyUtils.copyProperties( graduatoriaDefinitivaListBean, g);
						listGradDefinBean.add(graduatoriaDefinitivaListBean);
					}
				}
				
			
			}else{
				init();
			}
			
		} catch (GestioneErroriException e) {
			// TODO Auto-generated catch block
			return pageError;
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			return pageError;
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			return pageError;
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			return pageError;
		}
		
		return null;
	}
	
	public String indietro()
	{
		//JSFUtility.redirect("homeRegioni.jsf");
		return "homeRegioni";
	}

	
	public boolean isMostraRisultatiRicerca() {
		return mostraRisultatiRicerca;
	}

	public void setMostraRisultatiRicerca(boolean mostraRisultatiRicerca) {
		this.mostraRisultatiRicerca = mostraRisultatiRicerca;
	}

	public List<GraduatoriaDefinitiva> getListGradDefin() {
		return listGradDefin;
	}

	public void setListGradDefin(List<GraduatoriaDefinitiva> listGradDefin) {
		this.listGradDefin = listGradDefin;
	}

	public String[] getColor() {
		return color;
	}

	public void setColor(String[] color) {
		this.color = color;
	}

	public UtenteRegioni getUtenteReg() {
		return utenteReg;
	}

	public void setUtenteReg(UtenteRegioni utenteReg) {
		this.utenteReg = utenteReg;
	}

	public String getCodReg() {
		return codReg;
	}

	public void setCodReg(String codReg) {
		this.codReg = codReg;
	}

	public HttpSession getSession() {
		return session;
	}

	public void setSession(HttpSession session) {
		this.session = session;
	}

	public List<GraduatoriaDefinitivaListBean> getListGradDefinBean() {
		return listGradDefinBean;
	}

	public void setListGradDefinBean(
			List<GraduatoriaDefinitivaListBean> listGradDefinBean) {
		this.listGradDefinBean = listGradDefinBean;
	}

	public String getAbilitaSalva() {
		return abilitaSalva;
	}

	public void setAbilitaSalva(String abilitaSalva) {
		this.abilitaSalva = abilitaSalva;
	}

	public List<GraduatoriaDefinitivaListBean> getSalvaExAequoList() {
		return salvaExAequoList;
	}

	public void setSalvaExAequoList(
			List<GraduatoriaDefinitivaListBean> salvaExAequoList) {
		this.salvaExAequoList = salvaExAequoList;
	}

	public String getAbilitaValidazione() {
		return abilitaValidazione;
	}

	public void setAbilitaValidazione(String abilitaValidazione) {
		this.abilitaValidazione = abilitaValidazione;
	}
	
	public String getAbilitaPulsanteValidazione() {
		return abilitaPulsanteValidazione;
	}

	public void setAbilitaPulsanteValidazione(String abilitaPulsanteValidazione) {
		this.abilitaPulsanteValidazione = abilitaPulsanteValidazione;
	}

	
	
	public String getAbilitaEsportaPDF() {
		return abilitaEsportaPDF;
	}

	public void setAbilitaEsportaPDF(String abilitaEsportaPDF) {
		this.abilitaEsportaPDF = abilitaEsportaPDF;
	}

	public List<String> getIdCandidatiList() {
		return idCandidatiList;
	}

	public void setIdCandidatiList(List<String> idCandidatiList) {
		this.idCandidatiList = idCandidatiList;
	}

	public int getRowBlock() {
		return rowBlock;
	}

	public void setRowBlock(int rowBlock) {
		this.rowBlock = rowBlock;
	}

	public int getRowIniBlock() {
		return rowIniBlock;
	}

	public void setRowIniBlock(int rowIniBlock) {
		this.rowIniBlock = rowIniBlock;
	}

	public int getRowFinBlock() {
		return rowFinBlock;
	}

	public void setRowFinBlock(int rowFinBlock) {
		this.rowFinBlock = rowFinBlock;
	}

	public int getRowNumerUltimo() {
		return rowNumerUltimo;
	}

	public void setRowNumerUltimo(int rowNumerUltimo) {
		this.rowNumerUltimo = rowNumerUltimo;
	}

	public int getNumeroCandidati() {
		return numeroCandidati;
	}

	public void setNumeroCandidati(int numeroCandidati) {
		this.numeroCandidati = numeroCandidati;
	}

	public int getNumeroPatine() {
		return numeroPatine;
	}

	public void setNumeroPatine(int numeroPatine) {
		this.numeroPatine = numeroPatine;
	}

	public String getTotaleCandidati() {
		return totaleCandidati;
	}

	public void setTotaleCandidati(String totaleCandidati) {
		this.totaleCandidati = totaleCandidati;
	}

	public int getTotaleCandidatiInt() {
		return totaleCandidatiInt;
	}

	public void setTotaleCandidatiInt(int totaleCandidatiInt) {
		this.totaleCandidatiInt = totaleCandidatiInt;
	}

	public int getTotalePagine() {
		return totalePagine;
	}

	public void setTotalePagine(int totalePagine) {
		this.totalePagine = totalePagine;
	}

	public int getPaginaCorrente() {
		return paginaCorrente;
	}

	public void setPaginaCorrente(int paginaCorrente) {
		this.paginaCorrente = paginaCorrente;
	}

	public String getPulsantePagIndietro() {
		return pulsantePagIndietro;
	}

	public void setPulsantePagIndietro(String pulsantePagIndietro) {
		this.pulsantePagIndietro = pulsantePagIndietro;
	}

	public String getPulsantePagAvanti() {
		return pulsantePagAvanti;
	}

	public void setPulsantePagAvanti(String pulsantePagAvanti) {
		this.pulsantePagAvanti = pulsantePagAvanti;
	}

	public LazyDataModel<GraduatoriaDefinitivaListBean> getGraduatorieLazy() {
		return graduatorieLazy;
	}

	public void setGraduatorieLazy(
			LazyDataModel<GraduatoriaDefinitivaListBean> graduatorieLazy) {
		this.graduatorieLazy = graduatorieLazy;
	}


	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getMaxPerPage() {
		return maxPerPage;
	}

	public void setMaxPerPage(int maxPerPage) {
		this.maxPerPage = maxPerPage;
	}
	
	public String getMsgError() {
		return msgError;
	}

	public void setMsgError(String msgError) {
		this.msgError = msgError;
	}

	public int getNumeroExAequoNonRisolti() {
		return numeroExAequoNonRisolti;
	}

	public void setNumeroExAequoNonRisolti(int numeroExAequoNonRisolti) {
		this.numeroExAequoNonRisolti = numeroExAequoNonRisolti;
	}

	public String getNumeroExAequo() {
		return numeroExAequo;
	}

	public void setNumeroExAequo(String numeroExAequo) {
		this.numeroExAequo = numeroExAequo;
	}

	public String getValidaMessage() {
		return validaMessage;
	}

	public void setValidaMessage(String validaMessage) {
		this.validaMessage = validaMessage;
	}

	public String getPulsanteVaiAexequo() {
		return pulsanteVaiAexequo;
	}

	public void setPulsanteVaiAexequo(String pulsanteVaiAexequo) {
		this.pulsanteVaiAexequo = pulsanteVaiAexequo;
	}

	public String getPulsanteVaiAexequoDisplay() {
		return pulsanteVaiAexequoDisplay;
	}

	public void setPulsanteVaiAexequoDisplay(String pulsanteVaiAexequoDisplay) {
		this.pulsanteVaiAexequoDisplay = pulsanteVaiAexequoDisplay;
	}

	
	public String getProtocolloExaequo() {
		return protocolloExaequo;
	}

	public void setProtocolloExaequo(String protocolloExaequo) {
		this.protocolloExaequo = protocolloExaequo;
	}

	public String getCognomeExaequo() {
		return cognomeExaequo;
	}

	public void setCognomeExaequo(String cognomeExaequo) {
		this.cognomeExaequo = cognomeExaequo;
	}

	public List<Graduatoria> getGrdauatoria() {
		return grdauatoria;
	}

	public void setGrdauatoria(List<Graduatoria> grdauatoria) {
		this.grdauatoria = grdauatoria;
	}

	public boolean isExAequo() {
		return exAequo;
	}

	public void setExAequo(boolean exAequo) {
		this.exAequo = exAequo;
	}
	
	
	
	 

//	public LazyDataModel<GraduatoriaDefinitivaListBean> getGraduatoriaDefinitivaListBean() {
//		
//	//	
//			try
//			{
//				if(graduatorieLazy==null){
//					graduatorieLazy = new GraduatoriaDefinitivaLazyList();
//				}
//			
//			}
//			catch(Exception e)
//			{
//				JSFUtility.redirect(pageError);
//			}
//				
//			
//			return graduatorieLazy;
//		}	
//			
}