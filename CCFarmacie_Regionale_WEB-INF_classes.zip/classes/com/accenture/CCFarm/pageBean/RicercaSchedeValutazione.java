package com.accenture.CCFarm.pageBean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.component.dialog.Dialog;
import org.primefaces.component.tabview.Tab;

import com.accenture.CCFarm.Bean.Osservazione;
import com.accenture.CCFarm.DAO.CandidaturaReg;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.DAO.UtenteCandidaturaRegHome;
import com.accenture.CCFarm.DAO.UtenteReg;
import com.accenture.CCFarm.DAO.UtenteRegHome;
import com.accenture.CCFarm.action.CalcolaPunteggiAutomaticiAction;
import com.accenture.CCFarm.action.RicercaSchedaValutazioneAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CaricaOsservazioni;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


@ManagedBean
@SessionScoped
public class RicercaSchedeValutazione
{	
	private String idUtente;
	private String nome;
	private String cognome;	
	private String codiceFiscale;
	private String protocollo;
	private String candidatura;
	private String documentazionePrevista;
	private String documentazionePervenuta;
	private String codOsservazioni;
	
	// campi ricerca aggiunti
	private String nomeRicerca;
	private String cognomeRicerca;
	private String candidaturaRicerca;
	
	private String parametroOrdinamento;
	
	
	private String testoDettaglioOsservazioni;
	private Dialog dialogOsservazioni;
	
	private String testoDialogRettifica;
	private Dialog dialogRettifica;
	
	private String mostraDialogSingola="true";
	private String idCandRettifica;
	
	private Dialog dialogCompilaDomanda;
	
	private String osservazioneStringa;
	private String punteggio;
	private Date dataIstruttoria;
	private String dataIstruttoria_string;
	
	private boolean mostraRisultatiRicerca;
	
	private Osservazione osservazioneSelezionata;
	private List<Osservazione> osservazioni;
	
	private String[]listaHelp;
	
	private List<String>  idSchedeList;
	List<RicercaSchedeValutazione>  idProtocolliList;
	private String totaleSchede;
	private String parzialeSchede;
	
	List<RicercaSchedeValutazione> listaSchede;
	List<UtenteReg> listaUtentiAssociati;
	private UtenteReg utenteAssociatoSelezionato;
	
	private String idUtenteRettifica;
	
	
	private int rowBlock= 20;
	private int rowIniBlock= 0;
	private int rowFinBlock= 0;
	private int rowNumerUltimo= 0;
	private int numeroSchede= 0;
	private int totaleSchedeInt=0;
	private int totalePagine=0;
	private int paginaCorrente=0;
	private String pulsantePagIndietro= "true";
	private String pulsantePagAvanti= "true";
	public String disabilitaConferma="";
	RicercaSchedaValutazioneAction ricercaSchedaValutazioneAction;
	CalcolaPunteggiAutomaticiAction calcolaPunteggiAutomaticiAction;
	ElaboraGraduatoria elaboraGraduatoria;
	private SchedaValutazioneBean schedaValutazioneBean;
		 
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	String cod_reg = utenteReg.getCodRegione();
	 
	private Logger logger = CommonLogger.getLogger("RicercaSchedaValutazione");
	private final static String pageError = "errorPage.jsf";
	
	public RicercaSchedeValutazione() 
	{
		//ricercaSchedaValutazioneAction=new RicercaSchedaValutazioneAction();
		
	    init();
	}
	
	
	public RicercaSchedeValutazione(String noInit){}
	
	
	public void init()
	{
		try
		{
			osservazioni = CaricaOsservazioni.getOsservazioni();	
			setListaHelp(Help.caricaHelpElaboraGraduatoria());
			mostraRisultatiRicerca = false;
			totaleSchede="";
			parzialeSchede="0";	
			ricercaSchedaValutazioneAction=new RicercaSchedaValutazioneAction();
	//		List<String> listaTotaleSchede = (List<String>) ricercaSchedaValutazioneAction.ricercaSchedeAll(this);
	//		totaleSchede = ""+listaTotaleSchede.size();
//			totaleSchede = ""+100;
			idSchedeList= new ArrayList<String>();
	//		idSchedeList = listaTotaleSchede;
			schedaValutazioneBean=new SchedaValutazioneBean();
			/*if(ricercaSchedaValutazioneAction.checKTipoGraduatoria(this.cod_reg)){
				this.setDisabilitaConferma("true");
			}else{
				this.setDisabilitaConferma("false");
			}*/
			
		}
		catch (GestioneErroriException e)
		{
			logger.error("Eccezione in Ricerca Schede: " + e.getMessage());
			//JSFUtility.redirect(pageError);
		}
	}
	
	//apre pannello dialog con il dettaglio delle osservazioni per la candidatura selezionata
	public void visualizzaDettaglioOsservazioni()
	{
		String idCandidatura=(String)GetSessionUtility.getRequestParameter("idCandidaturaOsservazioni");
		
		testoDettaglioOsservazioni=null;
		
		for(RicercaSchedeValutazione scheda: listaSchede)
		{
			if (scheda.getIdUtente().equalsIgnoreCase(idCandidatura))
			{
				testoDettaglioOsservazioni = scheda.getOsservazioneStringa();
				dialogOsservazioni.setHeader("Dettaglio osservazioni per la candidatura con n� protocollo:  "+scheda.getProtocollo());
				
				break;
			}
		}
		
		if(testoDettaglioOsservazioni==null)
		{
			dialogOsservazioni.setHeader("Dettaglio osservazioni");
			testoDettaglioOsservazioni="Nessuna osservazione disponibile";
		}
		
		JSFUtility.executeScript("dialogOsservazioni.show()");
		JSFUtility.update("dialogOsservazioni");

	}
	
	
	public String checkGraduatoria(){
		
		String check="";
		try
		{
		   check=ricercaSchedaValutazioneAction.checkGraduatoria(cod_reg);			
		}
		catch(Exception e)
		{
			logger.error("Eccezione in Ricerca Schede: " + LogUtil.printException(e));
			JSFUtility.addWarningMessage("","Errore durante la ricerca delle schede");
		}
		
		return check;
	}
	
	
	public void pulisciFiltri()
	{
		nome="";
		cognome="";	
		codiceFiscale="";
		protocollo="";
		candidatura="";
		documentazionePrevista="";
		documentazionePervenuta="";
		codOsservazioni="";
		nomeRicerca="";
		cognomeRicerca="";
		candidaturaRicerca="";
		
		mostraRisultatiRicerca = false;
	}
	
	public void cercaSchede1(){
		setParametroOrdinamento("G.NUMERO_PROTOCOLLO DESC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede2(){
		setParametroOrdinamento("G.NUMERO_PROTOCOLLO ASC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede3(){
		setParametroOrdinamento("UPPER(U.COGNOME_UTENTE) DESC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede4(){
		setParametroOrdinamento("UPPER(U.COGNOME_UTENTE) ASC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede5(){
		setParametroOrdinamento("UPPER(U.NOME_UTENTE) DESC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede6(){
		setParametroOrdinamento("UPPER(U.NOME_UTENTE) ASC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede7(){
		setParametroOrdinamento("C.MODALITA_CANDIDATURA DESC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede8(){
		setParametroOrdinamento("C.MODALITA_CANDIDATURA ASC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede9(){
		setParametroOrdinamento("G.PUNTEGGIO DESC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede10(){
		setParametroOrdinamento("G.PUNTEGGIO ASC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede11(){
		setParametroOrdinamento("D.FLAG_CONF_DOC_DIC DESC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede12(){
		setParametroOrdinamento("D.FLAG_CONF_DOC_DIC ASC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede13(){
		setParametroOrdinamento("D.DOC_PERVENUTA DESC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede14(){
		setParametroOrdinamento("D.DOC_PERVENUTA ASC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede15(){
		setParametroOrdinamento("G.DATA_ISTRUTTORIA DESC");
		cercaSchede("withParam");
	}
	
	public void cercaSchede16(){
		setParametroOrdinamento("G.DATA_ISTRUTTORIA ASC");
		cercaSchede("withParam");
	}
	
	
	
	public void cercaSchede()
	{
		setParametroOrdinamento("G.NUMERO_PROTOCOLLO DESC");
		String check = this.checkGraduatoria();
		//performance pessima
		if (check.equalsIgnoreCase("")){
			
				try
			    {
			    	rowBlock=20;
			    	
			    	idSchedeList= (List<String>) ricercaSchedaValutazioneAction.ricercaSchedeAll(this);			    	
			    	totaleSchede=""+idSchedeList.size();
			    	totaleSchedeInt = Integer.parseInt(totaleSchede);
			    	
			    	if(idSchedeList.size()>0) {
						paginaCorrente=1;
						if (totaleSchedeInt>rowBlock){
							totalePagine= totaleSchedeInt / rowBlock;
							int remainderInt= 0;
							    remainderInt = totaleSchedeInt % rowBlock;
							if (remainderInt>0){
								totalePagine++;
							}
							
						} else {
							totalePagine=1;
						}
						setRowIniBlock(0);
						setRowFinBlock(rowBlock);
						if (idSchedeList.size()<rowBlock){
							rowBlock=idSchedeList.size();
							setRowFinBlock(rowBlock);
						}
						setNumeroSchede(idSchedeList.size());
					    if (numeroSchede==rowBlock || numeroSchede<rowBlock ){
					    	setPulsantePagAvanti("true");
					    	setPulsantePagIndietro("true");
					    } else {
					    	setPulsantePagAvanti("false");
					    	setPulsantePagIndietro("true");
					    }
					    	
					    listaSchede = ricercaSchedaValutazioneAction.ricercaSchede(this);
						mostraRisultatiRicerca=true;
						if (listaSchede != null)
							parzialeSchede = "" + listaSchede.size();
					}
			    	
			    	else if(idSchedeList.size()==0){
			    		listaSchede = null;
			    		mostraRisultatiRicerca=true;
			    		
			    		
			    		if (this.getProtocollo()!=null && !this.getProtocollo().equals("")){
							
			    			idProtocolliList= (List<RicercaSchedeValutazione>)ricercaSchedaValutazioneAction.check_protocollo(this);
			    			if (idProtocolliList.size()>0){
			    				listaSchede = idProtocolliList;
			    				JSFUtility.addWarningMessage("","Attenzione! Il numero protocollo cercato � stato sostituito con quello visualizzato in elenco");
			    				
			    			}
						}
			    		
			    	}
			    				    	
			    	JSFUtility.scrollTo("candidature");
				}
				catch (Exception e)
			    {
			    	logger.error("Eccezione in Ricerca Schede: " + LogUtil.printException(e));
					JSFUtility.addWarningMessage("","Errore durante la ricerca delle schede");
					JSFUtility.scrollTo("msgs");
				}
			}
		
		else {
			JSFUtility.addWarningMessage("",check);
			JSFUtility.scrollTo("msgs");
		}
	}
	
	public void cercaSchede(String param)
	{
		
		String check = this.checkGraduatoria();
		//performance pessima
		if (check.equalsIgnoreCase("")){
			
				try
			    {
			    	rowBlock=20;
			    	
			    	idSchedeList= (List<String>) ricercaSchedaValutazioneAction.ricercaSchedeAll(this);			    	
			    	totaleSchede=""+idSchedeList.size();
			    	totaleSchedeInt = Integer.parseInt(totaleSchede);
			    	
			    	if(idSchedeList.size()>0) {
						paginaCorrente=1;
						if (totaleSchedeInt>rowBlock){
							totalePagine= totaleSchedeInt / rowBlock;
							int remainderInt= 0;
							    remainderInt = totaleSchedeInt % rowBlock;
							if (remainderInt>0){
								totalePagine++;
							}
							
						} else {
							totalePagine=1;
						}
						setRowIniBlock(0);
						setRowFinBlock(rowBlock);
						if (idSchedeList.size()<rowBlock){
							rowBlock=idSchedeList.size();
							setRowFinBlock(rowBlock);
						}
						setNumeroSchede(idSchedeList.size());
					    if (numeroSchede==rowBlock || numeroSchede<rowBlock ){
					    	setPulsantePagAvanti("true");
					    	setPulsantePagIndietro("true");
					    } else {
					    	setPulsantePagAvanti("false");
					    	setPulsantePagIndietro("true");
					    }
					    	
					    listaSchede = ricercaSchedaValutazioneAction.ricercaSchede(this);
						mostraRisultatiRicerca=true;
						if (listaSchede != null)
							parzialeSchede = "" + listaSchede.size();
					}
			    	
			    	else if(idSchedeList.size()==0){
			    		listaSchede = null;
			    		mostraRisultatiRicerca=true;
			    	}
			    	
			    	JSFUtility.scrollTo("candidature");			    	
				}
				catch (Exception e)
			    {
			    	logger.error("Eccezione in Ricerca Schede: " + LogUtil.printException(e));
					JSFUtility.addWarningMessage("","Errore durante la ricerca delle schede");
					JSFUtility.scrollTo("msgs");
				}
			}
		
		else {
			JSFUtility.addWarningMessage("",check);
			JSFUtility.scrollTo("msgs");
		}
	}
	
	public void apriScheda()
	{
		String idCandidatura=(String)GetSessionUtility.getRequestParameter("idCandidaturaScheda");
		
		try
		{
			//trova la lista dei candidati associati alla domanda selezionata e avvia il calcolo dei punteggi
			List<UtenteCandidaturaReg> listaUtenti=new UtenteCandidaturaRegHome().findUtenteCandidaturaByQuery(idCandidatura);
			
			//recupera il bean di schedaValutazione dal bean principale della pagina
			ElaboraGraduatoria elaboraGraduatoria=(ElaboraGraduatoria)GetSessionUtility.getSessionAttribute("elaboraGraduatoria");
			SchedaValutazioneBean schedaValutazione=elaboraGraduatoria.getSchedaValutazioneBean();
			
			//imposta la lista di utenti e avvia il calcolo dei punteggi
			schedaValutazione.setIdCandidatura(idCandidatura);
			schedaValutazione.setUtenteCandidaturaList(listaUtenti);
			schedaValutazione.setCodReg(cod_reg);
			schedaValutazione.init();
			
			//apre la scheda di valutazione del candidato
			JSFUtility.executeScript("viewsValutazioni.next()");
			JSFUtility.scrollTo("viewsValutazioni");
			
		}
		catch(Exception e)
		{
			logger.error("Eccezione in Apri Scheda: " + e.getMessage());
			JSFUtility.addWarningMessage("","Errore durante il recupero delle informazioni della scheda");
			JSFUtility.scrollTo("msgs");
		}
	}
	
	public void chiudiScheda()
	{
		JSFUtility.executeScript("viewsValutazioni.back()");
		//JSFUtility.executeScript("window.location.reload()");
		//nascondi elenco candidature
//		mostraRisultatiRicerca=false;
		mostraRisultatiRicerca=true;
		JSFUtility.update("candidature");
		
		JSFUtility.scrollTo("viewsValutazioni");
	}
	
	public String selezionaSchedaRett()
	{
		String idCandidatura=(String)GetSessionUtility.getRequestParameter("idCandidaturaRettifica");
		
		CandidaturaRegHome candHome = new CandidaturaRegHome();
		CandidaturaReg scheda_selezionata = new CandidaturaReg();
		scheda_selezionata.setIdCandidatura(idCandidatura);
		UtenteRegHome utenteHome = new UtenteRegHome();
		
		ArrayList<CandidaturaReg> listaCandidature = new ArrayList<CandidaturaReg>();
		try
		{
			listaCandidature=candHome.findByExample(scheda_selezionata);
		}
		catch(Exception ex)
		{
			logger.error("Eccezione in Ricerca Schede: " + ex.getMessage());
			return pageError;
		} 

		if (listaCandidature.size()==1)
		{
			// candidatura singola --> va direttamente in rettifica domanda
			
			dialogRettifica.setHeader("Controllo Domanda");
			testoDialogRettifica="Per controllare la domanda dell'utente selezionato premere Conferma";
			
			//individua se possibile il nominativo dell'utente selezionato
			try
			{
				UtenteReg utenteSelezionato = utenteHome.findById(listaCandidature.get(0).getIdUtente());
				testoDialogRettifica=testoDialogRettifica.replace("selezionato",utenteSelezionato.getNomeUtente()+" "+utenteSelezionato.getCognomeUtente());
			}
			catch(Exception ex)
			{
				logger.error("Eccezione in Ricerca Schede: " + ex.getMessage());
				return pageError;
			}
			
			JSFUtility.executeScript("dialogRettifica.show()");
			JSFUtility.update("dialogRettifica");
			
			setIdCandRettifica(idCandidatura);
			setMostraDialogSingola("true");
			
//			return rettificaDomanda(idCandidatura);
		}
		// candidatura associata --> mostra il dialog per la scelta dell'utente da rettificare
		else if (listaCandidature.size()>1)
		{
			listaUtentiAssociati = new ArrayList<UtenteReg>();
			for (CandidaturaReg candidatura: listaCandidature)
			{
				String id_utente = candidatura.getIdUtente();
				try
				{
					utenteAssociatoSelezionato = utenteHome.findById(id_utente);
				}
				catch(Exception ex)
				{
					logger.error("Eccezione in Ricerca Schede: " + ex.getMessage());
					return pageError;
				}
				
				listaUtentiAssociati.add(utenteAssociatoSelezionato);
			}
			
			idUtenteRettifica = null;
			dialogRettifica.setHeader("Controllo Domanda");
			testoDialogRettifica="Selezionare l'utente di cui si vuole controllare la domanda e premere Conferma";
			
			setMostraDialogSingola("false");
			
			JSFUtility.executeScript("dialogRettifica.show()");
			JSFUtility.update("dialogRettifica");
			JSFUtility.executeScript("confermaButton.disable()");
		
		}
		return null;
	}
	
	
	// tolto il salvataggio delle schede
	
//	public String salvaDettagliCandidature()
//	{
//		RicercaSchedaValutazioneAction ricercaSchedaValutazioneAction = new RicercaSchedaValutazioneAction();
//		
//		try
//		{
//			ricercaSchedaValutazioneAction.salvaSchede(listaSchede);
//			JSFUtility.addInfoMessage("Salvataggio Riuscito","");
//			JSFUtility.scrollTo("msgs");
//			
//			return null;
//		}
//		catch(Exception e)
//		{
//			//JSFUtility.redirect(pageError);
//			return pageError;
//		}
//
//	}
	
	// ****************   metodi per paginazione  **************************** //
	// *********************************************************************** //
	
	
	public String primaPagina() {
		rowIniBlock=0;
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente=1;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowIniBlock()== 0 || getRowIniBlock()<0){
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
	    	setPulsantePagIndietro("true");
		}
		
		try {
			listaSchede = ricercaSchedaValutazioneAction.ricercaSchede(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
			//JSFUtility.redirect(pageError);
			//JSFUtility.addWarningMessage("","Errore durante la visualizzazione delle schermate");
			return pageError;
		}
		JSFUtility.scrollTo("candidature");
		return null;
	}
	
	
	public String ultimaPagina() {
		rowFinBlock=getNumeroSchede();
		setRowIniBlock(getRowFinBlock()-getRowBlock());
		
		paginaCorrente=totalePagine;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

    	if (getRowFinBlock()== getNumeroSchede() || getRowFinBlock()>getNumeroSchede()){
			setRowFinBlock(getNumeroSchede());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");
    	}
		
		try {
			listaSchede = ricercaSchedaValutazioneAction.ricercaSchede(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
			//JSFUtility.redirect(pageError);
			//JSFUtility.addWarningMessage("","Errore durante la visualizzazione delle schermate");
			return pageError;
		}
		JSFUtility.scrollTo("candidature");
		return null;
	}
	
	
	public String paginaAvanti() {
		setRowIniBlock(getRowFinBlock());
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente++;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowFinBlock()== getNumeroSchede() || getRowFinBlock()>getNumeroSchede()){
			setRowFinBlock(getNumeroSchede());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");
		}
		
		try {
			listaSchede = ricercaSchedaValutazioneAction.ricercaSchede(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
			//JSFUtility.redirect(pageError);
			//JSFUtility.addWarningMessage("","Errore durante la visualizzazione delle schermate");
			return pageError;
		}
		JSFUtility.scrollTo("candidature");	
		return null;
	}
	
	
	
	public String paginaIndietro() {
		rowIniBlock=rowIniBlock-rowBlock;
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente--;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowIniBlock()== 0 || getRowIniBlock()<0){
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
	    	setPulsantePagIndietro("true");
		}
		
		try {
			listaSchede = ricercaSchedaValutazioneAction.ricercaSchede(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
			return pageError;
		}
		JSFUtility.scrollTo("candidature");
		return null;
	}

	
	
	public String getIdUtente() {
		return idUtente;
	}
	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getCodiceFiscale() {
		return codiceFiscale;
	}
	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}

	public String getCandidatura() {
		return candidatura;
	}
	public void setCandidatura(String candidatura) {
		this.candidatura = candidatura;
	}

	public boolean isMostraRisultatiRicerca() {
		return mostraRisultatiRicerca;
	}

	public List<RicercaSchedeValutazione> getListaSchede() {
		return listaSchede;
	}
	
	public void setListaSchede(List<RicercaSchedeValutazione> listaSchede) {
		this.listaSchede = listaSchede;
	}
	
	public void setMostraRisultatiRicerca(boolean mostraRisultatiRicerca) {
		this.mostraRisultatiRicerca = mostraRisultatiRicerca;
	}

	public List<String> getIdSchedeList() {
		return idSchedeList;
	}

	public void setIdSchedeList(List<String> idSchedeList) {
		this.idSchedeList = idSchedeList;
	}

	public String getTotaleSchede() {
		return totaleSchede;
	}
	
	public void setTotaleSchede(String totaleSchede) {
		this.totaleSchede = totaleSchede;
	}
	
	public String getParzialeSchede() {
		return parzialeSchede;
	}
	public void setParzialeSchede(String parzialeSchede) {
		this.parzialeSchede = parzialeSchede;
	}
	
	public List<UtenteReg> getListaUtentiAssociati() {
		return listaUtentiAssociati;
	}
	public void setListaUtentiAssociati(List<UtenteReg> listaUtentiAssociati) {
		this.listaUtentiAssociati = listaUtentiAssociati;
	}
	
	public String getProtocollo() {
		return protocollo;
	}
	public Date getDataIstruttoria() {
		return dataIstruttoria;
	}
	public void setDataIstruttoria(Date dataIstruttoria) {
		this.dataIstruttoria = dataIstruttoria;
	}
	public String getDocumentazionePrevista() {
		return documentazionePrevista;
	}
	public String getDataIstruttoria_string() {
		return dataIstruttoria_string;
	}
	public void setDataIstruttoria_string(String dataIstruttoria_string) {
		this.dataIstruttoria_string = dataIstruttoria_string;
	}
	public String getPunteggio() {
		return punteggio;
	}
	public void setPunteggio(String punteggio) {
		this.punteggio = punteggio;
	}
	public void setDocumentazionePrevista(String documentazionePrevista) {
		this.documentazionePrevista = documentazionePrevista;
	}
	public String getDocumentazionePervenuta() {
		return documentazionePervenuta;
	}
	public void setDocumentazionePervenuta(String documentazionePervenuta) {
		this.documentazionePervenuta = documentazionePervenuta;
	}
	public String getCodOsservazioni() {
		return codOsservazioni;
	}
 	
	public void setCodOsservazioni(String codOsservazioni) throws GestioneErroriException {
		this.codOsservazioni = codOsservazioni;
		
		String nome="";
		String osservazione="";
		String stringa_completa="";
		String stringa_finale="";
		
		if (codOsservazioni!=null && !codOsservazioni.equalsIgnoreCase("-1")){
			
			String[] array_oss1 = codOsservazioni.split(" # ");
			
			for (int i=0; i< array_oss1.length; i++){
				
				String appoggio = array_oss1[i];
				String[] array_oss2 = appoggio.split(" | ");
				
				     nome="";
				     osservazione="";
						for (int j=0; j< array_oss2.length; j++){
							stringa_completa="";
							if (!array_oss2[j].contains("|") && !array_oss2[j].contains("_")){
								nome= nome+" "+ array_oss2[j];
							}
								
							else if (!array_oss2[j].contains("|")){
//								osservazione += CaricaOsservazioni.decodificaosservazione(array_oss2[j]) + " * ";
								osservazione += CaricaOsservazioni.decodificaosservazione(array_oss2[j]) + " - ";
							}
								
							stringa_completa = nome.toUpperCase() + osservazione.toLowerCase();
						}	
						stringa_completa = " " + nome.toUpperCase() + " : " +osservazione.toLowerCase();
						nome="";
						osservazione="";
						stringa_finale += stringa_completa+" <br/> ";
			}
			
		 this.osservazioneStringa = stringa_finale;
		 
		}
		
	}
	
	public void setProtocollo(String protocollo) {
		this.protocollo = protocollo;
	}
	
	public Osservazione getOsservazioneSelezionata() {
		return osservazioneSelezionata;
	}
	public void setOsservazioneSelezionata(Osservazione osservazioneSelezionata) {
		this.osservazioneSelezionata = osservazioneSelezionata;
	}
	public List<Osservazione> getOsservazioni() {
		return osservazioni;
	}
	public void setOsservazioni(List<Osservazione> osservazioni) {
		this.osservazioni = osservazioni;
	}
	
	public String getOsservazioneStringa() {
		return osservazioneStringa;
	}
	public void setOsservazioneStringa(String osservazioneStringa) {
		this.osservazioneStringa = osservazioneStringa;
	}

	public String getTestoDettaglioOsservazioni() {
		return testoDettaglioOsservazioni;
	}

	public void setTestoDettaglioOsservazioni(String testoDettaglioOsservazioni) {
		this.testoDettaglioOsservazioni = testoDettaglioOsservazioni;
	}

	public Dialog getDialogOsservazioni() {
		return dialogOsservazioni;
	}
	
	public void setDialogOsservazioni(Dialog dialogOsservazioni) {
		this.dialogOsservazioni = dialogOsservazioni;
	}

	public Dialog getDialogRettifica() {
		return dialogRettifica;
	}

	public void setDialogRettifica(Dialog dialogRettifica) {
		this.dialogRettifica = dialogRettifica;
	}
	
	public UtenteReg getUtenteAssociatoSelezionato() {
		return utenteAssociatoSelezionato;
	}

	public void setUtenteAssociatoSelezionato(UtenteReg utenteAssociatoSelezionato) {
		this.utenteAssociatoSelezionato = utenteAssociatoSelezionato;
	}
	
	public String getIdUtenteRettifica() {
		return idUtenteRettifica;
	}

	public void setIdUtenteRettifica(String idUtenteRettifica) {
		this.idUtenteRettifica = idUtenteRettifica;
	}

	public String getTestoDialogRettifica() {
		return testoDialogRettifica;
	}

	public void setTestoDialogRettifica(String testoDialogRettifica) {
		this.testoDialogRettifica = testoDialogRettifica;
	}

	public Dialog getDialogCompilaDomanda() {
		return dialogCompilaDomanda;
	}

	public void setDialogCompilaDomanda(Dialog dialogCompilaDomanda) {
		this.dialogCompilaDomanda = dialogCompilaDomanda;
	}

	public String getPulsantePagIndietro() {
		return pulsantePagIndietro;
	}

	public void setPulsantePagIndietro(String pulsantePagIndietro) {
		this.pulsantePagIndietro = pulsantePagIndietro;
	}

	public String getPulsantePagAvanti() {
		return pulsantePagAvanti;
	}

	public void setPulsantePagAvanti(String pulsantePagAvanti) {
		this.pulsantePagAvanti = pulsantePagAvanti;
	}

	public int getRowBlock() {
		return rowBlock;
	}

	public void setRowBlock(int rowBlock) {
		this.rowBlock = rowBlock;
	}

	public int getRowIniBlock() {
		return rowIniBlock;
	}

	public void setRowIniBlock(int rowIniBlock) {
		this.rowIniBlock = rowIniBlock;
	}

	public int getRowFinBlock() {
		return rowFinBlock;
	}

	public void setRowFinBlock(int rowFinBlock) {
		this.rowFinBlock = rowFinBlock;
	}

	public int getRowNumerUltimo() {
		return rowNumerUltimo;
	}

	public void setRowNumerUltimo(int rowNumerUltimo) {
		this.rowNumerUltimo = rowNumerUltimo;
	}

	public int getNumeroSchede() {
		return numeroSchede;
	}

	public void setNumeroSchede(int numeroSchede) {
		this.numeroSchede = numeroSchede;
	}

//	public String getTotaleCandidati() {
//		return totaleCandidati;
//	}
//
//	public void setTotaleCandidati(String totaleCandidati) {
//		this.totaleCandidati = totaleCandidati;
//	}

	public int getTotalePagine() {
		return totalePagine;
	}

	public void setTotalePagine(int totalePagine) {
		this.totalePagine = totalePagine;
	}

	public int getPaginaCorrente() {
		return paginaCorrente;
	}

	public void setPaginaCorrente(int paginaCorrente) {
		this.paginaCorrente = paginaCorrente;
	}

	public int getTotaleSchedeInt() {
		return totaleSchedeInt;
	}

	public void setTotaleSchedeInt(int totaleSchedeInt) {
		this.totaleSchedeInt = totaleSchedeInt;
	}

	public String getMostraDialogSingola() {
		return mostraDialogSingola;
	}

	public void setMostraDialogSingola(String mostraDialogSingola) {
		this.mostraDialogSingola = mostraDialogSingola;
	}

	public String getIdCandRettifica() {
		return idCandRettifica;
	}

	public void setIdCandRettifica(String idCandRettifica) {
		this.idCandRettifica = idCandRettifica;
	}

	public String[] getListaHelp() {
		return listaHelp;
	}

	public void setListaHelp(String[] listaHelp) {
		this.listaHelp = listaHelp;
	}
	
	
	public String getNomeRicerca() {
		return nomeRicerca;
	}


	public void setNomeRicerca(String nomeRicerca) {
		this.nomeRicerca = nomeRicerca;
	}


	public String getCognomeRicerca() {
		return cognomeRicerca;
	}


	public void setCognomeRicerca(String cognomeRicerca) {
		this.cognomeRicerca = cognomeRicerca;
	}


	public String getCandidaturaRicerca() {
		return candidaturaRicerca;
	}


	public void setCandidaturaRicerca(String candidaturaRicerca) {
		this.candidaturaRicerca = candidaturaRicerca;
	}


	public String getDisabilitaConferma() {
		return disabilitaConferma;
	}


	public void setDisabilitaConferma(String disabilitaConferma) {
		this.disabilitaConferma = disabilitaConferma;
	}


	public String getParametroOrdinamento() {
		return parametroOrdinamento;
	}


	public void setParametroOrdinamento(String parametroOrdinamento) {
		this.parametroOrdinamento = parametroOrdinamento;
	}

	public void changeValueListener()
	{
		HttpServletRequest request = (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String parameter = request.getParameter("formGraduatoria:viewsGraduatoria:associati_input");
		this.setIdUtenteRettifica(parameter);
	}
	public void confermaGraduatoria() throws GestioneErroriException{
		
		try {
			JSFUtility.executeScript("dialogConferma.hide()");
			
			ricercaSchedaValutazioneAction.confermaGraduatoria(cod_reg);
			Tab tab  = (Tab) JSFUtility.findComponent(JSFUtility.getUIViewRoot(), "tabGestisciGraduatoria");
			tab.setDisabled(false);
			JSFUtility.update("formGraduatoria");
			JSFUtility.addInfoMessage("", "Conferma Graduatoria avvenuta con successo");
			JSFUtility.scrollTo("msgs");
			
		} catch (GestioneErroriException e) {
			// TODO Auto-generated catch blockz
			e.printStackTrace();
			logger.error("Eccezione in ricercaSchede - confermaGraduatoria: " + LogUtil.printException(e));
			JSFUtility.addWarningMessage("", "Errore durante la conferma della graduatoria");
			JSFUtility.scrollTo("msgs");
		}
	}

}