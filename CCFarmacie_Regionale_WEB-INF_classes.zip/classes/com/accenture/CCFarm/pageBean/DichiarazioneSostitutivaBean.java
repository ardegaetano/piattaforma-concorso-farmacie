package com.accenture.CCFarm.pageBean;


import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DocumentoReg;
import com.accenture.CCFarm.action.DichiarazioneSostitutivaAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;


public class DichiarazioneSostitutivaBean {

	private String tipologiaVersamento;
	
	private Date dataOperazione;
	private String iban;
	private String cro;
	private Date dataVersamento;
	private String numeroUffPostale;
	private String progressivoOperazione;
	private String flagDichiarazione;
	private String elencoDocumenti;
	private String tipiPagamento;
	private String noteCommissione;
	
	boolean result= false;
	Logger logger = CommonLogger.getLogger("ConsultaSediBean");
	
	Date dataPubblicazioneBando;
	Date dataFineBando;
	
	private ArrayList<DocumentoReg> listaDocumenti;

	DichiarazioneSostitutivaAction dichiarazioneSostitutivaAction;
	
	public DichiarazioneSostitutivaBean()
	{
		dichiarazioneSostitutivaAction=new DichiarazioneSostitutivaAction();
		findDateBando();
	}
	
	
	private void findDateBando()
   {
		dataPubblicazioneBando = ((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataPubblicazioneBando();
		dataFineBando = ((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataFineBando();
   }
	
	//restituisce il tipo di versamento specificato nel bando - "Bancario" o "Postale"
	
	public boolean init(String idUtente) throws Exception
	{
		
	    result =  dichiarazioneSostitutivaAction.loadPaginaInserimento(idUtente,this);
	    
		return result;
	}
	
	public boolean updateDAO(String idUtente)
	{
		try {
			//Tipologia Versamento da REGIONE combinata
			if(tipologiaVersamento!= null) {
				if(tipologiaVersamento.equals("Bancario/Postale")) {
					if(tipiPagamento!=null && tipiPagamento.equals("0")){ //Bancario
						setDataVersamento(null);
						setNumeroUffPostale("");
						setProgressivoOperazione("");
					}
					else if(tipiPagamento!=null && tipiPagamento.equals("1")){ //Postale
						setDataOperazione(null);
						setIban("");
						setCro("");
					}
					else {
						setDataVersamento(null);
						setNumeroUffPostale("");
						setProgressivoOperazione("");
						setDataOperazione(null);
						setIban("");
						setCro("");
					}
				}
				else if(tipologiaVersamento.equals("Bancario")||tipologiaVersamento.equals("Postale")) {
					setTipiPagamento("");
					if (elencoDocumenti!=null && (!elencoDocumenti.equals(""))) {
						// do
						setDataVersamento(null);
						setNumeroUffPostale("");
						setProgressivoOperazione("");
						setDataOperazione(null);
						setIban("");
						setCro("");
						
					}
				}
			}
			
			return dichiarazioneSostitutivaAction.updateDAO(idUtente,this);
		} catch (GestioneErroriException e) {
			logger.error("DichiarazioneSostitutivaBean - updateDAO: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
			return false;
		}
	}
	
	//controlla che tutti flag siano stati valorizzati a true
	public boolean controllaFlag()
	{
		/*if(flagDichiarazione!=null && flagDichiarazione.equals("false"))
		{
			setTipiPagamento("");
			JSFUtility.addWarningMessage("Attenzione","E' necessario che la casella di 'dichiarazione di conformit�' sia spuntata");
			JSFUtility.scrollTo("msgs");
			return false;
		}*/
		return true;
	}
	
	public boolean controllaDate()
	{
		if(tipologiaVersamento.equals("Bancario"))
		{
			if(dataOperazione!=null)
			{
				if(dataOperazione.before(dataPubblicazioneBando)||dataOperazione.after(dataFineBando))
				{
					setTipiPagamento("");
					JSFUtility.addWarningMessage("Attenzione","La data di operazione dev'essere successiva alla data di pubblicazione del bando e precedente alla data di fine bando");
					return false;
				}
			}
		}
		else if(tipologiaVersamento.equals("Postale"))
		{
			if(dataVersamento!=null)
			{
				if(dataVersamento.before(dataPubblicazioneBando)||dataVersamento.after(dataFineBando))
				{
					setTipiPagamento("");
					JSFUtility.addWarningMessage("Attenzione","La data di versamento dev'essere successiva alla data di pubblicazione del bando e precedente alla data di fine bando");
					return false;
				}
				
			}
		}
		else if(tipologiaVersamento.equals("Bancario/Postale"))
		{
			if(dataOperazione!=null)
			{
				if(dataOperazione.before(dataPubblicazioneBando)||dataOperazione.after(dataFineBando))
				{
					JSFUtility.addWarningMessage("Attenzione","La data di operazione dev'essere successiva alla data di pubblicazione del bando e precedente alla data di fine bando");
					return false;
				}
			}
			else if(dataVersamento!=null)
			{
				if(dataVersamento.before(dataPubblicazioneBando)||dataVersamento.after(dataFineBando))
				{
					JSFUtility.addWarningMessage("Attenzione","La data di versamento dev'essere successiva alla data di pubblicazione del bando e precedente alla data di fine bando");
					return false;
				}
			}
		}
		
		return true;
	}
	
	public void pagamentoCambiato()
	{
		if(tipiPagamento!=null && tipiPagamento.equals("0")){ //Bancario
			setDataVersamento(null);
			setNumeroUffPostale("");
			setProgressivoOperazione("");
		}
		else if(tipiPagamento!=null && tipiPagamento.equals("1")){ //Postale
			setDataOperazione(null);
			setIban("");
			setCro("");
		}
		JSFUtility.update("panelVersamentoBancario");
		JSFUtility.update("panelVersamentoPostale");
	}
	
	public String getTipologiaVersamento() {
		return tipologiaVersamento;
	}

	public void setTipologiaVersamento(String tipologiaVersamento) {
		this.tipologiaVersamento = tipologiaVersamento;
	}

	public Date getDataOperazione() {
		return dataOperazione;
	}

	public void setDataOperazione(Date dataOperazione) {
		this.dataOperazione = dataOperazione;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public String getCro() {
		return cro;
	}

	public void setCro(String cro) {
		this.cro = cro;
	}

	public Date getDataVersamento() {
		return dataVersamento;
	}

	public void setDataVersamento(Date dataVersamento) {
		this.dataVersamento = dataVersamento;
	}

	public String getNumeroUffPostale() {
		return numeroUffPostale;
	}

	public void setNumeroUffPostale(String numeroUffPostale) {
		this.numeroUffPostale = numeroUffPostale;
	}

	public String getProgressivoOperazione() {
		return progressivoOperazione;
	}

	public void setProgressivoOperazione(String progressivoOperazione) {
		this.progressivoOperazione = progressivoOperazione;
	}

	public String getFlagDichiarazione() {
		return flagDichiarazione;
	}

	public void setFlagDichiarazione(String flagDichiarazione) {
		this.flagDichiarazione = flagDichiarazione;
	}

	public String getElencoDocumenti() {
		return elencoDocumenti;
	}

	public void setElencoDocumenti(String elencoDocumenti) {
		this.elencoDocumenti = elencoDocumenti;
	}
	
	public ArrayList<DocumentoReg> getListaDocumenti() {
		return listaDocumenti;
	}

	public void setListaDocumenti(ArrayList<DocumentoReg> listaDocumenti) {
		this.listaDocumenti = listaDocumenti;
	}


	public String getTipiPagamento() {
		return tipiPagamento;
	}

	public void setTipiPagamento(String tipiPagamento) {
		this.tipiPagamento = tipiPagamento;
	}


	public String getNoteCommissione() {
		return noteCommissione;
	}


	public void setNoteCommissione(String noteCommissione) {
		this.noteCommissione = noteCommissione;
	}
	
}
