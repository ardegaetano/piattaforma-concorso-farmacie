package com.accenture.CCFarm.pageBean;

import com.accenture.CCFarm.utility.StringUtil;


@SuppressWarnings("serial")
public class CriteriPunteggiListBean implements Comparable<CriteriPunteggiListBean> {

	private String voto;
	private String punteggio;
	
	public CriteriPunteggiListBean() {}
	
	public int compareTo(CriteriPunteggiListBean otherObject)
	{
		Integer iVoto = new Integer(StringUtil.eliminaLode(voto));
		int ret = new Integer(StringUtil.eliminaLode(otherObject.getVoto())).compareTo(iVoto); //ORDINE DECRESCENTE
	    return ret;
	}

	public String getVoto() {
		return voto;
	}

	public void setVoto(String voto) {
		this.voto = voto;
	}

	public String getPunteggio() {
		return punteggio;
	}

	public void setPunteggio(String punteggio) {
		this.punteggio = punteggio;
	}
	
}