package com.accenture.CCFarm.pageBean;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.primefaces.component.tabview.TabView;

import com.accenture.CCFarm.action.SediNonAssegnateAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


@ManagedBean
@SessionScoped
public class SediNonAssegnateInterpelloBean
{	
	private Logger logger = CommonLogger.getLogger("SediNonAssegnateInterpelloBean");
	private final static String pageError = "errorPage.jsf";
	AppProperties paramProperties = AppProperties.getAppProperties();
	String sVero = paramProperties.getProperty("flag.valore.vero");
	String sFalso = paramProperties.getProperty("flag.valore.falso");
	
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
    UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	String cod_reg = utenteReg.getCodRegione();
	
	
	private SediNonAssegnateAction sediNonAssegnateAction;
	private String visibilitaTabSediNonAssegnate = sFalso;
	private String descrInterpello;
	List<ConsultaSediListBean> listFarmNonAssegnate;
	private String nSediNonAssegnate;
	
	
	public SediNonAssegnateInterpelloBean() 
	{
		try {
			init();
		}
		catch(GestioneErroriException e) {
			logger.error("SediNonAssegnateInterpelloBean - costruzione del bean fallita", e);
			JSFUtility.redirect(pageError);
		}
	}	
	
	public void init() throws GestioneErroriException
	{
		sediNonAssegnateAction = new SediNonAssegnateAction();
		sediNonAssegnateAction.init(cod_reg, this);
	}
	
	public void handleTabSediNonAssegnate()
	{
		try {
			TabView tabView = (TabView) JSFUtility.findComponent(JSFUtility.getUIViewRoot(), "viewsSedi");
			int currentTab= tabView.getActiveIndex();
			//Tab sedi non assegnate
			if(currentTab==1) {
				this.init();
			}
		}
		catch(GestioneErroriException e) {
			logger.error("SediNonAssegnateInterpelloBean - handleTabSediNonAssegnate: errore", e);
			JSFUtility.redirect(pageError);
		}
	}

	public String getDescrInterpello() {
		return descrInterpello;
	}

	public void setDescrInterpello(String descrInterpello) {
		this.descrInterpello = descrInterpello;
	}

	public List<ConsultaSediListBean> getListFarmNonAssegnate() {
		return listFarmNonAssegnate;
	}

	public void setListFarmNonAssegnate(
			List<ConsultaSediListBean> listFarmNonAssegnate) {
		this.listFarmNonAssegnate = listFarmNonAssegnate;
	}

	public String getVisibilitaTabSediNonAssegnate() {
		return visibilitaTabSediNonAssegnate;
	}

	public void setVisibilitaTabSediNonAssegnate(
			String visibilitaTabSediNonAssegnate) {
		this.visibilitaTabSediNonAssegnate = visibilitaTabSediNonAssegnate;
	}

	public String getnSediNonAssegnate() {
		return nSediNonAssegnate;
	}

	public void setnSediNonAssegnate(String nSediNonAssegnate) {
		this.nSediNonAssegnate = nSediNonAssegnate;
	}

	public UtenteRegioni getUtenteReg() {
		return utenteReg;
	}

	public void setUtenteReg(UtenteRegioni utenteReg) {
		this.utenteReg = utenteReg;
	}

}