package com.accenture.CCFarm.pageBean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.model.StreamedContent;

import com.accenture.CCFarm.utility.StringUtil;

@ManagedBean
@SessionScoped
public class BandoRegionale {

	private Date dataPubblicazioneBando;
	private Date dataInizioBando;
	private Date dataFineBando;
	private boolean contributoPartecipazione;
	private String estremiPagamento;
	private Date dataInizioCorsi;
	private Date dataFineCorsi;
	private Date dataInizioPubblicazioni;
	private Date dataFinePubblicazioni;
	private String ufficioBando;
	private String telefonoBando;
	private String mailBando;
	private String disponibilitaBando;
	private String dataPubblicazioneBandoString;
	private String dataInizioBandoString;
	private String dataFineBandoString;
	private String dataInizioCorsiString;
	private String dataFineCorsiString;
	private String dataInizioPubblicazioniString;
	private String dataFinePubblicazioniString;
	private boolean bCaricaBando = false;
	private String visibilitaCaricaBando = "none";
	private String invisibilitaCaricaBando = "block";
	private Short sediBando;
	List<ConsultaSediListBean> listFarm = null;
	private boolean bCaricaSedi = false;
	private boolean bCSVValido = true;
	private String visibilita = "none";
	private String indirizzoSitoRegionale;
	private String visibilitaRipubblica = "none";
	private String visibilitaSalva = "block";
	private boolean flagColonnaTedesco = false;
	private String flgAbilitaCaricaSedi;
	private Short sediCaricate;
	
	//Gestione DownLoad
	private StreamedContent fileDownloadBando;
	
	private String stato;
	private boolean bStato = false;
	
	private String[]listaHelp;
	
	public BandoRegionale(){}
	
	public void clearBean(int i){
		if((i==1)|| (i==3)){ //Pulisce i dati del bean di DatiBando
			
			dataPubblicazioneBando=null;
			dataInizioBando=null;
			dataFineBando=null;
			contributoPartecipazione=false;
			estremiPagamento="";
			dataInizioCorsi=null;
			dataFineCorsi=null;
			dataInizioPubblicazioni=null;
			dataFinePubblicazioni=null;
			ufficioBando="";
			telefonoBando="";
			mailBando="";
			disponibilitaBando="";
			dataPubblicazioneBandoString="";
			dataInizioBandoString="";
			dataFineBandoString="";
			dataInizioCorsiString="";
			dataFineCorsiString="";
			dataInizioPubblicazioniString="";
			dataFinePubblicazioniString="";
			bCaricaBando = false;
			visibilitaCaricaBando = "none";
	    	invisibilitaCaricaBando = "block";	
			bStato = false;
			stato=null;
			flagColonnaTedesco = false;
		}
		else if((i==2)||(i==3)){ //Pulisce i dati del bean di DatiSede
			sediBando=0;
			sediCaricate=0;
			listFarm = null;
			bCaricaSedi = false;
			bCSVValido = true;
			bStato = false;
			stato=null;
			flagColonnaTedesco = false;
		}
		/*else if(i==3){ //Pulisce i dati del bean di ValidaBando
			fileDownloadBando = null;
		}*/
		
	}
	
	public Date getDataInizioBando() {
		return dataInizioBando;
	}
	
	public void setDataInizioBando(Date dataInizioBando) {
		this.dataInizioBando = dataInizioBando;
	}

	public Date getDataFineBando() {
		return dataFineBando;
	}

	public void setDataFineBando(Date dataFineBando) {
		this.dataFineBando = dataFineBando;
	}
	
	public Date getDataInizioCorsi() {
		return dataInizioCorsi;
	}

	public void setDataInizioCorsi(Date dataInizioCorsi) {
		this.dataInizioCorsi = dataInizioCorsi;
	}

	public Date getDataFineCorsi() {
		return dataFineCorsi;
	}

	public void setDataFineCorsi(Date dataFineCorsi) {
		this.dataFineCorsi = dataFineCorsi;
	}
	
	public Date getDataInizioPubblicazioni() {
		return dataInizioPubblicazioni;
	}

	public void setDataInizioPubblicazioni(Date dataInizioPubblicazioni) {
		this.dataInizioPubblicazioni = dataInizioPubblicazioni;
	}
	
	public Date getDataFinePubblicazioni() {
		return dataFinePubblicazioni;
	}

	public void setDataFinePubblicazioni(Date dataFinePubblicazioni) {
		this.dataFinePubblicazioni = dataFinePubblicazioni;
	}
	
	public String getUfficioBando() {
		return ufficioBando;
	}

	public void setUfficioBando(String ufficioBando) {
		this.ufficioBando = ufficioBando;
	}

	public String getMailBando() {
		return mailBando;
	}

	public void setMailBando(String mailBando) {
		this.mailBando = mailBando;
	}

	public String getDisponibilitaBando() {
		return disponibilitaBando;
	}

	public void setDisponibilitaBando(String disponibilitaBando) {
		this.disponibilitaBando = disponibilitaBando;
	}
	
	public boolean isbStato() {
		return bStato;
	}

	public void setbStato(boolean bStato) {
		this.bStato = bStato;
	}
	
	public String getEstremiPagamento() {
		return estremiPagamento;
	}

	public void setEstremiPagamento(String estremiPagamento) {
		this.estremiPagamento = estremiPagamento;
	}	
	
	public boolean isContributoPartecipazione() {
		return contributoPartecipazione;
	}

	public void setContributoPartecipazione(boolean contributoPartecipazione) {
		this.contributoPartecipazione = contributoPartecipazione;
		if(contributoPartecipazione)
			visibilita = "block";
		else
			visibilita = "none";
	}	
	
	public Date getDataPubblicazioneBando() {
		return dataPubblicazioneBando;
	}

	public void setDataPubblicazioneBando(Date dataPubblicazioneBando) {
		this.dataPubblicazioneBando = dataPubblicazioneBando;
	}

	public Short getSediBando() {
		return sediBando;
	}

	public void setSediBando(Short sediBando) {
		this.sediBando = sediBando;
	}
	
    public String getTelefonoBando() {
		return telefonoBando;
	}

	public void setTelefonoBando(String telefonoBando) {
		this.telefonoBando = telefonoBando;
	}

	public boolean isbCaricaSedi() {
		return bCaricaSedi;
	}

	public void setbCaricaSedi(boolean bCaricaSedi) {
		this.bCaricaSedi = bCaricaSedi;
	}

	public boolean isbCSVValido() {
		return bCSVValido;
	}

	public void setbCSVValido(boolean bCSVValido) {
		this.bCSVValido = bCSVValido;
	}

	public boolean isbCaricaBando() {
		return bCaricaBando;
	}

	public void setbCaricaBando(boolean bCaricaBando) {
		this.bCaricaBando = bCaricaBando;
	}

	public String getVisibilitaCaricaBando() {
		return visibilitaCaricaBando;
	}

	public void setVisibilitaCaricaBando(String visibilitaCaricaBando) {
		this.visibilitaCaricaBando = visibilitaCaricaBando;
	}
	
	public String getInvisibilitaCaricaBando() {
		return invisibilitaCaricaBando;
	}

	public void setInvisibilitaCaricaBando(String invisibilitaCaricaBando) {
		this.invisibilitaCaricaBando = invisibilitaCaricaBando;
	}

	public String getStato() {
		return stato;
	}

	public void setStato(String stato) {
		this.stato = stato;
	}
	
	public List<ConsultaSediListBean> getListFarm() {
		return listFarm;
	}

	public void setListFarm(List<ConsultaSediListBean> listFarm) {
		this.listFarm = listFarm;
	}
	
	public void initListFarm() {
		this.listFarm = new ArrayList<ConsultaSediListBean>();
	}

	public StreamedContent getFileDownloadBando() {
		return fileDownloadBando;
	}

	public void setFileDownloadBando(StreamedContent fileDownloadBando) {
		this.fileDownloadBando = fileDownloadBando;
	}

	public String getDataPubblicazioneBandoString() {
		Date d = getDataPubblicazioneBando();
		if(d!=null)
			dataPubblicazioneBandoString = StringUtil.dateToStringDDMMYYYY(d);
		return dataPubblicazioneBandoString;
	}

	public void setDataPubblicazioneBandoString(String dataPubblicazioneBandoString) {
		
		this.dataPubblicazioneBandoString = (dataPubblicazioneBando!=null)? dataPubblicazioneBando.toString() : dataPubblicazioneBandoString;
	}

	public String getDataInizioBandoString() {
		Date d = getDataInizioBando();
		if(d!=null)
			dataInizioBandoString = StringUtil.dateToStringDDMMYYYY(d);
		return dataInizioBandoString;
	}

	public void setDataInizioBandoString(String dataInizioBandoString) {
		this.dataInizioBandoString = (dataInizioBando!=null)? dataInizioBando.toString() : dataInizioBandoString;
	}

	public String getDataFineBandoString() {
		Date d = getDataFineBando();
		if(d!=null)
			dataFineBandoString = StringUtil.dateToStringDDMMYYYY(d);
		return dataFineBandoString;
	}

	public void setDataFineBandoString(String dataFineBandoString) {
		this.dataFineBandoString = (dataFineBando!=null)? dataFineBando.toString() : dataFineBandoString;
	}

	public String getDataInizioCorsiString() {
		Date d = getDataInizioCorsi();
		if(d!=null)
			dataInizioCorsiString = StringUtil.dateToStringDDMMYYYY(d);
		return dataInizioCorsiString;
	}

	public void setDataInizioCorsiString(String dataInizioCorsiString) {
		this.dataInizioCorsiString = (dataInizioCorsi!=null)? dataInizioCorsi.toString() : dataInizioCorsiString;
	}

	public String getDataFineCorsiString() {
		Date d = getDataFineCorsi();
		if(d!=null)
			dataFineCorsiString = StringUtil.dateToStringDDMMYYYY(d);
		return dataFineCorsiString;
	}

	public void setDataFineCorsiString(String dataFineCorsiString) {
		this.dataFineCorsiString = (dataFineCorsi!=null)? dataFineCorsi.toString() : dataFineCorsiString;
	}

	public String getDataInizioPubblicazioniString() {
		Date d = getDataInizioPubblicazioni();
		if(d!=null)
			dataInizioPubblicazioniString = StringUtil.dateToStringDDMMYYYY(d);
		return dataInizioPubblicazioniString;
	}

	public void setDataInizioPubblicazioniString(
			String dataInizioPubblicazioniString) {
		this.dataInizioPubblicazioniString = (dataInizioPubblicazioni!=null)? dataInizioPubblicazioni.toString() : dataInizioPubblicazioniString;
	}

	public String getDataFinePubblicazioniString() {
		Date d = getDataFinePubblicazioni();
		if(d!=null)
			dataFinePubblicazioniString = StringUtil.dateToStringDDMMYYYY(d);
		return dataFinePubblicazioniString;
	}

	public void setDataFinePubblicazioniString(String dataFinePubblicazioniString) {
		this.dataFinePubblicazioniString = (dataFinePubblicazioni!=null)? dataFinePubblicazioni.toString() : dataFinePubblicazioniString;
	}

	public String[] getListaHelp() {
		return listaHelp;
	}

	public void setListaHelp(String[] listaHelp) {
		this.listaHelp = listaHelp;
	}

	public String getVisibilita() {
		return visibilita;
	}

	public void setVisibilita(String visibilita) {
		this.visibilita = visibilita;
	}

	public String getIndirizzoSitoRegionale() {
		return indirizzoSitoRegionale;
	}

	public void setIndirizzoSitoRegionale(String indirizzoSitoRegionale) {
		this.indirizzoSitoRegionale = indirizzoSitoRegionale;
	}

	public String getVisibilitaRipubblica() {
		return visibilitaRipubblica;
	}

	public void setVisibilitaRipubblica(String visibilitaRipubblica) {
		this.visibilitaRipubblica = visibilitaRipubblica;
	}

	public String getVisibilitaSalva() {
		return visibilitaSalva;
	}

	public void setVisibilitaSalva(String visibilitaSalva) {
		this.visibilitaSalva = visibilitaSalva;
	}

	public boolean isFlagColonnaTedesco() {
		return flagColonnaTedesco;
	}

	public void setFlagColonnaTedesco(boolean flagColonnaTedesco) {
		this.flagColonnaTedesco = flagColonnaTedesco;
	}

	public String getFlgAbilitaCaricaSedi() {
		return flgAbilitaCaricaSedi;
	}

	public void setFlgAbilitaCaricaSedi(String flgAbilitaCaricaSedi) {
		this.flgAbilitaCaricaSedi = flgAbilitaCaricaSedi;
	}

	public Short getSediCaricate() {
		return sediCaricate;
	}

	public void setSediCaricate(Short sediCaricate) {
		this.sediCaricate = sediCaricate;
	}

}
