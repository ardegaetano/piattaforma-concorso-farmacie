package com.accenture.CCFarm.pageBean;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.primefaces.component.confirmdialog.ConfirmDialog;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.action.CalcolaPunteggiAutomaticiAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


@ManagedBean
//@SessionScoped
public class CalcolaPunteggiAutomatici
{	
	
	private String descrizione="";
	private String esitoCalcolo="";
	private String pulsantePrenotaCalcolo= "true";
	private ConfirmDialog dialogConfermaCalcolo;
	
	private String[]listaHelp;
	
	CalcolaPunteggiAutomaticiAction calcolaPunteggiAutomaticiAction;
	 
	private Logger logger = CommonLogger.getLogger("CalcolaPunteggiAutomatici");
	private final static String pageError = "errorPage.jsf";
	
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
    UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	String cod_reg = utenteReg.getCodRegione();
	
	
	public CalcolaPunteggiAutomatici() 
	{
		calcolaPunteggiAutomaticiAction=new CalcolaPunteggiAutomaticiAction();
		
	    init();
	}	
	
	public CalcolaPunteggiAutomatici(String noInit){
		
	}
	
	public void init()
	{
		
		try
		{
			
			setListaHelp(Help.caricaHelpElaboraGraduatoria());
			String[] array_app =calcolaPunteggiAutomaticiAction.checkElaborazione(cod_reg);
			setPulsantePrenotaCalcolo(array_app[0]);
			setDescrizione(array_app[1]);
			setEsitoCalcolo(array_app[2]);
			
			DatiBando datiBando = new  DatiBando();
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			
			try {
				datiBando = datiBandoHome.findById(cod_reg);
				if (datiBando!=null){
					if (datiBando.getFlgScarti()!= null && datiBando.getFlgScarti().equalsIgnoreCase("true")){
						setEsitoCalcolo("Il calcolo � terminato con errori");
					}
				}	
			} catch (GestioneErroriException e) {
			
			}
			
			
		}
		catch (Exception e)
		{
			logger.error("Eccezione in Calcola Punteggi automatici: " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
	}
	
	
	public void confermaCalcoloDialog()
	{
		JSFUtility.executeScript("dialogConfermaCalcolo.show()");
		JSFUtility.update("dialogConfermaCalcolo");

	}
	
	
	public void prenotaCalcolo(){
		
		try{
		
			if(calcolaPunteggiAutomaticiAction.checkCaricamentoPunteggi(cod_reg).equalsIgnoreCase("true")){
				calcolaPunteggiAutomaticiAction.prenotaCalcolo(cod_reg);
				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				Date date = new Date();
				JSFUtility.addInfoMessage("	E' stata effettuata la richiesta per il lancio del calcolo automatico dei punteggi. Per confermare tale richiesta bisogna contattare il Service Desk e richiedere l'avvio del calcolo. Il lancio del calcolo comporta che tutti i punteggi inseriti dalla commissione sulle schede dei candidati verranno cancellati.","");
				JSFUtility.scrollTo("msgs");
			}
			else {
				JSFUtility.addWarningMessage("La preparazione delle schede di valutazione pu� essere prenotata solo dopo aver caricato i criteri","");
				JSFUtility.scrollTo("msgs");
			}
		}catch(Exception e){
			logger.error("Eccezione in Calcola Punteggi automatici: " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
	}
	
	
	

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public String getEsitoCalcolo() {
		return esitoCalcolo;
	}

	public void setEsitoCalcolo(String esitoCalcolo) {
		this.esitoCalcolo = esitoCalcolo;
	}

	public String getPulsantePrenotaCalcolo() {
		return pulsantePrenotaCalcolo;
	}

	public void setPulsantePrenotaCalcolo(String pulsantePrenotaCalcolo) {
		this.pulsantePrenotaCalcolo = pulsantePrenotaCalcolo;
	}

	public ConfirmDialog getDialogConfermaCalcolo() {
		return dialogConfermaCalcolo;
	}

	public void setDialogConfermaCalcolo(ConfirmDialog dialogConfermaCalcolo) {
		this.dialogConfermaCalcolo = dialogConfermaCalcolo;
	}

	public String[] getListaHelp() {
		return listaHelp;
	}

	public void setListaHelp(String[] listaHelp) {
		this.listaHelp = listaHelp;
	}

}