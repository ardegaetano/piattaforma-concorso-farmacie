package com.accenture.CCFarm.pageBean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.accenture.punteggi.esperienze.bean.in.*;
import com.accenture.CCFarm.Bean.EsercizioProfessionale;
import com.accenture.CCFarm.Bean.Ruolo;
import com.accenture.CCFarm.action.SimulazioneCalcoloAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CaricaRuoli;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.JSFUtility;


@ManagedBean
@SessionScoped
public class SimulazioneCalcoloBean {

	org.apache.log4j.Logger logger =org.apache.log4j.Logger.getLogger("Simulazione");
	SimulazioneCalcoloAction simulazioneController = null;
	FacesContext context;
	HttpServletRequest req;
	HttpSession session;
	private HtmlPanelGrid mainGrid;


	
	public HtmlPanelGrid getMainGrid() {
		return mainGrid;
	}

	public void setMainGrid(HtmlPanelGrid mainGrid) {
		this.mainGrid = mainGrid;
	}
	private String esitoSimulazione;
	public String getEsitoSimulazione() {
		return esitoSimulazione;
	}

	public void setEsitoSimulazione(String esitoSimulazione) {
		this.esitoSimulazione = esitoSimulazione;
	}
	private Date dataInizio;
	private Date dataFine;
	private String flagFarmRurale;
	public String getFlagFarmRurale() {
		return flagFarmRurale;
	}

	public void setFlagFarmRurale(String flagFarmRurale) {
		this.flagFarmRurale = flagFarmRurale;
	}
	private String[]listaHelp;
	private List<EsercizioProfessionale> eserciziTable; 
	private EsercizioProfessionale entityEseSelected;
	public EsercizioProfessionale getEntityEseSelected() {
		return entityEseSelected;
	}

	public void setEntityEseSelected(EsercizioProfessionale entityEseSelected) {
		this.entityEseSelected = entityEseSelected;
	}

	public List<EsercizioProfessionale> getEserciziTable() {
		return eserciziTable;
	}

	public void setEserciziTable(List<EsercizioProfessionale> eserciziTable) {
		this.eserciziTable = eserciziTable;
	}
	private String codRuoloEs;
	private List<Ruolo> ruoli;
	public List<Ruolo> getRuoli() {
		return ruoli;
	}
	private String codModalitaEs;
	public String getCodModalitaEs() {
		return codModalitaEs;
	}

	public void setCodModalitaEs(String codModalitaEs) {
		this.codModalitaEs = codModalitaEs;
	}
	private String modalitaEs;
	private String ruoloEs; 
	private String regEsDescr;

	public void setRuoli(List<Ruolo> ruoli) {
		this.ruoli = ruoli;
	}

	public Ruolo getRuoloSelezionato() {
		return ruoloSelezionato;
	}

	public void setRuoloSelezionato(Ruolo ruoloSelezionato) {
		this.ruoloSelezionato = ruoloSelezionato;
	}

	private Ruolo ruoloSelezionato;
	
	
	public String getCodRuoloEs() {
		return codRuoloEs;
	}

	public void setCodRuoloEs(String codRuoloEs) {
		this.codRuoloEs = codRuoloEs;
	}

	
	
	public String getRuoloEs() {
		return ruoloEs;
	}

	public void setRuoloEs(String ruoloEs) {
		this.ruoloEs = ruoloEs;
	}

	public String getRegEsDescr() {
		return regEsDescr;
	}

	public void setRegEsDescr(String regEsDescr) {
		this.regEsDescr = regEsDescr;
	}

	public SimulazioneCalcoloBean(){
		init();
	}
	
	public String[] getListaHelp() {
		return listaHelp;
	}

	public void setListaHelp(String[] listaHelp) {
		this.listaHelp = listaHelp;
	}

	public Date getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(Date dataInizio) {
		this.dataInizio = dataInizio;
	}

	public Date getDataFine() {
		return dataFine;
	}

	public void setDataFine(Date dataFine) {
		this.dataFine = dataFine;
	}

	public String getIdRuolo() {
		return idRuolo;
	}

	public void setIdRuolo(String idRuolo) {
		this.idRuolo = idRuolo;
	}

	public String getDescRuolo() {
		return descRuolo;
	}

	public void setDescRuolo(String descRuolo) {
		this.descRuolo = descRuolo;
	}

	public String getIdModalita() {
		return idModalita;
	}

	public void setIdModalita(String idModalita) {
		this.idModalita = idModalita;
	}

	public String getDescModalita() {
		return descModalita;
	}

	public void setDescModalita(String descModalita) {
		this.descModalita = descModalita;
	}

	public String getRuralita() {
		return ruralita;
	}

	public void setRuralita(String ruralita) {
		this.ruralita = ruralita;
	}

	private boolean contributoPartecipazione;
	private String idRuolo;
	private String descRuolo;
	private String idModalita;
	private String descModalita;
	private String ruralita;

	//INIT PAGINA
	public void init() {  
		
		try {
			loadPagina(this);
		} catch (GestioneErroriException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addMessage(String Intestazione, String summary) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN,Intestazione, summary);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
	private void loadPagina(SimulazioneCalcoloBean simBean) throws GestioneErroriException {
		simBean.setListaHelp( Help.caricaHelpSimulazioneCalcolo());
		ruoli = CaricaRuoli.getRuoli();
    }
	
	public void inserisciEsp(){
		
		if(this.dataInizio == null)
			addMessage("ATTENZIONE", "E' necessario valorizzare la data di decorrenza esperienza");
		else
			if(this.dataFine == null)
				addMessage("ATTENZIONE", "E' necessario valorizzare la data fine esperienza");
			else
				if(this.dataInizio.after(this.dataFine)) 
					addMessage("ATTENZIONE", "La data decorrenza esperienza non pu� essere successiva alla data fine");
				else
					if(this.codRuoloEs == null || this.codRuoloEs.equals(""))
						addMessage("ATTENZIONE", "E' necessario definire il ruolo");
					else
						if(this.codModalitaEs == null || this.codModalitaEs.equals(""))
							addMessage("ATTENZIONE", "E' necessario definire la modalit�");
						else
							if(this.flagFarmRurale == null || this.flagFarmRurale.equals(""))
								addMessage("ATTENZIONE", "E' necessario specificare la ruralit�");
							else{
								List<EsercizioProfessionale> lista = SimulazioneCalcoloAction.inserisci(this);
								setEserciziTable(lista);
								this.dataInizio = null;
								this.dataFine = null;
								this.codModalitaEs = null;
								this.codRuoloEs = null;
								this.flagFarmRurale = null;}
	}
	
	public String backHome()
	{	
		clearBean();
	//	JSFUtility.redirect("homeRegioni.jsf");
    	return "homeRegioni";
		//return null;
	}
	
	public String backDatiSimulazione()
	{	
		//loadPagina(this);
		return "simulazioneCalcolo";
	}
	
	
	public String calcolaPunteggio(){
		String pagina = "simulazioneCalcolo";
		if(this.eserciziTable == null || this.eserciziTable.isEmpty() )
			addMessage("ATTENZIONE", "Inserire almeno una esperienza professionale");
		else{
			try{
			loadPaginaDettaglio(this);
			pagina = "simulazioneCalcoloDettaglio";
			}catch(Exception e) {
				logger.error("Simulazione calcolo - calcolaPunteggio: " + e.getMessage());
			}
		}
		return pagina;
	}
	
	private void loadPaginaDettaglio(SimulazioneCalcoloBean simBean) throws Exception {
		ruoli = CaricaRuoli.getRuoli();
		try {
			String risultato = SimulazioneCalcoloAction.calcola(this);
			if(!risultato.equals("") ){
				setEsitoSimulazione(risultato);
			}
		} catch (Exception e) {
			throw e;
		}
		
				
    }
	
	public void clearBean(){
			this.codModalitaEs = null;
			this.codRuoloEs = null;
			this.dataFine = null;
			this.dataInizio = null;
			this.descModalita = null;
			this.descRuolo = null;
			this.eserciziTable = null;
			this.esitoSimulazione = null;
			this.flagFarmRurale = null;
			this.idModalita = null;
			this.idRuolo = null;
			this.listaHelp = null;
			this.modalitaEs = null;
			this.regEsDescr = null;
		//	this.ruoli = null;
			this.ruoloEs = null;
			this.ruoloSelezionato = null;
			this.ruralita = null;
			}
	
	public void svuotaLista(){
		this.eserciziTable = null;
		}
	
	public void stampa(){
		this.eserciziTable = null;
		}
	
	public void cancella(){
		int riga = 0;
		for (int i = 0; i < this.eserciziTable.size(); i++) {
			EsercizioProfessionale esApp =  this.eserciziTable.get(i);
			if(esApp.equals(entityEseSelected))
				riga = i;
		}
		this.eserciziTable.remove(riga);
		}
	
	
}
