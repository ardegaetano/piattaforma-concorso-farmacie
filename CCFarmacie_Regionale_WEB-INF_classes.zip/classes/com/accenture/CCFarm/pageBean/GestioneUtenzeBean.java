package com.accenture.CCFarm.pageBean;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.DatiUtenza;
import com.accenture.CCFarm.Bean.RegioneSelect;
import com.accenture.CCFarm.action.GestioneUtenzeAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;

@ManagedBean(name="gestioneUtenzeBean")
@ViewScoped
public class GestioneUtenzeBean {
	
	private static final Logger logger = CommonLogger.getLogger("GestioneUtenzeBean");
	private static final String pageError = "errorPage.jsf";
	
	//filtri di ricerca credenziali
	DatiUtenza datiUtenza;
	
	private List<DatiUtenza> elencoCredenzialiTrovate;
	private boolean mostraElencoCredenzialiTrovate;
	private GestioneUtenzeAction gestioneUtenzeAction;
	private List<RegioneSelect> regioniSelect;
	private String regioneSelezionata="";
	
	//campi cambio indirizzo PEC
	private String idUtente;
	private String indirizzoPecOriginale;
	private String vecchioIndirizzoPec;
	private String nuovoIndirizzoPec;
	private String confermaNuovoIndirizzoPec;
	private String emailOriginale;
	private boolean bUtenteMds;
	
	public GestioneUtenzeBean() throws GestioneErroriException {
	
		try {
			init();
		}
		catch(Exception e) {
			
			logger.error("GestioneUtenzeBean - costruzione del bean fallita", e);
			throw new GestioneErroriException("GestioneUtenzeBean - costruzione del bean fallita");
		}
	}
	
	public void init() throws GestioneErroriException {  
    	
		HttpSession session = (HttpSession) JSFUtility.getFacesContext().getExternalContext().getSession(false);
		UtenteRegioni utente = (UtenteRegioni) session.getAttribute(RepositorySession.UTENTE_NSIS);
		datiUtenza = new DatiUtenza();
		if(utente.getCodRegione().equalsIgnoreCase("MDS")){
			setRegioniSelect(Localita.getRegioni());
			setbUtenteMds(true);
			setRegioneSelezionata("-1");
		}
		else {
			datiUtenza.setCodRegione(utente.getCodRegione());
			setbUtenteMds(false);
			setRegioneSelezionata("");
		}
		gestioneUtenzeAction = new GestioneUtenzeAction();
	}
	
	//ricerca tutte le credenziali che possono corrispondere ai criteri impostati
	//NOTA: codice regione selezionato da cartina come filtro di ricerca impicito
	public void ricercaCredenziali() {
		
		try {
			String sMsgWarning = checkFiltri(isbUtenteMds());
			
			if(sMsgWarning == null){
				if(isbUtenteMds())
					datiUtenza.setCodRegione(getRegioneSelezionata());
				
				List<DatiUtenza> elencoCredenziali = gestioneUtenzeAction.ricercaUtentiCandidati(datiUtenza);
				setElencoCredenzialiTrovate(elencoCredenziali);
				setMostraElencoCredenzialiTrovate(true);
			}
			else 
				JSFUtility.addWarningMessage("", sMsgWarning);
		}
		catch(Exception e) {
			logger.error("GestioneUtenzeBean - ricerca credenziali fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void inviaCredenzialiSuPecCorrente() {
		
		try {
			Map<String,String> requestParameters = JSFUtility.getFacesContext().getExternalContext().getRequestParameterMap();
		    String idUtenteSelezionato = requestParameters.get("idUtenteSelezionato");
		    gestioneUtenzeAction.inviaCredenzialiPecUtente(idUtenteSelezionato, null);
		    JSFUtility.addInfoMessage("", "Credenziali inviate correttamente");
		    
		}
		catch(Exception e) {
			logger.error("GestioneUtenzeBean - invio credenziali su PEC corrente fallito", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void inviaCredenzialiSuNuovoIndirizzoPec() {
		
		try {
			String msg = checkMail();
			if(msg==null){
			    String idUtenteSelezionato = getIdUtente();
				gestioneUtenzeAction.inviaCredenzialiPecUtente(idUtenteSelezionato, getNuovoIndirizzoPec());
				
				JSFUtility.addInfoMessage("", "Aggiornamento indirizzo PEC ed invio credenziali effettuati correttamente");
				JSFUtility.update("dialogRegistrazioneNuovaPec");
				JSFUtility.executeScript("dlgRegistraNuovaPec.hide()");
				ricercaCredenziali();
				JSFUtility.update("pannelloRisultatiRicerca");
			}
			else {
				JSFUtility.addWarningMessage("", msg);
			}
		}
		catch(Exception e) {
			
			logger.error("GestioneUtenzeBean - invio credenziali su nuovo indirizzo PEC fallito", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void impostaPecCorrente() {
		try {
			Map<String,String> requestParameters = JSFUtility.getFacesContext().getExternalContext().getRequestParameterMap();
		    String idUtenteSelezionato = requestParameters.get("idUtenteSelezionato");
		    String mailPECUtente = requestParameters.get("mailPECUtente");
		    String mailPECUtenteOriginale = requestParameters.get("mailPECUtenteOriginale");
		    setIdUtente(idUtenteSelezionato);
		    setVecchioIndirizzoPec(mailPECUtente);
		    setIndirizzoPecOriginale(mailPECUtenteOriginale);
		    setNuovoIndirizzoPec("");
		    setConfermaNuovoIndirizzoPec("");
		    JSFUtility.update("dialogRegistrazioneNuovaPec");
		}
		catch(Exception e) {
			
			logger.error("GestioneUtenzeBean - invio credenziali su nuovo indirizzo PEC fallito", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	private String checkFiltri(boolean bUtenteMds) throws GestioneErroriException {
		
		String sRet = null;
		if(bUtenteMds){
			if(getRegioneSelezionata()==null || getRegioneSelezionata().equalsIgnoreCase("") || getRegioneSelezionata().equalsIgnoreCase("-1"))
				sRet = "Inserire la Regione specifica";
		}
		else if ((datiUtenza.getNomeUtente()==null || datiUtenza.getNomeUtente().equalsIgnoreCase("")) &&
				(datiUtenza.getCognomeUtente()==null || datiUtenza.getCognomeUtente().equalsIgnoreCase("")) &&
				(datiUtenza.getCodiceFiscale()==null || datiUtenza.getCodiceFiscale().equalsIgnoreCase("")) &&
				(datiUtenza.getnProtocollo()==null || datiUtenza.getnProtocollo().equalsIgnoreCase("")))
				sRet = "Inserire almeno un filtro di ricerca";
		return sRet;
	}
	
	private String checkMail() throws GestioneErroriException {
		String sMsg = null;
		if((nuovoIndirizzoPec==null || nuovoIndirizzoPec.equalsIgnoreCase("")) ||
				(confermaNuovoIndirizzoPec==null || confermaNuovoIndirizzoPec.equalsIgnoreCase("")))
			sMsg = "I campi del nuovo indirizzo PEC sono obbligatori";	
		else {
				
			if(!bValidateMail(nuovoIndirizzoPec))
				sMsg = "Nuovo indirizzo PEC: formato non corretto";	
			else if(!bValidateMail(confermaNuovoIndirizzoPec))
				sMsg = "Conferma nuovo indirizzo PEC: formato non corretto";	
			else if(vecchioIndirizzoPec.equalsIgnoreCase(nuovoIndirizzoPec))
				sMsg = "Inserire un nuovo indirizzo PEC";	
			else if(!nuovoIndirizzoPec.equalsIgnoreCase(confermaNuovoIndirizzoPec))
				sMsg = "Il campo di conferma non corrisponde al nuovo indirizzo PEC inserito";	
		}
		return sMsg;
	}
	
	private boolean bValidateMail(String str) {
		String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		Matcher matcher = pattern.matcher(str);
		return matcher.matches();
	}

	public DatiUtenza getDatiUtenza() {
		return datiUtenza;
	}

	public void setDatiUtenza(DatiUtenza datiUtenza) {
		this.datiUtenza = datiUtenza;
	}

	public List<DatiUtenza> getElencoCredenzialiTrovate() {
		return elencoCredenzialiTrovate;
	}

	public void setElencoCredenzialiTrovate(
			List<DatiUtenza> elencoCredenzialiTrovate) {
		this.elencoCredenzialiTrovate = elencoCredenzialiTrovate;
	}

	public boolean isMostraElencoCredenzialiTrovate() {
		return mostraElencoCredenzialiTrovate;
	}

	public void setMostraElencoCredenzialiTrovate(
			boolean mostraElencoCredenzialiTrovate) {
		this.mostraElencoCredenzialiTrovate = mostraElencoCredenzialiTrovate;
	}

	public String getVecchioIndirizzoPec() {
		return vecchioIndirizzoPec;
	}

	public void setVecchioIndirizzoPec(String vecchioIndirizzoPec) {
		this.vecchioIndirizzoPec = vecchioIndirizzoPec;
	}

	public String getNuovoIndirizzoPec() {
		return nuovoIndirizzoPec;
	}

	public void setNuovoIndirizzoPec(String nuovoIndirizzoPec) {
		this.nuovoIndirizzoPec = nuovoIndirizzoPec;
	}

	public String getConfermaNuovoIndirizzoPec() {
		return confermaNuovoIndirizzoPec;
	}

	public void setConfermaNuovoIndirizzoPec(String confermaNuovoIndirizzoPec) {
		this.confermaNuovoIndirizzoPec = confermaNuovoIndirizzoPec;
	}

	public String getIndirizzoPecOriginale() {
		return indirizzoPecOriginale;
	}

	public void setIndirizzoPecOriginale(String indirizzoPecOriginale) {
		this.indirizzoPecOriginale = indirizzoPecOriginale;
	}

	public String getEmailOriginale() {
		return emailOriginale;
	}

	public void setEmailOriginale(String emailOriginale) {
		this.emailOriginale = emailOriginale;
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public List<RegioneSelect> getRegioniSelect() {
		return regioniSelect;
	}

	public void setRegioniSelect(List<RegioneSelect> regioniSelect) {
		this.regioniSelect = regioniSelect;
	}

	public boolean isbUtenteMds() {
		return bUtenteMds;
	}

	public void setbUtenteMds(boolean bUtenteMds) {
		this.bUtenteMds = bUtenteMds;
	}

	public String getRegioneSelezionata() {
		return regioneSelezionata;
	}

	public void setRegioneSelezionata(String regioneSelezionata) {
		this.regioneSelezionata = regioneSelezionata;
	}
	
}
