package com.accenture.CCFarm.pageBean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


@ManagedBean
@RequestScoped
public class HeaderBean implements Serializable {
	
	private String logoCodRegione = "";
	private String nome = "";
	private String cognome= "";
	private String nominativo = "";
	
	private UtenteRegioni utenteRegioni;
	private String username;
	private String codRegione;
	private Regione regione;
	private String labelBread;
	private String nomeRegione;
	
	private String manualeRegione = "none";
	private String manualeCommissione = "none";
	
	private String displayLinkBO = "none";
	
	
	private HttpSession session= null; 
	
	public HeaderBean(){
			this.init();
	}
	
	public void init()  {  
    	
		FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	session = req.getSession();

    	logoCodRegione=  (String) session.getAttribute(RepositorySession.ID_REGIONE);
    	if (logoCodRegione==null) logoCodRegione="";
        
    	nome =   (String) session.getAttribute(RepositorySession.NOME_UTENTE);
    	if (nome==null) nome="";
    	cognome=   (String) session.getAttribute(RepositorySession.COGNOME_UTENTE);
    	if (cognome==null) cognome="";
    	
    	nominativo = nome+" "+cognome;
    
    	utenteRegioni = (UtenteRegioni) session.getAttribute(RepositorySession.UTENTE_NSIS);
    	username = nome = utenteRegioni.getNome() + " " + utenteRegioni.getCognome();
    	codRegione = utenteRegioni.getCodRegione();
    	
    	RegioneHome regioneHome = new RegioneHome();
    	regione= regioneHome.findById(codRegione);
    	
    	if (codRegione.equalsIgnoreCase("MDS")){
    		labelBread="Ministero della Salute ";
    	} else{
    		labelBread="Regione ";
    	}
    	
    	nomeRegione = GenericConstants.getDescrRegioneByCod(codRegione);
    	
    	if (utenteRegioni!=null&& utenteRegioni.isRegione()){
    		manualeRegione = "block";
	    } else {
	    	manualeRegione = "none";
		}
    	if (utenteRegioni!=null&& utenteRegioni.isCommissione()){
    		manualeCommissione= "block";
	    } else {
	    	manualeCommissione = "none";
		}
    	
    	//Area BO
    	setDisplayLinkBO(utenteRegioni.isAbilitataAreaBO() ? "inline" : "none");
    	
	}


	public String getLogoCodRegione() {
		return logoCodRegione;
	}


	public void setLogoCodRegione(String logoCodRegione) {
		this.logoCodRegione = logoCodRegione;
	}


	public HttpSession getSession() {
		return session;
	}


	public void setSession(HttpSession session) {
		this.session = session;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCognome() {
		return cognome;
	}


	public void setCognome(String cognome) {
		this.cognome = cognome;
	}


	public String getNominativo() {
		return nominativo;
	}


	public void setNominativo(String nominativo) {
		this.nominativo = nominativo;
	}

	public UtenteRegioni getUtenteRegioni() {
		return utenteRegioni;
	}

	public void setUtenteRegioni(UtenteRegioni utenteRegioni) {
		this.utenteRegioni = utenteRegioni;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}

	public Regione getRegione() {
		return regione;
	}

	public void setRegione(Regione regione) {
		this.regione = regione;
	}
	
	public String getLabelBread() {
		return labelBread;
	}

	public void setLabelBread(String labelBread) {
		this.labelBread = labelBread;
	}
	
	public String getNomeRegione() {
		return nomeRegione;
	}

	public void setNomeRegione(String nomeRegione) {
		this.nomeRegione = nomeRegione;
	}
	
	public String getManualeRegione() {
		return manualeRegione;
	}

	public void setManualeRegione(String manualeRegione) {
		this.manualeRegione = manualeRegione;
	}

	public String getManualeCommissione() {
		return manualeCommissione;
	}

	public void setManualeCommissione(String manualeCommissione) {
		this.manualeCommissione = manualeCommissione;
	}

	public String getDisplayLinkBO() {
		return displayLinkBO;
	}

	public void setDisplayLinkBO(String displayLinkBO) {
		this.displayLinkBO = displayLinkBO;
	}

}
