package com.accenture.CCFarm.pageBean;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.StreamedContent;

import com.accenture.CCFarm.DAO.StoricoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoriaHome;
import com.accenture.CCFarm.action.PubblicaGraduatoriaAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.UtenteRegioni;
import com.engiweb.framework.dispatching.service.HttpRequestContextIFace;

@ManagedBean
@SessionScoped
public class PubblicaGraduatoriaBean {
	private String numeroPosInizialeString;
	private String numeroPosFinaleString;
	private String numeroProtocollo;
	private String cognome;
	private String nome;
	private int codiceGraduatoria;
	private String tipoGraduatoria;
	private String codRegione;
	private BigDecimal etaMedia;
	private BigDecimal punteggio;
	private String dataNascita;
	private Date dataValidazione;
	private String dataValidazioneString;
	private String dataValidazioneString_show;
	private BigDecimal indiceTotale;
	private BigDecimal indiceRelativo;
	private BigDecimal indiceRettificato;
	private BigDecimal indicePrimoInterpello;
	private BigDecimal indiceSecondoInterpello;

	private Date dataPubb;
	private String dataPubblicazioneString;
	private Date dataBolUffReg;
	private String dataBolUffRegString;
	private String numBolUffReg;

	private boolean mostraRisultatiRicerca;
	private boolean abilitaRicerca;
	private String mostraRisultatoBlok= "none";
	private String[] listaHelp;

	//Gestione DownLoad
	private StreamedContent fileDownload;

	private int rowBlock = 20;
	private int rowIniBlock = 0;
	private int rowFinBlock = 0;
	private int rowNumerUltimo = 0;
	private int numeroCandidati = 0;
	private int totaleCandidatiInt = 0;
	private int totalePagine;
	private int paginaCorrente = 0;
	private String pulsantePagIndietro = "true";
	private String pulsantePagAvanti = "true";
	private int startPage;
	private int maxPerPage;
	private String gradPubblicata="false";
	
	private int totaleSchede;
	
	private String bCaricaAtto = "false";
	private String invisibilitaCaricaAtto = "block";
	private String visibilitaCaricaAtto = "none";


	SimpleDateFormat fs = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");

	List<StoricoGraduatoria> listaStoricoGraduatoria;
	List<StoricoGraduatoria> listaGraduatoria;
	List<TipoGraduatoria> listaTipologiaGraduatoria;
	TipoGraduatoria tipoGradSelected = null;
	TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
	// RicercaStoricoGraduatoriaAction ricercaStoricoGraduatoriaAction;
	PubblicaGraduatoriaAction pubblicaGraduatoriaAction;

	HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);

	UtenteRegioni utenteReg = (UtenteRegioni) session.getAttribute(RepositorySession.UTENTE_NSIS);
	String codReg = utenteReg.getCodRegione();

	private Logger logger = CommonLogger.getLogger("RicercaStoricoGraduatoria");
	private final static String pageError = "errorPage.jsf";

	public PubblicaGraduatoriaBean() {
		init();
	}

	public PubblicaGraduatoriaBean(String noInit) {
	}

	public void init() {
		try {
            
			String codGrad = (String) session.getAttribute(RepositorySession.TIPO_GRAD_RELOAD);
			int codGradInt= 0;
			if (codGrad!=null){
				codGradInt = Integer.parseInt(codGrad);
				codiceGraduatoria=codGradInt;
			}
			
			if (codiceGraduatoria==0){
				codiceGraduatoria = -1;		
			}
		
			// ricercaStoricoGraduatoriaAction=new
			// RicercaStoricoGraduatoriaAction();
			pubblicaGraduatoriaAction = new PubblicaGraduatoriaAction();

			setListaHelp(Help.caricaHelpStoricoGraduatoria());

			//listaTipologiaGraduatoria = pubblicaGraduatoriaAction.findTipologieGraduatorie(cod_reg);
			listaTipologiaGraduatoria = pubblicaGraduatoriaAction.findUltimaVersioneGraduatorie(codReg);
			listaStoricoGraduatoria = null;

			if (listaTipologiaGraduatoria != null && listaTipologiaGraduatoria.size() == 0) {
				abilitaRicerca = true;
			} else {
				abilitaRicerca = false;
				mostraRisultatiRicerca = false;
				mostraRisultatoBlok= "none";
			}

			mostraRisultatiRicerca = false;
			mostraRisultatoBlok= "none";
//			JSFUtility.update("graduatorie");
			cercaSchede();

		} catch (GestioneErroriException e) {
			logger.error("Eccezione in Ricerca Storico Graduatoria: "
					+ e.getMessage());
		}
		// abilitaRicerca=true;
	}

	public void cercaSchede() {
		try {


			if (listaTipologiaGraduatoria.get(0) != null) {

				tipoGradSelected = listaTipologiaGraduatoria.get(0);
				tipoGraduatoria  = listaTipologiaGraduatoria.get(0).getDescrizione();
				session.setAttribute(RepositorySession.TIPO_GRADUATORIA, tipoGradSelected);
				if (tipoGradSelected.getDataPublicazione()!=null) {
					gradPubblicata="true";
					dataPubb= tipoGradSelected.getDataPublicazione();
					dataPubblicazioneString= StringUtil.dateToStringDDMMYYYY(tipoGradSelected.getDataPublicazione()); 
					dataBolUffReg=tipoGradSelected.getDataBollettinoUffReg();
					dataBolUffRegString = StringUtil.dateToStringDDMMYYYY(tipoGradSelected.getDataBollettinoUffReg());
				} else {
					gradPubblicata="false";
					dataPubb=null;
				    dataPubblicazioneString="";
				    dataBolUffReg=null;
					dataBolUffRegString =""; 
				}
				if (tipoGradSelected.getNumeroBollettinoUffReg()!=null && !tipoGradSelected.equals("")){
					numBolUffReg= tipoGradSelected.getNumeroBollettinoUffReg();
				} else {
					numBolUffReg= "";
				}
				if (tipoGradSelected.getAttoAmministrativoPDF()!=null){
					bCaricaAtto= "true";
					visibilitaCaricaAtto="block";
					invisibilitaCaricaAtto="none";
				} else {
					bCaricaAtto= "false";
					visibilitaCaricaAtto="none";
					invisibilitaCaricaAtto="block";
				}
				// totaleSchede =
				// ricercaStoricoGraduatoriaAction.findCount(cod_reg,
				// ""+codiceGraduatoria,getNumeroPosInizialeString(),getNumeroPosFinaleString(),getDataValidazioneString());
				totaleSchede = pubblicaGraduatoriaAction.findCount(codReg, ""+ codiceGraduatoria, getNumeroPosInizialeString(),getNumeroPosFinaleString(), getDataValidazioneString());
				totaleCandidatiInt = totaleSchede;

				if (this.getDataValidazione() != null) {
					dataValidazioneString = StringUtil.dateToStringDDMMYYYY(this.getDataValidazione());
					dataValidazioneString_show = dataValidazioneString;
				} else {
					// dataValidazioneString_show =
					// pubblicaGraduatoriaAction.findDataValidazione(cod_reg,""+
					// tipoGraduatoria);
					dataValidazioneString_show = StringUtil.dateToStringDDMMYYYY(listaTipologiaGraduatoria.get(0).getDataValutazione());
				}

				setMostraRisultatiRicerca(true);
				mostraRisultatoBlok= "block";
				
				if (totaleCandidatiInt > 0) {
					paginaCorrente = 1;
					if (totaleCandidatiInt > rowBlock) {
						totalePagine = totaleCandidatiInt / rowBlock;
						int remainderInt = 0;
						remainderInt = totaleCandidatiInt % rowBlock;
						if (remainderInt > 0) {
							totalePagine++;
						}
					} else {
						totalePagine = 1;
					}
					setRowIniBlock(0);
					setRowFinBlock(rowBlock);
					if (totaleCandidatiInt < rowBlock) {
						rowBlock = totaleCandidatiInt;
						setRowFinBlock(rowBlock);
					}
					setNumeroCandidati(totaleCandidatiInt);
					if (numeroCandidati == rowBlock
							|| numeroCandidati < rowBlock) {
						setPulsantePagAvanti("true");
						setPulsantePagIndietro("true");
					} else {
						setPulsantePagAvanti("false");
						setPulsantePagIndietro("true");
					}

					mostraRisultatiRicerca = true;
					mostraRisultatoBlok= "block";
				}

				this.primaPagina();
				dataValidazioneString = "";
				JSFUtility.update(":formGraduatoria:graduatorie");
				JSFUtility.update(":formRicerca:parametriRicercaGrad");
				//JSFUtility.update("idPubblicazioni");
			} else {
				JSFUtility.addWarningMessage("Selezionare una tipologia di graduatoria", "");
				JSFUtility.scrollTo("msgs");
			}

			// } else {
			// JSFUtility.addWarningMessage("Valorizzare correttamente i campi di ricerca relativi alle posizioni",
			// "");
			// JSFUtility.scrollTo("msgs");
			// }
		} catch (NumberFormatException e) {
			JSFUtility.addWarningMessage("","Inserire caratteri numerici nei campi relativi agli indici di posizione");
			JSFUtility.scrollTo("msgs");
		}

		catch (Exception e) {
			logger.error("Eccezione in Ricerca Graduatoria: " + e.getMessage());
			JSFUtility.addWarningMessage("", "Errore durante la ricerca della graduatoria");
			JSFUtility.scrollTo("msgs");
		}

	}
	
	
	public void cercaSchedeOld() {
		try {

			// if (!(((getNumeroPosInizialeString()!=null &&
			// !getNumeroPosInizialeString().equalsIgnoreCase(""))
			// && (getNumeroPosFinaleString()==null ||
			// getNumeroPosFinaleString().equalsIgnoreCase("")))
			// ||((getNumeroPosFinaleString()!=null &&
			// !getNumeroPosFinaleString().equalsIgnoreCase(""))
			// && (getNumeroPosInizialeString()==null ||
			// getNumeroPosInizialeString().equalsIgnoreCase("")))) &&
			// !((getNumeroPosInizialeString()!=null &&
			// !getNumeroPosInizialeString().equalsIgnoreCase("")) &&
			// (getNumeroPosFinaleString()!=null &&
			// !getNumeroPosFinaleString().equalsIgnoreCase("")) &&
			// (Integer.parseInt(getNumeroPosInizialeString())>
			// Integer.parseInt(getNumeroPosFinaleString())))
			// ){

			if (codiceGraduatoria != -1) {

				tipoGradSelected = listaTipologiaGraduatoria.get(codiceGraduatoria - 1);
				tipoGraduatoria  = listaTipologiaGraduatoria.get(codiceGraduatoria - 1).getDescrizione();
				session.setAttribute(RepositorySession.TIPO_GRADUATORIA, tipoGradSelected);
				if (tipoGradSelected.getDataPublicazione()!=null) {
					gradPubblicata="true";
					dataPubb= tipoGradSelected.getDataPublicazione();
					dataPubblicazioneString= StringUtil.dateToStringDDMMYYYY(tipoGradSelected.getDataPublicazione()); 
					dataBolUffReg=tipoGradSelected.getDataBollettinoUffReg();
					dataBolUffRegString = StringUtil.dateToStringDDMMYYYY(tipoGradSelected.getDataBollettinoUffReg());
				} else {
					gradPubblicata="false";
					dataPubb=null;
				    dataPubblicazioneString="";
				    dataBolUffReg=null;
					dataBolUffRegString =""; 
				}
				if (tipoGradSelected.getNumeroBollettinoUffReg()!=null && !tipoGradSelected.equals("")){
					numBolUffReg= tipoGradSelected.getNumeroBollettinoUffReg();
				} else {
					numBolUffReg= "";
				}
				if (tipoGradSelected.getAttoAmministrativoPDF()!=null){
					bCaricaAtto= "true";
					visibilitaCaricaAtto="block";
					invisibilitaCaricaAtto="none";
				} else {
					bCaricaAtto= "false";
					visibilitaCaricaAtto="none";
					invisibilitaCaricaAtto="block";
				}
				// totaleSchede =
				// ricercaStoricoGraduatoriaAction.findCount(cod_reg,
				// ""+codiceGraduatoria,getNumeroPosInizialeString(),getNumeroPosFinaleString(),getDataValidazioneString());
				totaleSchede = pubblicaGraduatoriaAction.findCount(codReg, ""+ codiceGraduatoria, getNumeroPosInizialeString(),getNumeroPosFinaleString(), getDataValidazioneString());
				totaleCandidatiInt = totaleSchede;

				if (this.getDataValidazione() != null) {
					dataValidazioneString = StringUtil.dateToStringDDMMYYYY(this.getDataValidazione());
					dataValidazioneString_show = dataValidazioneString;
				} else {
					// dataValidazioneString_show =
					// pubblicaGraduatoriaAction.findDataValidazione(cod_reg,""+
					// tipoGraduatoria);
					dataValidazioneString_show = StringUtil.dateToStringDDMMYYYY(listaTipologiaGraduatoria.get(codiceGraduatoria - 1).getDataValutazione());
				}

				setMostraRisultatiRicerca(true);
				mostraRisultatoBlok= "block";
				
				if (totaleCandidatiInt > 0) {
					paginaCorrente = 1;
					if (totaleCandidatiInt > rowBlock) {
						totalePagine = totaleCandidatiInt / rowBlock;
						int remainderInt = 0;
						remainderInt = totaleCandidatiInt % rowBlock;
						if (remainderInt > 0) {
							totalePagine++;
						}
					} else {
						totalePagine = 1;
					}
					setRowIniBlock(0);
					setRowFinBlock(rowBlock);
					if (totaleCandidatiInt < rowBlock) {
						rowBlock = totaleCandidatiInt;
						setRowFinBlock(rowBlock);
					}
					setNumeroCandidati(totaleCandidatiInt);
					if (numeroCandidati == rowBlock
							|| numeroCandidati < rowBlock) {
						setPulsantePagAvanti("true");
						setPulsantePagIndietro("true");
					} else {
						setPulsantePagAvanti("false");
						setPulsantePagIndietro("true");
					}

					mostraRisultatiRicerca = true;
					mostraRisultatoBlok= "block";
				}

				this.primaPagina();
				dataValidazioneString = "";
				JSFUtility.update(":formGraduatoria:graduatorie");
				JSFUtility.update(":formRicerca:parametriRicercaGrad");
				JSFUtility.update("idPubblicazioni");
			} else {
				JSFUtility.addWarningMessage("Selezionare una tipologia di graduatoria", "");
				JSFUtility.scrollTo("msgs");
			}

			// } else {
			// JSFUtility.addWarningMessage("Valorizzare correttamente i campi di ricerca relativi alle posizioni",
			// "");
			// JSFUtility.scrollTo("msgs");
			// }
		} catch (NumberFormatException e) {
			JSFUtility.addWarningMessage("","Inserire caratteri numerici nei campi relativi agli indici di posizione");
			JSFUtility.scrollTo("msgs");
		}

		catch (Exception e) {
			logger.error("Eccezione in Ricerca Graduatoria: " + e.getMessage());
			JSFUtility.addWarningMessage("", "Errore durante la ricerca della graduatoria");
			JSFUtility.scrollTo("msgs");
		}

	}


	// **************** metodi per paginazione **************************** //
	// ***********************************************************************
	// //

	
	public String pubblicaGraduatoria() {
		java.util.Date dataSys= new java.util.Date();
		JSFUtility.update(":formPubblica:idDataPubblicazione");
		JSFUtility.update(":formPubblica:idDataPubblicazionePubb");
		
		int dataSysInt = trasformaData(dataSys);
		try {
			if (tipoGradSelected.getAttoAmministrativoPDF()!=null){
			
				if (dataPubb!=null){
				    int dataPubInt = trasformaData(dataPubb);	
				    if (dataSysInt<= dataPubInt){
				        tipoGradSelected.setStatoGraduatoria("P");
				        tipoGradSelected.setDataPublicazione(dataPubb);
				        tipoGraduatoriaHome.saveOrUpdate(tipoGradSelected);
				        listaTipologiaGraduatoria = pubblicaGraduatoriaAction.findUltimaGradutaoriaValidata(codReg);
				        gradPubblicata = "true";
				    	dataPubblicazioneString= StringUtil.dateToStringDDMMYYYY(tipoGradSelected.getDataPublicazione()); 
				    	session.setAttribute(RepositorySession.TIPO_GRADUATORIA, tipoGradSelected);
				    	pubblicaGraduatoriaAction.updateDatiBando(codReg);
				    } else {
				    	gradPubblicata = "false";
						JSFUtility.addWarningMessage("La data di Pubblicazione non pu� essere antecedente alla data odierna", "");
						JSFUtility.scrollTo("msgs");
				    }
				}else {
					gradPubblicata = "false";
					JSFUtility.addWarningMessage("Inserire una data valida per la Pubblicazione della graduatoria", "");
					JSFUtility.scrollTo("msgs");
				}
			} else {
				gradPubblicata = "false";
				JSFUtility.addWarningMessage("Non � possibile Pubblicare una graduatoria senza aver caricato l'Atto Amministrativo", "");
				JSFUtility.scrollTo("msgs");
			}
		} catch (GestioneErroriException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	//metodo per pubblicare la graduatoria
	public String pubblicaGraduatoriaAll() {
		java.util.Date dataSys= new java.util.Date();
		JSFUtility.update(":formPubblica:idDataPubblicazione");
		JSFUtility.update(":formPubblica:idDataPubblicazionePubb");
		
		int dataSysInt = trasformaData(dataSys);
		try {
			if (tipoGradSelected.getAttoAmministrativoPDF()!=null){
			
				if (dataPubb!=null){
				    int dataPubInt = trasformaData(dataPubb);	
				    if (dataSysInt<= dataPubInt && dataBolUffReg!=null && numBolUffReg!=null && !numBolUffReg.trim().equals("")){
				        gradPubblicata = "true";
				    } else {
				    	if (numBolUffReg==null || numBolUffReg.trim().equals("")){
				    		gradPubblicata = "false";
				    		JSFUtility.addWarningMessage("Il numero Bollettino Ufficiale Regionale non valorizzata", "");
							JSFUtility.scrollTo("msgs");
				    	} else {
				    		if (dataBolUffReg==null ){
				    			gradPubblicata = "false";
				    			JSFUtility.addWarningMessage("La data Bollettino Ufficiale Regionale non valorizzata", "");
				    			JSFUtility.scrollTo("msgs");
					    	} else{
					    		gradPubblicata = "false";
								JSFUtility.addWarningMessage("La data di Pubblicazione non pu� essere antecedente alla data odierna", "");
								JSFUtility.scrollTo("msgs");
						    }
				    	}
				    }
				}else {
					gradPubblicata = "false";
					JSFUtility.addWarningMessage("Inserire una data valida per la Pubblicazione della graduatoria", "");
					JSFUtility.scrollTo("msgs");
				}
			} else {
				gradPubblicata = "false";
				JSFUtility.addWarningMessage("Non � possibile Pubblicare una graduatoria senza aver caricato l'Atto Amministrativo", "");
				JSFUtility.scrollTo("msgs");
			}
			
			
			if(gradPubblicata.equalsIgnoreCase("true")){
			    tipoGradSelected.setStatoGraduatoria("P");
		        tipoGradSelected.setDataPublicazione(dataPubb);
		        tipoGradSelected.setNumeroBollettinoUffReg(numBolUffReg);
		        tipoGradSelected.setDataBollettinoUffReg(dataBolUffReg);
		        tipoGraduatoriaHome.saveOrUpdate(tipoGradSelected);
		       // listaTipologiaGraduatoria = pubblicaGraduatoriaAction.findUltimaGradutaoriaValidata(codReg);
		        dataPubblicazioneString= StringUtil.dateToStringDDMMYYYY(tipoGradSelected.getDataPublicazione()); 
		        dataBolUffRegString= StringUtil.dateToStringDDMMYYYY(tipoGradSelected.getDataBollettinoUffReg()); 
		    	session.setAttribute(RepositorySession.TIPO_GRADUATORIA, tipoGradSelected);
		    	pubblicaGraduatoriaAction.updateDatiBando(codReg);
		    	JSFUtility.addInfoMessage("Graduatoria pubblicata con successo", "");
		    }
			
		} catch (GestioneErroriException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	private int trasformaData(Date data) {
		String dataString = fs.format(data);
		String dataConfert = dataString.substring(6, 10)
				           + dataString.substring(3, 5) 
				           + dataString.substring(0, 2);
		return Integer.parseInt(dataConfert);
	}

	public String cambiaGraduatoria(){
		
		abilitaRicerca = false;
		mostraRisultatiRicerca = false;
		mostraRisultatoBlok= "none";
//		JSFUtility.update(":formRicerca:parametriRicercaGrad");
//		JSFUtility.update("idPubblicazioni");
//		JSFUtility.update("formRicerca");
//		JSFUtility.update("formUpLoad");
//		JSFUtility.update("formDownload");
//		JSFUtility.update("formPubblica");
//		JSFUtility.update("formGraduatoria");
//		
		if (codiceGraduatoria==-1) codiceGraduatoria=0;
		session.setAttribute(RepositorySession.TIPO_GRAD_RELOAD, ""+codiceGraduatoria );
//		JSFUtility.executeScript("window.location.reload()");
		JSFUtility.executeScript("window.location.href('../ChiamaPaginaPubbReloadServlet?PAGE_SEND=pubblicaGraduatoria.jsf')");
		
//		init();
		
		return null;
				
	}

	
	//Gestione Upload File Atto Amministrativo
	public void upLoadAttoAmm(FileUploadEvent event)
	{	
		try{
			String sMsg = pubblicaGraduatoriaAction.upLoadAttoAmministrativo(event, this);
			if(sMsg!=null){
				JSFUtility.addWarningMessage(sMsg, "");
				JSFUtility.scrollTo("msgs");
			} else{
				session.setAttribute(RepositorySession.TIPO_GRADUATORIA, tipoGradSelected);
				JSFUtility.addInfoMessage("Atto Amministrativo caricato correttamente", "");
				JSFUtility.scrollTo("msgs");
			}
			//else 
				//addMessage("Carica Bando", "File Bando caricato con successo.");
		} catch (GestioneErroriException e) {
			logger.error("Publica graduatoria - uploadBando: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}	
		
	}

	
	
	public String esportaGraduatoriaPDF() {
		
//		HttpRequestContextIFace requestContextIFace = (HttpRequestContextIFace) RequestContext.getCurrentInstance();
//		HttpServletResponse response=    requestContextIFace.getHttpResponse();
		FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
        
		byte[] pdfData = tipoGradSelected.getGraduatoriaPDF();
    	try
    	{ 
    		response.reset(); 
            response.setContentType("application/pdf"); 
            response.setContentLength((int) pdfData.length); 
            response.setHeader("Content-disposition", "attachment; filename=\"Graduatoria.pdf\"");
            ByteArrayInputStream in = null;             
            BufferedInputStream input = null; 
            BufferedOutputStream output = null; 
            final int buffersize = (int) pdfData.length; 
            try 
            { 
            	in = new ByteArrayInputStream(pdfData);
            	input = new BufferedInputStream(in); 
            	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
            	byte[] buffer = new byte[buffersize]; 
            	for (int length; (length = input.read(buffer)) > 0;) 
            	{	 
            		output.write(buffer, 0, length); 
            		output.flush();
            	}            	
            } 
            finally 
            { 
            	if (input != null) 
            		try 
            		{ 
            			input.close(); 
            			output.close();
            		} 
            		catch (IOException e) 
            		{ 
            			e.printStackTrace(); 
            		} 
            } 
//	            facesContext.responseComplete(); 

    	}
    	catch (IOException e)
    	{
    		e.printStackTrace();
    	}

		
		
		return null;
	}

	public String paginaInizio() {

		try {
			startPage = 0;
			maxPerPage = rowBlock;
			rowNumerUltimo = maxPerPage;
			// listaStoricoGraduatoria =
			// ricercaStoricoGraduatoriaAction.getPageStoricoGraduatoria(this,
			// this.startPage, this.maxPerPage, cod_reg);
			listaStoricoGraduatoria = pubblicaGraduatoriaAction.getPageStoricoGraduatoria(this, this.startPage,this.maxPerPage, codReg);

		} catch (GestioneErroriException e) {
			logger.error("StoricoGraduatoria- paginaInizio : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}

		return null;
	}

	public String paginaAvanti() {

		setRowIniBlock(getRowNumerUltimo());
		setRowFinBlock(getRowIniBlock() + getRowBlock());

		paginaCorrente++;
		setPulsantePagAvanti("false");
		setPulsantePagIndietro("false");

		if (getRowFinBlock() == getNumeroCandidati()
				|| getRowFinBlock() > getNumeroCandidati()) {
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
			setPulsantePagIndietro("false");

		}

		startPage = getRowNumerUltimo();
		maxPerPage = rowBlock;
		if (rowNumerUltimo < rowBlock)
			startPage = 0;
		try {
			// listaStoricoGraduatoria =
			// ricercaStoricoGraduatoriaAction.getPageStoricoGraduatoria(this,
			// this.startPage, this.maxPerPage, cod_reg);
			listaStoricoGraduatoria = pubblicaGraduatoriaAction.getPageStoricoGraduatoria(this, this.startPage,this.maxPerPage, codReg);
			setRowNumerUltimo(getRowNumerUltimo() + 20);

		} catch (GestioneErroriException e) {
			logger.error("StoricoGraduatoria - paginaAvanti : "
					+ e.getMessage());
			JSFUtility.redirect(pageError);
		}

		return null;
	}

	public String ultimaPagina() {
		rowFinBlock = getNumeroCandidati();
		setRowIniBlock(getRowFinBlock() - getRowBlock());

		paginaCorrente = totalePagine;
		setPulsantePagAvanti("false");
		setPulsantePagIndietro("false");

		if (getRowFinBlock() == getNumeroCandidati()
				|| getRowFinBlock() > getNumeroCandidati()) {
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
			setPulsantePagIndietro("false");
		}

		startPage = totaleCandidatiInt - rowBlock + 1;
		maxPerPage = rowBlock;
		rowNumerUltimo = totaleCandidatiInt;
		try {
			// listaStoricoGraduatoria =
			// ricercaStoricoGraduatoriaAction.getPageStoricoGraduatoria(this,
			// this.startPage, this.maxPerPage, cod_reg);
			listaStoricoGraduatoria = pubblicaGraduatoriaAction.getPageStoricoGraduatoria(this, this.startPage,this.maxPerPage, codReg);

		} catch (GestioneErroriException e) {
			logger.error("StoricoGraduatoria - ultimaPagina : "
					+ e.getMessage());
			JSFUtility.redirect(pageError);
		}

		return null;
	}

	public String primaPagina() {
		rowIniBlock = 0;
		setRowFinBlock(getRowIniBlock() + getRowBlock());

		paginaCorrente = 1;
		setPulsantePagAvanti("false");
		setPulsantePagIndietro("false");

		if (getRowIniBlock() == 0 || getRowIniBlock() < 0) {
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
			setPulsantePagIndietro("true");

		}

		paginaInizio();
		return null;
	}

	public String paginaIndietro() {
		rowIniBlock = rowIniBlock - rowBlock;
		setRowFinBlock(getRowIniBlock() + getRowBlock());

		paginaCorrente--;
		if (paginaCorrente == 0)
			paginaCorrente = 1;
		setPulsantePagAvanti("false");
		setPulsantePagIndietro("false");

		if (getRowIniBlock() == 0 || getRowIniBlock() < 0) {
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
			setPulsantePagIndietro("true");
		}

		startPage = startPage - rowBlock;
		maxPerPage = rowBlock;
		if (startPage < 0)
			startPage = 0;
		try {
			// listaStoricoGraduatoria =
			// ricercaStoricoGraduatoriaAction.getPageStoricoGraduatoria(this,
			// this.startPage, this.maxPerPage, cod_reg );
			listaStoricoGraduatoria = pubblicaGraduatoriaAction.getPageStoricoGraduatoria(this, this.startPage,this.maxPerPage, codReg);

		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaExAequoBean - paginaIndietro : "
					+ e.getMessage());
			JSFUtility.redirect(pageError);
		}
		return null;
	}

	public int getNumeroCandidati() {
		return numeroCandidati;
	}

	public void setNumeroCandidati(int numeroCandidati) {
		this.numeroCandidati = numeroCandidati;
	}

	public String getPulsantePagIndietro() {
		return pulsantePagIndietro;
	}

	public void setPulsantePagIndietro(String pulsantePagIndietro) {
		this.pulsantePagIndietro = pulsantePagIndietro;
	}

	public String getPulsantePagAvanti() {
		return pulsantePagAvanti;
	}

	public void setPulsantePagAvanti(String pulsantePagAvanti) {
		this.pulsantePagAvanti = pulsantePagAvanti;
	}

	public int getRowBlock() {
		return rowBlock;
	}

	public void setRowBlock(int rowBlock) {
		this.rowBlock = rowBlock;
	}

	public int getRowIniBlock() {
		return rowIniBlock;
	}

	public void setRowIniBlock(int rowIniBlock) {
		this.rowIniBlock = rowIniBlock;
	}

	public int getRowFinBlock() {
		return rowFinBlock;
	}

	public void setRowFinBlock(int rowFinBlock) {
		this.rowFinBlock = rowFinBlock;
	}

	public int getRowNumerUltimo() {
		return rowNumerUltimo;
	}

	public void setRowNumerUltimo(int rowNumerUltimo) {
		this.rowNumerUltimo = rowNumerUltimo;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getMaxPerPage() {
		return maxPerPage;
	}

	public void setMaxPerPage(int maxPerPage) {
		this.maxPerPage = maxPerPage;
	}

	public String getNumeroPosInizialeString() {
		return numeroPosInizialeString;
	}

	public void setNumeroPosInizialeString(String numeroPosInizialeString) {
		this.numeroPosInizialeString = numeroPosInizialeString;
	}

	public String getNumeroPosFinaleString() {
		return numeroPosFinaleString;
	}

	public void setNumeroPosFinaleString(String numeroPosFinaleString) {
		this.numeroPosFinaleString = numeroPosFinaleString;
	}

	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}

	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipoGraduatoria() {
		return tipoGraduatoria;
	}

	public void setTipoGraduatoria(String tipoGraduatoria) {
		this.tipoGraduatoria = tipoGraduatoria;
	}

	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}

	public BigDecimal getEtaMedia() {
		return etaMedia;
	}

	public void setEtaMedia(BigDecimal etaMedia) {
		this.etaMedia = etaMedia;
	}

	public BigDecimal getPunteggio() {
		return punteggio;
	}

	public void setPunteggio(BigDecimal punteggio) {
		this.punteggio = punteggio;
	}

	public Date getDataValidazione() {
		return dataValidazione;
	}

	public void setDataValidazione(Date dataValidazione) {
		this.dataValidazione = dataValidazione;
	}

	public String getDataValidazioneString() {
		return dataValidazioneString;
	}

	public void setDataValidazioneString(String dataValidazioneString) {
		this.dataValidazioneString = dataValidazioneString;
	}

	public BigDecimal getIndiceTotale() {
		return indiceTotale;
	}

	public void setIndiceTotale(BigDecimal indiceTotale) {
		this.indiceTotale = indiceTotale;
	}

	public BigDecimal getIndiceRettificato() {
		return indiceRettificato;
	}

	public void setIndiceRettificato(BigDecimal indiceRettificato) {
		this.indiceRettificato = indiceRettificato;
	}

	public BigDecimal getIndicePrimoInterpello() {
		return indicePrimoInterpello;
	}

	public void setIndicePrimoInterpello(BigDecimal indicePrimoInterpello) {
		this.indicePrimoInterpello = indicePrimoInterpello;
	}

	public BigDecimal getIndiceSecondoInterpello() {
		return indiceSecondoInterpello;
	}

	public void setIndiceSecondoInterpello(BigDecimal indiceSecondoInterpello) {
		this.indiceSecondoInterpello = indiceSecondoInterpello;
	}

	public boolean isMostraRisultatiRicerca() {
		return mostraRisultatiRicerca;
	}

	public void setMostraRisultatiRicerca(boolean mostraRisultatiRicerca) {
		this.mostraRisultatiRicerca = mostraRisultatiRicerca;
	}

	public String[] getListaHelp() {
		return listaHelp;
	}

	public void setListaHelp(String[] listaHelp) {
		this.listaHelp = listaHelp;
	}

	public String getCodReg() {
		return codReg;
	}

	public void setCodReg(String codReg) {
		this.codReg = codReg;
	}

	public int getTotaleSchede() {
		return totaleSchede;
	}

	public void setTotaleSchede(int totaleSchede) {
		this.totaleSchede = totaleSchede;
	}

	public List<StoricoGraduatoria> getListaGraduatoria() {
		return listaGraduatoria;
	}

	public void setListaGraduatoria(List<StoricoGraduatoria> listaGraduatoria) {
		this.listaGraduatoria = listaGraduatoria;
	}

	public List<TipoGraduatoria> getListaTipologiaGraduatoria() {
		return listaTipologiaGraduatoria;
	}

	public void setListaTipologiaGraduatoria(
			List<TipoGraduatoria> listaTipologiaGraduatoria) {
		this.listaTipologiaGraduatoria = listaTipologiaGraduatoria;
	}

	public boolean isAbilitaRicerca() {
		return abilitaRicerca;
	}

	public void setAbilitaRicerca(boolean abilitaRicerca) {
		this.abilitaRicerca = abilitaRicerca;
	}

	public int getCodiceGraduatoria() {
		return codiceGraduatoria;
	}

	public void setCodiceGraduatoria(int codiceGraduatoria) {
		this.codiceGraduatoria = codiceGraduatoria;
	}

	public BigDecimal getIndiceRelativo() {
		return indiceRelativo;
	}

	public void setIndiceRelativo(BigDecimal indiceRelativo) {
		this.indiceRelativo = indiceRelativo;
	}

	public String getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}

	public String getDataValidazioneString_show() {
		return dataValidazioneString_show;
	}

	public void setDataValidazioneString_show(String dataValidazioneString_show) {
		this.dataValidazioneString_show = dataValidazioneString_show;
	}

	public List<StoricoGraduatoria> getListaStoricoGraduatoria() {
		return listaStoricoGraduatoria;
	}

	public void setListaStoricoGraduatoria(
			List<StoricoGraduatoria> listaStoricoGraduatoria) {
		this.listaStoricoGraduatoria = listaStoricoGraduatoria;
	}

	// public RicercaStoricoGraduatoriaAction
	// getRicercaStoricoGraduatoriaAction() {
	// return ricercaStoricoGraduatoriaAction;
	// }
	//
	// public void setRicercaStoricoGraduatoriaAction(
	// RicercaStoricoGraduatoriaAction ricercaStoricoGraduatoriaAction) {
	// this.ricercaStoricoGraduatoriaAction = ricercaStoricoGraduatoriaAction;
	// }

	public int getPaginaCorrente() {
		return paginaCorrente;
	}

	public void setPaginaCorrente(int paginaCorrente) {
		this.paginaCorrente = paginaCorrente;
	}

	// public LazyDataModel<StoricoGraduatoria> getStoricoGraduatoriaList()
	// throws GestioneErroriException{
	//
	// try
	// {
	// if(graduatorie==null){
	// if (this.numeroPosInizialeString!=null &&
	// !this.numeroPosInizialeString.equalsIgnoreCase("") &&
	// this.numeroPosFinaleString!=null &&
	// !this.numeroPosFinaleString.equalsIgnoreCase("") &&
	// this.codiceGraduatoria!=-1
	// ){
	// graduatorie = new
	// StoricoGraduatoriaLazyList(cod_reg,Integer.parseInt(this.numeroPosInizialeString),Integer.parseInt(this.numeroPosFinaleString),""+this.codiceGraduatoria,totaleSchede,dataValidazioneString);
	// }
	// else {
	// graduatorie = new
	// StoricoGraduatoriaLazyList(cod_reg,1,totaleSchede,""+codiceGraduatoria,totaleSchede,dataValidazioneString);
	// }
	//
	// }
	//
	// }
	// catch(Exception e)
	// {
	// logger.error("Eccezione in SchedaValutazioneBean - updateGraduatoria: " +
	// e.getMessage());
	// JSFUtility.addWarningMessage("",
	// "Errore durante la visualizzazione della graduatoria");
	// JSFUtility.scrollTo("msgs");
	//
	// }
	//
	//
	// return graduatorie;
	//
	// }

	public int getTotaleCandidatiInt() {
		return totaleCandidatiInt;
	}

	public void setTotaleCandidatiInt(int totaleCandidatiInt) {
		this.totaleCandidatiInt = totaleCandidatiInt;
	}

	public int getTotalePagine() {
		return totalePagine;
	}

	public void setTotalePagine(int totalePagine) {
		this.totalePagine = totalePagine;
	}


	public Date getDataPubb() {
		return dataPubb;
	}

	public void setDataPubb(Date dataPubb) {
		this.dataPubb = dataPubb;
	}

	public UtenteRegioni getUtenteReg() {
		return utenteReg;
	}

	public void setUtenteReg(UtenteRegioni utenteReg) {
		this.utenteReg = utenteReg;
	}

	public TipoGraduatoria getTipoGradSelected() {
		return tipoGradSelected;
	}

	public void setTipoGradSelected(TipoGraduatoria tipoGradSelected) {
		this.tipoGradSelected = tipoGradSelected;
	}

	public String getGradPubblicata() {
		return gradPubblicata;
	}

	public void setGradPubblicata(String gradPubblicata) {
		this.gradPubblicata = gradPubblicata;
	}

	public String getDataPubblicazioneString() {
		return dataPubblicazioneString;
	}

	public void setDataPubblicazioneString(String dataPubblicazioneString) {
		this.dataPubblicazioneString = dataPubblicazioneString;
	}

	public StreamedContent getFileDownload() {
		return fileDownload;
	}

	public void setFileDownload(StreamedContent fileDownload) {
		this.fileDownload = fileDownload;
	}

	public String getbCaricaAtto() {
		return bCaricaAtto;
	}

	public void setbCaricaAtto(String bCaricaAtto) {
		this.bCaricaAtto = bCaricaAtto;
	}

	public String getInvisibilitaCaricaAtto() {
		return invisibilitaCaricaAtto;
	}

	public void setInvisibilitaCaricaAtto(String invisibilitaCaricaAtto) {
		this.invisibilitaCaricaAtto = invisibilitaCaricaAtto;
	}

	public String getVisibilitaCaricaAtto() {
		return visibilitaCaricaAtto;
	}

	public void setVisibilitaCaricaAtto(String visibilitaCaricaAtto) {
		this.visibilitaCaricaAtto = visibilitaCaricaAtto;
	}

	public String getMostraRisultatoBlok() {
		return mostraRisultatoBlok;
	}

	public void setMostraRisultatoBlok(String mostraRisultatoBlok) {
		this.mostraRisultatoBlok = mostraRisultatoBlok;
	}

	public Date getDataBolUffReg() {
		return dataBolUffReg;
	}

	public void setDataBolUffReg(Date dataBolUffReg) {
		this.dataBolUffReg = dataBolUffReg;
	}

	public String getNumBolUffReg() {
		return numBolUffReg;
	}

	public void setNumBolUffReg(String numBolUffReg) {
		this.numBolUffReg = numBolUffReg;
	}

	public String getDataBolUffRegString() {
		return dataBolUffRegString;
	}

	public void setDataBolUffRegString(String dataBolUffRegString) {
		this.dataBolUffRegString = dataBolUffRegString;
	}

	
	

}