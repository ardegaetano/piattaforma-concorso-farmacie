package com.accenture.CCFarm.pageBean;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.event.FileUploadEvent;

import com.accenture.CCFarm.action.DatiBandoAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.JSFUtility;


@ManagedBean
@SessionScoped
public class Bando {

	Logger logger = CommonLogger.getLogger("Bando");
	DatiBandoAction bandoController = null;
	BandoRegionale bandoRegionale = null;
	String esito = null;
	String pageError = "errorPage.jsf";
	String abilitaSalva = "true";
	public Bando(){
		bandoController = new DatiBandoAction();
		bandoRegionale = new BandoRegionale();
		bandoRegionale.setListaHelp(Help.caricaHelpDatiBando());
	}
	
	//INIT PAGINA
	public void initDatiBando() {  
		try{
			bandoController.loadPaginaInserimento(getBandoRegionale());
		} catch (GestioneErroriException e) {
			logger.error("Bando - initDatiBando: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void initDatiSedi() {  
		try{
			bandoController.loadPaginaInserimento(getBandoRegionale());
		} catch (GestioneErroriException e) {
			logger.error("Bando - initDatiSedi: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void sedibandoDB() {  
		try{
			bandoController.loadPaginaInserimento(getBandoRegionale());
		} catch (GestioneErroriException e) {
			logger.error("Bando - initDatiSedi: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}
	}

	public void initValidaBando() {  
		try{
			bandoController.loadPaginaInserimento(getBandoRegionale());
		} catch (GestioneErroriException e) {
			logger.error("Bando - initValidaBando: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}
	}
	
	//INDIETRO gestione a livello di singola PAGINA
	public String backDatiBando()
	{	
		getBandoRegionale().clearBean(1);
		return "homeRegioni";
		//JSFUtility.redirect("homeRegioni.jsf");
	}
	
	public String backDatiSede()
	{	
		getBandoRegionale().clearBean(2);
    	return "homeRegioni";
	//	JSFUtility.redirect("homeRegioni.jsf");
	}
	
	public String backValidaBando()
	{	
		getBandoRegionale().clearBean(3);
		return "homeRegioni";
//		JSFUtility.redirect("homeRegioni.jsf");
	}
	 

	public String caricaFileDownload()
	{
		try{
			bandoController.caricaFileDownload(getBandoRegionale());
			return "";
		} catch (GestioneErroriException e) {
			logger.error("Bando - caricaFileDownload: " + e.getMessage(), e);
			return "pageError";
			//JSFUtility.redirect(pageError);
		}
	}
	
	public String salvaDatiBando()
	{	
		String sPage = "";
		
		try{
			String sMsg = bandoController.insertDatiBando(this);
			if(sMsg!=null  && !sMsg.equalsIgnoreCase("")){
				addMessageError(sMsg);
				return "bandoRegionale";
			}	
			else {
				//addMessage("Caratteristiche Bando", "Salvataggio avvenuto correttamente");
				sPage = "homeRegioni.jsf";
			}
			return sPage;
		} catch (GestioneErroriException e) {
			logger.error("Bando - salvaDatiBando: " + e.getMessage(), e);
			return pageError;
			//sPage = pageError;
		}
		
//		JSFUtility.redirect(sPage);
//		return null;
	}
	
	public String salvaDatiSedi()
	{	String sPage = "";
		try{
			String sMsg = bandoController.insertDatiSedi(this);
			if(sMsg!=null){
				addMessageError(sMsg);
				return "gestioneSedi";
			}
			else {
				//addMessage("Gestione Sedi", "Salvataggio avvenuto correttamente");
				sPage = "homeRegioni.jsf";
			}
			return sPage;
		} catch (GestioneErroriException e) {
			logger.error("Bando - salvaDatiSedi: " + e.getMessage(), e);
			return pageError;
		}
		
//		JSFUtility.redirect(sPage);
//		return null;
	}
	
	public String validaBando()
	{	
		String sPage = "";
		try{
			String sMsg = bandoController.validaBando(this);
			if(sMsg!=null && !sMsg.equalsIgnoreCase("")) {	
				addMessageError(sMsg);
				return "validaConcorso";
//				return null;
			}
			else {
				//addMessage("Validazione Bando", "Salvataggio avvenuto correttamente");
				return "homeRegioni.jsf";
			}
//			return sPage;
		} catch (GestioneErroriException e) {
			logger.error("Bando - validaBando: " + e.getMessage(), e);
			return pageError;
		}
//		JSFUtility.redirect(sPage);
//		return null;
	}
	
	public String esiti()
	{
		return getEsito();
	}
	
	//Gestione Upload File
	public void uploadBando(FileUploadEvent event)
	{	
		try{
			String sMsg = bandoController.uploadBando(event, this);
			if(sMsg!=null)
				addMessageError(sMsg);
				
			//else 
				//addMessage("Carica Bando", "File Bando caricato con successo.");
		} catch (GestioneErroriException e) {
			logger.error("Bando - uploadBando: " + e.getMessage(), e);
			JSFUtility.redirect(pageError);
		}	
		
	}
	
	public void uploadSedi(FileUploadEvent event)
	{	
		try{
			String sMsg = bandoController.uploadSedi(event, this);
			if(sMsg!=null)
				addMessageError(sMsg);
			this.abilitaSalva="false";
			JSFUtility.update("btnS");
			//else 
				//addMessage("Carica Sedi", "File CSV caricato con successo.");
		} catch (GestioneErroriException e) {
			logger.error("Bando - uploadSedi: " + e.getMessage(), e);
			JSFUtility.redirect(pageError); 
		}		
	}
	
	public void addMessage(String Intestazione, String summary) throws GestioneErroriException {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,Intestazione, summary);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
	public void addMessageError(String summary) throws GestioneErroriException {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN,"ATTENZIONE", summary);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
	public BandoRegionale getBandoRegionale() {
		return bandoRegionale;
	}

	public void setBandoRegionale(BandoRegionale bandoRegionale) {
		this.bandoRegionale = bandoRegionale;
	}

	public String getEsito() {
		return esito;
	}

	public void setEsito(String esito) {
		this.esito = esito;
	}

	public String getAbilitaSalva() {
		return abilitaSalva;
	}

	public void setAbilitaSalva(String abilitaSalva) {
		this.abilitaSalva = abilitaSalva;
	}
	
	

}
