package com.accenture.CCFarm.pageBean;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.CandidatoInterpello;
import com.accenture.CCFarm.action.PredisponiInterpelloAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.exception.SediException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.UtenteRegioni;

@ManagedBean
@ViewScoped
public class PredisponiInterpelloBean {
	
	private static final Logger log = CommonLogger.getLogger("PredisponiInterpelloBean");
	private static final String pageError = "errorPage.jsf";
	
	private static final int numeroGiorniPreavvisoInterpello  = Integer.parseInt(AppProperties.getAppProperties().getProperty("numero.giorni.preavviso.interpello"));
	private static final int numeroGiorniValiditaInterpello   = Integer.parseInt(AppProperties.getAppProperties().getProperty("numero.giorni.validita.interpello"));
	private static final int orarioInizioValiditaInterpello  = Integer.parseInt(AppProperties.getAppProperties().getProperty("orario.inizio.validita.interpello"));
	private static final int orarioTermineValiditaInterpello  = Integer.parseInt(AppProperties.getAppProperties().getProperty("orario.termine.validita.interpello"));
	
	private PredisponiInterpelloAction predisponiInterpelloAction;
	
	private String codiceRegione;
	private List<CandidatoInterpello> candidatiInterpello;
	private int numeroInterpello;
	private int numeroCandidati;
	
	private Date minDataInizioInterpello;
	private Date dataInizioInterpello;
	private String dataInizioInterpelloString;
	private Date minDataFineInterpello;
	private Date dataFineInterpello;
	private String dataFineInterpelloString;
	
	public PredisponiInterpelloBean() throws GestioneErroriException {
		
		try {
			
			init();
		}
		catch(Exception e) {
			
			log.error("PredisponiInterpelloBean - costruzione del bean fallita", e);
			throw new GestioneErroriException("PredisponiInterpelloBean - costruzione del bean fallita");
		}
	}
	
	private void init() throws GestioneErroriException {
		
		//recupero codice regione dai dati in sessione
		FacesContext context = JSFUtility.getFacesContext();
    	HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = request.getSession();
    	
    	UtenteRegioni utenteRegioni = (UtenteRegioni) session.getAttribute(RepositorySession.UTENTE_NSIS);
		setCodiceRegione(utenteRegioni.getCodRegione());
		
		if(getCodiceRegione() == null || getCodiceRegione().isEmpty())
			throw new RuntimeException("Codice regione non presente tra i dati del profilo utente");
		
		predisponiInterpelloAction = new PredisponiInterpelloAction(getCodiceRegione());
		
		//verifica se esiste un interpello gi� in corso
		if(predisponiInterpelloAction.isInterpelloInCorso()) {
			
			//determina progressivo dell'interpello in corso
			setNumeroInterpello(predisponiInterpelloAction.getProgressivoInterpelloCorrente());
			
			//determina elenco candidati per l'interpello in corso
			setCandidatiInterpello(
				predisponiInterpelloAction.trovaCandidatiInterpelloCorrente()
			);
			
			//determina date registrate per l'interpello in corso
			setDataInizioInterpello(
					predisponiInterpelloAction.getDataInizioInterpelloCorrente()
			);
			setDataFineInterpello(
					predisponiInterpelloAction.getDataFineInterpelloCorrente()
			);
			
		}
		
		setMinDataInizioInterpello(
				DateUtil.getDataEstremoIntervallo(DateUtil.dataOdierna(), numeroGiorniPreavvisoInterpello, 0)
		);
		
		setMinDataFineInterpello(
				DateUtil.getDataEstremoIntervallo(DateUtil.dataOdierna(), numeroGiorniPreavvisoInterpello, 0)
		);
	}
	
	public boolean isInterpelloPredisposto() {
		return predisponiInterpelloAction.isInterpelloPredisposto();
	}
	
	public boolean isInterpelloPubblicato() {
		return predisponiInterpelloAction.isInterpelloPubblicato();
	}
	
	public boolean isInterpelloChiuso() {
		return predisponiInterpelloAction.isInterpelloChiuso();
	}
	
	public boolean isInterpelloInCorso() {
		return predisponiInterpelloAction.isInterpelloInCorso();
	}
	
	public boolean isInterpelloPubblicabile() {
		
		return isInterpelloPredisposto() == true &&
			   getDataInizioInterpello() != null &&
			   getDataFineInterpello() != null;
	}
	
	private boolean isDomenica(Date date) {
		
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		return dayOfWeek == 1;
	}
	
	//data inizio valida s.s.e. segue quella odierna di un numero di giorni pari al preavviso stabilito, e se cade di DOMENICA
	//0: data inizio valida
	//1: data inizio che non rispetta il preavviso
	//2: data inizio che non cade di domenica
	//3: condizioni 1 e 2 entrambe verificate
	private int dataInizioInterpelloValidaDettaglio() {
		
		boolean rispettaPreavviso = getDataInizioInterpello() != null &&
						 	 		DateUtil.calcolaDifferenzaDate(DateUtil.dataOdierna(), getDataInizioInterpello()) >= numeroGiorniPreavvisoInterpello;
		
		boolean isDomenica = getDataInizioInterpello() != null &&
							 isDomenica(getDataInizioInterpello());
		
		if(rispettaPreavviso && isDomenica) {
			return 0;
		}
		
		if(!rispettaPreavviso && isDomenica) {
			return 1;
		}
		
		if(rispettaPreavviso && !isDomenica) {
			return 2;
		}
		
		return 3;
	}
	
	private boolean dataFineInterpelloValida() {

		return getDataInizioInterpello() != null &&
			   getDataFineInterpello() != null &&
			   DateUtil.calcolaDifferenzaDate(getDataInizioInterpello(), getDataFineInterpello()) == numeroGiorniValiditaInterpello;
	}
	
	private boolean validaDati() {
		
		boolean datiInseriti = dataInizioInterpello != null &&
							   dataFineInterpello != null;
		if(!datiInseriti) {
			JSFUtility.addWarningMessage("Attenzione", "E' necessario inserire entrambe le date per l'interpello");
		}
		
		int statoDataInizioInterpello = dataInizioInterpelloValidaDettaglio();
		if(datiInseriti && statoDataInizioInterpello > 0) {
			
			if(statoDataInizioInterpello == 1 || statoDataInizioInterpello == 3) {
				
				JSFUtility.addWarningMessage("Attenzione", "Tra la data di inizio interpello e quella odierna devono intercorrere almeno " + numeroGiorniPreavvisoInterpello + " giorni");
			}
			if(statoDataInizioInterpello == 2 || statoDataInizioInterpello == 3) {
				
				JSFUtility.addWarningMessage("Attenzione", "La data di inizio interpello deve cadere di Domenica");
			}
		}
		
		boolean dataFineInterpelloValida = dataFineInterpelloValida();
		if(datiInseriti && !dataFineInterpelloValida) {
			
			JSFUtility.addWarningMessage("Attenzione", "Tra la data di inizio e la data di fine interpello devono intercorrere " + numeroGiorniValiditaInterpello + " giorni");
		}
		
		return datiInseriti && (statoDataInizioInterpello == 0) && dataFineInterpelloValida;
	}
	
	//LISTENERS
	
	public void dataInizioInterpelloCambiata(AjaxBehaviorEvent event) {
		
		setDataFineInterpello(DateUtil.getDataEstremoIntervallo(getDataInizioInterpello(), numeroGiorniValiditaInterpello, orarioTermineValiditaInterpello));
	}
	
	public void predisponiInterpello() {
		
		try {
			
			if(isInterpelloChiuso()) {
				
				//crea un nuovo interpello 
				predisponiInterpelloAction.predisponiNuovoInterpello(getCodiceRegione());
				
				//determina progressivo dell'interpello predisposto
				setNumeroInterpello(predisponiInterpelloAction.getProgressivoInterpelloCorrente());
				
				//determina elenco candidati per l'interpello predisposto
				setCandidatiInterpello(
						predisponiInterpelloAction.trovaCandidatiInterpelloCorrente()
				);
				
				JSFUtility.addInfoMessage("", "Interpello predisposto con successo");
			}
		}
		catch(Exception e) {
			
			log.error("PredisponiInterpelloBean - predisposizione interpello fallita", e);
			
			if(e instanceof SediException)
				JSFUtility.addWarningMessage("Attenzione", "Al momento non risulta registrata alcuna sede farmaceutica. Occorre caricare le sedi prima di avviare la predisposizione dell'interpello");
			else
				JSFUtility.redirect(pageError);
		}
	}
	
	public void annullaPredisposizioneInterpello() {
		
		try {
			
			if(isInterpelloPredisposto()) {
				
				//annulla predisposizione dati interpello su DB
				predisponiInterpelloAction.annullaInterpelloPredisposto(getCodiceRegione());
				
				//reset date interpello
				setDataInizioInterpello(null);
				setDataFineInterpello(null);
				
				//elimina elenco candidati precedentemente indicati come idonei per l'interpello
				setCandidatiInterpello(null);
				
				JSFUtility.addInfoMessage("", "Interpello annullato");
			}
		}
		catch(Exception e) {
			
			log.error("PredisponiInterpelloBean - annullamento predisposizione interpello fallito", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void salvaInterpello() {
		
		try {
			
			if(isInterpelloPredisposto() && validaDati()) {
				
				//imposta l'orario per la data inizio interpello
				setDataInizioInterpello(
						DateUtil.setOrarioData(getDataInizioInterpello(), orarioInizioValiditaInterpello)
				);
				
				//imposta l'orario per la data fine interpello
				setDataFineInterpello(
						DateUtil.setOrarioData(getDataFineInterpello(), orarioTermineValiditaInterpello)
				);
			
				predisponiInterpelloAction.salvaInterpelloCorrente(dataInizioInterpello, dataFineInterpello);
				
				JSFUtility.addInfoMessage("", "Interpello salvato con successo");
			}		}
		catch(Exception e) {
			
			log.error("PredisponiInterpelloBean - salvataggio dati interpello fallito", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void pubblicaInterpello() {
		
		try {
			
			if(isInterpelloPredisposto() && validaDati()) {
				
				//imposta l'orario per la data inizio interpello
				setDataInizioInterpello(
						DateUtil.setOrarioData(getDataInizioInterpello(), orarioInizioValiditaInterpello)
				);
				
				//imposta l'orario per la data fine interpello
				setDataFineInterpello(
						DateUtil.setOrarioData(getDataFineInterpello(), orarioTermineValiditaInterpello)
				);
				
				//pubblicazione interpello
				predisponiInterpelloAction.pubblicaInterpelloCorrente(dataInizioInterpello, dataFineInterpello);
				
				JSFUtility.addInfoMessage("", "Interpello avviato con successo");
			}
		}
		catch(Exception e) {
			
			log.error("PredisponiInterpelloBean - pubblicazione interpello fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	//FINE LISTENERS
	
	public String getCodiceRegione() {
		return codiceRegione;
	}

	public void setCodiceRegione(String codiceRegione) {
		this.codiceRegione = codiceRegione;
	}

	public List<CandidatoInterpello> getCandidatiInterpello() {
		return candidatiInterpello;
	}

	public void setCandidatiInterpello(List<CandidatoInterpello> candidatiInterpello) {
		
		if(candidatiInterpello == null)
			setNumeroCandidati(0);
		else
			setNumeroCandidati(candidatiInterpello.size());
		
		this.candidatiInterpello = candidatiInterpello;
	}
	
	public int getNumeroInterpello() {
		return numeroInterpello;
	}

	public void setNumeroInterpello(int numeroInterpello) {
		this.numeroInterpello = numeroInterpello;
	}

	public int getNumeroCandidati() {
		return numeroCandidati;
	}

	public void setNumeroCandidati(int numeroCandidati) {
		this.numeroCandidati = numeroCandidati;
	}

	public Date getMinDataInizioInterpello() {
		return minDataInizioInterpello;
	}

	public void setMinDataInizioInterpello(Date minDataInizioInterpello) {
		this.minDataInizioInterpello = minDataInizioInterpello;
	}

	public Date getDataInizioInterpello() {
		return dataInizioInterpello;
	}

	public void setDataInizioInterpello(Date dataInizioInterpello) {
		
		if(dataInizioInterpello == null)
			setDataInizioInterpelloString(null);
		else
			setDataInizioInterpelloString(StringUtil.dateToStringDDMMYYYY(dataInizioInterpello));
		
		this.dataInizioInterpello = dataInizioInterpello;
	}

	public String getDataInizioInterpelloString() {
		return dataInizioInterpelloString;
	}

	public void setDataInizioInterpelloString(String dataInizioInterpelloString) {
		this.dataInizioInterpelloString = dataInizioInterpelloString;
	}

	public Date getMinDataFineInterpello() {
		return minDataFineInterpello;
	}

	public void setMinDataFineInterpello(Date minDataFineInterpello) {
		this.minDataFineInterpello = minDataFineInterpello;
	}

	public Date getDataFineInterpello() {
		return dataFineInterpello;
	}

	public void setDataFineInterpello(Date dataFineInterpello) {
		
		if(dataFineInterpello == null)
			setDataFineInterpelloString(null);
		else
			setDataFineInterpelloString(StringUtil.dateToStringDDMMYYYY(dataFineInterpello));
		
		this.dataFineInterpello = dataFineInterpello;
	}

	public String getDataFineInterpelloString() {
		return dataFineInterpelloString;
	}

	public void setDataFineInterpelloString(String dataFineInterpelloString) {
		this.dataFineInterpelloString = dataFineInterpelloString;
	}
	
}
