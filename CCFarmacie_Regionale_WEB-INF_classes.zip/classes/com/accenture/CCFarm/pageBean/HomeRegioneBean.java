package com.accenture.CCFarm.pageBean;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.DAO.UtenteCandidaturaHome;
import com.accenture.CCFarm.DAO.UtenteCandidaturaRegHome;
import com.accenture.CCFarm.action.HomeRegioneAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.ControlloBandoScaduto;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;

@ManagedBean
@ViewScoped
public class HomeRegioneBean {

	HomeRegioneAction regAction = null;
	Logger logger = CommonLogger.getLogger("HomeRegioneBean");
	private String regione;
	private String username;
	private String codRegione;
	//private StreamedContent fileDownloadManualeUtente;
	private String disabledAreaDocumentale = "true";
	private Long ndomandeInviate = new Long(0);
	
	String pageError = "errorPage.jsf";
//bando REgionale
	private String pulsanteBandoReg= "none";
	private String imgBandoReg = "none";
	private String visBandoReg = "true";
//Gestione Sedi
	private String pulsanteGestSedi= "none";
	private String imgGestSedi = "none";
	private String visGestSedi = "true";

//Valida Concorso
	private String pulsanteValidaConcorso= "none";
	private String imgValidaConcorso = "none";
	private String visValidaConcorso = "true";

//Simula Calcolo
	private String pulsanteSimulaCalcolo= "none";
	private String imgSimulaCalcolo = "none";
	private String visSimulaCalcolo = "true";

//Area Documentale
	private String pulsanteAreaDocumentale = "none";
	private String imgAreaDocumentale = "none";
	private String visAreaDocumentale = "true";

//Commissione
//	private String pulsanteCommissione = "none";
//	private String imgCommissione = "none";
//	private String visCommissione = "true";
	
//Stampa Elenco candidature
	private String pulsanteStpEleCand = "none";
	private String imgStpEleCand = "none";
	private String visStpEleCand = "true";

// Consulta Graduatoria
	private String pulsanteConGrad = "none";
	private String imgConGrad = "none";
	private String visConGrad = "true";

	//Stampa Elenco candidature
	private String pulsantePubbGrad = "none";
	private String imgPubbGrad = "none";
	private String visPubbGrad = "true";

//Gestione Utenze
	private String pulsanteGestioneUtenze = "none";
	private String imgGestioneUtenze = "none";
	private String visGestioneUtenze = "true";
	
//Elenco candidature
	private String pulsanteEleCand = "none";
	private String imgEleCand = "none";
	private String visEleCand = "true";

//Definisci Criteri
	private String pulsanteDefCriteri = "none";
	private String imgDefCriteri = "none";
	private String visDefCriteri = "true";

//Elabora graduatoria
	private String pulsanteGraduatoria = "none";
	private String imgGraduatoria = "none";
	private String visGraduatoria = "true";

//Predisponi Interpello - Fase 3
	private String pulsantePredInterpello = "none";
	private String imgPredInterpello = "none";
	private String visPredInterpello = "true";
	
//Gestione esclusione candidatura interpellata
	private String pulsanteEscludiInterpellato = "none";
	private String imgEscludiInterpellato = "../images/layout/btn_escludiInterpellato.png";
	private String visEscludiInterpellato = "false";
	
	
//Gestione Assegnazioni
	private String pulsanteGestAssegnazioni = "none";
	private String imgGestAssegnazioni = "none";
	private String visGestAssegnazioni = "true";
	
	//Esclusioni
	private String pulsanteEsclusioni = "none";
	private String imgEsclusioni = "none";
	private String visEsclusioni = "true";
	
	private String labelBread="";
	
	private String utenteAccesso="";
	private String testoAreaReg = "none";
	private String testoAreaCom = "none";
	private String testoAreaDom = "none";
	private String testoAreaCCScaduto= "none";
	
	
	private FacesContext context =null;
	private HttpSession session= null; 
	private HttpServletRequest request=null; 
	
	private String pageStampaCandidati    = "stampaElencoCandidati.jsf";
	private String pageRicercaCandidature = "ricercaCandidatureDom.jsf";
	private String pagePubblicaGraduatoria= "pubblicaGraduatoria.jsf";
	private String pageConsultaGraduatoria= "consultaGraduatoria.jsf";
	
	private boolean isAbilitataAreaBO = false;
	
	/*public StreamedContent getFileDownloadManualeUtente() {
		return fileDownloadManualeUtente;
	}

	public void setFileDownloadManualeUtente(
			StreamedContent fileDownloadManualeUtente) {
		this.fileDownloadManualeUtente = fileDownloadManualeUtente;
	}*/

	public HomeRegioneBean(){
		try {
			this.init();
//			InputStream stream = ((ServletContext)FacesContext.getCurrentInstance().getExternalContext().getContext()).getResourceAsStream("/ManualeUtenteRegionale.pdf");  
//			fileDownloadManualeUtente = new DefaultStreamedContent(stream, "application/pdf", "ManualeUtenteRegionale.pdf");  
		} catch (Exception e) {
			logger.error("HomeRegioneBean - init: " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
		}
	
	/*public void caricaFileDownload()
	{
		try{
			InputStream stream = ((ServletContext)FacesContext.getCurrentInstance().getExternalContext().getContext()).getResourceAsStream("/ManualeUtenteRegionale.pdf");  
			fileDownloadManualeUtente = new DefaultStreamedContent(stream, "application/pdf", "ManualeUtenteRegionale.pdf");  
		} catch (Exception e) {
			logger.error("HomeRegioneBean - caricaFileDownload: " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
	}*/
	
	public void init()
	{  
		try
		{

			regAction = new HomeRegioneAction(); //init Al suo interno
			regAction.loadPaginaInserimento(this);
			context = FacesContext.getCurrentInstance();
			request = (HttpServletRequest) context.getExternalContext().getRequest();
			request.getSession().removeAttribute("elaboraGraduatoria");
	    	session = request.getSession();
	    	
	    	//recupera i dati dell'utente connesso dalla sessione
	    	UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	    	if(utenteReg==null)
	    	{
	    		throw new GestioneErroriException("HomeRegioneBean - users: utente non in sessione");
	    	}
	    	
	    	//determina se c'� un interpello in corso per la regione corrente
	    	boolean interpelloInCorso = regAction.controllaPresenzaInterpelloInCorso(utenteReg.getCodRegione());
	    	
	    	boolean bExistInterpello = regAction.existInterpello(utenteReg.getCodRegione());
	    	
	    	boolean bAssegnazioneSedi = regAction.controllaPresenzaInterpelloScaduto(utenteReg.getCodRegione());
	    	
	    	//determina se il bando presente in sessione � scaduto o meno
	    	// bandoScaduto=true  - bando scaduto
	    	// bandoScaduto=false - bando in essere
	    	boolean bandoScaduto=!((new ControlloBandoScaduto()).controllaScadenza(utenteReg.getCodRegione()));
	    	
	    	if (utenteReg.getCodRegione().equalsIgnoreCase("MDS")){
	    		labelBread="Ministero della Salute ";
	    		visEscludiInterpellato = "false";
    			pulsanteEscludiInterpellato = "none";
	    	} 
	
//Area Regionale	    	
	    	if (utenteReg.isRegione())
	    	{
	    		utenteAccesso= "Utente Regione";
	    		testoAreaReg="block";
	    		//testoAreaCom="none";

//pulsanti abilitati ed visualizzati per la regione	
	    		
	    		//Escludi interpellato (attivo solo se � stato fatto alemno un interpello)
	    		if(!(utenteReg.getCodRegione().equalsIgnoreCase("MDS")) && (bExistInterpello)){
	    			visEscludiInterpellato = "true";
	    			pulsanteEscludiInterpellato = "block";
	    		}else{
	    			visEscludiInterpellato = "false";
	    			pulsanteEscludiInterpellato = "none";
	    		}
	    		
	    		//bando Regionale	
	        	pulsanteBandoReg = "block";
	        	imgBandoReg = "../images/layout/btn_bando_regionale.png";
	        	visBandoReg = "false";
	    		
	        	if(!interpelloInCorso) {
	        		//pulsante Gestioni Sedi visibile solo in assenza di interpelli in corso
		        	pulsanteGestSedi = "block";
		        	imgGestSedi = "../images/layout/btn_gestione_sedi.png";
		        	visGestSedi = "false";
	        	}
	        	else {
	        		//pulsante Gestioni Sedi nascosto in presenza di interpelli in corso
	        		pulsanteGestSedi = "none";
		        	imgGestSedi = "../images/layout/btn_gestione_sedi.png";
		        	visGestSedi = "true";
	        	}
	        	
	        	//Valida concorso
	        	pulsanteValidaConcorso = "block";
	        	imgValidaConcorso = "../images/layout/btn-validazioneConcorso.png";
	        	visValidaConcorso = "false";
	    		
	        	//Simula Calcolo
	        	pulsanteSimulaCalcolo = "block";
	        	imgSimulaCalcolo = "../images/layout/btn_simulazionecalcolo.png";
	        	visSimulaCalcolo = "false";    		
	        	
	        	//Gestione Utenze
	        	pulsanteGestioneUtenze = "block";
	        	imgGestioneUtenze = "../images/layout/btn-gestione-utenze.png";
	        	visGestioneUtenze = "false";
	        	
	        	//se il bando � scaduto
	        	if(bandoScaduto)
	        	{
		        	//Stampa Elenco candidature    	
		        	pulsanteStpEleCand= "block";
		        	imgStpEleCand = "../images/layout/btn_Stampa_Candidati.png";
		        	visStpEleCand = "false";
		        	//Elenco candidature    	
		        	pulsanteEleCand = "block";
		        	imgEleCand = "../images/layout/btn_Ricerca_Candidati.png";
		        	visEleCand = "false";
		        	testoAreaCCScaduto= "block";
		        	
//		    per il momento si blocca la visualizzazione    	//Pubblica Graduatoria  bloccato 
//		        	pulsantePubbGrad= "none";
//		        	imgPubbGrad = "../images/layout/btn_Pubblica_Graduatoria.png";
//		        	visPubbGrad = "true";
//per sbloccare il pulsante		        	//Pubblica Graduatoria   attivo
		        	
		        	List<TipoGraduatoria> listTipoGrad = regAction.getGraduatoria(utenteReg.getCodRegione());
		        	
			        if (listTipoGrad!=null && listTipoGrad.size() > 0) {
			        	
			        	//Dal primo interpello pubblica Graduatoria non e' piu' consentita
			        	//if(!bExistInterpello) {
			        		//pulsante pubblica graduatoria visibile
			        		pulsantePubbGrad= "block";
				        	imgPubbGrad = "../images/layout/btn_pubblicaGraduatoria.png";
				        	visPubbGrad = "false";
			        	//}
			        	//else {
			        		//pulsante pubblica graduatoria nascosto
			        		//pulsantePubbGrad= "none";
				        	//imgPubbGrad = "../images/layout/btn_pubblicaGraduatoria.png";
				        	//visPubbGrad = "true";
			        	//}
			        	
			        	//pulsante consulta graduatoria visibile in presenza di graduatorie
			        	pulsanteConGrad = "block";
			        	imgConGrad = "../images/layout/btn_consulta_graduatoria.png";
			        	visConGrad = "false";
			        	
			        	if(regAction.controllaPubblicazioneGraduatoria(listTipoGrad)) {
			        	
			        		//Predisponi Interpello visibile solo se presente almeno una graduatoria pubblicata in una data non successiva a quella corrente
					    	pulsantePredInterpello = "block";
					    	imgPredInterpello = "../images/layout/btn_Predisponi_Interpello.png";
				        	visGraduatoria = "false";
				        	
				        	if(!interpelloInCorso) {
					        	//Esclusioni
					        	pulsanteEsclusioni = "block";
						    	imgEsclusioni = "../images/layout/btn_escludi.png"; 
						    	visEsclusioni = "false";
				        	}
				        	else {
					        	//Esclusioni
					        	pulsanteEsclusioni = "none";
						    	imgEsclusioni = "../images/layout/btn_escludi.png";
						    	visEsclusioni = "true";
				        	}
			        	}
			        	else {
				        	//Predisponi Interpello nascosto in assenza di graduatorie pubblicate
				        	pulsantePredInterpello = "none";
					    	imgPredInterpello = "../images/layout/btn_Predisponi_Interpello.png";
				        	visGraduatoria = "true";
				        	
				        	//Esclusioni
				        	pulsanteEsclusioni = "none";
					    	imgEsclusioni = "../images/layout/btn_escludi.png";
					    	visEsclusioni = "true";
			        	}
			        }
			        else {
			        	
			        	//pulsante Consulta Graduatoria nascosto in assenza di graduatorie
			        	pulsanteConGrad= "none";
			        	imgConGrad = "../images/layout/btn_consulta_graduatoria.png";
			        	visConGrad = "true";
			        }
	        	}
	        	
	        	//PULSANTE GESTIONE ASSEGNAZIONE SEDI
	        	if(bAssegnazioneSedi) {
		        	pulsanteGestAssegnazioni = "block";
		        	imgGestAssegnazioni = "../images/layout/btn-pred-abb-sedi.png";
		        	visGestAssegnazioni = "false";
	        	}
		    	
	    	}
	    	//se non si tratta di un'utenza regionale
	    	else
	    	{
	//pulsanti disabilitati non visualizzati
	    		//bando REgionale	
	        	pulsanteBandoReg = "none";
	        	imgBandoReg = "../images/layout/btn_bando_regionale.png";
	        	visBandoReg = "true";
	    		
	    		//Gestioni Sedi	
	        	pulsanteGestSedi = "none";
	        	imgGestSedi = "../images/layout/btn_gestione_sedi.png";
	        	visGestSedi = "true";
	    		
	        	//Valida concorso
	        	pulsanteValidaConcorso = "none";
	        	imgValidaConcorso = "../images/layout/btn-validazioneConcorso.png";
	        	visValidaConcorso = "true";
	    		
	        	//Simula Calcolo
	        	pulsanteSimulaCalcolo = "none";
	        	imgSimulaCalcolo = "../images/layout/btn_simulazionecalcolo.png";
	        	visSimulaCalcolo = "true";
	        	
	        	//Area Documentale
	        	pulsanteAreaDocumentale = "none";
	        	imgAreaDocumentale = "../images/layout/btn_area_documentale.png";
	        	visAreaDocumentale = "true";
//	        	visAreaDocumentale =disabledAreaDocumentale;
	    		
	           	//Stampa Elenco candidature    	
	        	pulsanteStpEleCand= "none";
	        	imgStpEleCand = "../images/layout/btn_Stampa_Candidati.png";
	        	visStpEleCand = "true";
	        	
	        	//Elenco candidature    	
	        	pulsanteEleCand = "none";
	        	imgEleCand = "../images/layout/btn_ElencoCandidature.png";
	        	visEleCand = "true";
	        	
	        	//Pubblica Graduatoria  
	        	pulsantePubbGrad= "none";
	        	imgPubbGrad = "../images/layout/btn_Pubblica_Graduatoria.png";
	        	visPubbGrad = "true";
	        	
	        	//Consulta Graduatoria
	        	pulsanteConGrad= "none";
	        	imgConGrad = "../images/layout/btn_consulta_graduatoria.png";
	        	visConGrad = "true";
	        	
	        	//Predisponi Interpello disattivato
	        	pulsantePredInterpello = "none";
		    	imgPredInterpello = "../images/layout/btn_Predisponi_Interpello.png";
	        	visGraduatoria = "true";
	        	
	        	//Gestione Assegnazioni disattivato
	        	pulsanteGestAssegnazioni = "none";
		    	imgGestAssegnazioni = "../images/layout/btn-pred-abb-sedi.png";
		    	visGestAssegnazioni = "true";
		    	
		    	//Esclusioni disattivato
		    	pulsanteEsclusioni = "none";
		    	imgEsclusioni = "../images/layout/btn_escludi.png";
		    	visEsclusioni = "true";
	        	
	    	}
	    	
//sezione Area documentale
	    	if(utenteReg.isAbilitataAreaDocumentale())
	    	{
	    		//Area Documentale abilitata e visualizzata
	    		testoAreaDom= "block";
	            pulsanteAreaDocumentale = "block";
	        	imgAreaDocumentale = "../images/layout/btn_area_documentale.png";
	        	visAreaDocumentale = "false";
//	        	visAreaDocumentale =disabledAreaDocumentale;
	    	}
	    	else
	    	{
	    		//Area Documentale disabilitata e non visualizzata
	    		testoAreaDom= "none";
		        visAreaDocumentale = "true";
	    		pulsanteAreaDocumentale = "none";
	        	imgAreaDocumentale = "../images/layout/btn_area_documentale.png";
	        	visAreaDocumentale = "true";
//	        	visAreaDocumentale =disabledAreaDocumentale;
	    	}
	    	
//Area commissione
	    	if (utenteReg.isCommissione())
	    	{
	    	//   pulsante abilitato 		
//	    		testoAreaReg="none";
	    		utenteAccesso= "Utente Commissione";
//	    	    commissione
//	    		pulsanteCommissione = "block";
//	        	imgCommissione = "../images/layout/btn_Area_Commissione.png";
//	        	visCommissione = "false";	
	    		
	    		//sezione Definisci criteri
	    		imgDefCriteri = "../images/layout/btn_definisci_criteri.png";
	    		//se il bando � scaduto
	    		if(bandoScaduto)
	    		{
	    			//sezione Definisci criteri attiva	
		    		pulsanteDefCriteri= "block";
		        	visDefCriteri = "false";
		        	testoAreaCom="block";
		        		        	
	    		}
	    		else //se il bando � ancora in essere
	    		{
	    			//sezione Definisci criteri disattiva	
		    		pulsanteDefCriteri= "none";
		        	visDefCriteri = "true";
		        	testoAreaCom="none";
	    		}
	    		
	    		
//tologo la visualizzazione 	       //   Elabora graduatoria	
//	    		pulsanteGraduatoria= "block";
         //	imgGraduatoria = "../images/layout/btn_Elabora_graduatoria.png";
//	        	visGraduatoria = "false";
//blocco la vis per un installazione parziale	       //   Elabora graduatoria	
	    	//	pulsanteGraduatoria= "none";
	        //	imgGraduatoria = "../images/layout/btn_Elabora_graduatoria.png";
	       // 	visGraduatoria = "true";
	    	}
	    	else
	    	{
	    	//   pulsante abilitato 		
//	    		pulsanteCommissione = "none";
//	        	imgCommissione = "../images/layout/btn_Area_Commissione.png";
//	        	visCommissione = "true";
	    		
	    		//sezione Definisci criteri disattiva
	    		pulsanteDefCriteri= "none";
	        	imgDefCriteri = "../images/layout/btn_definisci_criteri.png";
	        	visDefCriteri = "true";	
	        	
	        	//   Elabora graduatoria	
//	    		pulsanteGraduatoria= "none";
//	        	imgGraduatoria = "../images/layout/btn_Elabora_graduatoria.png";
//	        	visGraduatoria = "true";
	    	}
	    	
	    	//Elabora graduatoria sia per profilo regionale che commissione
	    	//Dal primo interpello l'elabora Graduatoria non e' piu' consentita
	    	imgGraduatoria = "../images/layout/btn_Elabora_graduatoria.png";
	    	//if(bandoScaduto && !bExistInterpello)
	    	if(bandoScaduto && !utenteReg.getCodRegione().equalsIgnoreCase("MDS"))
    		{
	    		//pulsante elabora graduatoria visibile in assenza di interpelli pubblicati
    	    	pulsanteGraduatoria= "block";
    	    	imgGraduatoria = "../images/layout/btn_Elabora_graduatoria.png";
	        	visGraduatoria = "false";
	        	testoAreaCCScaduto= "block";
    		}
    		else //se il bando � ancora in essere
    		{
    			//pulsante elabora graduatoria nascosto in presenza di interpelli pubblicati
    	    	pulsanteGraduatoria= "none";
    	    	imgGraduatoria = "../images/layout/btn_Elabora_graduatoria.png";
	        	visGraduatoria = "true";
	        	testoAreaCCScaduto= "none";
    		}
	    	
	    	//Gestione Utenze attivo per MDS
	    	if(bandoScaduto && utenteReg.getCodRegione().equalsIgnoreCase("MDS"))
    		{
	        	pulsanteGestioneUtenze = "block";
	        	imgGestioneUtenze = "../images/layout/btn-gestione-utenze.png";
	        	visGestioneUtenze = "false";
	        	
	        }
	    	
	    	//Area BO
	    	setAbilitataAreaBO(utenteReg.isAbilitataAreaBO());
	    	
			aggiornaDomInviate();
			
		}
		catch (GestioneErroriException e)
		{
			logger.error("HomeRegioneBean - init failed: " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
	}


	public String bandoRegionale(){
		
		System.out.println("bandoRegionale.jsf");
//		JSFUtility.redirect("bandoRegionale.jsf");
		return "bandoRegionale.jsf";
	}

	public String gestioniSedi(){
		System.out.println("gestioneSediTab.jsf");
		//JSFUtility.redirect("gestioneSediTab.jsf");
		return "gestioneSediTab.jsf";
	}


	
	public String validaConcorso(){
		System.out.println("validaConcorso.jsf");
		//JSFUtility.redirect("validaConcorso.jsf");
		return "validaConcorso.jsf";
	}
	
	public String simulaCalcolo(){
		System.out.println("simulazioneCalcolo.jsf");
		//JSFUtility.redirect("simulazioneCalcolo.jsf");
		return "simulazioneCalcolo.jsf";
	}

	public void pubblicaGraduatoria(){
		System.out.println("pubblicaGraduatoria.jsf");
//		JSFUtility.redirect(".jsf");
	}

//	public void getAreaDocumentale() {
//		try{
//			regAction.getAreaDocumentale(this);
//		} catch (GestioneErroriException e) {
//			logger.error("HomeRegioneBean - getAreaDocumentale: " + e.getMessage());
//			JSFUtility.redirect(pageError);
//		}
//	}
//	public void commissione(){
//		System.out.println("homeCommissione.jsf");
//		JSFUtility.redirect("homeCommissione.jsf");
//	}
//	
	
	public String stampaElencoCandidati(){
//		session.setAttribute(RepositorySession.CHIAMO_STAMPA_DA_FUORI, "SI");
		StampaCandidatiBean stampaCandidatiBean= (StampaCandidatiBean) GetSessionUtility.getSessionAttribute("stampaCandidatiBean");
		if (stampaCandidatiBean!=null){
			stampaCandidatiBean.init();
		}
	//	JSFUtility.redirect("stampaElencoCandidati.jsf");
		return "stampaElencoCandidati.jsf";
	}
	
	public String elencoCandidati(){
//		JSFUtility.redirect("ricercaCandidati.jsf");
		RicercaCandidati ricercaCandidati = (RicercaCandidati) GetSessionUtility.getSessionAttribute("ricercaCandidati");
		if (ricercaCandidati!=null){
			ricercaCandidati.initInizializzazione();
		}
		//JSFUtility.redirect("ricercaCandidatureDom.jsf");
		return "ricercaCandidatureDom.jsf";
	}
	
	public String definisciCriteri(){
		System.out.println("Definici Criteri ");
		//JSFUtility.redirect("definisciCriteri.jsf");
		return "definisciCriteri";
	}
	
	public String elaboraGraduatoria(){
		System.out.println("elaboraGraduatoria");
		//JSFUtility.redirect("elaboraGraduatoria.jsf");
		return "elaboraGraduatoria";
	}
	
	
	
	public String getRegione() {
		return regione;
	}

	public void setRegione(String regione) {
		this.regione = regione;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	public HomeRegioneAction getRegAction() {
		return regAction;
	}

	public void setRegAction(HomeRegioneAction regAction) {
		this.regAction = regAction;
	}

	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}

	public String getDisabledAreaDocumentale() {
		return disabledAreaDocumentale;
	}

	public void setDisabledAreaDocumentale(String disabledAreaDocumentale) {
		this.disabledAreaDocumentale = disabledAreaDocumentale;
	}

	public Long getNdomandeInviate() {
		return ndomandeInviate;
	}

	public void setNdomandeInviate(Long ndomandeInviate) {
		this.ndomandeInviate = ndomandeInviate;
	}

	@SuppressWarnings("rawtypes")
	public String aggiornaDomInviate()
	{	
		try{
			String sCodiceRegione = getCodRegione();
	    	UtenteCandidaturaRegHome utenteCandidaturaRegHome = new UtenteCandidaturaRegHome();
	    	UtenteCandidaturaHome    utenteCandidaturaHome    = new UtenteCandidaturaHome();
	    	
	    	ControlloBandoScaduto bandoScaduto = new ControlloBandoScaduto();
	    	String query = null;
	    	ArrayList lista = new ArrayList();
	    	if(bandoScaduto.controllaScadenza(sCodiceRegione)){
	    		query = "select count(*) from UtenteCandidatura u where u.codRegUtente = '"+sCodiceRegione+"' and u.idUtente = u.candidatura.idUtente and u.candidatura.statoDomanda ='I'";
	    		lista = (ArrayList)utenteCandidaturaHome.findCountByQuery(query);
		    }else {
	    		query = "select count(*) from UtenteCandidaturaReg u where u.codRegUtente = '"+sCodiceRegione+"' and u.idUtente = u.candidatura.idUtente and u.candidatura.statoDomanda ='I'";
	    		lista = (ArrayList)utenteCandidaturaRegHome.findCountByQuery(query);
		    }
	    	Long nDomande = (Long)lista.get(0);
	    	setNdomandeInviate(nDomande);
			
		} catch (Exception e) {
			logger.error("HomeRegioneBean - getDomandeInviate: " + e.getMessage());
		//	JSFUtility.redirect(pageError);
			return pageError;
		}
		return null;
	}
	
	public void logout()
	{	
		((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).invalidate();
	}
	
	

	public String getPulsanteBandoReg() {
		return pulsanteBandoReg;
	}

	public void setPulsanteBandoReg(String pulsanteBandoReg) {
		this.pulsanteBandoReg = pulsanteBandoReg;
	}

	public String getImgBandoReg() {
		return imgBandoReg;
	}

	public void setImgBandoReg(String imgBandoReg) {
		this.imgBandoReg = imgBandoReg;
	}

	public String getVisBandoReg() {
		return visBandoReg;
	}

	public void setVisBandoReg(String visBandoReg) {
		this.visBandoReg = visBandoReg;
	}

	public String getPulsanteGestSedi() {
		return pulsanteGestSedi;
	}

	public void setPulsanteGestSedi(String pulsanteGestSedi) {
		this.pulsanteGestSedi = pulsanteGestSedi;
	}

	public String getImgGestSedi() {
		return imgGestSedi;
	}

	public void setImgGestSedi(String imgGestSedi) {
		this.imgGestSedi = imgGestSedi;
	}

	public String getVisGestSedi() {
		return visGestSedi;
	}

	public void setVisGestSedi(String visGestSedi) {
		this.visGestSedi = visGestSedi;
	}

	public String getPulsanteValidaConcorso() {
		return pulsanteValidaConcorso;
	}

	public void setPulsanteValidaConcorso(String pulsanteValidaConcorso) {
		this.pulsanteValidaConcorso = pulsanteValidaConcorso;
	}

	public String getImgValidaConcorso() {
		return imgValidaConcorso;
	}

	public void setImgValidaConcorso(String imgValidaConcorso) {
		this.imgValidaConcorso = imgValidaConcorso;
	}

	public String getVisValidaConcorso() {
		return visValidaConcorso;
	}

	public void setVisValidaConcorso(String visValidaConcorso) {
		this.visValidaConcorso = visValidaConcorso;
	}

	public String getPulsanteSimulaCalcolo() {
		return pulsanteSimulaCalcolo;
	}

	public void setPulsanteSimulaCalcolo(String pulsanteSimulaCalcolo) {
		this.pulsanteSimulaCalcolo = pulsanteSimulaCalcolo;
	}

	public String getImgSimulaCalcolo() {
		return imgSimulaCalcolo;
	}

	public void setImgSimulaCalcolo(String imgSimulaCalcolo) {
		this.imgSimulaCalcolo = imgSimulaCalcolo;
	}

	public String getVisSimulaCalcolo() {
		return visSimulaCalcolo;
	}

	public void setVisSimulaCalcolo(String visSimulaCalcolo) {
		this.visSimulaCalcolo = visSimulaCalcolo;
	}

	public String getPulsanteAreaDocumentale() {
		return pulsanteAreaDocumentale;
	}

	public void setPulsanteAreaDocumentale(String pulsanteAreaDocumentale) {
		this.pulsanteAreaDocumentale = pulsanteAreaDocumentale;
	}

	public String getImgAreaDocumentale() {
		return imgAreaDocumentale;
	}

	public void setImgAreaDocumentale(String imgAreaDocumentale) {
		this.imgAreaDocumentale = imgAreaDocumentale;
	}

	public String getVisAreaDocumentale() {
		return visAreaDocumentale;
	}

	public void setVisAreaDocumentale(String visAreaDocumentale) {
		this.visAreaDocumentale = visAreaDocumentale;
	}

//	public String getPulsanteCommissione() {
//		return pulsanteCommissione;
//	}
//
//	public void setPulsanteCommissione(String pulsanteCommissione) {
//		this.pulsanteCommissione = pulsanteCommissione;
//	}
//
//	public String getImgCommissione() {
//		return imgCommissione;
//	}
//
//	public void setImgCommissione(String imgCommissione) {
//		this.imgCommissione = imgCommissione;
//	}
//
//	public String getVisCommissione() {
//		return visCommissione;
//	}
//
//	public void setVisCommissione(String visCommissione) {
//		this.visCommissione = visCommissione;
//	}

	public String getPulsanteStpEleCand() {
		return pulsanteStpEleCand;
	}

	public void setPulsanteStpEleCand(String pulsanteStpEleCand) {
		this.pulsanteStpEleCand = pulsanteStpEleCand;
	}

	public String getImgStpEleCand() {
		return imgStpEleCand;
	}

	public void setImgStpEleCand(String imgStpEleCand) {
		this.imgStpEleCand = imgStpEleCand;
	}

	public String getVisStpEleCand() {
		return visStpEleCand;
	}

	public void setVisStpEleCand(String visStpEleCand) {
		this.visStpEleCand = visStpEleCand;
	}

	public String getPulsanteEleCand() {
		return pulsanteEleCand;
	}

	public void setPulsanteEleCand(String pulsanteEleCand) {
		this.pulsanteEleCand = pulsanteEleCand;
	}

	public String getPulsanteEscludiInterpellato() {
		return pulsanteEscludiInterpellato;
	}

	public void setPulsanteEscludiInterpellato(String pulsanteEscludiInterpellato) {
		this.pulsanteEscludiInterpellato = pulsanteEscludiInterpellato;
	}

	public String getImgEscludiInterpellato() {
		return imgEscludiInterpellato;
	}

	public void setImgEscludiInterpellato(String imgEscludiInterpellato) {
		this.imgEscludiInterpellato = imgEscludiInterpellato;
	}

	public String getVisEscludiInterpellato() {
		return visEscludiInterpellato;
	}

	public void setVisEscludiInterpellato(String visEscludiInterpellato) {
		this.visEscludiInterpellato = visEscludiInterpellato;
	}

	public String getPulsanteGestioneUtenze() {
		return pulsanteGestioneUtenze;
	}

	public void setPulsanteGestioneUtenze(String pulsanteGestioneUtenze) {
		this.pulsanteGestioneUtenze = pulsanteGestioneUtenze;
	}
	
	public String getImgGestioneUtenze() {
		return imgGestioneUtenze;
	}

	public void setImgGestioneUtenze(String imgGestioneUtenze) {
		this.imgGestioneUtenze = imgGestioneUtenze;
	}

	public String getVisGestioneUtenze() {
		return visGestioneUtenze;
	}

	public void setVisGestioneUtenze(String visGestioneUtenze) {
		this.visGestioneUtenze = visGestioneUtenze;
	}

	public String getImgEleCand() {
		return imgEleCand;
	}

	public void setImgEleCand(String imgEleCand) {
		this.imgEleCand = imgEleCand;
	}

	public String getVisEleCand() {
		return visEleCand;
	}

	public void setVisEleCand(String visEleCand) {
		this.visEleCand = visEleCand;
	}

	public String getUtenteAccesso() {
		return utenteAccesso;
	}

	public void setUtenteAccesso(String utenteAccesso) {
		this.utenteAccesso = utenteAccesso;
	}

	public String getTestoAreaReg() {
		return testoAreaReg;
	}

	public void setTestoAreaReg(String testoAreaReg) {
		this.testoAreaReg = testoAreaReg;
	}

	public String getTestoAreaCom() {
		return testoAreaCom;
	}

	public void setTestoAreaCom(String testoAreaCom) {
		this.testoAreaCom = testoAreaCom;
	}

	public String getPulsanteDefCriteri() {
		return pulsanteDefCriteri;
	}

	public void setPulsanteDefCriteri(String pulsanteDefCriteri) {
		this.pulsanteDefCriteri = pulsanteDefCriteri;
	}

	public String getImgDefCriteri() {
		return imgDefCriteri;
	}

	public void setImgDefCriteri(String imgDefCriteri) {
		this.imgDefCriteri = imgDefCriteri;
	}

	public String getVisDefCriteri() {
		return visDefCriteri;
	}

	public void setVisDefCriteri(String visDefCriteri) {
		this.visDefCriteri = visDefCriteri;
	}

	public String getPulsanteGraduatoria() {
		return pulsanteGraduatoria;
	}

	public void setPulsanteGraduatoria(String pulsanteGraduatoria) {
		this.pulsanteGraduatoria = pulsanteGraduatoria;
	}

	public String getImgGraduatoria() {
		return imgGraduatoria;
	}

	public void setImgGraduatoria(String imgGraduatoria) {
		this.imgGraduatoria = imgGraduatoria;
	}

	public String getVisGraduatoria() {
		return visGraduatoria;
	}

	public void setVisGraduatoria(String visGraduatoria) {
		this.visGraduatoria = visGraduatoria;
	}

	public String getPulsantePredInterpello() {
		return pulsantePredInterpello;
	}

	public void setPulsantePredInterpello(String pulsantePredInterpello) {
		this.pulsantePredInterpello = pulsantePredInterpello;
	}

	public String getImgPredInterpello() {
		return imgPredInterpello;
	}

	public void setImgPredInterpello(String imgPredInterpello) {
		this.imgPredInterpello = imgPredInterpello;
	}

	public String getVisPredInterpello() {
		return visPredInterpello;
	}

	public void setVisPredInterpello(String visPredInterpello) {
		this.visPredInterpello = visPredInterpello;
	}

	public String getPulsantePubbGrad() {
		return pulsantePubbGrad;
	}

	public void setPulsantePubbGrad(String pulsantePubbGrad) {
		this.pulsantePubbGrad = pulsantePubbGrad;
	}

	public String getImgPubbGrad() {
		return imgPubbGrad;
	}

	public void setImgPubbGrad(String imgPubbGrad) {
		this.imgPubbGrad = imgPubbGrad;
	}

	public String getVisPubbGrad() {
		return visPubbGrad;
	}

	public void setVisPubbGrad(String visPubbGrad) {
		this.visPubbGrad = visPubbGrad;
	}

	public String getTestoAreaDom() {
		return testoAreaDom;
	}

	public void setTestoAreaDom(String testoAreaDom) {
		this.testoAreaDom = testoAreaDom;
	}

	public String getPageStampaCandidati() {
		return pageStampaCandidati;
	}

	public void setPageStampaCandidati(String pageStampaCandidati) {
		this.pageStampaCandidati = pageStampaCandidati;
	}

	public String getPageRicercaCandidature() {
		return pageRicercaCandidature;
	}

	public void setPageRicercaCandidature(String pageRicercaCandidature) {
		this.pageRicercaCandidature = pageRicercaCandidature;
	}

	public String getLabelBread() {
		return labelBread;
	}

	public void setLabelBread(String labelBread) {
		this.labelBread = labelBread;
	}

	public String getPagePubblicaGraduatoria() {
		return pagePubblicaGraduatoria;
	}

	public void setPagePubblicaGraduatoria(String pagePubblicaGraduatoria) {
		this.pagePubblicaGraduatoria = pagePubblicaGraduatoria;
	}

	public String getPulsanteConGrad() {
		return pulsanteConGrad;
	}

	public void setPulsanteConGrad(String pulsanteConGrad) {
		this.pulsanteConGrad = pulsanteConGrad;
	}
	 
	public String getPageConsultaGraduatoria() {
		return pageConsultaGraduatoria;
	}

	public void setPageConsultaGraduatoria(String pageConsultaGraduatoria) {
		this.pageConsultaGraduatoria = pageConsultaGraduatoria;
	}  
	
	public String getImgConGrad() {
		return imgConGrad;
	}

	public void setImgConGrad(String imgConGrad) {
		this.imgConGrad = imgConGrad;
	}
	
	public String getVisConGrad() {
		return visConGrad;
	}

	public void setVisConGrad(String visConGrad) {
		this.visConGrad = visConGrad;
	}

	public String getTestoAreaCCScaduto() {
		return testoAreaCCScaduto;
	}

	public void setTestoAreaCCScaduto(String testoAreaCCScaduto) {
		this.testoAreaCCScaduto = testoAreaCCScaduto;
	}

	public String getPulsanteGestAssegnazioni() {
		return pulsanteGestAssegnazioni;
	}

	public void setPulsanteGestAssegnazioni(String pulsanteGestAssegnazioni) {
		this.pulsanteGestAssegnazioni = pulsanteGestAssegnazioni;
	}

	public String getImgGestAssegnazioni() {
		return imgGestAssegnazioni;
	}

	public void setImgGestAssegnazioni(String imgGestAssegnazioni) {
		this.imgGestAssegnazioni = imgGestAssegnazioni;
	}

	public String getVisGestAssegnazioni() {
		return visGestAssegnazioni;
	}

	public void setVisGestAssegnazioni(String visGestAssegnazioni) {
		this.visGestAssegnazioni = visGestAssegnazioni;
	}

	public String getImgEsclusioni() {
		return imgEsclusioni;
	}

	public void setImgEsclusioni(String imgEsclusioni) {
		this.imgEsclusioni = imgEsclusioni;
	}

	public String getPulsanteEsclusioni() {
		return pulsanteEsclusioni;
	}

	public void setPulsanteEsclusioni(String pulsanteEsclusioni) {
		this.pulsanteEsclusioni = pulsanteEsclusioni;
	}

	public String getVisEsclusioni() {
		return visEsclusioni;
	}

	public void setVisEsclusioni(String visEsclusioni) {
		this.visEsclusioni = visEsclusioni;
	}

	public boolean isAbilitataAreaBO() {
		return isAbilitataAreaBO;
	}

	public void setAbilitataAreaBO(boolean isAbilitataAreaBO) {
		this.isAbilitataAreaBO = isAbilitataAreaBO;
	}
	
	
}
