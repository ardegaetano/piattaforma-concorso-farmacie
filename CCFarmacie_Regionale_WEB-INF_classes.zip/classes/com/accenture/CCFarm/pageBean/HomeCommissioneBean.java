package com.accenture.CCFarm.pageBean;

import java.io.IOException;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.model.StreamedContent;

import com.accenture.CCFarm.DAO.RegioneDatiBando;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;


@ManagedBean
@RequestScoped
public class HomeCommissioneBean {

//Configura punteggi voti di laurea
	private String pulsanteCPuntiLaurea = "none";
	private String imgCPuntiLaurea = "none";
	private String visCPuntiLaurea = "true";

//Configura punteggi voti di abilitazione
	private String pulsanteCPuntiAbili = "none";
	private String imgCPuntiAbili = "none";
	private String visCPuntiAbili = "true";

//Calcola punteggi 	automatici
	private String pulsanteCalcolaAuto = "none";
	private String imgCalcolaAuto = "none";
	private String visCalcolaAuto = "true";

//Elabora pre-graduatoria
	private String pulsantePreGraduatoria = "none";
	private String imgPreGraduatoria = "none";
	private String visPreGraduatoria = "true";

//Gestisci graduatoria
	private String pulsanteGraduatoria = "none";
	private String imgGraduatoria = "none";
	private String visGraduatoria = "true";
	
//	
//	private String msgAssociata="";
//	private String esitoAnnullaDom="";
	
	
	private FacesContext context =null;
	private HttpSession session= null; 
	private HttpServletRequest request=null; 
	
	Logger logger = CommonLogger.getLogger("HomeCommissioneBean");

	
 
	
	public HomeCommissioneBean(){
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	
	public void init() {  
		
		context = FacesContext.getCurrentInstance();
		request = (HttpServletRequest) context.getExternalContext().getRequest();
    	session = request.getSession();

//Configura punteggi voti di laurea
    	pulsanteCPuntiLaurea = "block";
    	imgCPuntiLaurea = "../images/layout/btn_conf_punti_laurea..png";
    	visCPuntiLaurea = "false";

//Configura punteggi voti di abilitazione
    	pulsanteCPuntiAbili = "block";
    	imgCPuntiAbili = "../images/layout/btn_conf_punti_abilitazione.png";
    	visCPuntiAbili = "false";

//Calcola punteggi 	automatici
    	pulsanteCalcolaAuto = "block";
    	imgCalcolaAuto = "../images/layout/btn_calcola_punt_auto.png";
    	visCalcolaAuto = "false";

//Elabora pre-graduatoria
    	pulsantePreGraduatoria = "block";
    	imgPreGraduatoria = "../images/layout/btn_pre_graduatoria.png";
    	visPreGraduatoria = "false";

//Gestisci graduatoria
    	pulsanteGraduatoria = "block";
    	imgGraduatoria = "../images/layout/btn_gestisci_graduatoria.png";
    	visGraduatoria = "false";
    	    	

	
	}
	
	
	public void confPuntLaureati(){
		System.out.println("confPuntLaureati");
//		JSFUtility.redirect("contatti.jsf");
	}
	public void confPuntAbilitati(){
		System.out.println("confPuntAbilitati");
//	JSFUtility.redirect("contatti.jsf");
	}
	public void calcolaPuntAutomatico(){
		System.out.println("calcolaPuntAutomatico");
//	JSFUtility.redirect("contatti.jsf");
	}
	public void preGraduatoria(){
		System.out.println("preGraduatoria");
//	JSFUtility.redirect("contatti.jsf");
	}
	public void graduatoria(){
		System.out.println("graduatoria");
//	JSFUtility.redirect("contatti.jsf");
	}


	public String getPulsanteCPuntiLaurea() {
		return pulsanteCPuntiLaurea;
	}


	public void setPulsanteCPuntiLaurea(String pulsanteCPuntiLaurea) {
		this.pulsanteCPuntiLaurea = pulsanteCPuntiLaurea;
	}


	public String getImgCPuntiLaurea() {
		return imgCPuntiLaurea;
	}


	public void setImgCPuntiLaurea(String imgCPuntiLaurea) {
		this.imgCPuntiLaurea = imgCPuntiLaurea;
	}


	public String getVisCPuntiLaurea() {
		return visCPuntiLaurea;
	}


	public void setVisCPuntiLaurea(String visCPuntiLaurea) {
		this.visCPuntiLaurea = visCPuntiLaurea;
	}


	public String getPulsanteCPuntiAbili() {
		return pulsanteCPuntiAbili;
	}


	public void setPulsanteCPuntiAbili(String pulsanteCPuntiAbili) {
		this.pulsanteCPuntiAbili = pulsanteCPuntiAbili;
	}


	public String getImgCPuntiAbili() {
		return imgCPuntiAbili;
	}


	public void setImgCPuntiAbili(String imgCPuntiAbili) {
		this.imgCPuntiAbili = imgCPuntiAbili;
	}


	public String getVisCPuntiAbili() {
		return visCPuntiAbili;
	}


	public void setVisCPuntiAbili(String visCPuntiAbili) {
		this.visCPuntiAbili = visCPuntiAbili;
	}


	public String getPulsanteCalcolaAuto() {
		return pulsanteCalcolaAuto;
	}


	public void setPulsanteCalcolaAuto(String pulsanteCalcolaAuto) {
		this.pulsanteCalcolaAuto = pulsanteCalcolaAuto;
	}


	public String getImgCalcolaAuto() {
		return imgCalcolaAuto;
	}


	public void setImgCalcolaAuto(String imgCalcolaAuto) {
		this.imgCalcolaAuto = imgCalcolaAuto;
	}


	public String getVisCalcolaAuto() {
		return visCalcolaAuto;
	}


	public void setVisCalcolaAuto(String visCalcolaAuto) {
		this.visCalcolaAuto = visCalcolaAuto;
	}


	public String getPulsantePreGraduatoria() {
		return pulsantePreGraduatoria;
	}


	public void setPulsantePreGraduatoria(String pulsantePreGraduatoria) {
		this.pulsantePreGraduatoria = pulsantePreGraduatoria;
	}


	public String getImgPreGraduatoria() {
		return imgPreGraduatoria;
	}


	public void setImgPreGraduatoria(String imgPreGraduatoria) {
		this.imgPreGraduatoria = imgPreGraduatoria;
	}


	public String getVisPreGraduatoria() {
		return visPreGraduatoria;
	}


	public void setVisPreGraduatoria(String visPreGraduatoria) {
		this.visPreGraduatoria = visPreGraduatoria;
	}


	public String getPulsanteGraduatoria() {
		return pulsanteGraduatoria;
	}


	public void setPulsanteGraduatoria(String pulsanteGraduatoria) {
		this.pulsanteGraduatoria = pulsanteGraduatoria;
	}


	public String getImgGraduatoria() {
		return imgGraduatoria;
	}


	public void setImgGraduatoria(String imgGraduatoria) {
		this.imgGraduatoria = imgGraduatoria;
	}


	public String getVisGraduatoria() {
		return visGraduatoria;
	}


	public void setVisGraduatoria(String visGraduatoria) {
		this.visGraduatoria = visGraduatoria;
	}


	public FacesContext getContext() {
		return context;
	}


	public void setContext(FacesContext context) {
		this.context = context;
	}


	public HttpSession getSession() {
		return session;
	}


	public void setSession(HttpSession session) {
		this.session = session;
	}


	public HttpServletRequest getRequest() {
		return request;
	}


	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}


	public Logger getLogger() {
		return logger;
	}


	public void setLogger(Logger logger) {
		this.logger = logger;
	}


	
}
