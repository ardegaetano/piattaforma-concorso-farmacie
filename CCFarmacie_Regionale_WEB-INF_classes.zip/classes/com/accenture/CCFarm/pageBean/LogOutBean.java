package com.accenture.CCFarm.pageBean;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.utility.AppProperties;


@ManagedBean
@RequestScoped
public class LogOutBean implements Serializable {
	
	
	private HttpSession session= null; 
	private HttpServletRequest req =null;
	private HttpServletResponse res =null;
	
	
	public LogOutBean(){
		try {
			this.init();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void init() throws IllegalAccessException, InvocationTargetException {  
		FacesContext context = FacesContext.getCurrentInstance();
    	//HttpSession session = (HttpSession)context.getExternalContext().getSession(true);
    	req = (HttpServletRequest) context.getExternalContext().getRequest();
    	session = req.getSession();
    	res = (HttpServletResponse) context.getExternalContext().getResponse();
    	

	}
		
	public String chiudiSessione(){
		
		
		req.getSession().invalidate();
	
    		
		try {
			res.sendRedirect(AppProperties.getAppProperties().getProperty("BaseUrlCartina")+"/jsp/cartinaPortale.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return  "homeCandidato";
		
	}
	
	
}
