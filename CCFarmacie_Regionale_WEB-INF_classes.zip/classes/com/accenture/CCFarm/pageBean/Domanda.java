package com.accenture.CCFarm.pageBean;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.log4j.Logger;
import org.primefaces.event.FlowEvent;

import com.accenture.CCFarm.DAO.CandidaturaReg;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.DomandaDao;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.RegioneDatiBando;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.DAO.UtenteCandidaturaRegHome;
import com.accenture.CCFarm.action.DomandaAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.ControlloBandoScaduto;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;

@ManagedBean
@SessionScoped
public class Domanda {
	private boolean flagVerifica;

	private String idUtente;
	private String tipologiaUtente;// pu� assumere i valori: singolo, referente,
									// associato
	private String codiceRegione, denominazioneRegione;
	private String messaggioErrore;

	private String oldWizardStep;
	private String currentWizardStep;
	private String newWizardStep;

	// sotto-bean di pagina
	private RequisitiMinimiBean requisitiMinimiBean;
	private TitoliStudioCarrieraBean titoliStudioCarrieraBean;
	private EsercizioProfBean esercizioProfBean;
	private DichiarazioneSostitutivaBean dichiarazioneSostitutivaBean;

	private RegioneDatiBando regioneDatiBando = null;
	private CandidaturaReg candidaturaReg = null;
	private String statoCandidatura = "";
	private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss");
	private boolean showEscludi = true;
	Logger logger = CommonLogger.getLogger("Domanda");

	private DomandaAction domandaAction;
	private static final String flagValoreVero  = AppProperties.getAppProperties().getProperty("flag.valore.vero");
	private static final String msg  = AppProperties.getAppProperties().getProperty("msg.interpello.in.corso.controlla.domanda");
	
	
	public Domanda() {
		try {
			trovaDatiRegione();
			requisitiMinimiBean = new RequisitiMinimiBean();
			titoliStudioCarrieraBean = new TitoliStudioCarrieraBean();
			esercizioProfBean = new EsercizioProfBean();
			dichiarazioneSostitutivaBean = new DichiarazioneSostitutivaBean();

			domandaAction = new DomandaAction();
			init();
			
		} catch (Exception e) {
			e.printStackTrace();
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
	}

	private void trovaIDUtente() throws Exception {
		idUtente = (String) GetSessionUtility.getSessionAttribute(RepositorySession.ID_UTENTE_RETTIFICA);

		// PER TEST
		// idUtente ="620";

		if (idUtente == null)
			throw new Exception("[Impossibile individuare Utente loggato]");
	}

	private void trovaDomandaUtente() throws Exception {
		CandidaturaReg candidatura = domandaAction.trovaCandidaturaUtente(idUtente);
		if (candidatura == null)
			throw new Exception("[Impossibile trovare la candidatura per l'Utente " + idUtente + "]");
		setCandidaturaReg(candidatura);
	}

	// recupera dalla sessione il codice regione
	private void trovaDatiRegione() throws Exception {
		UtenteRegioni utenteReg = (UtenteRegioni) GetSessionUtility.getSessionAttribute(RepositorySession.UTENTE_NSIS);
		if (utenteReg != null)
			codiceRegione = utenteReg.getCodRegione();
		if (codiceRegione == null)
			throw new Exception("[Impossibile individuare codice Regione]");

		DatiBando datiBando = new DatiBandoHome().findById(codiceRegione);
		GetSessionUtility.setSessionAttribute(RepositorySession.DATI_BANDO, datiBando);
	}

	public void init() {
		try {
			trovaIDUtente();
			trovaDomandaUtente();

			// inizializza frasi per l'Help
			requisitiMinimiBean.setListaHelp(Help.caricaHelpDatiCandidato());
			requisitiMinimiBean.setListaHelpTitoli(Help.caricaHelpTitoliDiStudio());
			requisitiMinimiBean.setListaHelpEsercizio(Help.caricaHelpEsercizioProfessionale());
			requisitiMinimiBean.setListaHelpVersamento(Help.caricaHelpDatiVersamento());
			requisitiMinimiBean.setListaHelpUtente(Help.caricaHelpDatiUtente());

			// inizializza tutti e 4 i sotto-bean
			// tab 1
			requisitiMinimiBean.init(idUtente);

			// tab 2
			titoliStudioCarrieraBean.init(idUtente);
			titoliStudioCarrieraBean.titoliStudioAction.setUtenteCandidatura(requisitiMinimiBean.requisitiMinimiAction.getUtenteCandidatura());

			// tab 3
			esercizioProfBean.init(idUtente, codiceRegione);

			// tab 4
			dichiarazioneSostitutivaBean.init(idUtente);
			requisitiMinimiBean.setNoteAppRequisiti(dichiarazioneSostitutivaBean.getNoteCommissione());
			
			
		} catch (Exception e) {
			e.printStackTrace();
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
	}

	private DomandaDao getUpdatedDomanda() {
		// ricava il timestamp dell'orario corrente
		Timestamp now = DateUtil.getCurrentTimestamp();

		// popola i bean del database

		// tab 1
		requisitiMinimiBean.updateDAO(idUtente, now);

		// tab 2
		titoliStudioCarrieraBean.updateDAO(idUtente);

		// tab 3
		esercizioProfBean.updateDAO(idUtente);

		// tab 4
		dichiarazioneSostitutivaBean.updateDAO(idUtente);

		UtenteCandidaturaReg utenteCandidatura = requisitiMinimiBean.requisitiMinimiAction.getUtenteCandidatura();

		// se il popolamento dei bean del db � andato a buon fine (nessuna
		// eccezione a runtime)..
		// ..procedi col salvataggio dei dati

		DomandaDao domanda = new DomandaDao();

		// dati tab 1
		domanda.setUtenteCandidatura(utenteCandidatura);

		domanda.setCandidaturaReg(candidaturaReg);

		domanda.setRequisitiMinimi(requisitiMinimiBean.requisitiMinimiAction.getRequisitiMinimi());

		// dati tab 2
		domanda.setAltraLaurea(titoliStudioCarrieraBean.titoliStudioAction.getAltraLaurea());
		domanda.setListaAltraLaureaBis(titoliStudioCarrieraBean.titoliStudioAction.getAltreLaureeBis());
		domanda.setListaAltroTitolo(titoliStudioCarrieraBean.titoliStudioAction.getAltriTitoli());
		domanda.setListaBorsaStudio(titoliStudioCarrieraBean.titoliStudioAction.getBorseStudio());
		domanda.setListaCorsoAggiornamento(titoliStudioCarrieraBean.titoliStudioAction.getCorsiAggiornamento());
		domanda.setListaDottorato(titoliStudioCarrieraBean.titoliStudioAction.getDottorati());
		domanda.setListaPubblicazione(titoliStudioCarrieraBean.titoliStudioAction.getPubblicazioni());
		domanda.setListaSpecializzazione(titoliStudioCarrieraBean.titoliStudioAction.getSpecializzazioni());
		domanda.setIdoneita(titoliStudioCarrieraBean.titoliStudioAction.getIdoneita());

		// dati tab 3
		domanda.setListaEserciziProf(esercizioProfBean.esercizioProfAction.getEserciziProf());

		// dati tab 4
		domanda.setDichiarazioneSostitutiva(dichiarazioneSostitutivaBean.dichiarazioneSostitutivaAction.getDichiarazioneSostitutiva());
		domanda.setListaDocumenti(dichiarazioneSostitutivaBean.dichiarazioneSostitutivaAction.getListaDocumenti());

		return domanda;
	}

	private void salvaDatiDomanda() throws GestioneErroriException
	{
		UtenteRegioni utenteReg = (UtenteRegioni) GetSessionUtility.getSessionAttribute(RepositorySession.UTENTE_NSIS);
		String userLoggato = utenteReg.getUserId();
		
		// esegui transazione per salvare i dati sul db
		UtenteCandidaturaRegHome utenteCandidaturaHome = new UtenteCandidaturaRegHome();
		//utenteCandidaturaHome.inserisciDomanda(getUpdatedDomanda());
		
		DomandaDao domanda = getUpdatedDomanda();
		Graduatoria vecchio = new Graduatoria();
		GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
		DatiBando datiBando = new DatiBando();
		DatiBandoHome datiBandoHome = new DatiBandoHome();
		CandidaturaRegHome candidaturaHome = new CandidaturaRegHome();
		
		
//		boolean bRet = utenteCandidaturaHome.bAggiornaDomanda(domanda); //salvataggio della domanda e modifica flag
		boolean bRet = utenteCandidaturaHome.bAggiornaDomanda_newB(domanda, userLoggato); //salvataggio della domanda e modifica flag  Nuova versione
		if(bRet){
			JSFUtility.addInfoMessage("Salvataggio Domanda Riuscito","",false);
//			boolean bPunteggiOk = utenteCandidaturaHome.bCalcolaPunteggiCandidatura(domanda); //ricalcola i punteggi della candidatura
			
			datiBando = datiBandoHome.findById(getCodiceRegione());
			datiBando.setFlgAbilitaGrad("false");
			datiBandoHome.saveOrUpdate(datiBando);
			if(datiBandoHome.getFlagPrecalcolataByRegione(getCodiceRegione())){  //ho fatto il calcolo
				    vecchio = graduatoriaHome.findById(domanda.getCandidaturaReg().getIdCandidatura());
					
				    if(vecchio!=null){ //utente presente in graduatoria
					boolean bPunteggiOk = utenteCandidaturaHome.bCalcolaPunteggiCandidatura_new(domanda, userLoggato); //ricalcola i punteggi della candidatura  Nuova versione 
						
						if(bPunteggiOk){
							domandaAction.ricalcolaGraduatoria(domanda.getCandidaturaReg().getIdCandidatura(),vecchio, userLoggato);
							JSFUtility.addInfoMessage("Rielaborazione Candidatura Riuscito","",false);
						
						}else {
							JSFUtility.addWarningMessage("Attenzione","Errore nel ricalcolo del punteggio");
						}
				  }	else{
					 // metti a true l'errore di calcolo
					  candidaturaHome.setErroreElaborazione(domanda.getCandidaturaReg().getIdUtente());
					  					  					
					  JSFUtility.addWarningMessage("Attenzione","La candidatura non � presente in graduatoria pertanto non si pu� procedere al ricalcolo della scheda");
				  }
			  
			}
			
		}
	}

	// procede al salvataggio parziale dei dati
	public void salvaDomanda() {
		try {
		    	
			boolean controlliSuperati = true;

			// controlla che i dati del tab 1 siano stati correttamente inseriti
			if (!requisitiMinimiBean.controllaCampi())
				controlliSuperati = false;

			// se si � nel tab 2..
			if (currentWizardStep != null && currentWizardStep.equalsIgnoreCase("tabTitoliStudio")) {
				if (!titoliStudioCarrieraBean.controllaCampi() || !titoliStudioCarrieraBean.controllaSecondaLaurea())
					controlliSuperati = false;
			}

			// se si � nel tab 3..
			if (currentWizardStep != null && currentWizardStep.equalsIgnoreCase("tabEsercizioProfessionale")) {
				if (!esercizioProfBean.controllaCampi())
					controlliSuperati = false;
			}

			// se si � nel tab 4..
			if (currentWizardStep != null && currentWizardStep.equalsIgnoreCase("tabDichiarazioneSostitutiva")) {
				// ..controlla che i suoi dati siano stati correttamente
				// inseriti

				if (titoliStudioCarrieraBean.isVisualizzaPanelVersamenti()) {
					if (!dichiarazioneSostitutivaBean.controllaDate())
						controlliSuperati = false;
				}
				/*
				 * else
				 * if(titoliStudioCarrieraBean.isVisualizzaPanelDocumenti()) {
				 * if(!dichiarazioneSostitutivaBean.controllaFlag())
				 * controlliSuperati=false; }
				 */
				else if (!titoliStudioCarrieraBean.isVisualizzaPanelDocumenti())// Per
																				// NO
																				// contributo
																				// partecipazione
					dichiarazioneSostitutivaBean.setTipiPagamento("");

			}

			if (controlliSuperati) {
				// salva domanda
				String id_Candidatura = candidaturaReg.getIdCandidatura(); 
				//Controllo che l'utente non sia escluso
				CandidaturaRegHome candidaturaHome = new CandidaturaRegHome();
			    if(candidaturaHome.isCandidaturaEsclusa(candidaturaReg)) {
			    	JSFUtility.addWarningMessage("Operazione non consentita:", "la candidatura risulta esclusa");
			    }
			    else {
			    	salvaDatiDomanda();
			    }
			}
	    
			JSFUtility.scrollTo("msgs");
			
		} catch (Exception e) {
			e.printStackTrace();
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
	}
	
	

	public void controllaEscludi()
	{
		
			 JSFUtility.executeScript("confirmation.show()");
		}

	public boolean isShowEscludi() {
		return showEscludi;
	}

	public void setShowEscludi(boolean showEscludi) {
		this.showEscludi = showEscludi;
	}

	public String escludiDomanda() {
		try {
			trovaIDUtente();
			trovaDomandaUtente();
			boolean result = domandaAction.escludiDomanda(this);
			showEscludi = false;
			if(result){
				JSFUtility.addInfoMessage("Candidatura esclusa con successo", "", false);
				//Se provengo da elabora graduatoria la lista schede viene azzerata in quanto la scheda candidato non � pi� presente
				ElaboraGraduatoria elaboraGraduatoria = (ElaboraGraduatoria) GetSessionUtility.getSessionAttribute("elaboraGraduatoria");
    			if(elaboraGraduatoria!=null)
    			{
    				elaboraGraduatoria.getRicercaSchedeValutazione().pulisciFiltri();
    				elaboraGraduatoria.getRicercaSchedeValutazione().setListaSchede(new ArrayList<RicercaSchedeValutazione>());
    				elaboraGraduatoria.getRicercaSchedeValutazione().setIdSchedeList(new ArrayList<String>());
    				elaboraGraduatoria.getRicercaSchedeValutazione().setTotaleSchedeInt(0);
    				elaboraGraduatoria.getRicercaSchedeValutazione().setTotaleSchede("0");
    				elaboraGraduatoria.getRicercaSchedeValutazione().setParzialeSchede("0");
    			}
			}else{
				JSFUtility.addWarningMessage("Attenzione","La candidatura � gi� stata esclusa");
			}
			JSFUtility.scrollTo("msgs");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
		return null;

	}

	// restituisce true solo se sono rispettate le condizioni perliminari per
	// procedere all'invio/inserimento della domanda corrente
	private boolean controllaRequisitiDomanda() {
		ControlloBandoScaduto controllo = new ControlloBandoScaduto();
		try {
			// se il bando non � scaduto
			if (controllo.controllaScadenza(codiceRegione)) {
				// se il tab requisiti minimi � stato compilato per intero
				if (requisitiMinimiBean.isCompletato()) {
					// controlla che i dati dell'ultimo tab siano corretti
					if (titoliStudioCarrieraBean.isVisualizzaPanelVersamenti()) {
						if (!dichiarazioneSostitutivaBean.controllaDate())
							return false;
					}
					return true;
				} else {
					JSFUtility.addWarningMessage("Attenzione", "I dati relativi ai requisiti minimi di ammissione non sono completi");
					JSFUtility.scrollTo("msgs");
				}
			} else {
				JSFUtility.addWarningMessage("", "Il termine per la presentazione della domanda � scaduto.");
				JSFUtility.scrollTo("msgs");
			}
		} catch (GestioneErroriException e) {
			logger.error("Domanda - controllo validit� bando: " + e);
			LogUtil.printException(e);
			JSFUtility.redirect("errorPageGenerica.jsf");
		}

		return false;
	}

	/*
	 * private boolean controllaCondizioniNecessarie() { try {
	 * if(controllaInvioGiaEffettuato()) {
	 * 
	 * if(controllaRequisitiDomanda()) { if
	 * (!tipologiaUtente.equals("referente") ||
	 * (tipologiaUtente.equals("referente") && controlloAbilitaInvio())) return
	 * true; } return false; }
	 * 
	 * return false; }
	 * 
	 * catch(Exception e) { e.printStackTrace();
	 * JSFUtility.addWarningMessage("Attenzione"
	 * ,"Si � verificato un problema nel controllo dei requisiti"); return
	 * false; } }
	 */

	// verifica se ci sono tutte le condizioni per procedere ad un completamento
	// o all'invio di una domanda
	/*
	 * public void controllaDati() { if(controllaCondizioniNecessarie()) {
	 * //cerca in sessione il bean per la visualizzazione della domanda
	 * DomandaVisualizzazione
	 * domandaVisualizzazione=(DomandaVisualizzazione)GetSessionUtility
	 * .getSessionAttribute("domandaVisualizzazione");
	 * if(domandaVisualizzazione!=null) { // se gi� presente, forza il
	 * ricaricamento dei dati // (necessario per evitare che mostri in riepilogo
	 * dati non corrispondenti alle ultime modifiche)
	 * domandaVisualizzazione.init(); } else { //se non � presente, ne crea una
	 * nuova istanza e la setta in sessione domandaVisualizzazione=new
	 * DomandaVisualizzazione();
	 * GetSessionUtility.setSessionAttribute("domandaVisualizzazione"
	 * ,domandaVisualizzazione); }
	 * 
	 * JSFUtility.redirect("riepilogoDomanda.jsf"); } else {
	 * JSFUtility.executeScript("blockUI.hide()"); } }
	 */

	/*
	 * public String indietro() { //DA RICERCA CANDIDATI String sRet =
	 * (String)GetSessionUtility
	 * .getSessionAttribute(RepositorySession.PAGE_RETURN); if(sRet!=null) {
	 * return sRet; } else { //DA ELABORA GRADUATORIA
	 * //((HttpSession)FacesContext
	 * .getCurrentInstance().getExternalContext().getSession
	 * (false)).removeAttribute("domanda"); ElaboraGraduatoria
	 * elaboraGraduatoria = new ElaboraGraduatoria();
	 * elaboraGraduatoria.aggiornaTabDaVisualizzare();
	 * //JSFUtility.redirect("elaboraGraduatoria.jsf");
	 * //JSFUtility.redirect("elaboraGraduatoria.jsf?indexTab=1;"); return
	 * "elaboraGraduatoria.jsf"; } }
	 */

	public void controllaFlagVerifica() {
		if (!flagVerifica) {
			JSFUtility.addWarningMessage("", "E' necessario spuntare la casella di dichiarazione sulla verifica dei dati inseriti");
		} else {
			JSFUtility.executeScript("confirmation.show()");
		}
	}

	public void prosegui() {
		JSFUtility.redirect("confermaDomanda.jsf");
	}

	// procede con la chiusura dell'inserimento (da parte di un associato), se
	// sussistono tutte le condizioni per poterlo fare

	private void completaInserimento() {
		try {
			// salva domanda in stato "Completata"
			salvaDatiDomanda();

			// aggiornaStatoCandidaturaInSessione("C");

			JSFUtility.redirect("successPage.jsf");
		} catch (Exception e) {
			e.printStackTrace();
			JSFUtility.redirect("errorPage.jsf");
		}
	}

	// ------------------------------------------------------------------------------------------------------------------------------

	// gestisce il passaggio tra un tab e l'altro del wizard
	public String handleFlow(FlowEvent event) {
		oldWizardStep = event.getOldStep();
		newWizardStep = event.getNewStep();

		try {
			
			//Controllo Interpello in corso
			if(domandaAction.isFaseInterpelloAttiva(codiceRegione)){
				JSFUtility.addWarningMessage("Attenzione!!", msg);
			}
			
			// passaggio al tab 1
			if (newWizardStep != null && newWizardStep.equalsIgnoreCase("tabRequisitiAmmissione") && oldWizardStep.equalsIgnoreCase("tabTitoliStudio")) {
				requisitiMinimiBean.setNoteAppRequisiti(titoliStudioCarrieraBean.getNoteAppTitoli());
			}
	
			// passaggio al tab 2
			if (newWizardStep != null && newWizardStep.equalsIgnoreCase("tabTitoliStudio")) {
				// controlla che tutte i campi siano stati valorizzati correttamente
				if (!requisitiMinimiBean.controllaCampi()) {
					// se il controllo fallisce -> blocca sul tab corrente e sposta
					// il focus sull'area messaggi
					JSFUtility.scrollTo("msgs");
	
					currentWizardStep = oldWizardStep;
					return oldWizardStep;
				}
				// se i controlli sono stati superati
				titoliStudioCarrieraBean.setDataNascitaUtente(requisitiMinimiBean.getDataNascitaUtente());
				titoliStudioCarrieraBean.setDataPrimaLaurea(requisitiMinimiBean.getDataLaurea());
				titoliStudioCarrieraBean.setDescPrimaLaurea(requisitiMinimiBean.getCodTipoLaurea());
	
				if (oldWizardStep.equalsIgnoreCase("tabEsercizioProfessionale"))
					titoliStudioCarrieraBean.setNoteAppTitoli(esercizioProfBean.getNoteAppEsercizio());
				else
					titoliStudioCarrieraBean.setNoteAppTitoli(requisitiMinimiBean.getNoteAppRequisiti());
			}
	
			// passaggio al tab 3
			if (newWizardStep != null && newWizardStep.equalsIgnoreCase("tabEsercizioProfessionale")) {
				// passa la data di iscrizione albo al bean esercizio professionale
	
				titoliStudioCarrieraBean.controllaPubbl();
	
				if (!titoliStudioCarrieraBean.controllaCampi() || !titoliStudioCarrieraBean.controllaSecondaLaurea()) {
					JSFUtility.scrollTo("msgs");
	
					currentWizardStep = oldWizardStep;
					return oldWizardStep;
				}
	
				esercizioProfBean.setDataIscrizioneAlbo(requisitiMinimiBean.getDataAlbo());
				esercizioProfBean.setDataNascitaUtente(requisitiMinimiBean.getDataNascitaUtente());
	
				if (oldWizardStep.equalsIgnoreCase("tabTitoliStudio"))
					esercizioProfBean.setNoteAppEsercizio(titoliStudioCarrieraBean.getNoteAppTitoli());
				else
					esercizioProfBean.setNoteAppEsercizio(dichiarazioneSostitutivaBean.getNoteCommissione());
			}
	
			// passaggio al tab 4
			if (newWizardStep != null && newWizardStep.equalsIgnoreCase("tabDichiarazioneSostitutiva")) {
				if (!esercizioProfBean.controllaCampi()) {
					JSFUtility.scrollTo("msgs");
	
					currentWizardStep = oldWizardStep;
					return oldWizardStep;
				}
	
				dichiarazioneSostitutivaBean.setTipologiaVersamento(titoliStudioCarrieraBean.getTipologiaVersamento());
	
				// Tipologia Versamento da REGIONE combinata
				if (!titoliStudioCarrieraBean.isVisualizzaPanelDocumenti() && dichiarazioneSostitutivaBean.getTipologiaVersamento() != null && dichiarazioneSostitutivaBean.getTipologiaVersamento().equals("Bancario/Postale")) {
					if (dichiarazioneSostitutivaBean.getIban() != null && (!dichiarazioneSostitutivaBean.getIban().equals(""))) {
						dichiarazioneSostitutivaBean.setTipiPagamento("0"); // Bancario
					} else if (dichiarazioneSostitutivaBean.getNumeroUffPostale() != null && (!dichiarazioneSostitutivaBean.getNumeroUffPostale().equals(""))) {
						dichiarazioneSostitutivaBean.setTipiPagamento("1"); // Postale
					} else {
						dichiarazioneSostitutivaBean.setTipiPagamento(""); // Default
					}
				} else {
					dichiarazioneSostitutivaBean.setTipiPagamento(""); // Default
				}
	
				dichiarazioneSostitutivaBean.setElencoDocumenti(titoliStudioCarrieraBean.getElencoDoc());
	
				dichiarazioneSostitutivaBean.setNoteCommissione(esercizioProfBean.getNoteAppEsercizio());
				
				JSFUtility.addWarningMessage("Attenzione:", "verranno ricalcolati esclusivamenti i punteggi relativi alle esperienze professionali.");
	
			}
	
			JSFUtility.update("commandPanel");
			JSFUtility.scrollTo("wizardDomanda");
	
			currentWizardStep = newWizardStep;
			
		} catch (Exception e) {
			e.printStackTrace();
			JSFUtility.redirect("errorPage.jsf");
		}
			
		return newWizardStep;
	}

	public RequisitiMinimiBean getRequisitiMinimiBean() {
		return requisitiMinimiBean;
	}

	public void setRequisitiMinimiBean(RequisitiMinimiBean requisitiMinimiBean) {
		this.requisitiMinimiBean = requisitiMinimiBean;
	}

	public TitoliStudioCarrieraBean getTitoliStudioCarrieraBean() {
		return titoliStudioCarrieraBean;
	}

	public void setTitoliStudioCarrieraBean(TitoliStudioCarrieraBean titoliStudioCarrieraBean) {
		this.titoliStudioCarrieraBean = titoliStudioCarrieraBean;
	}

	public EsercizioProfBean getEsercizioProfBean() {
		return esercizioProfBean;
	}

	public void setEsercizioProfBean(EsercizioProfBean esercizioProfBean) {
		this.esercizioProfBean = esercizioProfBean;
	}

	public DichiarazioneSostitutivaBean getDichiarazioneSostitutivaBean() {
		return dichiarazioneSostitutivaBean;
	}

	public void setDichiarazioneSostitutivaBean(DichiarazioneSostitutivaBean dichiarazioneSostitutivaBean) {
		this.dichiarazioneSostitutivaBean = dichiarazioneSostitutivaBean;
	}

	public DomandaAction getDomandaAction() {
		return domandaAction;
	}

	public void setDomandaAction(DomandaAction domandaAction) {
		this.domandaAction = domandaAction;
	}

	public boolean isFlagVerifica() {
		return flagVerifica;
	}

	public void setFlagVerifica(boolean flagVerifica) {
		this.flagVerifica = flagVerifica;
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public String getTipologiaUtente() {
		return tipologiaUtente;
	}

	public void setTipologiaUtente(String tipologiaUtente) {
		this.tipologiaUtente = tipologiaUtente;
	}

	public String getCodiceRegione() {
		return codiceRegione;
	}

	public void setCodiceRegione(String codiceRegione) {
		this.codiceRegione = codiceRegione;
	}

	public String getDenominazioneRegione() {
		return denominazioneRegione;
	}

	public void setDenominazioneRegione(String denominazioneRegione) {
		this.denominazioneRegione = denominazioneRegione;
	}

	public String getMessaggioErrore() {
		return messaggioErrore;
	}

	public void setMessaggioErrore(String messaggioErrore) {
		this.messaggioErrore = messaggioErrore;
	}

	public String getOldWizardStep() {
		return oldWizardStep;
	}

	public void setOldWizardStep(String oldWizardStep) {
		this.oldWizardStep = oldWizardStep;
	}

	public String getCurrentWizardStep() {
		return currentWizardStep;
	}

	public void setCurrentWizardStep(String currentWizardStep) {
		this.currentWizardStep = currentWizardStep;
	}

	public String getNewWizardStep() {
		return newWizardStep;
	}

	public void setNewWizardStep(String newWizardStep) {
		this.newWizardStep = newWizardStep;
	}

	public RegioneDatiBando getRegioneDatiBando() {
		return regioneDatiBando;
	}

	public void setRegioneDatiBando(RegioneDatiBando regioneDatiBando) {
		this.regioneDatiBando = regioneDatiBando;
	}

	public CandidaturaReg getCandidaturaReg() {
		return candidaturaReg;
	}

	public void setCandidaturaReg(CandidaturaReg candidaturaReg) {
		this.candidaturaReg = candidaturaReg;
	}

	public SimpleDateFormat getSdf() {
		return sdf;
	}

	public void setSdf(SimpleDateFormat sdf) {
		this.sdf = sdf;
	}

	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	public String getStatoCandidatura() {
		return statoCandidatura;
	}

	public void setStatoCandidatura(String statoCandidatura) {
		this.statoCandidatura = statoCandidatura;
	}

	// public String getNote() {
	// return note;
	// }
	//
	// public void setNote(String note) {
	// this.note = note;
	// }

}