package com.accenture.CCFarm.pageBean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.RegioneSelect;
import com.accenture.CCFarm.Bean.RicevutaBean;
import com.accenture.CCFarm.Bean.UtenteBean;
import com.accenture.CCFarm.Bean.UtenteCandidatureBean;
import com.accenture.CCFarm.action.RicercaCandidatoAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


@ManagedBean
@SessionScoped
public class RicercaCandidati
{
	private String nomeRicerca="";
	private String cognomeRicerca="";
	private String codiceFiscaleRicerca="";
	private String codRegioneRicerca;
	private boolean mostraRisultatiRicerca = false;
	private boolean salvaRisultatiRicerca = true;
	
	private String documentazionePervenuta;	
	private String documentazionePrevista;
	private String richiestaCambioPEC;
	
	private String ammessoSelezionato="";
	private String protocollo="";
	private String osservazioniSelezionato="";
	private String osservazioniTitolo="";
	private String osservazioneUno="Attuale provincia d�iscrizione all�albo non valorizzata";
	private String osservazioneDue="Data prima iscrizione all�albo precedente all�anno di abilitazione";
	private String osservazioneTre="Data rilascio doc. di riconoscimento uguale alla data di nascita";
	private String osservazioneQuattro="Voto di laurea mancante";
	private String osservazioneCinque="Voto di abilitazione mancante";
	
	private String regioneSelezionata="";
	private List<RegioneSelect> regioniSelect;
	
	
	private List<String>  idCandidatiList;
	private String totaleCandidati="";
	private String candidatiRicercati="0";
	
	UtenteBean utenteSelezionato  = new UtenteBean();;
	List<UtenteBean> listaCandidature = new ArrayList<UtenteBean>();;
	List<UtenteCandidatureBean> listaUtenteCand = new ArrayList<UtenteCandidatureBean>();
	List<String> listaIDUtenteCand = new ArrayList<String>();
	private UtenteCandidatureBean candidatoSelezionato = new UtenteCandidatureBean();
	private UtenteBean associatoSelezionato =new UtenteBean();
	
	List<UtenteCandidatureBean> listaSalva = new ArrayList<UtenteCandidatureBean>();
	List<RicevutaBean> listaRicevute = new ArrayList<RicevutaBean>();
	
	
	String pageError = "errorPage.jsf";
	
//paginator
	private int rowBlock= 20;
	private int rowIniBlock= 0;
	private int rowFinBlock= 0;
	private int rowNumerUltimo= 0;
	private int numeroCandidati= 0;
	private int numeroPatine= 0;
	private String totaleCandidatiPag="";
	private int totaleCandidatiInt=0;
	private int totalePagine=0;
	private int paginaCorrente=0;
	private String pulsantePagIndietro= "true";
	private String pulsantePagAvanti= "true";
	private String disabledAmmesso = "false";
	
	
//	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
//    Date data_pubb_appoggio = ((DatiBando)session.getValue("DATI_BANDO")).getDataInizioPubblicazioni();
//    Date dataPubblicazioneBando = ((DatiBando)session.getValue("DATI_BANDO")).getDataPubblicazioneBando();
//    UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
//	String codReg = utenteReg.getCodRegione();
	UtenteRegioni utenteReg =null ;
	String codReg = null;
	HttpSession session= null;
	
	RicercaCandidatoAction ricercaCandidatoAction;
	private String[]listaHelp;
	
	private SimpleDateFormat sdf = new SimpleDateFormat();
     
	Logger logger = CommonLogger.getLogger("EsercizioProfBean");
	
	
	
	public RicercaCandidati() 
	{
	    init();
	}	
	public RicercaCandidati(String noInit) 
	{
	}
	public void init(){
		session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	    utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	    codReg = utenteReg.getCodRegione();
		ricercaCandidatoAction=new RicercaCandidatoAction();	
		try {
			idCandidatiList= ricercaCandidatoAction.ricIdCandidatiAll(this);
			setTotaleCandidati(""+idCandidatiList.size());
			setRegioniSelect(Localita.getRegioni());
//	dalla combo delle regioni tolgo quella che ha fatto login
			List<RegioneSelect> listCombo = new ArrayList<RegioneSelect>();
			for (int i = 0; i < regioniSelect.size(); i++) {
				RegioneSelect viaRegione = new RegioneSelect();
				viaRegione = regioniSelect.get(i);
				if (!viaRegione.getCodice().equalsIgnoreCase(utenteReg.getCodRegione())){
					listCombo.add(viaRegione);
				}
			}
			setRegioniSelect(listCombo);
			setOsservazioniTitolo("");
			setListaHelp(Help.caricaHelpRicercaCandidature());
			//Abilita o disabilita button Ammesso SI/NO
			setDisabledAmmesso(ricercaCandidatoAction.isGraduatoriaElaborata(codReg));
			
		} catch (GestioneErroriException e) {
			logger.error("Ricerca Candidati - init : " + e.getMessage());
			JSFUtility.redirect(pageError);
		}
	}
	public String initInizializzazione() {
		try {
			idCandidatiList= ricercaCandidatoAction.ricIdCandidatiAll(this);
			setTotaleCandidati(""+idCandidatiList.size());
			candidatiRicercati="0";
//reset dei campi cerca e lista precedente
			mostraRisultatiRicerca=false;
			salvaRisultatiRicerca=true;
			nomeRicerca= "";
			cognomeRicerca= "";
			codiceFiscaleRicerca="";
			ammessoSelezionato = "-1";
			protocollo ="";
			regioneSelezionata="-1";
			osservazioniSelezionato="-1";
			richiestaCambioPEC="-1";
			
			osservazioniTitolo="";
			listaUtenteCand=null;
			setListaUtenteCand(new ArrayList<UtenteCandidatureBean>());
//			listaUtenteCand= new ArrayList<UtenteCandidatureBean>();
			
		} catch (GestioneErroriException e) {
			logger.error("Ricerca Candidati - initInizializzazione : " + e.getMessage());
//			JSFUtility.redirect(pageError);
			return pageError;
		}
		 return null;
	}
	
	public String puliziaFiltri() {
//		try {
//			idCandidatiList= ricercaCandidatoAction.ricIdCandidatiAll(this);
//			setTotaleCandidati(""+idCandidatiList.size());
//			candidatiRicercati="0";
//reset dei campi cerca e lista precedente
			mostraRisultatiRicerca=false;
			salvaRisultatiRicerca=true;
			nomeRicerca= "";
			cognomeRicerca= "";
			codiceFiscaleRicerca="";
			ammessoSelezionato = "-1";
			protocollo ="";
			regioneSelezionata="-1";
			osservazioniSelezionato="-1";
			documentazionePrevista="-1";
			documentazionePervenuta="-1";			
			richiestaCambioPEC="-1";
			osservazioniTitolo="";
//			listaUtenteCand=null;
//			setListaUtenteCand(new ArrayList<UtenteCandidatureBean>());
//			listaUtenteCand= new ArrayList<UtenteCandidatureBean>();
			
//		} catch (GestioneErroriException e) {
//			logger.error("Ricerca Candidati - initInizializzazione : " + e.getMessage());
//			JSFUtility.redirect(pageError);
//		}
		 return null;
	}
	

	
	public void selezionaCandidature(){
		
//		    listaCandidature = ricercaCandidatoAction.ricercaCandidati(this);
		    try {
				listaUtenteCand = ricercaCandidatoAction.ricercaCandidature(this);
		    	setCandidatiRicercati(""+listaUtenteCand.size());
		    	if (getOsservazioniSelezionato().equals("-1")){
					setOsservazioniTitolo("");
				} else{
					if (getOsservazioniSelezionato().equals("1")){
						setOsservazioniTitolo(" - "+osservazioneUno);
					} else{
						if (getOsservazioniSelezionato().equals("2")){
							setOsservazioniTitolo(" - "+osservazioneDue);
						} else{
							if (getOsservazioniSelezionato().equals("3")){
								setOsservazioniTitolo(" - "+osservazioneTre);
							} else {
								if (getOsservazioniSelezionato().equals("4")){
									setOsservazioniTitolo(" - "+osservazioneQuattro);
								} else {
									if (getOsservazioniSelezionato().equals("5")){
										setOsservazioniTitolo(" - "+osservazioneCinque);
									}
								}
							}
						}
					}
				}
			} catch (Exception e) {
				JSFUtility.redirect(pageError);
			}
		    mostraRisultatiRicerca=true;
		    if (listaUtenteCand.size()>0){
		    	salvaRisultatiRicerca=false;	
		    } else{
		    	salvaRisultatiRicerca=true;
		    }
		    
//		    JSFUtility.update("form:salva");
//		    JSFUtility.update("form:panelRicerca");
	        
   }
	public void selezionaCandidaturePaginato(){
		listaUtenteCand= new ArrayList<UtenteCandidatureBean>();
		rowBlock =20;
		
	    try {
//			listaUtenteCand = ricercaCandidatoAction.ricercaCandidature(this);
//	    	setCandidatiRicercati(""+listaUtenteCand.size());
			listaIDUtenteCand = ricercaCandidatoAction.ricercaCandidaturePaginataID(this);
			if (listaIDUtenteCand.size()==0){
//				listaUtenteCand = null;
//	    		mostraRisultatiRicerca=true;
	    		if (this.getProtocollo()!=null && !this.getProtocollo().equals("")){
	    			listaIDUtenteCand	= ricercaCandidatoAction.check_protocollo(this);
	    			if (listaIDUtenteCand.size()>0){
	    				JSFUtility.addWarningMessage("","Attenzione! Il numero protocollo cercato � stato sostituito con quello visualizzato in elenco");
	    				
	    			}
				}
			}
		
			
			
			
			setCandidatiRicercati(""+listaIDUtenteCand.size());
//row blok  
			totaleCandidatiInt = Integer.parseInt(candidatiRicercati);
			
			if(listaIDUtenteCand.size()>0) {
				paginaCorrente=1;
				if (totaleCandidatiInt>rowBlock){
					totalePagine= totaleCandidatiInt / rowBlock;
					int remainderInt= 0;
					    remainderInt = totaleCandidatiInt % rowBlock;
					if (remainderInt>0){
						totalePagine++;
					}
	//				
				} else {
					totalePagine=1;
				}
				setRowIniBlock(0);
				setRowFinBlock(rowBlock);
				if (listaIDUtenteCand.size()<rowBlock){
					rowBlock=listaIDUtenteCand.size();
					setRowFinBlock(rowBlock);
				}
				setNumeroCandidati(listaIDUtenteCand.size());
			    if (numeroCandidati==rowBlock || numeroCandidati<rowBlock ){
			    	setPulsantePagAvanti("true");
			    	setPulsantePagIndietro("true");
			    } else {
			    	setPulsantePagAvanti("false");
			    	setPulsantePagIndietro("true");
			    }
			
			    listaUtenteCand = ricercaCandidatoAction.ricercaCandidaturePaginataList(this);
			} 
			
//fine row blok	
			
			if (getOsservazioniSelezionato().equals("-1")){
				setOsservazioniTitolo("");
			} else{
				if (getOsservazioniSelezionato().equals("1")){
					setOsservazioniTitolo(" - "+osservazioneUno);
				} else{
					if (getOsservazioniSelezionato().equals("2")){
						setOsservazioniTitolo(" - "+osservazioneDue);
					} else{
						if (getOsservazioniSelezionato().equals("3")){
							setOsservazioniTitolo(" - "+osservazioneTre);
						} else {
							if (getOsservazioniSelezionato().equals("4")){
								setOsservazioniTitolo(" - "+osservazioneQuattro);
							} else {
								if (getOsservazioniSelezionato().equals("5")){
									setOsservazioniTitolo(" - "+osservazioneCinque);
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			JSFUtility.redirect(pageError);
		}
	    mostraRisultatiRicerca=true;
	    if (listaUtenteCand.size()>0){
	    	salvaRisultatiRicerca=false;	
	    } else{
	    	salvaRisultatiRicerca=true;
	    }
	    
	}
	
	public String caricaRicevuta()
	{
		String idUtente=  candidatoSelezionato.getIdUtente();
		if (idUtente==null) idUtente=""; 
//		String urlServlet= " ../scaricaFileServlet?idUtente="+candidatoSelezionato.getIdUtente()==null?"":candidatoSelezionato.getIdUtente();
		String urlServlet= "../scaricaFileServlet?idUtente="+idUtente;
		JSFUtility.redirect(urlServlet);	
	   return null;
	}
	
	public String salvaCandidature()
	{
//		listaUtenteCand = ricercaCandidatoAction.ricercaCandidature(this);
		try {
			ricercaCandidatoAction.salvaCandidatureAmmesse(this);
//			selezionaCandidature(); 
			selezionaCandidaturePaginato();
			
			JSFUtility.addInfoMessage("","Salvataggio avvenuto con successo.");
			
			return null;
			
		} catch (GestioneErroriException e) {
			//JSFUtility.redirect(pageError);
			return pageError;
		}
	}
	
	public String initScaricaRicevute() 
	{
		try {
			Map<String,String> requestParameters = JSFUtility.getFacesContext().getExternalContext().getRequestParameterMap();
		    String idCandidatura = requestParameters.get("idUtente");
		    List<RicevutaBean> listaRicevute = ricercaCandidatoAction.getRicevuteCandidato(codReg, idCandidatura);
		    setListaRicevute(listaRicevute);
		    JSFUtility.update("modalRicevute");
		    JSFUtility.update("ricevute");
			return null;
		}
		catch (GestioneErroriException e) {
			return pageError;	
		}
	}
	
	//Verifica se l'utente risulta escluso o meno
	public String controllaDomanda()
	{
		Map<String,String> requestParameters = JSFUtility.getFacesContext().getExternalContext().getRequestParameterMap();
	    String idUtente = requestParameters.get("idUtente");
	    JSFUtility.redirect("../ChiamaPaginaServlet?PAGE_SEND=compilaDomanda.jsf&ID_UTENTE="+idUtente+"&PAGE_RETURN=ricercaCandidatureDom.jsf"); 
	    return null;
	}
	
	//Verifica se l'utente referente risulta escluso o meno
	public String controllaDomandaReferente()
	{
		Map<String,String> requestParameters = JSFUtility.getFacesContext().getExternalContext().getRequestParameterMap();
	    String idUtente = requestParameters.get("idUtente");
	    String idUtenteAssociato = requestParameters.get("idAssociato");
	    JSFUtility.redirect("../ChiamaPaginaServlet?PAGE_SEND=compilaDomanda.jsf&ID_UTENTE="+idUtenteAssociato+"&PAGE_RETURN=ricercaCandidatureDom.jsf"); 
	    return null;
	}
	
	public String pirmaPagina() {
		rowIniBlock=0;
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente=1;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowIniBlock()== 0 || getRowIniBlock()<0){
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
	    	setPulsantePagIndietro("true");

		}
		
		try {
//			listaCandidature = ricercaCandidatoAction.paginazioneCandidati(this);
			listaUtenteCand = ricercaCandidatoAction.ricercaCandidaturePaginataList(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
//			JSFUtility.redirect(pageError);
			return pageError;
		}
		return null;
	}

	
	public String paginaAvanti() {
		setRowIniBlock(getRowFinBlock());
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente++;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowFinBlock()== getNumeroCandidati() || getRowFinBlock()>getNumeroCandidati()){
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");

		}
		
		try {
			listaUtenteCand = ricercaCandidatoAction.ricercaCandidaturePaginataList(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
//			JSFUtility.redirect(pageError);
			return pageError;
		}
			
		return null;
	}
	
	public String paginaIndietro() {
		rowIniBlock=rowIniBlock-rowBlock;
		setRowFinBlock(getRowIniBlock()+getRowBlock());
		
		paginaCorrente--;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

		if (getRowIniBlock()== 0 || getRowIniBlock()<0){
			setRowIniBlock(0);
			setRowFinBlock(rowBlock);
			setPulsantePagAvanti("false");
	    	setPulsantePagIndietro("true");

		}
		
		try {
//			listaCandidature = new ArrayList<UtenteBean>();
			listaUtenteCand = ricercaCandidatoAction.ricercaCandidaturePaginataList(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
//			JSFUtility.redirect(pageError);
			return pageError;
		}
		return null;
	}
	
	public String ultimaPagina() {
		rowFinBlock=getNumeroCandidati();
		setRowIniBlock(getRowFinBlock()-getRowBlock());
		
		paginaCorrente=totalePagine;
		setPulsantePagAvanti("false");
    	setPulsantePagIndietro("false");

    	if (getRowFinBlock()== getNumeroCandidati() || getRowFinBlock()>getNumeroCandidati()){
			setRowFinBlock(getNumeroCandidati());
			setPulsantePagAvanti("true");
	    	setPulsantePagIndietro("false");
    	}
		
		try {
//			listaCandidature = ricercaCandidatoAction.paginazioneCandidati(this);
			listaUtenteCand = ricercaCandidatoAction.ricercaCandidaturePaginataList(this);
		} catch (GestioneErroriException e) {
			logger.error("Stampa Candidati - paginaAvanti : " + e.getMessage());
//			JSFUtility.redirect(pageError);
			return pageError;
		}
		return null;
	}

	
	
	public String indietro() {
		 
			candidatiRicercati="0";
			//reset dei campi cerca e lista precedente
			mostraRisultatiRicerca=false;
			salvaRisultatiRicerca=true;
			nomeRicerca= "";
			cognomeRicerca= "";
			codiceFiscaleRicerca="";
			ammessoSelezionato = "-1";
			protocollo ="";
			regioneSelezionata="-1";
			osservazioniSelezionato="-1";
			
			osservazioniTitolo="";
			listaUtenteCand=null;
			setListaUtenteCand(new ArrayList<UtenteCandidatureBean>());
//			listaUtenteCand= new ArrayList<UtenteCandidatureBean>();
			
		
		return "homeRegioni";
	}
	
	
	public void regioneCambiata(javax.faces.event.AjaxBehaviorEvent event){
		String sourceId=event.getComponent().getId();
		//carica tutti le province appartenenti alla regione selezionata
//		if(sourceId.equals("regione")){
//			 setProvinceSelect(Localita.getProvince(regioneSelezionata));
//			 provinceList=provinceSelect.get(regioneSelezionata);
//			 setAttivaProvincia(false);
//			 setAttivaComune(true);
//			 RequestContext.getCurrentInstance().update(JSFUtility.getClientId("provincia"));
//		}
	}

//	public void onRowToggle() {  
//      
//          JSFUtility.update("pervenutaDocumentazione");
//       
//    }  
	
	public String getNomeRicerca() {
		return nomeRicerca;
	}

	public void setNomeRicerca(String nomeRicerca) {
		this.nomeRicerca = nomeRicerca;
	}

	public String getCognomeRicerca() {
		return cognomeRicerca;
	}

	public void setCognomeRicerca(String cognomeRicerca) {
		this.cognomeRicerca = cognomeRicerca;
	}

	public String getCodiceFiscaleRicerca() {
		return codiceFiscaleRicerca;
	}

	public void setCodiceFiscaleRicerca(String codiceFiscaleRicerca) {
		this.codiceFiscaleRicerca = codiceFiscaleRicerca;
	}

	public String getCodRegioneRicerca() {
		return codRegioneRicerca;
	}

	public void setCodRegioneRicerca(String codRegioneRicerca) {
		this.codRegioneRicerca = codRegioneRicerca;
	}


	public UtenteBean getUtenteSelezionato() {
		return utenteSelezionato;
	}

	public void setUtenteSelezionato(UtenteBean utenteSelezionato) {
		this.utenteSelezionato = utenteSelezionato;
	}

	public String getCodReg() {
		return codReg;
	}

	public void setCodReg(String codReg) {
		this.codReg = codReg;
	}

	public List<UtenteBean> getListaCandidature() {
		return listaCandidature;
	}

	public void setListaCandidature(List<UtenteBean> listaCandidature) {
		this.listaCandidature = listaCandidature;
	}

	public boolean isMostraRisultatiRicerca() {
		return mostraRisultatiRicerca;
	}

	public void setMostraRisultatiRicerca(boolean mostraRisultatiRicerca) {
		this.mostraRisultatiRicerca = mostraRisultatiRicerca;
	}

	
	public String getRegioneSelezionata() {
		return regioneSelezionata;
	}

	public void setRegioneSelezionata(String regioneSelezionata) {
		this.regioneSelezionata = regioneSelezionata;
	}

	public List<RegioneSelect> getRegioniSelect() {
		return regioniSelect;
	}

	public void setRegioniSelect(List<RegioneSelect> regioniSelect) {
		this.regioniSelect = regioniSelect;
	}

	public List<String> getIdCandidatiList() {
		return idCandidatiList;
	}

	public void setIdCandidatiList(List<String> idCandidatiList) {
		this.idCandidatiList = idCandidatiList;
	}

	public String getTotaleCandidati() {
		return totaleCandidati;
	}

	public void setTotaleCandidati(String totaleCandidati) {
		this.totaleCandidati = totaleCandidati;
	}

	public UtenteRegioni getUtenteReg() {
		return utenteReg;
	}

	public void setUtenteReg(UtenteRegioni utenteReg) {
		this.utenteReg = utenteReg;
	}

	public List<UtenteCandidatureBean> getListaUtenteCand() {
		return listaUtenteCand;
	}

	public void setListaUtenteCand(List<UtenteCandidatureBean> listaUtenteCand) {
		this.listaUtenteCand = listaUtenteCand;
	}
	 
	public List<String> getListaIDUtenteCand() {
		return listaIDUtenteCand;
	}
	public void setListaIDUtenteCand(List<String> listaIDUtenteCand) {
		this.listaIDUtenteCand = listaIDUtenteCand;
	}
	public String getAmmessoSelezionato() {
		return ammessoSelezionato;
	}
	public void setAmmessoSelezionato(String ammessoSelezionato) {
		this.ammessoSelezionato = ammessoSelezionato;
	}
	public String getProtocollo() {
		return protocollo;
	}
	public void setProtocollo(String protocollo) {
		this.protocollo = protocollo;
	}
	public UtenteCandidatureBean getCandidatoSelezionato() {
		return candidatoSelezionato;
	}
	public void setCandidatoSelezionato(UtenteCandidatureBean candidatoSelezionato) {
		this.candidatoSelezionato = candidatoSelezionato;
	}
	public UtenteBean getAssociatoSelezionato() {
		return associatoSelezionato;
	}
	public void setAssociatoSelezionato(UtenteBean associatoSelezionato) {
		this.associatoSelezionato = associatoSelezionato;
	}
	public List<UtenteCandidatureBean> getListaSalva() {
		return listaSalva;
	}
	public void setListaSalva(List<UtenteCandidatureBean> listaSalva) {
		this.listaSalva = listaSalva;
	}
	public List<RicevutaBean> getListaRicevute() {
		return listaRicevute;
	}
	public void setListaRicevute(List<RicevutaBean> listaRicevute) {
		this.listaRicevute = listaRicevute;
	}
	public boolean isSalvaRisultatiRicerca() {
		return salvaRisultatiRicerca;
	}
	public void setSalvaRisultatiRicerca(boolean salvaRisultatiRicerca) {
		this.salvaRisultatiRicerca = salvaRisultatiRicerca;
	}
	public String getCandidatiRicercati() {
		return candidatiRicercati;
	}
	public void setCandidatiRicercati(String candidatiRicercati) {
		this.candidatiRicercati = candidatiRicercati;
	}
	public String getOsservazioniSelezionato() {
		return osservazioniSelezionato;
	}
	public void setOsservazioniSelezionato(String osservazioniSelezionato) {
		this.osservazioniSelezionato = osservazioniSelezionato;
	}
	public String getOsservazioniTitolo() {
		return osservazioniTitolo;
	}
	public void setOsservazioniTitolo(String osservazioniTitolo) {
		this.osservazioniTitolo = osservazioniTitolo;
	}
	public String getOsservazioneUno() {
		return osservazioneUno;
	}
	public void setOsservazioneUno(String osservazioneUno) {
		this.osservazioneUno = osservazioneUno;
	}
	public String getOsservazioneDue() {
		return osservazioneDue;
	}
	public void setOsservazioneDue(String osservazioneDue) {
		this.osservazioneDue = osservazioneDue;
	}
	public String getOsservazioneTre() {
		return osservazioneTre;
	}
	public void setOsservazioneTre(String osservazioneTre) {
		this.osservazioneTre = osservazioneTre;
	}
	public String[] getListaHelp() {
		return listaHelp;
	}
	public void setListaHelp(String[] listaHelp) {
		this.listaHelp = listaHelp;
	}
	public int getRowBlock() {
		return rowBlock;
	}
	public void setRowBlock(int rowBlock) {
		this.rowBlock = rowBlock;
	}
	public int getRowIniBlock() {
		return rowIniBlock;
	}
	public void setRowIniBlock(int rowIniBlock) {
		this.rowIniBlock = rowIniBlock;
	}
	public int getRowFinBlock() {
		return rowFinBlock;
	}
	public void setRowFinBlock(int rowFinBlock) {
		this.rowFinBlock = rowFinBlock;
	}
	public int getRowNumerUltimo() {
		return rowNumerUltimo;
	}
	public void setRowNumerUltimo(int rowNumerUltimo) {
		this.rowNumerUltimo = rowNumerUltimo;
	}
	public int getNumeroCandidati() {
		return numeroCandidati;
	}
	public void setNumeroCandidati(int numeroCandidati) {
		this.numeroCandidati = numeroCandidati;
	}
	public int getNumeroPatine() {
		return numeroPatine;
	}
	public void setNumeroPatine(int numeroPatine) {
		this.numeroPatine = numeroPatine;
	}
	public String getTotaleCandidatiPag() {
		return totaleCandidatiPag;
	}
	public void setTotaleCandidatiPag(String totaleCandidatiPag) {
		this.totaleCandidatiPag = totaleCandidatiPag;
	}
	public int getTotaleCandidatiInt() {
		return totaleCandidatiInt;
	}
	public void setTotaleCandidatiInt(int totaleCandidatiInt) {
		this.totaleCandidatiInt = totaleCandidatiInt;
	}
	public int getTotalePagine() {
		return totalePagine;
	}
	public void setTotalePagine(int totalePagine) {
		this.totalePagine = totalePagine;
	}
	public int getPaginaCorrente() {
		return paginaCorrente;
	}
	public void setPaginaCorrente(int paginaCorrente) {
		this.paginaCorrente = paginaCorrente;
	}
	public String getPulsantePagIndietro() {
		return pulsantePagIndietro;
	}
	public void setPulsantePagIndietro(String pulsantePagIndietro) {
		this.pulsantePagIndietro = pulsantePagIndietro;
	}
	public String getPulsantePagAvanti() {
		return pulsantePagAvanti;
	}
	public void setPulsantePagAvanti(String pulsantePagAvanti) {
		this.pulsantePagAvanti = pulsantePagAvanti;
	}
	public String getOsservazioneQuattro() {
		return osservazioneQuattro;
	}
	public void setOsservazioneQuattro(String osservazioneQuattro) {
		this.osservazioneQuattro = osservazioneQuattro;
	}
	public String getOsservazioneCinque() {
		return osservazioneCinque;
	}
	public void setOsservazioneCinque(String osservazioneCinque) {
		this.osservazioneCinque = osservazioneCinque;
	}
	public String getDocumentazionePervenuta() {
		return documentazionePervenuta;
	}
	public void setDocumentazionePervenuta(String documentazionePervenuta) {
		this.documentazionePervenuta = documentazionePervenuta;
	}
	public String getDocumentazionePrevista() {
		return documentazionePrevista;
	}
	public void setDocumentazionePrevista(String documentazionePrevista) {
		this.documentazionePrevista = documentazionePrevista;
	}
	public String getRichiestaCambioPEC() {
		return richiestaCambioPEC;
	}
	public void setRichiestaCambioPEC(String richiestaCambioPEC) {
		this.richiestaCambioPEC = richiestaCambioPEC;
	}
	public String getDisabledAmmesso() {
		return disabledAmmesso;
	}
	public void setDisabledAmmesso(String disabledAmmesso) {
		this.disabledAmmesso = disabledAmmesso;
	}
	
}