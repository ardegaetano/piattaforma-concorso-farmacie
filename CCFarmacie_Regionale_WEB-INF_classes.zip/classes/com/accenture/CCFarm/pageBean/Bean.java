package com.accenture.CCFarm.pageBean;


import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class Bean 
{	
	private String text;
	
	public List<String> complete(String query) 
	{		
		 List<String> results = new ArrayList<String>();			
			
		 for (int i = 0; i < 10; i++)				 
		 {
			 results.add(query + i);
		 }	
		 
		 
		 return results;
	}

	public String getText() {
		System.out.println("getText");
		return text;
	}

	public void setText(String text) {
		this.text = text;
		System.out.println("setText");
	}	
}
