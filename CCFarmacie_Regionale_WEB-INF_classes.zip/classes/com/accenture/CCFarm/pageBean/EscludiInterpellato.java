package com.accenture.CCFarm.pageBean;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.component.confirmdialog.ConfirmDialog;

import com.accenture.CCFarm.Bean.DatiUtenza;
import com.accenture.CCFarm.Bean.RegioneSelect;
import com.accenture.CCFarm.action.EscludiInterpellatoService;
import com.accenture.CCFarm.action.GestioneUtenzeAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;

@ManagedBean(name="escludiInterpellato")
@ViewScoped
public class EscludiInterpellato {

	
	private static final Logger logger = CommonLogger.getLogger("GestioneUtenzeBean");
	private static final String pageError = "errorPage.jsf";
	
	//filtri di ricerca credenziali
	DatiUtenza datiUtenza;
	
	private List<DatiUtenza> datiInterpellato;
	private boolean datiInterpellatoTrovati;
	private EscludiInterpellatoService escludiInterpellatoService;
	private List<RegioneSelect> regioniSelect;
	private String regioneSelezionata="";
	private String idCandidaturaSelezionata;
	
	//campi cambio indirizzo PEC
	private String idUtente;
	private String indirizzoPecOriginale;
	private String vecchioIndirizzoPec;
	private String nuovoIndirizzoPec;
	private String confermaNuovoIndirizzoPec;
	private String emailOriginale;
	private boolean bUtenteMds;
	UtenteRegioni utente ;
	private ConfirmDialog dialogEscludiInterpellato;
	
	public EscludiInterpellato() throws GestioneErroriException {
	
		try {
			init();
		}
		catch(Exception e) {
			
			logger.error("GestioneUtenzeBean - costruzione del bean fallita", e);
			throw new GestioneErroriException("GestioneUtenzeBean - costruzione del bean fallita");
		}
	}
	
	public void init() throws GestioneErroriException {  
    	
		HttpSession session = (HttpSession) JSFUtility.getFacesContext().getExternalContext().getSession(false);
		utente = (UtenteRegioni) session.getAttribute(RepositorySession.UTENTE_NSIS);
		datiUtenza = new DatiUtenza();
		if(utente.getCodRegione().equalsIgnoreCase("MDS")){
			setRegioniSelect(Localita.getRegioni());
			setbUtenteMds(true);
			setRegioneSelezionata("-1");
		}
		else {
			datiUtenza.setCodRegione(utente.getCodRegione());
			setbUtenteMds(false);
			setRegioneSelezionata("");
		}

		escludiInterpellatoService = new EscludiInterpellatoService();
	}
	
	//ricerca tutte le credenziali che possono corrispondere ai criteri impostati
	//NOTA: codice regione selezionato da cartina come filtro di ricerca impicito
	public void ricercaInterpellato() {
		
		try {
			String sMsgWarning = checkFiltri(isbUtenteMds());
			
			if(sMsgWarning == null){
				if(isbUtenteMds())
					datiUtenza.setCodRegione(getRegioneSelezionata());
				
				List<DatiUtenza> interpellato = escludiInterpellatoService.ricercaUtenteInterpellato(datiUtenza);
				setDatiInterpellato(interpellato);
				setDatiInterpellatoTrovati(true);
			}
			else 
				JSFUtility.addWarningMessage("", sMsgWarning);
		}
		catch(Exception e) {
			logger.error("GestioneUtenzeBean - ricerca credenziali fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void escludiInterpellato() {
		
		try {
			if(!idCandidaturaSelezionata.equals("")){
				boolean esclusioneAvvenuta = escludiInterpellatoService.escludiUtenteInterpellato(datiUtenza,idCandidaturaSelezionata, utente.getUserId());
				idCandidaturaSelezionata ="";
				if(esclusioneAvvenuta){
					JSFUtility.addInfoMessage("", "Esclusione avvenuta correttamente");
				}else{
					JSFUtility.redirect(pageError);
				}
			}	    
		}
		catch(Exception e) {
			logger.error("GestioneUtenzeBean - Esclusione interpellato fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	
	private String checkFiltri(boolean bUtenteMds) throws GestioneErroriException {
		
		String sRet = null;
		if(bUtenteMds){
			if(getRegioneSelezionata()==null || getRegioneSelezionata().equalsIgnoreCase("") || getRegioneSelezionata().equalsIgnoreCase("-1"))
				sRet = "Inserire la Regione specifica";
		}
		else if ((datiUtenza.getCodiceFiscale()==null || datiUtenza.getCodiceFiscale().equalsIgnoreCase("")) &&
				(datiUtenza.getnProtocollo()==null || datiUtenza.getnProtocollo().equalsIgnoreCase("")))
				sRet = "Inserire almeno un filtro di ricerca";
		return sRet;
	}
	
	public DatiUtenza getDatiUtenza() {
		return datiUtenza;
	}

	public void setDatiUtenza(DatiUtenza datiUtenza) {
		this.datiUtenza = datiUtenza;
	}

	public List<DatiUtenza> getDatiInterpellato() {
		return datiInterpellato;
	}

	public void setDatiInterpellato(List<DatiUtenza> datiInterpellato) {
		this.datiInterpellato = datiInterpellato;
	}

	public boolean isDatiInterpellatoTrovati() {
		return datiInterpellatoTrovati;
	}

	public void setDatiInterpellatoTrovati(boolean datiInterpellatoTrovati) {
		this.datiInterpellatoTrovati = datiInterpellatoTrovati;
	}

	public String getVecchioIndirizzoPec() {
		return vecchioIndirizzoPec;
	}

	public void setVecchioIndirizzoPec(String vecchioIndirizzoPec) {
		this.vecchioIndirizzoPec = vecchioIndirizzoPec;
	}

	public String getNuovoIndirizzoPec() {
		return nuovoIndirizzoPec;
	}

	public void setNuovoIndirizzoPec(String nuovoIndirizzoPec) {
		this.nuovoIndirizzoPec = nuovoIndirizzoPec;
	}

	public String getConfermaNuovoIndirizzoPec() {
		return confermaNuovoIndirizzoPec;
	}

	public void setConfermaNuovoIndirizzoPec(String confermaNuovoIndirizzoPec) {
		this.confermaNuovoIndirizzoPec = confermaNuovoIndirizzoPec;
	}

	public String getIndirizzoPecOriginale() {
		return indirizzoPecOriginale;
	}

	public void setIndirizzoPecOriginale(String indirizzoPecOriginale) {
		this.indirizzoPecOriginale = indirizzoPecOriginale;
	}

	public String getEmailOriginale() {
		return emailOriginale;
	}

	public void setEmailOriginale(String emailOriginale) {
		this.emailOriginale = emailOriginale;
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public List<RegioneSelect> getRegioniSelect() {
		return regioniSelect;
	}

	public void setRegioniSelect(List<RegioneSelect> regioniSelect) {
		this.regioniSelect = regioniSelect;
	}

	public boolean isbUtenteMds() {
		return bUtenteMds;
	}

	public void setbUtenteMds(boolean bUtenteMds) {
		this.bUtenteMds = bUtenteMds;
	}

	public String getRegioneSelezionata() {
		return regioneSelezionata;
	}

	public void setRegioneSelezionata(String regioneSelezionata) {
		this.regioneSelezionata = regioneSelezionata;
	}


	public ConfirmDialog getDialogEscludiInterpellato() {
		return dialogEscludiInterpellato;
	}

	public void setDialogEscludiInterpellato(ConfirmDialog dialogEscludiInterpellato) {
		this.dialogEscludiInterpellato = dialogEscludiInterpellato;
	}

	public void dialogEscludiInterpellato()
	{
		Map<String,String> requestParameters = JSFUtility.getFacesContext().getExternalContext().getRequestParameterMap();
	    idCandidaturaSelezionata = requestParameters.get("idCandidaturaSelezionata");
		JSFUtility.executeScript("dialogEscludiInterpellato.show()");
		JSFUtility.update("dialogEscludiInterpellato");

	}
}
