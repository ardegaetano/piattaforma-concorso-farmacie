package com.accenture.CCFarm.pageBean;

import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.CandidatoSedeAssegnataListBean;
import com.accenture.CCFarm.action.GestioneAssegnazioniAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.UtenteRegioni;

@ManagedBean
@ViewScoped
public class GestioneAssegnazioni
{	
	private Logger logger = CommonLogger.getLogger("CalcolaAbbinamentoAutomatico");
	private final static String pageError = "errorPage.jsf";
	private final static String pageHome ="homeRegioni.jsf";
	AppProperties paramProperties = AppProperties.getAppProperties();
	String sVero = paramProperties.getProperty("flag.valore.vero");
	String sFalso = paramProperties.getProperty("flag.valore.falso");
	private String tabDaVisualizzare="0";
	private String disabilitaTabElaboraAssegnazioni = sVero;
	private String disabilitaTabConfiguraAccettazione = sVero;
	private String disabilitaTabGestisciAccettazioni = sVero;
	
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
    UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	String cod_reg = utenteReg.getCodRegione();
	private GestioneAssegnazioniAction gestioneAssegnazioniAction;
	private static final int numeroGiorniPostInterpelloPerAccettazione  = Integer.parseInt(AppProperties.getAppProperties().getProperty("numero.giorni.dopo.interpello.per.accettazione"));
	private static final int numeroGiorniValiditaAccettazione   = Integer.parseInt(AppProperties.getAppProperties().getProperty("numero.giorni.validita.accettazione"));
	private static final int orarioInizioValiditaAccettazione  = Integer.parseInt(AppProperties.getAppProperties().getProperty("orario.inizio.validita.accettazione"));
	private static final int orarioTermineValiditaAccettazione  = Integer.parseInt(AppProperties.getAppProperties().getProperty("orario.termine.validita.accettazione"));
	
	private String descrInterpello;
	//TAB 1
	private String flagEsitoAbbinamento;
	private String[]listaHelp;
	private String descrizione="";
	private String esitoAbbinamento="";
	private String pulsantePrenotaAbbinamento= sVero;
	private String pulsanteRefresh= sVero;
	
	//TAB 2
	private List<CandidatoSedeAssegnataListBean> sediAssegnateList;
	private String nCandidatiTotAssegnazione;
	private String nCandidatiConSedeAssegnata;
	private String nCandidatiSenzaSedeAssegnata;
	private Date minDataInizioAccettazione;
	private Date dataInizioAccettazione;
	private String dataInizioAccettazioneString;
	private Date minDataFineAccettazione;
	private Date dataFineAccettazione;
	private String dataFineAccettazioneString;
	
	//TAB 3
	private List<CandidatoSedeAssegnataListBean> sediAccettateList;
	private String nCandidatiTotAccettazione;
	private String nCandidatiConSedeAccettata;
	private String nCandidatiSenzaSede;
	
	public GestioneAssegnazioni() 
	{
		try {
			init();
		}
		catch(GestioneErroriException e) {
			logger.error("GestioneAssegnazioni - costruzione del bean fallita", e);
			JSFUtility.redirect(pageError);
		}
	}	
	
	public void init() throws GestioneErroriException
	{
		
		gestioneAssegnazioniAction = new GestioneAssegnazioniAction();
		gestioneAssegnazioniAction.init(cod_reg, this);
		
		//Elabora Assegnazioni
		if(getDisabilitaTabElaboraAssegnazioni().equals(sFalso)) {
			String[] array_app = checkElaborazione();
			elaboraAssegnazioni(array_app);
		}
		
		//Accettazione Sedi
		if(getDisabilitaTabConfiguraAccettazione().equals(sFalso)) {
			List<CandidatoSedeAssegnataListBean> listaCandidati = gestioneAssegnazioniAction.caricaListaCandidatiSediAbbinate();
			setnCandidatiTotAssegnazione(Integer.toString(listaCandidati.size()));
			setSediAssegnateList(listaCandidati);
			setnCandidatiConSedeAssegnata(gestioneAssegnazioniAction.getNumCandidatiConSedeAssegnata());
			setnCandidatiSenzaSedeAssegnata(gestioneAssegnazioniAction.getNumCandidatiSenzaSedeAssegnata());
			setMinDataInizioAccettazione(DateUtil.getDataEstremoIntervallo(new Date(), numeroGiorniPostInterpelloPerAccettazione, 0));
			setMinDataFineAccettazione(DateUtil.getDataEstremoIntervallo(new Date(), numeroGiorniPostInterpelloPerAccettazione, 0));
		}
		
		//Gestisci Accettazioni
		if(getDisabilitaTabGestisciAccettazioni().equals(sFalso)) {
			List<CandidatoSedeAssegnataListBean> listaCandidati = gestioneAssegnazioniAction.caricaListaCandidatiSediAccettate();
			setnCandidatiTotAccettazione(Integer.toString(listaCandidati.size()));
			setSediAccettateList(listaCandidati);
			setnCandidatiConSedeAccettata(gestioneAssegnazioniAction.getNumCandidatiConSedeAccettata());
			setnCandidatiSenzaSedeAccettata(gestioneAssegnazioniAction.getNumCandidatiSenzaSede());
		}
	}
	
	
	//METODI TAB 1
	
	public void refreshElaborazione() {
		try {
			init();
		}
		catch(GestioneErroriException e) {
			logger.error("GestioneAssegnazioni - refreshElaborazione - errore", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void abbinaSedi() throws GestioneErroriException {
		
		//Esecuzione Thread di Abbinamento automatico
		gestioneAssegnazioniAction.avviaProcessoAssegnazione(cod_reg);
		
		setEsitoAbbinamento("L'assegnazione automatica delle Sedi � in esecuzione.");
		setPulsantePrenotaAbbinamento(sFalso);
		setPulsanteRefresh(sVero);
		JSFUtility.update("elaboraAssegnazioni");
		
	}
	
	//METODI TAB 2
	
	//data inizio valida s.s.e. segue quella odierna di un numero di giorni pari al preavviso stabilito
	private boolean dataInizioAccettazioneValida() {
		
		return getDataInizioAccettazione() != null &&
			   DateUtil.calcolaDifferenzaDate(DateUtil.dataOdierna(), getDataInizioAccettazione()) >= numeroGiorniPostInterpelloPerAccettazione;
	}
	
	private boolean dataFineAccettazioneValida() {

		return getDataInizioAccettazione() != null &&
				getDataFineAccettazione() != null &&
			   DateUtil.calcolaDifferenzaDate(getDataInizioAccettazione(), getDataFineAccettazione()) == numeroGiorniValiditaAccettazione;
	}
	
	private boolean validaDati() {
		
		boolean datiInseriti = dataInizioAccettazione != null &&
				   			   dataFineAccettazione != null;
		
		if(!datiInseriti) {
			
			JSFUtility.addWarningMessage("Attenzione", "E' necessario inserire entrambe le date per la fase di accettazione");
		}
		
		boolean dataInizioAccettazioneValida = dataInizioAccettazioneValida();
		if(datiInseriti && !dataInizioAccettazioneValida) {
			
			JSFUtility.addWarningMessage("Attenzione", "Tra la data odierna e quella di inizio accettazione devono intercorrere almeno " + numeroGiorniPostInterpelloPerAccettazione + " giorni");
		}
		
		boolean dataFineAccettazioneValida = dataFineAccettazioneValida();
		if(datiInseriti && !dataFineAccettazioneValida) {
			
			JSFUtility.addWarningMessage("Attenzione", "Tra la data di inizio e la data di fine accettazione devono intercorrere " + numeroGiorniValiditaAccettazione + " giorni");
		}
		
		return datiInseriti && dataInizioAccettazioneValida && dataFineAccettazioneValida;
	}
	
	public void salvaDatiAccettazione() {
		
		try {
			
			if(validaDati()) {
				
				//imposta l'orario per la data inizio accettazione
				setDataInizioAccettazione(
					DateUtil.setOrarioData(getDataInizioAccettazione(), orarioInizioValiditaAccettazione)
				);
				
				//imposta l'orario per la data fine accettazione
				setDataFineAccettazione(
					DateUtil.setOrarioData(getDataFineAccettazione(), orarioTermineValiditaAccettazione)
				);
				
				gestioneAssegnazioniAction.salvaAccettazione(dataInizioAccettazione, dataFineAccettazione);
				JSFUtility.addInfoMessage("", "Dati Accettazione salvati con successo");
			}
		}
		catch(GestioneErroriException e) {
			logger.error("GestioneAssegnazioni - salvataggio dati accettazione fallito", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public void pubblicaDatiAccettazione() {
		
		try {
			
			if(validaDati()) {
				
				//imposta l'orario per la data inizio accettazione
				setDataInizioAccettazione(
					DateUtil.setOrarioData(getDataInizioAccettazione(), orarioInizioValiditaAccettazione)
				);
				
				//imposta l'orario per la data fine accettazione
				setDataFineAccettazione(
					DateUtil.setOrarioData(getDataFineAccettazione(), orarioTermineValiditaAccettazione)
				);
				
				gestioneAssegnazioniAction.pubblicaAccettazione(dataInizioAccettazione, dataFineAccettazione);
				JSFUtility.addInfoMessage("", "Accettazione avviata con successo");
			}
		}
		catch(GestioneErroriException e) {
			logger.error("GestioneAssegnazioni - pubblicazione dati accettazione fallito", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public boolean isAccettazionePubblicata() {
		try {
			return gestioneAssegnazioniAction.isAccettazionePubblicata();
		}
		catch(GestioneErroriException e) {
			logger.error("GestioneAssegnazioni - isAccettazionePubblicata fallito", e);
			return false;
		}
	}
	
	public void dataInizioAccettazioneCambiata(AjaxBehaviorEvent event) {
		
		setDataFineAccettazione(DateUtil.getDataEstremoIntervallo(getDataInizioAccettazione(), numeroGiorniValiditaAccettazione, orarioTermineValiditaAccettazione));
	}
	
	//METODI TAB 3
	
	public void chiudiInterpello() {
		try {
			gestioneAssegnazioniAction.chiudiInterpello();
			//JSFUtility.addInfoMessage("", "Interpello chiuso con successo");
			JSFUtility.redirect(pageHome);
		}
		catch(GestioneErroriException e) {
			logger.error("GestioneAssegnazioni - chiusura interpello fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	
	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public String getEsitoAbbinamento() {
		return esitoAbbinamento;
	}

	public void setEsitoAbbinamento(String esitoAbbinamento) {
		this.esitoAbbinamento = esitoAbbinamento;
	}

	public String getPulsantePrenotaAbbinamento() {
		return pulsantePrenotaAbbinamento;
	}

	public void setPulsantePrenotaAbbinamento(String pulsantePrenotaAbbinamento) {
		this.pulsantePrenotaAbbinamento = pulsantePrenotaAbbinamento;
	}

	public String getPulsanteRefresh() {
		return pulsanteRefresh;
	}

	public void setPulsanteRefresh(String pulsanteRefresh) {
		this.pulsanteRefresh = pulsanteRefresh;
	}

	public String[] getListaHelp() {
		return listaHelp;
	}

	public void setListaHelp(String[] listaHelp) {
		this.listaHelp = listaHelp;
	}

	public List<CandidatoSedeAssegnataListBean> getSediAssegnateList() {
		return sediAssegnateList;
	}

	public void setSediAssegnateList(
			List<CandidatoSedeAssegnataListBean> sediAssegnateList) {
		this.sediAssegnateList = sediAssegnateList;
	}

	public String getTabDaVisualizzare() {
		return tabDaVisualizzare;
	}

	public void setTabDaVisualizzare(String tabDaVisualizzare) {
		this.tabDaVisualizzare = tabDaVisualizzare;
	}

	public String getDisabilitaTabElaboraAssegnazioni() {
		return disabilitaTabElaboraAssegnazioni;
	}

	public void setDisabilitaTabElaboraAssegnazioni(
			String disabilitaTabElaboraAssegnazioni) {
		this.disabilitaTabElaboraAssegnazioni = disabilitaTabElaboraAssegnazioni;
	}

	public String getDisabilitaTabConfiguraAccettazione() {
		return disabilitaTabConfiguraAccettazione;
	}

	public void setDisabilitaTabConfiguraAccettazione(
			String disabilitaTabConfiguraAccettazione) {
		this.disabilitaTabConfiguraAccettazione = disabilitaTabConfiguraAccettazione;
	}

	public String getDisabilitaTabGestisciAccettazioni() {
		return disabilitaTabGestisciAccettazioni;
	}

	public void setDisabilitaTabGestisciAccettazioni(
			String disabilitaTabGestisciAccettazioni) {
		this.disabilitaTabGestisciAccettazioni = disabilitaTabGestisciAccettazioni;
	}

	public String getnCandidatiConSedeAssegnata() {
		return nCandidatiConSedeAssegnata;
	}

	public void setnCandidatiConSedeAssegnata(String nCandidatiConSedeAssegnata) {
		this.nCandidatiConSedeAssegnata = nCandidatiConSedeAssegnata;
	}

	public String getnCandidatiSenzaSedeAssegnata() {
		return nCandidatiSenzaSedeAssegnata;
	}

	public void setnCandidatiSenzaSedeAssegnata(String nCandidatiSenzaSedeAssegnata) {
		this.nCandidatiSenzaSedeAssegnata = nCandidatiSenzaSedeAssegnata;
	}

	public Date getDataInizioAccettazione() {
		return dataInizioAccettazione;
	}

	public void setDataInizioAccettazione(Date dataInizioAccettazione) {
		if(dataInizioAccettazione == null)
			setDataInizioAccettazioneString(null);
		else
			setDataInizioAccettazioneString(StringUtil.dateToStringDDMMYYYY(dataInizioAccettazione));
		this.dataInizioAccettazione = dataInizioAccettazione;
	}

	public String getDataInizioAccettazioneString() {
		return dataInizioAccettazioneString;
	}

	public void setDataInizioAccettazioneString(String dataInizioAccettazioneString) {
		this.dataInizioAccettazioneString = dataInizioAccettazioneString;
	}

	public Date getMinDataFineAccettazione() {
		return minDataFineAccettazione;
	}

	public void setMinDataFineAccettazione(Date minDataFineAccettazione) {
		this.minDataFineAccettazione = minDataFineAccettazione;
	}

	public Date getDataFineAccettazione() {
		return dataFineAccettazione;
	}

	public void setDataFineAccettazione(Date dataFineAccettazione) {
		if(dataFineAccettazione == null)
			setDataFineAccettazioneString(null);
		else
			setDataFineAccettazioneString(StringUtil.dateToStringDDMMYYYY(dataFineAccettazione));
		this.dataFineAccettazione = dataFineAccettazione;
	}
	
	public String getDataFineAccettazioneString() {
		return dataFineAccettazioneString;
	}

	public void setDataFineAccettazioneString(String dataFineAccettazioneString) {
		this.dataFineAccettazioneString = dataFineAccettazioneString;
	}

	public String getFlagEsitoAbbinamento() {
		return flagEsitoAbbinamento;
	}

	public void setFlagEsitoAbbinamento(String flagEsitoAbbinamento) {
		this.flagEsitoAbbinamento = flagEsitoAbbinamento;
	}

	public Date getMinDataInizioAccettazione() {
		return minDataInizioAccettazione;
	}

	public void setMinDataInizioAccettazione(Date minDataInizioAccettazione) {
		this.minDataInizioAccettazione = minDataInizioAccettazione;
	}

	public String getDescrInterpello() {
		return descrInterpello;
	}

	public void setDescrInterpello(String descrInterpello) {
		this.descrInterpello = descrInterpello;
	}

	public List<CandidatoSedeAssegnataListBean> getSediAccettateList() {
		return sediAccettateList;
	}

	public void setSediAccettateList(
			List<CandidatoSedeAssegnataListBean> sediAccettateList) {
		this.sediAccettateList = sediAccettateList;
	}

	public String getnCandidatiConSedeAccettata() {
		return nCandidatiConSedeAccettata;
	}

	public void setnCandidatiConSedeAccettata(String nCandidatiConSedeAccettata) {
		this.nCandidatiConSedeAccettata = nCandidatiConSedeAccettata;
	}

	public String getnCandidatiSenzaSede() {
		return nCandidatiSenzaSede;
	}

	public void setnCandidatiSenzaSedeAccettata(String nCandidatiSenzaSede) {
		this.nCandidatiSenzaSede = nCandidatiSenzaSede;
	}

	
	public String getnCandidatiTotAssegnazione() {
		return nCandidatiTotAssegnazione;
	}

	public void setnCandidatiTotAssegnazione(String nCandidatiTotAssegnazione) {
		this.nCandidatiTotAssegnazione = nCandidatiTotAssegnazione;
	}

	public String getnCandidatiTotAccettazione() {
		return nCandidatiTotAccettazione;
	}

	public void setnCandidatiTotAccettazione(String nCandidatiTotAccettazione) {
		this.nCandidatiTotAccettazione = nCandidatiTotAccettazione;
	}

	private String[] checkElaborazione()throws GestioneErroriException{
			
	    String[] messaggi=new String[4];
		String abilita_btnPrenota="";
		String abilita_btnRefresh="";
		String descrizione="";
		String esito_calcolo="";
		
		try{
			String flagEsAbbinamento = getFlagEsitoAbbinamento();
			
			descrizione="Per schedulare il processo di assegnazione delle sedi premere il pulsante \"Predisponi Assegnazioni\".";
			
			if (flagEsAbbinamento==null){
				abilita_btnPrenota=sVero;
				abilita_btnRefresh=sFalso;
				esito_calcolo="";
			}
			else if (flagEsAbbinamento!=null && flagEsAbbinamento.equals(paramProperties.getProperty("esito.abbinamento.sedi.avviato")))
			{
				abilita_btnPrenota=sFalso;
				abilita_btnRefresh=sVero;
				esito_calcolo="L'assegnazione automatica delle Sedi � in esecuzione.";
			}
			else if (flagEsAbbinamento!=null && flagEsAbbinamento.equals(paramProperties.getProperty("esito.abbinamento.sedi.terminato")))
			{
				abilita_btnPrenota=sFalso;
				abilita_btnRefresh=sFalso;
				esito_calcolo="Assegnazione eseguita con successo.";
			}
			else if (flagEsAbbinamento!=null && flagEsAbbinamento.equals(paramProperties.getProperty("esito.abbinamento.sedi.errore")))
			{
				abilita_btnPrenota=sVero;
				abilita_btnRefresh=sFalso;
				esito_calcolo="Assegnazione eseguita con errori.";
			}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new GestioneErroriException("errore nell'abbinamento sedi");
		}
			
		messaggi[0]=descrizione;
		messaggi[1]=esito_calcolo;
		messaggi[2]=abilita_btnPrenota;
		messaggi[3]=abilita_btnRefresh;
		
		return messaggi;
	}
	
	private void elaboraAssegnazioni(String[] array_app) throws GestioneErroriException {
		
		setListaHelp(Help.caricaHelpCalcoloAbbinamento());
		setDescrizione(array_app[0]);
		setEsitoAbbinamento(array_app[1]);
		setPulsantePrenotaAbbinamento(array_app[2]);
		setPulsanteRefresh(array_app[3]);
		JSFUtility.update("formAssegnazioni");
	}
	
}