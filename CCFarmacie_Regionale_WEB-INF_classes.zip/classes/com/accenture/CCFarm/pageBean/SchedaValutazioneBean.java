package com.accenture.CCFarm.pageBean;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.log4j.Logger;
import org.primefaces.component.tabview.Tab;
import org.primefaces.model.LazyDataModel;

import com.accenture.CCFarm.Bean.GraduatoriaLazyList;
import com.accenture.CCFarm.Bean.UtenteEspProf;
import com.accenture.CCFarm.Bean.UtenteOsservazioni;
import com.accenture.CCFarm.Bean.UtenteTitoli;
import com.accenture.CCFarm.DAO.AltraLaureaBisReg;
import com.accenture.CCFarm.DAO.AltraLaureaReg;
import com.accenture.CCFarm.DAO.AltroTitoloReg;
import com.accenture.CCFarm.DAO.BorsaStudioReg;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoReg;
import com.accenture.CCFarm.DAO.DottoratoReg;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.IdoneitaReg;
import com.accenture.CCFarm.DAO.PubblicazioneReg;
import com.accenture.CCFarm.DAO.RequisitiMinimiReg;
import com.accenture.CCFarm.DAO.SpecializzazioneReg;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.action.CalcoloTitoliAction;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;

@ManagedBean
@SessionScoped
public class SchedaValutazioneBean {

	private final static String pageError = "errorPage.jsf";

	private CalcoloTitoliAction calcoloTitoliAction;

	private String totale[];

	private String titoli[];

	private String risultato;

	private String idCandidatura;

	private List<UtenteCandidaturaReg> utenteCandidaturaList;

	private List<UtenteOsservazioni> utenteOsservazioniList;

	private LazyDataModel<Graduatoria> graduatorie;

	private String totaleTitoli;

	private String totaleEspProf;

	private String totaleScheda;

	private String nomeUtente;

	private String note;

	private String idUtente;

	private String codReg;

	private Logger logger = CommonLogger.getLogger("SchedaValutazioneBean");

	private String color[];

	private Boolean azzeraAltraLaurea;

	private Boolean azzeraAltraLaureaBis;

	private Boolean azzeraIdoneita;

	private Boolean azzeraIdoneitaNaz;

	SimpleDateFormat data;

	private String anteprima;

	private List<UtenteTitoli> utenteTitoliList;

	private List<UtenteEspProf> utenteEspProfList;

	private List<RequisitiMinimiReg> requisitiMinimiRegList;

	private List<PubblicazioneReg> pubblicazioniRegList;

	private List<AltraLaureaReg> altraLaureaReg;

	private List<SpecializzazioneReg> specializzazioniRegList;

	private List<DottoratoReg> dottoratoReglist;

	private List<BorsaStudioReg> borsaStudioRegList;

	private List<CorsoAggiornamentoReg> corsoAggiornamentoRegList;

	private List<AltroTitoloReg> altroTitoloRegList;

	private List<AltraLaureaBisReg> altraLaureaBisRegList;

	private List<IdoneitaReg> idoneitaRegList;

	public SchedaValutazioneBean() {
		try {
			this.setAnteprima("F");
			// graduatorieList = new GraduatoriaLazyList();
			totale = new String[8];

		}catch (Exception e) {
			logger.error("Eccezione in SchedaValutazioneBean - costruttore: "
					+ LogUtil.printException(e));
		}
	}

	public void init() {
		try

		{
			calcoloTitoliAction = new CalcoloTitoliAction();
			calcoloTitoliAction.calcolaTitoli(this);
			calcoloTitoliAction.calcolaEspProf(this);
			calcoloTitoliAction.recuperaOsservazioni(this);
			
		} catch (GestioneErroriException e) {
			logger.error("Eccezione in SchedaValutazioneBean - init: "
					+ LogUtil.printException(e));
		}
	}

	public void aggiornaPunteggi() {
		try {
			calcoloTitoliAction.aggiornaTitoli(this);
		} catch (GestioneErroriException e) {
			logger.error("Eccezione in SchedaValutazioneBean - aggiornaPunteggi: "
					+ LogUtil.printException(e));
		}
	}

	public void aggiornaScheda() {
		JSFUtility.update("elencoTitoli");
		JSFUtility.update("espProfTable");
		JSFUtility.update("totale");
		JSFUtility.update("note");
	}

	public List<UtenteTitoli> getUtenteTitoliList() {
		return utenteTitoliList;
	}

	public void setUtenteTitoliList(List<UtenteTitoli> utenteTitoliList) {
		this.utenteTitoliList = utenteTitoliList;
	}

	public String[] getTitoli() {
		return titoli;
	}

	public void setTitoli(String[] titoli) {
		this.titoli = titoli;
	}

	public String[] getTotale() {
		return totale;
	}

	public String[] getColor() {
		return color;
	}

	public void setColor(String[] color) {
		this.color = color;
	}

	public Boolean getAzzeraAltraLaurea() {
		return azzeraAltraLaurea;
	}

	public void setAzzeraAltraLaurea(Boolean azzeraAltraLaurea) {
		this.azzeraAltraLaurea = azzeraAltraLaurea;
	}

	public Boolean getAzzeraAltraLaureaBis() {
		return azzeraAltraLaureaBis;
	}

	public void setAzzeraAltraLaureaBis(Boolean azzeraAltraLaureaBis) {
		this.azzeraAltraLaureaBis = azzeraAltraLaureaBis;
	}

	public Boolean getAzzeraIdoneita() {
		return azzeraIdoneita;
	}

	public void setAzzeraIdoneita(Boolean azzeraIdoneita) {
		this.azzeraIdoneita = azzeraIdoneita;
	}

	public Boolean getAzzeraIdoneitaNaz() {
		return azzeraIdoneitaNaz;
	}

	public void setAzzeraIdoneitaNaz(Boolean azzeraIdoneitaNaz) {
		this.azzeraIdoneitaNaz = azzeraIdoneitaNaz;
	}

	public LazyDataModel<Graduatoria> getGraduatorie() {
		return graduatorie;
	}

	public void setGraduatorie(LazyDataModel<Graduatoria> graduatorie) {
		this.graduatorie = graduatorie;
	}

	public void setTotale(String[] totale) {
		this.totale = totale;
	}

	public String getAnteprima() {
		return anteprima;
	}

	public void setAnteprima(String anteprima) {
		this.anteprima = anteprima;
	}

	public List<AltroTitoloReg> getAltroTitoloRegList() {
		return altroTitoloRegList;
	}

	public void setAltroTitoloRegList(List<AltroTitoloReg> altroTitoloRegList) {
		this.altroTitoloRegList = altroTitoloRegList;
	}

	public List<CorsoAggiornamentoReg> getCorsoAggiornamentoRegList() {
		return corsoAggiornamentoRegList;
	}

	public void setCorsoAggiornamentoRegList(
			List<CorsoAggiornamentoReg> corsoAggiornamentoRegList) {
		this.corsoAggiornamentoRegList = corsoAggiornamentoRegList;
	}

	public String getTotaleTitoli() {
		return totaleTitoli;
	}

	public void setTotaleTitoli(String totaleTitoli) {
		this.totaleTitoli = totaleTitoli;
	}

	public String getIdCandidatura() {
		return idCandidatura;
	}

	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}

	public List<UtenteCandidaturaReg> getUtenteCandidaturaList() {
		return utenteCandidaturaList;
	}

	public void setUtenteCandidaturaList(List<UtenteCandidaturaReg> utenteCandidaturaList) {
		this.utenteCandidaturaList = utenteCandidaturaList;
	}

	public List<UtenteEspProf> getUtenteEspProfList() {
		return utenteEspProfList;
	}

	public void setUtenteEspProfList(List<UtenteEspProf> utenteEspProfList) {
		this.utenteEspProfList = utenteEspProfList;
	}

	public String getRisultato() {
		return risultato;
	}

	public void setRisultato(String risultato) {
		this.risultato = risultato;
	}

	public String getTotaleEspProf() {
		return totaleEspProf;
	}

	public void setTotaleEspProf(String totaleEspProf) {
		this.totaleEspProf = totaleEspProf;
	}

	public String getNomeUtente() {
		return nomeUtente;
	}

	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}

	public List<UtenteOsservazioni> getUtenteOsservazioniList() {
		return utenteOsservazioniList;
	}

	public void setUtenteOsservazioniList(List<UtenteOsservazioni> utenteOsservazioniList) {
		this.utenteOsservazioniList = utenteOsservazioniList;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public String getCodReg() {
		return codReg;
	}

	public void setCodReg(String codReg) {
		this.codReg = codReg;
	}

	public List<RequisitiMinimiReg> getRequisitiMinimiRegList() {
		return requisitiMinimiRegList;
	}

	public void setRequisitiMinimiRegList(List<RequisitiMinimiReg> requisitiMinimiRegList) {
		this.requisitiMinimiRegList = requisitiMinimiRegList;
	}

	public List<DottoratoReg> getDottoratoReglist() {
		return dottoratoReglist;
	}

	public void setDottoratoReglist(List<DottoratoReg> dottoratoReglist) {
		this.dottoratoReglist = dottoratoReglist;
	}

	public List<BorsaStudioReg> getBorsaStudioRegList() {
		return borsaStudioRegList;
	}

	public void setBorsaStudioRegList(List<BorsaStudioReg> borsaStudioRegList) {
		this.borsaStudioRegList = borsaStudioRegList;
	}

	public List<PubblicazioneReg> getPubblicazioniRegList() {
		return pubblicazioniRegList;
	}

	public void setPubblicazioniRegList(List<PubblicazioneReg> pubblicazioniRegList) {
		this.pubblicazioniRegList = pubblicazioniRegList;
	}

	public List<AltraLaureaReg> getAltraLaureaReg() {
		return altraLaureaReg;
	}

	public void setAltraLaureaReg(List<AltraLaureaReg> altraLaureaReg) {
		this.altraLaureaReg = altraLaureaReg;
	}

	public List<AltraLaureaBisReg> getAltraLaureaBisRegList() {
		return altraLaureaBisRegList;
	}

	public void setAltraLaureaBisRegList(List<AltraLaureaBisReg> altraLaureaBisRegList) {
		this.altraLaureaBisRegList = altraLaureaBisRegList;
	}

	public List<IdoneitaReg> getIdoneitaRegList() {
		return idoneitaRegList;
	}

	public void setIdoneitaRegList(List<IdoneitaReg> idoneitaRegList) {
		this.idoneitaRegList = idoneitaRegList;
	}

	public List<SpecializzazioneReg> getSpecializzazioniRegList() {
		return specializzazioniRegList;
	}

	public void setSpecializzazioniRegList(List<SpecializzazioneReg> specializzazioniRegList) {
		this.specializzazioniRegList = specializzazioniRegList;
	}

	public String getTotaleScheda() {

		BigDecimal tot = new BigDecimal(0);

		tot = tot.add(new BigDecimal(this.totaleTitoli.replace(",", "."))).add(
				new BigDecimal(this.totaleEspProf.replace(",", ".")));
		if (tot.compareTo(new BigDecimal("50.0000")) > 0) {
			tot = new BigDecimal("50.0000");
		}
		this.totaleScheda = tot.toString().replace(".", ",");
		return totaleScheda;
	}

	public void setTotaleScheda(String totaleScheda) {
		this.totaleScheda = totaleScheda;
	}

	public void selectedTitolo() {

		try {

			Map<String, String> params = JSFUtility.getFacesContext()
					.getExternalContext().getRequestParameterMap();

			idUtente = params.get("idUtente");

			GetSessionUtility.setSessionAttribute(RepositorySession.ID_UTENTE,
					idUtente);
			for (UtenteTitoli utenteTitoli : utenteTitoliList) {
				if (utenteTitoli.getUtente().getIdUtente().equals(idUtente)) {
					this.setNomeUtente(utenteTitoli.getUtente().getNomeUtente()
							+ " " + utenteTitoli.getUtente().getCognomeUtente());
				}
			}

			data = new SimpleDateFormat("dd-MM-yyyy");
			int livelloTitolo = Integer.parseInt(params.get("livelloTitolo"));

			switch (livelloTitolo) {

			case 0:

				// Laurea principale
				this.setRequisitiMinimiRegList(new ArrayList<RequisitiMinimiReg>());
				for (UtenteTitoli utenteTitoli : utenteTitoliList) {
					if (utenteTitoli.getUtente().getIdUtente().equals(idUtente)) {

						for (RequisitiMinimiReg r : utenteTitoli.getTitoli()
								.getRequisitiMinimiReg()) {
							if (r.getPunteggioLaurea() != null)
								r.setPunteggioLaureaString(r
										.getPunteggioLaurea().toString()
										.replace(".", ","));
						}

						this.setRequisitiMinimiRegList(utenteTitoli.getTitoli()
								.getRequisitiMinimiReg());

					}
				}
				// this.requisitiMinimi = true;
				JSFUtility.update("RequisitiMinimiRegDlg");
				JSFUtility.executeScript("RequisitiMinimiRegDialog.show()");

				break;

			case 1:

				// Seconda laurea
				this.setAltraLaureaReg(new ArrayList<AltraLaureaReg>());
				this.setAzzeraAltraLaurea(false);
				for (UtenteTitoli utenteTitoli : utenteTitoliList) {
					if (utenteTitoli.getUtente().getIdUtente().equals(idUtente)) {

						if (utenteTitoli.getTitoli().getAltraLaureaReg() != null) {
							if (utenteTitoli.getTitoli().parzialeTitolo[1]
									.equals("0")) {
								this.setAzzeraAltraLaurea(true);
							}
							this.setAltraLaureaReg(utenteTitoli.getTitoli()
									.getAltraLaureaReg());
						}

					}
				}

				JSFUtility.update("AltraLaureaRegDlg");
				JSFUtility.executeScript("AltraLaureaRegDialog.show()");
				break;

			case 2:
				this.setAltraLaureaBisRegList(new ArrayList<AltraLaureaBisReg>());
				this.setAzzeraAltraLaureaBis(false);
				for (UtenteTitoli utenteTitoli : utenteTitoliList) {

					if (utenteTitoli.getUtente().getIdUtente().equals(idUtente)) {
						if (utenteTitoli.getTitoli().parzialeTitolo[2]
								.equals("0")) {
							this.setAzzeraAltraLaureaBis(true);
						}
						if (utenteTitoli.getTitoli().getAltraLaureaBisReg() != null) {
							this.setAltraLaureaBisRegList(utenteTitoli
									.getTitoli().getAltraLaureaBisReg());
						}

					}
				}

				JSFUtility.update("AltraLaureaBisRegDlg");
				JSFUtility.executeScript("AltraLaureaBisRegDialog.show()");

				break;

			case 3:

				this.setSpecializzazioniRegList(new ArrayList<SpecializzazioneReg>());
				this.setBorsaStudioRegList(new ArrayList<BorsaStudioReg>());
				for (UtenteTitoli utenteTitoli : utenteTitoliList) {
					if (utenteTitoli.getUtente().getIdUtente().equals(idUtente)) {

						if (utenteTitoli.getTitoli().getSpecializzazioneReg() != null
								&& utenteTitoli.getTitoli()
										.getSpecializzazioneReg().size() > 0) {
							this.setSpecializzazioniRegList(utenteTitoli
									.getTitoli().getSpecializzazioneReg());
							for (SpecializzazioneReg r : utenteTitoli
									.getTitoli().getSpecializzazioneReg()) {
								r.setPunteggioString(r.getPunteggio() == null ? "0"
										: r.getPunteggio().toString()
												.replace(".", ","));

							}
						}

						if (utenteTitoli.getTitoli().getBorsaStudioReg() != null
								&& utenteTitoli.getTitoli().getBorsaStudioReg()
										.size() > 0) {
							this.setBorsaStudioRegList(utenteTitoli.getTitoli()
									.getBorsaStudioReg());
							for (BorsaStudioReg r : utenteTitoli.getTitoli()
									.getBorsaStudioReg()) {
								if (r.getDataInizioBorsa() != null) {
									String dta1 = data.format(r
											.getDataInizioBorsa());
									r.setDataInizioBorsaString(dta1);
								} else {
									r.setDataInizioBorsaString("");
								}
								if (r.getDataFineBorsa() != null) {
									String dta2 = data.format(r
											.getDataFineBorsa());

									r.setDataFineBorsaString(dta2);
								} else {
									r.setDataFineBorsaString("");
								}

								r.setPunteggioString(r.getPunteggio() == null ? "0"
										: r.getPunteggio().toString()
												.replace(".", ","));

							}
						}

					}
				}

				JSFUtility.update("specBorsDotDlg");
				JSFUtility.executeScript("specBorsDotDialog.show()");
				break;

			case 4:
				this.setPubblicazioniRegList(new ArrayList<PubblicazioneReg>());
				for (UtenteTitoli utenteTitoli : utenteTitoliList) {
					if (utenteTitoli.getUtente().getIdUtente().equals(idUtente)) {
						if (utenteTitoli.getTitoli().getPubblicazioneReg() != null) {
							for (PubblicazioneReg r : utenteTitoli.getTitoli()
									.getPubblicazioneReg()) {

								if (r.getDataPubblicazione() != null) {
									String dta = data.format(r
											.getDataPubblicazione());
									r.setDataPubblicazioneString(dta);

								} else {
									r.setDataPubblicazioneString("");
								}
								r.setPunteggioString(r.getPunteggio() == null ? "0"
										: r.getPunteggio().toString()
												.replace(".", ","));

							}

							if (utenteTitoli.getTitoli().getPubblicazioneReg() != null
									&& utenteTitoli.getTitoli()
											.getPubblicazioneReg().size() > 0) {
								this.setPubblicazioniRegList(utenteTitoli
										.getTitoli().getPubblicazioneReg());
							}
						}

					}
				}

				JSFUtility.update("PubblicazioniRegDlg");
				JSFUtility.executeScript("PubblicazioniRegDialog.show()");
				break;

			case 5:
				// Idoneita
				this.setIdoneitaRegList(new ArrayList<IdoneitaReg>());
				this.setAzzeraIdoneita(false);
				for (UtenteTitoli utenteTitoli : utenteTitoliList) {

					if (utenteTitoli.getUtente().getIdUtente().equals(idUtente)) {
						if (utenteTitoli.getTitoli().getIdoneitaReg() != null) {
							if (utenteTitoli.getTitoli().parzialeTitolo[5]
									.equals("0")) {
								this.setAzzeraIdoneita(true);
							}
							data = new SimpleDateFormat("dd-MM-yyyy");
							for (IdoneitaReg i : utenteTitoli.getTitoli()
									.getIdoneitaReg()) {
								if (i.getDataIdoneita() != null) {
									String dta = data.format(i
											.getDataIdoneita());
									i.setData(dta);
								} else {
									i.setData("");
								}

							}

							if (utenteTitoli.getTitoli().getIdoneitaReg() != null
									&& utenteTitoli.getTitoli()
											.getIdoneitaReg().size() > 0) {
								this.setIdoneitaRegList(utenteTitoli
										.getTitoli().getIdoneitaReg());
							}

						}

					}
				}
				JSFUtility.update("IdoneitaRegDlg");
				JSFUtility.executeScript("IdoneitaRegDialog.show()");
				break;

			case 6:
				// Idoneita Nazionale
				this.setIdoneitaRegList(new ArrayList<IdoneitaReg>());
				this.setAzzeraIdoneitaNaz(false);
				for (UtenteTitoli utenteTitoli : utenteTitoliList) {
					if (utenteTitoli.getUtente().getIdUtente().equals(idUtente)) {
						if (utenteTitoli.getTitoli().getIdoneitaReg() != null) {
							this.setIdoneitaRegList(utenteTitoli.getTitoli()
									.getIdoneitaReg());
							if (utenteTitoli.getTitoli().parzialeTitolo[6]
									.equals("0")) {
								this.setAzzeraIdoneitaNaz(true);
							}
						}

					}
				}
				JSFUtility.update("IdoneitaRegNazDlg");
				JSFUtility.executeScript("IdoneitaRegNazDlgDialog.show()");
				break;

			case 7:

				this.setRequisitiMinimiRegList(new ArrayList<RequisitiMinimiReg>());
				this.setCorsoAggiornamentoRegList(new ArrayList<CorsoAggiornamentoReg>());
				for (UtenteTitoli utenteTitoli : utenteTitoliList) {
					if (utenteTitoli.getUtente().getIdUtente().equals(idUtente)) {

						if (utenteTitoli.getTitoli().getRequisitiMinimiReg() != null) {
							this.setRequisitiMinimiRegList(utenteTitoli
									.getTitoli().getRequisitiMinimiReg());
							for (RequisitiMinimiReg r : utenteTitoli
									.getTitoli().getRequisitiMinimiReg()) {
								r.setPunteggioAbilitazioneString(r
										.getPunteggioAbilitazione() == null ? "0"
										: r.getPunteggioAbilitazione()
												.toString().replace(".", ","));

							}
						}
						if (utenteTitoli.getTitoli().getCorsoAggiornamentoReg() != null
								&& utenteTitoli.getTitoli()
										.getCorsoAggiornamentoReg().size() > 0) {
							this.setCorsoAggiornamentoRegList(utenteTitoli
									.getTitoli().getCorsoAggiornamentoReg());
							for (CorsoAggiornamentoReg r : utenteTitoli
									.getTitoli().getCorsoAggiornamentoReg()) {

								if (r.getDataInizioCorsoAgg() != null) {
									String dta1 = data.format(r
											.getDataInizioCorsoAgg());
									r.setDataInizioCorsoAggString(dta1);
								} else {
									r.setDataInizioCorsoAggString("");
								}
								if (r.getDataFineCorsoAgg() != null) {
									String dta2 = data.format(r
											.getDataFineCorsoAgg() == null ? ""
											: r.getDataFineCorsoAgg());
									r.setDataFineCorsoAggString(dta2);
								} else {
									r.setDataFineCorsoAggString("");
								}

								r.setPunteggioString(r.getPunteggio() == null ? "0"
										: r.getPunteggio().toString()
												.replace(".", ","));

							}
						}
					}
				}

				JSFUtility.update("votoCorsiAltriDlg");
				JSFUtility.executeScript("votoCorsiAltriDialog.show()");

				break;

			case 8:
				this.setAltroTitoloRegList(new ArrayList<AltroTitoloReg>());
				this.setDottoratoReglist(new ArrayList<DottoratoReg>());
				for (UtenteTitoli utenteTitoli : utenteTitoliList) {
					if (utenteTitoli.getUtente().getIdUtente().equals(idUtente)) {
						if (utenteTitoli.getTitoli().getAltroTitoloReg() != null
								&& utenteTitoli.getTitoli().getAltroTitoloReg()
										.size() > 0) {

							for (AltroTitoloReg r : utenteTitoli.getTitoli()
									.getAltroTitoloReg()) {

								if (r.getDataRilascioAltroTitolo() != null) {
									String dta1 = data.format(r
											.getDataRilascioAltroTitolo());
									r.setDataRilascioAltroTitoloString(dta1);

								} else {
									r.setDataRilascioAltroTitoloString("");
								}

								r.setPunteggioString(r.getPunteggio() == null ? "0"
										: r.getPunteggio().toString()
												.replace(".", ","));

							}
							this.setAltroTitoloRegList(utenteTitoli.getTitoli()
									.getAltroTitoloReg());
						}
						if (utenteTitoli.getTitoli().getDottoratoReg() != null
								&& utenteTitoli.getTitoli().getDottoratoReg()
										.size() > 0) {
							for (DottoratoReg r : utenteTitoli.getTitoli()
									.getDottoratoReg()) {
								if (r.getDataInizioDottorato() != null) {
									String dta1 = data.format(r
											.getDataInizioDottorato());
									r.setDataInizioDottoratoString(dta1);
								} else {
									r.setDataInizioDottoratoString("");
								}

								if (r.getDataFineDottorato() != null) {
									String dta2 = data.format(r
											.getDataFineDottorato());

									r.setDataFineDottoratoString(dta2);
								} else {
									r.setDataFineDottoratoString("");
								}

								r.setPunteggioString(r.getPunteggio() == null ? "0"
										: r.getPunteggio().toString()
												.replace(".", ","));

							}

							this.setDottoratoReglist(utenteTitoli.getTitoli()
									.getDottoratoReg());
						}

					}
				}
				JSFUtility.update("votoAltriDlg");
				JSFUtility.executeScript("votoAltriDialog.show()");

				break;
			}
		} catch (Exception e) {
			logger.error("Eccezione in SchedaValutazioneBean - selectedTitolo: "
					+ LogUtil.printException(e));
			JSFUtility.addWarningMessage("",
					"impossibile visualizzare il dettaglio");
			JSFUtility.scrollTo("msgs");
			e.printStackTrace();
		}
	}

	public void updateLaurea() {
		aggiornaPunteggi();
		aggiornaScheda();
		JSFUtility.update("RequisitiMinimiRegDlg");
		JSFUtility.executeScript("RequisitiMinimiRegDialog.hide()");

	}

	public void updatePubblicazioni() {
		aggiornaPunteggi();
		aggiornaScheda();
		JSFUtility.update("PubblicazioniRegDlg");
		JSFUtility.executeScript("PubblicazioniRegDialog.hide()");
	}

	public void updateSpecBorsDot() {

		aggiornaPunteggi();

		aggiornaScheda();
		JSFUtility.update("specBorsDotDlg");
		JSFUtility.executeScript("specBorsDotDialog.hide()");
	}

	public void updateVotoCorsiAltri() {

		aggiornaPunteggi();

		aggiornaScheda();
		JSFUtility.update("votoCorsiAltriDlg");
		JSFUtility.executeScript("votoCorsiAltriDialog.hide()");

	}

	public void updateVotoAltri() {

		JSFUtility.executeScript("votoAltriDialog.hide()");
		aggiornaPunteggi();

		aggiornaScheda();

	}

	public void resetAltraLaurea() {
		for (UtenteTitoli utenteTitoli : utenteTitoliList) {
			if (utenteTitoli.getUtente().getIdUtente()
					.equals(GetSessionUtility.getSessionAttribute("ID_UTENTE"))) {
				utenteTitoli
						.getTitoli()
						.getAltraLaureaReg()
						.get(0)
						.setPunteggio(
								this.getAzzeraAltraLaurea() ? new BigDecimal(0)
										: new BigDecimal("1.5"));
			}
		}

		aggiornaPunteggi();
		aggiornaScheda();

	}

	public void resetAltraLaureaBis() {
		for (UtenteTitoli utenteTitoli : utenteTitoliList) {
			if (utenteTitoli.getUtente().getIdUtente()
					.equals(GetSessionUtility.getSessionAttribute("ID_UTENTE"))) {
				for (AltraLaureaBisReg altraLaureaBisReg : utenteTitoli
						.getTitoli().getAltraLaureaBisReg()) {
					altraLaureaBisReg.setPunteggio(this
							.getAzzeraAltraLaureaBis() ? new BigDecimal(0)
							: new BigDecimal("3.5"));
				}
			}
		}
		aggiornaPunteggi();
		aggiornaScheda();

	}

	public void resetIdoneita() {

		for (UtenteTitoli utenteTitoli : utenteTitoliList) {
			if (utenteTitoli.getUtente().getIdUtente()
					.equals(GetSessionUtility.getSessionAttribute("ID_UTENTE"))) {
				for (IdoneitaReg idoneitaReg : utenteTitoli.getTitoli()
						.getIdoneitaReg()) {
					idoneitaReg
							.setPunteggio(this.getAzzeraIdoneita() ? new BigDecimal(
									0) : new BigDecimal("1"));
				}
			}
		}

		aggiornaPunteggi();
		aggiornaScheda();

	}

	public void resetIdoneitaNaz() {

		for (UtenteTitoli utenteTitoli : utenteTitoliList) {
			if (utenteTitoli.getUtente().getIdUtente()
					.equals(GetSessionUtility.getSessionAttribute("ID_UTENTE"))) {
				for (IdoneitaReg idoneitaReg : utenteTitoli.getTitoli()
						.getIdoneitaReg()) {
					idoneitaReg
							.setPunteggioNaz(this.getAzzeraIdoneitaNaz() ? new BigDecimal(
									0) : new BigDecimal("1"));
				}
			}
		}
		aggiornaPunteggi();
		aggiornaScheda();
	}

	public void selectedEspProf() {

		Map<String, String> params = JSFUtility.getFacesContext()
				.getExternalContext().getRequestParameterMap();
		String idUtente = params.get("idUtente");

		for (UtenteEspProf u : utenteEspProfList) {
			if (u.getUtente().getIdUtente().equals(idUtente)) {
				this.setNomeUtente(u.getUtente().getNomeUtente()+" "+u.getUtente().getCognomeUtente());
				setRisultato(u.getRisultati());

				break;
			}

		}

		apriDialogEspProf();
	}

	public void chiudiDialogTitoli(javax.faces.event.ActionEvent event) {
		JSFUtility.update("titoloDlg");
		JSFUtility.executeScript("titoloDialog.hide()");
	}

	public void apriDialogEspProf() {
		JSFUtility.update("espProfDlg");
		JSFUtility.executeScript("espProfDialog.show()");
	}

	public String updateGraduatoria() throws GestioneErroriException {
		try {
			
			//Controllo che l'utente non sia escluso
			CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
		    if(candidaturaRegHome.isCandidaturaEsclusa(candidaturaRegHome.findById(idCandidatura))) {
		    	JSFUtility.addWarningMessage("Operazione non consentita:", "la candidatura risulta esclusa");
		    	JSFUtility.scrollTo("msgs");
		    }
		    else {
				UtenteRegioni utenteReg = (UtenteRegioni) GetSessionUtility.getSessionAttribute(RepositorySession.UTENTE_NSIS);
				String userLoggato = utenteReg.getUserId();
				
				GetSessionUtility.setSessionAttribute(RepositorySession.ID_UTENTE,
						idCandidatura);
				ElaboraGraduatoria elaboraGraduatoria = (ElaboraGraduatoria) GetSessionUtility
						.getSessionAttribute("elaboraGraduatoria");
				elaboraGraduatoria.setAbilitaTabGestisciGraduatoria("false");
				calcoloTitoliAction.saveGraduatoria(this, userLoggato);
				Tab tab = (Tab) JSFUtility.findComponent(
						JSFUtility.getUIViewRoot(), "tabGestisciGraduatoria");
				tab.setDisabled(true);
				JSFUtility.update("viewsGraduatoria");
				init();
				JSFUtility.update("viewsGraduatoria");
				JSFUtility.addInfoMessage("", "Salvataggio avvenuto con successo");
				JSFUtility.scrollTo("msgs");
				
		    }
		    return null;
		} catch (GestioneErroriException e) {
			logger.error("Eccezione in SchedaValutazioneBean - updateGraduatoria: "
					+ LogUtil.printException(e));
			return pageError;
		}
	}
	
	public String updateGraduatoriaEStampa() throws GestioneErroriException {
		try {
			
			//Controllo che l'utente non sia escluso
			CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
		    if(candidaturaRegHome.isCandidaturaEsclusa(candidaturaRegHome.findById(idCandidatura))) {
		    	JSFUtility.addWarningMessage("Operazione non consentita:", "la candidatura risulta esclusa");
		    	JSFUtility.scrollTo("msgs");
		    }
		    else {
				UtenteRegioni utenteReg = (UtenteRegioni) GetSessionUtility.getSessionAttribute(RepositorySession.UTENTE_NSIS);
				String userLoggato = utenteReg.getUserId();
				
				GetSessionUtility.setSessionAttribute(RepositorySession.ID_UTENTE,
						idCandidatura);
				ElaboraGraduatoria elaboraGraduatoria = (ElaboraGraduatoria) GetSessionUtility
						.getSessionAttribute("elaboraGraduatoria");
				elaboraGraduatoria.setAbilitaTabGestisciGraduatoria("false");
				calcoloTitoliAction.saveGraduatoria(this, userLoggato);
				Tab tab = (Tab) JSFUtility.findComponent(
						JSFUtility.getUIViewRoot(), "tabGestisciGraduatoria");
				tab.setDisabled(true);
				JSFUtility.update("viewsGraduatoria");
				init();
				JSFUtility.update("viewsGraduatoria");
				JSFUtility.addInfoMessage("", "Salvataggio avvenuto con successo");
				JSFUtility.scrollTo("msgs");
				//Stampa
				JSFUtility.redirect("../StampaValutazioneCandidaturaPDFServlet"); 
		    }
		    return null;
		} catch (GestioneErroriException e) {
			logger.error("Eccezione in SchedaValutazioneBean - updateGraduatoriaEStampa: "
					+ LogUtil.printException(e));
			return pageError;
		}
	}

	public LazyDataModel<Graduatoria> getGraduatorieList()
			throws GestioneErroriException {

		try {
			if (this.anteprima.equalsIgnoreCase("T")) {
				graduatorie = new GraduatoriaLazyList();
				this.setAnteprima("F");
			}
		} catch (Exception e) {
			logger.error("Eccezione in SchedaValutazioneBean - updateGraduatoria: "
					+ LogUtil.printException(e));
			JSFUtility.addWarningMessage("",
					"Errore durante la visualizzazione della graduatoria");
			JSFUtility.scrollTo("msgs");

		}
		return graduatorie;

	}

	public void viewGraduatoria() throws GestioneErroriException {

		this.setAnteprima("T");
		JSFUtility.update("graduatoriaDialog");
		JSFUtility.executeScript("graduatoriaDialog.show()");
	}

}
