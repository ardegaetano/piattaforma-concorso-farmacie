package com.accenture.CCFarm.thread;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.AnagraficaFarmInterpelli;
import com.accenture.CCFarm.DAO.AnagraficaFarmInterpelliHome;
import com.accenture.CCFarm.DAO.CandidaturaReg;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.CandidaturaSedi;
import com.accenture.CCFarm.DAO.CandidaturaSediHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;

public class ThreadAssegnazioniAutomatiche extends Thread {

	private static final Logger log = CommonLogger.getLogger("ThreadAssegnazioniAutomatiche");
	private static AppProperties paramProperties = AppProperties.getAppProperties();
	private String codRegione = null;
	
	public ThreadAssegnazioniAutomatiche(String codRegione) {
		this.codRegione = codRegione;
	}

	@SuppressWarnings("unchecked")
	public void run() {

		log.info("Inizio Elaborazione ThreadAssegnazioniAutomatiche");
		
		DatiBandoHome datiBandoHome = null;
		DatiBando datiBando = null;
		
		try {		
			datiBandoHome = new DatiBandoHome();
			datiBando = datiBandoHome.findById(codRegione);
			
			//IMPOSTA IL FLAG ABBINAMENTO SEDI "AVVIATO"
			datiBando.setFlagAbbinamentoSedi(paramProperties.getProperty("esito.abbinamento.sedi.avviato"));
			datiBandoHome.saveOrUpdate(datiBando);
			
				
			//Recupero Interpello valido
			InterpelloHome interpelloHome = new InterpelloHome();
			Interpello interpello = interpelloHome.determinaInterpelloCorrente(codRegione);
				
			//DATA SISTEMA > A DATA FINE INTERPELLO
			if(interpello!=null && interpello.getStato().equals(paramProperties.getProperty("codice.interpello.pubblicato")) && 
				DateUtil.calcolaDifferenzaDate(DateUtil.sqlTimestampToUtilDate((Timestamp)interpello.getDataFine()), new Date()) >= 0 ) {
			
				String idInterpello = interpello.getId().getIdInterpello().toString();
					
				//Recupero la lista delle sedi a disposizione
				AnagraficaFarmInterpelliHome anagFarmInterpelliHome = new AnagraficaFarmInterpelliHome();
				List<AnagraficaFarmInterpelli> listaFarmacie = (List<AnagraficaFarmInterpelli>) anagFarmInterpelliHome.getSediByInterpello(codRegione, new BigDecimal(idInterpello));
				if(listaFarmacie.size()>0) {
					//Mappa IDFARMACIA - IDCANDIDATURA inizializzazione della chiave
					HashMap<String, CandidaturaSedi> assegnazione = impostalistaFarmacieMappa(listaFarmacie);
					
					//Recupero la lista degli utenti che hanno espresso le preferenze
					GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
					
					List<Graduatoria> listaCandidati = (List<Graduatoria>) graduatoriaHome.getUtentiByInterpello(codRegione, new BigDecimal(idInterpello));
					
					if(listaCandidati != null) {
						for( int s=0; s<listaCandidati.size(); s++){
							Graduatoria graduatoria = listaCandidati.get(s);
							//Verifica che il candidato abbia fatto la scelta
							CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
							CandidaturaReg candidatura = candidaturaRegHome.findById(graduatoria.getIdCandidatura());
							if(candidatura!=null && candidatura.getFlagSceltaSedi()!=null && candidatura.getFlagSceltaSedi().equals("true")) {
								//Completa la mappa con CandidaturaSedi
								String idSedeAssegnata = setSceltaFarmacia(assegnazione, graduatoria.getIdCandidatura());
								log.info("ID Candidatura: " + graduatoria.getIdCandidatura() +" - Sede Assegnata: "+idSedeAssegnata+". ");
							}
						}
						//Salvataggio Candidatura Sedi
						ArrayList<CandidaturaSedi> lista = new ArrayList<CandidaturaSedi>();
						lista.addAll(assegnazione.values());
						CandidaturaSediHome candidaturaSediHome = new CandidaturaSediHome();
						candidaturaSediHome.associaCandidati(lista);
					}
					else
						log.error("Regione: "+codRegione+" - Interpello: "+idInterpello+" - Lista candidati non presente");
				}
				else
					log.error("Regione: "+codRegione+" - Interpello: "+idInterpello+" - Lista farmacie non presente");
			}
			
			//IMPOSTA IL FLAG ABBINAMENTO SEDI "TERMINATO"
			datiBando.setFlagAbbinamentoSedi(paramProperties.getProperty("esito.abbinamento.sedi.terminato"));
			datiBandoHome.saveOrUpdate(datiBando);
			
		}
		catch(Exception e) {
			//IMPOSTA IL FLAG ABBINAMENTO SEDI "ERRORE"
			datiBando.setFlagAbbinamentoSedi(paramProperties.getProperty("esito.abbinamento.sedi.errore"));
			try {
				datiBandoHome.saveOrUpdate(datiBando);
			}
			catch(GestioneErroriException ex) {
				log.error("Errore durante l'elaborazione di assegnazione sedi", ex);
				throw new NullPointerException();
			}	
			log.error("Errore durante l'elaborazione di assegnazione sedi", e);
			throw new NullPointerException();
		}
		log.info("Fine Elaborazione ThreadAssegnazioniAutomatiche");
		
	}	
	
	private HashMap<String, CandidaturaSedi> impostalistaFarmacieMappa(List<AnagraficaFarmInterpelli> listaFarm) {
	
		HashMap<String, CandidaturaSedi> mappa = new HashMap<String, CandidaturaSedi>();
		for( int i=0; i<listaFarm.size(); i++){
			AnagraficaFarmInterpelli anagFarmInterpelli = listaFarm.get(i);
			mappa.put(anagFarmInterpelli.getId().getIdFarm(), null);
		}
		return mappa;
	}
	
	private String setSceltaFarmacia(HashMap<String, CandidaturaSedi> assegnazione, String idCandidatura) throws Exception {
		
		String idSede = null;
		CandidaturaSediHome candidaturaSediHome = new CandidaturaSediHome();
		
		List<CandidaturaSedi> listaSedi = (List<CandidaturaSedi>) candidaturaSediHome.getPreferenzeScelte(idCandidatura);
		
		if(listaSedi!=null) {
			for(int i = 0; i < listaSedi.size(); i++) {
				
				CandidaturaSedi sedeScelta = listaSedi.get(i);
				
				if(sedeScelta != null && 
				   sedeScelta.getId() != null &&
				   assegnazione.get(sedeScelta.getId().getIdFarm()) == null) {
					
					idSede = sedeScelta.getId().getIdFarm();
					assegnazione.put(idSede, sedeScelta);
					
					break;
				}
			}
		}
		return idSede;
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		new ThreadAssegnazioniAutomatiche("090").start();
    }

}
