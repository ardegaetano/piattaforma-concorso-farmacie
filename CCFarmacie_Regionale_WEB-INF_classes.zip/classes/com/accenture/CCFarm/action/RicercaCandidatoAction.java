package com.accenture.CCFarm.action;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.accenture.CCFarm.Bean.RicevutaBean;
import com.accenture.CCFarm.Bean.UtenteBean;
import com.accenture.CCFarm.Bean.UtenteCandidatureBean;
import com.accenture.CCFarm.DAO.CandidaturaReg;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutivaReg;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutivaRegHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.UtenteRegHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.RicercaCandidati;
import com.accenture.CCFarm.pageBean.StampaCandidatiBean;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.DateUtil;


public class RicercaCandidatoAction{
	
    //Logger logger = CommonLogger.getLogger("RicercaCandidatoAction");
    String pageError = "errorPage.jsf";
    private static String tipoRicevuta_Domanda = "DD";
	private static String tipoRicevuta_SceltaSedi = "SS";
	private static String tipoRicevuta_AccettaRinunciaSede = "ARS";
	AppProperties paramProperties = AppProperties.getAppProperties();
	private static final String flagValoreVero  = AppProperties.getAppProperties().getProperty("flag.valore.vero");

	public RicercaCandidatoAction(){
		
	}
	
	public List<UtenteBean> ricercaCandidati(RicercaCandidati ricercaCandidato) throws GestioneErroriException {
	    	UtenteRegHome utenteHome=new UtenteRegHome();
	    	
	    	List<UtenteBean> utentiList = new ArrayList<UtenteBean>();
			
	    	utentiList = utenteHome.findByFilter(ricercaCandidato);
			
			return utentiList ;
	}

	public List<UtenteCandidatureBean> ricercaCandidature(RicercaCandidati ricercaCandidato) throws GestioneErroriException {
    	UtenteRegHome utenteHome=new UtenteRegHome();
    	
    	List<UtenteCandidatureBean> utentiList = new ArrayList<UtenteCandidatureBean>();
		
    	utentiList = utenteHome.findByFilterCandidatura(ricercaCandidato);
		
		return utentiList ;
	}

	public List<String> ricercaCandidaturePaginataID(RicercaCandidati ricercaCandidato) throws GestioneErroriException {
    	UtenteRegHome utenteHome=new UtenteRegHome();
    	
//    	List<UtenteCandidatureBean> utentiList = new ArrayList<UtenteCandidatureBean>();
//		
//    	utentiList = utenteHome.findByFilterCandidatura(ricercaCandidato);
//		
    	List<String> utentiList = new ArrayList<String>();
		
    	utentiList = utenteHome.findByFilterCandidaturaPaginataID(ricercaCandidato);
		
		return utentiList ;
	}
	
	public List<UtenteCandidatureBean> ricercaCandidaturePaginataList(RicercaCandidati ricercaCandidato) throws GestioneErroriException {
//    	UtenteHome utenteHome=new UtenteHome();
//    	
//    	List<UtenteCandidatureBean> utentiList = new ArrayList<UtenteCandidatureBean>();
//		
//    	utentiList = utenteHome.findByFilterCandidatura(ricercaCandidato);
//		
		UtenteRegHome utenteHome=new UtenteRegHome();
    	
		List<UtenteCandidatureBean> utentiList = new ArrayList<UtenteCandidatureBean>();
//		List<UtenteBean> utentiList = new ArrayList<UtenteBean>();
		
    	List<String> listSelectIn = new ArrayList<String>();
		int primo = ricercaCandidato.getRowIniBlock();
    	int ultimo = ricercaCandidato.getRowIniBlock();
    	
    	for (int i = primo; i < ricercaCandidato.getRowFinBlock(); i++) {
			String idCandidato = ricercaCandidato.getListaIDUtenteCand().get(i);
			listSelectIn.add(idCandidato);
			ultimo++;
		}
    	ricercaCandidato.setRowNumerUltimo(ultimo);
    	
    	utentiList = utenteHome.findByFilterCandidaturaPaginataList(ricercaCandidato, listSelectIn);
		
    	
    	
		return utentiList ;
	}
	
	public List ricIdCandidatiAll(StampaCandidatiBean stampaCandidatiBean ) throws GestioneErroriException {
    	UtenteRegHome utenteHome=new UtenteRegHome();
    	
    	List<UtenteBean> utentiList = new ArrayList<UtenteBean>();
		
    	utentiList = utenteHome.findCandiatoAll(stampaCandidatiBean.getUtenteReg().getCodRegione(), "STAMPA_CANDIDATI");
		
		return utentiList ;
	}
	
	public List ricIdCandidatiAll(RicercaCandidati ricercaCandidato) throws GestioneErroriException {
    	UtenteRegHome utenteHome=new UtenteRegHome();
    	
    	List<UtenteBean> utentiList = new ArrayList<UtenteBean>();
		
    	utentiList = utenteHome.findCandiatoAll(ricercaCandidato.getUtenteReg().getCodRegione(), "RICERCA_CANDIDATURE");
		
		
    
    	return utentiList ;
	}
	
	public List<UtenteBean> paginazioneCandidati(StampaCandidatiBean candidati ) throws GestioneErroriException {
    	UtenteRegHome utenteHome=new UtenteRegHome();
    	
    	List<UtenteBean> utentiList = new ArrayList<UtenteBean>();
		
    	List<String> listSelectIn = new ArrayList<String>();
		int primo = candidati.getRowIniBlock();
    	int ultimo = candidati.getRowIniBlock();
    	
    	for (int i = primo; i < candidati.getRowFinBlock(); i++) {
			String idCandidato = candidati.getIdCandidatiList().get(i);
			listSelectIn.add(idCandidato);
			ultimo++;
		}
    	candidati.setRowNumerUltimo(ultimo);
    	
    	utentiList = utenteHome.findPage(candidati.getUtenteReg().getCodRegione(), listSelectIn);
		
		
    	return utentiList ;
	}
	
	public List<UtenteBean> listaCandidatiCSV(String codiceRegione ) throws GestioneErroriException {
    	UtenteRegHome utenteHome=new UtenteRegHome();
    	
    	List<UtenteBean> utentiList = new ArrayList<UtenteBean>();
		
    	utentiList = utenteHome.findListCandidati(codiceRegione);
		
    	return utentiList ;
	}
	
	
	public void salvaCandidatureAmmesse(RicercaCandidati ricercaCandidato) throws GestioneErroriException {
    	
    	CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
    	GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
    	DichiarazioneSostitutivaRegHome dichiarazioneSostitutivaRegHome = new DichiarazioneSostitutivaRegHome();
    	//DatiBandoHome datiBandoHome = new DatiBandoHome();
    	//DatiBando datiBando = datiBandoHome.findById(ricercaCandidato.getCodReg());
    	String ammesso = "";
    	for (int i = 0; i < ricercaCandidato.getListaUtenteCand().size(); i++) {
			CandidaturaReg candidaturaReg = new CandidaturaReg();
			UtenteCandidatureBean utenteCandidatureBean = new UtenteCandidatureBean();
			
			utenteCandidatureBean= ricercaCandidato.getListaUtenteCand().get(i);
			candidaturaReg.setIdCandidatura(utenteCandidatureBean.getIdCandidatura());
			List<CandidaturaReg> listaCandidati= new ArrayList<CandidaturaReg>();
			listaCandidati= candidaturaRegHome.findByExample(candidaturaReg);
//			Verifico se � stato modificato il falg dell'ammissione
			if (utenteCandidatureBean.getAmmessoValore().equalsIgnoreCase("NO") &&  utenteCandidatureBean.isAmmesso()  ||
				utenteCandidatureBean.getAmmessoValore().equalsIgnoreCase("SI") && !utenteCandidatureBean.isAmmesso()  	){
				
				
				if (utenteCandidatureBean.isAmmesso()){
					ammesso = "SI";
					//if(datiBando.)
					Graduatoria graduatoria = new Graduatoria();
					List<Graduatoria> listGraduatoria = graduatoriaHome.findByExample(new Graduatoria(ricercaCandidato.getCodReg()));
					if(!listGraduatoria.isEmpty()){
						graduatoria = graduatoriaHome.findById(ricercaCandidato.getListaIDUtenteCand().get(0));
			        	if(graduatoria==null){
			        		listaCandidati.get(i).setErroreElabAutomatica("T");
			        		
			        	}
					}
		        	
				} else {
					ammesso = "NO";
					
					
				}
				
				
				
				
				candidaturaRegHome.aggiornaAmmissione(listaCandidati, ammesso);
				
			}
			
			
			if (utenteCandidatureBean.getDocumentazionePervenuta().equalsIgnoreCase("NO") ||
					utenteCandidatureBean.getDocumentazionePervenuta().equalsIgnoreCase("SI")){
					
					String docPervenuta = "";
					if (utenteCandidatureBean.getDocumentazionePervenuta().equalsIgnoreCase("NO")){
						docPervenuta = "false";
					} else {
						docPervenuta = "true";
					}
					
					// da modificare
					DichiarazioneSostitutivaReg dichiarazioneSostitutivaReg = new DichiarazioneSostitutivaReg();
					dichiarazioneSostitutivaReg = dichiarazioneSostitutivaRegHome.findById(utenteCandidatureBean.getIdCandidatura());
					dichiarazioneSostitutivaReg.setDocPervenuta(docPervenuta);
					dichiarazioneSostitutivaRegHome.saveOrUpdate(dichiarazioneSostitutivaReg);					
				
				}
			
			
    		
		}
    
    	
//    	return utentiList ;
	}
	

	public List<String> check_protocollo(RicercaCandidati ricercaCandidato) throws GestioneErroriException {
		
		UtenteRegHome utenteRegHome = new UtenteRegHome();
		
		List<String> listaIDUtenteCand = new ArrayList<String>();
		
		listaIDUtenteCand = utenteRegHome.check_protocollo(ricercaCandidato);
		
		return listaIDUtenteCand ;
	}
	
	public List<RicevutaBean> getRicevuteCandidato(String codiceRegione, String idCandidatura) throws GestioneErroriException {
		
		List<RicevutaBean> listaRicevute = new ArrayList<RicevutaBean>();
		RicevuteHome ricevuteHome = new RicevuteHome();
		List<Ricevute> ricevute = ricevuteHome.findRicevuteCandidato(idCandidatura);
		if(ricevute!=null) {
			
			InterpelloHome interpelloHome = new InterpelloHome();
			for (Iterator iterator = ricevute.iterator(); iterator.hasNext();) {
				
				boolean bAddRicevuta=false;
				RicevutaBean ricevuta=new RicevutaBean();
				Ricevute row = (Ricevute) iterator.next(); 
				ricevuta.setIdCandidato(row.getId().getIdCandidatura());
				ricevuta.setIdRicevuta(row.getId().getIdRicevuta());
				String sTipoRicevuta = (row.getId().getTipoRicevuta());
				String sDescr = (sTipoRicevuta!=null ? ((sTipoRicevuta.equals(tipoRicevuta_Domanda)) ? "Scarica Ricevuta Domanda di Partecipazione" : (sTipoRicevuta.equals(tipoRicevuta_SceltaSedi)) ? "Scarica Ricevuta Scelta Sedi" : (sTipoRicevuta.equals(tipoRicevuta_AccettaRinunciaSede)) ? "Scarica Ricevuta Accettazione/Rinuncia Sede" : "" ) : "");
				ricevuta.setDescrizione(sDescr);
				ricevuta.setTipoRicevuta(sTipoRicevuta);
				
				if(sTipoRicevuta.equals(tipoRicevuta_Domanda))
					bAddRicevuta = true;
				else {
					Interpello interpello = interpelloHome.getInterpelloByCandidatura(codiceRegione, idCandidatura);
					//Le ricevute di scelta sedi devono essere scaricabili solo a chiusura della fase di scelta
					if(sTipoRicevuta.equals(tipoRicevuta_SceltaSedi) && (isChiusaFaseInterpello(interpello))) {
						bAddRicevuta = true;
					}
					//Le ricevute di accettazione devono essere scaricabili solo a chiusura della fase di accettazione
					else if(sTipoRicevuta.equals(tipoRicevuta_AccettaRinunciaSede) && (isChiusaFaseAccettazione(interpello))) {
						bAddRicevuta = true;
					}
				}
				
				if(bAddRicevuta)
					listaRicevute.add(ricevuta);
			}
		}
		return listaRicevute;
	}
	
	public String isGraduatoriaElaborata(String codiceRegione) throws GestioneErroriException {
		String ret = "false";
	    DatiBandoHome datiBandoHome = new DatiBandoHome();
		DatiBando datiBando = datiBandoHome.findById(codiceRegione);
		if(datiBando.getFlgScarti()!= null && !datiBando.getFlgScarti().equalsIgnoreCase("true"))
			ret = "true";
		return ret;
	}
	
	//Fase di scelta delle sedi - DATA SISTEMA > A DATA FINE INTERPELLO
	private boolean isChiusaFaseInterpello(Interpello interpello) {
		if(interpello!=null && interpello.getDataFine()!=null &&  new Date().after(DateUtil.utilDateToSqlTimestamp((Timestamp)interpello.getDataFine())))
			return true;
		return false;
	}

	//DATA SISTEMA > A DATA FINE ACCETTAZIONE
	private boolean isChiusaFaseAccettazione(Interpello interpello) {
		if(interpello!=null && interpello.getDataFineAccettazione()!=null &&  new Date().after(DateUtil.utilDateToSqlTimestamp((Timestamp)interpello.getDataFineAccettazione())))
			return true;
		return false;
	}
	
	
}