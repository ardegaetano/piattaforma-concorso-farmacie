package com.accenture.CCFarm.action;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import com.accenture.CCFarm.DAO.CriteriPunteggi;
import com.accenture.CCFarm.DAO.CriteriPunteggiHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.CriteriPunteggiBean;
import com.accenture.CCFarm.pageBean.CriteriPunteggiListBean;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.UtenteRegioni;


public class CriteriPunteggiAction{
	
    Logger logger = CommonLogger.getLogger("CriteriPunteggiAction");
    String pageError = "errorPage.jsf";
    int CONST_TIPO_LAUREA = 1;
    int CONST_TIPO_ABILITAZIONE = 2;
    
    //Voti Laurea DA 66 a 110 e lode
    public static HashMap<Integer, String> mappaVotiLaurea = new HashMap<Integer, String>();
    int lenRecordCSV_Laurea = 46;
    //Voti Abilitazioni DA 60 a 100
    public static HashMap<Integer, String> mappaVotiAbilitazione = new HashMap<Integer, String>();
    int lenRecordCSV_Abilitazione = 41;

	public CriteriPunteggiAction(){}
	
	//Load di Pagina 
    public void loadPaginaInserimento(CriteriPunteggiBean criteriPunteggioBean) throws GestioneErroriException {
    	
    	//RECUPERO DALLA SESSIONE CODICE REGIONE
    	FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	
    	try {
	    	
    		String codRegione = null;
	    	UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	    	
	    	if(utenteReg!=null)
	    	{
	    		logger.info("Utente NSIS recuperato dalla sessione");
	    		codRegione = utenteReg.getCodRegione();
	    		//TIPO PUNTEGGI LAUREA
		    	CriteriPunteggi criteri = new CriteriPunteggi();
		    	CriteriPunteggiHome criteriHome = new CriteriPunteggiHome();
		    	List listaPunteggiLaurea = criteriHome.findByTipoPunteggiLaurea(criteri, codRegione);
			    if(listaPunteggiLaurea.size()>0){
			    	criteriPunteggioBean.setbCaricaCSV_Laurea(true);
			    	criteriPunteggioBean.setMsgErroreCSV_Laurea(null);
			    	List<CriteriPunteggiListBean> listCriteriPunteggiLaurea = popolaListaBeanCriteri(listaPunteggiLaurea, criteriPunteggioBean, GenericConstants.TIPO_PUNTEGGI_LAUREA);
			    	criteriPunteggioBean.setListCriteriPunteggiLaurea(listCriteriPunteggiLaurea);
			    }
			    else { //No record
			    	criteriPunteggioBean.setListCriteriPunteggiLaurea(null);
			    	criteriPunteggioBean.setbCaricaCSV_Laurea(false);
					criteriPunteggioBean.setMsgErroreCSV_Laurea(null);
					criteriPunteggioBean.setbStato(false);
			    }	
			    
			    //TIPO PUNTEGGI ABILITAZIONE
		    	CriteriPunteggi criteriAb = new CriteriPunteggi();
		    	CriteriPunteggiHome criteriHomeAb = new CriteriPunteggiHome();
		    	List listaPunteggiAbilitazione = criteriHomeAb.findByTipoPunteggiAbilitazione(criteriAb, codRegione);
			    if(listaPunteggiAbilitazione.size()>0){
			    	criteriPunteggioBean.setbCaricaCSV_Abilitazione(true);
			    	criteriPunteggioBean.setMsgErroreCSV_Abilitazione(null);
			    	List<CriteriPunteggiListBean> listCriteriPunteggiAbilitazione = popolaListaBeanCriteri(listaPunteggiAbilitazione, criteriPunteggioBean, GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE);
			    	criteriPunteggioBean.setListCriteriPunteggiAbilitazione(listCriteriPunteggiAbilitazione);
			    }
			    else { //No record
			    	criteriPunteggioBean.setListCriteriPunteggiAbilitazione(null);
			    	criteriPunteggioBean.setbCaricaCSV_Abilitazione(false);
			    	criteriPunteggioBean.setMsgErroreCSV_Abilitazione(null);
					criteriPunteggioBean.setbStatoA(false);
			    }	
	    	}
	    	else {
	    		logger.error("Utente NSIS non presente in sessione");
	    		JSFUtility.redirect(pageError);
	    	}
	    
    	} catch (Exception e) {
			logger.error("CriteriPunteggiAction - loadPaginaInserimento: errore nel caricamento dei dati da DB " + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiAction - loadPaginaInserimento: "+e);
			throw eccezione;
    	}
    }
    
    //Effettua il controllo dell'estensione file e crea gli array per la visualizzazione in tabella
    public void uploadCSV(FileUploadEvent event, CriteriPunteggiBean criteriPunteggi, String tipoTitolo) throws GestioneErroriException { 
    	
    	try
		{
    		mappaVotiLaurea.clear();
        	mappaVotiAbilitazione.clear();
        	
    		//Inizializza a Validi i CSV
    		if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) {
    			//criteriPunteggi.setbCSVValido_Laurea(true);
    			criteriPunteggi.setMsgErroreCSV_Laurea(null);
    		} 
    		else if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE)) {
    			//criteriPunteggi.setbCSVValido_Abilitazione(true);	
    			criteriPunteggi.setMsgErroreCSV_Abilitazione(null);
    		} 
    		
    		UploadedFile file = event.getFile();
    		if(file!=null){
    			InputStream is = null;
    			is = file.getInputstream();
				List<CriteriPunteggiListBean> lista = caricaTabellaCSV(is, criteriPunteggi, tipoTitolo);
   				if(lista.size()>0){
   					if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) {
   						
   						if(criteriPunteggi.getMsgErroreCSV_Laurea()==null) { 
   							if(mappaVotiLaurea.size() < lenRecordCSV_Laurea || mappaVotiLaurea.size() > lenRecordCSV_Laurea) {
   	   							criteriPunteggi.setMsgErroreCSV_Laurea("ERRORE CSV: Il file deve contenere tutti i record con voti da 66 a 110 e Lode.");
   	   						}
   						}
   						
   						if(criteriPunteggi.getMsgErroreCSV_Laurea()==null) { 
	   						criteriPunteggi.setListCriteriPunteggiLaurea(lista);
	   						criteriPunteggi.setbCaricaCSV_Laurea(true);
	   					} 
	   					else {
	   						criteriPunteggi.setListCriteriPunteggiLaurea(null);
	   						criteriPunteggi.setbCaricaCSV_Laurea(false);
	   					}
   						
   					}	
   					else if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE)){
   						
   						if(criteriPunteggi.getMsgErroreCSV_Abilitazione()==null) { 
   							if(mappaVotiAbilitazione.size() < lenRecordCSV_Abilitazione || mappaVotiAbilitazione.size() > lenRecordCSV_Abilitazione) {
   								criteriPunteggi.setMsgErroreCSV_Abilitazione("ERRORE CSV: Il file deve contenere tutti i record con voti da 60 a 100.");
   							}
   						}
   						
   						if(criteriPunteggi.getMsgErroreCSV_Abilitazione()==null) { 
	   						criteriPunteggi.setListCriteriPunteggiAbilitazione(lista);
	   						criteriPunteggi.setbCaricaCSV_Abilitazione(true);
	   					} 
	   					else {
	   						criteriPunteggi.setListCriteriPunteggiAbilitazione(null);
	   						criteriPunteggi.setbCaricaCSV_Abilitazione(false);
	   					}
   					}	
   				}
   				else { //No record
   					if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) {
	   					criteriPunteggi.setbCaricaCSV_Laurea(false);
	   					criteriPunteggi.setListCriteriPunteggiLaurea(null);
   					}
   					else if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE)){
	   					criteriPunteggi.setbCaricaCSV_Abilitazione(false);
	   					criteriPunteggi.setListCriteriPunteggiAbilitazione(null);
   					}
   				}
    	    } 
    	} catch (Exception e) {
			logger.error("CriteriPunteggiAction - uploadCSV: " + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiAction - uploadCSV: "+e);
			throw eccezione;
    	}
    }
    
    public String salva(CriteriPunteggiBean critPunteggi, String tipoTitolo) throws GestioneErroriException {
    	
    	String msg = controlli(critPunteggi, tipoTitolo);
		if(msg==null) {
			//Salvataggio dei dati
			salvaPunteggi(critPunteggi, tipoTitolo, false);
		}
		return msg;
	}

    public String valida(CriteriPunteggiBean critPunteggi, String tipoTitolo) throws GestioneErroriException {
    	
    	String msg = controlli(critPunteggi, tipoTitolo);
		if(msg==null) {
			//Salvataggio dei dati e validazione
			salvaPunteggi(critPunteggi, tipoTitolo, true);
		}
		return msg;
	}

//******************************************************************************************************
//Metodi Privati 
//******************************************************************************************************
    private List<CriteriPunteggiListBean> caricaTabellaCSV(InputStream inputStream, CriteriPunteggiBean critPunt, String tipoCSV) throws GestioneErroriException {

    	List<CriteriPunteggiListBean> listCrit = null;
    	
    	String SEPARATOR = "\\|";
    	String CAMPO_PREC = "PUNTEGGIO";
    	String CAMPO_PREC_MIN = "punteggio";
    	String CAMPO_PREC_MAI_SEMI = "Punteggio";
    	try { 
    		   DataInputStream in = new DataInputStream(inputStream);
    		   BufferedReader br = new BufferedReader(new InputStreamReader(in));
    	       String line = "";
    	       int lineNumber = 0; 
    	       int nRigaExcel = 1;
    	       boolean bGo = false;
    	       listCrit = new ArrayList<CriteriPunteggiListBean>();
    	       
    	       while ((line = br.readLine()) != null) {
    	    	   
    	         String[] riga = line.split(SEPARATOR);
    	         if(bGo){
    	        	if(riga.length==2){
    	        		String sMessaggio = sControlliRiga(riga, tipoCSV, nRigaExcel);
    	        		if(sMessaggio==null){
    	        			listCrit.add(addRiga(riga));
    	        			lineNumber++;
    	        		}
    	        		else //CSV non corretto
    	        		{
    	        			if(tipoCSV.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) {
    	        				critPunt.setMsgErroreCSV_Laurea(sMessaggio);
        	        			break;
        	        		}
        	        		else if(tipoCSV.equals(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE)) {
        	        			critPunt.setMsgErroreCSV_Abilitazione(sMessaggio);
        	        			break;
        	        		}
    	        		}
    	        	}
    	        	else { //CSV non corretto
    	        		if(tipoCSV.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) {
    	        			critPunt.setMsgErroreCSV_Laurea("Errore: il CSV eccede nel numero di colonne.");
    	        			critPunt.setListCriteriPunteggiLaurea(null);
    	        			break;
    	        		}
    	        		else if(tipoCSV.equals(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE)) {
    	        			critPunt.setMsgErroreCSV_Abilitazione("Errore: il CSV eccede nel numero di colonne.");
    	        			critPunt.setListCriteriPunteggiAbilitazione(null);
    	        			break;
    	        		}
    	        	}
    	         }
    	         if(line.contains(CAMPO_PREC) || line.contains(CAMPO_PREC_MIN) || line.contains(CAMPO_PREC_MAI_SEMI))
  	    		   bGo = true;
  	    		 
    	         nRigaExcel++;
    	       }//end While
    	       
    	       if (listCrit.size()>0) {
    	    	   Collections.sort(listCrit);	//ORDINA LA LISTA
    	    	   
    	    	   if(tipoCSV.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) { //Rimette la LODE al posto di 111
        	    	   reimpostaLode(listCrit);
        	       }
    	       }   
    	       
    	       

	    } catch (Exception e) {
			logger.error("CriteriPunteggiAction - caricaTabellaCSV: errore nel caricamento della tabella sedi da CSV: " + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiAction - caricaTabellaCSV: "+e);
			throw eccezione;
	    }
    	
    	return listCrit;
    }
    
    private void reimpostaLode(List<CriteriPunteggiListBean> lista){
    	
    	CriteriPunteggiListBean riga = lista.get(0);
    	if(riga.getVoto().equals("111"))
    			riga.setVoto("110 e lode");
    }
    
    private CriteriPunteggiListBean addRiga(String[] riga) throws GestioneErroriException {
    	
    	CriteriPunteggiListBean criteriPunteggiList = new CriteriPunteggiListBean();
    	criteriPunteggiList.setVoto(riga[0].toString());
    	criteriPunteggiList.setPunteggio(riga[1].toString());
    
		return criteriPunteggiList;
	}
    
    private String sControlliRiga(String[] riga, String tipoTitolo, int index) throws GestioneErroriException {

    	String sMsg = null;
    	
    	String sVoto = riga[0].toString();
    	String sPunteggio = riga[1].toString();
    	Integer iVoto = null;
    	
    	//CONTROLLI LAUREA
    	if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) {
    		
    		try {
    			String sVotazione = sVoto;
    			
    			if(StringUtil.bIsLode(sVotazione)) {
    				sVotazione = StringUtil.eliminaLode(sVotazione); //LODE
    				iVoto = new Integer(sVotazione)+1; //111 (per 110 e Lode)
    				riga[0] = iVoto.toString();
    			}
    			else
    				iVoto = new Integer(sVotazione);
    			
    			//Voto - dovranno essere inserita la scala da "66" a "110 e lode"
	    		if(iVoto < 66 || iVoto > 111) { 
	    			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il voto di laurea deve essere compreso tra 66 e 110.";
	    			return sMsg;
	    		}
    		}
    		catch (Exception e) {
    			sMsg = "[ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il voto di laurea non � formalmente corretto.";
    			return sMsg;
    		}
    		
    		try {
    			//Controllare che il separatore decimale sia ","
        		if(sPunteggio.contains(".")) {
        			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il punteggio di laurea deve essere espresso con separatore decimale ','.";
        			return sMsg;
        		}
	    		String sPunt = sPunteggio.replace(",",".");
	    		//Controllo nMax decimali =4
	    		if(sPunt.indexOf('.')!=-1) {
	    			String sDecimali = sPunt.substring(sPunt.indexOf('.')+1, sPunt.length());
	    			if(sDecimali.length()>4) {
	    				sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il punteggio di laurea deve avere al massimo quattro cifre decimali.";
	    				return sMsg;
	    			}
	    		}
	    			
	    		Double dPunteggio = new Double(sPunt);
	    		//Punteggio - i valori del punteggio devono essere compresi tra 0 e 5
	    		if(dPunteggio < 0 || dPunteggio > 5) {
	    			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il punteggio di laurea deve essere compreso tra 0 e 5.";
	    			return sMsg;
	    		}
    		}
    		catch (Exception e) {
    			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il punteggio di laurea non � formalmente corretto.";
    			return sMsg;
    		}
    		
    		//Controllo che Il file CSV deve contenere tutti i record da "66" a "110 e lode"
    		if(mappaVotiLaurea.containsKey(iVoto)) {
    			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Record duplicato.";
				return sMsg;
    		}
    		else
    			mappaVotiLaurea.put(iVoto, sPunteggio);
    		
    	}
    	//CONTROLLI ABILITAZIONE
    	else if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE)) {
        	//Voto - dovranno essere inserita la scala da "60" a "100"
    		try {
	    		iVoto = new Integer(sVoto);
	    		if(iVoto < 60 || iVoto > 100) {
	    			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il voto di abilitazione deve essere compreso tra 60 e 100.";
	    			return sMsg;
	    		}
    		}
    		catch (Exception e) {
    			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il voto di abilitazione non � formalmente corretto.";
    			return sMsg;
    		}
    		
    		try {
    			//Controllare che il separatore decimale sia ","
        		if(sPunteggio.contains(".")) {
        			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il punteggio di abilitazione deve essere espresso con separatore decimale ','.";
        			return sMsg;
        		}
	    		String sPunt = sPunteggio.replace(",",".");
	    		//Controllo nMax decimali =4
	    		if(sPunt.indexOf('.')!=-1) {
	    			String sDecimali = sPunt.substring(sPunt.indexOf('.')+1, sPunt.length());
	    			if(sDecimali.length()>4) {
	    				sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il punteggio di abilitazione deve avere al massimo quattro cifre decimali.";
	    				return sMsg;
	    			}
	    		}
	    		
	    		//Punteggio - i valori del punteggio devono essere compresi tra 0 e 0,5
	    		Double dPunteggio = new Double(sPunt);
	    		if(dPunteggio < 0 || dPunteggio > 0.5) {
	    			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il punteggio di abilitazione deve essere compreso tra 0 e 0,5.";
	    			return sMsg;
	    		}
    		}
    		catch (Exception e) {
    			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Il punteggio di abilitazione non � formalmente corretto.";
    			return sMsg;
    		}
    		
    		//Controllo che Il file CSV deve contenere tutti i record da "60" a "100"
    		if(mappaVotiAbilitazione.containsKey(iVoto)) {
    			sMsg = "ERRORE CSV - [riga "+index+": "+sVoto+" | "+sPunteggio+"] - Record duplicato.";
				return sMsg;
    		}
    		else
    			mappaVotiAbilitazione.put(iVoto, sPunteggio);
    		
    	}
    	return sMsg;
    }
    
    private String controlli(CriteriPunteggiBean critPunteggi, String tipoTitolo) throws GestioneErroriException {
    	String msg = null;
    	//Controlli CSV Laurea
    	if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) {
    		if(!critPunteggi.isbCaricaCSV_Laurea())
    			msg = "File CSV non presente";	
    		else if(critPunteggi.getMsgErroreCSV_Laurea()!=null)
    			msg = "File CSV non valido";	
    	}
    	//Controlli CSV Abilitazione
    	else if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE)) {
    		if(!critPunteggi.isbCaricaCSV_Abilitazione())
    			msg = "File CSV non presente";	
    		else if(critPunteggi.getMsgErroreCSV_Abilitazione()!=null)
    			msg = "File CSV non valido";	
    	}
    	return msg;
    }
    
    private List<CriteriPunteggiListBean> popolaListaBeanCriteri(List listaPunteggiDB, CriteriPunteggiBean criteriBean, String tipoTitolo) throws GestioneErroriException {
    
    	List<CriteriPunteggiListBean> listaCriteri = null; 
    	if(listaPunteggiDB.size()>0) {
    		
    		listaCriteri = new ArrayList<CriteriPunteggiListBean>();
    		Iterator iter = listaPunteggiDB.iterator();
    		while(iter.hasNext()){	
    			CriteriPunteggi criteriPunt = (CriteriPunteggi)iter.next();
    			CriteriPunteggiListBean elemento = new CriteriPunteggiListBean();
    			String sVoto = criteriPunt.getVoto();
    			
    			if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) {
	    			if(StringUtil.bIsLode(sVoto)) {
	    				sVoto = StringUtil.eliminaLode(sVoto); 
	    				Integer iVoto = new Integer(sVoto)+1; //111 (per 110 e Lode)
	    				sVoto = iVoto.toString();
	    			}
    			}
    			elemento.setVoto(sVoto);
    			
    			String dPunt = criteriPunt.getPunteggio().toString().replace('.', ',');
    			elemento.setPunteggio(dPunt);
    			if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA))
    				criteriBean.setbStato((criteriPunt.getStato().equals("1") ? true : false));
    			else if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE))
    				criteriBean.setbStatoA((criteriPunt.getStato().equals("1") ? true : false));
    				
    			listaCriteri.add(elemento);
    		}
    		Collections.sort(listaCriteri); //Ordinamento Lista
    		
    		if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) { //Rimette la LODE al posto di 111
 	    	   reimpostaLode(listaCriteri);
 	       	}
    	}
    	return listaCriteri;		
    }
    
    private void salvaPunteggi(CriteriPunteggiBean critPunteggi, String tipoTitolo, boolean bValida) throws GestioneErroriException {
	    
		try {
			logger.info("1 - salvaPunteggi - Inizio");
			
			FacesContext context = FacesContext.getCurrentInstance();
			HttpSession session = (HttpSession)context.getExternalContext().getSession(true);
			UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
			String codRegione = null;
			
			if(utenteReg!=null)
			{
				logger.info("Utente NSIS recuperato dalla sessione");
				codRegione = utenteReg.getCodRegione();
				if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_LAUREA)) {
					//Elimina eventuali record gia inseriti e li REINSERISCE		
					List<CriteriPunteggiListBean> lista = critPunteggi.getListCriteriPunteggiLaurea();
					if(lista!=null){
						CriteriPunteggiHome critPunteggiHome = new CriteriPunteggiHome();
						critPunteggiHome.deleteLaureaByRegione(codRegione);
						critPunteggiHome.insertListaLaurea(codRegione, lista, bValida);
						critPunteggi.setbStato((bValida)? true : false);
					}	
				}
				else if(tipoTitolo.equals(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE)) {
					//Elimina eventuali record gia inseriti e li REINSERISCE		
					List<CriteriPunteggiListBean> lista = critPunteggi.getListCriteriPunteggiAbilitazione();
					if(lista!=null){
						CriteriPunteggiHome critPunteggiHome = new CriteriPunteggiHome();
						critPunteggiHome.deleteAbilitazioneByRegione(codRegione);
						critPunteggiHome.insertListaAbilitazione(codRegione, lista, bValida);
						critPunteggi.setbStatoA((bValida)? true : false);
					}
				}
				logger.info("2 - salvaPunteggi - DOPO IL SALVA");
			}
			else {
				logger.error("Utente NSIS non presente in sessione");
	    		JSFUtility.redirect(pageError);
			}
			
		} catch (Exception e) {
			logger.error("CriteriPunteggiAction - salvaPunteggi: errore in fase di salvataggio: " + e.getMessage());
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiAction - salvaPunteggi: errore in fase di salvataggio "+e);
			throw eccezione;
		}
		logger.info("3 - salvaPunteggi - Fine");
	}
    
    
}