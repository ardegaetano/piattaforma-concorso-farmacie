package com.accenture.CCFarm.action;


import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.poi.xslf.usermodel.ListAutoNumber;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.accenture.CCFarm.Bean.GraduatoriaDefinitivaListBean;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaDefinitiva;
import com.accenture.CCFarm.DAO.GraduatoriaDefinitivaHome;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.StoricoGraduatoria;
import com.accenture.CCFarm.DAO.StoricoGraduatoriaHome;
import com.accenture.CCFarm.DAO.StoricoGraduatoriaId;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoriaHome;
import com.accenture.CCFarm.DAO.TipoGraduatoriaId;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.GraduatoriaExAequoBean;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.RisolviExAequo;


public class GraduatoriaExAequoAction{
	
    //Logger logger = CommonLogger.getLogger("RicercaCandidatoAction");
    String pageError = "errorPage.jsf";
	GraduatoriaDefinitivaHome graduatoriaDefinitivaHome = new GraduatoriaDefinitivaHome();
	
	GraduatoriaHome graduatoriaHome = new GraduatoriaHome();

	private List<Graduatoria> graduatoriaListPrec;
	
	private List<Graduatoria> graduatoriaListSucc;
	
	private List<Graduatoria> graduatoriaListCurr;

	GraduatoriaDefinitivaHome definitivaHome = new GraduatoriaDefinitivaHome();
	
	private List<Graduatoria> graduatoriaList = null;
	
	private RisolviExAequo r = new RisolviExAequo();

	private int maxElementGraduatoria = 0;
	
	public GraduatoriaExAequoAction(){
		
	}
	
	
	
	public int getCountGraduatoria(String codReg) throws GestioneErroriException{
		
		 maxElementGraduatoria = graduatoriaHome.searchCount(codReg);
		
		 return maxElementGraduatoria;
	}
	public int getCountExAequoNonRisolti(String codReg) throws GestioneErroriException{
		
		 return  graduatoriaHome.searchCountExaequoRisolto(codReg);
	}
	
	public int getCounttGraduatoriaDefinitiva(String codReg) throws GestioneErroriException{
		
		return definitivaHome.searchCount(codReg);
	}
	
	public List<GraduatoriaDefinitivaListBean> getPageGraduatoriDefin(GraduatoriaExAequoBean graduatoriaExAequoBean , int startPage, int maxPerPage, String function) throws GestioneErroriException{
	   
		int posizione = startPage;
		int j=startPage;
		if (startPage==0)j=1;
		if (startPage>0)posizione--;
				
		String codReg = graduatoriaExAequoBean.getCodReg();
		List<GraduatoriaDefinitiva> graduatoriaDefinitivaList = new ArrayList<GraduatoriaDefinitiva>();
		
//			graduatoriaHome = new GraduatoriaHome();
			
			graduatoriaList = new ArrayList<Graduatoria>();
			
			
			graduatoriaListCurr = graduatoriaHome.findLazyListGradJoinGradDefin(codReg,posizione, maxPerPage);
			
//			r.risolviexAequo(graduatoriaListCurr);
			r.risolviexAequoSuGraduatoria(graduatoriaListCurr);
				
			if (function.equalsIgnoreCase("paginaAvanti") || function.equalsIgnoreCase("aggiornaLista")){
				while (true) {											 
					if ((startPage+maxPerPage)>graduatoriaExAequoBean.getTotaleCandidatiInt()){
						break;
					}
//					if (graduatoriaListCurr.get(graduatoriaListCurr.size()-1).getExAequoRisolto()!=null &&
//						graduatoriaListCurr.get(graduatoriaListCurr.size()-1).getExAequoRisolto().equals("F")){
					if (graduatoriaListCurr.get(graduatoriaListCurr.size()-1).getExAequo()!=null &&
						graduatoriaListCurr.get(graduatoriaListCurr.size()-1).getExAequo().equals("T")){
						maxPerPage++;
						graduatoriaListCurr = graduatoriaHome.findLazyListGradJoinGradDefin(codReg,posizione, maxPerPage);
//						r.risolviexAequo(graduatoriaListCurr);
						r.risolviexAequoSuGraduatoria(graduatoriaListCurr);
					} else{
						break;
					}
				}
			}	
			
			if (function.equalsIgnoreCase("paginaIndietro")){
				while (true) {											 
					if (posizione<0){
						posizione=0;
						break;
					}
//					if (graduatoriaListCurr.get(0).getExAequoRisolto()!=null &&
//							graduatoriaListCurr.get(0).getExAequoRisolto().equals("F")){
					if (graduatoriaListCurr.get(0).getExAequo()!=null &&
						graduatoriaListCurr.get(0).getExAequo().equals("T")){
						maxPerPage++;
						posizione--;
						graduatoriaListCurr = graduatoriaHome.findLazyListGradJoinGradDefin(codReg,posizione, maxPerPage);
//						r.risolviexAequo(graduatoriaListCurr);
						r.risolviexAequoSuGraduatoria(graduatoriaListCurr);
					} else{
						break;
					}
				}
				while (true) {											 
					if ((startPage+maxPerPage)>graduatoriaExAequoBean.getTotaleCandidatiInt()){
						break;
					}
//					if (graduatoriaListCurr.get(graduatoriaListCurr.size()-1).getExAequoRisolto()!=null &&
//						graduatoriaListCurr.get(graduatoriaListCurr.size()-1).getExAequoRisolto().equals("F")){
					if (graduatoriaListCurr.get(graduatoriaListCurr.size()-1).getExAequo()!=null &&
						graduatoriaListCurr.get(graduatoriaListCurr.size()-1).getExAequo().equals("T")){
						maxPerPage++;
						graduatoriaListCurr = graduatoriaHome.findLazyListGradJoinGradDefin(codReg,posizione, maxPerPage);
//						r.risolviexAequo(graduatoriaListCurr);
						r.risolviexAequoSuGraduatoria(graduatoriaListCurr);
					} else{
						break;
					}
				}
			}	
			
			graduatoriaExAequoBean.setAbilitaSalva("true");
			
			for(Graduatoria graduatoria : graduatoriaListCurr){
				
				if (graduatoria.getIndiceTotale()==null ||graduatoria.getIndiceTotale().intValue()==0) {
					graduatoriaExAequoBean.setAbilitaSalva("false"); 
				}
				if (graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().endsWith("F")){
					graduatoriaExAequoBean.setAbilitaSalva("false"); 
				}
//				if (graduatoria.getIndiceTotale()!=null   && graduatoria.getIndiceTotale().intValue()>0 &&
//					graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().endsWith("F")){
//					graduatoriaExAequoBean.setAbilitaSalva("false"); 
//				}
					
				GraduatoriaDefinitiva graduatoriaDefinitiva = new GraduatoriaDefinitiva();
				posizione++;
				if(graduatoria.getExAequoRisolto()!=null && !graduatoria.getExAequoRisolto().equals("T") && !graduatoria.getExAequoRisolto().trim().equals("")){
					graduatoriaDefinitiva.setIndiceTotale(new BigDecimal(j));
					graduatoriaDefinitiva.setIndiceRelativo(new BigDecimal(0));
					
					graduatoriaDefinitiva.setIdCandidatura(graduatoria.getIdCandidatura());
					graduatoriaDefinitiva.setCognome(graduatoria.getCognome());
					graduatoriaDefinitiva.setNome(graduatoria.getNome());
					graduatoriaDefinitiva.setPunteggio(graduatoria.getPunteggio());
					graduatoriaDefinitiva.setEtaMedia(graduatoria.getEtaMedia());
					graduatoriaDefinitiva.setDataNascita(graduatoria.getDataNascita());
					graduatoriaDefinitiva.setCodRegione(graduatoria.getCodRegione());
					graduatoriaDefinitiva.setNumeroProtocollo(graduatoria.getNumeroProtocollo());
					graduatoriaDefinitiva.setExAequo("T");
					graduatoriaDefinitiva.setExAequoRisolto("F");
					
					
					}else if(graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().equals("T") ){
						graduatoriaDefinitiva.setIndiceTotale(new BigDecimal(posizione));
//						if (graduatoria.getIndiceTotale()!=null && graduatoria.getIndiceTotale().intValue()>0){
//							graduatoriaDefinitiva.setIndiceTotale(graduatoria.getIndiceTotale());
//						} else {
//							graduatoriaDefinitiva.setIndiceTotale(new BigDecimal(posizione));
//						}
						if (graduatoria.getIndiceTotale()!=null && graduatoria.getIndiceTotale().intValue()>0  &&
							graduatoria.getIndiceTotale().compareTo(new BigDecimal(posizione))!=0	){
							graduatoriaExAequoBean.setAbilitaSalva("false"); 
							graduatoriaExAequoBean.setAbilitaValidazione("true");
						}
							
						if (graduatoria.getIndiceRelativo()!=null && graduatoria.getIndiceRelativo().intValue()>0){
							graduatoriaDefinitiva.setIndiceRelativo(graduatoria.getIndiceRelativo());
						} else{
							graduatoriaDefinitiva.setIndiceRelativo(new BigDecimal(0));
						}
//						graduatoriaDefinitiva.setIndiceRelativo(new BigDecimal(0));
						graduatoriaDefinitiva.setExAequoRisolto("T");
						graduatoriaDefinitiva.setExAequo("T");
						graduatoriaDefinitiva.setIdCandidatura(graduatoria.getIdCandidatura());
						graduatoriaDefinitiva.setCognome(graduatoria.getCognome());
						graduatoriaDefinitiva.setNome(graduatoria.getNome());
						graduatoriaDefinitiva.setPunteggio(graduatoria.getPunteggio());
						graduatoriaDefinitiva.setEtaMedia(graduatoria.getEtaMedia());
						graduatoriaDefinitiva.setDataNascita(graduatoria.getDataNascita());
						graduatoriaDefinitiva.setCodRegione(graduatoria.getCodRegione());
						graduatoriaDefinitiva.setNumeroProtocollo(graduatoria.getNumeroProtocollo());
						j = posizione+1;
					}else{
						if((graduatoriaListCurr.indexOf(graduatoria)-1)>0 && graduatoriaDefinitivaList.get(graduatoriaListCurr.indexOf(graduatoria)-1)!=null &&  graduatoriaDefinitivaList.get(graduatoriaListCurr.indexOf(graduatoria)-1).getExAequo()!=null && graduatoriaDefinitivaList.get(graduatoriaListCurr.indexOf(graduatoria)-1).getExAequo().equals("T") && graduatoriaDefinitivaList.get(graduatoriaListCurr.indexOf(graduatoria)-1).getExAequoRisolto()!=null && graduatoriaDefinitivaList.get(graduatoriaListCurr.indexOf(graduatoria)-1).getExAequoRisolto().equalsIgnoreCase("F")){
							int count = graduatoriaListCurr.indexOf(graduatoria)-1;
							do{
								
								//graduatoriaListCurr.get(count).setIndiceRelativo(posizione);
								graduatoriaDefinitivaList.get(count).setIndiceRelativo(new BigDecimal(posizione-1));
								
								count--;
							}while(count>=0 && graduatoriaDefinitivaList.get(count)!=null && graduatoriaDefinitivaList.get(count).getExAequo()!=null && graduatoriaDefinitivaList.get(count).getExAequo().equals("T") && graduatoriaDefinitivaList.get(graduatoriaListCurr.indexOf(graduatoria)-1).getExAequoRisolto()!=null && graduatoriaDefinitivaList.get(graduatoriaListCurr.indexOf(graduatoria)-1).getExAequoRisolto().equalsIgnoreCase("F"));
						}
							
					//graduatoriaDefinitiva.setExAequoRisolto("T");
					//graduatoriaDefinitiva.setExAequo("T");
					graduatoriaDefinitiva.setIndiceTotale(new BigDecimal(posizione));
//					if (graduatoria.getIndiceTotale()!=null && graduatoria.getIndiceTotale().intValue()>0){
//						graduatoriaDefinitiva.setIndiceTotale(graduatoria.getIndiceTotale());
//					} else {
//						graduatoriaDefinitiva.setIndiceTotale(new BigDecimal(posizione));
//					}
					if (graduatoria.getIndiceTotale()!=null && graduatoria.getIndiceTotale().intValue()>0  &&
						graduatoria.getIndiceTotale().compareTo(new BigDecimal(posizione))!=0	){
						graduatoriaExAequoBean.setAbilitaSalva("false"); 
						graduatoriaExAequoBean.setAbilitaValidazione("true");
					}
					if (graduatoria.getIndiceRelativo()!=null && graduatoria.getIndiceRelativo().intValue()>0){
						graduatoriaDefinitiva.setIndiceRelativo(graduatoria.getIndiceRelativo());
					} else{
						graduatoriaDefinitiva.setIndiceRelativo(new BigDecimal(0));
					}
//					graduatoriaDefinitiva.setIndiceRelativo(new BigDecimal(0));
					graduatoriaDefinitiva.setIdCandidatura(graduatoria.getIdCandidatura());
					graduatoriaDefinitiva.setCognome(graduatoria.getCognome());
					graduatoriaDefinitiva.setNome(graduatoria.getNome());
					graduatoriaDefinitiva.setPunteggio(graduatoria.getPunteggio());
					graduatoriaDefinitiva.setEtaMedia(graduatoria.getEtaMedia());
					graduatoriaDefinitiva.setDataNascita(graduatoria.getDataNascita());
					graduatoriaDefinitiva.setCodRegione(graduatoria.getCodRegione());
					graduatoriaDefinitiva.setNumeroProtocollo(graduatoria.getNumeroProtocollo());
					j = posizione+1;
					}
			
				graduatoriaDefinitivaList.add(graduatoriaDefinitiva);
				
			}
			
		
//
//		if (maxPerPage!=graduatoriaDefinitivaList.size()){
//			maxPerPage= graduatoriaDefinitivaList.size();
//		}
		int ultimo = 0;
		if (function.equalsIgnoreCase("paginaAvanti")){
			if (graduatoriaExAequoBean.getRowNumerUltimo()==graduatoriaExAequoBean.getTotaleCandidatiInt()){
				ultimo = graduatoriaExAequoBean.getTotaleCandidatiInt();
			}else {
				ultimo = graduatoriaExAequoBean.getRowNumerUltimo()+maxPerPage;
			}
		}
		
		if (function.equalsIgnoreCase("paginaIndietro")){
			if (startPage==0){
				ultimo = maxPerPage;
			} else{
				ultimo = graduatoriaExAequoBean.getRowNumerUltimo()-maxPerPage;
			}
		}
		
		if (function.equalsIgnoreCase("aggiornaLista")){ultimo = graduatoriaExAequoBean.getRowNumerUltimo();}
			
		graduatoriaExAequoBean.setRowNumerUltimo(ultimo);
		

		return modellaViewDataTable(graduatoriaDefinitivaList);
//		return graduatoriaExAequoBean.getListGradDefinBean();
	}
	
	

	
	private List<GraduatoriaDefinitivaListBean> modellaViewDataTable(List<GraduatoriaDefinitiva> listaGraduatoriDef) throws GestioneErroriException{
		
//		String color[];
		int posizione;
		
		List<GraduatoriaDefinitivaListBean> graduatoriaListBean = new ArrayList<GraduatoriaDefinitivaListBean>();
		try {
			
//			color = new String[listaGraduatoriDef.size()];
			for(GraduatoriaDefinitiva graduatoria : listaGraduatoriDef){
				
				GraduatoriaDefinitivaListBean definitivaListBean= new GraduatoriaDefinitivaListBean();
				
				
				PropertyUtils.copyProperties(definitivaListBean, graduatoria);
				definitivaListBean.setIndiceSave(graduatoria.getIndiceTotale());
				
				definitivaListBean.setColorRow("white");
				definitivaListBean.setPunteggioString(graduatoria.getPunteggio().toString().replace(".", ","));
				definitivaListBean.setEtaMediaString(graduatoria.getEtaMedia().toString().replace(".", ","));
				
				definitivaListBean.setIndiceView("true");
				definitivaListBean.setIndiceSpinner("false");
				
				posizione = listaGraduatoriDef.indexOf(graduatoria);
				if (graduatoria.getExAequo()!=null &&  graduatoria.getExAequo().equalsIgnoreCase("T")){
	//exAequo da risovere					
					if(graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().equals("F") ){
//						definitivaListBean.setIndiceSave(graduatoria.getIndiceTotale());
//						color[posizione]="red";
						definitivaListBean.setColorRow("red");
						definitivaListBean.setIndiceView("false");
						definitivaListBean.setIndiceSpinner("true");
					}
//exAequo risolto in valutazione automatica
//						color[posizione]="green";
					if(graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().equals("T") ){
						definitivaListBean.setColorRow("green");
						if(graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().equals("T") &&
						   graduatoria.getIndiceRelativo().intValue()>0		){
			//exAequo risolto manulamente
//							color[posizione]="blue";
							definitivaListBean.setColorRow("blue");
						} 
					}
						
				}
				
				graduatoriaListBean.add(definitivaListBean);
			}
		
		} catch(Exception e){
			throw new GestioneErroriException("GraduatoriaExAequoAction - modellaViewDataTable: errore  ");
		}		
		
		
		return graduatoriaListBean;
		
	}
	
	
	public List<GraduatoriaDefinitivaListBean> getPageGraduatoria(GraduatoriaExAequoBean graduatoriaExAequoBean , int startPage, int maxPerPage, String function) throws GestioneErroriException{
		   
		int posizione = startPage;
		int j=startPage;
		if (startPage==0)j=1;
		if (startPage>0)posizione--;
				
		String codReg = graduatoriaExAequoBean.getCodReg();
		List<GraduatoriaDefinitiva> graduatoriaDefinitivaList = new ArrayList<GraduatoriaDefinitiva>();
		
		
		graduatoriaList = new ArrayList<Graduatoria>();
		
		graduatoriaListCurr = graduatoriaHome.findLazyListGradJoinGradDefin(codReg,posizione, maxPerPage);
		
		graduatoriaExAequoBean.setAbilitaSalva("true");
		
		List<GraduatoriaDefinitivaListBean> graduatoriaListBean = new ArrayList<GraduatoriaDefinitivaListBean>();
		try {
			
//				color = new String[listaGraduatoriDef.size()];
			for(Graduatoria graduatoria : graduatoriaListCurr){
				
				GraduatoriaDefinitivaListBean definitivaListBean= new GraduatoriaDefinitivaListBean();
				
				if (graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().endsWith("F")){
					graduatoriaExAequoBean.setAbilitaSalva("false"); 
				}
//				if (graduatoria.getIndiceTotale()==null){
//					graduatoriaExAequoBean.setAbilitaSalva("false"); 
//				}
//			
				
				PropertyUtils.copyProperties(definitivaListBean, graduatoria);
				definitivaListBean.setIndiceSave(graduatoria.getIndiceTotale());
				
				definitivaListBean.setColorRow("white");
				definitivaListBean.setPunteggioString(graduatoria.getPunteggio().toString().replace(".", ","));
				definitivaListBean.setEtaMediaString(graduatoria.getEtaMedia().toString().replace(".", ","));
				
				definitivaListBean.setIndiceView("true");
				definitivaListBean.setIndiceSpinner("false");
				
				posizione = graduatoriaListCurr.indexOf(graduatoria);
				if (graduatoria.getExAequo()!=null &&  graduatoria.getExAequo().equalsIgnoreCase("T")){
	//exAequo da risovere					
					if(graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().equals("F") ){
//							definitivaListBean.setIndiceSave(graduatoria.getIndiceTotale());
//							color[posizione]="red";
						definitivaListBean.setColorRow("red");
						definitivaListBean.setIndiceView("false");
						definitivaListBean.setIndiceSpinner("true");
					}
//exAequo risolto in valutazione automatica
//							color[posizione]="green";
					if(graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().equals("T") ){
						definitivaListBean.setColorRow("green");
//						if(graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().equals("T") &&
//							   graduatoria.getIndiceRelativo().intValue()>0		){
						if(graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().equals("T") &&
						   graduatoria.getColor()!=null && graduatoria.getColor().equalsIgnoreCase("blue")		){
					//exAequo risolto manulamente
//								color[posizione]="blue";
							definitivaListBean.setColorRow("blue");
						} 
					}
						
				}
				
				graduatoriaListBean.add(definitivaListBean);
			}
		
		} catch(Exception e){
			throw new GestioneErroriException("GraduatoriaExAequoAction - modellaViewDataTable: errore  ");
		}
		
		int ultimo = 0;
		if (function.equalsIgnoreCase("paginaAvanti")){
			if (graduatoriaExAequoBean.getRowNumerUltimo()==graduatoriaExAequoBean.getTotaleCandidatiInt()){
				ultimo = graduatoriaExAequoBean.getTotaleCandidatiInt();
			}else {
				ultimo = graduatoriaExAequoBean.getRowNumerUltimo()+maxPerPage;
			}
		}
		
		if (function.equalsIgnoreCase("paginaIndietro")){
			if (startPage==0){
				ultimo = maxPerPage;
			} else{
				ultimo = graduatoriaExAequoBean.getRowNumerUltimo()-maxPerPage;
			}
		}
		
		if (function.equalsIgnoreCase("aggiornaLista")){ultimo = graduatoriaExAequoBean.getRowNumerUltimo();}
			
		graduatoriaExAequoBean.setRowNumerUltimo(ultimo);
		

		return graduatoriaListBean;
//		return graduatoriaExAequoBean.getListGradDefinBean();
	}
	

	public List<Graduatoria> cerca(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
		String exAequo="";
		GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
		Graduatoria graduatoria = new Graduatoria();
		if(graduatoriaExAequoBean.isExAequo()){
			 exAequo="F";
		}
		List<Graduatoria> result = graduatoriaHome.findByCriteria(new Graduatoria(graduatoriaExAequoBean.getProtocolloExaequo(), graduatoriaExAequoBean.getCognomeExaequo(),exAequo,graduatoriaExAequoBean.getCodReg()));
		
		return result;
	}
	
	
//	private List<GraduatoriaDefinitivaListBean> modellaViewDataTable(List<GraduatoriaDefinitiva> listaGraduatoriDef) throws GestioneErroriException{
//	
//	String color[];
//	int posizione;
//	
//	List<GraduatoriaDefinitivaListBean> graduatoriaListBean = new ArrayList<GraduatoriaDefinitivaListBean>();
//	try {
//		
//		color = new String[listaGraduatoriDef.size()];
//		for(GraduatoriaDefinitiva graduatoria : listaGraduatoriDef){
//			
//			GraduatoriaDefinitivaListBean definitivaListBean= new GraduatoriaDefinitivaListBean();
//			
//			
//				PropertyUtils.copyProperties(definitivaListBean, graduatoria);
//			
//			definitivaListBean.setColorRow("white");
//			definitivaListBean.setPunteggioString(graduatoria.getPunteggio().toString().replace(".", ","));
//			definitivaListBean.setEtaMediaString(graduatoria.getEtaMedia().toString().replace(".", ","));
//			
//			definitivaListBean.setIndiceView("true");
//			definitivaListBean.setIndiceSpinner("false");
//			
//			posizione = listaGraduatoriDef.indexOf(graduatoria);
//			if (graduatoria.getExAequo()!=null &&  graduatoria.getExAequo().equalsIgnoreCase("T")){
////exAequo da risovere					
//				if(graduatoria.getExAequoRisolto()!=null && !graduatoria.getExAequoRisolto().equals("T") ){
////					definitivaListBean.setIndiceSave(graduatoria.getIndiceTotale());
//					color[posizione]="red";
//					definitivaListBean.setColorRow("red");
//					definitivaListBean.setIndiceView("false");
//					definitivaListBean.setIndiceSpinner("true");
//					GraduatoriaDefinitiva graduatoriaDefinitiva = new GraduatoriaDefinitiva();
//					graduatoriaDefinitiva = graduatoriaDefinitivaHome.findById(graduatoria.getIdCandidatura());
//					if (graduatoriaDefinitiva!=null){
//						if(graduatoriaDefinitiva.getExAequoRisolto()!=null && graduatoriaDefinitiva.getExAequoRisolto().equals("T") &&
//						   graduatoriaDefinitiva.getIndiceRelativo().intValue()>0		){
//	//exAequo risolto manulamente
//							color[posizione]="blue";
//							definitivaListBean.setColorRow("blue");
//							definitivaListBean.setIndiceView("true");
//							definitivaListBean.setIndiceSpinner("false");
//							definitivaListBean.setIndiceTotale(graduatoriaDefinitiva.getIndiceTotale());
//							definitivaListBean.setIndiceRelativo(graduatoriaDefinitiva.getIndiceRelativo());
//							definitivaListBean.setExAequoRisolto(graduatoriaDefinitiva.getExAequoRisolto());
//						} 
//					}		
//
//					
//				}else {
////exAequo risolto in valutazione automatica
//					color[posizione]="green";
//					definitivaListBean.setColorRow("green");
//
//				}	
//			}
//			
//			graduatoriaListBean.add(definitivaListBean);
//		}
//	
//	} catch(Exception e){
//		throw new GestioneErroriException("GraduatoriaExAequoAction - modellaViewDataTable: errore  ");
//	}		
//	
//	
//	return graduatoriaListBean;
//	
//}
//
	
	public List<GraduatoriaDefinitiva> getdefinitiva(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
		
		List<GraduatoriaDefinitiva> listGradDefin = new ArrayList<GraduatoriaDefinitiva>();
//		GraduatoriaDefinitivaHome graduatoriaDefinitivaHome = new GraduatoriaDefinitivaHome();
//		
		listGradDefin= graduatoriaDefinitivaHome.findByExample(new GraduatoriaDefinitiva());
		
		
		return listGradDefin;
		
	}
	
	
	public void getGraduatoriaDefinitiva(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
		
//		RisolviExAequo r = new RisolviExAequo();
		int posizione;
		int j = 1;
		String color[];
//		GraduatoriaDefinitivaHome graduatoriaDefinitivaHome = new GraduatoriaDefinitivaHome();
		GraduatoriaDefinitiva graduatoriaDefinitiva = new GraduatoriaDefinitiva();
		graduatoriaDefinitiva.setCodRegione(graduatoriaExAequoBean.getCodReg());
		//query sulla tabella graduatoria per 
		try {
			List<GraduatoriaDefinitiva> graduatoriaList = graduatoriaDefinitivaHome.findByExample(graduatoriaDefinitiva);
			List<GraduatoriaDefinitivaListBean> graduatoriaListBean = new ArrayList<GraduatoriaDefinitivaListBean>();

//			r.risolviexAequo(graduatoriaList);
			color = new String[graduatoriaList.size()];
			for(GraduatoriaDefinitiva graduatoriaDef : graduatoriaList){
				
				GraduatoriaDefinitivaListBean definitivaListBean= new GraduatoriaDefinitivaListBean();
				
				PropertyUtils.copyProperties(definitivaListBean, graduatoriaDef);
				definitivaListBean.setColorRow("white");
				definitivaListBean.setPunteggioString(graduatoriaDef.getPunteggio().toString().replace(".", ","));
				definitivaListBean.setEtaMediaString(graduatoriaDef.getEtaMedia().toString().replace(".", ","));
				
				definitivaListBean.setIndiceView("true");
				definitivaListBean.setIndiceSpinner("false");
//				definitivaListBean.setColorRow(".textSmallClass");
				
				posizione = graduatoriaList.indexOf(graduatoriaDef);
				if (graduatoriaDef.getExAequo()!=null &&  graduatoriaDef.getExAequo().equalsIgnoreCase("T")){
// exAequo da risovere					
					if(graduatoriaDef.getExAequoRisolto()!=null && !graduatoriaDef.getExAequoRisolto().equals("T") ){
						definitivaListBean.setIndiceSave(graduatoriaDef.getIndiceTotale());
						color[posizione]="red";
						definitivaListBean.setColorRow("red");
						definitivaListBean.setIndiceView("false");
						definitivaListBean.setIndiceSpinner("true");
//						definitivaListBean.setColorRow(".textSmallClassColorRed");
						
					}else {
						if(graduatoriaDef.getExAequoRisolto()!=null && graduatoriaDef.getExAequoRisolto().equals("T") &&
						   graduatoriaDef.getIndiceRelativo().intValue()>0		){
// exAequo risolto manulamente
							color[posizione]="lime";
							definitivaListBean.setColorRow("lime");
							
						} else{
// exAequo risolto in valutazione automatica
						color[posizione]="green";
						definitivaListBean.setColorRow("green");
						}
					}	
				}
				
				graduatoriaListBean.add(definitivaListBean);
			}
			
//			graduatoriaExAequoBean.setListGradDefin(graduatoriaList);
			graduatoriaExAequoBean.setListGradDefinBean(graduatoriaListBean);
			graduatoriaExAequoBean.setColor(color);
		} catch(Exception e){
			throw new GestioneErroriException("GraduatoriaExAequoAction - getGraduatoriaDefinitiva: errore  ");
		}	
		
		
	}
	
	
	public List<String> getListGraduatoriaDefinitiva(GraduatoriaExAequoBean graduatoriaExAequoBean_save) throws GestioneErroriException{
		
//		GraduatoriaDefinitiva graduatoriaDefinitiva = new GraduatoriaDefinitiva();
//		graduatoriaDefinitiva.setCodRegione(graduatoriaExAequoBean.getCodReg());
		//query sulla tabella graduatoria per 
		List<String> graduatoriaList =  graduatoriaDefinitivaHome.findByIdListGraduatoria(graduatoriaExAequoBean_save.getCodReg());
				
//		graduatoriaExAequoBean.setListGradDefin(graduatoriaList);
//		graduatoriaExAequoBean.setIdCandidatiList(graduatoriaList);
		return graduatoriaList;
		
	}

	
	
	public List<GraduatoriaDefinitivaListBean> paginazioneCandidati(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException {
    	
    	List<GraduatoriaDefinitiva>         graduatoriaList     = new ArrayList<GraduatoriaDefinitiva>();
    	List<GraduatoriaDefinitivaListBean> graduatoriaListBean = new ArrayList<GraduatoriaDefinitivaListBean>();
		
    	
    	List<String> listSelectIn = new ArrayList<String>();
		int primo = graduatoriaExAequoBean.getRowIniBlock();
    	int ultimo = graduatoriaExAequoBean.getRowIniBlock();
    	
    	for (int i = primo; i < graduatoriaExAequoBean.getRowFinBlock(); i++) {
			String idCandidato = graduatoriaExAequoBean.getIdCandidatiList().get(i);
			listSelectIn.add(idCandidato);
			ultimo++;
		}
    	graduatoriaExAequoBean.setRowNumerUltimo(ultimo);
    	
    	graduatoriaList = graduatoriaDefinitivaHome.findPage(graduatoriaExAequoBean.getUtenteReg().getCodRegione(), listSelectIn);
		
		
    	return graduatoriaListBean ;
	}
	
	
	
	
	
	
	public boolean risolviExAequo(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
		
//Verifico che tutti gli ex Aequo della lista sono stati risolti
		HashMap hmPosizione = new HashMap();
		for (GraduatoriaDefinitivaListBean definitivaListBean : graduatoriaExAequoBean.getListGradDefinBean()) {
			if (!hmPosizione.containsKey(definitivaListBean.getIndiceTotale())){
				hmPosizione.put(definitivaListBean.getIndiceTotale(), "");
			} else{
				return false;
			}
		}
			
		GraduatoriaDefinitivaHome graduatoriaDefinitivaHome = new GraduatoriaDefinitivaHome();
		
		for (GraduatoriaDefinitivaListBean definitivaListBean : graduatoriaExAequoBean.getListGradDefinBean()) {
			try {
				if (definitivaListBean.getExAequo()!=null &&  definitivaListBean.getExAequo().equalsIgnoreCase("T")){
		// exAequo da risovere					
					if(definitivaListBean.getExAequoRisolto()!=null && !definitivaListBean.getExAequoRisolto().equals("T") ){
						GraduatoriaDefinitiva definitiva = new GraduatoriaDefinitiva();
						PropertyUtils.copyProperties(definitiva, definitivaListBean);
						definitiva.setExAequoRisolto("T");
						graduatoriaDefinitivaHome.saveOrUpdate(definitiva);
					}
				}
			} catch(Exception e){
				throw new GestioneErroriException("GraduatoriaExAequoAction - risolviExAequo: errore  ");
			}	
		}
		
		return true;
	}
	
	
	
	public boolean risolviExAequoDB(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
		
		//Verifico che tutti gli ex Aequo della lista sono stati risolti
				HashMap hmPosizione = new HashMap();
				for (GraduatoriaDefinitivaListBean definitivaListBean : graduatoriaExAequoBean.getListGradDefinBean()) {
					if (definitivaListBean.getExAequo()!=null        &&  definitivaListBean.getExAequo().equalsIgnoreCase("T") &&
						definitivaListBean.getExAequoRisolto()!=null &&	 definitivaListBean.getExAequoRisolto().equalsIgnoreCase("F")){
						if (!hmPosizione.containsKey(definitivaListBean.getIndiceTotale())){
							hmPosizione.put(definitivaListBean.getIndiceTotale(), "");
							int posizioneTrovata = graduatoriaHome.getPosizioneExsist(graduatoriaExAequoBean.getCodReg(), definitivaListBean.getIndiceTotale());
						    if (posizioneTrovata>0) {	
//						    	if (posizioneTrovata>1){
//						    		int diff = definitivaListBean.getIndiceRelativo().intValue()-definitivaListBean.getIndiceTotale().intValue();
//							    	if (posizioneTrovata!=diff+1){
								    	graduatoriaExAequoBean.setMsgError("M03");
										return false;
//									}		
//						    	}
						    }
						} else{
							graduatoriaExAequoBean.setMsgError("M01");
							return false;
						}
						if (definitivaListBean.getExAequoRisolto()!=null && definitivaListBean.getExAequoRisolto().equalsIgnoreCase("F") ){
							if (definitivaListBean.getIndiceTotale()!=null && definitivaListBean.getIndiceRelativo()!=null && definitivaListBean.getIndiceSave()!=null){
								if (definitivaListBean.getIndiceTotale().intValue() < definitivaListBean.getIndiceSave().intValue()  ||
										definitivaListBean.getIndiceTotale().intValue() > definitivaListBean.getIndiceRelativo().intValue() ){
										graduatoriaExAequoBean.setMsgError("M02");
										return false;
								}		
							} else{
								throw new GestioneErroriException("GraduatoriaExAequoAction - risolviExAequoDB: errore indice null");
							}
						}
					}
				}
					
//				GraduatoriaDefinitivaHome graduatoriaDefinitivaHome = new GraduatoriaDefinitivaHome();
				
				
				for (GraduatoriaDefinitivaListBean definitivaListBean : graduatoriaExAequoBean.getListGradDefinBean()) {
					try {
//						GraduatoriaDefinitiva definitiva = new GraduatoriaDefinitiva();
//						BigDecimal indice_totale = new BigDecimal(definitivaListBean.getIndiceTotale().toString());
//						BigDecimal indice_relativo = new BigDecimal(definitivaListBean.getIndiceRelativo().toString());
						if (definitivaListBean.getExAequo()!=null        &&  definitivaListBean.getExAequo().equalsIgnoreCase("T") &&
							definitivaListBean.getExAequoRisolto()!=null &&	 definitivaListBean.getExAequoRisolto().equalsIgnoreCase("F")){
				// exAequo da risovere					
							Graduatoria definitiva = new Graduatoria();
							definitiva = graduatoriaHome.findById(definitivaListBean.getIdCandidatura());
							PropertyUtils.copyProperties(definitiva, definitivaListBean);
							definitiva.setExAequoRisolto("T");
							definitiva.setColor("blue");
							graduatoriaHome .saveOrUpdate(definitiva);
						}
//						graduatoriaDefinitivaHome.saveOrUpdate(definitiva);
//						graduatoriaHome .saveOrUpdate(definitiva);
					} catch(Exception e){
						throw new GestioneErroriException("GraduatoriaExAequoAction - risolviExAequoDB: errore  ");
					}	
				}
				
				return true;
			}
	
	
	
	
	public boolean validaGraduatorXStoricoProva(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
	
		
		StoricoGraduatoriaHome storicoGraduatoriaHome = new StoricoGraduatoriaHome();
		int maxSizeTabel =definitivaHome.searchCount(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
		int countRow=0;
		int startRow=0;
		int maxRow=20;
		Transaction trx = null;
		Session session = null;
		
		List<GraduatoriaDefinitiva> listGD = new ArrayList<GraduatoriaDefinitiva>();
		
		listGD = definitivaHome.findOrderByGraduatoria("070");
		
		
		try {
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			trx.begin();	
			
			//while ((countRow+1)<maxSizeTabel) {
			
				for (GraduatoriaDefinitiva graduatoriaDefinitiva : listGD) {
					
					StoricoGraduatoria storicoGraduatoria = new StoricoGraduatoria();
					StoricoGraduatoriaId idKey = new StoricoGraduatoriaId();
					
					//storicoGraduatoria = storicoGraduatoriaHome.findById(id)
					PropertyUtils.copyProperties(storicoGraduatoria, graduatoriaDefinitiva);
					
					idKey.setIdCandidatura(graduatoriaDefinitiva.getIdCandidatura());
					idKey.setnProgressivo("1");
					storicoGraduatoria.setIdKey(idKey);
					storicoGraduatoria.setDataValidazione(new Date());
					storicoGraduatoria.setDataValidazioneString("");
					storicoGraduatoria.setExAequoRisolto(graduatoriaDefinitiva.getExAequoRisolto());
					storicoGraduatoria.setnProgressivo("1");
					
//					storicoGraduatoriaHome.saveOrUpdate(storicoGraduatoria);
					session.save(storicoGraduatoria);
//					countRow++;
//					startRow++;
				}
				trx.commit();
			//}
			
//			System.out.println("righe totali :"+ countRow);
//			
		} catch(Exception e){
			trx.rollback();
			throw new GestioneErroriException("GraduatoriaExAequoAction - validaGraduatorXStorico: errore  ");
		}finally{
			session.close();
		}
		
		
		
		
		return true;	

		
	}
	
	
	
	//se in tipologia graduatoria non c'� il flag P 
	//all'ultima graduatoria presente , allora sovrascivo in storico
	//a�trimenti ne scrivo un altra in storico
	public boolean validaGraduatorXStorico(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
	
		
		StoricoGraduatoriaHome storicoGraduatoriaHome = new StoricoGraduatoriaHome();
		TipoGraduatoria   tipoGraduatoria        = new TipoGraduatoria();
		TipoGraduatoriaId tipoGraduatoriaId      = new TipoGraduatoriaId();
		TipoGraduatoriaHome tipoGraduatoriaHome  = new TipoGraduatoriaHome();
		
		List<Graduatoria> listGraduatoria = new ArrayList<Graduatoria>();
		listGraduatoria = graduatoriaHome.findOrderAllGraduatoria(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
		
		tipoGraduatoria.setCodRegione(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
		tipoGraduatoriaId.setCodRegione(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
		tipoGraduatoria.setIdKey(tipoGraduatoriaId);
		List<TipoGraduatoria> listTipoGrad = new ArrayList<TipoGraduatoria>();
		listTipoGrad = tipoGraduatoriaHome.findByExample(tipoGraduatoria);
		
		java.util.Date dataSys= new java.util.Date();
//		logAccessi.setLogAccesso(new java.sql.Timestamp(dataSys.getTime()));	
		
		if (listTipoGrad==null || listTipoGrad.size()==0){
			//prima graduatoria pubblicata
			tipoGraduatoria.setCodRegione(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
			tipoGraduatoriaId.setCodRegione(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
			tipoGraduatoria.setCodTipologiaGraduatoria("1");
			tipoGraduatoria.setProgressivo(new BigDecimal(1));
			tipoGraduatoriaId.setProgressivo(new BigDecimal(1));
			tipoGraduatoria.setIdKey(tipoGraduatoriaId);
			tipoGraduatoria.setDataValutazione(dataSys);
			storicoGraduatoriaHome.caricamentoStoricoFromGraduatoria(listGraduatoria, tipoGraduatoria, tipoGraduatoriaHome);
		} else{
			//graduatoria rettificata
			tipoGraduatoria = listTipoGrad.get(0);
			
			TipoGraduatoria tipoGradNew = new TipoGraduatoria();
			TipoGraduatoriaId   tipoGradNewId    = new TipoGraduatoriaId();
			tipoGradNew.setCodRegione(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
			tipoGradNewId.setCodRegione(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
			tipoGradNew.setDataValutazione(dataSys);
			BigDecimal progressivo = new BigDecimal(tipoGraduatoria.getProgressivo().intValue()+1);
			tipoGradNew.setProgressivo(progressivo);
			tipoGradNewId.setProgressivo(progressivo);
			tipoGradNew.setCodTipologiaGraduatoria(""+progressivo);
			tipoGradNew.setIdKey(tipoGradNewId);
			
			
			storicoGraduatoriaHome.caricamentoStoricoFromGraduatoria(listGraduatoria, tipoGradNew, tipoGraduatoriaHome);
			
			//sovrascrive la graduatoria con lo stesso progressivo, noi vogiamo storicizzarle tutte quindi � un nuovo caricamento
			//storicoGraduatoriaHome.updateStoricoFromGraduatoria(listGraduatoria, tipoGraduatoria, tipoGraduatoriaHome);

			
			//gestione graduatire rettificate : abbiamo modificato inserendo sempre una nuova tipologia con un nuovo progressivo
			//			if(tipoGraduatoria.getStatoGraduatoria().equals("P")){
//				TipoGraduatoria     tipoGradRettifica      = new TipoGraduatoria();
//				TipoGraduatoriaId   tipoGradRettificaId    = new TipoGraduatoriaId();
//				tipoGradRettifica.setCodRegione(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
//				tipoGradRettificaId.setCodRegione(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
//				tipoGradRettifica.setDataValutazione(dataSys);
//					
//				if (tipoGraduatoria.getCodTipologiaGraduatoria().equals("1")){
//					tipoGradRettifica.setCodTipologiaGraduatoria("2");
//					BigDecimal progressivo = new BigDecimal(tipoGraduatoria.getProgressivo().intValue()+1);
//					tipoGradRettifica.setProgressivo(progressivo);
//					tipoGradRettificaId.setProgressivo(progressivo);
//					tipoGradRettifica.setIdKey(tipoGradRettificaId);
//				}else {
//					tipoGradRettifica.setCodTipologiaGraduatoria("3");
//					BigDecimal progressivo = new BigDecimal(tipoGraduatoria.getProgressivo().intValue()+1);
//					tipoGradRettifica.setProgressivo(progressivo);
//					tipoGradRettificaId.setProgressivo(progressivo);
//					tipoGradRettifica.setIdKey(tipoGradRettificaId);
//				}
//				storicoGraduatoriaHome.caricamentoStoricoFromGraduatoria(listGraduatoria, tipoGradRettifica, tipoGraduatoriaHome);
//				}
//			else{
//				//aggiorno quella che c'era gi�
//				tipoGraduatoria.setDataValutazione(dataSys);
//				storicoGraduatoriaHome.updateStoricoFromGraduatoria(listGraduatoria, tipoGraduatoria, tipoGraduatoriaHome);
//			}
		}

		
		
		DatiBando datiBando = new DatiBando();
		DatiBandoHome datiBandoHome = new DatiBandoHome();
		datiBando = datiBandoHome.findById(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
		if (datiBando!=null){
//FlagGeneraZIP = a true serve per sottomentere il batch di generazione zippone, ma in data 15/05/2013 si � deciso di attivarlo a mano 
//			datiBando.setFlagGeneraZIP("true");
			datiBando.setFlgValidaGrad("false");
			datiBandoHome.saveOrUpdate(datiBando);
		}
		
		
		return true;	
		
	}
	
	public void getTipoGraduatoriaMessage(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
		TipoGraduatoria   tipoGraduatoria        = new TipoGraduatoria();
		TipoGraduatoriaId tipoGraduatoriaId      = new TipoGraduatoriaId();
		TipoGraduatoriaHome tipoGraduatoriaHome  = new TipoGraduatoriaHome();
		
		tipoGraduatoria.setCodRegione(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
		tipoGraduatoriaId.setCodRegione(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
		tipoGraduatoria.setIdKey(tipoGraduatoriaId);
		List<TipoGraduatoria> listTipoGrad = new ArrayList<TipoGraduatoria>();
		listTipoGrad = tipoGraduatoriaHome.findByExample(tipoGraduatoria);
		
		
		if (listTipoGrad==null || listTipoGrad.size()==0){
			tipoGraduatoria.setCodTipologiaGraduatoria("1");
			graduatoriaExAequoBean.setValidaMessage("Definitiva");
		} else{
			tipoGraduatoria = listTipoGrad.get(listTipoGrad.size()-1);
			BigDecimal progressivo = new BigDecimal(""+tipoGraduatoria.getProgressivo());
			graduatoriaExAequoBean.setValidaMessage("Rettificata n�"+progressivo);
//			
//			if (tipoGraduatoria.getCodTipologiaGraduatoria().equals("1")){
//				graduatoriaExAequoBean.setValidaMessage("Rettificata");
//			}else {
//				BigDecimal progressivo = new BigDecimal(tipoGraduatoria.getProgressivo().intValue()+1);
//				graduatoriaExAequoBean.setValidaMessage("interpello n� "+(progressivo.intValue()-2));
//			}
		}
		
	}
	
	
	public String abilitaValidaGraduatorXStorico(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
		int maxSizeGradDefin =graduatoriaHome.searchCountIndiceTotale(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
		int maxSizeGrad      =maxElementGraduatoria;

		if (maxSizeGrad==maxSizeGradDefin){
//			int maxAexequoNonRisolti = definitivaHome.searchCountValida(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
			graduatoriaExAequoBean.setNumeroExAequoNonRisolti(graduatoriaHome.searchCountExaequoRisolto(graduatoriaExAequoBean.getUtenteReg().getCodRegione())) ;
			 
			if (graduatoriaExAequoBean.getNumeroExAequoNonRisolti()>0){
				return "true";
			}
				return "false";
		} else{
			return "true";
		}
	}

	public String abilitaPulsanteValidaGradXStorico(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
		int maxSizeGradDefin =graduatoriaHome.searchCountIndiceTotale(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
		int maxSizeGrad      =maxElementGraduatoria;

		if (maxSizeGrad==maxSizeGradDefin){
//			int maxAexequoNonRisolti = definitivaHome.searchCountValida(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
			graduatoriaExAequoBean.setNumeroExAequoNonRisolti(graduatoriaHome.searchCountExaequoRisolto(graduatoriaExAequoBean.getUtenteReg().getCodRegione())) ;
			 
			if (graduatoriaExAequoBean.getNumeroExAequoNonRisolti()>0){
				return "true";
			}
//controllo della per l'abilitazione del valida graduatoria che sia solo per definitiva e rettificata.
			return getValidaGraduatoria(graduatoriaExAequoBean);
		} else{
			return "true";
		}
	}

	
	
	private String  getValidaGraduatoria(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
		DatiBando bando = new DatiBando();
		DatiBandoHome datiBandoHome = new DatiBandoHome();
		bando = datiBandoHome.findById(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
		if (bando.getFlgValidaGrad()!=null){
				
			if (bando.getFlgValidaGrad().equalsIgnoreCase("true")){
				return "false";
			} else {
				return "true";
			}
		}
		
		return "true";
		
		
	}
	

	public boolean getRettificati(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
		return graduatoriaHome.getRettificatiRow(graduatoriaExAequoBean.getCodReg());

	}

//	public String abilitaValidaGraduatorXStorico(GraduatoriaExAequoBean graduatoriaExAequoBean) throws GestioneErroriException{
//		int maxSizeGradDefin =definitivaHome.searchCount(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
//		int maxSizeGrad      =maxElementGraduatoria;
//
//		if (maxSizeGrad==maxSizeGradDefin){
////			int maxAexequoNonRisolti = definitivaHome.searchCountValida(graduatoriaExAequoBean.getUtenteReg().getCodRegione());
//			return "false";
//		} else{
//			return "true";
//		}
//	}
		
	
	public void confermaGraduatoria(String codReg) throws GestioneErroriException{
	
		List<Graduatoria> graduatoriaList;
		    
		RisolviExAequo r = new RisolviExAequo();

		
		
		GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
		
		GraduatoriaDefinitiva graduatoriaDefinitiva;
		
		List<GraduatoriaDefinitiva> graduatoriaDefinitivaList = new ArrayList<GraduatoriaDefinitiva>();
		
		int posizione = 0;
		int j = 1;
		try {
			graduatoriaList = graduatoriaHome.findOrderByGraduatoria(codReg);
			//r.risolviexAequo(graduatoriaList);
			
			for(Graduatoria graduatoria : graduatoriaList){
				
				
				
				graduatoriaDefinitiva = new GraduatoriaDefinitiva();
				posizione++;
				if(graduatoria.getExAequoRisolto()!=null && !graduatoria.getExAequoRisolto().equals("T") ){
					graduatoriaDefinitiva.setIndiceTotale(new BigDecimal(j));
					graduatoriaDefinitiva.setIndiceRelativo(new BigDecimal(0));
				
					graduatoriaDefinitiva.setIdCandidatura(graduatoria.getIdCandidatura());
					graduatoriaDefinitiva.setCognome(graduatoria.getCognome());
					graduatoriaDefinitiva.setNome(graduatoria.getNome());
					graduatoriaDefinitiva.setPunteggio(graduatoria.getPunteggio());
					graduatoriaDefinitiva.setEtaMedia(graduatoria.getEtaMedia());
					graduatoriaDefinitiva.setDataNascita(graduatoria.getDataNascita());
					graduatoriaDefinitiva.setCodRegione(graduatoria.getCodRegione());
					graduatoriaDefinitiva.setNumeroProtocollo(graduatoria.getNumeroProtocollo());
					graduatoriaDefinitiva.setExAequo("T");
					graduatoriaDefinitiva.setExAequoRisolto("F");
					
					
					}else if(graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().equals("T") ){
						graduatoriaDefinitiva.setIndiceTotale(new BigDecimal(posizione));
						graduatoriaDefinitiva.setIndiceRelativo(new BigDecimal(0));
						graduatoriaDefinitiva.setExAequoRisolto("T");
						graduatoriaDefinitiva.setExAequo("T");
						graduatoriaDefinitiva.setIdCandidatura(graduatoria.getIdCandidatura());
						graduatoriaDefinitiva.setCognome(graduatoria.getCognome());
						graduatoriaDefinitiva.setNome(graduatoria.getNome());
						graduatoriaDefinitiva.setPunteggio(graduatoria.getPunteggio());
						graduatoriaDefinitiva.setEtaMedia(graduatoria.getEtaMedia());
						graduatoriaDefinitiva.setDataNascita(graduatoria.getDataNascita());
						graduatoriaDefinitiva.setCodRegione(graduatoria.getCodRegione());
						graduatoriaDefinitiva.setNumeroProtocollo(graduatoria.getNumeroProtocollo());
						j = posizione+1;
					}else{
						if((graduatoriaList.indexOf(graduatoria)-1)>0 && graduatoriaDefinitivaList.get(graduatoriaList.indexOf(graduatoria)-1)!=null &&  graduatoriaDefinitivaList.get(graduatoriaList.indexOf(graduatoria)-1).getExAequo()!=null && graduatoriaDefinitivaList.get(graduatoriaList.indexOf(graduatoria)-1).getExAequo().equals("T") && graduatoriaDefinitivaList.get(graduatoriaList.indexOf(graduatoria)-1).getExAequoRisolto()!=null && graduatoriaDefinitivaList.get(graduatoriaList.indexOf(graduatoria)-1).getExAequoRisolto().equalsIgnoreCase("F")){
							int count = graduatoriaList.indexOf(graduatoria)-1;
							do{
								
								//graduatoriaList.get(count).setIndiceRelativo(posizione);
								graduatoriaDefinitivaList.get(count).setIndiceRelativo(new BigDecimal(posizione-1));
								
								count--;
							}while(count>=0 && graduatoriaDefinitivaList.get(count)!=null && graduatoriaDefinitivaList.get(count).getExAequo()!=null && graduatoriaDefinitivaList.get(count).getExAequo().equals("T") && graduatoriaDefinitivaList.get(graduatoriaList.indexOf(graduatoria)-1).getExAequoRisolto()!=null && graduatoriaDefinitivaList.get(graduatoriaList.indexOf(graduatoria)-1).getExAequoRisolto().equalsIgnoreCase("F"));
						}
							
					//graduatoriaDefinitiva.setExAequoRisolto("T");
					//graduatoriaDefinitiva.setExAequo("T");
					graduatoriaDefinitiva.setIndiceTotale(new BigDecimal(posizione));
					graduatoriaDefinitiva.setIndiceRelativo(new BigDecimal(0));
					graduatoriaDefinitiva.setIdCandidatura(graduatoria.getIdCandidatura());
					graduatoriaDefinitiva.setCognome(graduatoria.getCognome());
					graduatoriaDefinitiva.setNome(graduatoria.getNome());
					graduatoriaDefinitiva.setPunteggio(graduatoria.getPunteggio());
					graduatoriaDefinitiva.setEtaMedia(graduatoria.getEtaMedia());
					graduatoriaDefinitiva.setDataNascita(graduatoria.getDataNascita());
					graduatoriaDefinitiva.setCodRegione(graduatoria.getCodRegione());
					graduatoriaDefinitiva.setNumeroProtocollo(graduatoria.getNumeroProtocollo());
					j = posizione+1;
					}
			
				graduatoriaDefinitivaList.add(graduatoriaDefinitiva);
				
				
				
			
				
			}
			
//			saveGraduatoria(graduatoriaDefinitivaList);
			
		} catch (GestioneErroriException e) {
			throw new GestioneErroriException("errore nella conferma della graduatoria");
		}
		
	}



	public int getMaxElementGraduatoria() {
		return maxElementGraduatoria;
	}



	public void setMaxElementGraduatoria(int maxElementGraduatoria) {
		this.maxElementGraduatoria = maxElementGraduatoria;
	}
	

}