package com.accenture.CCFarm.action;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;

import com.accenture.CCFarm.DAO.RequisitiMinimiReg;
import com.accenture.CCFarm.DAO.RequisitiMinimiRegHome;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.DAO.UtenteCandidaturaRegHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.RequisitiMinimiBean;
import com.accenture.CCFarm.utility.BigDecimalToIntConverter;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.IntToBigDecimalConverter;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.SQLDateToUtilDateConverter;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.TabellaDecodifica;
import com.accenture.CCFarm.utility.UtilDateToSQLDateConverter;

public class RequisitiMinimiAction
{
	private UtenteCandidaturaReg utenteCandidatura;
	private UtenteCandidaturaRegHome utenteCandidaturaHome;
	
	private RequisitiMinimiReg requisitiMinimi;
	private RequisitiMinimiRegHome requisitiMinimiHome;
	
	public RequisitiMinimiAction()
	{
		//inizializza i controller di Hibernate
		utenteCandidaturaHome=new UtenteCandidaturaRegHome();
		requisitiMinimiHome=new RequisitiMinimiRegHome();
		
		//registra convertitori aggiuntivi per BeanUtils
		//BigDecimal <--> Int
		ConvertUtils.register(new BigDecimalToIntConverter(),Integer.class);
		ConvertUtils.register(new IntToBigDecimalConverter(),BigDecimal.class);
		//SQL Date <--> Util Date
		ConvertUtils.register(new SQLDateToUtilDateConverter(),java.util.Date.class);
		ConvertUtils.register(new UtilDateToSQLDateConverter(),java.sql.Date.class);
	}
	
	//carica dati da db nel bean di pagina
	public boolean init(String idUtente,RequisitiMinimiBean requisitiMinimiBean) throws GestioneErroriException 
	{	
		if(requisitiMinimiBean==null)
			return false;
		try
		{
			//popola i campi relativi al bean "utente"
			utenteCandidatura=utenteCandidaturaHome.findById(idUtente);
			if(utenteCandidatura.getNazioneResidenzaUtente()==null || utenteCandidatura.getNazioneResidenzaUtente().equals("")){
				utenteCandidatura.setNazioneResidenzaUtente("IT");
			}
			if(utenteCandidatura.getCodiceFiscaleUtente()!=null && utenteCandidatura.getCodiceFiscaleUtente().startsWith("*"))
			{
				utenteCandidatura.setCodiceFiscaleUtente("N.D.");
			}
			//recupera idDomanda dall'istanza di "utente"
			String idDomanda=utenteCandidatura.getIdDomandaUtente();
			
			//popola i campi relativi al bean "RequisitiMinimi"
			requisitiMinimi=requisitiMinimiHome.findById(idDomanda);
		}
		catch(RuntimeException e)
		{
			e.printStackTrace();
			return false;
		}
		//copia i dati dai bean di hibernate al bean di pagina
		try
		{
			//copia campi dai bean del db al bean di pagina
			
			//se il bean "utente" � stato popolato
			if(utenteCandidatura!=null)
			{
				BeanUtils.copyProperties(requisitiMinimiBean,utenteCandidatura);
				
				//decodifica codice del documento
				TabellaDecodifica.getDocumentoIdentita();
				String tipoDocumento=TabellaDecodifica.decodificaDocumentoIdentita(utenteCandidatura.getTipoDocumento());
				
				//compone il campo "estremi documento d'identit�" della pagina a partire dai dati nel database
				/*requisitiMinimiBean.setEstremiDocumentoIdentitaUtente(tipoDocumento+": "+
																	  utenteCandidatura.getNumeroDoc()+","+
																	  utenteCandidatura.getEnteRilascioDoc()+" ("+
																	  StringUtil.dateToStringDDMMYYYY(utenteCandidatura.getDataRilascioDoc())+")");
																	  */
			}
			//se il bean "requisitiMinimi" � stato popolato
			if(requisitiMinimi!=null)
				BeanUtils.copyProperties(requisitiMinimiBean,requisitiMinimi);
			
			if(utenteCandidatura.getPrvNascitaUtente()!=null)
			{
				requisitiMinimiBean.setComuniSelect(Localita.getComuni(utenteCandidatura.getPrvNascitaUtente()));
				requisitiMinimiBean.setComuniNascitaList(requisitiMinimiBean.getComuniSelect().get(utenteCandidatura.getPrvNascitaUtente()));
			}
			if(utenteCandidatura.getPrvResidenzaUtente()!=null)
			{
				requisitiMinimiBean.setComuniSelect(Localita.getComuni(utenteCandidatura.getPrvResidenzaUtente()));
				requisitiMinimiBean.setComuniResidenzaList(requisitiMinimiBean.getComuniSelect().get(utenteCandidatura.getPrvResidenzaUtente()));
			}
			if(utenteCandidatura.getProvinciaListaElettorale()!=null)
			{
				requisitiMinimiBean.setComuniSelect(Localita.getComuni(utenteCandidatura.getProvinciaListaElettorale()));
				requisitiMinimiBean.setComuniElettoraliList(requisitiMinimiBean.getComuniSelect().get(utenteCandidatura.getProvinciaListaElettorale()));
			}
			
			//controlla regione selezionata: se corrisponde a Bolzano attiva il pannello opzionale della pagina
			String codiceRegione=(String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_REGIONE);
			if(codiceRegione!=null && codiceRegione.equals("041"))
				requisitiMinimiBean.setIsBolzano(true);
		}
		catch(IllegalAccessException  e)
		{
			e.printStackTrace();
			return false;
		}
		catch( InvocationTargetException e)
		{
			e.printStackTrace();
			return false;
		}
		
		return (utenteCandidatura!=null);// && (requisitiMinimi!=null);
	}
	
	//inserisce dati del bean di pagina nel db
	public boolean updateDAO(String idUtente,java.sql.Timestamp now,RequisitiMinimiBean requisitiMinimiBean)
	{
		//aggiorna
		utenteCandidatura.setLastUpdateDateUtente(now);
		utenteCandidatura.setLastUpdatedByUtente(idUtente);
		
		//se � la prima volta che si esegue un'aggiornamento, crea un record sulla tabella Requisiti Minimi
		//(qualora non ne esista gi� uno associato all'id utente corrente) 
		if(requisitiMinimi==null)
		{
			requisitiMinimi=new RequisitiMinimiReg(idUtente,
											    idUtente,
											    now,
											    idUtente,
											    now);
		}
		else
		{
			requisitiMinimi.setLastUpdatedByReq(idUtente);
			requisitiMinimi.setLastUpdateDateReq(now);
		}
		
		//preleva i dati dal bean di pagina e li copia nei bean del db
		try
		{	
			if(utenteCandidatura!=null)
				BeanUtils.copyProperties(utenteCandidatura,requisitiMinimiBean);

			if(requisitiMinimi!=null)
				BeanUtils.copyProperties(requisitiMinimi,requisitiMinimiBean);
		}
		catch(IllegalAccessException  e)
		{
			e.printStackTrace();
			return false;
		}
		catch(InvocationTargetException e)
		{
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	public UtenteCandidaturaReg getUtenteCandidatura() {
		return utenteCandidatura;
	}

	public void setUtenteCandidatura(UtenteCandidaturaReg utenteCandidatura) {
		this.utenteCandidatura = utenteCandidatura;
	}

	public RequisitiMinimiReg getRequisitiMinimi() {
		return requisitiMinimi;
	}

	public void setRequisitiMinimi(RequisitiMinimiReg requisitiMinimi) {
		this.requisitiMinimi = requisitiMinimi;
	}
}