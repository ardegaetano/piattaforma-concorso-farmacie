package com.accenture.CCFarm.action;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.CandidatoInterpello;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.exception.SediException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;

public class PredisponiInterpelloAction {
	
	private static final Logger log = CommonLogger.getLogger("PredisponiInterpelloAction");
	
	private InterpelloHome interpelloHome;
	private Interpello interpelloCorrente;
	
	private static final String codiceInterpelloPredisposto = AppProperties.getAppProperties().getProperty("codice.interpello.predisposto");
	private static final String codiceInterpelloPubblicato = AppProperties.getAppProperties().getProperty("codice.interpello.pubblicato");
	private static final String codiceInterpelloChiuso = AppProperties.getAppProperties().getProperty("codice.interpello.chiuso");
	
	public PredisponiInterpelloAction(String codiceRegione) throws GestioneErroriException {
		
		interpelloHome = new InterpelloHome();
		setInterpelloCorrente(
				interpelloHome.determinaInterpelloCorrente(codiceRegione)
		);
	}
	
	public boolean isInterpelloPredisposto() {
		
		return (getInterpelloCorrente() != null && 
				getInterpelloCorrente().getStato() != null &&
				getInterpelloCorrente().getStato().equalsIgnoreCase(codiceInterpelloPredisposto));
	}
	
	public boolean isInterpelloPubblicato() {
		
		return (getInterpelloCorrente() != null && 
				getInterpelloCorrente().getStato() != null &&
				getInterpelloCorrente().getStato().equalsIgnoreCase(codiceInterpelloPubblicato));
	}
	
	public boolean isInterpelloChiuso() {
		
		return (getInterpelloCorrente() == null || 
				(getInterpelloCorrente().getStato() != null &&
				 getInterpelloCorrente().getStato().equalsIgnoreCase(codiceInterpelloChiuso)));
	}
	
	//determina se c'� un interpello ancora in corso
	public boolean isInterpelloInCorso() {
		
		return isInterpelloPredisposto() || isInterpelloPubblicato();
	}
	
	public int getProgressivoInterpelloCorrente() {
		
		if(getInterpelloCorrente() == null)
			return -1;
		return getInterpelloCorrente().getId().getIdInterpello().intValue();
	}
	
	public Date getDataInizioInterpelloCorrente() {
		
		if(getInterpelloCorrente() == null)
			return null;
		return DateUtil.sqlTimestampToUtilDate((java.sql.Timestamp) getInterpelloCorrente().getDataInizio());
	}
	
	public Date getDataFineInterpelloCorrente() {
		
		if(getInterpelloCorrente() == null)
			return null;
		return DateUtil.sqlTimestampToUtilDate((java.sql.Timestamp) getInterpelloCorrente().getDataFine());
	}
	
	//determina elenco candidati interpello corrente
	public List<CandidatoInterpello> trovaCandidatiInterpelloCorrente() throws GestioneErroriException {
		
		try {
			
			return interpelloHome.trovaCandidatiInterpello(getInterpelloCorrente());
		}
		catch(Exception e) {
			
			log.error("PredisponiInterpelloAction - ricerca candidati interpello fallita", e);
			throw new GestioneErroriException("PredisponiInterpelloAction - ricerca candidati interpello fallita");
		}
	}
	
	//predisposizione nuovo interpello
	public void predisponiNuovoInterpello(String codiceRegione) throws GestioneErroriException, SediException {
		
		try {
			
			//inserimento nuovo interpello su DB
			setInterpelloCorrente(
					interpelloHome.predisponiNuovoInterpello(codiceRegione)
			);
		}
		catch(Exception e) {
			
			log.error("PredisponiInterpelloAction - predisposizione nuovo interpello fallita", e);
			
			if(e instanceof SediException)
				throw (SediException) e;
			else
				throw new GestioneErroriException("PredisponiInterpelloAction - predisposizione nuovo interpello fallita");
		}
	}
	
	//annulla interpello corrente
	public void annullaInterpelloPredisposto(String codiceRegione) throws GestioneErroriException {
		
		try {
			
			//inserimento dati nuovo interpello su DB
			interpelloHome.eliminaInterpello(getInterpelloCorrente());
			setInterpelloCorrente(
					interpelloHome.determinaInterpelloCorrente(codiceRegione)
			);
		}
		catch(Exception e) {
			
			log.error("PredisponiInterpelloAction - annullamento interpello predisposto fallito", e);
			throw new GestioneErroriException("PredisponiInterpelloAction - annullamento interpello predisposto fallito");
		}
	}
	
	//salvataggio dati interpello corrente
	public void salvaInterpelloCorrente(Date dataInizioInterpello, Date dataFineInterpello) throws GestioneErroriException {
		
		try {
			
			//aggiornamento dati interpello
			getInterpelloCorrente().setDataInizio(DateUtil.utilDateToSqlTimestamp(dataInizioInterpello));
			getInterpelloCorrente().setDataFine(DateUtil.utilDateToSqlTimestamp(dataFineInterpello));
			
			//inserimento interpello su DB
			setInterpelloCorrente(
					interpelloHome.salvaInterpello(getInterpelloCorrente())
			);
		}
		catch(Exception e) {
			
			log.error("PredisponiInterpelloAction - salvataggio interpello corrente fallito", e);
			throw new GestioneErroriException("PredisponiInterpelloAction - salvataggio interpello corrente fallito");
		}
	}
	
	//pubblicazione interpello corrente
	public void pubblicaInterpelloCorrente(Date dataInizioInterpello, Date dataFineInterpello) throws GestioneErroriException {
		
		try {
			
			//aggiornamento dati interpello
			getInterpelloCorrente().setDataInizio(DateUtil.utilDateToSqlTimestamp(dataInizioInterpello));
			getInterpelloCorrente().setDataFine(DateUtil.utilDateToSqlTimestamp(dataFineInterpello));
			
			//demarcazione interpello come "pubblicato"
			setInterpelloCorrente(
					interpelloHome.pubblicaInterpello(getInterpelloCorrente())
			);
		}
		catch(Exception e) {
			
			log.error("PredisponiInterpelloAction - pubblicazione interpello corrente fallita", e);
			throw new GestioneErroriException("PredisponiInterpelloAction - pubblicazione interpello corrente fallita");
		}
	}

	private Interpello getInterpelloCorrente() {
		return interpelloCorrente;
	}

	private void setInterpelloCorrente(Interpello interpelloCorrente) {
		this.interpelloCorrente = interpelloCorrente;
	}
	
}