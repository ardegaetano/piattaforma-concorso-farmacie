package com.accenture.CCFarm.action;


import java.util.ArrayList;
import java.util.List;

import com.accenture.CCFarm.Bean.StoricoGraduatoriaLazyList;
import com.accenture.CCFarm.DAO.StoricoGraduatoria;
import com.accenture.CCFarm.DAO.StoricoGraduatoriaHome;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.RicercaStoricoGraduatoria;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.StringUtil;

import org.apache.log4j.Logger;


	public class RicercaStoricoGraduatoriaAction{
		
	    Logger logger = CommonLogger.getLogger("RicercaCandidatoAction");
	    String pageError = "errorPage.jsf";
	
		public RicercaStoricoGraduatoriaAction(){
			
		}
	


	public int findCount(String cod_reg, String tipoGrad, String primo, String ultimo, String dataValid) throws GestioneErroriException {
		
		int totaleSchede;
		StoricoGraduatoriaHome storicoGraduatoriaHome = new StoricoGraduatoriaHome();	
		
		if (primo!=null && !primo.equalsIgnoreCase("") && ultimo!=null && !ultimo.equalsIgnoreCase("")  ){	
			totaleSchede = storicoGraduatoriaHome.findCount(cod_reg,tipoGrad,Integer.parseInt(primo),Integer.parseInt(ultimo),dataValid);			
		}
		else {
			totaleSchede = storicoGraduatoriaHome.findCount(cod_reg,tipoGrad,0,0,dataValid);
		}
		
		return totaleSchede ;
	}


	public List findTipologieGraduatorie(String cod_reg) throws GestioneErroriException {
		List<TipoGraduatoria> tipoGraduatoriaList = new ArrayList<TipoGraduatoria>();
		StoricoGraduatoriaHome storicoGraduatoriaHome = new StoricoGraduatoriaHome();
		StoricoGraduatoria storicoGraduatoria = new StoricoGraduatoria();
		storicoGraduatoria.setCodRegione(cod_reg);
		tipoGraduatoriaList = storicoGraduatoriaHome.findTipologieGraduatorie(cod_reg);
		
		return tipoGraduatoriaList ;
	}


	public String findDataValid(String cod_reg, String codiceGraduatoria) throws GestioneErroriException {
		 String dataVal="";
		 List<StoricoGraduatoria> lista ;
		StoricoGraduatoriaHome storicoGraduatoriaHome = new StoricoGraduatoriaHome();
		StoricoGraduatoria storicoGraduatoria = new StoricoGraduatoria();
		storicoGraduatoria.setCodRegione(cod_reg);
		storicoGraduatoria.setnProgressivo(codiceGraduatoria);		
	    lista = storicoGraduatoriaHome.findByExample(storicoGraduatoria);
	    if (!lista.isEmpty())
	    dataVal = StringUtil.dateToStringDDMMYYYY(lista.get(0).getDataValidazione());
		
		return dataVal ;
	}
	
	
	public List<StoricoGraduatoria> getPageStoricoGraduatoria(RicercaStoricoGraduatoria ricercaStoricoGraduatoria , int startPage, int maxPerPage, String cod_reg) throws GestioneErroriException{
		
		List<StoricoGraduatoria> listaStoricoGraduatoria ;
		StoricoGraduatoriaHome storicoGraduatoriaHome = new StoricoGraduatoriaHome();
		listaStoricoGraduatoria = new ArrayList<StoricoGraduatoria>();
				
		if (ricercaStoricoGraduatoria.getNumeroPosInizialeString()!=null && !ricercaStoricoGraduatoria.getNumeroPosInizialeString().equalsIgnoreCase("") && 
				ricercaStoricoGraduatoria.getNumeroPosFinaleString()!=null && !ricercaStoricoGraduatoria.getNumeroPosFinaleString().equalsIgnoreCase("") &&	ricercaStoricoGraduatoria.getCodiceGraduatoria()!=-1 
				){			
			listaStoricoGraduatoria = storicoGraduatoriaHome.findLazyListStoricoGraduatoria(startPage, maxPerPage, cod_reg, Integer.parseInt(ricercaStoricoGraduatoria.getNumeroPosInizialeString()), Integer.parseInt(ricercaStoricoGraduatoria.getNumeroPosFinaleString()), "" + ricercaStoricoGraduatoria.getCodiceGraduatoria() ,ricercaStoricoGraduatoria.getDataValidazioneString());
		}
		else {
			listaStoricoGraduatoria = storicoGraduatoriaHome.findLazyListStoricoGraduatoria(startPage, maxPerPage, cod_reg, 1, ricercaStoricoGraduatoria.getTotaleSchede(),"" + ricercaStoricoGraduatoria.getCodiceGraduatoria() ,ricercaStoricoGraduatoria.getDataValidazioneString());
		}
		
		return listaStoricoGraduatoria;
	}

	
	
}