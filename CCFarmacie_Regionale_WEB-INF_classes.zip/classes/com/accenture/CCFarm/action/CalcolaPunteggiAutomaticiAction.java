package com.accenture.CCFarm.action;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.accenture.CCFarm.DAO.CriteriPunteggi;
import com.accenture.CCFarm.DAO.CriteriPunteggiHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.exception.GestioneErroriException;


public class CalcolaPunteggiAutomaticiAction{
	

	public CalcolaPunteggiAutomaticiAction(){
		
	}
	
	
  public String[] checkElaborazione(String codReg)throws GestioneErroriException{
		
	    String[] messaggi=new String[3];
		String abilita_pulsante="";
		String descrizione="";
		String esito_calcolo="";
		
		try{
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			DatiBando datiBando = new DatiBando();
			datiBando = datiBandoHome.findById(codReg);	
			
			if ((datiBando.getFlgPrenota()==null) || (datiBando.getFlgPrenota().equalsIgnoreCase("false"))){
				abilita_pulsante="true";
				descrizione="Per prenotare la preparazione delle schede di valutazione, selezionare il pulsante \"Preparazione schede di valutazione\".";
				esito_calcolo="";
			}
			
			if ((datiBando.getFlgPrenota()!=null && datiBando.getFlgPrenota().equalsIgnoreCase("true")) &&
				((datiBando.getFlgPrecalcolato()==null || datiBando.getFlgPrecalcolato().equalsIgnoreCase("false"))
				||(datiBando.getFlgPrecalcolato()!=null && datiBando.getFlgPrecalcolato().equalsIgnoreCase("true"))))				
				
			{
				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				Date date = new Date();
				abilita_pulsante="false";
				descrizione="La preparazione delle schede di valutazione sar� eseguita in data "+dateFormat.format(date)+" dopo le ore 19.00."
				+ "  Eventuali modifiche manuali sulle candidature, verranno sovrascritte.";
				esito_calcolo="";
			}
		
			if ((datiBando.getFlgPrenota()!=null && datiBando.getFlgPrenota().equalsIgnoreCase("true")) &&
				(datiBando.getFlgPrecalcolato()!=null && datiBando.getFlgPrecalcolato().equalsIgnoreCase("true")) &&
				(datiBando.getFlgScarti()==null))
			{
				abilita_pulsante="false";
				descrizione="La preparazione delle schede di valutazione � in esecuzione";
				esito_calcolo="";
			}
			
			if ((datiBando.getFlgPrenota()!=null && datiBando.getFlgPrenota().equalsIgnoreCase("false")) &&
				(datiBando.getFlgPrecalcolato()!=null && datiBando.getFlgPrecalcolato().equalsIgnoreCase("true")) &&
				(datiBando.getFlgScarti()!=null && datiBando.getFlgScarti().equalsIgnoreCase("false")))
			{
				abilita_pulsante="true";
				descrizione="";
				esito_calcolo="Calcolo eseguito con successo";
			}
			
			if ((datiBando.getFlgPrenota()!=null && datiBando.getFlgPrenota().equalsIgnoreCase("false")) &&
				(datiBando.getFlgPrecalcolato()!=null && datiBando.getFlgPrecalcolato().equalsIgnoreCase("true")) &&
				(datiBando.getFlgScarti()!=null && datiBando.getFlgScarti().equalsIgnoreCase("true"))){
				abilita_pulsante="true";
				descrizione="";
				esito_calcolo="Calcolo eseguito con errori. Contattare l�assistenza tecnica.";
			}
					
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new GestioneErroriException("errore nel controllo del prenota calcolo");
		}
			
		messaggi[0]=abilita_pulsante;
		messaggi[1]=descrizione;
		messaggi[2]=esito_calcolo;
		
		return messaggi;
	}
	

    public String checkCaricamentoPunteggi(String codReg) throws GestioneErroriException{
    	
    	String PunteggiCaricati="false";
    	CriteriPunteggiHome criteriPunteggiHome = new CriteriPunteggiHome();
    	CriteriPunteggi criteriPunteggi = new CriteriPunteggi();
    	List<CriteriPunteggi> listaPunteggiLauree;
    	List<CriteriPunteggi> listaPunteggiAbilitazione;
    	
    	try {
    		criteriPunteggi.setIdRegione(codReg);
    		criteriPunteggi.setTipoTitolo("1");
    		listaPunteggiLauree = criteriPunteggiHome.findByExample(criteriPunteggi);
    		criteriPunteggi.setTipoTitolo("2");
    		listaPunteggiAbilitazione = criteriPunteggiHome.findByExample(criteriPunteggi);
        	if (listaPunteggiLauree!=null && listaPunteggiAbilitazione!=null && !listaPunteggiAbilitazione.isEmpty() && !listaPunteggiLauree.isEmpty()) PunteggiCaricati="true";
    	}
    	catch(Exception e){    		
    		e.printStackTrace();
			throw new GestioneErroriException("errore nel controllo caricamento criteri punteggi");
    	}
    	
    	return PunteggiCaricati;
    }
	
	public void prenotaCalcolo(String codReg) throws GestioneErroriException{
		
		try{
			
				DatiBandoHome datiBandoHome = new DatiBandoHome();
				DatiBando datiBando = new DatiBando();
				datiBando = datiBandoHome.findById(codReg);	
				datiBando.setFlgPrenota("true");
				datiBandoHome.saveOrUpdate(datiBando);
	
			}
			catch(Exception e){
				e.printStackTrace();
				throw new GestioneErroriException("errore nell'aggiornamento flag prenota calcolo");
			}
		
	}
	
}