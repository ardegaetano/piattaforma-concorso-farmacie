package com.accenture.CCFarm.action;

import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.DatiUtenza;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;

public class EscludiInterpellatoService {
	
	private static final Logger logger = CommonLogger.getLogger("EscludiInterpellatoService");
	private UtenteHome utenteHome;
	private LogInHome loginHome;
	
	
	
	public EscludiInterpellatoService() throws GestioneErroriException {
		
		try {
			utenteHome = new UtenteHome();
		}
		catch(Exception e) {
			logger.error("GestioneUtenzeAction - inizializzazione fallita", e);
			throw new GestioneErroriException("GestioneUtenzeAction - inizializzazione fallita");
		}
		
	}
	
	public List<DatiUtenza> ricercaUtenteInterpellato(DatiUtenza datiUtenza) throws GestioneErroriException {
		List<DatiUtenza> elencoUtenti = utenteHome.ricercaUtenteInterpello(datiUtenza);
		return elencoUtenti;
	}
	
	public boolean escludiUtenteInterpellato(DatiUtenza datiUtenza, String idCandidaturaSelezionata, String idOperatore) throws GestioneErroriException {
		boolean utenteEscluso = utenteHome.escludiUtenteInterpello(datiUtenza,idCandidaturaSelezionata,idOperatore);
		return utenteEscluso;
	}


}
