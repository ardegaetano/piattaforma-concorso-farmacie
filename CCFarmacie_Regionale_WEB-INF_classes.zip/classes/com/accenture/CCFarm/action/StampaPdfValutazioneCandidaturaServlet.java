package com.accenture.CCFarm.action;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.PDFModulo.GestionePDFRiepilogoValutazione;
import com.accenture.CCFarm.PDFModulo.GestionePDFStampaElenco;
import com.accenture.CCFarm.pageBean.ElaboraGraduatoria;
import com.accenture.CCFarm.pageBean.SchedaValutazioneBean;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;

public class StampaPdfValutazioneCandidaturaServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	Logger logger = CommonLogger.getLogger("StampaPdfValutazioneCandidaturaServlet");

	

	public StampaPdfValutazioneCandidaturaServlet() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
		// 
		super.init();
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


    	try {	
    		HttpSession session = null;
	    	
    		session = request.getSession();
//			ElaboraGraduatoria elaboraGraduatoriaBean = (ElaboraGraduatoria) session.getAttribute("elaboraGraduatoria");
//			
//			elaboraGraduatoriaBean.getRicercaSchedeValutazione();
    		
			
			SchedaValutazioneBean schedaValutazioneBean = new  SchedaValutazioneBean();
	    	
	    	GestionePDFRiepilogoValutazione gestionePDFRiepilogoValutazione = new GestionePDFRiepilogoValutazione();
	    	
	    	gestionePDFRiepilogoValutazione.caricaDatiPerEntityPDF(schedaValutazioneBean);
	    	gestionePDFRiepilogoValutazione.creaRicevutaPDF();
 		    
 		    byte[] pdfData = gestionePDFRiepilogoValutazione.getImgStampaElencoPDF();
 	    	try
 	    	{
	            response.reset(); 
 	            response.setContentType("application/pdf"); 
 	            response.setContentLength((int) pdfData.length); 
 	            response.setHeader("Content-disposition", "attachment; filename=\"riepilogoValutazioneCandidatura.pdf\"");
 	            ByteArrayInputStream in = null;             
 	            BufferedInputStream input = null; 
 	            BufferedOutputStream output = null; 
 	            final int buffersize = (int) pdfData.length; 
 	            try 
 	            { 
 	            	in = new ByteArrayInputStream(pdfData);
 	            	input = new BufferedInputStream(in); 
 	            	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
 	            	byte[] buffer = new byte[buffersize]; 
 	            	for (int length; (length = input.read(buffer)) > 0;) 
 	            	{	 
 	            		output.write(buffer, 0, length); 
 	            		output.flush();
 	            	}            	
 	            } 
 	            finally 
 	            { 
 	            	if (input != null) 
 	            		try 
 	            		{ 
 	            			input.close(); 
 	            			output.close();
 	            		} 
 	            		catch (IOException e) 
 	            		{ 
 	            			e.printStackTrace(); 
 	            		} 
 	            } 
// 	            facesContext.responseComplete(); 

 	    	}
 	    	catch (IOException e)
 	    	{
 	    		e.printStackTrace();
 	    	}
    	
    	} catch (Exception e) {
 			logger.error(" stampaPdfValutazioneCandidaturaServlet - caricaDatiPerEntityPDF: " + e.getMessage());
// 			JSFUtility.redirect("er);
 			response.sendRedirect(AppProperties.getAppProperties().getProperty("BaseUrl")+"/jsp/errorPage.jsf");
 			//response.sendRedirect(AppProperties.getAppProperties().getProperty("BaseUrl")+"/jsp/errorDownLoadStampaElenco.jsf");
 			
 		} 
 		
	
    	
	
	
	}

}
