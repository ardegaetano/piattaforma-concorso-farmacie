package com.accenture.CCFarm.action;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.accenture.CCFarm.Bean.Ruolo;
import com.accenture.CCFarm.Bean.UtenteEspProf;
import com.accenture.CCFarm.Bean.UtenteOsservazioni;
import com.accenture.CCFarm.Bean.UtenteTitoli;
import com.accenture.CCFarm.DAO.AltraLaureaBisReg;
import com.accenture.CCFarm.DAO.AltraLaureaBisRegHome;
import com.accenture.CCFarm.DAO.AltraLaureaBisRegStorico;
import com.accenture.CCFarm.DAO.AltraLaureaReg;
import com.accenture.CCFarm.DAO.AltraLaureaRegHome;
import com.accenture.CCFarm.DAO.AltraLaureaRegStorico;
import com.accenture.CCFarm.DAO.AltroTitoloReg;
import com.accenture.CCFarm.DAO.AltroTitoloRegHome;
import com.accenture.CCFarm.DAO.AltroTitoloRegStorico;
import com.accenture.CCFarm.DAO.AltroTitoloRegStoricoId;
import com.accenture.CCFarm.DAO.BorsaStudioReg;
import com.accenture.CCFarm.DAO.BorsaStudioRegHome;
import com.accenture.CCFarm.DAO.BorsaStudioRegStorico;
import com.accenture.CCFarm.DAO.BorsaStudioRegStoricoId;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoReg;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoRegHome;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoRegStorico;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoRegStoricoId;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.DottoratoReg;
import com.accenture.CCFarm.DAO.DottoratoRegHome;
import com.accenture.CCFarm.DAO.DottoratoRegStorico;
import com.accenture.CCFarm.DAO.DottoratoRegStoricoId;
import com.accenture.CCFarm.DAO.EsercizioProfReg;
import com.accenture.CCFarm.DAO.EsercizioProfRegHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.GraduatoriaStorico;
import com.accenture.CCFarm.DAO.IdoneitaReg;
import com.accenture.CCFarm.DAO.IdoneitaRegHome;
import com.accenture.CCFarm.DAO.IdoneitaRegStorico;
import com.accenture.CCFarm.DAO.PubblicazioneReg;
import com.accenture.CCFarm.DAO.PubblicazioneRegHome;
import com.accenture.CCFarm.DAO.PubblicazioneRegStorico;
import com.accenture.CCFarm.DAO.PubblicazioneRegStoricoId;
import com.accenture.CCFarm.DAO.RequisitiMinimiReg;
import com.accenture.CCFarm.DAO.RequisitiMinimiRegHome;
import com.accenture.CCFarm.DAO.RequisitiMinimiRegStorico;
import com.accenture.CCFarm.DAO.SpecializzazioneReg;
import com.accenture.CCFarm.DAO.SpecializzazioneRegHome;
import com.accenture.CCFarm.DAO.SpecializzazioneRegStorico;
import com.accenture.CCFarm.DAO.SpecializzazioneRegStoricoId;
import com.accenture.CCFarm.DAO.Titoli;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.SchedaValutazioneBean;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CaricaOsservazioni;
import com.accenture.CCFarm.utility.CaricaRuoli;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.mailer.concorsofarma.logger.CommonLogger;
import com.accenture.punteggi.esperienze.RisultatiValutazioneEsperienze;
import com.accenture.punteggi.esperienze.bean.in.EsperienzaOriginal;

public class CalcoloTitoliAction {
	
	private static final Logger logger = CommonLogger.getLogger("CalcoloTitoliAction");
	
	private List<Ruolo> ruoli;
	
	private HashMap hmRuoli;
	
	private static final String flagValoreVero  = AppProperties.getAppProperties().getProperty("flag.valore.vero");
	
	String titoli[] = new String[9];
	
	public String totaleTitolo[];

	public BigDecimal parzialeSpecDottBors;
	
	public BigDecimal parzialePubblicazioni;
	
	public BigDecimal parzialeAbiCorsoAltri;
	
	public BigDecimal totaleLaurea;
	
	public BigDecimal totaleSecondaLaurea;
	
	public BigDecimal totaleSecondaLaureaBis;
	
	public BigDecimal totaleSpecBorseDottorato;
	
	public BigDecimal totalePubblicazioni;
	
	public BigDecimal totaleIdoneitaPrecedenteConcorso;
	
	public BigDecimal totaleIdoneitaNazionale;
	
	public BigDecimal totaleAbiCorsoAltri;

	public BigDecimal totaleEspProf;
	
	public BigDecimal totaleTitoli;
	//reset 
	 RequisitiMinimiRegHome requisitiMinimiRegHome;
	
	AltraLaureaRegHome altraLaureaRegHome; 
	
	AltraLaureaBisRegHome altraLaureaBisRegHome;
	
	SpecializzazioneRegHome specilaizzazioneRegHome;
	
	DottoratoRegHome dottoratoRegHome;
	
	BorsaStudioRegHome borsaStudioRegHome;
	
	PubblicazioneRegHome pubblicazioneRegHome;

	IdoneitaRegHome idoneitaRegHome;
	
	CorsoAggiornamentoRegHome corsoAggiornamentoRegHome;
	
	AltroTitoloRegHome altroTitoloRegHome;
	
	EsercizioProfRegHome esercizioProfRegHome;
	
	GraduatoriaHome graduatoriaHome;
	
	Graduatoria graduatoria;
	
	DatiBando datiBando;
	
	DatiBandoHome datiBandoHome;
	
	int dataIdoneita;
	
	int dataIdoneitaNazionale;
	
	
	
	List<Graduatoria> graduatoriaListExAequoRisolti = new ArrayList<Graduatoria>();
	Graduatoria graduatoriaExAequoRisolti = new Graduatoria();
	List<Graduatoria> exEaequoRisoliToDelete;
	List<Graduatoria> exEaequoRisoltiToResolved;
	public CalcoloTitoliAction() {
		titoli[0] = "A-Laurea principale";
		titoli[1] = "D-Seconda laurea in farmacia o CTF";
		titoli[2] = "B-Altre Lauree";
		titoli[3] = "C-Specializzazioni-Borse di studio o di ricerca";
		titoli[4] = "E-Pubblicazioni Scientifiche";
		titoli[5] = "F-Idoneit� precedente concorso";
		titoli[6] = "G-Idoneit� nazionale farmacista dirigente";
		titoli[7] = "H-Voto di abilitazione e corsi di aggiornamento ";
		titoli[8] = "Altri Titoli";
		totaleTitolo = new String[8];
		
		requisitiMinimiRegHome = new RequisitiMinimiRegHome();
		
		altraLaureaRegHome = new AltraLaureaRegHome();
		
		altraLaureaBisRegHome = new AltraLaureaBisRegHome();
		
		specilaizzazioneRegHome = new SpecializzazioneRegHome();
		
		dottoratoRegHome = new DottoratoRegHome();
		
		borsaStudioRegHome = new BorsaStudioRegHome();
		
		pubblicazioneRegHome = new PubblicazioneRegHome();
		
		idoneitaRegHome = new IdoneitaRegHome();
		
		corsoAggiornamentoRegHome = new CorsoAggiornamentoRegHome();
		
		altroTitoloRegHome = new AltroTitoloRegHome();
		
		esercizioProfRegHome = new EsercizioProfRegHome();
		
		graduatoriaHome = new GraduatoriaHome();
		
		dataIdoneitaNazionale = (int)System.currentTimeMillis();

	}

	public void  calcolaTitoli(SchedaValutazioneBean schedaValutazioneBean) throws GestioneErroriException{
		
		totaleLaurea = new BigDecimal(0);
		totaleSecondaLaurea = new BigDecimal(0);
		totaleSecondaLaureaBis = new BigDecimal(0);
		totaleSpecBorseDottorato = new BigDecimal(0);
		totalePubblicazioni = new BigDecimal(0);
		totaleIdoneitaPrecedenteConcorso = new BigDecimal(0);
		totaleIdoneitaNazionale = new BigDecimal(0);
		totaleAbiCorsoAltri = new BigDecimal(0);
		totaleTitoli= new BigDecimal(0);
		
		
		List<RequisitiMinimiReg> requisitiMinimiRegList;
		
		List<AltraLaureaReg> altraLaureaRegList;
		
		List<AltraLaureaBisReg> altraLaureaBisList;
		
		List<SpecializzazioneReg> specializzazioneRegList;
		
		List<DottoratoReg> dottoratoRegList;
		
		List<BorsaStudioReg> borsaStudioRegList;
		
		List<PubblicazioneReg> pubblicazioniRegList;
		
		List<IdoneitaReg> idoneitaRegList;
		
		List<CorsoAggiornamentoReg> corsoAggiornamentoRegList;
		
		List<AltroTitoloReg> altroTitoloRegList;
		
		List<UtenteTitoli> utenteTitoliList;
		
		//HashMap<String[], UtenteTitoli[]> utenteTitoliMapArray = new HashMap<String[], UtenteTitoli[]>();
		try {
			
			utenteTitoliList = new ArrayList<UtenteTitoli>();
			//Titoli titoliArray[] = new Titoli[utenteCandidaturaList.size()];
			//UtenteCandidatura utenteArray[] = new UtenteCandidatura[utenteCandidaturaList.size()];
			
			if(schedaValutazioneBean.getUtenteCandidaturaList().size()>0){
				
				UtenteTitoli utenteTitoli;
				Titoli titolo;
				
				
				for(UtenteCandidaturaReg u : schedaValutazioneBean.getUtenteCandidaturaList()){
					
					parzialeSpecDottBors = new BigDecimal(0);
					parzialePubblicazioni = new BigDecimal(0);
					parzialeAbiCorsoAltri = new BigDecimal(0);
					
					utenteTitoli = new UtenteTitoli();
					titolo = new Titoli();
					
					requisitiMinimiRegList = new ArrayList<RequisitiMinimiReg>();
				
					//punteggio laurea
					
					requisitiMinimiRegList.add(requisitiMinimiRegHome.findById(u.getIdUtente()));
					
					titolo.setRequisitiMinimiReg(requisitiMinimiRegList);
					titolo.parzialeTitolo[0]="0";
					for(RequisitiMinimiReg requisitiMinimiReg: requisitiMinimiRegList){
						
						//voto abilitazione
						parzialeAbiCorsoAltri = parzialeAbiCorsoAltri.add(requisitiMinimiReg.getPunteggioAbilitazione()==null?new BigDecimal("0"):requisitiMinimiReg.getPunteggioAbilitazione());
						
						if(requisitiMinimiReg.getPunteggioLaurea()!=null){
							titolo.parzialeTitolo[0] = requisitiMinimiReg.getPunteggioLaurea().toString().replace(".",",");
							totaleLaurea = totaleLaurea.add( requisitiMinimiReg.getPunteggioLaurea());
						}
						
						
						
						
						if(totaleLaurea.compareTo(new BigDecimal("5.0000"))>0){
							totaleLaurea = new BigDecimal("5.0000");
						}
						
						if(requisitiMinimiReg.getPunteggioLaurea()!=null&&requisitiMinimiReg.getPunteggioLaurea().compareTo(new BigDecimal(0))==0){
							titolo.color[0] = "#F91307;";
						}
											
						if(requisitiMinimiReg.getPunteggioAbilitazione()!=null&&requisitiMinimiReg.getPunteggioAbilitazione().compareTo(new BigDecimal(0))==0){
							
							titolo.color[7] = "#F91307;";
						}
						
						
					}
					
					altraLaureaRegList = new ArrayList<AltraLaureaReg>();
					//punteggio seconda laurea in farmacia o CTF 
					AltraLaureaReg altraLaureaReg = altraLaureaRegHome.findById(u.getIdUtente());
					titolo.parzialeTitolo[1] ="0";
					if (altraLaureaReg!=null){
						if(altraLaureaReg.getPunteggio()!=null&&altraLaureaReg.getPunteggio().compareTo(new BigDecimal(0))==0){
							
							titolo.color[1] = "#F91307;";
						}else{
							altraLaureaReg.setPunteggio(new BigDecimal("1.5"));
						}
						altraLaureaRegList.add(altraLaureaReg);
						titolo.setAltraLaureaReg(altraLaureaRegList);
						titolo.parzialeTitolo[1] =altraLaureaReg.getPunteggio().toString().replace(".",",");						
						totaleSecondaLaurea = totaleSecondaLaurea.add(altraLaureaReg.getPunteggio());
						if(totaleSecondaLaurea.compareTo(new BigDecimal("1.5"))>0){
							
							totaleSecondaLaurea = new BigDecimal("1.5000");
						}
						
					}else{
						titolo.color[1]="#09EA10";
					}
					
					
					//punteggio altre laure in medicina � veterinaria-chimica- scienze biologiche
					AltraLaureaBisReg altraLaureaBisReg = new AltraLaureaBisReg();
					altraLaureaBisReg.setIdDomandaLaureaBis(u.getIdUtente());
					
					altraLaureaBisList = (List<AltraLaureaBisReg>) altraLaureaBisRegHome.findByExample(altraLaureaBisReg);
					
					titolo.parzialeTitolo[2] = "0";
					if (altraLaureaBisList!=null && !altraLaureaBisList.isEmpty()){
						
						for(AltraLaureaBisReg altrLaureaBisReg : altraLaureaBisList){
							if(altrLaureaBisReg.getPunteggio()==null){
								altrLaureaBisReg.setPunteggio(new BigDecimal("3.5"));
								
							}
							totaleSecondaLaureaBis = totaleSecondaLaureaBis.add(altrLaureaBisReg.getPunteggio());
							
						}
						if(totaleSecondaLaureaBis.compareTo(new BigDecimal("3.5"))>0){
							
							totaleSecondaLaureaBis = new BigDecimal("3.5000");
						}
						
						if(totaleSecondaLaureaBis.compareTo(new BigDecimal("0"))==0){
							titolo.color[2]="#F91307";
						}
						titolo.parzialeTitolo[2] = totaleSecondaLaureaBis.toString().replace(".", ",");
						titolo.setAltraLaureaBisReg(altraLaureaBisList);
					}else{
						titolo.color[2]="#09EA10";
					}
					
					//inizio calcolo Pubblicazioni
					titolo.parzialeTitolo[4] = "0";
					pubblicazioniRegList = (List<PubblicazioneReg>) pubblicazioneRegHome.findByExample(new PubblicazioneReg(u.getIdUtente()));
					if(pubblicazioniRegList!=null && !pubblicazioniRegList.isEmpty()){
						titolo.setPubblicazioneReg(pubblicazioniRegList);
						for(PubblicazioneReg pubblicazioneReg: pubblicazioniRegList){
							parzialePubblicazioni = parzialePubblicazioni.add(pubblicazioneReg.getPunteggio() == null ? new BigDecimal(0) : pubblicazioneReg.getPunteggio());
						}
						
						titolo.parzialeTitolo[4] = parzialePubblicazioni.toString().replace(".", ",");
					}else{
						titolo.color[4]="#09EA10";
					}
					
					totalePubblicazioni = totalePubblicazioni.add(parzialePubblicazioni);
					if(totalePubblicazioni.compareTo(new BigDecimal("1.0000"))>0){
						totalePubblicazioni = new BigDecimal("1.0000");
					}
					//fine calcolo Pubblicazioni
					
					//inizio calcolo idoneit�
					titolo.parzialeTitolo[5]="0";
					titolo.parzialeTitolo[6]="0";
					
					
					IdoneitaReg idoneitaReg = idoneitaRegHome.findById(u.getIdUtente());
					idoneitaRegList = new ArrayList<IdoneitaReg>();
					if(idoneitaReg!=null){
				
						
						if(idoneitaReg.getEstremiIdoneita()!=null && !idoneitaReg.getEstremiIdoneita().equals("") ){
								if(idoneitaReg.getPunteggio()==null){
									idoneitaReg.setPunteggio(new BigDecimal("1"));
								}
								titolo.parzialeTitolo[5] = idoneitaReg.getPunteggio().toString();
								totaleIdoneitaPrecedenteConcorso = totaleIdoneitaPrecedenteConcorso.add(idoneitaReg.getPunteggio());
								if(idoneitaReg.getPunteggio().compareTo(new BigDecimal(0))==0){
									titolo.color[5]="#F91307";
								}
								if(totaleIdoneitaPrecedenteConcorso.compareTo(new BigDecimal(1))>0){
									totaleIdoneitaPrecedenteConcorso = new BigDecimal(1);
								}
							}else{
								titolo.color[5]="#09EA10";
								idoneitaReg.setPunteggio(new BigDecimal("0"));
							}
							
							if(idoneitaReg.getRifIdoneitaNazionale()!=null && !idoneitaReg.getRifIdoneitaNazionale().equals("")){
								if(idoneitaReg.getAnnoIdoneitaNazionale()!=null){
									dataIdoneitaNazionale = Integer.parseInt(idoneitaReg.getAnnoIdoneitaNazionale());
									if(dataIdoneitaNazionale<=Integer.parseInt(AppProperties.getAppProperties().getProperty("annoValiditaIdoneitaNaz"))){
										
										if(idoneitaReg.getPunteggioNaz()==null){
											idoneitaReg.setPunteggioNaz(new BigDecimal("1"));
										}
										titolo.parzialeTitolo[6] = idoneitaReg.getPunteggioNaz().toString();
										totaleIdoneitaNazionale = totaleIdoneitaNazionale.add(idoneitaReg.getPunteggioNaz());
										if( idoneitaReg.getPunteggioNaz().compareTo(new BigDecimal(0))==0){
											titolo.color[6]="#F91307";
										}
										if(totaleIdoneitaNazionale.compareTo(new BigDecimal(1))>0){
											totaleIdoneitaNazionale = new BigDecimal(1);
										}
									}else{
										titolo.color[6]="#F91307";
										idoneitaReg.setPunteggioNaz(new BigDecimal("0"));
									}
								}
								
								
								
							}else{
								titolo.color[6]="#09EA10";
								idoneitaReg.setPunteggioNaz(new BigDecimal("0"));
							}
							
							
							idoneitaRegList.add(idoneitaReg);
							titolo.setIdoneitaReg(idoneitaRegList);
						
					}else{
						titolo.color[5]="#09EA10";
						titolo.color[6]="#09EA10";
					}
					//fine calcolo idoneit�
					
					//inizio calcolo abilitazione-aggiornamnto-altrititoli
						
						//Voto Abilitazione
					
						//corso aggiornamento
						titolo.parzialeTitolo[7]="0";
						corsoAggiornamentoRegList = (List<CorsoAggiornamentoReg>) corsoAggiornamentoRegHome.findByExample(new CorsoAggiornamentoReg(u.getIdUtente()));
						if(corsoAggiornamentoRegList!=null && !corsoAggiornamentoRegList.isEmpty()){
							titolo.setCorsoAggiornamentoReg(corsoAggiornamentoRegList);
							
							for(CorsoAggiornamentoReg corsoAggiornamentoReg:corsoAggiornamentoRegList){
								parzialeAbiCorsoAltri = parzialeAbiCorsoAltri.add(corsoAggiornamentoReg.getPunteggio() == null ? new BigDecimal(0):corsoAggiornamentoReg.getPunteggio());
							}
							
						}
						
						//altri titoli
						titolo.parzialeTitolo[8]="0";
						altroTitoloRegList = (List<AltroTitoloReg>) altroTitoloRegHome.findByExample(new AltroTitoloReg(u.getIdUtente()));
						if(altroTitoloRegList!=null && !altroTitoloRegList.isEmpty()){
							titolo.setAltroTitoloReg(altroTitoloRegList);
							for(AltroTitoloReg altroTitoloReg: altroTitoloRegList){
								if(altroTitoloReg.getFlagTitolo()!=null)
								if(altroTitoloReg.getFlagTitolo().equals("H")){
									parzialeAbiCorsoAltri = parzialeAbiCorsoAltri.add(altroTitoloReg.getPunteggio() == null ? new BigDecimal(0):altroTitoloReg.getPunteggio());
								}else{
									parzialeSpecDottBors = parzialeSpecDottBors.add(altroTitoloReg.getPunteggio() == null ? new BigDecimal(0):altroTitoloReg.getPunteggio());
								}
								
							}
						}
						dottoratoRegList =  (List<DottoratoReg>) dottoratoRegHome.findByExample(new DottoratoReg(u.getIdUtente()));
						if(dottoratoRegList!=null && !dottoratoRegList.isEmpty()){
							titolo.setDottoratoReg(dottoratoRegList);
							for(DottoratoReg dottoratoReg: titolo.getDottoratoReg()){
								if(dottoratoReg.getFlagTitolo()!=null)
								if(dottoratoReg.getFlagTitolo().equals("H")){
									parzialeAbiCorsoAltri = parzialeAbiCorsoAltri.add(dottoratoReg.getPunteggio() == null ? new BigDecimal(0):dottoratoReg.getPunteggio());
								}else{
									parzialeSpecDottBors = parzialeSpecDottBors.add(dottoratoReg.getPunteggio() == null ? new BigDecimal(0):dottoratoReg.getPunteggio());
								}
							}
						}
						
						totaleAbiCorsoAltri = totaleAbiCorsoAltri.add(parzialeAbiCorsoAltri);
						titolo.parzialeTitolo[7] = parzialeAbiCorsoAltri.toString().replace(".", ",");
						if(totaleAbiCorsoAltri.compareTo(new BigDecimal("0.5000"))>0){
							totaleAbiCorsoAltri = new BigDecimal("0.5000");
							//titolo.parzialeTitolo[7] = "0,5000";
						}
						
						if(parzialeAbiCorsoAltri.compareTo(new BigDecimal(0))>0){
							titolo.color[7]="black";
						}
						//fine calcolo abilitazione-aggiornamnto-altrititoli
						
						//inizio calcolo specializzazione-borse-di-studio-dottorato
						titolo.parzialeTitolo[3] = "0";
						specializzazioneRegList = (List<SpecializzazioneReg>) specilaizzazioneRegHome.findByExample(new SpecializzazioneReg(u.getIdUtente()));
						if(specializzazioneRegList!=null && !specializzazioneRegList.isEmpty()){
							titolo.setSpecializzazioneReg(specializzazioneRegList);
							for (SpecializzazioneReg specializzazioneReg :specializzazioneRegList){
								parzialeSpecDottBors = parzialeSpecDottBors.add(specializzazioneReg.getPunteggio() == null ? new BigDecimal(0) : specializzazioneReg.getPunteggio());
								
							}
						}
						borsaStudioRegList = (List<BorsaStudioReg>) borsaStudioRegHome.findByExample(new BorsaStudioReg(u.getIdUtente()));
						if(borsaStudioRegList!=null && !borsaStudioRegList.isEmpty()){
							titolo.setBorsaStudioReg(borsaStudioRegList);
							for(BorsaStudioReg borsaStudioReg:borsaStudioRegList ){
								parzialeSpecDottBors = parzialeSpecDottBors.add(borsaStudioReg.getPunteggio() == null ? new BigDecimal(0) : borsaStudioReg.getPunteggio());
							}
						}
						
						totaleSpecBorseDottorato=totaleSpecBorseDottorato.add(parzialeSpecDottBors);
						titolo.parzialeTitolo[3] = parzialeSpecDottBors.toString().replace(".", ",");
						if(totaleSpecBorseDottorato.compareTo(new BigDecimal("2.0000"))>0){
							totaleSpecBorseDottorato = new BigDecimal("2.0000");
						}
						if(specializzazioneRegList.isEmpty() && borsaStudioRegList.isEmpty()){
							titolo.color[3]="#09EA10";
						}
						
						if(altroTitoloRegList.isEmpty() && dottoratoRegList.isEmpty()){
							titolo.color[8]="#09EA10";
						}
						//fine calcolo specializzazione-borse-di-studio-dottorato
					utenteTitoli.setUtente(u);
					utenteTitoli.setTitoli(titolo);
					utenteTitoliList.add(utenteTitoli);
					
				}
			
			totaleTitoli= totaleTitoli.add(totaleLaurea)
									  .add(totaleSecondaLaurea)
									  .add(totaleSecondaLaureaBis)
									  .add(totaleSpecBorseDottorato)
									  .add(totalePubblicazioni)
									  .add(totaleIdoneitaNazionale)
									  .add(totaleIdoneitaPrecedenteConcorso)
									  .add(totaleAbiCorsoAltri);
			
			if(totaleTitoli.compareTo(new BigDecimal("15.0000"))>0){
				totaleTitoli= new BigDecimal("15.0000");
			}
			
			schedaValutazioneBean.setTotaleTitoli(totaleTitoli.toString().replace(".", ","));
			
			totaleTitolo[0] = totaleLaurea.toString().replace(".", ",");
			totaleTitolo[1] = totaleSecondaLaurea.toString().replace(".", ",");
			totaleTitolo[2] = totaleSecondaLaureaBis.toString().replace(".", ",");
			totaleTitolo[3] = totaleSpecBorseDottorato.toString().replace(".", ",");
			totaleTitolo[4] = totalePubblicazioni.toString().replace(".", ",");
			totaleTitolo[5] = totaleIdoneitaPrecedenteConcorso.toString().replace(".", ",");
			totaleTitolo[6] = totaleIdoneitaNazionale.toString().replace(".", ",");
			totaleTitolo[7] = totaleAbiCorsoAltri.toString().replace(".", ",");
			schedaValutazioneBean.setTotale(totaleTitolo);
			schedaValutazioneBean.setUtenteTitoliList(utenteTitoliList);
			schedaValutazioneBean.setTitoli(titoli);
			//schedaValutazioneBean.setColor(color);
			}
		}
		catch(Exception e) {
			
			logger.error("CalcoloTitoliAction - errore nel calcolo dei titoli", e);
			throw new GestioneErroriException("errore nel calcolo dei titoli");
		}
		
	}
	
public void  aggiornaTitoli(SchedaValutazioneBean schedaValutazioneBean) throws GestioneErroriException{
		
		totaleLaurea = new BigDecimal(0);
		totaleSecondaLaurea = new BigDecimal(0);
		totaleSecondaLaureaBis = new BigDecimal(0);
		totaleSpecBorseDottorato = new BigDecimal(0);
		totalePubblicazioni = new BigDecimal(0);
		totaleIdoneitaPrecedenteConcorso = new BigDecimal(0);
		totaleIdoneitaNazionale = new BigDecimal(0);
		totaleAbiCorsoAltri = new BigDecimal(0);
		totaleTitoli= new BigDecimal(0);
		
		try {
		
			
			if(schedaValutazioneBean.getUtenteCandidaturaList().size()>0){
		
				for(UtenteTitoli u : schedaValutazioneBean.getUtenteTitoliList()){
					
					parzialeSpecDottBors = new BigDecimal(0);
					parzialePubblicazioni = new BigDecimal(0);
					parzialeAbiCorsoAltri = new BigDecimal(0);
					
				
					if(u.getTitoli().getRequisitiMinimiReg()!=null){
					
					for(RequisitiMinimiReg requisitiMinimiReg: u.getTitoli().getRequisitiMinimiReg()){
						if(requisitiMinimiReg.getPunteggioLaureaString()!=null){
							requisitiMinimiReg.setPunteggioLaurea(new BigDecimal(requisitiMinimiReg.getPunteggioLaureaString().replace(",",".")));
						}
						if(requisitiMinimiReg.getPunteggioAbilitazioneString()!=null){
							requisitiMinimiReg.setPunteggioAbilitazione(new BigDecimal(requisitiMinimiReg.getPunteggioAbilitazioneString().replace(",",".")));
						}
						//voto abilitazione
						parzialeAbiCorsoAltri = parzialeAbiCorsoAltri.add(requisitiMinimiReg.getPunteggioAbilitazione()==null?new BigDecimal("0"):requisitiMinimiReg.getPunteggioAbilitazione());
						u.getTitoli().parzialeTitolo[0] = requisitiMinimiReg.getPunteggioLaurea().toString().replace(".",",");
						
						totaleLaurea = totaleLaurea.add( requisitiMinimiReg.getPunteggioLaurea());
						
						if(totaleLaurea.compareTo(new BigDecimal("5.0000"))>0){
							totaleLaurea = new BigDecimal("5.0000");
						}
						
						if(requisitiMinimiReg.getPunteggioLaurea()!=null){
							if(requisitiMinimiReg.getPunteggioLaurea().compareTo(new BigDecimal(0))==0){
								u.getTitoli().color[0] = "#F91307;";
							}else{
								u.getTitoli().color[0] = "black;";
							}
						}else{
							u.getTitoli().color[0] = "#09EA10;";
						}
						
						if(requisitiMinimiReg.getPunteggioAbilitazione()!=null){
							if(requisitiMinimiReg.getPunteggioAbilitazione().compareTo(new BigDecimal(0))==0){
								
								u.getTitoli().color[7] = "#F91307;";
							}else{
								u.getTitoli().color[7] = "black;";
							}
						}else{
							u.getTitoli().color[7] = "#09EA10;";
						}
					}
				
					}
					
					u.getTitoli().parzialeTitolo[1] ="0";
					if(u.getTitoli().getAltraLaureaReg()!=null && u.getTitoli().getAltraLaureaReg().size()>0){
						if(u.getTitoli().getAltraLaureaReg().get(0).getPunteggio()!=null&&u.getTitoli().getAltraLaureaReg().get(0).getPunteggio().compareTo(new BigDecimal(0))==0){
							
							u.getTitoli().color[1] = "#F91307;";
						}
					
						u.getTitoli().parzialeTitolo[1] =u.getTitoli().getAltraLaureaReg().get(0).getPunteggio().toString().replace(".",",");						
						totaleSecondaLaurea = totaleSecondaLaurea.add(u.getTitoli().getAltraLaureaReg().get(0).getPunteggio());
						if(totaleSecondaLaurea.compareTo(new BigDecimal("1.5"))>0){
							
							totaleSecondaLaurea = new BigDecimal("1.5000");
						}
					
					}else{
						u.getTitoli().color[1] = "#09EA10;";
					}
					//punteggio altre laure in medicina � veterinaria-chimica- scienze biologiche
					
					u.getTitoli().parzialeTitolo[2] = "0";
					
					if (u.getTitoli().getAltraLaureaBisReg()!=null && !u.getTitoli().getAltraLaureaBisReg().isEmpty()){
						//titolo.setAltraLaureaBisReg(altraLaureaBisList);
						for(AltraLaureaBisReg altrLaureaBisReg : u.getTitoli().getAltraLaureaBisReg()){
							totaleSecondaLaureaBis = totaleSecondaLaureaBis.add(altrLaureaBisReg.getPunteggio());
							
						}
						if(totaleSecondaLaureaBis.compareTo(new BigDecimal("3.5"))>0){
							
							totaleSecondaLaureaBis = new BigDecimal("3.5");
						}
						if(totaleSecondaLaureaBis.compareTo(new BigDecimal(0))==0){
							u.getTitoli().color[2]="#F91307";
						}
												
						u.getTitoli().parzialeTitolo[2] =totaleSecondaLaureaBis.toString().replace(".", ",");
					}else{
						u.getTitoli().color[2]="#09EA10";
					}
					
					//inizio calcolo specializzazione-borse-di-studio-dottorato
					u.getTitoli().parzialeTitolo[3] = "0";
					if(u.getTitoli().getSpecializzazioneReg()!=null && u.getTitoli().getSpecializzazioneReg().size()>0){
						
						for (SpecializzazioneReg specializzazioneReg :u.getTitoli().getSpecializzazioneReg()){
							if(specializzazioneReg.getPunteggioString()!=null){
								specializzazioneReg.setPunteggio(new BigDecimal(specializzazioneReg.getPunteggioString().replace(",", ".")));
							}
							parzialeSpecDottBors = parzialeSpecDottBors.add(specializzazioneReg.getPunteggio() == null ? new BigDecimal(0) : specializzazioneReg.getPunteggio());
							
						}
						
					}
					
					if(u.getTitoli().getBorsaStudioReg()!=null && u.getTitoli().getBorsaStudioReg().size()>0){
						
						for(BorsaStudioReg borsaStudioReg:u.getTitoli().getBorsaStudioReg()){
							if(borsaStudioReg.getPunteggioString()!=null){
								borsaStudioReg.setPunteggio(new BigDecimal(borsaStudioReg.getPunteggioString().replace(",", ".")));
							}
							parzialeSpecDottBors = parzialeSpecDottBors.add(borsaStudioReg.getPunteggio() == null ? new BigDecimal(0) : borsaStudioReg.getPunteggio());
							
						}
						
					}
					
					if(u.getTitoli().getBorsaStudioReg()==null&&u.getTitoli().getSpecializzazioneReg()==null){
						u.getTitoli().color[3]="#09EA10";
					}
					//fine calcolo specializzazione-borse-di-studio-dottorato
					//inizio calcolo Pubblicazioni
					u.getTitoli().parzialeTitolo[4] = "0";
					if(u.getTitoli().getPubblicazioneReg()!=null && !u.getTitoli().getPubblicazioneReg().isEmpty()){
					
						for(PubblicazioneReg pubblicazioneReg: u.getTitoli().getPubblicazioneReg()){
							if(pubblicazioneReg.getPunteggioString()!=null){
								pubblicazioneReg.setPunteggio(new BigDecimal(pubblicazioneReg.getPunteggioString().toString().replace(",", ".")));
							}
							parzialePubblicazioni = parzialePubblicazioni.add(pubblicazioneReg.getPunteggio() == null ? new BigDecimal(0) : pubblicazioneReg.getPunteggio());
						}
						
						u.getTitoli().parzialeTitolo[4] = parzialePubblicazioni.toString().replace(".", ",");
					}else{
						u.getTitoli().color[4]="#09EA10";
					}
					
					totalePubblicazioni = totalePubblicazioni.add(parzialePubblicazioni);
					if(totalePubblicazioni.compareTo(new BigDecimal("1.0000"))>0){
						totalePubblicazioni = new BigDecimal("1.0000");
					}
					//fine calcolo Pubblicazini
				
					//inizio calcolo idoneit�
					u.getTitoli().parzialeTitolo[5]="0";
					u.getTitoli().parzialeTitolo[6]="0";
					if(u.getTitoli().getIdoneitaReg()!=null && u.getTitoli().getIdoneitaReg().size()>0){
					
						for(IdoneitaReg idoneitaReg :u.getTitoli().getIdoneitaReg()){
							if(u.getTitoli().getIdoneitaReg().get(0)!=null){
								if(idoneitaReg.getEstremiIdoneita()!=null && !idoneitaReg.getEstremiIdoneita().equals("") ){
									if(idoneitaReg.getPunteggio()==null){
										idoneitaReg.setPunteggio(new BigDecimal("1"));
									}
									u.getTitoli().parzialeTitolo[5] = idoneitaReg.getPunteggio().toString();
									totaleIdoneitaPrecedenteConcorso = totaleIdoneitaPrecedenteConcorso.add(idoneitaReg.getPunteggio());
									if(idoneitaReg.getPunteggio().compareTo(new BigDecimal(0))==0){
										u.getTitoli().color[5]="#F91307";
									}
									if(totaleIdoneitaPrecedenteConcorso.compareTo(new BigDecimal(1))>0){
										totaleIdoneitaPrecedenteConcorso = new BigDecimal(1);
									}
									
								}else{
									u.getTitoli().color[5]="#09EA10";
								}
								if(idoneitaReg.getRifIdoneitaNazionale()!=null && !idoneitaReg.getRifIdoneitaNazionale().equals("")){
									
									if(idoneitaReg.getPunteggioNaz()==null){
										idoneitaReg.setPunteggioNaz(new BigDecimal("1"));
									}
									u.getTitoli().parzialeTitolo[6] = idoneitaReg.getPunteggioNaz().toString();
									totaleIdoneitaNazionale = totaleIdoneitaNazionale.add(idoneitaReg.getPunteggioNaz());
									if(idoneitaReg.getPunteggioNaz().compareTo(new BigDecimal(0))==0){
										u.getTitoli().color[6]="#F91307";
									}
									
									if(totaleIdoneitaNazionale.compareTo(new BigDecimal(1))>0){
										totaleIdoneitaNazionale = new BigDecimal(1);
									}
								}else{
									u.getTitoli().color[6]="#09EA10";
								}
												
							
						}
							}
						
						
						
					}
					//fine calcolo idoneit�
					u.getTitoli().parzialeTitolo[7]="0";
						if(u.getTitoli().getCorsoAggiornamentoReg()!=null && u.getTitoli().getCorsoAggiornamentoReg().size()>0){
							for(CorsoAggiornamentoReg corsoAggiornamentoReg:u.getTitoli().getCorsoAggiornamentoReg()){
								if(corsoAggiornamentoReg.getPunteggioString()!=null){
									corsoAggiornamentoReg.setPunteggio(new BigDecimal(corsoAggiornamentoReg.getPunteggioString().replace(",",".")));
								}
								parzialeAbiCorsoAltri = parzialeAbiCorsoAltri.add(corsoAggiornamentoReg.getPunteggio() == null ? new BigDecimal(0):corsoAggiornamentoReg.getPunteggio());
							}
						}
						if(u.getTitoli().getAltroTitoloReg()!=null && u.getTitoli().getAltroTitoloReg().size()>0){
							
							for(AltroTitoloReg altroTitoloReg: u.getTitoli().getAltroTitoloReg()){
								if(altroTitoloReg.getPunteggioString()!=null){
									altroTitoloReg.setPunteggio(new BigDecimal(altroTitoloReg.getPunteggioString().replace(",", ".")));
								}
								if(altroTitoloReg.getFlagTitolo()!=null && !altroTitoloReg.getFlagTitolo().equals("")) 
									
								if(altroTitoloReg.getFlagTitolo().equals("H")){
									altroTitoloReg.setFlagTitolo("H");
									parzialeAbiCorsoAltri = parzialeAbiCorsoAltri.add(altroTitoloReg.getPunteggio() == null ? new BigDecimal(0):altroTitoloReg.getPunteggio());
								}else{
									altroTitoloReg.setFlagTitolo("C");
									parzialeSpecDottBors = parzialeSpecDottBors.add(altroTitoloReg.getPunteggio() == null ? new BigDecimal(0):altroTitoloReg.getPunteggio());
								}
								
								
							}
						}
						if(u.getTitoli().getDottoratoReg()!=null && u.getTitoli().getDottoratoReg().size()>0){
							
							for(DottoratoReg dottoratoReg:u.getTitoli().getDottoratoReg()){
								if(dottoratoReg.getPunteggioString()!=null){
									dottoratoReg.setPunteggio(new BigDecimal(dottoratoReg.getPunteggioString().replace(",", ".")));
								}
								if(dottoratoReg.getFlagTitolo()!=null  && !dottoratoReg.getFlagTitolo().equals("")) 
								if(dottoratoReg.getFlagTitolo().equals("H")){
									dottoratoReg.setFlagTitolo("H");
									parzialeAbiCorsoAltri = parzialeAbiCorsoAltri.add(dottoratoReg.getPunteggio() == null ? new BigDecimal(0):dottoratoReg.getPunteggio());
								}else{
									dottoratoReg.setFlagTitolo("C");
									parzialeSpecDottBors = parzialeSpecDottBors.add(dottoratoReg.getPunteggio() == null ? new BigDecimal(0):dottoratoReg.getPunteggio());
								}
								
								
							}
						}
						
						if(u.getTitoli().getDottoratoReg()!=null && u.getTitoli().getDottoratoReg().isEmpty()&&u.getTitoli().getAltroTitoloReg()!=null &&u.getTitoli().getAltroTitoloReg().isEmpty()){
							u.getTitoli().color[7]="#09EA10";
						}
						totaleAbiCorsoAltri = totaleAbiCorsoAltri.add(parzialeAbiCorsoAltri);
						u.getTitoli().parzialeTitolo[7] = parzialeAbiCorsoAltri.toString().replace(".", ",");
						if(totaleAbiCorsoAltri.compareTo(new BigDecimal("0.5000"))>0){
							totaleAbiCorsoAltri = new BigDecimal("0.5000");
							//titolo.parzialeTitolo[7] = "0,5000";
						}
						u.getTitoli().parzialeTitolo[3] = parzialeSpecDottBors.toString().replace(".", ",");
						totaleSpecBorseDottorato=totaleSpecBorseDottorato.add(parzialeSpecDottBors);
						
						if(totaleSpecBorseDottorato.compareTo(new BigDecimal("2.0000"))>0){
							totaleSpecBorseDottorato = new BigDecimal("2.0000");
						}
						
					//fine calcolo abilitazione-aggiornamnto-altrititoli
								
				}
			
			totaleTitoli= totaleTitoli.add(totaleLaurea)
									  .add(totaleSecondaLaurea)
									  .add(totaleSecondaLaureaBis)
									  .add(totaleSpecBorseDottorato)
									  .add(totalePubblicazioni)
									  .add(totaleIdoneitaNazionale)
									  .add(totaleIdoneitaPrecedenteConcorso)
									  .add(totaleAbiCorsoAltri);
			
			if(totaleTitoli.compareTo(new BigDecimal("15.0000"))>0){
				totaleTitoli= new BigDecimal("15.0000");
			}
			
			schedaValutazioneBean.setTotaleTitoli(totaleTitoli.toString().replace(".", ","));
			
			totaleTitolo[0] = totaleLaurea.toString().replace(".", ",");
			totaleTitolo[1] = totaleSecondaLaurea.toString().replace(".", ",");
			totaleTitolo[2] = totaleSecondaLaureaBis.toString().replace(".", ",");
			totaleTitolo[3] = totaleSpecBorseDottorato.toString().replace(".", ",");
			totaleTitolo[4] = totalePubblicazioni.toString().replace(".", ",");
			totaleTitolo[5] = totaleIdoneitaPrecedenteConcorso.toString().replace(".", ",");
			totaleTitolo[6] = totaleIdoneitaNazionale.toString().replace(".", ",");
			totaleTitolo[7] = totaleAbiCorsoAltri.toString().replace(".", ",");
			schedaValutazioneBean.setTotale(totaleTitolo);
			}
		}
		catch(Exception e) {
			
			logger.error("CalcoloTitoliAction - errore nel calcolo dei titoli", e);
			throw new GestioneErroriException("errore nel calcolo dei titoli");
		}
	}

	public void calcolaEspProf(SchedaValutazioneBean schedaValutazioneBean) throws GestioneErroriException{
		
		totaleEspProf = new BigDecimal(0);
		
		List<UtenteEspProf> utenteEspProfList = new ArrayList<UtenteEspProf>();
		RisultatiValutazioneEsperienze risultato = null;
		
		try{
		UtenteEspProf utenteEspProf;
		for(UtenteCandidaturaReg u : schedaValutazioneBean.getUtenteCandidaturaList()){
			
			utenteEspProf = new UtenteEspProf();
			
			if (hmRuoli==null) recuperaRuoli();
			EsercizioProfReg  esercizioProfReg = new EsercizioProfReg(); 
			
			List<EsercizioProfReg> listEsercizio = new ArrayList<EsercizioProfReg>();
			esercizioProfReg.setIdDomandaEs(u.getIdUtente());
			listEsercizio = esercizioProfRegHome.findByExample(esercizioProfReg);
			List<EsperienzaOriginal> listEsp = new ArrayList<EsperienzaOriginal>();
			
			for (EsercizioProfReg esercizio : listEsercizio) {
				
				EsperienzaOriginal espOr = new EsperienzaOriginal();
			
				String descRuolo = (String) hmRuoli.get(esercizio.getCodRuoloEs());
				
				String codiceCategoria =  descRuolo.substring(5, 6);
				espOr.setCodiceCategoria(codiceCategoria);
				
				if(esercizio.getCodModalitaEs().equals("0"))
					espOr.setCodiceModalita("P");
				else
					espOr.setCodiceModalita("F");
				if(esercizio.getFlagFarmRurale() !=null && esercizio.getFlagFarmRurale().equals("Si"))
					espOr.setRurale(true);
				else
					espOr.setRurale(false);
				espOr.setDataInizio(esercizio.getDataInizioEs());
				espOr.setDataFine(esercizio.getDataFineEs());
				
				String ruoloStringa =  descRuolo.substring(7,descRuolo.length() );
				espOr.setRuolo(ruoloStringa);
				
				
				listEsp.add(espOr);
			
			}
			
			
			if(!listEsp.isEmpty()){
				//calcolo del punteggio delle esperienze professionali 			
							try {
								risultato = com.accenture.punteggi.esperienze.CalcoloPunteggi.calcola((ArrayList<EsperienzaOriginal>) listEsp);
								totaleEspProf = totaleEspProf.add(new BigDecimal(risultato.getVotoFinale().toString().replace(",", ".")));
								utenteEspProf.setRisultato(risultato);
								utenteEspProf.setRisultati(risultato.toString().replace(
										"table{border:2px solid black;border-collapse:collapse; } td{border:1px solid black;padding:2px; }",
										"")
								.replaceAll("<table",
										"<table style=\"border:2px solid black;border-collapse:collapse; \" ")
					
								.replaceAll("<td",
										"<td style=\"border:1px solid black;padding:2px; \" "));
								utenteEspProf.setUtente(u);
								utenteEspProfList.add(utenteEspProf);
							}
							catch(Exception e) {
								
								logger.error("CalcoloTitoliAction - simulazione calcolo errato", e);
								throw new GestioneErroriException("Simulazione calcolo errato");
							}
							
				
			}
			if(totaleEspProf.compareTo(new BigDecimal("35.0000"))>0){
				
				totaleEspProf = new BigDecimal("35.0000");
			}
			
			
		}
		schedaValutazioneBean.setTotaleEspProf(totaleEspProf.toString().replace(".",","));
		schedaValutazioneBean.setUtenteEspProfList(utenteEspProfList);
		}
		catch(Exception e) {
			
			logger.error("CalcoloTitoliAction - errore nel calcolo delle esperienze professionali", e);
			throw new GestioneErroriException("errore nel calcolo delle esperienze professionali");
		}
	}
	private void recuperaRuoli() throws GestioneErroriException{
		ruoli = CaricaRuoli.getRuoli();
		hmRuoli= new HashMap();
		
		for (int i = 0; i < ruoli.size(); i++) {
			Ruolo ruolo = new Ruolo();
			ruolo = ruoli.get(i);
			hmRuoli.put(ruolo.getCodice(), ruolo.getDescrizione());
		}
		 
	}
	public void recuperaOsservazioni(SchedaValutazioneBean schedaValutazioneBean) throws GestioneErroriException{
		
			graduatoria = graduatoriaHome.findById(schedaValutazioneBean.getIdCandidatura());
		
		 	String nome="";
			
		 	List<UtenteOsservazioni> utenteOsservazioniList = new ArrayList<UtenteOsservazioni>();
			
		 	UtenteOsservazioni utenteOsservazioni;
		 	
		 	if(graduatoria!=null && graduatoria.getOsservazioni()!=null && !graduatoria.getOsservazioni().equals("") ){
				String[] array_oss1 = graduatoria.getOsservazioni().split(" # ");
				
				for (int i=0; i< array_oss1.length; i++){
					utenteOsservazioni = new UtenteOsservazioni();
					String appoggio = array_oss1[i];
					String[] array_oss2 = appoggio.split(" | ");
					
					     nome="";
					  
							for (int j=0; j<array_oss2.length; j++){
								
								if (!array_oss2[j].contains("|") && !array_oss2[j].contains("_")){
									nome= nome+" "+ array_oss2[j];
								}
									
								else if (!array_oss2[j].contains("|")){
									utenteOsservazioni.getOsservazioni().add(CaricaOsservazioni.decodificaosservazione(array_oss2[j]));
								}
									
								
								utenteOsservazioni.setNomeUtente(nome);
							}
							
							utenteOsservazioniList.add(utenteOsservazioni);		
				}
		 	}
		 	if(graduatoria.getNote()!=null && !graduatoria.getNote().equals("")){
		 		String nota = StringUtil.convertClob(graduatoria.getNote());
		 		nota = nota.replaceAll("L'utente ", "");
				schedaValutazioneBean.setNote(nota);
			}else{
				schedaValutazioneBean.setNote("");
			}
			
			schedaValutazioneBean.setUtenteOsservazioniList(utenteOsservazioniList);
			
		
	}
	public void saveGraduatoria(SchedaValutazioneBean schedaValutazioneBean, String miUtente) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		for(UtenteTitoli u : schedaValutazioneBean.getUtenteTitoliList()){
		
			Transaction trx = session.beginTransaction();
			trx.begin();
			try{
				java.util.Date dataSys= new java.util.Date();
				java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
				String sIdStorico = graduatoriaHome.getSequenceIdStorico();
				
				//log.debug("apertura transazione per l'utente con id " + utenteBean.getIdUtente() );
				if(u.getTitoli().getRequisitiMinimiReg()!=null && u.getTitoli().getRequisitiMinimiReg().size()>0){
					
					saveRequisitiminimiReg(u.getTitoli().getRequisitiMinimiReg(),session, sIdStorico, miUtente, oggi);
				}
				
				if(u.getTitoli().getAltraLaureaReg()!=null && u.getTitoli().getAltraLaureaReg().size()>0){
					
					saveAltraLaureaReg(u.getTitoli().getAltraLaureaReg(),session, sIdStorico, miUtente, oggi);
				}
				if(u.getTitoli().getAltraLaureaBisReg()!=null && u.getTitoli().getAltraLaureaBisReg().size()>0){
					
					saveAltraLaureaBisReg(u.getTitoli().getAltraLaureaBisReg(),session, sIdStorico, miUtente, oggi);
				}
				if(u.getTitoli().getIdoneitaReg()!=null && u.getTitoli().getIdoneitaReg().size()>0){
					
					saveIdoneita(u.getTitoli().getIdoneitaReg(),session, sIdStorico, miUtente, oggi);
				}
				
				if(u.getTitoli().getSpecializzazioneReg()!=null && u.getTitoli().getSpecializzazioneReg().size()>0){
					saveSpecializzazioneReg(u.getTitoli().getSpecializzazioneReg(),session, sIdStorico, miUtente, oggi);
				}
				
				if(u.getTitoli().getDottoratoReg()!=null && u.getTitoli().getDottoratoReg().size()>0 ){
					saveDottoratoReg(u.getTitoli().getDottoratoReg(), session, sIdStorico, miUtente, oggi);
				}
				
				if(u.getTitoli().getBorsaStudioReg()!=null && u.getTitoli().getBorsaStudioReg().size()>0 ){
					saveBorsaStudioReg(u.getTitoli().getBorsaStudioReg(), session, sIdStorico, miUtente, oggi);
				}
				
				if(u.getTitoli().getPubblicazioneReg()!=null && u.getTitoli().getPubblicazioneReg().size()>0 ){
					savePubblicazioneReg(u.getTitoli().getPubblicazioneReg(), session, sIdStorico, miUtente, oggi);
				}
				if(u.getTitoli().getCorsoAggiornamentoReg()!=null && u.getTitoli().getCorsoAggiornamentoReg().size()>0 ){
					saveCorsoAggiornamentoReg(u.getTitoli().getCorsoAggiornamentoReg(), session, sIdStorico, miUtente, oggi);
				}
				if(u.getTitoli().getAltroTitoloReg()!=null && u.getTitoli().getAltroTitoloReg().size()>0 ){
					saveAltroTitoloReg(u.getTitoli().getAltroTitoloReg(), session, sIdStorico, miUtente, oggi);
				}
			
				datiBando = new DatiBando();
				datiBandoHome = new DatiBandoHome();
				datiBando = datiBandoHome.findById(schedaValutazioneBean.getCodReg());
				
				datiBando.setFlgAbilitaGrad("false");
				datiBandoHome.saveOrUpdate(datiBando);
				graduatoriaExAequoRisolti.setExAequo("T");
				graduatoriaListExAequoRisolti = graduatoriaHome.findByExample(graduatoriaExAequoRisolti);
				graduatoria = graduatoriaHome.findById(schedaValutazioneBean.getIdCandidatura());
				exEaequoRisoliToDelete = new ArrayList<Graduatoria>();
				exEaequoRisoltiToResolved= new ArrayList<Graduatoria>();
				//controllare che il vecchio punteggio era in exequo con un altro record quindi togliere l'exequita con il vecchio 
				for(Graduatoria g :graduatoriaListExAequoRisolti){
					if(!graduatoria.getIdCandidatura().equalsIgnoreCase(g.getIdCandidatura())  && (graduatoria.getPunteggio().compareTo(g.getPunteggio())==0||graduatoria.getEtaMedia().compareTo(g.getEtaMedia())==0)){
						//aggiungo alla lista d'appoggio
						
						if((graduatoria.getPunteggio().compareTo(g.getPunteggio())==0 && graduatoria.getEtaMedia().compareTo(g.getEtaMedia())==0)){
							//aggiungo alla lista d'appoggio
							
							exEaequoRisoliToDelete.add(g);
							
						}else if(graduatoria.getPunteggio().compareTo(g.getPunteggio())==0){
							exEaequoRisoltiToResolved.add(g);
						}
						
					}
					
					
				}
				
				if(exEaequoRisoliToDelete.size()>0){
					if(exEaequoRisoliToDelete.size()<=1){
						exEaequoRisoliToDelete.get(0).setExAequo(null);
						exEaequoRisoliToDelete.get(0).setExAequoRisolto(null);
						exEaequoRisoliToDelete.get(0).setColor(null);
						
						//STORICO
						GraduatoriaStorico graduatoriaStrRes = new GraduatoriaStorico();
						PropertyUtils.copyProperties(graduatoriaStrRes, exEaequoRisoliToDelete.get(0));
						graduatoriaStrRes.setIdStorico(sIdStorico);
						graduatoriaStrRes.setMiUtente(miUtente);
						graduatoriaStrRes.setDataUltimaModifica(oggi);
						graduatoriaHome.saveOrUpdate(exEaequoRisoliToDelete.get(0), graduatoriaStrRes);
					}
						
					
				}
				if(exEaequoRisoltiToResolved.size()>0){
					if(exEaequoRisoltiToResolved.size()<=1){
						exEaequoRisoltiToResolved.get(0).setExAequo(null);
						exEaequoRisoltiToResolved.get(0).setExAequoRisolto(null);
						exEaequoRisoltiToResolved.get(0).setColor(null);
						
						//STORICO
						GraduatoriaStorico graduatoriaStrRes = new GraduatoriaStorico();
						PropertyUtils.copyProperties(graduatoriaStrRes, exEaequoRisoltiToResolved.get(0));
						graduatoriaStrRes.setIdStorico(sIdStorico);
						graduatoriaStrRes.setMiUtente(miUtente);
						graduatoriaStrRes.setDataUltimaModifica(oggi);
						graduatoriaHome.saveOrUpdate(exEaequoRisoltiToResolved.get(0), graduatoriaStrRes);
					}
						
					
				}
				exEaequoRisoliToDelete = new ArrayList<Graduatoria>();
				exEaequoRisoltiToResolved= new ArrayList<Graduatoria>();
				// controllare che il nuovo sta in exequo con un altro o altri che gia sono exequi quinid rielaborare gli exequi
				for(Graduatoria g :graduatoriaListExAequoRisolti){
					if(!graduatoria.getIdCandidatura().equalsIgnoreCase(g.getIdCandidatura()) &&graduatoria.getPunteggio().compareTo(new BigDecimal(schedaValutazioneBean.getTotaleScheda().replace(",", ".")))!=0 && (g.getPunteggio().compareTo(new BigDecimal(schedaValutazioneBean.getTotaleScheda().replace(",", ".")))==0||graduatoria.getEtaMedia().compareTo(g.getEtaMedia())==0)){
						//aggiungo alla lista d'appoggio
						
						if(!graduatoria.getIdCandidatura().equalsIgnoreCase(g.getIdCandidatura()) &&graduatoria.getPunteggio().compareTo(new BigDecimal(schedaValutazioneBean.getTotaleScheda().replace(",", ".")))!=0 && (g.getPunteggio().compareTo(new BigDecimal(schedaValutazioneBean.getTotaleScheda().replace(",", ".")))==0 && graduatoria.getEtaMedia().compareTo(g.getEtaMedia())==0)){
							//aggiungo alla lista d'appoggio
							
							exEaequoRisoliToDelete.add(g);
							
						}else if(g.getPunteggio().compareTo(new BigDecimal(schedaValutazioneBean.getTotaleScheda().replace(",", ".")))==0){
							exEaequoRisoltiToResolved.add(g);
						}
						
					}
					
				}
				
				if(graduatoria.getExAequo()==null && exEaequoRisoliToDelete.size()>0){
					for(Graduatoria g :exEaequoRisoliToDelete){
						 g.setExAequo(null);
						 g.setExAequoRisolto(null);
						 g.setColor(null);
						 
						 //STORICO
						 GraduatoriaStorico gStr = new GraduatoriaStorico();
						 PropertyUtils.copyProperties(gStr, g);
						 String sIdStor = graduatoriaHome.getSequenceIdStorico();
						 gStr.setIdStorico(sIdStor);
						 gStr.setMiUtente(miUtente);
						 gStr.setDataUltimaModifica(oggi);
						 graduatoriaHome.saveOrUpdate(g, gStr);
					}
					
				}
				
				if(graduatoria.getExAequo()==null && exEaequoRisoltiToResolved.size()>0){
					for(Graduatoria g :exEaequoRisoltiToResolved){
						 g.setExAequo(null);
						 g.setExAequoRisolto(null);
						 g.setColor(null);
						 
						 //STORICO
						 GraduatoriaStorico gStr = new GraduatoriaStorico();
						 PropertyUtils.copyProperties(gStr, g);
						 String sIdStor = graduatoriaHome.getSequenceIdStorico();
						 gStr.setIdStorico(sIdStor);
						 gStr.setMiUtente(miUtente);
						 gStr.setDataUltimaModifica(oggi);
						 graduatoriaHome.saveOrUpdate(g, gStr);
					}
					
				}
				
				graduatoria.setPunteggioTitolo(new BigDecimal(schedaValutazioneBean.getTotaleTitoli().replace(",", ".")));
				graduatoria.setPunteggioEsperienza(new BigDecimal(schedaValutazioneBean.getTotaleEspProf().replace(",", ".")));
				graduatoria.setPunteggio(new BigDecimal(schedaValutazioneBean.getTotaleScheda().replace(",", ".")));
				graduatoria.setPunteggioLaurea(new BigDecimal(schedaValutazioneBean.getTotale()[0].replace(",", ".")));
				graduatoria.setPunteggioAltraLaurea(new BigDecimal(schedaValutazioneBean.getTotale()[1].replace(",", ".")));
				graduatoria.setPunteggioAltraLaureaBis(new BigDecimal(schedaValutazioneBean.getTotale()[2].replace(",", ".")));
				graduatoria.setPunteggioIdoneita(new BigDecimal(schedaValutazioneBean.getTotale()[5].replace(",", ".")));
				graduatoria.setPunteggioIdoneitaNazionale(new BigDecimal(schedaValutazioneBean.getTotale()[6].replace(",", ".")));
				graduatoria.setPunteggioPubblicazione(new BigDecimal(schedaValutazioneBean.getTotale()[4].replace(",", ".")));
				graduatoria.setPunteggioSpecDottBorse(new BigDecimal(schedaValutazioneBean.getTotale()[3].replace(",", ".")));
				graduatoria.setPunteggioAbilitazioneCorsiAggAltriTitoli(new BigDecimal(schedaValutazioneBean.getTotale()[7].replace(",", ".")));
				graduatoria.setExAequo(null);
				graduatoria.setExAequoRisolto(null);
				graduatoria.setColor(null);
				graduatoria.setDataIstruttoria(new Date(System.currentTimeMillis()));
				if(schedaValutazioneBean.getNote()!= null && !schedaValutazioneBean.getNote().equals("")){
					graduatoria.setNote(Hibernate.createClob(schedaValutazioneBean.getNote()));
				}
		
				
				//STORICO
				GraduatoriaStorico graduatoriaStr = new GraduatoriaStorico();
				PropertyUtils.copyProperties(graduatoriaStr, graduatoria);
				graduatoriaStr.setIdStorico(sIdStorico);
				graduatoriaStr.setMiUtente(miUtente);
				graduatoriaStr.setDataUltimaModifica(oggi);
				graduatoriaHome.saveOrUpdate(graduatoria, graduatoriaStr);
				
				trx.commit();
			
			}
			catch(Exception e) {
			
				trx.rollback();
				session.close();
				
				logger.error("CalcoloTitoliAction - eccezione in salva scheda", e);
				throw new GestioneErroriException("eccezione in salva scheda");
			}
		}
		
		session.close();
	}
	
	void saveRequisitiminimiReg(List<RequisitiMinimiReg> requisitiMinimiRegList,Session session, String sIdStorico, String miUtente, Timestamp oggi) throws Exception{
		
		for (RequisitiMinimiReg requisitiMinimiReg : requisitiMinimiRegList){
				RequisitiMinimiReg req = requisitiMinimiRegHome.findById(requisitiMinimiReg.getIdDomandaReq());
				
					if(!(requisitiMinimiReg.getPunteggioLaurea().compareTo(req.getPunteggioLaurea())==0)){
						//punteggio laurea variato
						requisitiMinimiReg.setFlgElabManualeLaurea("true");
					} 
					if(!(requisitiMinimiReg.getPunteggioAbilitazione().compareTo(req.getPunteggioAbilitazione())==0)){
						//punteggio abilitazione variato
						requisitiMinimiReg.setFlgElabManualeAbilitazione("true");
					}
			
				session.saveOrUpdate(requisitiMinimiReg);
				
				//STORICO
				RequisitiMinimiRegStorico strReqMinReg = new RequisitiMinimiRegStorico();
				PropertyUtils.copyProperties(strReqMinReg, requisitiMinimiReg);
				strReqMinReg.setIdStorico(sIdStorico);
				strReqMinReg.setMiUtente(miUtente);
				strReqMinReg.setDataUltimaModifica(oggi);
				session.saveOrUpdate(strReqMinReg);
		
		}
		
		
	}
	
void saveAltraLaureaReg(List<AltraLaureaReg> altraLaureaRegList,Session session, String sIdStorico, String miUtente, Timestamp oggi) throws Exception{
		
		for (AltraLaureaReg altraLaureaReg : altraLaureaRegList){
			session.saveOrUpdate(altraLaureaReg);
			//STORICO
			AltraLaureaRegStorico strAltraLaureaReg = new AltraLaureaRegStorico();
			PropertyUtils.copyProperties(strAltraLaureaReg, altraLaureaReg);
			strAltraLaureaReg.setIdStorico(sIdStorico);
			strAltraLaureaReg.setMiUtente(miUtente);
			strAltraLaureaReg.setDataUltimaModifica(oggi);
			session.saveOrUpdate(strAltraLaureaReg);
		
		}
	}
void saveAltraLaureaBisReg(List<AltraLaureaBisReg> altraLaureaBisRegList,Session session, String sIdStorico, String miUtente, Timestamp oggi) throws Exception{
	
	for (AltraLaureaBisReg altraLaureaBisReg : altraLaureaBisRegList){
	
		session.saveOrUpdate(altraLaureaBisReg);
		//STORICO
		AltraLaureaBisRegStorico strAltraLaureaBisReg = new AltraLaureaBisRegStorico();
		PropertyUtils.copyProperties(strAltraLaureaBisReg, altraLaureaBisReg);
		strAltraLaureaBisReg.setIdStorico(sIdStorico);
		strAltraLaureaBisReg.setMiUtente(miUtente);
		strAltraLaureaBisReg.setDataUltimaModifica(oggi);
		session.saveOrUpdate(strAltraLaureaBisReg);
		
	}
}
void saveIdoneita(List<IdoneitaReg> idoneitaReglist,Session session, String sIdStorico, String miUtente, Timestamp oggi) throws Exception{
	
	session.saveOrUpdate(idoneitaReglist.get(0));
	//STORICO
	IdoneitaRegStorico strIdoneitaReg = new IdoneitaRegStorico();
	PropertyUtils.copyProperties(strIdoneitaReg, idoneitaReglist.get(0));
	strIdoneitaReg.setIdStorico(sIdStorico);
	strIdoneitaReg.setMiUtente(miUtente);
	strIdoneitaReg.setDataUltimaModifica(oggi);
	session.saveOrUpdate(strIdoneitaReg);
}

	 void saveSpecializzazioneReg(List<SpecializzazioneReg> specializzazioneRegList,Session session, String sIdStorico, String miUtente, Timestamp oggi) throws Exception{
		
		for (SpecializzazioneReg specializzazioneReg : specializzazioneRegList){
				session.saveOrUpdate(specializzazioneReg);
				//STORICO
				SpecializzazioneRegStorico strSpecializzazioneReg = new SpecializzazioneRegStorico();
				PropertyUtils.copyProperties(strSpecializzazioneReg, specializzazioneReg);
				SpecializzazioneRegStoricoId strSpecializzazioneRegId = new SpecializzazioneRegStoricoId();
				strSpecializzazioneRegId.setIdStorico(sIdStorico);
				strSpecializzazioneRegId.setIdSpecializzazione(specializzazioneReg.getIdSpecializzazione());
				strSpecializzazioneReg.setId(strSpecializzazioneRegId);
				strSpecializzazioneReg.setMiUtente(miUtente);
				strSpecializzazioneReg.setDataUltimaModifica(oggi);
				session.saveOrUpdate(strSpecializzazioneReg);
					
		}
	}
	
	 void saveDottoratoReg(List<DottoratoReg> dottoratoRegList,Session session, String sIdStorico, String miUtente, Timestamp oggi) throws Exception{
		for (DottoratoReg dottoratoReg : dottoratoRegList){
			
			session.saveOrUpdate(dottoratoReg);
			//STORICO
			DottoratoRegStorico strDottoratoReg = new DottoratoRegStorico();
			PropertyUtils.copyProperties(strDottoratoReg, dottoratoReg);
			DottoratoRegStoricoId strDottoratoRegId = new DottoratoRegStoricoId();
			strDottoratoRegId.setIdStorico(sIdStorico);
			strDottoratoRegId.setIdDottorato(dottoratoReg.getIdDottorato());
			strDottoratoReg.setId(strDottoratoRegId);
			strDottoratoReg.setMiUtente(miUtente);
			strDottoratoReg.setDataUltimaModifica(oggi);
			session.saveOrUpdate(strDottoratoReg);
			
		}
	}
	
	 void saveBorsaStudioReg(List<BorsaStudioReg> borsaStudioRegList,Session session, String sIdStorico, String miUtente, Timestamp oggi) throws Exception{
		for (BorsaStudioReg borsaStudioReg : borsaStudioRegList){
			
			session.saveOrUpdate(borsaStudioReg);
			//STORICO
			BorsaStudioRegStorico strBorsaReg = new BorsaStudioRegStorico();
			PropertyUtils.copyProperties(strBorsaReg, borsaStudioReg);
			BorsaStudioRegStoricoId strBorsaRegId = new BorsaStudioRegStoricoId();
			strBorsaRegId.setIdStorico(sIdStorico);
			strBorsaRegId.setIdBorsaStudio(borsaStudioReg.getIdBorsaStudio());
			strBorsaReg.setId(strBorsaRegId);
			strBorsaReg.setMiUtente(miUtente);
			strBorsaReg.setDataUltimaModifica(oggi);
			session.saveOrUpdate(strBorsaReg);
		
		}
	}
	
	 void savePubblicazioneReg(List<PubblicazioneReg> pubblicazioneRegList,Session session, String sIdStorico, String miUtente, Timestamp oggi) throws Exception{
		for (PubblicazioneReg pubblicazioneReg : pubblicazioneRegList){
			
			session.saveOrUpdate(pubblicazioneReg);
			//STORICO
			PubblicazioneRegStorico strPubblicazioneReg = new PubblicazioneRegStorico();
			PropertyUtils.copyProperties(strPubblicazioneReg, pubblicazioneReg);
			PubblicazioneRegStoricoId strPubblicazioneRegId = new PubblicazioneRegStoricoId();
			strPubblicazioneRegId.setIdStorico(sIdStorico);
			strPubblicazioneRegId.setIdPubblicazione(pubblicazioneReg.getIdPubblicazione());
			strPubblicazioneReg.setId(strPubblicazioneRegId);
			strPubblicazioneReg.setMiUtente(miUtente);
			strPubblicazioneReg.setDataUltimaModifica(oggi);
			session.saveOrUpdate(strPubblicazioneReg);
		
		}
	}
	
	 void saveCorsoAggiornamentoReg(List<CorsoAggiornamentoReg> corsoAggiornamentoRegList,Session session, String sIdStorico, String miUtente, Timestamp oggi) throws Exception{
			for (CorsoAggiornamentoReg corsoAggiornamentoReg : corsoAggiornamentoRegList){
			
				session.saveOrUpdate(corsoAggiornamentoReg);
				//STORICO
				CorsoAggiornamentoRegStorico strCorsoAggiornamentoReg = new CorsoAggiornamentoRegStorico();
				PropertyUtils.copyProperties(strCorsoAggiornamentoReg, corsoAggiornamentoReg);
				CorsoAggiornamentoRegStoricoId strCorsoAggiornamentoRegId = new CorsoAggiornamentoRegStoricoId();
				strCorsoAggiornamentoRegId.setIdStorico(sIdStorico);
				strCorsoAggiornamentoRegId.setIdCorsoAgg(corsoAggiornamentoReg.getIdCorsoAgg());
				strCorsoAggiornamentoReg.setId(strCorsoAggiornamentoRegId);
				strCorsoAggiornamentoReg.setMiUtente(miUtente);
				strCorsoAggiornamentoReg.setDataUltimaModifica(oggi);
				session.saveOrUpdate(strCorsoAggiornamentoReg);
		
			}
	}
	
	 void saveAltroTitoloReg(List<AltroTitoloReg> altroTitoloRegList,Session session, String sIdStorico, String miUtente, Timestamp oggi) throws Exception{
		for (AltroTitoloReg altroTitoloReg : altroTitoloRegList){
			
			session.saveOrUpdate(altroTitoloReg);
			//STORICO
			AltroTitoloRegStorico strAltroTitoloReg = new AltroTitoloRegStorico();
			PropertyUtils.copyProperties(strAltroTitoloReg, altroTitoloReg);
			AltroTitoloRegStoricoId strAltroTitoloRegId = new AltroTitoloRegStoricoId();
			strAltroTitoloRegId.setIdStorico(sIdStorico);
			strAltroTitoloRegId.setIdAltroTitolo(altroTitoloReg.getIdAltroTitolo());
			strAltroTitoloReg.setId(strAltroTitoloRegId);
			strAltroTitoloReg.setMiUtente(miUtente);
			strAltroTitoloReg.setDataUltimaModifica(oggi);
			session.saveOrUpdate(strAltroTitoloReg);
	
		}
	}

}
