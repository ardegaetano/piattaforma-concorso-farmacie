package com.accenture.CCFarm.action;

import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.DatiUtenza;
import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;

public class GestioneUtenzeAction {
	
	private static final Logger logger = CommonLogger.getLogger("GestioneUtenzeAction");
	private UtenteHome utenteHome;
	private LogInHome loginHome;
	
	
	
	public GestioneUtenzeAction() throws GestioneErroriException {
		
		try {
			utenteHome = new UtenteHome();
		}
		catch(Exception e) {
			logger.error("GestioneUtenzeAction - inizializzazione fallita", e);
			throw new GestioneErroriException("GestioneUtenzeAction - inizializzazione fallita");
		}
		
	}
	
	public List<DatiUtenza> ricercaUtentiCandidati(DatiUtenza datiUtenza) throws GestioneErroriException {
		List<DatiUtenza> elencoUtenti = utenteHome.ricercaUtentiCandidati(datiUtenza);
		return elencoUtenti;
	}
	
	public void inviaCredenzialiPecUtente(String idUtente, String sNuovaPEC) throws GestioneErroriException {
		Utente utente = utenteHome.findById(idUtente);
		if(sNuovaPEC!=null)
			utente.setPecMail(sNuovaPEC);
		String sUtenza = getUtenzaByUtente(utente);
		utenteHome.reinvioCredenzialiPecUtente(utente, sUtenza, sNuovaPEC);
	}
	
	private String getUtenzaByUtente(Utente utente) throws GestioneErroriException {
		String sUser = null;
		loginHome = new LogInHome();
		LogIn login = new LogIn();
		login.setIdUtente(utente.getIdUtente());
		login.setIdRegione(utente.getCodRegUtente());
		List lista = loginHome.findByExample(login);
		sUser = ((LogIn)lista.get(0)).getUtenza();
		return sUser;
	}
	
	
	
}