package com.accenture.CCFarm.action;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


public class ScaricaBando extends HttpServlet {
	 
	Logger logger = CommonLogger.getLogger("ScaricaBando");
	
    public ScaricaBando() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    	doPost(request, response);
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	try {
			//recupero dalla Session	
			HttpSession session = request.getSession();
			
			UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
			String codiceRegione = utenteReg.getCodRegione();
			
			//Recupero del file su DB
			DatiBandoHome bandoHome = new DatiBandoHome();
			DatiBando datiBando = bandoHome.findById(codiceRegione);
			InputStream streamB = null;
			if(datiBando!=null) {
				Blob fileBando = datiBando.getFileBando();
				if(fileBando!=null)
					streamB = fileBando.getBinaryStream();
				else
					//Recupero del file in sessione
					streamB = (InputStream)session.getAttribute(RepositorySession.FILE_BANDO); 
			}
			else {
				//Recupero del file in sessione
				streamB = (InputStream)session.getAttribute(RepositorySession.FILE_BANDO); 
			}
	    	byte[] pdfData = IOUtils.toByteArray(streamB);
	    	
            response.reset(); 
            response.setContentType("application/pdf"); 
            response.setContentLength((int) pdfData.length); 
            response.setHeader("Content-disposition", "attachment; filename=\"Bando.pdf\"");
            ByteArrayInputStream in = null;             
            BufferedInputStream input = null; 
            BufferedOutputStream output = null; 
            final int buffersize = pdfData.length; 
	        try {
	        	in = new ByteArrayInputStream(pdfData);
	        	input = new BufferedInputStream(in); 
	        	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
	        	byte[] buffer = new byte[buffersize]; 
	        	for (int length; (length = input.read(buffer)) > 0;) 
	        	{	 
	        		output.write(buffer, 0, length); 
	        	}            	
	        } finally {
	        	if(input!=null){
	        		try {
	        			input.close();
	        			output.close();
	        		}catch (IOException ioex) {
	        			logger.info("ScaricaBando: Annulla operazione" + ioex);
	            	}	
	        	}
	        }
	        
    	} catch (Exception e) {
    		logger.error("ScaricaBando: " + e);
    		response.sendRedirect(AppProperties.getAppProperties().getProperty("BaseUrl")+"/jsp/errorPage.jsf");
    	}		
	}
	
}
