package com.accenture.CCFarm.action;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;

import com.accenture.CCFarm.Bean.CorsoAgg;
import com.accenture.CCFarm.DAO.AltraLaureaReg;
import com.accenture.CCFarm.DAO.AltraLaureaBisReg;
import com.accenture.CCFarm.DAO.AltraLaureaBisRegHome;
import com.accenture.CCFarm.DAO.AltraLaureaRegHome;
import com.accenture.CCFarm.DAO.AltroTitoloReg;
import com.accenture.CCFarm.DAO.AltroTitoloRegHome;
import com.accenture.CCFarm.DAO.BorsaStudioReg;
import com.accenture.CCFarm.DAO.BorsaStudioRegHome;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoReg;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoRegHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutivaReg;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutivaRegHome;
import com.accenture.CCFarm.DAO.DottoratoReg;
import com.accenture.CCFarm.DAO.DottoratoRegHome;
import com.accenture.CCFarm.DAO.IdoneitaReg;
import com.accenture.CCFarm.DAO.IdoneitaRegHome;
import com.accenture.CCFarm.DAO.ProvinciaHome;
import com.accenture.CCFarm.DAO.PubblicazioneReg;
import com.accenture.CCFarm.DAO.PubblicazioneRegHome;
import com.accenture.CCFarm.DAO.SpecializzazioneReg;
import com.accenture.CCFarm.DAO.SpecializzazioneRegHome;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.TitoliStudioCarrieraBean;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.StringUtil;

public class TitoliStudioAction {
	
	
	java.util.Date dataSys= new java.util.Date();
    private java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
    Logger logger =Logger.getLogger("Bando");
	java.util.Date date;
  
	UtenteCandidaturaReg utenteCandidatura;
	
	List province;
	ProvinciaHome provinciaHome;
	
	AltraLaureaReg altraLaurea;
	AltraLaureaRegHome altraLaureaHome;
	AltraLaureaBisReg altraLaureaBis;
	AltraLaureaBisRegHome altraLaureaBisHome;
	SpecializzazioneReg specializzazione;
	SpecializzazioneRegHome specializzazioneHome;
	BorsaStudioReg borsaStudio;
	BorsaStudioRegHome borsaStudioHome;
	DottoratoReg dottorato;
	DottoratoRegHome dottoratoHome;
	AltroTitoloReg altroTitolo;
	AltroTitoloRegHome altroTitoloHome;
	CorsoAggiornamentoReg corsoAggiornamento;
	CorsoAggiornamentoRegHome corsoAggiornamentoHome;
	PubblicazioneReg pubblicazione;
	PubblicazioneRegHome pubblicazioneHome;
	IdoneitaReg idoneita;
	IdoneitaRegHome idoneitaHome;
	DichiarazioneSostitutivaReg dichiarazioneSostitutiva;
	DichiarazioneSostitutivaRegHome dichiarazioneSostitutivaHome;
	
	ArrayList<AltraLaureaReg> altreLauree;
	ArrayList<AltraLaureaBisReg> altreLaureeBis;
	ArrayList<SpecializzazioneReg> specializzazioni;
	ArrayList<BorsaStudioReg> borseStudio;
	ArrayList<DottoratoReg> dottorati;
	ArrayList<AltroTitoloReg> altriTitoli;
	ArrayList<CorsoAggiornamentoReg> corsiAggiornamento;
	ArrayList<PubblicazioneReg> pubblicazioni;
	ArrayList<IdoneitaReg> listaIdoneita;
	
	ArrayList<com.accenture.CCFarm.Bean.Pubblicazione> listaPubb;
	ArrayList<com.accenture.CCFarm.Bean.Specializzazione> listaSpec;
	ArrayList<CorsoAgg> listaCorsi;
	ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis> listaLaureeBis;
	ArrayList<com.accenture.CCFarm.Bean.Dottorato> listaDott;
	ArrayList<com.accenture.CCFarm.Bean.AltroTitolo> listaTitoli;
	ArrayList<com.accenture.CCFarm.Bean.BorsaStudio> listaBorse;
	
	private SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	
	
	public TitoliStudioAction(){
		
		altraLaureaHome = new AltraLaureaRegHome();
		altraLaureaBisHome = new AltraLaureaBisRegHome();
		specializzazioneHome = new SpecializzazioneRegHome();
		borsaStudioHome = new BorsaStudioRegHome();
		dottoratoHome = new DottoratoRegHome();
		altroTitoloHome = new AltroTitoloRegHome();
		corsoAggiornamentoHome = new CorsoAggiornamentoRegHome();
		pubblicazioneHome = new PubblicazioneRegHome();
	    idoneitaHome = new IdoneitaRegHome();
	    dichiarazioneSostitutivaHome = new DichiarazioneSostitutivaRegHome();
	} 
	
	public boolean loadPaginaInserimento(String idDomanda,TitoliStudioCarrieraBean titoliStudioCarriera) throws GestioneErroriException
	{
	    	try
	    	{
	    		Date data_corso_appoggio = ((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataInizioCorsi();
	    	    Date data_pubb_appoggio = ((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataInizioPubblicazioni();
	    	    
	    	    titoliStudioCarriera.setDataInizioCorsoReg(StringUtil.dateToString(data_corso_appoggio,sdf));
	    	    titoliStudioCarriera.setDataInizioPubblicazioneReg(StringUtil.dateToString(data_pubb_appoggio,sdf));
	    		
	    		
	    		//popolo altra laurea 
	    		altraLaurea = new AltraLaureaReg();
	    		altraLaurea = altraLaureaHome.findById(idDomanda);
	    		
	    		//popolo altra laurea bis
	    		altreLaureeBis = new ArrayList<AltraLaureaBisReg>();
	    		altraLaureaBis = new AltraLaureaBisReg();
	    		altraLaureaBis.setIdDomandaLaureaBis(idDomanda);
	    		altreLaureeBis = (ArrayList<AltraLaureaBisReg>) altraLaureaBisHome.findByExample(altraLaureaBis);	    		
	    		//popolo specializzazione
	    		specializzazioni = new ArrayList<SpecializzazioneReg>();
	    		specializzazione = new SpecializzazioneReg();
	    		specializzazione.setIdDomandaSpec(idDomanda);
	    		specializzazioni = (ArrayList<SpecializzazioneReg>) specializzazioneHome.findByExample(specializzazione);
	    		
	    		//popolo borse di studio 
	    		borseStudio = new ArrayList<BorsaStudioReg>();
	    		borsaStudio = new BorsaStudioReg();
	    		borsaStudio.setIdDomandaBorsaStudio(idDomanda);
	    		borseStudio = (ArrayList<BorsaStudioReg>)borsaStudioHome.findByExample(borsaStudio);
	    	
	    		//popolo dottorati
	    		dottorati = new ArrayList<DottoratoReg>();
	    		dottorato = new DottoratoReg();
	    		dottorato.setIdDomandaDottorato(idDomanda);
	    		dottorati = (ArrayList<DottoratoReg>)dottoratoHome.findByExample(dottorato);
	
	    		//popolo altri titoli
	    		altriTitoli = new ArrayList<AltroTitoloReg>();
	       		altroTitolo = new AltroTitoloReg();
	    		altroTitolo.setIdDomandaTitolo(idDomanda);
	    		altriTitoli = (ArrayList<AltroTitoloReg>) altroTitoloHome.findByExample(altroTitolo);
	    		
	    		//popolo corsi di aggiornamento
	    		corsiAggiornamento = new ArrayList<CorsoAggiornamentoReg>();
	    		corsoAggiornamento = new CorsoAggiornamentoReg();
	    		corsoAggiornamento.setIdDomandaAgg(idDomanda);
	    		corsiAggiornamento = (ArrayList<CorsoAggiornamentoReg>) corsoAggiornamentoHome.findByExample(corsoAggiornamento);
	    		
	    		//popolo pubblicazioni
	    		pubblicazioni = new ArrayList<PubblicazioneReg>();
	    		pubblicazione = new PubblicazioneReg();
	    		pubblicazione.setIdDomandaPubbl(idDomanda);
	    		pubblicazioni = (ArrayList<PubblicazioneReg>) pubblicazioneHome.findByExample(pubblicazione);
	    		
	    		//popolo idoneita
	    		idoneita = new IdoneitaReg();
	    		idoneita = idoneitaHome.findById(idDomanda);
	    		
	    		
	    		if(altraLaurea!=null){	    			
	    				PropertyUtils.copyProperties(titoliStudioCarriera, altraLaurea);	    				
	    		} 
	    		
	    		
	    		listaCorsi = new ArrayList<CorsoAgg>();
	    		CorsoAgg corso;
	    		if(corsiAggiornamento!=null){
	    			for (int i=0;i<corsiAggiornamento.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				corso = new CorsoAgg();
	    				corso.setDataInizioCorsoAggStringa(StringUtil.dateToString(corsiAggiornamento.get(i).getDataInizioCorsoAgg(),sdf));
	    				corso.setDataFineCorsoAggStringa(StringUtil.dateToString(corsiAggiornamento.get(i).getDataFineCorsoAgg(),sdf));
	    				corso.setIdCorsoAgg(corsiAggiornamento.get(i).getIdCorsoAgg());
	    				corso.setDichiarazioneCorsoAgg(corsiAggiornamento.get(i).getDichiarazioneCorsoAgg());
	    				corso.setFlagEsteroCorsoAgg(corsiAggiornamento.get(i).getFlagEsteroCorsoAgg());
	    				corso.setDataInizioCorsoAgg(corsiAggiornamento.get(i).getDataInizioCorsoAgg());
	    				corso.setDataFineCorsoAgg(corsiAggiornamento.get(i).getDataFineCorsoAgg());
	    				corso.setOrganizzatoCorsoAgg(corsiAggiornamento.get(i).getOrganizzatoCorsoAgg());
	    				corso.setTitoloCorsoAgg(corsiAggiornamento.get(i).getTitoloCorsoAgg());
	    				corso.setTotOreCorsoAgg(corsiAggiornamento.get(i).getTotOreCorsoAgg());
	    				listaCorsi.add(corso);
	    			}
	    		
	    		}    
	    		titoliStudioCarriera.setListaCorsiAgg(listaCorsi);
	    		
	    		
	    		listaTitoli = new ArrayList<com.accenture.CCFarm.Bean.AltroTitolo>();
	    		com.accenture.CCFarm.Bean.AltroTitolo titolo;
	    		if(altriTitoli!=null){
	    			for (int i=0;i<altriTitoli.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				titolo = new com.accenture.CCFarm.Bean.AltroTitolo();
	    				titolo.setDataRilascioAltroTitoloStringa(StringUtil.dateToString(altriTitoli.get(i).getDataRilascioAltroTitolo(),sdf));
	    				titolo.setIdAltroTitolo(altriTitoli.get(i).getIdAltroTitolo());
	    				titolo.setDataRilascioAltroTitolo(altriTitoli.get(i).getDataRilascioAltroTitolo());
	    				titolo.setDescAltroTitolo(altriTitoli.get(i).getDescAltroTitolo());
	    				titolo.setDurataAltroTitolo(altriTitoli.get(i).getDurataAltroTitolo());
	    				titolo.setEsameFinaleAltroTitolo(altriTitoli.get(i).getEsameFinaleAltroTitolo());
	    				titolo.setFlagEsteroAltroTitolo(altriTitoli.get(i).getFlagEsteroAltroTitolo());
	    				titolo.setNoteAltroTitolo(altriTitoli.get(i).getNoteAltroTitolo());
	    				titolo.setRilascioAltroTitolo(altriTitoli.get(i).getRilascioAltroTitolo());
	    				listaTitoli.add(titolo);
	    			}
	    		
	    		}  
	    		titoliStudioCarriera.setListaAltriTitoli(listaTitoli);
	    		
	    		
	    		listaLaureeBis = new ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis>();
	    		com.accenture.CCFarm.Bean.AltraLaureaBis laureaBis;
	    		if(altreLaureeBis!=null){
	    			for (int i=0;i<altreLaureeBis.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				laureaBis = new com.accenture.CCFarm.Bean.AltraLaureaBis();
	    				laureaBis.setDataSecondaLaureaBisStringa(StringUtil.dateToString(altreLaureeBis.get(i).getDataSecondaLaureaBis(),sdf));
	    				laureaBis.setIdAltraLaureaBis(altreLaureeBis.get(i).getIdAltraLaureaBis());
	    				laureaBis.setIdSecondaLaureaBis(altreLaureeBis.get(i).getIdSecondaLaureaBis());	    				
	    				laureaBis.setDataSecondaLaureaBis(altreLaureeBis.get(i).getDataSecondaLaureaBis());
	    				laureaBis.setDescUniSecondaLaureaBis(altreLaureeBis.get(i).getDescUniSecondaLaureaBis());
	    				laureaBis.setFlagEsteroSecondaLaureaBis(altreLaureeBis.get(i).getFlagEsteroSecondaLaureaBis());
	    				laureaBis.setLuogoSecondaLaureaBis(altreLaureeBis.get(i).getLuogoSecondaLaureaBis());
	    				laureaBis.setNazioneSecondaLaureaBis(altreLaureeBis.get(i).getNazioneSecondaLaureaBis());
	    				listaLaureeBis.add(laureaBis);
	    				
	    			}
	    		
	    		}  
	    		titoliStudioCarriera.setListaAltreLaureeBis(listaLaureeBis);
	    		
	    		
	    		listaSpec = new ArrayList<com.accenture.CCFarm.Bean.Specializzazione>();
	    		com.accenture.CCFarm.Bean.Specializzazione spec;
	    		if(specializzazioni!=null){	    			
	    			for (int i=0;i<specializzazioni.size();i++){
	    				spec = new com.accenture.CCFarm.Bean.Specializzazione();
	    				spec.setIdSpecializzazione(specializzazioni.get(i).getIdSpecializzazione());
	    				spec.setDenominazioneSpec(specializzazioni.get(i).getDenominazioneSpec());
	    				spec.setDescrFacoltaSpec(specializzazioni.get(i).getDescrFacoltaSpec());
	    				spec.setDescrUniversitaSpec(specializzazioni.get(i).getDescrUniversitaSpec());
	    				spec.setDurataSpec(specializzazioni.get(i).getDurataSpec());
	    				spec.setFlagEsteroSpec(specializzazioni.get(i).getFlagEsteroSpec());
	    				spec.setLuogoSpec(specializzazioni.get(i).getLuogoSpec());
	    				spec.setNazioneSpec(specializzazioni.get(i).getNazioneSpec());
	    				listaSpec.add(spec);
	    			}
	    		
	    		}  
	    		titoliStudioCarriera.setListaSpecializzazioni(listaSpec);
	    		
	    		
	    		listaPubb = new ArrayList<com.accenture.CCFarm.Bean.Pubblicazione>();
	    		com.accenture.CCFarm.Bean.Pubblicazione pubb;
	    		if(pubblicazioni!=null){
	    			for (int i=0;i<pubblicazioni.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				pubb = new com.accenture.CCFarm.Bean.Pubblicazione();
	    				pubb.setDataPubblicazioneStringa(StringUtil.dateToString(pubblicazioni.get(i).getDataPubblicazione(),sdf));
	    				pubb.setIdPubblicazione(pubblicazioni.get(i).getIdPubblicazione());
	    				pubb.setAutorePubblicazione(pubblicazioni.get(i).getAutorePubblicazione());
	    				pubb.setCodIsbn(pubblicazioni.get(i).getCodIsbn());
	    				pubb.setDataPubblicazione(pubblicazioni.get(i).getDataPubblicazione());
	    				pubb.setEditorePubblicazione(pubblicazioni.get(i).getEditorePubblicazione());
	    				pubb.setTipoPubblicazione(pubblicazioni.get(i).getTipoPubblicazione());
	    				pubb.setTitoloPubblicazione(pubblicazioni.get(i).getTitoloPubblicazione());
	    				listaPubb.add(pubb);
	    			}
	    		
	    		}  
	    		titoliStudioCarriera.setListaPubblicazioni(listaPubb);
	    		
	    		
	    		listaBorse = new ArrayList<com.accenture.CCFarm.Bean.BorsaStudio>();
	    		com.accenture.CCFarm.Bean.BorsaStudio borsa;
	    		if(borseStudio!=null){
	    			for (int i=0;i<borseStudio.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				borsa = new com.accenture.CCFarm.Bean.BorsaStudio();
	    				borsa.setDataInizioBorsaStringa(StringUtil.dateToString(borseStudio.get(i).getDataInizioBorsa(),sdf));
	    				borsa.setDataFineBorsaStringa(StringUtil.dateToString(borseStudio.get(i).getDataFineBorsa(),sdf));
	    				borsa.setIdBorsaStudio(borseStudio.get(i).getIdBorsaStudio());
	    				borsa.setDataFineBorsa(borseStudio.get(i).getDataFineBorsa());
	    				borsa.setDataInizioBorsa(borseStudio.get(i).getDataInizioBorsa());
	    				borsa.setDenominazioneBorsa(borseStudio.get(i).getDenominazioneBorsa());
	    				borsa.setDescrFacoltaBorsa(borseStudio.get(i).getDescrFacoltaBorsa());
	    				borsa.setDescrUniversitaBorsa(borseStudio.get(i).getDescrUniversitaBorsa());
	    				borsa.setFlagEsteroBorsa(borseStudio.get(i).getFlagEsteroBorsa());
	    				borsa.setLuogoBorsa(borseStudio.get(i).getLuogoBorsa());
	    				borsa.setNazioneBorsa(borseStudio.get(i).getNazioneBorsa());
	    				listaBorse.add(borsa);
	    			}
	    		
	    		}
	    		titoliStudioCarriera.setListaBorseStudio(listaBorse);
	    		
	    		
	    		listaDott = new ArrayList<com.accenture.CCFarm.Bean.Dottorato>();
	    		com.accenture.CCFarm.Bean.Dottorato dott;
	    		if(dottorati!=null){
	    			for (int i=0;i<dottorati.size();i++){ 
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				dott = new com.accenture.CCFarm.Bean.Dottorato();
	    				dott.setDataInizioDottoratoStringa(StringUtil.dateToString(dottorati.get(i).getDataInizioDottorato(),sdf));
	    				dott.setDataFineDottoratoStringa(StringUtil.dateToString(dottorati.get(i).getDataFineDottorato(),sdf));
	    				dott.setIdDottorato(dottorati.get(i).getIdDottorato());
	    				dott.setDataFineDottorato(dottorati.get(i).getDataFineDottorato());
	    				dott.setDataInizioDottorato(dottorati.get(i).getDataInizioDottorato());
	    				dott.setDenominazioneDottorato(dottorati.get(i).getDenominazioneDottorato());
	    				dott.setDescrFacoltaDottorato(dottorati.get(i).getDescrFacoltaDottorato());
	    				dott.setDescrUniversitaDottorato(dottorati.get(i).getDescrUniversitaDottorato());
	    				dott.setFlagEsteroDottorato(dottorati.get(i).getFlagEsteroDottorato());
	    				dott.setLuogoDottorato(dottorati.get(i).getLuogoDottorato());
	    				dott.setNazioneDottorato(dottorati.get(i).getNazioneDottorato());
	    				listaDott.add(dott);
	    			}
	    		
	    		}
	    		titoliStudioCarriera.setListaDottorati(listaDott);
	    		
	    		
//	    		if (listaIdoneita!=null){
//	    			for (int i=0;i<listaIdoneita.size();i++){
//	    				PropertyUtils.copyProperties(titoliStudioCarriera, listaIdoneita.get(i));
//	    			}
//	    			
//	    		}
	    		
	    		if (idoneita!=null){	    			
	    				PropertyUtils.copyProperties(titoliStudioCarriera, idoneita);	    			
	    		}
	    		
	    		
	    	}
	    	catch(RuntimeException re)
	    	{
	    		re.printStackTrace();
	    		return false;
	    	} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
	   		
	   		return true;
	    }

	
	public boolean updateDAO(String idDomanda,TitoliStudioCarrieraBean titoliStudioCarrieraBean) throws GestioneErroriException
	{
	
			//preleva i dati dal bean di pagina e li copia nei bean di hibernate
			try
					{
				        ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis> listaLaureeBis;
				        listaLaureeBis = (ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis>)titoliStudioCarrieraBean.getListaAltreLaureeBis();
				        ArrayList<com.accenture.CCFarm.Bean.AltroTitolo> listaTitoli;
				        listaTitoli = (ArrayList<com.accenture.CCFarm.Bean.AltroTitolo>)titoliStudioCarrieraBean.getListaAltriTitoli();
				        ArrayList<com.accenture.CCFarm.Bean.CorsoAgg> listaCorsi;
				        listaCorsi = (ArrayList<com.accenture.CCFarm.Bean.CorsoAgg>)titoliStudioCarrieraBean.getListaCorsiAgg();
				        ArrayList<com.accenture.CCFarm.Bean.Dottorato> listaDott;
				        listaDott = (ArrayList<com.accenture.CCFarm.Bean.Dottorato>)titoliStudioCarrieraBean.getListaDottorati();
				        ArrayList<com.accenture.CCFarm.Bean.Pubblicazione> listaPubb;
				        listaPubb = (ArrayList<com.accenture.CCFarm.Bean.Pubblicazione>)titoliStudioCarrieraBean.getListaPubblicazioni();
				        ArrayList<com.accenture.CCFarm.Bean.Specializzazione> listaSpec;
				        listaSpec = (ArrayList<com.accenture.CCFarm.Bean.Specializzazione>)titoliStudioCarrieraBean.getListaSpecializzazioni();
				        ArrayList<com.accenture.CCFarm.Bean.BorsaStudio> listaBorse;
				        listaBorse = (ArrayList<com.accenture.CCFarm.Bean.BorsaStudio>)titoliStudioCarrieraBean.getListaBorseStudio();
				        
				        altraLaurea = new AltraLaureaReg();
				        
				        altreLaureeBis = new ArrayList<AltraLaureaBisReg>();
						altraLaureaBis = null;
						
						specializzazioni = new ArrayList<SpecializzazioneReg>();
						specializzazione = null;
						
						borseStudio = new ArrayList<BorsaStudioReg>();
						borsaStudio = null;
						
						dottorati = new ArrayList<DottoratoReg>();
						dottorato = null;
						
						altriTitoli = new ArrayList<AltroTitoloReg>();
				   		altroTitolo = new AltroTitoloReg();
				   		
				   		idoneita = new IdoneitaReg();
						
						corsiAggiornamento = new ArrayList<CorsoAggiornamentoReg>();
						corsoAggiornamento = null;
						
						pubblicazioni = new ArrayList<PubblicazioneReg>();
						pubblicazione = null;
						
						
						BeanUtils.copyProperties(altraLaurea,titoliStudioCarrieraBean);
						
						altraLaurea.setIdDomandaLaurea(idDomanda);
						
						com.accenture.CCFarm.Bean.AltraLaureaBis laurea_appoggio = null;
						if(listaLaureeBis!=null)
						{
							for (int i=0;i<listaLaureeBis.size();i++)
							{
								altraLaureaBis = new AltraLaureaBisReg();
								laurea_appoggio = listaLaureeBis.get(i);
								
								altraLaureaBis.setIdAltraLaureaBis(laurea_appoggio.getIdAltraLaureaBis());
								altraLaureaBis.setDataSecondaLaureaBis(laurea_appoggio.getDataSecondaLaureaBis()); 
								altraLaureaBis.setDescUniSecondaLaureaBis(laurea_appoggio.getDescUniSecondaLaureaBis());
								altraLaureaBis.setFlagEsteroSecondaLaureaBis(laurea_appoggio.getFlagEsteroSecondaLaureaBis());
								altraLaureaBis.setIdDomandaLaureaBis(idDomanda);
								altraLaureaBis.setLuogoSecondaLaureaBis(laurea_appoggio.getLuogoSecondaLaureaBis());
								altraLaureaBis.setNazioneSecondaLaureaBis(laurea_appoggio.getNazioneSecondaLaureaBis());
								
								altraLaureaBis.setIdSecondaLaureaBis(altraLaureaBisHome.getSequenceIdAltraLaureaBis());								

								altreLaureeBis.add(altraLaureaBis);
							}
						
						}
						
						if(listaPubb!=null)
						{
							for (int i=0;i<listaPubb.size();i++)
							{
								pubblicazione = new PubblicazioneReg();
								
								com.accenture.CCFarm.Bean.Pubblicazione pubb_appoggio = new com.accenture.CCFarm.Bean.Pubblicazione();
								pubb_appoggio = listaPubb.get(i);
								
								pubblicazione.setAutorePubblicazione(pubb_appoggio.getAutorePubblicazione());
								pubblicazione.setCodIsbn(pubb_appoggio.getCodIsbn());
								pubblicazione.setDataPubblicazione(pubb_appoggio.getDataPubblicazione());
								pubblicazione.setEditorePubblicazione(pubb_appoggio.getEditorePubblicazione());
								pubblicazione.setIdDomandaPubbl(idDomanda);
								pubblicazione.setTipoPubblicazione(pubb_appoggio.getTipoPubblicazione());
								pubblicazione.setTitoloPubblicazione(pubb_appoggio.getTitoloPubblicazione());
								pubblicazione.setIdPubblicazione(pubblicazioneHome.getSequenceIdPubblicazione());								

								pubblicazioni.add(pubblicazione);
							}
						
						} 
						
						if(listaTitoli!=null)
						{
							for (int i=0;i<listaTitoli.size();i++)
							{
								altroTitolo = new AltroTitoloReg();
								
								com.accenture.CCFarm.Bean.AltroTitolo titolo_appoggio = new com.accenture.CCFarm.Bean.AltroTitolo();
								titolo_appoggio = listaTitoli.get(i);

								altroTitolo.setDataRilascioAltroTitolo(titolo_appoggio.getDataRilascioAltroTitolo());
								altroTitolo.setDescAltroTitolo(titolo_appoggio.getDescAltroTitolo());
								altroTitolo.setDurataAltroTitolo(titolo_appoggio.getDurataAltroTitolo());
								altroTitolo.setEsameFinaleAltroTitolo(titolo_appoggio.getEsameFinaleAltroTitolo());
								altroTitolo.setFlagEsteroAltroTitolo(titolo_appoggio.getFlagEsteroAltroTitolo());
								altroTitolo.setIdAltroTitolo(altroTitoloHome.getSequenceIdAltroTitolo());
								
								altroTitolo.setIdDomandaTitolo(idDomanda);
								
								altroTitolo.setNoteAltroTitolo(titolo_appoggio.getNoteAltroTitolo());
								altroTitolo.setRilascioAltroTitolo(titolo_appoggio.getRilascioAltroTitolo());								

								altriTitoli.add(altroTitolo);
							}
						
						} 
						
						if(listaSpec!=null)
						{
							for (int i=0;i<listaSpec.size();i++)
							{
								specializzazione = new SpecializzazioneReg();
								com.accenture.CCFarm.Bean.Specializzazione spec_appoggio = new com.accenture.CCFarm.Bean.Specializzazione();
								spec_appoggio = listaSpec.get(i);
							
								specializzazione.setDenominazioneSpec(spec_appoggio.getDenominazioneSpec());
								specializzazione.setDescrFacoltaSpec(spec_appoggio.getDescrFacoltaSpec());
								specializzazione.setDurataSpec(spec_appoggio.getDurataSpec());
								specializzazione.setFlagEsteroSpec(spec_appoggio.getFlagEsteroSpec());
								specializzazione.setIdDomandaSpec(idDomanda);
								specializzazione.setIdSpecializzazione(specializzazioneHome.getSequenceIdSpecializzazione());
								specializzazione.setLuogoSpec(spec_appoggio.getLuogoSpec());
								specializzazione.setNazioneSpec(spec_appoggio.getNazioneSpec());
								specializzazione.setDescrUniversitaSpec(spec_appoggio.getDescrUniversitaSpec());
								
								specializzazioni.add(specializzazione);
							}
						
						} 
						
						if(listaCorsi!=null)
						{
							for (int i=0;i<listaCorsi.size();i++)
							{
								corsoAggiornamento = new CorsoAggiornamentoReg();
								com.accenture.CCFarm.Bean.CorsoAgg corso_appoggio = new com.accenture.CCFarm.Bean.CorsoAgg();
								corso_appoggio = listaCorsi.get(i);
							
								corsoAggiornamento.setDichiarazioneCorsoAgg(corso_appoggio.getDichiarazioneCorsoAgg());
								corsoAggiornamento.setFlagEsteroCorsoAgg(corso_appoggio.getFlagEsteroCorsoAgg());
								corsoAggiornamento.setDataInizioCorsoAgg(corso_appoggio.getDataInizioCorsoAgg());
								corsoAggiornamento.setDataFineCorsoAgg(corso_appoggio.getDataFineCorsoAgg());
								corsoAggiornamento.setIdCorsoAgg(corsoAggiornamentoHome.getSequenceIdCorsoAggiornamento());
								corsoAggiornamento.setIdDomandaAgg(idDomanda);
								corsoAggiornamento.setOrganizzatoCorsoAgg(corso_appoggio.getOrganizzatoCorsoAgg());
								corsoAggiornamento.setTitoloCorsoAgg(corso_appoggio.getTitoloCorsoAgg());
								corsoAggiornamento.setTotOreCorsoAgg(corso_appoggio.getTotOreCorsoAgg());								

								corsiAggiornamento.add(corsoAggiornamento);
							}
						
						} 
						
						if(listaBorse!=null)
						{
							for (int i=0;i<listaBorse.size();i++)
							{
								borsaStudio = new BorsaStudioReg();
								com.accenture.CCFarm.Bean.BorsaStudio borsa_appoggio = new com.accenture.CCFarm.Bean.BorsaStudio();
								borsa_appoggio = listaBorse.get(i);
								
								borsaStudio.setDenominazioneBorsa(borsa_appoggio.getDenominazioneBorsa());
								borsaStudio.setDescrFacoltaBorsa(borsa_appoggio.getDescrFacoltaBorsa());
								borsaStudio.setDescrUniversitaBorsa(borsa_appoggio.getDescrUniversitaBorsa());
								borsaStudio.setFlagEsteroBorsa(borsa_appoggio.getFlagEsteroBorsa());
								borsaStudio.setDataInizioBorsa(borsa_appoggio.getDataInizioBorsa());
								borsaStudio.setDataFineBorsa(borsa_appoggio.getDataFineBorsa());
								borsaStudio.setIdBorsaStudio(borsaStudioHome.getSequenceIdBorsaStudio());
								borsaStudio.setIdDomandaBorsaStudio(idDomanda);
								borsaStudio.setLuogoBorsa(borsa_appoggio.getLuogoBorsa());
								borsaStudio.setNazioneBorsa(borsa_appoggio.getNazioneBorsa());								

								borseStudio.add(borsaStudio);
							}
						
						} 
						
						if(listaDott!=null)
						{
							for (int i=0;i<listaDott.size();i++)
							{
								dottorato = new DottoratoReg();
								com.accenture.CCFarm.Bean.Dottorato dott_appoggio = new com.accenture.CCFarm.Bean.Dottorato();
								dott_appoggio = listaDott.get(i);

								dottorato.setDataFineDottorato(dott_appoggio.getDataFineDottorato());
								dottorato.setDataInizioDottorato(dott_appoggio.getDataInizioDottorato());
								dottorato.setDenominazioneDottorato(dott_appoggio.getDenominazioneDottorato());
								dottorato.setDescrFacoltaDottorato(dott_appoggio.getDescrFacoltaDottorato());
								dottorato.setDescrUniversitaDottorato(dott_appoggio.getDescrUniversitaDottorato());
								dottorato.setFlagEsteroDottorato(dott_appoggio.getFlagEsteroDottorato());
								dottorato.setIdDomandaDottorato(idDomanda);
								dottorato.setIdDottorato(dottoratoHome.getSequenceIdDottorato());
								dottorato.setLuogoDottorato(dott_appoggio.getLuogoDottorato());
								dottorato.setNazioneDottorato(dott_appoggio.getNazioneDottorato());								

								dottorati.add(dottorato);
							}
						
						} 
						
						BeanUtils.copyProperties(idoneita,titoliStudioCarrieraBean);
						
						if(idoneita!=null)
							idoneita.setIdDomandaIdon(idDomanda);
			}
			
			catch(IllegalAccessException  e)
				{
					e.printStackTrace();
					return false;
				}
			
			catch(InvocationTargetException e)
				{
					e.printStackTrace();
					return false;
				}	
		
			catch(RuntimeException re)
				{
					re.printStackTrace();
					return false;
				}
			
			return true;

}	


		public AltraLaureaReg getAltraLaurea() {
			return altraLaurea;
		}
		
		public void setAltraLaurea(AltraLaureaReg altraLaurea) {
			this.altraLaurea = altraLaurea;
		}
		
		public AltraLaureaRegHome getAltraLaureaHome() {
			return altraLaureaHome;
		}
		
		public void setAltraLaureaHome(AltraLaureaRegHome altraLaureaHome) {
			this.altraLaureaHome = altraLaureaHome;
		}
		
		public AltraLaureaBisReg getAltraLaureaBis() {
			return altraLaureaBis;
		}
		
		public void setAltraLaureaBis(AltraLaureaBisReg altraLaureaBis) {
			this.altraLaureaBis = altraLaureaBis;
		}
		
		public AltraLaureaBisRegHome getAltraLaureaBisHome() {
			return altraLaureaBisHome;
		}
		
		public void setAltraLaureaBisHome(AltraLaureaBisRegHome altraLaureaBisHome) {
			this.altraLaureaBisHome = altraLaureaBisHome;
		}
		
		public SpecializzazioneReg getSpecializzazione() {
			return specializzazione;
		}
		
		public void setSpecializzazione(SpecializzazioneReg specializzazione) {
			this.specializzazione = specializzazione;
		}
		
		public SpecializzazioneRegHome getSpecializzazioneHome() {
			return specializzazioneHome;
		}
		
		public void setSpecializzazioneHome(SpecializzazioneRegHome specializzazioneHome) {
			this.specializzazioneHome = specializzazioneHome;
		}
		
		public BorsaStudioReg getBorsaStudio() {
			return borsaStudio;
		}
		
		public void setBorsaStudio(BorsaStudioReg borsaStudio) {
			this.borsaStudio = borsaStudio;
		}
		
		public BorsaStudioRegHome getBorsaStudioHome() {
			return borsaStudioHome;
		}
		
		public void setBorsaStudioHome(BorsaStudioRegHome borsaStudioHome) {
			this.borsaStudioHome = borsaStudioHome;
		}
		
		public DottoratoReg getDottorato() {
			return dottorato;
		}
		
		public void setDottorato(DottoratoReg dottorato) {
			this.dottorato = dottorato;
		}
		
		public DottoratoRegHome getDottoratoHome() {
			return dottoratoHome;
		}
		
		public void setDottoratoHome(DottoratoRegHome dottoratoHome) {
			this.dottoratoHome = dottoratoHome;
		}
		
		public AltroTitoloReg getAltroTitolo() {
			return altroTitolo;
		}
		
		public void setAltroTitolo(AltroTitoloReg altroTitolo) {
			this.altroTitolo = altroTitolo;
		}
		
		public AltroTitoloRegHome getAltroTitoloHome() {
			return altroTitoloHome;
		}
		
		public void setAltroTitoloHome(AltroTitoloRegHome altroTitoloHome) {
			this.altroTitoloHome = altroTitoloHome;
		}
		
		public CorsoAggiornamentoReg getCorsoAggiornamento() {
			return corsoAggiornamento;
		}
		
		public void setCorsoAggiornamento(CorsoAggiornamentoReg corsoAggiornamento) {
			this.corsoAggiornamento = corsoAggiornamento;
		}
		
		public CorsoAggiornamentoRegHome getCorsoAggiornamentoHome() {
			return corsoAggiornamentoHome;
		}
		
		public void setCorsoAggiornamentoHome(
				CorsoAggiornamentoRegHome corsoAggiornamentoHome) {
			this.corsoAggiornamentoHome = corsoAggiornamentoHome;
		}
		
		public PubblicazioneReg getPubblicazione() {
			return pubblicazione;
		}
		
		public void setPubblicazione(PubblicazioneReg pubblicazione) {
			this.pubblicazione = pubblicazione;
		}
		
		public PubblicazioneRegHome getPubblicazioneHome() {
			return pubblicazioneHome;
		}
		
		public void setPubblicazioneHome(PubblicazioneRegHome pubblicazioneHome) {
			this.pubblicazioneHome = pubblicazioneHome;
		}
		
		public IdoneitaReg getIdoneita() {
			return idoneita;
		}
		
		public void setIdoneita(IdoneitaReg idoneita) {
			this.idoneita = idoneita;
		}
		
		public IdoneitaRegHome getIdoneitaHome() {
			return idoneitaHome;
		}
		
		public void setIdoneitaHome(IdoneitaRegHome idoneitaHome) {
			this.idoneitaHome = idoneitaHome;
		}
		
		public ArrayList<AltraLaureaReg> getAltreLauree() {
			return altreLauree;
		}
		
		public void setAltreLauree(ArrayList<AltraLaureaReg> altreLauree) {
			this.altreLauree = altreLauree;
		}
		
		public ArrayList<AltraLaureaBisReg> getAltreLaureeBis() {
			return altreLaureeBis;
		}
		
		public void setAltreLaureeBis(ArrayList<AltraLaureaBisReg> altreLaureeBis) {
			this.altreLaureeBis = altreLaureeBis;
		}
		
		public ArrayList<SpecializzazioneReg> getSpecializzazioni() {
			return specializzazioni;
		}
		
		public void setSpecializzazioni(ArrayList<SpecializzazioneReg> specializzazioni) {
			this.specializzazioni = specializzazioni;
		}
		
		public ArrayList<BorsaStudioReg> getBorseStudio() {
			return borseStudio;
		}
		
		public void setBorseStudio(ArrayList<BorsaStudioReg> borseStudio) {
			this.borseStudio = borseStudio;
		}
		
		public ArrayList<DottoratoReg> getDottorati() {
			return dottorati;
		}
		
		public void setDottorati(ArrayList<DottoratoReg> dottorati) {
			this.dottorati = dottorati;
		}
		
		public ArrayList<AltroTitoloReg> getAltriTitoli() {
			return altriTitoli;
		}
		
		public void setAltriTitoli(ArrayList<AltroTitoloReg> altriTitoli) {
			this.altriTitoli = altriTitoli;
		}
		
		public ArrayList<CorsoAggiornamentoReg> getCorsiAggiornamento() {
			return corsiAggiornamento;
		}
		
		public void setCorsiAggiornamento(
				ArrayList<CorsoAggiornamentoReg> corsiAggiornamento) {
			this.corsiAggiornamento = corsiAggiornamento;
		}
		
		public ArrayList<PubblicazioneReg> getPubblicazioni() {
			return pubblicazioni;
		}
		
		public void setPubblicazioni(ArrayList<PubblicazioneReg> pubblicazioni) {
			this.pubblicazioni = pubblicazioni;
		}
		
		public ArrayList<IdoneitaReg> getListaIdoneita() {
			return listaIdoneita;
		}
		
		public void setListaIdoneita(ArrayList<IdoneitaReg> listaIdoneita) {
			this.listaIdoneita = listaIdoneita;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.Pubblicazione> getListaPubb() {
			return listaPubb;
		}
		
		public void setListaPubb(
				ArrayList<com.accenture.CCFarm.Bean.Pubblicazione> listaPubb) {
			this.listaPubb = listaPubb;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.Specializzazione> getListaSpec() {
			return listaSpec;
		}
		
		public void setListaSpec(
				ArrayList<com.accenture.CCFarm.Bean.Specializzazione> listaSpec) {
			this.listaSpec = listaSpec;
		}
		
		public ArrayList<CorsoAgg> getListaCorsi() {
			return listaCorsi;
		}
		
		public void setListaCorsi(ArrayList<CorsoAgg> listaCorsi) {
			this.listaCorsi = listaCorsi;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis> getListaLaureeBis() {
			return listaLaureeBis;
		}
		
		public void setListaLaureeBis(
				ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis> listaLaureeBis) {
			this.listaLaureeBis = listaLaureeBis;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.Dottorato> getListaDott() {
			return listaDott;
		}
		
		public void setListaDott(
				ArrayList<com.accenture.CCFarm.Bean.Dottorato> listaDott) {
			this.listaDott = listaDott;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.AltroTitolo> getListaTitoli() {
			return listaTitoli;
		}
		
		public void setListaTitoli(
				ArrayList<com.accenture.CCFarm.Bean.AltroTitolo> listaTitoli) {
			this.listaTitoli = listaTitoli;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.BorsaStudio> getListaBorse() {
			return listaBorse;
		}
		
		public void setListaBorse(
				ArrayList<com.accenture.CCFarm.Bean.BorsaStudio> listaBorse) {
			this.listaBorse = listaBorse;
		}

		public UtenteCandidaturaReg getUtenteCandidatura() {
			return utenteCandidatura;
		}

		public void setUtenteCandidatura(UtenteCandidaturaReg utenteCandidatura) {
			this.utenteCandidatura = utenteCandidatura;
		}  

}
