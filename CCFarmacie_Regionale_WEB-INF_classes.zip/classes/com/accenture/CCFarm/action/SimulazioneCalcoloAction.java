package com.accenture.CCFarm.action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.primefaces.context.RequestContext;

import com.accenture.CCFarm.Bean.EsercizioProfessionale;
import com.accenture.CCFarm.pageBean.SimulazioneCalcoloBean;
import com.accenture.CCFarm.utility.CaricaRuoli;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.punteggi.esperienze.RisultatiValutazioneEsperienze;
import com.accenture.punteggi.esperienze.bean.in.EsperienzaOriginal;

//import com.accenture.pm.autenticazione.Utente;

abstract public class SimulazioneCalcoloAction implements Serializable{
	protected HttpServletRequest request = null;
	protected HttpServletResponse response = null;

	public SimulazioneCalcoloAction(HttpServletRequest request,HttpServletResponse response) {
		this.request = request;
		this.response = response;
	}

	public Object validateRequest() throws Exception{
		return null;
	}
	
	public Object executeRequest() throws Exception{
		return "Generic Action";
	}

	public String formatter(Object bean) throws Exception{
		return "Generic JSON";
	}
	
	public static List<EsercizioProfessionale> inserisci(SimulazioneCalcoloBean simulazioneCalcoloBean) {
		EsercizioProfessionale esProf = new EsercizioProfessionale();
		esProf.setDataInizioStringa(StringUtil.dateToStringDDMMYYYY(simulazioneCalcoloBean.getDataInizio()));
		esProf.setDataInizioEs(simulazioneCalcoloBean.getDataInizio());
		esProf.setDataFineStringa(StringUtil.dateToStringDDMMYYYY(simulazioneCalcoloBean.getDataFine()));
		esProf.setDataFineEs(simulazioneCalcoloBean.getDataFine());
		esProf.setCodModalitaEs(simulazioneCalcoloBean.getCodModalitaEs()); 
		if(simulazioneCalcoloBean.getCodModalitaEs().equals("0")){
			esProf.setModalitaTempoDescr("Tempo parziale");  
		}
		if(simulazioneCalcoloBean.getCodModalitaEs().equals("1")){
    	   esProf.setModalitaTempoDescr("Tempo pieno");
		}
		esProf.setCodModalitaEs(simulazioneCalcoloBean.getCodModalitaEs());
		esProf.setCodRuoloEs(simulazioneCalcoloBean.getCodRuoloEs());
		esProf.setDescrizioneRuolo(CaricaRuoli.decodificaruolo(simulazioneCalcoloBean.getCodRuoloEs())); 
		
		esProf.setFlagFarmRurale(simulazioneCalcoloBean.getFlagFarmRurale());
		
		
    	List<EsercizioProfessionale> esProfList = simulazioneCalcoloBean.getEserciziTable() ;
    	if(esProfList == null)
    		esProfList = new ArrayList<EsercizioProfessionale>();
    	esProfList.add(esProf);
    	RequestContext.getCurrentInstance().update(JSFUtility.getClientId("inserimentoEsperienza"));
	return esProfList ;
}

	
	public static String calcola(SimulazioneCalcoloBean simulazioneCalcoloBean) throws Exception {
		RisultatiValutazioneEsperienze risultato = new RisultatiValutazioneEsperienze();
		String risultatoString = "";
		ArrayList<EsperienzaOriginal> listEsp = new ArrayList<EsperienzaOriginal>();
		for (int i = 0; i < simulazioneCalcoloBean.getEserciziTable().size(); i++) {
			EsercizioProfessionale esProf = simulazioneCalcoloBean.getEserciziTable().get(i);
			EsperienzaOriginal espOr = new EsperienzaOriginal();
			
			String codiceCategoria =  esProf.getDescrizioneRuolo().substring(5, 6);
			espOr.setCodiceCategoria(codiceCategoria);
			
			if(esProf.getCodModalitaEs().equals("0"))
				espOr.setCodiceModalita("P");
			else
				espOr.setCodiceModalita("F");
			if(esProf.getFlagFarmRurale().equals("Si"))
				espOr.setRurale(true);
			else
				espOr.setRurale(false);
			espOr.setDataInizio(esProf.getDataInizioEs());
			espOr.setDataFine(esProf.getDataFineEs());
			
			String ruoloStringa =  esProf.getDescrizioneRuolo().substring(7,esProf.getDescrizioneRuolo().length() );
			espOr.setRuolo(ruoloStringa);
			
			listEsp.add(espOr);
		}
		
		if(!listEsp.isEmpty()){
			risultato = com.accenture.punteggi.esperienze.CalcoloPunteggi.calcola(listEsp);
			
		}
		if(risultato != null){
			risultatoString = risultato.toString();
		}
	return risultatoString ;
}
	

	
	
}
