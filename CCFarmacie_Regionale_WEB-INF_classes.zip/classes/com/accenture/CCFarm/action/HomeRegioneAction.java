package com.accenture.CCFarm.action;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoriaHome;
import com.accenture.CCFarm.DAO.TipoGraduatoriaId;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.HomeRegioneBean;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


public class HomeRegioneAction {
	
	Logger logger = CommonLogger.getLogger("HomeRegioneAction");
	
	AppProperties paramProperties = AppProperties.getAppProperties();
	
	private InterpelloHome interpelloHome;
	
	String pageError = "errorPage.jsf";
    
	String codRegione;
	String utente;
	String nome;
	String cognome;
	
	public HomeRegioneAction() {
		
		interpelloHome = new InterpelloHome();
	}
	
    public void loadPaginaInserimento(HomeRegioneBean regBean) throws GestioneErroriException {
    	
    	//RECUPERO DALLA SESSIONE
    	FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	
    	try {
	    	//ACCESSO DA CARTINA ***********************************************************************************
	    	DatiBando datiBando = (DatiBando)session.getAttribute(RepositorySession.DATI_BANDO);
	    	if(datiBando!=null) {
	    		
	    		regBean.setRegione(GenericConstants.getDescrRegioneByCod(datiBando.getCodReg()));
	    	}
	    	else { //ACCESSO DA REGIONI *****************************************************************************
	    	
		    	UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
		    	
		    	if(utenteReg!=null)
		    	{
		    		logger.info("Utente NSIS recuperato dalla sessione");
		    		codRegione = utenteReg.getCodRegione();
		    		utente = utenteReg.getUserId();
		    		nome = utenteReg.getNome();
		    		cognome = utenteReg.getCognome();
		    		
		    		logger.info("CodRegione:"+codRegione);
					
			    	regBean.setCodRegione(codRegione);
			    	regBean.setRegione(GenericConstants.getDescrRegioneByCod(codRegione));
			    	regBean.setUsername(nome+" "+cognome);
			    	
			    	//Area Documentale
			    	if(utenteReg.isAbilitataAreaDocumentale())
			    		regBean.setDisabledAreaDocumentale("false");
			    	else
			    		regBean.setDisabledAreaDocumentale("true");
		    	}
		    	else {
		    		logger.error("Utente NSIS non presente in sessione");
		    		GestioneErroriException eccezione = new GestioneErroriException("HomeRegioneAction - loadPaginaInserimento: Utente NSIS non presente in sessione");
					throw eccezione;
		    	}
	    	}	
	    } catch (Exception e) {
			logger.error("HomeRegioneAction - loadPaginaInserimento: " + e.getMessage());
			GestioneErroriException eccezione = new GestioneErroriException("HomeRegioneAction - loadPaginaInserimento: "+e);
			throw eccezione;
		} 
    
    }
    
    /*public void getAreaDocumentale(HomeRegioneBean regBean) throws GestioneErroriException {
    	
    	Logger logger = CommonLogger.getLogger("getAreaDocumentale");
    	FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	
    	try {
		    	UtenteRegioni user = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
		    	
		    	//Verifica che l'utente abbia abilitata la funzione di ACCESSO AREA DOCUMENTALE
	    		logger.info("Utente NSIS recuperato dalla sessione");
	    		String id_User = (String)session.getAttribute(RepositorySession.UTENTE_ID_NSIS);
	    		String tokenSAML = (String)session.getAttribute(RepositorySession.TOKEN_SAML_NSIS);
	    		String nomeApplicazione = (String)session.getAttribute(RepositorySession.NOME_APPLICAZIONE_NSIS);
	    		String bolink = (String)session.getAttribute(RepositorySession.BOXI_LINK_NSIS); 
	    	
	    		if(id_User==null || tokenSAML==null || user==null || nomeApplicazione==null || bolink ==null) {
	    			logger.error("Area Documentale: parametri non presenti in sessione");
	    			regBean.setDisabledAreaDocumentale("true");
	    			GestioneErroriException eccezione = new GestioneErroriException("HomeRegioneAction - Area Documentale: parametri non presenti in sessione");
	    			throw eccezione;
	    		}
	    		else {
	    			logger.info("Parametri NSIS recuperati dalla sessione - id_User: "+id_User+"; tokenSAML: "+tokenSAML+"; nomeApplicazione: "+nomeApplicazione +"; bolink: "+bolink);
	    			JSFUtility.redirect("areaDocumentale.jsp");
	    			
	    		}
		    	
    	} catch (Exception e) {
			logger.error("HomeRegioneAction - getAreaDocumentale: " + e.getMessage());
			GestioneErroriException eccezione = new GestioneErroriException("HomeRegioneAction - getAreaDocumentale: "+e);
			throw eccezione;
		} 
    }*/
    
    
    @SuppressWarnings("unchecked")
	public List<TipoGraduatoria> getGraduatoria(String idRegione) throws GestioneErroriException {
		
    	TipoGraduatoria   tipoGraduatoria        = new TipoGraduatoria();
		TipoGraduatoriaId tipoGraduatoriaId      = new TipoGraduatoriaId();
		TipoGraduatoriaHome tipoGraduatoriaHome  = new TipoGraduatoriaHome();
		
		tipoGraduatoria.setCodRegione(idRegione);
		tipoGraduatoriaId.setCodRegione(idRegione);
		tipoGraduatoria.setIdKey(tipoGraduatoriaId);
		List<TipoGraduatoria> listTipoGrad = new ArrayList<TipoGraduatoria>();
		listTipoGrad = (List<TipoGraduatoria>) tipoGraduatoriaHome.findByExample(tipoGraduatoria);
		
    	
    	return listTipoGrad;
    	
    }
    
    //restituisce true se nella lista di graduatorie ce n'� almeno una che risulta pubblicata in una data non successiva a quella corrente
    public boolean controllaPubblicazioneGraduatoria(List<TipoGraduatoria> tipiGraduatoria) throws GestioneErroriException {
    	
    	if(tipiGraduatoria == null || tipiGraduatoria.isEmpty())
    		return false;
    	
    	Date dataOdierna = DateUtil.dataOdierna();
    	
    	for(TipoGraduatoria tipoGraduatoria : tipiGraduatoria) {
    		
    		if(tipoGraduatoria != null) {
    			
    			//controlla stato e data pubblicazione per la graduatoria corrente
    			if(tipoGraduatoria.getStatoGraduatoria() != null &&
    			   tipoGraduatoria.getStatoGraduatoria().equalsIgnoreCase("P") &&
    			   tipoGraduatoria.getDataPublicazione() != null &&
    			   DateUtil.calcolaDifferenzaDate(tipoGraduatoria.getDataPublicazione(), dataOdierna) >= 0) {
    				return true;
    			}
    		}
    	}
    	
    	return false;
    }
    
    //restituisce true se per la regione specificata risulta un interpello in corso
    public boolean controllaPresenzaInterpelloInCorso(String codiceRegione) throws GestioneErroriException {
    	
    	return interpelloHome.controllaPresenzaInterpelloInCorso(codiceRegione);
    }
    
    //restituisce true se per la regione specificata risulta un interpello pubblicato scaduto
    public boolean controllaPresenzaInterpelloScaduto(String codiceRegione) throws GestioneErroriException {
    	
    	Interpello interpello = interpelloHome.determinaInterpelloCorrente(codiceRegione);
		//DATA SISTEMA > A DATA FINE INTERPELLO
		if(interpello!=null && interpello.getStato().equals(paramProperties.getProperty("codice.interpello.pubblicato")) && 
				DateUtil.getCurrentTimestamp().after((Timestamp) interpello.getDataFine()))
			 
				return true;
		else return false;
    }
    
    public boolean existInterpello(String codiceRegione) throws GestioneErroriException {
    	
    	Interpello interpello = interpelloHome.determinaInterpelloCorrente(codiceRegione);
		return (interpello!=null)? true : false; 
    }
    
    
    
}