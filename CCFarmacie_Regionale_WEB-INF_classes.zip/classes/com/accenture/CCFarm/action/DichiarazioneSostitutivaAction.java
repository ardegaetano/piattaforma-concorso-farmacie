package com.accenture.CCFarm.action;

import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.commons.beanutils.BeanUtils;
import org.hibernate.Hibernate;

import com.accenture.CCFarm.DAO.DichiarazioneSostitutivaReg;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutivaRegHome;
import com.accenture.CCFarm.DAO.DocumentoReg;
import com.accenture.CCFarm.DAO.DocumentoRegHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.DichiarazioneSostitutivaBean;
import com.accenture.CCFarm.utility.StringUtil;

public class DichiarazioneSostitutivaAction {
	
	java.util.Date date;
    private Timestamp oggi;
    
	DichiarazioneSostitutivaReg dichiarazioneSostitutiva;
	DichiarazioneSostitutivaRegHome dichiarazioneSostitutivaHome;
	DocumentoRegHome documentoHome;
	ArrayList<DocumentoReg> listaDocumenti;
	ArrayList<DichiarazioneSostitutivaReg> dichiarazioni = new ArrayList<DichiarazioneSostitutivaReg>();

	public DichiarazioneSostitutivaAction() {
		dichiarazioneSostitutivaHome=new DichiarazioneSostitutivaRegHome();
		documentoHome=new DocumentoRegHome();
	}
	
	public boolean loadPaginaInserimento(String idDomandaDic,DichiarazioneSostitutivaBean dichiarazioneSostitutivaBean) throws GestioneErroriException{
    	try
    	{
    		//popola lista delle province
    		dichiarazioneSostitutiva=new DichiarazioneSostitutivaReg();
    		dichiarazioneSostitutiva =  dichiarazioneSostitutivaHome.findById(idDomandaDic);
    		
	    	}
    	catch(RuntimeException re)
    	{
    		re.printStackTrace();
    		return false;
    	}
	    
    	//copia i dati dai bean di hibernate nel bean di pagina
   		try
   		{
 
   			if(dichiarazioneSostitutiva!=null)
   				BeanUtils.copyProperties(dichiarazioneSostitutivaBean,dichiarazioneSostitutiva);
   			if (dichiarazioneSostitutiva.getNoteComm()!=null)
   			dichiarazioneSostitutivaBean.setNoteCommissione(StringUtil.convertClob(dichiarazioneSostitutiva.getNoteComm()));
   			else dichiarazioneSostitutivaBean.setNoteCommissione("");
   			
   			
		}
   		catch(IllegalAccessException e)
   		{
			e.printStackTrace();
			return false;
		}
   		catch(InvocationTargetException e)
   		{
			e.printStackTrace();
			return false;
		}
   		
   		return true;
    }
	
	public boolean updateDAO(String idDomanda,DichiarazioneSostitutivaBean dichiarazioneSostitutivaBean) throws GestioneErroriException {
			
		
		dichiarazioneSostitutiva=new DichiarazioneSostitutivaReg();
		
		
		//preleva i dati dal bean di pagina e li copia nei bean di hibernate
		try
		{
			BeanUtils.copyProperties(dichiarazioneSostitutiva,dichiarazioneSostitutivaBean);
			
			dichiarazioneSostitutiva.setNoteComm(Hibernate.createClob(dichiarazioneSostitutivaBean.getNoteCommissione()));
			
			dichiarazioneSostitutiva.setIdDomandaDic(idDomanda);
			
			if(dichiarazioneSostitutiva.getElencoDocumenti()!=null && !dichiarazioneSostitutiva.getElencoDocumenti().equals("")){
				StringTokenizer stringToken = new StringTokenizer(dichiarazioneSostitutiva.getElencoDocumenti(),"|");
				Vector vettoreDiDoc = new Vector();
				while (stringToken.hasMoreTokens()){
					vettoreDiDoc.add(stringToken.nextElement());
				}
				//String[] listaDoc = dichiarazioneSostitutiva.getElencoDocumenti().split("|");
				String appoggio = "";
				listaDocumenti = new ArrayList<DocumentoReg>();
				DocumentoReg doc_appoggio;
	    		
				for (int i=0;i<vettoreDiDoc.size(); i++)
				{
	    			appoggio =(String) vettoreDiDoc.get(i);
	    			doc_appoggio = new DocumentoReg();
					doc_appoggio.setTipoDocumento(appoggio);
					doc_appoggio.setIdDomandaDocumento(idDomanda);
					doc_appoggio.setIdDocumento(documentoHome.getSequenceIdDocumento());
					
					listaDocumenti.add(doc_appoggio);
				}
			}
			else {
				listaDocumenti = null;
			}
			dichiarazioneSostitutivaBean.setListaDocumenti(listaDocumenti);
			
		}
		catch(IllegalAccessException e)
		{
			e.printStackTrace();
			return false;
		}
		catch(InvocationTargetException e)
		{
			e.printStackTrace();
			return false;
		}
				
		return true;
		}
					

	public String[] validatorFields() {
		
		return null;
	}

	public boolean sendMailDom() {
		
		return true;
	}

	public boolean printDom() {
		
		return true;
	}

	public DichiarazioneSostitutivaReg getDichiarazioneSostitutiva() {
		return dichiarazioneSostitutiva;
	}

	public void setDichiarazioneSostitutiva(
			DichiarazioneSostitutivaReg dichiarazioneSostitutiva) {
		this.dichiarazioneSostitutiva = dichiarazioneSostitutiva;
	}

	public ArrayList<DocumentoReg> getListaDocumenti() {
		return listaDocumenti;
	}

	public void setListaDocumenti(ArrayList<DocumentoReg> listaDocumenti) {
		this.listaDocumenti = listaDocumenti;
	}
	
}
