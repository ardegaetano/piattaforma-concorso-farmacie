package com.accenture.CCFarm.action;


import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.Bean.StoricoGraduatoriaLazyList;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.StoricoGraduatoria;
import com.accenture.CCFarm.DAO.StoricoGraduatoriaHome;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoriaHome;
import com.accenture.CCFarm.DAO.TipoGraduatoriaId;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.Bando;
import com.accenture.CCFarm.pageBean.RicercaStoricoGraduatoria;
import com.accenture.CCFarm.pageBean.PubblicaGraduatoriaBean;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;

import org.apache.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.UploadedFile;


	public class PubblicaGraduatoriaAction{
		
	    Logger logger = CommonLogger.getLogger("RicercaCandidatoAction");
	    String pageError = "errorPage.jsf";
	  //Gestione UpLoad
	  	private UploadedFile fileAtto;
//	  	private UploadedFile fileSedi;
	  
		public PubblicaGraduatoriaAction(){
			
		}
	


	public int findCount(String cod_reg, String tipoGrad, String primo, String ultimo, String dataValid) throws GestioneErroriException {
		
		int totaleSchede;
		StoricoGraduatoriaHome storicoGraduatoriaHome = new StoricoGraduatoriaHome();	
		
		if (primo!=null && !primo.equalsIgnoreCase("") && ultimo!=null && !ultimo.equalsIgnoreCase("")  ){	
			totaleSchede = storicoGraduatoriaHome.findCount(cod_reg,tipoGrad,Integer.parseInt(primo),Integer.parseInt(ultimo),dataValid);			
		}
		else {
			totaleSchede = storicoGraduatoriaHome.findCount(cod_reg,tipoGrad,0,0,dataValid);
		}
		
		return totaleSchede ;
	}


	public List findTipologieGraduatorie(String cod_reg) throws GestioneErroriException {
//		
		List<TipoGraduatoria> tipoGraduatoriaList = new ArrayList<TipoGraduatoria>();
		TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
		TipoGraduatoria tipoGraduatoria = new TipoGraduatoria();
		tipoGraduatoria.setCodRegione(cod_reg);
		TipoGraduatoriaId tipoGraduatoriaId = new TipoGraduatoriaId();
		tipoGraduatoriaId.setCodRegione(cod_reg);
		tipoGraduatoria.setIdKey(tipoGraduatoriaId);
		
		tipoGraduatoriaList = tipoGraduatoriaHome.findByExample(tipoGraduatoria);
		
		List<TipoGraduatoria> tipoGradList = new ArrayList<TipoGraduatoria>();
		
		for (TipoGraduatoria tipGrad : tipoGraduatoriaList) {
			int progressivo = tipGrad.getProgressivo().intValue();
			String descrizione= new String();
			
//			if (progressivo == 1) descrizione="Graduatoria definitiva";
//			else if (progressivo == 2) descrizione="Graduatoria rettificata";
//			else if (progressivo > 2) descrizione="Graduatoria rettificata n�"+(progressivo -2);
			if (progressivo == 1) descrizione="Graduatoria definitiva";
			else 
			 if (progressivo > 1) descrizione="Graduatoria n�"+(progressivo -1);
			
//			int indice = tipoGraduatoriaList.indexOf(tipGrad);
			tipGrad.setDescrizione(descrizione);
		
			tipoGradList.add(tipGrad);
			
		}
		
		return tipoGradList;
	}
	
	
	//meteodo che prende l'ultima graduatiria validata, serve per popolare la lista della graduatria in pagina pubblicazione graduatoria 
	public List findUltimaGradutaoriaValidata (String codReg) throws GestioneErroriException{
		
		List<TipoGraduatoria> tipoGraduatoriaList = new ArrayList<TipoGraduatoria>();
		
		TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
		
		TipoGraduatoria tipoGraduatoria = tipoGraduatoriaHome.findLastPubblicata(codReg);
		
		tipoGraduatoriaList.add(tipoGraduatoria);
		
		return tipoGraduatoriaList;
		
	}
	
	public List findUltimaVersioneGraduatorie(String cod_reg) throws GestioneErroriException {
//		
		List<TipoGraduatoria> tipoGraduatoriaList = new ArrayList<TipoGraduatoria>();
		TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
		TipoGraduatoria tipoGraduatoria = new TipoGraduatoria();
		tipoGraduatoria.setCodRegione(cod_reg);
	
		
		TipoGraduatoriaId tipoGraduatoriaId = new TipoGraduatoriaId();
		tipoGraduatoriaId.setCodRegione(cod_reg);
		tipoGraduatoria.setIdKey(tipoGraduatoriaId);
		
		
		
		tipoGraduatoriaList = tipoGraduatoriaHome.findByExample(tipoGraduatoria);
		
		List<TipoGraduatoria> tipoGradList = new ArrayList<TipoGraduatoria>();
		
		if(tipoGraduatoriaList!=null && !tipoGraduatoriaList.isEmpty()){
			TipoGraduatoria tipGrad = tipoGraduatoriaList.get(0);
			int progressivo = tipGrad.getProgressivo().intValue();
			String descrizione= "graduatoria - "+tipGrad.getDataValutazione();
			
			tipGrad.setDescrizione(descrizione);
		
			tipoGradList.add(tipGrad);
			
		}
		
		return tipoGradList;
	}


	public String findDataValid(String cod_reg, String codiceGraduatoria) throws GestioneErroriException {
		 String dataVal="";
		 List<StoricoGraduatoria> lista ;
		StoricoGraduatoriaHome storicoGraduatoriaHome = new StoricoGraduatoriaHome();
		StoricoGraduatoria storicoGraduatoria = new StoricoGraduatoria();
		storicoGraduatoria.setCodRegione(cod_reg);
		storicoGraduatoria.setnProgressivo(codiceGraduatoria);		
	    lista = storicoGraduatoriaHome.findByExample(storicoGraduatoria);
	    if (!lista.isEmpty())
	    dataVal = StringUtil.dateToStringDDMMYYYY(lista.get(0).getDataValidazione());
		
		return dataVal ;
	}

	public String findDataValidazione(String cod_reg, TipoGraduatoria tipoGraduatoria) throws GestioneErroriException {
		String dataVal="";
//		List<StoricoGraduatoria> lista ;
//		StoricoGraduatoriaHome storicoGraduatoriaHome = new StoricoGraduatoriaHome();
//		StoricoGraduatoria storicoGraduatoria = new StoricoGraduatoria();
//		storicoGraduatoria.setCodRegione(cod_reg);
//		storicoGraduatoria.setTipoGraduatoria(codiceGraduatoria);		
//	    lista = storicoGraduatoriaHome.findByExample(storicoGraduatoria);
//	    if (!lista.isEmpty())
//	    dataVal = StringUtil.dateToStringDDMMYYYY(lista.get(0).getDataValidazione());
//		
		return dataVal ;
	}

	
	public List<StoricoGraduatoria> getPageStoricoGraduatoria(PubblicaGraduatoriaBean pubblicaGraduatoriaBean , int startPage, int maxPerPage, String cod_reg) throws GestioneErroriException{
		
		List<StoricoGraduatoria> listaStoricoGraduatoria ;
		StoricoGraduatoriaHome storicoGraduatoriaHome = new StoricoGraduatoriaHome();
		listaStoricoGraduatoria = new ArrayList<StoricoGraduatoria>();
				
		if (pubblicaGraduatoriaBean.getNumeroPosInizialeString()!=null && !pubblicaGraduatoriaBean.getNumeroPosInizialeString().equalsIgnoreCase("") && 
				pubblicaGraduatoriaBean.getNumeroPosFinaleString()!=null && !pubblicaGraduatoriaBean.getNumeroPosFinaleString().equalsIgnoreCase("") &&	pubblicaGraduatoriaBean.getCodiceGraduatoria()!=-1 
				){			
			listaStoricoGraduatoria = storicoGraduatoriaHome.findLazyListStoricoGraduatoria(startPage, maxPerPage, cod_reg, Integer.parseInt(pubblicaGraduatoriaBean.getNumeroPosInizialeString()), Integer.parseInt(pubblicaGraduatoriaBean.getNumeroPosFinaleString()), "" + pubblicaGraduatoriaBean.getCodiceGraduatoria() ,pubblicaGraduatoriaBean.getDataValidazioneString());
		}
		else {
			listaStoricoGraduatoria = storicoGraduatoriaHome.findLazyListStoricoGraduatoria(startPage, maxPerPage, cod_reg, 1, pubblicaGraduatoriaBean.getTotaleSchede(),"" + pubblicaGraduatoriaBean.getCodiceGraduatoria() ,pubblicaGraduatoriaBean.getDataValidazioneString());
		}
		
		return listaStoricoGraduatoria;
	}

	
    public String upLoadAttoAmministrativo(FileUploadEvent event, PubblicaGraduatoriaBean pubblicaGraduatoriaBean) throws GestioneErroriException { 
    	String msg = null;
    	try { 
    		
    		//RECUPERO E INSERISCO IN SESSIONE IL FILE DI UPLOAD
        	FacesContext context = FacesContext.getCurrentInstance();
        	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
        	HttpSession session = req.getSession();
        	
        	fileAtto = event.getFile();
	        if (!fileAtto.getFileName().toLowerCase().endsWith(".pdf")) 
	            msg = "Upload file PDF: formato non corretto.";
	        else { 
	        	pubblicaGraduatoriaBean.setbCaricaAtto("true");
	        	pubblicaGraduatoriaBean.setVisibilitaCaricaAtto("block");
	        	pubblicaGraduatoriaBean.setInvisibilitaCaricaAtto("none");
        		InputStream streamB = fileAtto.getInputstream();
       
        		session.setAttribute(RepositorySession.FILE_ATTO_ABBINISTRATIVO, fileAtto.getContents()); //In sessione il file BANDO
        		
        		pubblicaGraduatoriaBean.setFileDownload(new DefaultStreamedContent(streamB, fileAtto.getContentType(), fileAtto.getFileName()));
        	    
        		pubblicaGraduatoriaBean.getTipoGradSelected().setAttoAmministrativoPDF(fileAtto.getContents()); 
        	    TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
        	    tipoGraduatoriaHome.saveOrUpdate(pubblicaGraduatoriaBean.getTipoGradSelected());
        	    
	        } 
	        
        }catch (Exception e) {
			logger.error("Errore metodo upLoadAttoAmministrativo - FileDownload" + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoAction - upload: "+e);
			throw eccezione;
    	}
    	return msg;
    }



	public UploadedFile getFileAtto() {
		return fileAtto;
	}



	public void setFileAtto(UploadedFile fileAtto) {
		this.fileAtto = fileAtto;
	}


	public void updateDatiBando(String codReg) throws GestioneErroriException{
		DatiBando datiBando = new DatiBando();
		DatiBandoHome datiBandoHome = new DatiBandoHome();
		datiBando = datiBandoHome.findById(codReg);
		datiBando.setFlagSendMailPubb("true");
		datiBando.setFlagGeneraZIP("true");
		datiBandoHome.saveOrUpdate(datiBando);
	}

	
    
	
}