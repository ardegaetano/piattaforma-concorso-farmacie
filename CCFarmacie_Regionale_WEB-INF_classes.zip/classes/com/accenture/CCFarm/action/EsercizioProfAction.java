package com.accenture.CCFarm.action;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;

import com.accenture.CCFarm.Bean.EsercizioProfessionale;
import com.accenture.CCFarm.Bean.ParafarmacieSearch;
import com.accenture.CCFarm.DAO.EsercizioProfReg;
import com.accenture.CCFarm.DAO.EsercizioProfRegHome;
import com.accenture.CCFarm.DAO.FarmacieHome;
import com.accenture.CCFarm.DAO.FarmacieSearch;
import com.accenture.CCFarm.DAO.ParafarmacieHome;
import com.accenture.CCFarm.DAO.UtenteReg;
import com.accenture.CCFarm.DAO.UtenteRegHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.EsercizioProfBean;
import com.accenture.CCFarm.utility.CaricaRuoli;
import com.accenture.CCFarm.utility.StringUtil;


//@SuppressWarnings("serial")
public class EsercizioProfAction
{
	java.util.Date date;
    
    java.util.Date dataSys= new java.util.Date();
    private java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
    Logger logger =Logger.getLogger("Bando");
	UtenteReg utente;
	UtenteRegHome utenteHome;
    
	EsercizioProfReg esercizioProf;
	EsercizioProfRegHome esercizioProfHome;
	EsercizioProfessionale esercizioProfessionale;
	ArrayList<EsercizioProfReg> eserciziProf;
	ArrayList<EsercizioProfessionale> listaEserciziProfessionali;
	private SimpleDateFormat sdf = new SimpleDateFormat();
	
	public EsercizioProfAction()
	{
		utenteHome=new UtenteRegHome();
		esercizioProfHome=new EsercizioProfRegHome();
		esercizioProf = new EsercizioProfReg();
	}
	
    public boolean loadPaginaInserimento(String idDomanda,EsercizioProfBean esercizioProfBean) throws GestioneErroriException 
    {
    	try
    	{
    		
    		//Localita localita = new Localita();
    		eserciziProf = new ArrayList<EsercizioProfReg>();
    		esercizioProf = new EsercizioProfReg();
    		esercizioProf.setIdDomandaEs(idDomanda);
    		eserciziProf = (ArrayList<EsercizioProfReg>) esercizioProfHome.findByExample(esercizioProf);
    		
    		listaEserciziProfessionali = new ArrayList<EsercizioProfessionale>();
    		
    		if(eserciziProf!=null){
    			for (int i=0;i<eserciziProf.size();i++){
    				EsercizioProfessionale esercizio_appoggio = new EsercizioProfessionale();
    				try {
						PropertyUtils.copyProperties(esercizio_appoggio,eserciziProf.get(i));
					} catch (NoSuchMethodException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    				
    				sdf = new SimpleDateFormat("dd-MM-yyyy");
    		        esercizio_appoggio.setDataInizioStringa(StringUtil.dateToString(esercizio_appoggio.getDataInizioEs(),sdf));
    		        
    		        sdf = new SimpleDateFormat("dd-MM-yyyy");
    		        esercizio_appoggio.setDataFineStringa(StringUtil.dateToString(esercizio_appoggio.getDataFineEs(),sdf));
    				
//    				esercizio_appoggio.setComuneDescrizione(localita.getDenominazioneComune(esercizio_appoggio.getComuneEs()));
//    				esercizio_appoggio.setRegDescrizione(localita.getDenominazioneRegione(esercizio_appoggio.getRegEs()));
//    				esercizio_appoggio.setPrvDescrizione(localita.getDenominazioneProvincia(esercizio_appoggio.getPrvEs()));
    		       
    				
    				if(esercizio_appoggio.getCodModalitaEs().equals("0")){
    					 esercizio_appoggio.setModalitaTempoDescr("Tempo parziale");  
    		        }
    		        if(esercizio_appoggio.getCodModalitaEs().equals("1")){
    		        	esercizio_appoggio.setModalitaTempoDescr("Tempo pieno");
    		       }
    		       
    		      
    		        esercizio_appoggio.setDescrizioneRuolo(CaricaRuoli.decodificaruolo(esercizio_appoggio.getCodRuoloEs())); 
    		        
    		        if(esercizio_appoggio.getCodCategoriaEs().equals("0")){
    		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Farmacia");
    		          }
    		        if(esercizio_appoggio.getCodCategoriaEs().equals("1")){
    		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Altro");
    		         }
    		        if(esercizio_appoggio.getCodCategoriaEs().equals("3")){
    		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Esercizio commerciale L.248/2006");
    		         }
    				
    		        esercizio_appoggio.setIdDomandaEs(esercizio_appoggio.getIdDomandaEs());
    				
    				listaEserciziProfessionali.add(esercizio_appoggio);
    				
    			}
    		
    		}  
    		esercizioProfBean.setListaEserciziProfessionali(listaEserciziProfessionali);
    		
    		if(!listaEserciziProfessionali.isEmpty())
    		{
//	    		System.out.println("*********************************************************");
//	    		System.out.println("valore asl: "+listaEserciziProfessionali.get(0).getAslDenom());
//	    		System.out.println("valore asl: "+listaEserciziProfessionali.get(0).getAslEs());
    		}
    		
    	}	
	    	
    	catch(RuntimeException re)
    	{
    		re.printStackTrace();
    		return false;
    	}
	    
   		catch(IllegalAccessException e)
   		{
			e.printStackTrace();
			return false;
		}
   		catch(InvocationTargetException e)
   		{
			e.printStackTrace();
			return false;
		}
   		
   		return true;
    }
    
    public boolean updateDAO(String idDomanda,EsercizioProfBean esercizioProfBean) throws GestioneErroriException 
	{
	
			//preleva i dati dal bean di pagina e li copia nei bean di hibernate
			try
					{
						EsercizioProfessionale eseProf_appoggio = new EsercizioProfessionale();
				        ArrayList<EsercizioProfessionale> listaEserciziProfessionali;
				        listaEserciziProfessionali = (ArrayList<EsercizioProfessionale>)esercizioProfBean.getListaEserciziProfessionali();
				        
				        eserciziProf = new ArrayList<EsercizioProfReg>();
				        esercizioProf = new EsercizioProfReg();
						
						if(listaEserciziProfessionali!=null){
							for (int i=0;i<listaEserciziProfessionali.size();i++){
								
							
								eseProf_appoggio = listaEserciziProfessionali.get(i);
								
								esercizioProf = new EsercizioProfReg();
								
								BeanUtils.copyProperties(esercizioProf,eseProf_appoggio);
								
								esercizioProf.setIdDomandaEs(idDomanda);
								
								esercizioProf.setIdEsercizio(esercizioProfHome.getSequenceIdEsercizioProfessionale());
	
								eserciziProf.add(esercizioProf);
								 
							}
						
						}
						
					}
			
			catch(IllegalAccessException  e)
				{
					e.printStackTrace();
					return false;
				}
			
			catch(InvocationTargetException e)
				{
					e.printStackTrace();
					return false;
				}	
		
			catch(RuntimeException re)
				{
					re.printStackTrace();
					return false;
				}
	
			
			return true;

}
    
	
//	private String controlliCampi(EsercizioProfBean esercizioProfBean) {
//		
//	    String msg = "";
//	
//	    if(utente==null)
//	    	utente=utenteHome.findById((String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_UTENTE));
//	    
//	    Date dataNascitaUtente = utente.getDataNascitaUtente();
//	    // da ricavare da DB (DATI_BANDO.DATA_PUBBLICAZIONE_BANDO, DATI_BANDO.DATA_INIZIO_PUBBLICAZIONI) specifico per regione (DATI_BANDO.COD_REG)
//	    Date dataPubblicazioneBando;
//	    Date datInizioPubblicazione;
//	    
//	    
//	    Date dataInizio = esercizioProfBean.getDataInizioEs();
//	    Date dataFine = esercizioProfBean.getDataFineEs();
//	    
//	    
//	    if (dataInizio!= null && dataInizio.before(dataNascitaUtente)){
//	    	msg = msg + "Data Inizio Esercizio Professionale errata - la data Inizio Esercizio Professionale deve essere successiva alla data di nascita";
//	    }
////	    if (dataInizio!= null && dataInizio.after(dataPubblicazioneBando)|| dataInizio.equals(dataPubblicazioneBando)){
////	    	msg = msg + "Data Inizio Esercizio Professionale errata - la data Pubblicazione deve essere antecedente o uguale alla data Pubblicazione Bando";
////        }
//	    if (dataInizio!= null && dataFine!=null && dataInizio.before(dataFine)){
//	    	msg = msg + "Date incongruenti - la data inizio Inizio Esercizio Professionale deve essere inferiore alla data Fine Esercizio Professionale";
//	    }
//	    
//	
//	return msg;
//}  
	
	
		
	  public List<FarmacieSearch> ricerca(EsercizioProfBean esercizioProfBean) throws GestioneErroriException{
	    	FarmacieHome farmacieHome=new FarmacieHome();
	    	FarmacieSearch farmacieSearch = new FarmacieSearch();
	    	farmacieSearch.setCodRg(esercizioProfBean.getRegioneSelezionata());
	    	farmacieSearch.setCodIstatProv(esercizioProfBean.getProvinciaSelezionata());
	    	farmacieSearch.setCodIstatComu(esercizioProfBean.getComuneSelezionato());
	    	farmacieSearch.setpIva(esercizioProfBean.getPartitaIVA());
	    	farmacieSearch.setCodCap(esercizioProfBean.getCodCap());
	    	farmacieSearch.setIndirizzo(esercizioProfBean.getIndirizzo());
	    	farmacieSearch.setIdMinisetro(esercizioProfBean.getIdEsercizio());
	    	List<FarmacieSearch> farmList = farmacieHome.findByFilter(farmacieSearch);
	    
  	return farmList ;
  }
  
	  public List<ParafarmacieSearch> ricercaParafarmacie (EsercizioProfBean esercizioProfBean) throws GestioneErroriException {
		   ParafarmacieHome parafarmacieHome = new ParafarmacieHome();
		   ParafarmacieSearch parafarmacieSearch = new ParafarmacieSearch();
		   List<ParafarmacieSearch> parafarmList = new ArrayList<ParafarmacieSearch>();
		   parafarmacieSearch.setCodCap(esercizioProfBean.getCodCapParafarmacie());
		   parafarmacieSearch.setCodCmn(esercizioProfBean.getComuneSelezionatoParafarmacia());
		   parafarmacieSearch.setCodProvincia(esercizioProfBean.getProvinciaSelezionataParafarmacia());
		   parafarmacieSearch.setCodPva(esercizioProfBean.getPartitaIVAParafarmacie());
		   parafarmacieSearch.setCodRegione(esercizioProfBean.getRegioneSelezionataParafarmacia());
		     
		   parafarmList = parafarmacieHome.findByFilter(parafarmacieSearch);
		  
		   return parafarmList;
	   }

	public EsercizioProfReg getEsercizioProf() {
		return esercizioProf;
	}

	public void setEsercizioProf(EsercizioProfReg esercizioProf) {
		this.esercizioProf = esercizioProf;
	}

	public ArrayList<EsercizioProfReg> getEserciziProf() {
		return eserciziProf;
	}

	public void setEserciziProf(ArrayList<EsercizioProfReg> eserciziProf) {
		this.eserciziProf = eserciziProf;
	}
	
}