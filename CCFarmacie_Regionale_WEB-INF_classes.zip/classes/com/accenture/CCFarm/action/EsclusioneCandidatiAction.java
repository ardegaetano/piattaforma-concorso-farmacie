package com.accenture.CCFarm.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.DatiCandidato;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.mailer.concorsofarma.data.MailBean;

public class EsclusioneCandidatiAction {
	
	private static final Logger logger = CommonLogger.getLogger("EsclusioneCandidatiAction");
	private GraduatoriaHome graduatoriaHome;
	
	public EsclusioneCandidatiAction() throws GestioneErroriException {
		
		try {
			graduatoriaHome = new GraduatoriaHome();
		}
		catch(Exception e) {
			logger.error("EsclusioneCandidatiAction - inizializzazione fallita", e);
			throw new GestioneErroriException("EsclusioneCandidatiAction - inizializzazione fallita");
		}
		
	}
	
	public List<DatiCandidato> ricercaUtentiCandidati(DatiCandidato datiCandidato) throws GestioneErroriException {
		return graduatoriaHome.findGraduatoriaForEsclusione(datiCandidato);
	}
	
	public void escludiCandidato(String idCandidatura, String motivoRinuncia) throws GestioneErroriException {
		Graduatoria graduatoria = graduatoriaHome.findById(idCandidatura);
		if(graduatoria!=null) {
			
			//Imposto il motivo della Rinuncia
			graduatoria.setEscluso("true");
     	   	graduatoria.setMotivoEsclusione(motivoRinuncia);
     	   
			//Preparazione MAIL
			MailBean mailBean = new MailBean();
			UtenteHome utenteHome = new UtenteHome();
			Utente utente = utenteHome.findById(graduatoria.getIdCandidatura());
			//Imposta il destinatario
            ArrayList listaDest = new ArrayList<String>();
            listaDest.add(utente.getPecMail());
            mailBean.setToAddresses(listaDest);
            
            //OGGETTO MAIL
            String sOggettoMail = "";
            sOggettoMail = getOggettoMailEsclusione(utente, graduatoria.getNumeroProtocollo(), sOggettoMail, "");
            //Oggetto Mail in Tedesco
     	   	if(utente.getCodRegUtente().equals("041")){
     		   sOggettoMail = getOggettoMailEsclusione(utente, graduatoria.getNumeroProtocollo(), sOggettoMail, ".de");
     	   	}
     	   	mailBean.setOggettoMail(sOggettoMail);
     	   
     	   	//CORPO MAIL
     	   	String sCorpoMail = "";
     	   	String sDenominazione = graduatoria.getNome()+" "+graduatoria.getCognome();
     	   	sCorpoMail = getCorpoMailEsclusione(utente, sDenominazione, sCorpoMail, "");
     	   
     	   	//Corpo Mail in Tedesco
     	   	if(utente.getCodRegUtente().equals("041")){
     		   sCorpoMail = getCorpoMailEsclusione(utente, sDenominazione, sCorpoMail, ".de");
     	   	}
     	   	mailBean.setCorpoMail( "<html>" + sCorpoMail + "</htlml>");
			
			graduatoriaHome.escludiCandidato(graduatoria, mailBean);
		}
	}
	
	public boolean isCandidatoInterpellato(String codReg, String idCandidatura) throws GestioneErroriException {
		return graduatoriaHome.isCandidatoInterpellato(codReg, idCandidatura);
	}
	
	private String getOggettoMailEsclusione(Utente utente, String sNumeroProtocollo, String sOggettoMail, String lingua){
		if(lingua!=null && lingua.equals(".de"))
			sOggettoMail = sOggettoMail + " / ";
		
		String regioneProv =  com.accenture.CCFarm.utility.Localita.getDenominazioneRegione(utente.getCodRegUtente()).toLowerCase();
		regioneProv = regioneProv.substring(0,1).toUpperCase() + regioneProv.substring(1);
 	   
		sOggettoMail = sOggettoMail + JSFUtility.getPropertyMessage("esclusione.oggetto.mail"+lingua, "it")
		   .replace("<regione>", regioneProv)
		   .replace("<protocollo>", sNumeroProtocollo);
		
		return sOggettoMail;
	}
	
	private String getCorpoMailEsclusione(Utente utente, String sCandidato, String corpoMail, String lingua){ 
		if(lingua!=null && lingua.equals(".de"))
			corpoMail = corpoMail + "\r\n<br/>\r\n<br/>\r\n<br/>____________________________________________\r\n<br/>\r\n<br/>";
		
		String regioneProv =  com.accenture.CCFarm.utility.Localita.getDenominazioneRegione(utente.getCodRegUtente()).toLowerCase();
		regioneProv = regioneProv.substring(0,1).toUpperCase() + regioneProv.substring(1);
		
		String line1 =JSFUtility.getPropertyMessage("esclusione.corpo.mail1"+lingua, "it")+" <B>"+sCandidato+"</B>,";
		String line2 =JSFUtility.getPropertyMessage("esclusione.corpo.mail2"+lingua, "it")+" <B>"+regioneProv+"</B>.";
		String attenzione = JSFUtility.getPropertyMessage("esclusione.attenzione.gestita"+lingua, "it");
	    
		corpoMail = corpoMail + line1+"\r\n"+line2+"\r\n<br/>\r\n<br/>"+attenzione;
		
	    return corpoMail;
	}

	
}