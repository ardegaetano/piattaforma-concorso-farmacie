package com.accenture.CCFarm.action;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.UploadedFile;

import com.accenture.CCFarm.DAO.AnagraficaFarm;
import com.accenture.CCFarm.DAO.AnagraficaFarmHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.Bando;
import com.accenture.CCFarm.pageBean.BandoRegionale;
import com.accenture.CCFarm.pageBean.ConsultaSediListBean;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.Convertitore;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


public class DatiBandoAction {
	
	private static final Logger logger = CommonLogger.getLogger("DatiBandoAction");
	private static final String pageError = "errorPage.jsf";
	
    //Gestione UpLoad
  	private UploadedFile fileBando;
  	private UploadedFile fileSedi;
  	
	// *** da modificare ***
	private String codRegione;//="041"; //Piemonte
	private String utente;//="UtenteTest";

	public DatiBandoAction(){
		
		//inizializza convertitori di tipo
		Convertitore.registraConvertitori();
	}
	
	//Setta il file per il download caricando il BLOB da DB
	public void caricaFileDownload(BandoRegionale bandoReg) throws GestioneErroriException {
		
		//RECUPERO DALLA SESSIONE
    	FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	
    	try {
    		UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	    	if(utenteReg!=null)
	    	{
	    		logger.info("Utente NSIS recuperato dalla sessione");
	    		codRegione = utenteReg.getCodRegione();
	    		DatiBandoHome hDatiBando = new DatiBandoHome();
				DatiBando datiBando = hDatiBando.findById(codRegione);
		    	if(datiBando!=null){
	       			Blob bFileBando = datiBando.getFileBando();
	       			if(bFileBando!=null){
	       				InputStream streamB = bFileBando.getBinaryStream();
	       		    	if(streamB!=null){
	       		    		bandoReg.setFileDownloadBando(new DefaultStreamedContent(streamB, "application/pdf", "BANDO.pdf")); 
	       		    		bandoReg.setbCaricaBando(true);
	       		    		bandoReg.setVisibilitaCaricaBando("block");
	       		    		bandoReg.setInvisibilitaCaricaBando("none");
	       		    	}	
	       			}
		    	}
		    	else {
		    		InputStream streamB = fileBando.getInputstream();
	   				bandoReg.setFileDownloadBando(new DefaultStreamedContent(streamB, fileBando.getContentType(), fileBando.getFileName()));
	   				bandoReg.setbCaricaBando(true);
	   				bandoReg.setVisibilitaCaricaBando("block");
	   				bandoReg.setInvisibilitaCaricaBando("none");
		    	}
	    	}
	    	else {
	    		logger.error("Utente NSIS non presente in sessione");
	    		GestioneErroriException eccezione = new GestioneErroriException("DatiBandoAction - caricaFileDownload: Utente NSIS non presente in sessione");
				throw eccezione;
	    	}
    	} catch (Exception e) {
			logger.error("DatiBandoAction - caricaFileDownload: errore nel caricamento del file: " + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoAction - caricaFileDownload: "+e);
			throw eccezione;
		} 
	}
	
	
	//Load di Pagina 
    public void loadPaginaInserimento(BandoRegionale bandoReg) throws GestioneErroriException {
    	
    	//RECUPERO DALLA SESSIONE
    	FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	
    	try {
	    	//ACCESSO DA CARTINA ***********************************************************************************
	    	DatiBando datiBando = (DatiBando)session.getAttribute(RepositorySession.DATI_BANDO);
	    	if(datiBando!=null) {
	    		
	    		BeanUtils.copyProperties(bandoReg, datiBando);
	    		if(datiBando.getCodReg().equals("041")){
	    			bandoReg.setFlagColonnaTedesco(true);
	    		}
	    	}
	    	else { //ACCESSO DA REGIONI *****************************************************************************
	    	
		    	UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
		    	
		    	if(utenteReg!=null)
		    	{
		    		logger.info("Utente NSIS recuperato dalla sessione");
		    		codRegione = utenteReg.getCodRegione();
		    		utente = utenteReg.getUserId();
		    	}
		    	else {
		    		logger.error("Utente NSIS non presente in sessione");
		    		GestioneErroriException eccezione = new GestioneErroriException("DatiBandoAction - loadPaginaInserimento: Utente NSIS non presente in sessione");
					throw eccezione;
		    	}
		    	
		    	//PROVA EXCEPTION
		    	//codRegione = null;
		    	
		    	DatiBandoHome hDatiBando = new DatiBandoHome();
				datiBando = hDatiBando.findById(codRegione);
		    	
		    	if(datiBando!=null){
			    		
		    		if(datiBando.getCodReg().equals("041")){
			    			bandoReg.setFlagColonnaTedesco(true);
			    		}
		    		
		       			Blob bFileBando = datiBando.getFileBando();
		       			if(bFileBando!=null){
		       				InputStream streamB = bFileBando.getBinaryStream();
		       		    	if(streamB!=null){
		       		    		bandoReg.setFileDownloadBando(new DefaultStreamedContent(streamB, "application/pdf", "BANDO.pdf")); 
		       		    		bandoReg.setbCaricaBando(true);
		       		    		bandoReg.setVisibilitaCaricaBando("block");
		       		    		bandoReg.setInvisibilitaCaricaBando("none");
		       		    	}	
		       			}
		       			
		       			//Gestione Sedi - leggo file CSV sedi da DB 
		       			if(datiBando.getFileSedi()!=null){
		       				InputStream is = datiBando.getFileSedi().getAsciiStream();
		       				List<ConsultaSediListBean> lista = caricaTabellaSediCSV(is, bandoReg);
		       				if(lista.size()>0){ //CSV valido
		       					short len = new Short(new Integer(lista.size()).toString()).shortValue();
		       					bandoReg.setSediBando(datiBando.getSediBando()); 
		       					bandoReg.setSediCaricate(len);
	        					bandoReg.setbCaricaSedi(true);
	        					bandoReg.setbCSVValido(true);
	        					bandoReg.setListFarm(lista);
		       				}
		       				else { //No record
		       					bandoReg.setSediBando(new Short("0")); 
	        					bandoReg.setbCaricaSedi(false);
	        					bandoReg.setbCSVValido(true);
	        					bandoReg.setListFarm(null);
		       				}
		       			}
		       			//Abilita/Disabilita campi    
		       			//alternativo alla riga successiva
		       			//bandoReg.setbStato((datiBando.getStato().equals("1")) ? true : false);
		       		/* modifica per caricare sedi pi� volte*/
		       			bandoReg.setbStato(((datiBando.getFlgAbilitaCaricaSedi()!=null && datiBando.getFlgAbilitaCaricaSedi().equals("true"))) ? false : true);
		       			
		       			bandoReg.setVisibilitaSalva((datiBando.getStato().equals("1")) ? "none" : "block");
		       			bandoReg.setVisibilitaRipubblica((datiBando.getStato().equals("1")) ? "block" : "none");
		       			
		       			if(!bandoReg.isContributoPartecipazione()) { //Contributo Partecipazione
		       				bandoReg.setEstremiPagamento(null);
		       				bandoReg.setVisibilita("none");
		       			}
		       			else bandoReg.setVisibilita("block");
		       			
						BeanUtils.copyProperties(bandoReg, datiBando);
						
		    	}
	    	}	
    	} catch (Exception e) {
			logger.error("DatiBandoAction - loadPaginaInserimento: errore nel caricamento del file" + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoAction - loadPaginaInserimento: "+e);
			throw eccezione;
    	}
    }
    
    public String insertDatiBando(Bando bando)throws GestioneErroriException {
    	
    	String msg = controlliCampi(bando, false);
		if(msg==null || msg.equalsIgnoreCase(""))
			salvaBando(bando, false);
    	
		return msg;
	}
    
    public String insertDatiSedi(Bando bando) throws GestioneErroriException{
    	
    	InterpelloHome inteppelloHome = new InterpelloHome();
    	HttpSession session = (HttpSession) JSFUtility.getFacesContext().getExternalContext().getSession(false);
    	UtenteRegioni utenteRegBando = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
    	boolean interpelloAperto = inteppelloHome.controllaPresenzaInterpelloInCorso(utenteRegBando.getCodRegione());
    	String msg =null;
    	if(interpelloAperto){
    		msg="Non � possibile aggiornre le sedi con un interpello in corso";
    	}else{
    		msg = controlliSedi(bando);
    	}
		if(msg==null)
			salvaSediBando(bando, true);
		return msg;
	}
    
    //Validazione del Bando
    public String validaBando(Bando bando) throws GestioneErroriException{
		
		String msg = controlliCampi(bando, true);
		
		//Aggiungere controlli per upload file
		if(msg==null || msg.equalsIgnoreCase(""))
			salvaBando(bando, true);
		
		return msg;
	}
    
    //Gestione UpLoadFile
    public String uploadBando(FileUploadEvent event, Bando bando) throws GestioneErroriException { 
    	String msg = null;
    	try { 
    		
    		//RECUPERO E INSERISCO IN SESSIONE IL FILE DI UPLOAD
        	FacesContext context = FacesContext.getCurrentInstance();
        	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
        	HttpSession session = req.getSession();
        	
	    	fileBando = event.getFile();
	        if (!fileBando.getFileName().toLowerCase().endsWith(".pdf")) 
	            msg = "Upload file PDF: formato non corretto.";
	        else { 
	        	bando.getBandoRegionale().setbCaricaBando(true);
	        	bando.getBandoRegionale().setVisibilitaCaricaBando("block");
	        	bando.getBandoRegionale().setInvisibilitaCaricaBando("none");
        		InputStream streamB = fileBando.getInputstream();
        		
        		session.setAttribute(RepositorySession.FILE_BANDO, streamB); //In sessione il file BANDO
        		
        		bando.getBandoRegionale().setFileDownloadBando(new DefaultStreamedContent(streamB, fileBando.getContentType(), fileBando.getFileName()));
        	} 
	        
        }catch (Exception e) {
			logger.error("Errore metodo uploadBando - setFileDownloadBando" + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoAction - uploadBando: "+e);
			throw eccezione;
    	}
    	return msg;
    }   
    
    //Effettua il controllo dell'estensione file e crea gli array per la visualizzazione in tabella
    public String uploadSedi(FileUploadEvent event, Bando bando) throws GestioneErroriException { 
    	String msg = null;
    	try
		{
    		
    		//RECUPERO DALLA SESSIONE
        	FacesContext context = FacesContext.getCurrentInstance();
        	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
        	HttpSession session = req.getSession();
    		
        	UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
        	if(utenteReg!=null)
	    	{
	    		logger.info("Utente NSIS recuperato dalla sessione");
	    		codRegione = utenteReg.getCodRegione();
	    		utente = utenteReg.getUserId();
	    	}
        	
    		fileSedi = event.getFile();
    		if(fileSedi!=null){
    			InputStream is = null;
    			is = fileSedi.getInputstream();
				List<ConsultaSediListBean> lista = caricaTabellaSediCSV(is, bando.getBandoRegionale());
   				if(lista.size()>0){
   					short len = new Short(new Integer(lista.size()).toString()).shortValue();
   					bando.getBandoRegionale().setSediCaricate(len);
   					bando.getBandoRegionale().setbCaricaSedi(true);
   					bando.getBandoRegionale().setbCSVValido(true);
   					bando.getBandoRegionale().setListFarm(lista);
   				}
   				else { //No record
   					if(bando.getBandoRegionale().isbCSVValido()) { //Gestione CSV non valido
   						bando.getBandoRegionale().setbCSVValido(true);
   					} 
   					else {
   						msg = "File CSV non corretto";
   					}
   					bando.getBandoRegionale().setSediBando(new Short("0")); 
   					bando.getBandoRegionale().setbCaricaSedi(false);
					bando.getBandoRegionale().setListFarm(null);
   				}
    	    } 
    	} catch (Exception e) {
			logger.error("DatiBandoAction - uploadSedi: " + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoAction - uploadSedi: "+e);
			throw eccezione;
    	}
        return msg;
    }
    
    public List<ConsultaSediListBean> caricaTabellaSediCSV(InputStream inputStream, BandoRegionale bandoReg) throws GestioneErroriException {

    	List<ConsultaSediListBean> listFarm = null;
    	
    	String SEPARATOR = "\\|";
    	String CAMPO_PREC = "avviamento";
    	String CAMPO_PREC_UPPER = "AVVIAMENTO";
    	try { 
    		   DataInputStream in = new DataInputStream(inputStream);
    		   BufferedReader br = new BufferedReader(new InputStreamReader(in));
    	       String line = "";
    	       int lineNumber = 0; 
    	       boolean bGo = false;
    	       listFarm = new ArrayList<ConsultaSediListBean>();
    	       
    	       while ((line = br.readLine()) != null) {
    	    	   
    	         String[] riga = line.split(SEPARATOR);
    	         if(bGo){
    	        	if ((bandoReg.isFlagColonnaTedesco() && riga.length==10)||(!bandoReg.isFlagColonnaTedesco() && riga.length==9)){ 
    	        		listFarm.add(addSede(riga));
    	        		lineNumber++;
    	        	}
    	        	else { //CSV non corretto
       					bandoReg.setbCSVValido(false);
    	        		break;
    	        	}
    	         }
    	         if(line.contains(CAMPO_PREC) || line.contains(CAMPO_PREC_UPPER))
  	    		   bGo = true;
  	    		   
    	       }

	    } catch (Exception e) {
			logger.error("DatiBandoAction - caricaTabellaSediCSV: errore nel caricamento della tabella sedi da CSV: " + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoAction - caricaTabellaSediCSV: "+e);
			throw eccezione;
	    }
    	return listFarm;
    }
    
    private ConsultaSediListBean addSede(String[] riga) throws GestioneErroriException {
    	
    	ConsultaSediListBean consultaSediList = new ConsultaSediListBean();
    	consultaSediList.setCodIstatProv(riga[0].toString());
		consultaSediList.setDesProv(riga[1].toString());
		consultaSediList.setCodIstatComu(riga[2].toString());
		consultaSediList.setDesComu(riga[3].toString());
		consultaSediList.setnProgCom(riga[4].toString());
		consultaSediList.setDesSede(riga[5].toString());
		consultaSediList.setTipoSede(riga[6].toString());
		consultaSediList.setCritTopo(riga[7].toString());
		consultaSediList.setIndennitaAvviamento(riga[8].toString());
		if(codRegione.equals("041"))
		consultaSediList.setDesSedeDe(riga[9].toString());
		
    
		return consultaSediList;
	}
    
//******************************************************************************************************
//Metodi Privati 
//******************************************************************************************************

	private void salvaBando(Bando bando, boolean bValida) throws GestioneErroriException {
	    
		try {
			java.util.Date dataSys= new java.util.Date();
			java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
			logger.info("salvaBando - Inizio");
			DatiBando datiBando = null;
			DatiBandoHome bandoHome = new DatiBandoHome();
		
			FacesContext context = FacesContext.getCurrentInstance();
			HttpSession session = (HttpSession)context.getExternalContext().getSession(true);
			UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
    	
			if(utenteReg!=null)
			{
				logger.info("Utente NSIS recuperato dalla sessione");
				codRegione = utenteReg.getCodRegione();
				utente = utenteReg.getUserId();
			}
			else {
				logger.error("Utente NSIS non presente in sessione");
	    		JSFUtility.redirect(pageError);
			}
			
			logger.info("salvaBando - user " + utente);
			logger.info("salvaBando - chiamo hibernate ");
			datiBando = bandoHome.findById(codRegione);
			if(datiBando==null) {
				datiBando = new DatiBando();
				datiBando.setCodReg(codRegione);
			}
			
			//Contributo Partecipazione
			if(!bando.getBandoRegionale().isContributoPartecipazione()) 
				bando.getBandoRegionale().setEstremiPagamento(null);
			  	        
			logger.info("1 - salvaBando - Codice Regione: " + codRegione);
			BeanUtils.copyProperties(datiBando,bando.getBandoRegionale());
			
			if(datiBando.getCreatedByBando()==null){
				datiBando.setCreatedByBando(utente);
				datiBando.setCreationDateBando(oggi);
			}
			datiBando.setLastUpdatedByBando(utente);
			datiBando.setLastUpdateDateBando(oggi);
				
			if(bValida){
				datiBando.setStato("1");
				bando.getBandoRegionale().setbStato(true);
				bando.getBandoRegionale().setStato("1");
				//Imposta il numero di sedi messe a Bando
				bando.getBandoRegionale().setSediBando(bando.getBandoRegionale().getSediCaricate());
			}
			else {
				if(datiBando.getStato()==null || datiBando.getStato().equalsIgnoreCase(""))
				datiBando.setStato("0");
			}
			logger.info("2 - salvaBando - prima del SALVA");
			
			//Gestione SEDI
			//if(bValida){
				InputStream is = datiBando.getFileSedi().getAsciiStream();
				List<ConsultaSediListBean> lista = bando.getBandoRegionale().getListFarm();
				
				if(lista!=null){
					//Imposta la data pubblicazione delle sedi
					datiBando.setDataPubblicazioneSedi(DateUtil.getCurrentTimestamp());
					
					AnagraficaFarmHome gestSediHome = new AnagraficaFarmHome();
					
					//cancellazione sedi registrate in precendenza
					gestSediHome.deleteSediPerRegione(codRegione);
					
					for(int i=0; i<lista.size(); i++){
						ConsultaSediListBean riga = (ConsultaSediListBean)lista.get(i);
						AnagraficaFarm gestSedi = new AnagraficaFarm();
						String idFarm = new AnagraficaFarmHome().getSequenceIdSede();
						gestSedi.setIdFarm(idFarm);
						gestSedi.setCodRegFarm(codRegione);
						gestSedi.setIdBandoFarm(codRegione);
						
						if(riga.getCodIstatProv()!=null)
							gestSedi.setPrvFarm(removeZeriTesta(riga.getCodIstatProv().toString()));
						if(riga.getDesProv()!=null)
							gestSedi.setDescrPrvFarm(riga.getDesProv().toString());
						if(riga.getCodIstatComu()!=null)
							gestSedi.setComuneFarm(addZeriTesta(riga.getCodIstatComu().toString(), 6));
						if(riga.getDesComu()!=null)
							gestSedi.setFrazioneFarm(riga.getDesComu().toString());
						if(riga.getnProgCom()!=null)
							gestSedi.setNProgressivo(riga.getnProgCom().toString());
						if(riga.getDesSede()!=null)
							gestSedi.setDescrizioneSede(Hibernate.createClob(riga.getDesSede().toString()));
						if(riga.getDesSedeDe()!=null)
							gestSedi.setDescrizioneSedeDe(Hibernate.createClob(riga.getDesSedeDe().toString()));
						if(riga.getTipoSede()!=null)
							gestSedi.setCodTipoSede(riga.getTipoSede().toString());
						if(riga.getCritTopo()!=null)
							gestSedi.setCriterioTopoFarm(riga.getCritTopo().toString());
						if(riga.getIndennitaAvviamento()!=null)
							gestSedi.setIndennitaAvviamento(riga.getIndennitaAvviamento().toString());
						
						if(gestSedi.getCreatedByFarm()==null){
							gestSedi.setCreatedByFarm(utente);
							gestSedi.setCreationDateFarm(oggi);
						}
						gestSedi.setLastUpdatedByFarm(utente);
						gestSedi.setLastUpdateDateFarm(oggi);
						
						gestSediHome.saveOrUpdate(gestSedi); //da inserire poi in bandoHome
					}
				}
			//} //fine bValida
			
			//Gestione DATA FINE
			Date dataFUtil =  datiBando.getDataFineBando();
			if(dataFUtil!=null){
				Calendar cal = Calendar.getInstance();
				cal.setTime(datiBando.getDataFineBando());
				cal.set(Calendar.HOUR_OF_DAY, 18);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				Date data = cal.getTime();
				datiBando.setDataFineBando(data);
			}
			
			//InsertUpdateDB - DATIBANDO
			bandoHome.saveOrUpdate(datiBando, getFileBando(), getFileSedi());
			
			logger.info("3 - salvaBando - DOPO IL SALVA");
			
		} catch (Exception e) {
			logger.error("DatiBandoAction - salvaBando: errore in fase di salvataggio del bando: " + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoAction - salvaBando: errore in fase di salvataggio del bando"+e);
			throw eccezione;
		}
		logger.info(" 4 - salvaBando - Fine");
	}
    
	
private void salvaSediBando(Bando bando, boolean bValida) throws GestioneErroriException {
	    
		try {
			java.util.Date dataSys= new java.util.Date();
			java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
			logger.info("salvaBando - Inizio");
			DatiBando datiBando = null;
			DatiBandoHome bandoHome = new DatiBandoHome();
		
			FacesContext context = FacesContext.getCurrentInstance();
			HttpSession session = (HttpSession)context.getExternalContext().getSession(true);
			UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
    	
			if(utenteReg!=null)
			{
				logger.info("Utente NSIS recuperato dalla sessione");
				codRegione = utenteReg.getCodRegione();
				utente = utenteReg.getUserId();
			}
			else {
				logger.error("Utente NSIS non presente in sessione");
	    		JSFUtility.redirect(pageError);
			}
			
			logger.info("salvaBando - user " + utente);
			logger.info("salvaBando - chiamo hibernate ");
			datiBando = bandoHome.findById(codRegione);
			
			//Gestione SEDI
			//if(bValida){
				InputStream is = datiBando.getFileSedi().getAsciiStream();
				List<ConsultaSediListBean> lista = bando.getBandoRegionale().getListFarm();
				
				if(lista!=null){
					//Imposta la data pubblicazione delle sedi
					datiBando.setDataPubblicazioneSedi(DateUtil.getCurrentTimestamp());
					
					AnagraficaFarmHome gestSediHome = new AnagraficaFarmHome();
					
					//cancellazione sedi registrate in precendenza
					gestSediHome.deleteSediPerRegione(codRegione);
					
					for(int i=0; i<lista.size(); i++){
						ConsultaSediListBean riga = (ConsultaSediListBean)lista.get(i);
						AnagraficaFarm gestSedi = new AnagraficaFarm();
						String idFarm = new AnagraficaFarmHome().getSequenceIdSede();
						gestSedi.setIdFarm(idFarm);
						gestSedi.setCodRegFarm(codRegione);
						gestSedi.setIdBandoFarm(codRegione);
						
						if(riga.getCodIstatProv()!=null)
							gestSedi.setPrvFarm(removeZeriTesta(riga.getCodIstatProv().toString()));
						if(riga.getDesProv()!=null)
							gestSedi.setDescrPrvFarm(riga.getDesProv().toString());
						if(riga.getCodIstatComu()!=null)
							gestSedi.setComuneFarm(addZeriTesta(riga.getCodIstatComu().toString(), 6));
						if(riga.getDesComu()!=null)
							gestSedi.setFrazioneFarm(riga.getDesComu().toString());
						if(riga.getnProgCom()!=null)
							gestSedi.setNProgressivo(riga.getnProgCom().toString());
						if(riga.getDesSede()!=null)
							gestSedi.setDescrizioneSede(Hibernate.createClob(riga.getDesSede().toString()));
						if(riga.getDesSedeDe()!=null)
							gestSedi.setDescrizioneSedeDe(Hibernate.createClob(riga.getDesSedeDe().toString()));
						if(riga.getTipoSede()!=null)
							gestSedi.setCodTipoSede(riga.getTipoSede().toString());
						if(riga.getCritTopo()!=null)
							gestSedi.setCriterioTopoFarm(riga.getCritTopo().toString());
						if(riga.getIndennitaAvviamento()!=null)
							gestSedi.setIndennitaAvviamento(riga.getIndennitaAvviamento().toString());
						
						if(gestSedi.getCreatedByFarm()==null){
							gestSedi.setCreatedByFarm(utente);
							gestSedi.setCreationDateFarm(oggi);
						}
						gestSedi.setLastUpdatedByFarm(utente);
						gestSedi.setLastUpdateDateFarm(oggi);
						
						gestSediHome.saveOrUpdate(gestSedi); //da inserire poi in bandoHome
					}
				}
			
			datiBando.setSediCaricate(new Short (lista.size() +""));
			
			//bandoHome.saveOrUpdate(datiBando);
			bandoHome.saveOrUpdate(datiBando, null, getFileSedi());
			
			logger.info("3 - salvaBando - DOPO IL SALVA");
			
		} catch (Exception e) {
			logger.error("DatiBandoAction - salvaBando: errore in fase di salvataggio del bando: " + e.getMessage(), e);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoAction - salvaBando: errore in fase di salvataggio del bando"+e);
			throw eccezione;
		}
		logger.info(" 4 - salvaBando - Fine");
	}
	
    private String controlliCampi(Bando bando, boolean bValida) throws GestioneErroriException {
    	
    	java.util.Date dataSys= new java.util.Date();
        java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
    	String msg = "";
		
    	if(!bValida) {
			Date dInizio = bando.getBandoRegionale().getDataInizioBando();
			Date dFine = bando.getBandoRegionale().getDataFineBando();
			
			if(dInizio!=null || dFine!=null){
				/*if(dataSys.after(dInizio)){
					msg = msg + "Data inizio errata - la data inizio presentazione domanda deve essere superiore alla data odierna";	
				}
				else*/ if(dFine!=null){
					if(dInizio.after(dFine))
						msg = msg + "Date incongruenti - la data inizio presentazione domanda deve essere inferiore alla data fine presentazione domanda";	
				}	
			}
			
			Date dInizioCorsi = bando.getBandoRegionale().getDataInizioCorsi();
			Date dFineCorsi = bando.getBandoRegionale().getDataFineCorsi();
			if(dInizioCorsi!=null && dFineCorsi!=null){
				if(dInizioCorsi.after(dFineCorsi))
					msg = msg + "Date incongruenti - la data inizio corsi deve essere inferiore alla data fine corsi";	
			}
			
			Date dInizioPubb = bando.getBandoRegionale().getDataInizioPubblicazioni();
			Date dFinePubb = bando.getBandoRegionale().getDataFinePubblicazioni();
			if(dInizioPubb!=null && dFinePubb!=null){
				if(dInizioPubb.after(dFinePubb))
					msg = msg + "Date incongruenti - la data inizio pubblicazioni deve essere inferiore alla data fine pubblicazioni";	
			}
			
    	}
    	else { //Controlli Validazione
    		Date dBando = bando.getBandoRegionale().getDataPubblicazioneBando();
    		if(dBando==null)
    			msg = msg + " Data di pubblicazione del bando obbligatoria.  ";	
    		Date dInizio = bando.getBandoRegionale().getDataInizioBando();
    		if(dInizio==null)
    			msg = msg + " Data inizio presentazione domanda obbligatoria.  ";	
			Date dFine = bando.getBandoRegionale().getDataFineBando();
    		if(dFine==null)
    			msg = msg + " Data fine presentazione domanda obbligatoria.  ";	
			
    		Date dInizioCorsi = bando.getBandoRegionale().getDataInizioCorsi();
    		if(dInizioCorsi==null)
    			msg = msg + " Data inizio corsi obbligatoria.  ";	
			Date dFineCorsi = bando.getBandoRegionale().getDataFineCorsi();
    		if(dFineCorsi==null)
    			msg = msg + " Data fine corsi obbligatoria.  ";	
    		
    		Date dInizioPubb = bando.getBandoRegionale().getDataInizioPubblicazioni();
    		if(dInizioPubb==null)
    			msg = msg + " Data inizio pubblicazioni obbligatoria.  ";	
			Date dFinePubb = bando.getBandoRegionale().getDataFinePubblicazioni();
    		if(dFinePubb==null)
    			msg = msg + " Data fine pubblicazioni obbligatoria.  ";	
    		
			if(!bando.getBandoRegionale().isbCaricaBando())
				msg = msg + " File Bando non presente.  ";	
			if(!bando.getBandoRegionale().isbCaricaSedi())
				msg = msg + " File Sedi non presente.  ";	
    	}
    	
		return msg;
    }   
    
    private UploadedFile getFileBando() {
		return fileBando;
	}

    private void setFileBando(UploadedFile fileBando) {
		this.fileBando = fileBando;
	}

    private UploadedFile getFileSedi() {
		return fileSedi;
	}

    private void setFileSedi(UploadedFile fileSedi) {
		this.fileSedi = fileSedi;
	}
    
    private String controlliSedi(Bando bando) throws GestioneErroriException {
    	String msg = null;
    	if(!bando.getBandoRegionale().isbCaricaSedi())
    		msg = "File Sedi non presente";	
    	//if(!bando.getBandoRegionale().())
    		
    	return msg;
    }
    
    private String addZeriTesta(String s, int lenMax) {
    	String campo = s;
    	while(campo.length()<lenMax){
    		campo = "0"+campo;
    	}
    	return campo;
    }
    
    private String removeZeriTesta(String s) {
    	String campo = s;
    	Integer campoInt = new Integer(s);
    	campo = campoInt.toString();
    	return campo;
    }
    
    
}