package com.accenture.CCFarm.action;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.PrintException;


public class RedirectFixFilter implements Filter 
{
	Logger logger = CommonLogger.getLogger("RedirectFixFilter");
	
	public void destroy() {}
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		String pageError = "errorPage.jsf";
		String pathToFix = AppProperties.getAppProperties().getProperty("path_da_correggere");
		String correctPath = AppProperties.getAppProperties().getProperty("path_corretto");
		
		HttpServletRequest req=(HttpServletRequest)request;
		HttpServletResponse resp=(HttpServletResponse)response;
		
		try
		{
			String pageRequested = req.getRequestURL().toString();
			
			//String pageRequested = "http://nsis.sanita.it/WSHUB/CCFarm_Regionale/jsp/homeRegioni.jsf";
			
			if(pageRequested.contains(pathToFix))
			{
				pageRequested=pageRequested.replace(pathToFix,correctPath);
				//resp.sendRedirect(pageRequested);
				
				resp.setStatus(HttpServletResponse.SC_FOUND);
				resp.setHeader("Location",pageRequested);
				
				//String page=pageRequested.substring(pageRequested.lastIndexOf('/')+1,pageRequested.length());
				//request.getRequestDispatcher(page).forward(request,response);
			}
			
			chain.doFilter(req,resp);
			
		}
		catch(Exception e)
		{
			logger.error("RedirectFixFilter error: " + PrintException.stack2string(e));
			resp.sendRedirect(pageError);
		}
	}

	public void init(FilterConfig arg0) throws ServletException {}

}
