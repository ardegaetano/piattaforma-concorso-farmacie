package com.accenture.CCFarm.action;

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.AnagraficaFarmInterpelli;
import com.accenture.CCFarm.DAO.AnagraficaFarmInterpelliHome;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.ConsultaSediListBean;
import com.accenture.CCFarm.pageBean.SediNonAssegnateInterpelloBean;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.StringUtil;

public class SediNonAssegnateAction {
	
	private static final Logger logger = CommonLogger.getLogger("SediNonAssegnateAction");
	private BigDecimal id_interpello;
	private String codRegione;
	private InterpelloHome interpelloHome;
	private AnagraficaFarmInterpelliHome anagFarmInterpelloHome;
	
	private AppProperties paramProperties = AppProperties.getAppProperties();
	private String sVero = paramProperties.getProperty("flag.valore.vero");
	private String sFalso = paramProperties.getProperty("flag.valore.falso");
	private static final String codiceInterpelloChiuso = AppProperties.getAppProperties().getProperty("codice.interpello.chiuso");
	
	public SediNonAssegnateAction() throws GestioneErroriException {
		
		try {
			interpelloHome = new InterpelloHome();
		}
		catch(Exception e) {
			logger.error("SediNonAssegnateAction - inizializzazione fallita", e);
			throw new GestioneErroriException("SediNonAssegnateAction - inizializzazione fallita");
		}
		
	}
	
	public void init(String codiceRegione, SediNonAssegnateInterpelloBean sediNonAssegnateBean) throws GestioneErroriException {
		try {
			setCodRegione(codiceRegione);
			//Torna il max interpello presente
			Interpello interpello = interpelloHome.determinaInterpelloCorrente(codRegione);
			if(interpello.getStato().equals(codiceInterpelloChiuso)) 
			{
				anagFarmInterpelloHome = new AnagraficaFarmInterpelliHome();
				setId_interpello(interpello.getId().getIdInterpello());
				sediNonAssegnateBean.setVisibilitaTabSediNonAssegnate(sVero);
				sediNonAssegnateBean.setDescrInterpello(getId_interpello().toString()+"� interpello");
				sediNonAssegnateBean.setnSediNonAssegnate(anagFarmInterpelloHome.getNSediNonAssegnate(codiceRegione, getId_interpello()));
				List<ConsultaSediListBean> listaSedi = setListaSediBean(anagFarmInterpelloHome.getSediNonAssegnate(codiceRegione, getId_interpello()));
				sediNonAssegnateBean.setListFarmNonAssegnate(listaSedi);
			}
			else 
				sediNonAssegnateBean.setVisibilitaTabSediNonAssegnate(sFalso);
			
		}
		catch(Exception e) {
			logger.error("SediNonAssegnateAction - init - nessun interpello chiuso presente", e);
		}
	}

	public BigDecimal getId_interpello() {
		return id_interpello;
	}

	public void setId_interpello(BigDecimal id_interpello) {
		this.id_interpello = id_interpello;
	}

	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}
	
	private List<ConsultaSediListBean> setListaSediBean(List<AnagraficaFarmInterpelli> listaAnagFarm) throws GestioneErroriException {
		List<ConsultaSediListBean> listaSedi = new ArrayList<ConsultaSediListBean>();
		ConsultaSediListBean anagFarm = null;
		for (Iterator iterator = listaAnagFarm.iterator(); iterator.hasNext();) {
			anagFarm = new ConsultaSediListBean();
			Object[] row = (Object[]) iterator.next(); 
			anagFarm.setCodIstatProv(StringUtil.addZeriTesta((String)row[0], 3));// row[0] codIstatProv
			anagFarm.setDesProv((String)row[1]);//1 desProv
			anagFarm.setCodIstatComu((String)row[2]);//2 codIstatComu
			anagFarm.setDesComu((String)row[3]);//3 desComu
			anagFarm.setnProgCom((String)row[4]);//4 nProgCom
			Clob cDesSede = (Clob)row[5];
			anagFarm.setDesSede(cDesSede!=null ? StringUtil.convertClob(cDesSede) : "");//5 desSede //CLOB
			Clob cDesSedeDe = (Clob)row[6];
			anagFarm.setDesSedeDe(cDesSedeDe!=null ? StringUtil.convertClob(cDesSedeDe) : "");//6 desSedeDe //CLOB
			anagFarm.setTipoSede((String)row[7]);//7 tipoSede
			anagFarm.setCritTopo((String)row[8]);//8 critTopo
			String[] sIndennita = ((String)row[9]).split(";");
			anagFarm.setIndennitaAvviamento(sIndennita[0]);//9 indennitaAvviamento
			
			listaSedi.add(anagFarm);
		}
		return listaSedi;
	}
	
	
	
}