package com.accenture.CCFarm.action;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.accenture.CCFarm.DAO.CandidaturaReg;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaDefinitiva;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.SchedaHome;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoriaHome;
import com.accenture.CCFarm.DAO.TipoGraduatoriaId;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.RicercaSchedeValutazione;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.RisolviExAequo;


public class RicercaSchedaValutazioneAction{
	
    Logger logger = CommonLogger.getLogger("RicercaCandidatoAction");
    String pageError = "errorPage.jsf";
    
    private List<Graduatoria> graduatoriaList;
    
    
   
    private RisolviExAequo r = new RisolviExAequo();
    
   

	public RicercaSchedaValutazioneAction(){
		
	}
	
	
	public void salvaSchede(List<RicercaSchedeValutazione> listaschede) throws GestioneErroriException {
    	
	    SchedaHome schedaHome=new SchedaHome();
		schedaHome.updateTabGraduatoria(listaschede);		

}

	public List<RicercaSchedeValutazione> check_protocollo(RicercaSchedeValutazione schede) throws GestioneErroriException {
		
		SchedaHome schedaHome = new SchedaHome();
		
		List<RicercaSchedeValutazione> listaSchede = new ArrayList<RicercaSchedeValutazione>();
		
		listaSchede = schedaHome.check_protocollo(schede);
		
		return listaSchede ;
	}

	public List ricercaSchedeAll(RicercaSchedeValutazione schede) throws GestioneErroriException {
		
		SchedaHome schedaHome = new SchedaHome();
		
		List<String> listaIdSchede = new ArrayList<String>();
		
		listaIdSchede = schedaHome.findSchedeAll(schede);
		
		return listaIdSchede ;
	}
	
	
	public List<RicercaSchedeValutazione> ricercaSchede(RicercaSchedeValutazione schede) throws GestioneErroriException {
    	
		SchedaHome schedaHome=new SchedaHome();
    	
    	List<RicercaSchedeValutazione> listaSchede= new ArrayList<RicercaSchedeValutazione>();
    		
    	List<String> listSelectIn = new ArrayList<String>();
		int primo = schede.getRowIniBlock();
    	int ultimo = schede.getRowIniBlock();
    	
    	for (int i = primo; i < schede.getRowFinBlock(); i++) {
			String idCandidato = schede.getIdSchedeList().get(i);
			listSelectIn.add(idCandidato);
			ultimo++;
		}
    	schede.setRowNumerUltimo(ultimo);
    	
    	listaSchede = schedaHome.findPage(schede,listSelectIn);		
		
    	return listaSchede ;
	}
	
	public String checkGraduatoria(String codReg) throws GestioneErroriException{
		
		String testoMess="";
		
			try
			{
				DatiBandoHome datiBandoHome = new DatiBandoHome();
				DatiBando datiBando = new DatiBando();
				datiBando = datiBandoHome.findById(codReg);	
				CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
				CandidaturaReg candidaturaReg;
				List<CandidaturaReg> listaCand;
				
				if ((datiBando.getFlgPrenota()!=null && datiBando.getFlgPrenota().equalsIgnoreCase("true")) && 
				   ((datiBando.getFlgPrecalcolato()==null || datiBando.getFlgPrecalcolato().equalsIgnoreCase("false")))){
					testoMess="Le schede di valutazione non sono ancora state predisposte";
				}
				
				if ((datiBando.getFlgPrenota()==null || datiBando.getFlgPrenota().equalsIgnoreCase("false")) && 
					(datiBando.getFlgPrecalcolato()==null || datiBando.getFlgPrecalcolato().equalsIgnoreCase("false"))){
					testoMess="Il calcolo dei punteggi non � ancora stato prenotato";
				}
				
				if ((datiBando.getFlgPrecalcolato()!=null && datiBando.getFlgPrecalcolato().equalsIgnoreCase("true")) &&
					(datiBando.getFlgScarti()!=null && datiBando.getFlgScarti().equalsIgnoreCase("true"))){
					testoMess="Il calcolo dei punteggi ha riportato degli errori";
				}
				
				if ((datiBando.getFlgPrecalcolato()!=null && datiBando.getFlgPrecalcolato().equalsIgnoreCase("true")) &&
					(datiBando.getFlgScarti()==null || datiBando.getFlgScarti().equalsIgnoreCase("false"))){
					
					candidaturaReg = new CandidaturaReg();
					candidaturaReg.setCodiceRegione(codReg);
					candidaturaReg.setErroreElabAutomatica("T");
					listaCand = candidaturaRegHome.findByExample(candidaturaReg);
					
					// errore logico c'era un OR invece ci va un AND
					if (listaCand!=null && !listaCand.isEmpty() ){
						
						testoMess="Il calcolo dei punteggi ha riportato degli errori";
						datiBando.setFlgScarti("true");
						datiBandoHome.saveOrUpdate(datiBando);
						
					}
					else testoMess="";
					
				}
							
			}
			catch(Exception e){
				e.printStackTrace();
				throw new GestioneErroriException("errore nel controllo del prenota calcolo");
			}
					
		return testoMess;
	}
	
	public void confermaGraduatoria(String codReg) throws GestioneErroriException{
		
		GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
		
		int posizione = 0;
		
	
		try {
			graduatoriaList = graduatoriaHome.findOrderByGraduatoria(codReg);
		
			r.risolviexAequoSuGraduatoria(graduatoriaList);
			
		
		
		for(Graduatoria graduatoria : graduatoriaList){
				
				
				
				//graduatoriaDefinitiva = new GraduatoriaDefinitiva();
				posizione++;
				if(graduatoria.getExAequoRisolto()!=null && !graduatoria.getExAequoRisolto().equals("T") ){
				
					if((graduatoriaList.indexOf(graduatoria)-1)>=0){
						if(graduatoriaList.get(graduatoriaList.indexOf(graduatoria)-1)!=null && graduatoriaList.get(graduatoriaList.indexOf(graduatoria)-1).getColor()!=null && graduatoriaList.get(graduatoriaList.indexOf(graduatoria)-1).getColor().equalsIgnoreCase("red") && !graduatoriaList.get(graduatoriaList.indexOf(graduatoria)-1).getColor().equalsIgnoreCase("blue")){
							int count = posizione-1;
							do{
								
								//graduatoriaList.get(count).setIndiceRelativo(posizione);
								if(graduatoriaList.get(count).getColor()!=null && graduatoriaList.get(count).getPunteggio().compareTo(graduatoriaList.get(count-1).getPunteggio())==0 && graduatoriaList.get(count).getEtaMedia().compareTo(graduatoriaList.get(count-1).getEtaMedia())==0 && !graduatoria.getExAequoRisolto().equals("T")){
									graduatoriaList.get(count).setIndiceRelativo(new BigDecimal(posizione));
									graduatoriaList.get(count-1).setIndiceRelativo(new BigDecimal(posizione));
								}else{
									break;
								}
								
								
								
								
								count--;
							}while(count>=0 && (count-1)>0 && graduatoriaList.get(count)!=null && graduatoriaList.get(count).getColor()!=null && graduatoriaList.get(count).getColor().equalsIgnoreCase("red") && !graduatoriaList.get(count).getColor().equalsIgnoreCase("blue") && graduatoriaList.get(count).getPunteggio().compareTo(graduatoriaList.get(count-1).getPunteggio())==0 && graduatoriaList.get(count).getEtaMedia().compareTo(graduatoriaList.get(count-1).getEtaMedia())==0 && !graduatoria.getExAequoRisolto().equals("T") );
						}
					}	
			}

			}
			
			saveGraduatoria(graduatoriaList);
			
		
			
			//AGGIORNO IL FLAG CHE MI ABILITA IL TAB DELLA GESTIONE DEGLI EXAEQUI
			DatiBando datiBando = new DatiBando();
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			datiBando = datiBandoHome.findById(codReg);
			datiBando.setFlgAbilitaGrad("true");
			datiBando.setFlgValidaGrad("true");
			datiBandoHome.saveOrUpdate(datiBando);
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			throw new GestioneErroriException("errore nella conferma della graduatoria");
		}
		
	}
	
	
	public void saveGraduatoria(List<Graduatoria> graduatoriaList) throws GestioneErroriException{
		
		Transaction trx = null;
		
		Session session = null;
		try{
		for(Graduatoria graduatoria: graduatoriaList){
			//logger.debug("apertura transazione per l'utente con id " + graduatoriaDefinitiva2.getIdCandidatura());
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			trx.begin();
			//deleteGraduatoria(graduatoriaDefinitiva2,session);
			session.saveOrUpdate(graduatoria);
			//insertGraduatoria(graduatoriaDefinitiva2,session);
			trx.commit();
			
		}
		
		
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			trx.rollback();
			e.printStackTrace();
			throw new GestioneErroriException("errore nel salvataggio  della graduatoria");
		}finally{
			session.close();
		}
	}
	public void deleteGraduatoria(GraduatoriaDefinitiva graduatoriaDefinitiva,Session session)  throws GestioneErroriException {
		
		
		
		
		try{
			session.delete(graduatoriaDefinitiva);
			
		}catch(Exception e){
			logger.error("la delete della graduatoria ha generato degli errori",e);
			e.printStackTrace();
		}
		
	}
	
	public void insertGraduatoria(GraduatoriaDefinitiva graduatoriaDefinitiva,Session session) throws GestioneErroriException{

		try{
			session.saveOrUpdate(graduatoriaDefinitiva);
			
		}catch(Exception e){
			logger.error("Il salvataggio  della graduatoria ha generato degli errori",e);
			e.printStackTrace();
		}
	}
	
	public boolean checKTipoGraduatoria(String codReg){
		
		TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
		TipoGraduatoria tipoGraduatoria = new TipoGraduatoria();
		TipoGraduatoriaId tipoGraduatoriaId = new TipoGraduatoriaId();
		tipoGraduatoriaId.setCodRegione(codReg);
		tipoGraduatoria.setIdKey(tipoGraduatoriaId);
		
		try {
			List<TipoGraduatoria> listGraduatoria = tipoGraduatoriaHome.findByExample(tipoGraduatoria);
			if(listGraduatoria.size()>1){
				
				return true;
			}
		} catch (GestioneErroriException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
		
	}

}