package com.accenture.CCFarm.action;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.CandidaturaReg;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.GraduatoriaStorico;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.DAO.UtenteCandidaturaRegStorico;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.Domanda;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.LogUtil;

public class DomandaAction
{
	private CandidaturaRegHome candidaturaHome;
	private CandidaturaReg candidatura;
	private GraduatoriaHome graduatoriaHome;
	private Graduatoria graduatoria;
	private Logger logger = CommonLogger.getLogger("DomandaAction");
	public DomandaAction()
	{
		candidaturaHome=new CandidaturaRegHome();
		
	}
	
	public CandidaturaReg trovaCandidaturaUtente(String idUtente) throws Exception
	{
		try
		{
			candidatura=candidaturaHome.findById(idUtente);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new Exception("[Impossibile determinare tipologia utente]");
		}
		return candidatura;
	}
	
	public void ricalcolaGraduatoria(String idCandidatura,Graduatoria vecchio, String idUserLoggato) throws GestioneErroriException{
		
		GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
		Graduatoria nuovo = new Graduatoria();
		List<Graduatoria> graduatoriaListExAequoRisolti = new ArrayList<Graduatoria>();
		Graduatoria graduatoriaExAequoRisolti = new Graduatoria();
		List<Graduatoria> exEaequoRisoliToDelete;
		List<Graduatoria> exEaequoRisoltiToResolved;
		graduatoriaExAequoRisolti.setExAequo("T");
		graduatoriaListExAequoRisolti = graduatoriaHome.findByExample(graduatoriaExAequoRisolti);
		try {
			java.util.Date dataSys= new java.util.Date();
			java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
			nuovo = graduatoriaHome.findById(idCandidatura);
			exEaequoRisoliToDelete = new ArrayList<Graduatoria>();
			exEaequoRisoltiToResolved= new ArrayList<Graduatoria>();
			
			//controllare che il vecchio punteggio era in exequo con un altro record quindi togliere l'exequita con il vecchio 
			for(Graduatoria g :graduatoriaListExAequoRisolti){
				if(!vecchio.getIdCandidatura().equalsIgnoreCase(g.getIdCandidatura())){
					
				}
				if(!vecchio.getIdCandidatura().equalsIgnoreCase(g.getIdCandidatura()) && vecchio.getPunteggio().compareTo(nuovo.getPunteggio())!=0 && (vecchio.getPunteggio().compareTo(g.getPunteggio())==0 || vecchio.getEtaMedia().compareTo(g.getEtaMedia())==0 )){
					//aggiungo alla lista d'appoggio
					
				if(!vecchio.getIdCandidatura().equalsIgnoreCase(g.getIdCandidatura()) && vecchio.getPunteggio().compareTo(nuovo.getPunteggio())!=0 && vecchio.getPunteggio().compareTo(g.getPunteggio())==0 && vecchio.getEtaMedia().compareTo(g.getEtaMedia())==0){
					//aggiungo alla lista d'appoggio
					 exEaequoRisoltiToResolved.add(g);
					
					
					
				}else if(vecchio.getPunteggio().compareTo(g.getPunteggio())==0){
					exEaequoRisoliToDelete.add(g);
				}
				}
			}
			
			String sIdStor = "";
			if(exEaequoRisoliToDelete.size()>0 || exEaequoRisoltiToResolved.size()>0)
				sIdStor = graduatoriaHome.getSequenceIdStorico();
				
			if(exEaequoRisoliToDelete.size()>0){
				if(exEaequoRisoliToDelete.size()<=1){
					exEaequoRisoliToDelete.get(0).setExAequo(null);
					exEaequoRisoliToDelete.get(0).setExAequoRisolto(null);
					exEaequoRisoliToDelete.get(0).setColor(null);
					
					//STORICO
					GraduatoriaStorico graduatoriaStr = new GraduatoriaStorico();
					PropertyUtils.copyProperties(graduatoriaStr, exEaequoRisoliToDelete.get(0));
					graduatoriaStr.setIdStorico(sIdStor);
					graduatoriaStr.setMiUtente(idUserLoggato);
					graduatoriaStr.setDataUltimaModifica(oggi);
					graduatoriaHome.saveOrUpdate(exEaequoRisoliToDelete.get(0), graduatoriaStr);
				}
					
				
			}
			
			if(exEaequoRisoltiToResolved.size()>0){
				if(exEaequoRisoltiToResolved.size()<=1){
					exEaequoRisoltiToResolved.get(0).setExAequo(null);
					exEaequoRisoltiToResolved.get(0).setExAequoRisolto(null);
					exEaequoRisoltiToResolved.get(0).setColor(null);
					
					//STORICO
					GraduatoriaStorico graduatoriaStrRes = new GraduatoriaStorico();
					PropertyUtils.copyProperties(graduatoriaStrRes, exEaequoRisoltiToResolved.get(0));
					graduatoriaStrRes.setIdStorico(sIdStor);
					graduatoriaStrRes.setMiUtente(idUserLoggato);
					graduatoriaStrRes.setDataUltimaModifica(oggi);
					graduatoriaHome.saveOrUpdate(exEaequoRisoltiToResolved.get(0), graduatoriaStrRes);
				}
					
				
			}
			exEaequoRisoliToDelete = new ArrayList<Graduatoria>();
			exEaequoRisoltiToResolved= new ArrayList<Graduatoria>();
			// controllare che il nuovo sta in exequo con un altro o altri che gia sono exequi quinid rielaborare gli exequi
			for(Graduatoria g :graduatoriaListExAequoRisolti){
				if(!vecchio.getIdCandidatura().equalsIgnoreCase(g.getIdCandidatura()) && vecchio.getPunteggio().compareTo(nuovo.getPunteggio())!=0 && (nuovo.getPunteggio().compareTo(g.getPunteggio())==0 || nuovo.getEtaMedia().compareTo(g.getEtaMedia())==0 )){
					//aggiungo alla lista d'appoggio
					
				if(!vecchio.getIdCandidatura().equalsIgnoreCase(g.getIdCandidatura()) && vecchio.getPunteggio().compareTo(nuovo.getPunteggio())!=0 && nuovo.getPunteggio().compareTo(g.getPunteggio())==0 && nuovo.getEtaMedia().compareTo(g.getEtaMedia())==0){
					//aggiungo alla lista d'appoggio
					
					 exEaequoRisoltiToResolved.add(g);
					
					
					
				}else if(vecchio.getPunteggio().compareTo(g.getPunteggio())==0){
					exEaequoRisoliToDelete.add(g);
				}
				}
			}
			if(vecchio.getExAequo()==null && exEaequoRisoliToDelete.size()>0){
				for(Graduatoria g :exEaequoRisoliToDelete){
					 g.setExAequo(null);
					 g.setExAequoRisolto(null);
					 g.setColor(null);
					 
					 //STORICO
					 GraduatoriaStorico gStr = new GraduatoriaStorico();
					 PropertyUtils.copyProperties(gStr, exEaequoRisoltiToResolved.get(0));
					 String sIdStorico = graduatoriaHome.getSequenceIdStorico();
					 gStr.setIdStorico(sIdStorico);
					 gStr.setMiUtente(idUserLoggato);
					 gStr.setDataUltimaModifica(oggi);
					 graduatoriaHome.saveOrUpdate(g, gStr);
				}
				
			}
			
			if(vecchio.getExAequo()==null && exEaequoRisoltiToResolved.size()>0){
				for(Graduatoria g :exEaequoRisoltiToResolved){
					 g.setExAequo(null);
					 g.setExAequoRisolto(null);
					 g.setColor(null);
					 
					//STORICO
					 GraduatoriaStorico gStr = new GraduatoriaStorico();
					 PropertyUtils.copyProperties(gStr, exEaequoRisoltiToResolved.get(0));
					 String sIdStorico = graduatoriaHome.getSequenceIdStorico();
					 gStr.setIdStorico(sIdStorico);
					 gStr.setMiUtente(idUserLoggato);
					 gStr.setDataUltimaModifica(oggi);
					 graduatoriaHome.saveOrUpdate(g, gStr);
				}
				
			}
			
			

			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("errore nel calcolo della graduatoria: " + LogUtil.printException(e));
			throw new GestioneErroriException("errore nel calcolo della graduatoria"+LogUtil.printException(e));
		}
		
	}
	
	public boolean escludiDomanda(Domanda domanda)throws GestioneErroriException{
		
			boolean result = true;
		
			graduatoriaHome = new GraduatoriaHome();
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			//escludi dalla graduatori(eliminazione totale della candidatura da graduatoria)
			List<CandidaturaReg> candidaturaRegList = new ArrayList<CandidaturaReg>();
			CandidaturaReg candidato = new CandidaturaReg();
			candidato.setIdCandidatura(candidatura.getIdCandidatura());
			graduatoria = graduatoriaHome.findById(domanda.getCandidaturaReg().getIdCandidatura());
			if(graduatoria!=null){
			
				graduatoriaHome.delete(graduatoria);
				//update su candidaturareg del flag di ammissione
				//candidatura.setIdCandidatura(domanda.getCandidaturaReg().getIdCandidatura());
				candidaturaRegList=candidaturaHome.findByExample(candidato);
				for(CandidaturaReg cand:candidaturaRegList){
					cand.setAmmesso("NO");
					candidaturaHome.saveOrUpdate(cand);
				}
				
				//disabilita terzo tab di elabora graduatoria
				DatiBando datiBando = datiBandoHome.findById(candidatura.getCodiceRegione());
				
				datiBando.setFlgAbilitaGrad("false");
				datiBandoHome.saveOrUpdate(datiBando);
				}
			else{
				result = false;
			}
			
			return result;
		
	}
	
	public boolean isFaseInterpelloAttiva(String codReg) throws GestioneErroriException{

		boolean bRet = false;
	    InterpelloHome interpelloHome = new  InterpelloHome();
	    Interpello interpello = interpelloHome.determinaInterpelloCorrentePubblicatoChiuso(codReg);
	    if(interpello!=null) {
			   /* Date dataInizio = (Timestamp)interpello.getDataInizio();
		    Date dataFine = (Timestamp)interpello.getDataFineAccettazione();
		    
		    //se data sistema >= dataInizio e data fine non valorizzata oppure data sistema <= dataFine
		    if((!new Date().before(dataInizio)) && (dataFine==null || (!new Date().after(dataFine))))*/
		    	bRet = true;
	    }
		return bRet;
	}
}
