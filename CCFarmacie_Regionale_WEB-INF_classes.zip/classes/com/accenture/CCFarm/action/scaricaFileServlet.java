package com.accenture.CCFarm.action;



import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.DAO.UtenteReg;
import com.accenture.CCFarm.DAO.UtenteRegHome;
import com.accenture.CCFarm.PDFModulo.ScaricaPDFModuloRicevuta;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;

/**
 * Servlet implementation class CaricoBandoRegione
 */

public class scaricaFileServlet extends HttpServlet {
//	private static final long serialVersionUID = 1L;
	Logger logger = CommonLogger.getLogger("LogInCandidatoServlet");
	private static String tipoRicevuta_Domanda = "DD";
	private static String tipoRicevuta_SceltaSedi = "SS";
	private static String tipoRicevuta_AccettaRinunciaSede = "ARS";
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public scaricaFileServlet() {
        super();
        // 
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// 
		super.init();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


    	try {	
    		String idUtente = (String) request.getParameter("idUtente");
    		String tipoRicevuta = (String) request.getParameter("tipoRicevuta");
    		String descrFile = (tipoRicevuta!=null && tipoRicevuta.equals(tipoRicevuta_Domanda) ? "ricevutaDomanda.pdf" : 
    			(tipoRicevuta!=null && tipoRicevuta.equals(tipoRicevuta_SceltaSedi)) ? "ricevutaSceltaSedi.pdf" : 
    			(tipoRicevuta!=null && tipoRicevuta.equals(tipoRicevuta_AccettaRinunciaSede)) ? "ricevutaAccettazioneRinunciaSede.pdf" : null);
    		
    		
    	    ScaricaPDFModuloRicevuta scaricaPDFModuloRicevuta= new ScaricaPDFModuloRicevuta();
 		    scaricaPDFModuloRicevuta.ristampaRiRcevutaIdUtentePDF(idUtente, tipoRicevuta);
// 		    scaricaPDFModuloRicevuta.downloadFile();
 		  byte[] pdfData = scaricaPDFModuloRicevuta.getImgRicevutaPDF();
 	    	try
 	    	{
// 	            FacesContext facesContext = FacesContext.getCurrentInstance(); 
// 	            ExternalContext externalContext = facesContext.getExternalContext(); 
// 	            HttpServletResponse response = (HttpServletResponse) externalContext.getResponse(); 
// 	            ServletContext servletContext = (ServletContext) externalContext.getContext(); 
 	            response.reset(); 
 	            response.setContentType("application/pdf"); 
 	            response.setContentLength((int) pdfData.length); 
 	            
 	            response.setHeader("Content-disposition", "attachment; filename=\""+descrFile+"\"");
 	            ByteArrayInputStream in = null;             
 	            BufferedInputStream input = null; 
 	            BufferedOutputStream output = null; 
 	            final int buffersize = (int) pdfData.length; 
 	            try 
 	            { 
 	            	in = new ByteArrayInputStream(pdfData);
 	            	input = new BufferedInputStream(in); 
 	            	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
 	            	byte[] buffer = new byte[buffersize]; 
 	            	for (int length; (length = input.read(buffer)) > 0;) 
 	            	{	 
 	            		output.write(buffer, 0, length); 
 	            	}            	
 	            } 
 	            finally 
 	            { 
 	            	if (input != null) 
 	            		try 
 	            		{ 
 	            			input.close(); 
 	            			output.close();
 	            		} 
 	            		catch (IOException e) 
 	            		{ 
 	            			e.printStackTrace(); 
 	            		} 
 	            } 
// 	            facesContext.responseComplete(); 

 	    	}
 	    	catch (Exception e)
 	    	{
 	    		e.printStackTrace();
 	    		throw new GestioneErroriException();
 	    	}
    	
    	} catch (GestioneErroriException e) {
 			logger.error("RicercaCandidati - caricaRicevuta: " + e.getMessage());
// 			JSFUtility.redirect("er);
// 			response.sendRedirect(AppProperties.getAppProperties().getProperty("BaseUrl")+"/jsp/errorPage.jsf");
 			response.sendRedirect(AppProperties.getAppProperties().getProperty("BaseUrl")+"/jsp/errorDownLoadRic.jsf");
 			
 		}
 		
	
    	
	
	
	}


	
	
	
}
