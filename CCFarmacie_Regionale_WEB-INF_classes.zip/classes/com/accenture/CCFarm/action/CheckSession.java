package com.accenture.CCFarm.action;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.RepositorySession;


public class CheckSession implements Filter 
{ 
	Logger logger = CommonLogger.getLogger("CheckSession");
	
	public void destroy() {}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		String pageError = "errorPageGenerica.jsf";
		String pageErrorSession = "errorPageGenericaSession.jsf";
		
		HttpServletRequest req=(HttpServletRequest)request;
		HttpServletResponse resp=(HttpServletResponse)response;
		
		try
		{
			HttpSession session = req.getSession(true);
			String pageRequested = req.getRequestURL().toString();
			
			if(session.getAttribute(RepositorySession.TOKEN_SAML_NSIS) == null && session.getAttribute(RepositorySession.UTENTE_ID_NSIS) == null &&
			 (!pageRequested.contains(pageError) && !pageRequested.contains(pageErrorSession)))
			{
				logger.error("CheckSession - sessione scaduta");
				
				resp.sendRedirect(AppProperties.getAppProperties().getProperty("BaseUrl")+"/jsp/"+pageErrorSession);
			}
			else
				chain.doFilter(request,response);
		}
		catch(Exception e)
		{
			logger.error("CheckSession error: " + e);
			
			resp.sendRedirect(AppProperties.getAppProperties().getProperty("BaseUrl")+"/jsp/"+pageError);
		}
	}

	public void init(FilterConfig arg0) throws ServletException {}

}
