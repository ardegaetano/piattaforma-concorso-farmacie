package com.accenture.CCFarm.action;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.CandidatoSedeAssegnataListBean;
import com.accenture.CCFarm.DAO.CandidaturaSediHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.GestioneAssegnazioni;
import com.accenture.CCFarm.thread.ThreadAssegnazioniAutomatiche;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;

public class GestioneAssegnazioniAction {
	
	private static final Logger logger = CommonLogger.getLogger("GestioneAssegnazioniAction");
	private BigDecimal id_interpello;
	private String codRegione;
	private DatiBandoHome datiBandoHome;
	private InterpelloHome interpelloHome;
	private CandidaturaSediHome candidaturaSediHome;
	private AppProperties paramProperties = AppProperties.getAppProperties();
	private String sVero = paramProperties.getProperty("flag.valore.vero");
	private String sFalso = paramProperties.getProperty("flag.valore.falso");
	
	private static final String codiceAssegnazionePredisposta = AppProperties.getAppProperties().getProperty("codice.accettazione.predisposta");
	private static final String codiceAssegnazionePubblicata = AppProperties.getAppProperties().getProperty("codice.accettazione.pubblicata");
	
	public GestioneAssegnazioniAction() throws GestioneErroriException {
		
		try {
			datiBandoHome = new DatiBandoHome();
			interpelloHome = new InterpelloHome();
			candidaturaSediHome = new CandidaturaSediHome();
		}
		catch(Exception e) {
			logger.error("GestioneAssegnazioniAction - inizializzazione fallita", e);
			throw new GestioneErroriException("GestioneAssegnazioniAction - inizializzazione fallita");
		}
		
	}
	
	public void init(String codiceRegione, GestioneAssegnazioni gestAssegnazioni) throws GestioneErroriException {
		try {
			setCodRegione(codiceRegione);
			Interpello interpello = interpelloHome.determinaInterpelloCorrente(codRegione);
			if(interpello.getStato().equals(AppProperties.getAppProperties().getProperty("codice.interpello.pubblicato"))) {
				setId_interpello(interpello.getId().getIdInterpello());
				gestAssegnazioni.setDescrInterpello(getId_interpello().toString()+"� interpello");
				
				//Abilito Tab 1 - Elabora Assegnazioni se la data di sistema � successiva alla data fine interpello
				if(interpello.getDataFine()!=null &&  new Date().after(DateUtil.utilDateToSqlTimestamp((Timestamp)interpello.getDataFine()))) {
					gestAssegnazioni.setDisabilitaTabElaboraAssegnazioni(sFalso);
					initElaboraAssegnazioni(gestAssegnazioni);
					initAccettazioneSedi(gestAssegnazioni, interpello);
				}
				//Abilito Tab 3 - Gestisci Accettazioni se la data di sistema � successiva alla data fine accettazione
				if(interpello.getDataFineAccettazione()!=null &&  new Date().after(DateUtil.utilDateToSqlTimestamp((Timestamp)interpello.getDataFineAccettazione()))) {
					gestAssegnazioni.setDisabilitaTabElaboraAssegnazioni(sVero);	
					gestAssegnazioni.setDisabilitaTabGestisciAccettazioni(sFalso);
					gestAssegnazioni.setTabDaVisualizzare("2");
				}
					
			}
		}
		catch(Exception e) {
			logger.error("GestioneAssegnazioniAction - init - nessun interpello pubblicato presente", e);
		}
	}
	
	public void initElaboraAssegnazioni(GestioneAssegnazioni gestAssegnazioni) throws GestioneErroriException {
		DatiBando datiBando = datiBandoHome.findById(codRegione);
		
		if (datiBando.getFlagAbbinamentoSedi()== null || (!datiBando.getFlagAbbinamentoSedi().equalsIgnoreCase(paramProperties.getProperty("esito.abbinamento.sedi.terminato")))) {
			gestAssegnazioni.setDisabilitaTabElaboraAssegnazioni(sFalso);
			gestAssegnazioni.setTabDaVisualizzare("0");
		}
		else if (datiBando.getFlagAbbinamentoSedi()!= null && datiBando.getFlagAbbinamentoSedi().equalsIgnoreCase(paramProperties.getProperty("esito.abbinamento.sedi.terminato"))) {
			gestAssegnazioni.setDisabilitaTabConfiguraAccettazione(sFalso);
			gestAssegnazioni.setTabDaVisualizzare("1");
		}
		gestAssegnazioni.setFlagEsitoAbbinamento(datiBando.getFlagAbbinamentoSedi());
	}
	
	public void initAccettazioneSedi(GestioneAssegnazioni gestAssegnazioni, Interpello interpello) throws GestioneErroriException {
		gestAssegnazioni.setDataInizioAccettazione(DateUtil.sqlTimestampToUtilDate((java.sql.Timestamp) interpello.getDataInizioAccettazione()));
		gestAssegnazioni.setDataFineAccettazione(DateUtil.sqlTimestampToUtilDate((java.sql.Timestamp) interpello.getDataFineAccettazione()));
	}
	
	//Esecuzione Thread di Abbinamento automatico
	public void avviaProcessoAssegnazione(String codRegione) throws GestioneErroriException {
		
		Thread processoAssegnazione = new Thread(new ThreadAssegnazioniAutomatiche(codRegione));
		
		Thread.UncaughtExceptionHandler h = new Thread.UncaughtExceptionHandler() {
			//INTERCETTA LE ECCEZIONI DEL THREAD
			@Override
		    public void uncaughtException(Thread th, Throwable ex) {
		        logger.error("Uncaught exception: " + ex);
		    }
		};

		processoAssegnazione.setUncaughtExceptionHandler(h);
		processoAssegnazione.start();
		
	}
	
	public List<CandidatoSedeAssegnataListBean> caricaListaCandidatiSediAbbinate()throws GestioneErroriException {
		
		try {
				List<CandidatoSedeAssegnataListBean> listaSedi = candidaturaSediHome.getListaSediAbbinate(codRegione, id_interpello);
				return listaSedi;
		}
		catch(Exception e) {
			logger.error("GestioneAssegnazioniAction - caricaListaCandidatiSediAbbinate fallita", e);
			throw new GestioneErroriException("GestioneAssegnazioniAction - caricaListaCandidatiSediAbbinate fallita");
		}
	}
	
	public String getNumCandidatiConSedeAssegnata() throws GestioneErroriException {
		try {
			return candidaturaSediHome.getNumCandidatiConSedeAssegnata(codRegione, id_interpello);
		}
		catch(Exception e) {
			logger.error("GestioneAssegnazioniAction - getNumCandidatiConSedeAssegnata fallita", e);
			throw new GestioneErroriException("GestioneAssegnazioniAction - getNumCandidatiConSedeAssegnata fallita");
		}
	}
	
	public String getNumCandidatiSenzaSedeAssegnata() throws GestioneErroriException {
		try {
			return candidaturaSediHome.getNumCandidatiSenzaSedeAssegnata(codRegione, id_interpello);
		}
		catch(Exception e) {
			logger.error("GestioneAssegnazioniAction - getNumCandidatiSenzaSedeAssegnata fallita", e);
			throw new GestioneErroriException("GestioneAssegnazioniAction - getNumCandidatiSenzaSedeAssegnata fallita");
		}
	}
	
	//salvataggio dati accettazione interpello
	public void salvaAccettazione(Date dataInizioAccettazione, Date dataFineAccettazione) throws GestioneErroriException {
		
		try {
			//aggiornamento dati interpello
			Interpello interpello = interpelloHome.determinaInterpelloCorrente(codRegione);
			interpello.setDataInizioAccettazione(DateUtil.utilDateToSqlTimestamp(dataInizioAccettazione));
			interpello.setDataFineAccettazione(DateUtil.utilDateToSqlTimestamp(dataFineAccettazione));
			interpello.setStatoAccettazione(codiceAssegnazionePredisposta);
			
			//inserimento interpello su DB
			interpelloHome.salvaInterpello(interpello);
		}
		catch(Exception e) {
			
			logger.error("GestioneAssegnazioniAction - salvataggio accettazione fallito", e);
			throw new GestioneErroriException("GestioneAssegnazioniAction - salvataggio accettazione fallito");
		}
	}
	
	//salvataggio dati accettazione interpello
	public void pubblicaAccettazione(Date dataInizioAccettazione, Date dataFineAccettazione) throws GestioneErroriException {
		
		try {
			//aggiornamento dati interpello
			Interpello interpello = interpelloHome.determinaInterpelloCorrente(codRegione);
			interpello.setDataInizioAccettazione(DateUtil.utilDateToSqlTimestamp(dataInizioAccettazione));
			interpello.setDataFineAccettazione(DateUtil.utilDateToSqlTimestamp(dataFineAccettazione));
			
			DatiBando datiBando = datiBandoHome.findById(codRegione);
			interpelloHome.pubblicaAccettazione(interpello, datiBando);
		}
		catch(Exception e) {
			
			logger.error("GestioneAssegnazioniAction - pubblicazione accettazione fallito", e);
			throw new GestioneErroriException("GestioneAssegnazioniAction - pubblicazione accettazione fallito");
		}
	}
	
	public boolean isAccettazionePubblicata() throws GestioneErroriException {
		Interpello interpello = interpelloHome.determinaInterpelloCorrente(codRegione);
		return (interpello != null && 
				interpello.getStatoAccettazione() != null &&
				interpello.getStatoAccettazione().equalsIgnoreCase(codiceAssegnazionePubblicata));
	}
	
	public List<CandidatoSedeAssegnataListBean> caricaListaCandidatiSediAccettate()throws GestioneErroriException {
		
		try {
				List<CandidatoSedeAssegnataListBean> listaSedi = candidaturaSediHome.getListaSediAccettate(codRegione, id_interpello);
				return listaSedi;
		}
		catch(Exception e) {
			logger.error("GestioneAssegnazioniAction - caricaListaCandidatiSediAccettate fallita", e);
			throw new GestioneErroriException("GestioneAssegnazioniAction - caricaListaCandidatiSediAccettate fallita");
		}
	}
	
	public String getNumCandidatiConSedeAccettata() throws GestioneErroriException {
		try {
			return candidaturaSediHome.getNumCandidatiConSedeAccettata(codRegione, id_interpello);
		}
		catch(Exception e) {
			logger.error("GestioneAssegnazioniAction - getNumCandidatiConSedeAccettata fallita", e);
			throw new GestioneErroriException("GestioneAssegnazioniAction - getNumCandidatiConSedeAccettata fallita");
		}
	}
	
	public String getNumCandidatiSenzaSede() throws GestioneErroriException {
		try {
			return candidaturaSediHome.getNumCandidatiSenzaSede(codRegione, id_interpello);
		}
		catch(Exception e) {
			logger.error("GestioneAssegnazioniAction - getNumCandidatiSenzaSede fallita", e);
			throw new GestioneErroriException("GestioneAssegnazioniAction - getNumCandidatiSenzaSede fallita");
		}
	}
	
	//chiusura interpello - imposta dataFine interpello e resetta flag datiBando (flagInvioInviti, flagAbbinamentoSedi)
	public void chiudiInterpello() throws GestioneErroriException {
		
		try {
			Interpello interpello = interpelloHome.determinaInterpelloCorrente(codRegione);
			DatiBando datiBando = datiBandoHome.findById(codRegione);
			interpelloHome.chiudiInterpello(interpello, datiBando);
		}
		catch(Exception e) {
			
			logger.error("GestioneAssegnazioniAction - chiusura interpello fallito", e);
			throw new GestioneErroriException("GestioneAssegnazioniAction - chiusura interpello fallito");
		}
	}

	public BigDecimal getId_interpello() {
		return id_interpello;
	}

	public void setId_interpello(BigDecimal id_interpello) {
		this.id_interpello = id_interpello;
	}

	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}
	
}