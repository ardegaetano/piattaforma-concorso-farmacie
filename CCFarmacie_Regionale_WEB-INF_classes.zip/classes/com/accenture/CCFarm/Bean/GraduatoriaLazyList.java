package com.accenture.CCFarm.Bean;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.RisolviExAequo;
import com.accenture.CCFarm.utility.UtenteRegioni;


public class GraduatoriaLazyList extends LazyDataModel<Graduatoria>{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private GraduatoriaHome graduatoriaHome;
	

	
	private List<Graduatoria> graduatoriaListPrec;
	
	private List<Graduatoria> graduatoriaListSucc;
	
	private List<Graduatoria> graduatoriaListCurr;

	
	private List<Graduatoria> graduatoriaList = null;
	
	private RisolviExAequo r = new RisolviExAequo();
	
	
	
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
    UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	String codReg = utenteReg.getCodRegione();
	
	@Override
	public List<Graduatoria> load(int startPage, int maxPerPage, String sortField,	SortOrder siDx, Map<String, String> filters) {
		// TODO Auto-generated method stub
		int posizione = 0;
		int j=1;
		
		try{
			
			
			graduatoriaHome = new GraduatoriaHome();
			
			graduatoriaList = new ArrayList<Graduatoria>();
			
			graduatoriaListCurr = new ArrayList<Graduatoria>();
			
			graduatoriaListPrec = new ArrayList<Graduatoria>();
			
			graduatoriaListSucc = new ArrayList<Graduatoria>();
			
			graduatoriaListCurr = graduatoriaHome.findLazyListGraduatoria(codReg,startPage, maxPerPage);
			
			if(startPage!=0){
				graduatoriaListPrec = graduatoriaHome.findLazyListGraduatoria(codReg,startPage-maxPerPage, maxPerPage);
			}
			if(startPage!=maxPerPage){
				graduatoriaListSucc = graduatoriaHome.findLazyListGraduatoria(codReg,startPage+maxPerPage, maxPerPage);
			}
				
			
			
			
			
		
			
			
			graduatoriaList.addAll(graduatoriaListPrec == null? new ArrayList<Graduatoria>():graduatoriaListPrec);

			graduatoriaList.addAll(graduatoriaListCurr);
			graduatoriaList.addAll(graduatoriaListSucc == null ? new ArrayList<Graduatoria>():graduatoriaListSucc);
			r.risolviexAequoSuGraduatoria(graduatoriaList);
			if(startPage!=0 && (graduatoriaList.get(graduatoriaListPrec.size()-1).getExAequoRisolto()!=null && graduatoriaList.get(graduatoriaListPrec.size()-1).getExAequoRisolto().equals("F"))){
				
				int z = 0;
				int k= graduatoriaListPrec.size()-1;
				do{
					j=startPage-z;
					z++;
					k--;
				}while(k>0&&graduatoriaList.get(k).getExAequo()!=null && graduatoriaList.get(k).getExAequo().equals("T"));
				
			}
			if(startPage!=0 && graduatoriaList.get(graduatoriaListPrec.size()-1).getExAequo()==null){
				j=startPage+1;				
			}
			posizione = startPage;
			for (int i = 0; i < graduatoriaListCurr.size() - 1; i++) {
				posizione++;
				Graduatoria primoUtente = graduatoriaListCurr.get(i);
				Graduatoria secondoUtente = graduatoriaListCurr.get(i+1);
				//primoUtente.setPosizione(posizione);
				//secondoUtente.setPosizione(posizione+1);
				//primoUtente.setIndiceTotale(new BigDecimal(posizione));
				//secondoUtente.setIndiceTotale(new BigDecimal(posizione+1));
			
			if(!(primoUtente.getColor()!=null && primoUtente.getColor().equalsIgnoreCase("blue") || secondoUtente.getColor()!=null && secondoUtente.getColor().equalsIgnoreCase("blue"))){
				if (primoUtente.getPunteggio().compareTo(secondoUtente.getPunteggio()) == 0) {
					if(!(primoUtente.getExAequoRisolto()!=null && primoUtente.getExAequoRisolto().equalsIgnoreCase("F")) ){
			/*			secondoUtente.setExAequo("T");
						secondoUtente.setExAequoRisolto("T");
						secondoUtente.setColor("green");
						
					}else{*/
		
						primoUtente.setPosizione(posizione);
						secondoUtente.setPosizione(posizione+1);
					
						j = posizione+1;
					}
					
					
					
					if (primoUtente.getEtaMedia().compareTo(secondoUtente.getEtaMedia()) == 0) {
						
						primoUtente.setPosizione(j);
						secondoUtente.setPosizione(j);
						
			/*			if((primoUtente.getRettifica()!=null && primoUtente.getRettifica().equalsIgnoreCase("true")) || (secondoUtente.getRettifica()!=null && secondoUtente.getRettifica().equalsIgnoreCase("true"))){
							for(Graduatoria g :graduatoriaListExAequoRisolti){
								if(primoUtente.getRettifica().equalsIgnoreCase("true")){
									if(primoUtente.getPunteggio().compareTo(g.getPunteggio())==0 && primoUtente.getEtaMedia().compareTo(g.getEtaMedia())==0){
										g.setExAequoRisolto("F");
										primoUtente.setRettifica("false");
									}
									
								}else if(secondoUtente.getPunteggio().compareTo(g.getPunteggio())==0 && secondoUtente.getEtaMedia().compareTo(g.getEtaMedia())==0){
										g.setExAequoRisolto("F");
										secondoUtente.setRettifica("false");
									}
								}
							}*/
							
							
						}
					
				}else{
						if(primoUtente.getColor()!=null && primoUtente.getColor().equalsIgnoreCase("red")){
							secondoUtente.setPosizione(posizione+1);
							
							j = posizione+1;
						}else{
							primoUtente.setPosizione(posizione);
							secondoUtente.setPosizione(posizione+1);
							j = posizione+1;
						}
						
					}
				
			}else{
				primoUtente.setPosizione(posizione);
				secondoUtente.setPosizione(posizione+1);
				j = posizione+1;
			}
			
		}
			
			//r.risolviexAequoSuGraduatoria(graduatoriaList);
/*			if(startPage!=0 && (graduatoriaList.get(graduatoriaListPrec.size()-1).getExAequo()!=null && graduatoriaList.get(graduatoriaListPrec.size()-1).getExAequo().equals("T"))){
				
				int i = 0;
				int k= graduatoriaListPrec.size()-1;
				do{
					j=startPage-i;
					i++;
					k--;
				}while(k>0&&graduatoriaList.get(k).getExAequo()!=null && graduatoriaList.get(k).getExAequo().equals("T"));
				
			}
			if(startPage!=0 && graduatoriaList.get(graduatoriaListPrec.size()-1).getExAequo()==null){
				j=startPage+1;				
			}
			posizione = startPage;
			for(Graduatoria graduatoria : graduatoriaListCurr){
				if((graduatoriaListCurr.indexOf(graduatoria)-1)!=-1)
				if(graduatoriaListCurr.get(graduatoriaListCurr.indexOf(graduatoria)-1)!=null&&graduatoria.getPunteggio().compareTo(graduatoriaListCurr.get(graduatoriaListCurr.indexOf(graduatoria)-1).getPunteggio())==0)
				posizione++;
				if(graduatoria.getExAequoRisolto()!=null && !graduatoria.getExAequoRisolto().equals("T") ){
					
					graduatoria.setPosizione(j);
					graduatoria.setIndiceTotale(new BigDecimal(j));
						
				}else if(graduatoria.getExAequoRisolto()!=null && graduatoria.getExAequoRisolto().equals("T") ){
					graduatoria.setPosizione(posizione);
					j = posizione+1;
				}else{
					if(startPage!=0 && (graduatoriaList.get(graduatoriaListPrec.size()-1).getExAequo()!=null && graduatoriaList.get(graduatoriaListPrec.size()-1).getExAequo().equals("T"))){
						
						int i = 0;
						int k= graduatoriaListPrec.size()-1;
						do{
							j=startPage-i;
							i++;
							k--;
						}while(k>0&&graduatoriaList.get(k).getExAequo()!=null && graduatoriaList.get(k).getExAequo().equals("T"));
						
					}
					graduatoria.setPosizione(posizione);
					j = posizione+1;
				}
			}*/
			
						if(getRowCount()<=0){
									setRowCount(graduatoriaHome.searchCount(codReg));
			
						}
			
					setPageSize(maxPerPage);
				}catch(Exception e){
					e.printStackTrace();
				}
		
		
		
		return graduatoriaListCurr;
	}
	
	@Override
	public void setRowIndex(int rowIndex) {
		// TODO Auto-generated method stub
		if(rowIndex == -1 || getPageSize()==0){
			super.setRowIndex(-1);
		}else{
			super.setRowIndex(rowIndex % getPageSize());
		}
		
	}

	@Override
	public Graduatoria getRowData(String rowKey) {
		// TODO Auto-generated method stub
		return super.getRowData(rowKey);
	}

	@Override
	public Object getRowKey(Graduatoria object) {
		// TODO Auto-generated method stub
		return super.getRowKey(object);
	}
		

	
}
