package com.accenture.CCFarm.Bean;

import java.util.List;
import java.util.Map;

import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import com.accenture.CCFarm.DAO.StoricoGraduatoria;
import com.accenture.CCFarm.DAO.StoricoGraduatoriaHome;


public class StoricoGraduatoriaLazyList extends LazyDataModel<StoricoGraduatoria>{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private StoricoGraduatoriaHome storicoGraduatoriaHome;
	
	private StoricoGraduatoria storicoGraduatoria;
	
	private List<StoricoGraduatoria> storicoGraduatoriaListCurr;
	
	private String codReg;

	private int primo;
	
	private int ultimo;
	
	private int totaleSchede;
	
	private String tipoGraduatoria;
	
	private String dataValidazione;
	
	private String dataValidazioneString;
	
	
	
	public StoricoGraduatoriaLazyList(String codReg,int primo,int ultimo,String tipoGraduatoria, int totaleSchede, String dataValidazione) {
		
		// TODO Auto-generated constructor stub
		this.codReg = codReg;
		this.primo = primo;
		this.ultimo = ultimo;
		this.tipoGraduatoria = tipoGraduatoria;
		this.totaleSchede = totaleSchede;
		this.dataValidazione = dataValidazione;
	}


	@Override
	public List<StoricoGraduatoria> load(int startPage, int maxPerPage, String sortField, SortOrder siDx, Map<String, String> filters) {
		// TODO Auto-generated method stub
		int posizione = 0;
		int j = 0;
		try{
			
			storicoGraduatoria = new StoricoGraduatoria();
			
			storicoGraduatoriaHome = new StoricoGraduatoriaHome();			
			
			storicoGraduatoriaListCurr = storicoGraduatoriaHome.findLazyListStoricoGraduatoria(startPage, maxPerPage,codReg, primo, ultimo, tipoGraduatoria ,dataValidazione);
			

			if(getRowCount()<=0){
				
					if (storicoGraduatoriaListCurr.isEmpty()){
						setRowCount(0);
					}
					else {
						
						if (primo>=0 && ultimo>=0 && ultimo >= primo){
							setRowCount(ultimo - primo);
						}
							else {
								setRowCount(totaleSchede);
							}
						
					}
				
					
				}
			
					setPageSize(maxPerPage);
				}catch(Exception e){
					e.printStackTrace();
				}
		
		if (!storicoGraduatoriaListCurr.isEmpty()){
			setDataValidazioneString(storicoGraduatoriaListCurr.get(0).getDataValidazioneString());
		}
			
		
		return storicoGraduatoriaListCurr;
	}
	
	
	@Override
    public void setRowIndex(int rowIndex) {
        
        
        if (rowIndex == -1 || getPageSize() == 0) {
            super.setRowIndex(-1);
        }
        else
            super.setRowIndex(rowIndex % getPageSize());
    }


	public int getPrimo() {
		return primo;
	}


	public void setPrimo(int primo) {
		this.primo = primo;
	}


	public int getUltimo() {
		return ultimo;
	}


	public void setUltimo(int ultimo) {
		this.ultimo = ultimo;
	}


	public String getTipoGraduatoria() {
		return tipoGraduatoria;
	}


	public void setTipoGraduatoria(String tipoGraduatoria) {
		this.tipoGraduatoria = tipoGraduatoria;
	}


	public StoricoGraduatoriaHome getStoricoGraduatoriaHome() {
		return storicoGraduatoriaHome;
	}


	public void setStoricoGraduatoriaHome(
			StoricoGraduatoriaHome storicoGraduatoriaHome) {
		this.storicoGraduatoriaHome = storicoGraduatoriaHome;
	}


	public StoricoGraduatoria getStoricoGraduatoria() {
		return storicoGraduatoria;
	}


	public void setStoricoGraduatoria(StoricoGraduatoria storicoGraduatoria) {
		this.storicoGraduatoria = storicoGraduatoria;
	}


	public List<StoricoGraduatoria> getStoricoGraduatoriaListCurr() {
		return storicoGraduatoriaListCurr;
	}


	public void setStoricoGraduatoriaListCurr(
			List<StoricoGraduatoria> storicoGraduatoriaListCurr) {
		this.storicoGraduatoriaListCurr = storicoGraduatoriaListCurr;
	}


	public String getCodReg() {
		return codReg;
	}


	public void setCodReg(String codReg) {
		this.codReg = codReg;
	}


	public int getTotaleSchede() {
		return totaleSchede;
	}


	public void setTotaleSchede(int totaleSchede) {
		this.totaleSchede = totaleSchede;
	}


	public String getDataValidazione() {
		return dataValidazione;
	}


	public void setDataValidazione(String dataValidazione) {
		this.dataValidazione = dataValidazione;
	}


	public String getDataValidazioneString() {
		return dataValidazioneString;
	}


	public void setDataValidazioneString(String dataValidazioneString) {
		this.dataValidazioneString = dataValidazioneString;
	}
	

}
