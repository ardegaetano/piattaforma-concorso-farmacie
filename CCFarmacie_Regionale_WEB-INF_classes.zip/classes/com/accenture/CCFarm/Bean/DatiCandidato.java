package com.accenture.CCFarm.Bean;

public class DatiCandidato {

	String idCandidato;
	String nome;
	String cognome;
	String codiceFiscale;
	String numeroProtocollo;
	String escluso;
	String codRegione;
	String motivoRinuncia;
	
	public String getIdCandidato() {
		return idCandidato;
	}
	public void setIdCandidato(String idCandidato) {
		this.idCandidato = idCandidato;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getCodiceFiscale() {
		return codiceFiscale;
	}
	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}
	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}
	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}
	public String getEscluso() {
		return escluso;
	}
	public void setEscluso(String escluso) {
		this.escluso = escluso;
	}
	public String getCodRegione() {
		return codRegione;
	}
	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}
	public String getMotivoRinuncia() {
		return motivoRinuncia;
	}
	public void setMotivoRinuncia(String motivoRinuncia) {
		this.motivoRinuncia = motivoRinuncia;
	}
	
}
