package com.accenture.CCFarm.Bean;

public class RicevutaBean{

	private String idCandidato;
	private String idRicevuta;
	private String descrizione;
	private String tipoRicevuta;
	
	public String getIdCandidato() {
		return idCandidato;
	}

	public void setIdCandidato(String idCandidato) {
		this.idCandidato = idCandidato;
	}

	public String getDescrizione() {
		return descrizione;
	}
	
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public String getIdRicevuta() {
		return idRicevuta;
	}

	public void setIdRicevuta(String idRicevuta) {
		this.idRicevuta = idRicevuta;
	}

	public String getTipoRicevuta() {
		return tipoRicevuta;
	}

	public void setTipoRicevuta(String tipoRicevuta) {
		this.tipoRicevuta = tipoRicevuta;
	}
	

}