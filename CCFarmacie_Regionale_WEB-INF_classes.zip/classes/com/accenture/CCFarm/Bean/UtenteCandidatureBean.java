package com.accenture.CCFarm.Bean;

import java.util.List;

import com.accenture.CCFarm.utility.StringUtil;

public class UtenteCandidatureBean{

	//anagrafica utente associato
	private String nomeUtente;
	private String cognomeUtente;
	private String sesso;
	private String codiceFiscaleUtente;
	private String pecMail;
	private java.util.Date dataNascita;
	private String luogoNascitaUtente;
	private String provinciaNascitaUtente;
	private String luogoNascitaEsteraUtente;
	private String nazioneNascitaUtente;
	private String prvNascitaUtente;
	private String documentazionePrevista;
	private String documentazionePervenuta;
	private String richiestaCambioPEC;
	private String dataNascitaString;
	private String idUtente;
	private String idCandidatura;
	private List<UtenteBean> listaAssociati;
	private String associata="false";
	private String protocolloRicevuta="";
	private String scaricaRicevuta="";
	
	private String tipoCandidato;
	private String  ammessoValore="";
	private boolean ammesso;
	
	
	
	//estremi documento
	private String tipoDocumento;
	private String numeroDoc;
	private String enteRilascioDoc;
	private java.util.Date dataRilascioDoc;
	
	private String regioneRichiesta;
	
	public String getNomeUtente() {
		return nomeUtente;
	}
	
	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}
	
	public String getCognomeUtente() {
		return cognomeUtente;
	}
	
	public void setCognomeUtente(String cognomeUtente) {
		this.cognomeUtente = cognomeUtente;
	}
	
	public String getSesso() {
		return sesso;
	}
	
	public void setSesso(String sesso) {
		this.sesso = sesso;
	}
	
	public String getCodiceFiscaleUtente() {
		return codiceFiscaleUtente;
	}
	
	public void setCodiceFiscaleUtente(String codiceFiscaleUtente) {
		this.codiceFiscaleUtente = codiceFiscaleUtente;
	}
	
	public String getPecMail() {
		return pecMail;
	}
	
	public void setPecMail(String pecMail) {
		this.pecMail = pecMail;
	}
	
	public java.util.Date getDataNascita() {
		
		return dataNascita;
	}
	
	public void setDataNascita(java.util.Date dataNascita) {
		if(dataNascita!=null && !dataNascita.equals("")){
			dataNascitaString = StringUtil.dateToStringDDMMYYYY(dataNascita);
			}
			this.dataNascita = dataNascita;
		
	}
	
	public String getLuogoNascitaUtente() {
		return luogoNascitaUtente;
	}
	
	public void setLuogoNascitaUtente(String luogoNascitaUtente) {
		this.luogoNascitaUtente = luogoNascitaUtente;
	}
	
	public String getLuogoNascitaEsteraUtente() {
		return luogoNascitaEsteraUtente;
	}
	
	public void setLuogoNascitaEsteraUtente(String luogoNascitaEsteraUtente) {
		this.luogoNascitaEsteraUtente = luogoNascitaEsteraUtente;
	}
	
	public String getNazioneNascitaUtente() {
		return nazioneNascitaUtente;
	}
	
	public void setNazioneNascitaUtente(String nazioneNascitaUtente) {
		this.nazioneNascitaUtente = nazioneNascitaUtente;
	}
	
	public String getPrvNascitaUtente() {
		return prvNascitaUtente;
	}
	
	public void setPrvNascitaUtente(String prvNascitaUtente) {
		this.prvNascitaUtente = prvNascitaUtente;
	}
	
	public String getDataNascitaString() {
		return dataNascitaString;
	}
	
	public void setDataNascitaString(String dataNascitaString) {
		this.dataNascitaString = dataNascitaString;
	}
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	public String getNumeroDoc() {
		return numeroDoc;
	}
	
	public void setNumeroDoc(String numeroDoc) {
		this.numeroDoc = numeroDoc;
	}
	
	public String getEnteRilascioDoc() {
		return enteRilascioDoc;
	}
	
	public void setEnteRilascioDoc(String enteRilascioDoc) {
		this.enteRilascioDoc = enteRilascioDoc;
	}
	
	public java.util.Date getDataRilascioDoc() {
		return dataRilascioDoc;
	}
	
	public void setDataRilascioDoc(java.util.Date dataRilascioDoc) {
		this.dataRilascioDoc = dataRilascioDoc;
	}
	
	public String getRegioneRichiesta() {
		return regioneRichiesta;
	}
	
	public void setRegioneRichiesta(String regioneRichiesta) {
		this.regioneRichiesta = regioneRichiesta;
	}
	
	public String getIdUtente() {
		return idUtente;
	}
	
	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}
	
	public String getProvinciaNascitaUtente() {
		return provinciaNascitaUtente;
	}
	
	public void setProvinciaNascitaUtente(String provinciaNascitaUtente) {
		this.provinciaNascitaUtente = provinciaNascitaUtente;
	}
	
	public List<UtenteBean> getListaAssociati() {
		return listaAssociati;
	}
	
	public void setListaAssociati(List<UtenteBean> listaAssociati) {
		this.listaAssociati = listaAssociati;
	}
	
	public String getAssociata() {
		return associata;
	}
	
	public void setAssociata(String associata) {
		this.associata = associata;
	}
	
	public String getProtocolloRicevuta() {
		return protocolloRicevuta;
	}
	
	public void setProtocolloRicevuta(String protocolloRicevuta) {
		this.protocolloRicevuta = protocolloRicevuta;
	}
	
	public String getTipoCandidato() {
		return tipoCandidato;
	}
	
	public void setTipoCandidato(String tipoCandidato) {
		this.tipoCandidato = tipoCandidato;
	}
	
	public String getIdCandidatura() {
		return idCandidatura;
	}
	
	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}
	
	public String getAmmessoValore() {
		return ammessoValore;
	}
	
	public void setAmmessoValore(String ammessoValore) {
		this.ammessoValore = ammessoValore;
	}
	
	public boolean isAmmesso() {
		return ammesso;
	}
	
	public void setAmmesso(boolean ammesso) {
		this.ammesso = ammesso;
	}
	
	public String getScaricaRicevuta() {
		return scaricaRicevuta;
	}
	
	public void setScaricaRicevuta(String scaricaRicevuta) {
		this.scaricaRicevuta = scaricaRicevuta;
	}
	
	public String getDocumentazionePrevista() {
		return documentazionePrevista;
	}
	
	public void setDocumentazionePrevista(String documentazionePrevista) {
		this.documentazionePrevista = documentazionePrevista;
	}
	
	public String getDocumentazionePervenuta() {
		return documentazionePervenuta;
	}
	
	public void setDocumentazionePervenuta(String documentazionePervenuta) {
		this.documentazionePervenuta = documentazionePervenuta;
	}
	
	public String getRichiestaCambioPEC() {
		return richiestaCambioPEC;
	}
	
	public void setRichiestaCambioPEC(String richiestaCambioPEC) {
		this.richiestaCambioPEC = richiestaCambioPEC;
	}


}

