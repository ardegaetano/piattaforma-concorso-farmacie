package com.accenture.CCFarm.Bean;

import java.util.Date;

public class AltraLaureaBis {
	
	private String idSecondaLaureaBis;
	private String idAltraLaureaBis;
	private String descUniSecondaLaureaBis;
	private String luogoSecondaLaureaBis;
	private Date dataSecondaLaureaBis;
	private String dataSecondaLaureaBisStringa;
	private String nazioneSecondaLaureaBis;
	private String flagEsteroSecondaLaureaBis;
	

	public String getDescUniSecondaLaureaBis() {
		return descUniSecondaLaureaBis;
	}
	public String getIdAltraLaureaBis() {
		return idAltraLaureaBis;
	}
	public String getIdSecondaLaureaBis() {
		return idSecondaLaureaBis;
	}
	public void setIdSecondaLaureaBis(String idSecondaLaureaBis) {
		this.idSecondaLaureaBis = idSecondaLaureaBis;
	}
	public void setIdAltraLaureaBis(String idAltraLaureaBis) {
		this.idAltraLaureaBis = idAltraLaureaBis;
	}
	public void setDescUniSecondaLaureaBis(String descUniSecondaLaureaBis) {
		this.descUniSecondaLaureaBis = descUniSecondaLaureaBis;
	}
	public String getLuogoSecondaLaureaBis() {
		return luogoSecondaLaureaBis;
	}
	public void setLuogoSecondaLaureaBis(String luogoSecondaLaureaBis) {
		this.luogoSecondaLaureaBis = luogoSecondaLaureaBis;
	}
	public Date getDataSecondaLaureaBis() {
		return dataSecondaLaureaBis;
	}
	public void setDataSecondaLaureaBis(Date dataSecondaLaureaBis) {
		this.dataSecondaLaureaBis = dataSecondaLaureaBis;
	}
	public String getNazioneSecondaLaureaBis() {
		return nazioneSecondaLaureaBis;
	}
	public void setNazioneSecondaLaureaBis(String nazioneSecondaLaureaBis) {
		this.nazioneSecondaLaureaBis = nazioneSecondaLaureaBis;
	}
	public String getFlagEsteroSecondaLaureaBis() {
		return flagEsteroSecondaLaureaBis;
	}
	public void setFlagEsteroSecondaLaureaBis(String flagEsteroSecondaLaureaBis) {
		this.flagEsteroSecondaLaureaBis = flagEsteroSecondaLaureaBis;
	}
	public String getDataSecondaLaureaBisStringa() {
		return dataSecondaLaureaBisStringa;
	}
	public void setDataSecondaLaureaBisStringa(String dataSecondaLaureaBisStringa) {
		this.dataSecondaLaureaBisStringa = dataSecondaLaureaBisStringa;
	}
	
	
}
