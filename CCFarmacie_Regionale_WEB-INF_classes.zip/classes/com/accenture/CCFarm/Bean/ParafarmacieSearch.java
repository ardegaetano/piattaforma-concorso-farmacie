package com.accenture.CCFarm.Bean;


@SuppressWarnings("serial")
public class ParafarmacieSearch implements java.io.Serializable {

	private String codSlo; //codice sito logistico
	private String desSlo;  // descr slo
	private String desInd;  //indirizzo
	private String codCap;  //cap
	private String codCmn;  // comune
	private String codProvincia;
	private String codRegione;
	private String codPva;  //partoita uiva
    private String desComune;
    private String desProvincia;
    private String desRegione;
	
	
	public String getCodSlo() {
		return codSlo;
	}
	public void setCodSlo(String codSlo) {
		this.codSlo = codSlo;
	}
	public String getDesSlo() {
		return desSlo;
	}
	public void setDesSlo(String desSlo) {
		this.desSlo = desSlo;
	}
	public String getDesInd() {
		return desInd;
	}
	public void setDesInd(String desInd) {
		this.desInd = desInd;
	}
	public String getCodCap() {
		return codCap;
	}
	public void setCodCap(String codCap) {
		this.codCap = codCap;
	}
	public String getCodCmn() {
		return codCmn;
	}
	public void setCodCmn(String codCmn) {
		this.codCmn = codCmn;
	}
	public String getCodPva() {
		return codPva;
	}
	public void setCodPva(String codPva) {
		this.codPva = codPva;
	}
	public String getDesComune() {
		return desComune;
	}
	public void setDesComune(String desComune) {
		this.desComune = desComune;
	}
	public String getDesProvincia() {
		return desProvincia;
	}
	public void setDesProvincia(String desProvincia) {
		this.desProvincia = desProvincia;
	}
	public String getDesRegione() {
		return desRegione;
	}
	public void setDesRegione(String desRegione) {
		this.desRegione = desRegione;
	}
	public String getCodProvincia() {
		return codProvincia;
	}
	public void setCodProvincia(String codProvincia) {
		this.codProvincia = codProvincia;
	}
	public String getCodRegione() {
		return codRegione;
	}
	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}
	
	
	
	
}