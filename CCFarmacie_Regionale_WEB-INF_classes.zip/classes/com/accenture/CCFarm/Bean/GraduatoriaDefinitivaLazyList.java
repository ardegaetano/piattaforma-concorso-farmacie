package com.accenture.CCFarm.Bean;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.PropertyUtils;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaDefinitiva;
import com.accenture.CCFarm.DAO.GraduatoriaDefinitivaHome;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.RisolviExAequo;
import com.accenture.CCFarm.utility.UtenteRegioni;


public class GraduatoriaDefinitivaLazyList extends LazyDataModel<GraduatoriaDefinitivaListBean>{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private GraduatoriaDefinitivaHome graduatoriaDefHome;
	
	private List<GraduatoriaDefinitiva> graduatoriaListTemp;
	
	private List<GraduatoriaDefinitiva> graduatoriaListPrec;
	
	private List<GraduatoriaDefinitiva> graduatoriaListSucc;
	
	private List<GraduatoriaDefinitiva> graduatoriaListCurr;

	private List<GraduatoriaDefinitivaListBean> graduatoriaListCurrView;

	private List<GraduatoriaDefinitiva> graduatoriaList = null;
	
	private List<GraduatoriaDefinitivaListBean> graduatoriaListView = null;
	
	private RisolviExAequo r = new RisolviExAequo();
	
	
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
    UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	String codReg = utenteReg.getCodRegione();

	@Override
	public List<GraduatoriaDefinitivaListBean> load(int startPage, int maxPerPage, String sortField,SortOrder siDx, Map<String, String> filters) {
		// TODO Auto-generated method stub
		int posizione = 0;
		int j = 0;
		try{
			
			
			graduatoriaDefHome = new GraduatoriaDefinitivaHome();
			
			graduatoriaList = new ArrayList<GraduatoriaDefinitiva>();
			
			graduatoriaListTemp = new ArrayList<GraduatoriaDefinitiva>();
			
			graduatoriaListCurrView = new ArrayList<GraduatoriaDefinitivaListBean>();
			
			graduatoriaListView = new ArrayList<GraduatoriaDefinitivaListBean>();

			
			graduatoriaListCurr = graduatoriaDefHome.findLazyListGraduatoriaDefinitiva(codReg,startPage, maxPerPage);
			
			if(startPage!=0){
				graduatoriaListPrec = graduatoriaDefHome.findLazyListGraduatoriaDefinitiva(codReg,startPage-graduatoriaListCurr.size(), maxPerPage);
			}
			
			
			graduatoriaListSucc = graduatoriaDefHome.findLazyListGraduatoriaDefinitiva(codReg,startPage+graduatoriaListCurr.size(), maxPerPage);
			
		
			
			
			graduatoriaList.addAll(graduatoriaListPrec == null? new ArrayList<GraduatoriaDefinitiva>():graduatoriaListPrec);

			graduatoriaList.addAll(graduatoriaListCurr);
			graduatoriaList.addAll(graduatoriaListSucc == null ? new ArrayList<GraduatoriaDefinitiva>():graduatoriaListSucc);
			
			
						
			if(getRowCount()<=0){
						setRowCount(graduatoriaDefHome.searchCount(codReg));

			}
			
			setPageSize(maxPerPage);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		graduatoriaListCurrView = modellaViewDataTable(graduatoriaListCurr);
		graduatoriaListView = null;
		
//		return graduatoriaListCurr;
		return graduatoriaListCurrView;
	}
	
	
	@Override
    public void setRowIndex(int rowIndex) {
        
        
        if (rowIndex == -1 || getPageSize() == 0) {
            super.setRowIndex(-1);
        }
        else
            super.setRowIndex(rowIndex % getPageSize());
    }
	
	
	private List<GraduatoriaDefinitivaListBean> modellaViewDataTable(List<GraduatoriaDefinitiva> listaGraduatoriDef){
		
		String color[];
		int posizione;
		
		List<GraduatoriaDefinitivaListBean> graduatoriaListBean = new ArrayList<GraduatoriaDefinitivaListBean>();
		try {
			
			color = new String[listaGraduatoriDef.size()];
			for(GraduatoriaDefinitiva graduatoriaDef : listaGraduatoriDef){
				
				GraduatoriaDefinitivaListBean definitivaListBean= new GraduatoriaDefinitivaListBean();
				
				
					PropertyUtils.copyProperties(definitivaListBean, graduatoriaDef);
				
				definitivaListBean.setColorRow("white");
				definitivaListBean.setPunteggioString(graduatoriaDef.getPunteggio().toString().replace(".", ","));
				definitivaListBean.setEtaMediaString(graduatoriaDef.getEtaMedia().toString().replace(".", ","));
				
				definitivaListBean.setIndiceView("true");
				definitivaListBean.setIndiceSpinner("false");
				
				posizione = listaGraduatoriDef.indexOf(graduatoriaDef);
				if (graduatoriaDef.getExAequo()!=null &&  graduatoriaDef.getExAequo().equalsIgnoreCase("T")){
	//exAequo da risovere					
					if(graduatoriaDef.getExAequoRisolto()!=null && !graduatoriaDef.getExAequoRisolto().equals("T") ){
						definitivaListBean.setIndiceSave(graduatoriaDef.getIndiceTotale());
						color[posizione]="red";
						definitivaListBean.setColorRow("red");
						definitivaListBean.setIndiceView("false");
						definitivaListBean.setIndiceSpinner("true");
	//					definitivaListBean.setColorRow(".textSmallClassColorRed");
						
					}else {
						if(graduatoriaDef.getExAequoRisolto()!=null && graduatoriaDef.getExAequoRisolto().equals("T") &&
						   graduatoriaDef.getIndiceRelativo().intValue()>0		){
	//exAequo risolto manulamente
							color[posizione]="lime";
							definitivaListBean.setColorRow("lime");
							
						} else{
	//exAequo risolto in valutazione automatica
						color[posizione]="green";
						definitivaListBean.setColorRow("green");
						}
					}	
				}
				
				graduatoriaListBean.add(definitivaListBean);
			}
		
		
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return graduatoriaListBean;
		
	}
	
	

}
