package com.accenture.CCFarm.Bean;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;





//import javax.el.ELContext;
//import javax.el.ExpressionFactory;
//import javax.el.ValueExpression;
import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.component.UIOutput;
import javax.faces.component.html.HtmlInputText;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.column.Column;
import org.primefaces.component.datatable.DataTable;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.StringUtil;

public class CommonDataTable {
	
	 FacesContext fCtx = FacesContext.getCurrentInstance();
	 
	 Application application = fCtx.getApplication();
	     
//	 ELContext elCtx = fCtx.getELContext();
//	
//	 ExpressionFactory ef = fCtx.getApplication().getExpressionFactory();
 
	 DataTable dataTable;
	 
	 List<List<Object>> dynamicList;
	 
	 SimpleDateFormat data;
	 
	 UIComponent tableTitle;
	 
	 private Logger logger = CommonLogger.getLogger("CommonDataTable");
	 
	 public DataTable getTableDetails(Class<?> entity,String id, List<UtenteTitoli> utenteTitoli, String[] campi,String[] nomeColonna,String titoloTabella, Boolean[] rendered,Boolean[] inputText) throws GestioneErroriException{
		 System.out.println("chiamata getTableDetails ");
		 try { 
			 UIOutput tableTitle = (UIOutput) application.createComponent(UIOutput.COMPONENT_TYPE);
			 
			 dataTable = (DataTable) application.createComponent(DataTable.COMPONENT_TYPE);
			 dataTable.clearInitialState();
			 dataTable.setId(entity.getSimpleName());
			 dataTable.setVar("dynamicRow");
			 dataTable.setRows(10);
			 dataTable.setRowsPerPageTemplate("10,20,30");
		
		 
		
			
				
				 Column column = null;
				 for(UtenteTitoli utenteTitoli2 : utenteTitoli ){
					 if(utenteTitoli2.getUtente().getIdUtente().equals(id)){
						
						 dynamicList = new ArrayList<List<Object>>();
						 //List<Object> col = new ArrayList<Object>();
						
						 //mi tiro fuori l'oggetto che compone la tabella 
						 List<Object> object = (List<Object>) utenteTitoli2.getTitoli().getClass().getMethod("get" + entity.getSimpleName()).invoke(utenteTitoli2.getTitoli());
					
						 if(object!=null){
							 System.out.println("uso refelection per prender mi i valori");
							 for(Object o : object){
									
								 Object[] field= new Object[campi.length];
								 
								 for(int i=0; i<campi.length;i++){
									 if (o!=null){
										 field[i] = o.getClass().getMethod("get" + campi[i]).invoke(o);
									 		if(field[i] instanceof BigDecimal){
									 			field[i] = field[i].toString().replace(".", ",");
									 			 System.out.println("assegno punteggio al campo");
									 		}
									 		if(field[i] instanceof Date){
									 			data = new SimpleDateFormat("dd-MM-yyyy");
									 			field[i] = StringUtil.dateToString((Date) field[i], data);
									 			
									 		} 
									 }
									
								 		
								 		
								 }
								
								 dynamicList.add(Arrays.asList(field));
							 }
							 
						 }else{
							 /*Object[] field= new Object[campi.length];
							 dynamicList.add(Arrays.asList(field));*/
							 dataTable.setEmptyMessage("non ci sono elementi");
						 }
							
							 
						 dataTable.setValue(dynamicList);
						 tableTitle.setValue(titoloTabella);
						 //tableTitle.setId(titoloTabella+"Title");
						 dataTable.getFacets().put("header", tableTitle); 
							
							
							 dataTable.setHeader(tableTitle);
							 
							
								 if(dynamicList.size()>0)
									 System.out.println("creo colonne della tabella");
								 for(int i = 0 ; i<dynamicList.get(0).size(); i++){
									 
									 column = (Column) application.createComponent(Column.COMPONENT_TYPE);
//									 ValueExpression ve = ef.createValueExpression(elCtx, "#{dynamicRow["+i+"]}",Object.class);
									 
									 if(inputText[i]){
										 System.out.println(" inizio inserito campo nel input text");
										 HtmlInputText inText = (HtmlInputText)application.createComponent( HtmlInputText.COMPONENT_TYPE );
//										 inText.setValueExpression("value", ve);
										 inText.setId(campi[i]);
										 column.setStyle("width:60px");
										 column.getChildren().add(inText);
										 System.out.println("fine inserito campo nel input text");
										 
									 }else{
										 System.out.println(" inizio inserito campo nel output text");
										 HtmlOutputText ouText = (HtmlOutputText)application.createComponent( HtmlOutputText.COMPONENT_TYPE );
//										 ouText.setValueExpression("value", ve);
										 ouText.setId(campi[i]);
										 //column.setStyle("width:360px");
										 column.getChildren().add(ouText);
										 System.out.println("fine inserito campo nel output text");
									 }
									 	
									 column.setRendered(rendered[i]);
									
									 UIOutput title = (UIOutput)application.createComponent(UIOutput.COMPONENT_TYPE);
									 title.setValue(nomeColonna[i]);
									 //title.setId(nomeColonna[i]+"Title");
									 column.getFacets().put("header", title);
									
									 dataTable.getChildren().add(column);
									 
								 }

					 }
					 
				 }
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			 System.out.println("fallimento della chiammata gettabledetails");
			e.printStackTrace();
			logger.error("errore nella creazione della tabella dettaglio"+e.getMessage());
			throw new GestioneErroriException("errore nella creazione della tabella dettaglio");
		}
		return dataTable;
		 
	 }

}
