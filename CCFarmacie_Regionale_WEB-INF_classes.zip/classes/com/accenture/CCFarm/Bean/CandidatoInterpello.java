package com.accenture.CCFarm.Bean;

import java.math.BigDecimal;


public class CandidatoInterpello {
	
	private static final String nd = "-";
	
	private BigDecimal posizioneGraduatoria;
	private BigDecimal posizioneInterpello;
	private String nominativo;
	private String nProtocollo;
	private String email;
	private String codiceTipoCandidatura;
	private String tipoCandidatura;
	
	public BigDecimal getPosizioneGraduatoria() {
		return posizioneGraduatoria;
	}
	public void setPosizioneGraduatoria(BigDecimal posizioneGraduatoria) {
		this.posizioneGraduatoria = posizioneGraduatoria;
	}
	public BigDecimal getPosizioneInterpello() {
		return posizioneInterpello;
	}
	public void setPosizioneInterpello(BigDecimal posizioneInterpello) {
		this.posizioneInterpello = posizioneInterpello;
	}
	public String getNominativo() {
		return nominativo;
	}
	public void setNominativo(String nominativo) {
		this.nominativo = nominativo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCodiceTipoCandidatura() {
		return codiceTipoCandidatura;
	}
	public void setCodiceTipoCandidatura(String codiceTipoCandidatura) {
		
		if(codiceTipoCandidatura == null) {
			
			setTipoCandidatura(null);
		}
		else {
			
			if(codiceTipoCandidatura.equalsIgnoreCase("S"))
				setTipoCandidatura("Singola");
			else if(codiceTipoCandidatura.equalsIgnoreCase("A"))
				setTipoCandidatura("Associata");
		}
		
		this.codiceTipoCandidatura = codiceTipoCandidatura;
	}
	public String getTipoCandidatura() {
		return tipoCandidatura;
	}
	public void setTipoCandidatura(String tipoCandidatura) {
		this.tipoCandidatura = tipoCandidatura;
	}
	public String getnProtocollo() {
		return nProtocollo;
	}
	public void setnProtocollo(String nProtocollo) {
		this.nProtocollo = nProtocollo;
	}
	
}
