package com.accenture.CCFarm.Bean;

import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;
import com.accenture.punteggi.esperienze.RisultatiValutazioneEsperienze;

public class UtenteEspProf {

	UtenteCandidaturaReg utente;
	
	RisultatiValutazioneEsperienze risultato;

	private String risultati;
	public UtenteCandidaturaReg getUtente() {
		return utente;
	}


	public void setUtente(UtenteCandidaturaReg utente) {
		this.utente = utente;
	}


	public RisultatiValutazioneEsperienze getRisultato() {
		return risultato;
	}


	public void setRisultato(
		RisultatiValutazioneEsperienze risultato) {
		this.risultato = risultato;
	}


	public String getRisultati() {
		return risultati;
	}


	public void setRisultati(String risultati) {
		this.risultati = risultati;
	}
	

	
}
