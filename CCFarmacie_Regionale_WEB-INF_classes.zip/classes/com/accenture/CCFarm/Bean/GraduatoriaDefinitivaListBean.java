package com.accenture.CCFarm.Bean;

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.Date;

@SuppressWarnings("serial")
public class GraduatoriaDefinitivaListBean implements java.io.Serializable, Comparable<GraduatoriaDefinitivaListBean>  {

	private String idCandidatura;
	private String numeroProtocollo;
	private String cognome;
	private String nome;
	private String codRegione;
	private BigDecimal etaMedia;
	private BigDecimal punteggio; 
	private String etaMediaString;
	private String punteggioString; 
	private String dataNascita;
	private BigDecimal indiceTotale;
	private BigDecimal indiceRelativo;
	private String exAequo;
	private String exAequoRisolto;
	
	private BigDecimal indiceSave;
	private String indiceView = "true";
	private String indiceSpinner= "false";
	
	private String colorRow = "";
	
	
	public GraduatoriaDefinitivaListBean() {}
	


	public String getIdCandidatura() {
		return idCandidatura;
	}

	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}

	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}

	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public BigDecimal getPunteggio() {
		return punteggio;
	}

	public void setPunteggio(BigDecimal punteggio) {
		this.punteggio = punteggio;
	}
 
	
	
	public BigDecimal getIndiceTotale() {
		return indiceTotale;
	}



	public void setIndiceTotale(BigDecimal indiceTotale) {
		this.indiceTotale = indiceTotale;
	}



	public BigDecimal getIndiceRelativo() {
		return indiceRelativo;
	}



	public void setIndiceRelativo(BigDecimal indiceRelativo) {
		this.indiceRelativo = indiceRelativo;
	}



	public String getExAequo() {
		return exAequo;
	}



	public void setExAequo(String exAequo) {
		this.exAequo = exAequo;
	}



	public String getExAequoRisolto() {
		return exAequoRisolto;
	}



	public void setExAequoRisolto(String exAequoRisolto) {
		this.exAequoRisolto = exAequoRisolto;
	}



	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}


	public BigDecimal getEtaMedia() {
		return etaMedia;
	}


	public void setEtaMedia(BigDecimal etaMedia) {
		this.etaMedia = etaMedia;
	}



	public String getDataNascita() {
		return dataNascita;
	}



	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}






	public BigDecimal getIndiceSave() {
		return indiceSave;
	}



	public void setIndiceSave(BigDecimal indiceSave) {
		this.indiceSave = indiceSave;
	}



	public String getIndiceView() {
		return indiceView;
	}



	public void setIndiceView(String indiceView) {
		this.indiceView = indiceView;
	}



	public String getColorRow() {
		return colorRow;
	}



	public void setColorRow(String colorRow) {
		this.colorRow = colorRow;
	}



	public String getEtaMediaString() {
		return etaMediaString;
	}



	public void setEtaMediaString(String etaMediaString) {
		this.etaMediaString = etaMediaString;
	}



	public String getPunteggioString() {
		return punteggioString;
	}



	public void setPunteggioString(String punteggioString) {
		this.punteggioString = punteggioString;
	}



	public String getIndiceSpinner() {
		return indiceSpinner;
	}



	public void setIndiceSpinner(String indiceSpinner) {
		this.indiceSpinner = indiceSpinner;
	}

 
	@Override
	public int compareTo(GraduatoriaDefinitivaListBean gDF) {
		
		if (indiceTotale==null) {
			if (gDF.indiceTotale==null){
				return 0;
			} 
			return -1;
		}
		return this.indiceTotale.compareTo(gDF.indiceTotale);
	}


}