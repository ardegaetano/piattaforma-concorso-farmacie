package com.accenture.CCFarm.Bean;

import java.util.ArrayList;
import java.util.List;

public class UtenteOsservazioni {
	
	String nomeUtente;
	
	List<String> osservazioni = new ArrayList<String>();

	public String getNomeUtente() {
		return nomeUtente;
	}

	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}

	public List<String> getOsservazioni() {
		return osservazioni;
	}

	public void setOsservazioni(List<String> osservazioni) {
		this.osservazioni = osservazioni;
	}
	
	
	

}
