package com.accenture.CCFarm.Bean;

import com.accenture.CCFarm.utility.StringUtil;



public class UtenteBean{

//anagrafica utente associato
private String nomeUtente;
private String cognomeUtente;
private String sesso;
private String codiceFiscaleUtente;
private String pecMail;
private java.util.Date dataNascita;
private String luogoNascitaUtente;
private String provinciaNascitaUtente;
private String luogoNascitaEsteraUtente;
private String nazioneNascitaUtente;
private String docPervenuta;
private String prvNascitaUtente;
private String dataNascitaString;
private String idUtente;
private String idCandidatura;
private String protocolloRicevuta="";
private String tipoCandidato;

private String richiestaCambioPEC;


//estremi documento
private String tipoDocumento;
private String numeroDoc;
private String enteRilascioDoc;
private java.util.Date dataRilascioDoc;

private String regioneRichiesta;
private String modalitaCandidatura;
private String codiceFiscaleRefCand;
private String codiceRegione;
private String ammesso;
	
	public String getNomeUtente() {
		return nomeUtente;
	}
	
	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}
	
	public String getCognomeUtente() {
		return cognomeUtente;
	}
	
	public void setCognomeUtente(String cognomeUtente) {
		this.cognomeUtente = cognomeUtente;
	}
	
	public String getSesso() {
		return sesso;
	}
	
	public void setSesso(String sesso) {
		this.sesso = sesso;
	}
	
	public String getCodiceFiscaleUtente() {
		return codiceFiscaleUtente;
	}
	
	public void setCodiceFiscaleUtente(String codiceFiscaleUtente) {
		this.codiceFiscaleUtente = codiceFiscaleUtente;
	}
	
	public String getPecMail() {
		return pecMail;
	}
	
	public void setPecMail(String pecMail) {
		this.pecMail = pecMail;
	}
	
	public java.util.Date getDataNascita() {
		
		return dataNascita;
	}
	
	public void setDataNascita(java.util.Date dataNascita) {
		if(dataNascita!=null && !dataNascita.equals("")){
			dataNascitaString = StringUtil.dateToStringDDMMYYYY(dataNascita);
			}
			this.dataNascita = dataNascita;
		
	}
	
	public String getLuogoNascitaUtente() {
		return luogoNascitaUtente;
	}
	
	public void setLuogoNascitaUtente(String luogoNascitaUtente) {
		this.luogoNascitaUtente = luogoNascitaUtente;
	}
	
	public String getLuogoNascitaEsteraUtente() {
		return luogoNascitaEsteraUtente;
	}
	
	public void setLuogoNascitaEsteraUtente(String luogoNascitaEsteraUtente) {
		this.luogoNascitaEsteraUtente = luogoNascitaEsteraUtente;
	}
	
	public String getNazioneNascitaUtente() {
		return nazioneNascitaUtente;
	}
	
	public void setNazioneNascitaUtente(String nazioneNascitaUtente) {
		this.nazioneNascitaUtente = nazioneNascitaUtente;
	}
	
	public String getPrvNascitaUtente() {
		return prvNascitaUtente;
	}
	
	public void setPrvNascitaUtente(String prvNascitaUtente) {
		this.prvNascitaUtente = prvNascitaUtente;
	}
	
	public String getDataNascitaString() {
		return dataNascitaString;
	}
	
	public void setDataNascitaString(String dataNascitaString) {
		this.dataNascitaString = dataNascitaString;
	}
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	public String getNumeroDoc() {
		return numeroDoc;
	}
	
	public void setNumeroDoc(String numeroDoc) {
		this.numeroDoc = numeroDoc;
	}
	
	public String getEnteRilascioDoc() {
		return enteRilascioDoc;
	}
	
	public void setEnteRilascioDoc(String enteRilascioDoc) {
		this.enteRilascioDoc = enteRilascioDoc;
	}
	
	public java.util.Date getDataRilascioDoc() {
		return dataRilascioDoc;
	}
	
	public void setDataRilascioDoc(java.util.Date dataRilascioDoc) {
		this.dataRilascioDoc = dataRilascioDoc;
	}
	
	public String getRegioneRichiesta() {
		return regioneRichiesta;
	}
	
	public void setRegioneRichiesta(String regioneRichiesta) {
		this.regioneRichiesta = regioneRichiesta;
	}
	
	public String getIdUtente() {
		return idUtente;
	}
	
	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}
	
	public String getProvinciaNascitaUtente() {
		return provinciaNascitaUtente;
	}
	
	public void setProvinciaNascitaUtente(String provinciaNascitaUtente) {
		this.provinciaNascitaUtente = provinciaNascitaUtente;
	}
	
	public String getProtocolloRicevuta() {
		return protocolloRicevuta;
	}
	
	public void setProtocolloRicevuta(String protocolloRicevuta) {
		this.protocolloRicevuta = protocolloRicevuta;
	}
	
	public String getTipoCandidato() {
		return tipoCandidato;
	}
	
	public void setTipoCandidato(String tipoCandidato) {
		this.tipoCandidato = tipoCandidato;
	}
	
	public String getIdCandidatura() {
		return idCandidatura;
	}
	
	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}
	
	public String getModalitaCandidatura() {
		return modalitaCandidatura;
	}
	
	public void setModalitaCandidatura(String modalitaCandidatura) {
		this.modalitaCandidatura = modalitaCandidatura;
	}
	
	public String getCodiceFiscaleRefCand() {
		return codiceFiscaleRefCand;
	}
	
	public void setCodiceFiscaleRefCand(String codiceFiscaleRefCand) {
		this.codiceFiscaleRefCand = codiceFiscaleRefCand;
	}
	
	public String getCodiceRegione() {
		return codiceRegione;
	}
	
	public void setCodiceRegione(String codiceRegione) {
		this.codiceRegione = codiceRegione;
	}
	
	public String getAmmesso() {
		return ammesso;
	}
	
	public void setAmmesso(String ammesso) {
		this.ammesso = ammesso;
	}
	
	public String getDocPervenuta() {
		return docPervenuta;
	}
	
	public void setDocPervenuta(String docuPervenuta) {
		this.docPervenuta = docuPervenuta;
	}
	
	public String getRichiestaCambioPEC() {
		return richiestaCambioPEC;
	}
	
	public void setRichiestaCambioPEC(String richiestaCambioPEC) {
		this.richiestaCambioPEC = richiestaCambioPEC;
	}


}

