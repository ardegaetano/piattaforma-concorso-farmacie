package com.accenture.CCFarm.Bean;

import java.util.Date;



public class EsercizioProfessionale {

	private Date dataInizioEs;
	private String dataInizioStringa;
    private Date dataFineEs;
    private String dataFineStringa;
	private String codModalitaEs;
	private String codRuoloEs;
	private String descrizioneRuolo;
	private String codCategoriaEs;
	private String denEsercizio;
	private String indirizzoEs;
	private String regEs;
	private String regDescrizione;
	private String prvEs;
	private String prvDescrizione;
	private String comuneEs;
	private String comuneDescrizione;
	private String aslEs;
	private String aslDenom;
	private String flagFarmRurale;
	private String tipologiaEsercizioDescrizione;
	private String modalitaTempoDescr;
	private String idDomandaEs;
	private String flagEstero;
	private String capEs;
	private String idEsercizio;
	
	public Date getDataInizioEs() {
		return dataInizioEs;
	}
	public String getIdDomandaEs() {
		return idDomandaEs;
	}
	public void setIdDomandaEs(String idDomandaEs) {
		this.idDomandaEs = idDomandaEs;
	}
	public void setDataInizioEs(Date dataInizioEs) {
		this.dataInizioEs = dataInizioEs;
	}
	public Date getDataFineEs() {
		return dataFineEs;
	}
	public void setDataFineEs(Date dataFineEs) {
		this.dataFineEs = dataFineEs;
	}
	public String getCodModalitaEs() {
		return codModalitaEs;
	}
	public void setCodModalitaEs(String codModalitaEs) {
		this.codModalitaEs = codModalitaEs;
	}
	public String getCodRuoloEs() {
		return codRuoloEs;
	}
	public void setCodRuoloEs(String codRuoloEs) {
		this.codRuoloEs = codRuoloEs;
	}
	public String getCodCategoriaEs() {
		return codCategoriaEs;
	}
	public void setCodCategoriaEs(String codCategoriaEs) {
		this.codCategoriaEs = codCategoriaEs;
	}
	public String getDenEsercizio() {
		return denEsercizio;
	}
	public void setDenEsercizio(String denEsercizio) {
		this.denEsercizio = denEsercizio;
	}
	public String getIndirizzoEs() {
		return indirizzoEs;
	}
	public void setIndirizzoEs(String indirizzoEs) {
		this.indirizzoEs = indirizzoEs;
	}
	public String getRegEs() {
		return regEs;
	}
	public void setRegEs(String regEs) {
		this.regEs = regEs;
	}
	public String getPrvEs() {
		return prvEs;
	}
	public void setPrvEs(String prvEs) {
		this.prvEs = prvEs;
	}
	public String getComuneEs() {
		return comuneEs;
	}
	public void setComuneEs(String comuneEs) {
		this.comuneEs = comuneEs;
	}
	public String getAslEs() {
		return aslEs;
	}
	public void setAslEs(String aslEs) {
		this.aslEs = aslEs;
	}
	public String getFlagFarmRurale() {
		return flagFarmRurale;
	}
	public void setFlagFarmRurale(String flagFarmRurale) {
		this.flagFarmRurale = flagFarmRurale;
	}
	public String getRegDescrizione() {
		return regDescrizione;
	}
	public void setRegDescrizione(String regDescrizione) {
		this.regDescrizione = regDescrizione;
	}
	public String getPrvDescrizione() {
		return prvDescrizione;
	}
	public void setPrvDescrizione(String prvDescrizione) {
		this.prvDescrizione = prvDescrizione;
	}
	public String getComuneDescrizione() {
		return comuneDescrizione;
	}
	public void setComuneDescrizione(String comuneDescrizione) {
		this.comuneDescrizione = comuneDescrizione;
	}
	public String getDataInizioStringa() {
		return dataInizioStringa;
	}
	public void setDataInizioStringa(String dataInizioStringa) {
		this.dataInizioStringa = dataInizioStringa;
	}
	public String getDataFineStringa() {
		return dataFineStringa;
	}
	public void setDataFineStringa(String dataFineStringa) {
		this.dataFineStringa = dataFineStringa;
	}
	public String getDescrizioneRuolo() {
		return descrizioneRuolo;
	}
	public void setDescrizioneRuolo(String descrizioneRuolo) {
		this.descrizioneRuolo = descrizioneRuolo;
	}
	public String getAslDenom() {
		return aslDenom;
	}
	public void setAslDenom(String aslDenom) {
		this.aslDenom = aslDenom;
	}
	public String getTipologiaEsercizioDescrizione() {
		return tipologiaEsercizioDescrizione;
	}
	public void setTipologiaEsercizioDescrizione(
			String tipologiaEsercizioDescrizione) {
		this.tipologiaEsercizioDescrizione = tipologiaEsercizioDescrizione;
	}
	public String getModalitaTempoDescr() {
		return modalitaTempoDescr;
	}
	public void setModalitaTempoDescr(String modalitaTempoDescr) {
		this.modalitaTempoDescr = modalitaTempoDescr;
	}
	public String getFlagEstero() {
		return flagEstero;
	}
	public void setFlagEstero(String flagEstero) {
		this.flagEstero = flagEstero;
	}
	public String getCapEs() {
		return capEs;
	}
	public void setCapEs(String capEs) {
		this.capEs = capEs;
	}
	public String getIdEsercizio() {
		return idEsercizio;
	}
	public void setIdEsercizio(String idEsercizio) {
		this.idEsercizio = idEsercizio;
	}
	
	
}
