package com.accenture.CCFarm.Bean;

import com.accenture.CCFarm.DAO.Titoli;
import com.accenture.CCFarm.DAO.UtenteCandidaturaReg;


public class UtenteTitoli {

	private UtenteCandidaturaReg utente;
		
	private Titoli titoli;
	
	

	public UtenteTitoli() {
		
	}
	
	public UtenteTitoli(//String titoli, 
			UtenteCandidaturaReg utente,Titoli titoli) {
		// TODO Auto-generated constructor stub
		//this.titoli=titoli;
		this.utente=utente;
		this.titoli= titoli;}
		//this.nomeTitolo = nomeTitolo;}
		

	
	

	public Titoli getTitoli() {
		return titoli;
	}

	public void setTitoli(Titoli titoli) {
		this.titoli = titoli;
	}

	public UtenteCandidaturaReg getUtente() {
		return utente;
	}

	public void setUtente(UtenteCandidaturaReg utente) {
		this.utente = utente;
	}

	
	


	
	
	
}
