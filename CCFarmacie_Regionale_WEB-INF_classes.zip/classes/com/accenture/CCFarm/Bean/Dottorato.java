package com.accenture.CCFarm.Bean;

import java.util.Date;

public class Dottorato {

	private String idDottorato;
	private String denominazioneDottorato;
	private String descrFacoltaDottorato;
	private String descrUniversitaDottorato;
	private String luogoDottorato;
	private String nazioneDottorato;
	private Date   dataInizioDottorato;
	private Date   dataFineDottorato;
	private String   dataInizioDottoratoStringa;
	private String   dataFineDottoratoStringa;
	private String flagEsteroDottorato;
	
	public String getDenominazioneDottorato() {
		return denominazioneDottorato;
	}
	public String getIdDottorato() {
		return idDottorato;
	}
	public void setIdDottorato(String idDottorato) {
		this.idDottorato = idDottorato;
	}
	public void setDenominazioneDottorato(String denominazioneDottorato) {
		this.denominazioneDottorato = denominazioneDottorato;
	}
	public String getDescrFacoltaDottorato() {
		return descrFacoltaDottorato;
	}
	public void setDescrFacoltaDottorato(String descrFacoltaDottorato) {
		this.descrFacoltaDottorato = descrFacoltaDottorato;
	}
	public String getDescrUniversitaDottorato() {
		return descrUniversitaDottorato;
	}
	public void setDescrUniversitaDottorato(String descrUniversitaDottorato) {
		this.descrUniversitaDottorato = descrUniversitaDottorato;
	}
	public String getLuogoDottorato() {
		return luogoDottorato;
	}
	public void setLuogoDottorato(String luogoDottorato) {
		this.luogoDottorato = luogoDottorato;
	}
	public String getNazioneDottorato() {
		return nazioneDottorato;
	}
	public void setNazioneDottorato(String nazioneDottorato) {
		this.nazioneDottorato = nazioneDottorato;
	}
	public Date getDataInizioDottorato() {
		return dataInizioDottorato;
	}
	public void setDataInizioDottorato(Date dataInizioDottorato) {
		this.dataInizioDottorato = dataInizioDottorato;
	}
	public Date getDataFineDottorato() {
		return dataFineDottorato;
	}
	public void setDataFineDottorato(Date dataFineDottorato) {
		this.dataFineDottorato = dataFineDottorato;
	}
	public String getFlagEsteroDottorato() {
		return flagEsteroDottorato;
	}
	public void setFlagEsteroDottorato(String flagEsteroDottorato) {
		this.flagEsteroDottorato = flagEsteroDottorato;
	}
	public String getDataInizioDottoratoStringa() {
		return dataInizioDottoratoStringa;
	}
	public void setDataInizioDottoratoStringa(String dataInizioDottoratoStringa) {
		this.dataInizioDottoratoStringa = dataInizioDottoratoStringa;
	}
	public String getDataFineDottoratoStringa() {
		return dataFineDottoratoStringa;
	}
	public void setDataFineDottoratoStringa(String dataFineDottoratoStringa) {
		this.dataFineDottoratoStringa = dataFineDottoratoStringa;
	}
	
	
}
