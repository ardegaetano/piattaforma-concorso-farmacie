package com.accenture.CCFarm.Bean;

public class DatiUtenza {
	
	private String idUtente;
	private String codRegione;
	private String nomeUtente;
	private String cognomeUtente;
	private String nProtocollo;
	private String nominativo;
	private String codiceFiscale;
	private String email;
	private String referente;
	private String tipoCandidatura;
	private String emailOriginale;
	private String numInterpello;
	private String posizioneInterpello;
	private String posizioneGraduatoria;
	private String idCandidatura;
    
	
	public String getIdUtente() {
		return idUtente;
	}
	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}
	public String getCodRegione() {
		return codRegione;
	}
	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}
	public String getNomeUtente() {
		return nomeUtente;
	}
	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}
	public String getCognomeUtente() {
		return cognomeUtente;
	}
	public void setCognomeUtente(String cognomeUtente) {
		this.cognomeUtente = cognomeUtente;
	}
	public String getReferente() {
		return referente;
	}
	public String getnProtocollo() {
		return nProtocollo;
	}
	public void setnProtocollo(String nProtocollo) {
		this.nProtocollo = nProtocollo;
	}
	public void setReferente(String referente) {
		this.referente = referente;
	}
	public String getNominativo() {
		return nominativo;
	}
	public void setNominativo(String nominativo) {
		this.nominativo = nominativo;
	}
	public String getCodiceFiscale() {
		return codiceFiscale;
	}
	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTipoCandidatura() {
		return tipoCandidatura;
	}
	public void setTipoCandidatura(String tipoCandidatura) {
		this.tipoCandidatura = tipoCandidatura;
	}
	public String getEmailOriginale() {
		return emailOriginale;
	}
	public void setEmailOriginale(String emailOriginale) {
		this.emailOriginale = emailOriginale;
	}
	public String getNumInterpello() {
		return numInterpello;
	}
	public void setNumInterpello(String numInterpello) {
		this.numInterpello = numInterpello;
	}
	public String getPosizioneInterpello() {
		return posizioneInterpello;
	}
	public void setPosizioneInterpello(String posizioneInterpello) {
		this.posizioneInterpello = posizioneInterpello;
	}
	public String getPosizioneGraduatoria() {
		return posizioneGraduatoria;
	}
	public void setPosizioneGraduatoria(String posizioneGraduatoria) {
		this.posizioneGraduatoria = posizioneGraduatoria;
	}
	public String getIdCandidatura() {
		return idCandidatura;
	}
	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}
	
}
