package com.accenture.CCFarm.Bean;

import java.math.BigDecimal;
import java.sql.Clob;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.StringUtil;


@SuppressWarnings("serial")
public class CandidatoSedeAssegnataListBean {

	private BigDecimal posizioneGraduatoria;
	private BigDecimal indiceInterpello;
	private String sede;
	private Clob sedeEstesa;
	private String descSedeString;
	private String idCandidatura;
	private String nominativo;
	private String numeroProtocollo;
	private String mailPEC;
	private String tipoPartecipazione;
	private String altraRegionePartecipazione;
	private String statoPartecipazione;
	private String styleRowSede;
	
	public BigDecimal getPosizioneGraduatoria() {
		return posizioneGraduatoria;
	}

	public void setPosizioneGraduatoria(BigDecimal posizioneGraduatoria) {
		this.posizioneGraduatoria = posizioneGraduatoria;
	}

	public BigDecimal getIndiceInterpello() {
		return indiceInterpello;
	}

	public void setIndiceInterpello(BigDecimal indiceInterpello) {
		this.indiceInterpello = indiceInterpello;
	}

	public String getSede() {
		return sede;
	}

	public void setSede(String sede) {
		this.sede = sede;
	}

	public String getDescSedeString() {
		return descSedeString;
	}

	public void setDescSedeString(String descSedeString) {
		this.descSedeString = descSedeString;
	}

	public String getIdCandidatura() {
		return idCandidatura;
	}

	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}

	public String getNominativo() {
		return nominativo;
	}

	public void setNominativo(String nominativo) {
		this.nominativo = nominativo;
	}

	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}

	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}

	public String getMailPEC() {
		return mailPEC;
	}

	public void setMailPEC(String mailPEC) {
		this.mailPEC = mailPEC;
	}

	public String getTipoPartecipazione() {
		return tipoPartecipazione;
	}

	public void setTipoPartecipazione(String tipoPartecipazione) {
		this.tipoPartecipazione = tipoPartecipazione;
	}

	public String getAltraRegionePartecipazione() {
		return altraRegionePartecipazione;
	}

	public void setAltraRegionePartecipazione(String altraRegionePartecipazione) {
		this.altraRegionePartecipazione = altraRegionePartecipazione;
	}

	public String getStatoPartecipazione() {
		return statoPartecipazione;
	}

	public void setStatoPartecipazione(String statoPartecipazione) {
		this.statoPartecipazione = statoPartecipazione;
	}

	public Clob getSedeEstesa() {
		return sedeEstesa;
	}

	public void setSedeEstesa(Clob sedeEstesa) throws GestioneErroriException {
		this.sedeEstesa = sedeEstesa;
		if(this.sedeEstesa!=null)
			setDescSedeString(StringUtil.convertClob(this.sedeEstesa).trim());
	}

	public String getStyleRowSede() {
		return styleRowSede;
	}

	public void setStyleRowSede(String styleRowSede) {
		this.styleRowSede = styleRowSede;
	}

}