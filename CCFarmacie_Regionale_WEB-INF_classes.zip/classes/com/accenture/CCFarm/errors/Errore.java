package com.accenture.CCFarm.errors;

public class Errore
{
    private String nomeCampo ="";
    private String messaggio = "";
    
    public String getNomeCampo()
    {
        return nomeCampo;
    }
    protected void setNomeCampo(String etichetta)
    {
        this.nomeCampo = etichetta;
    }
    public String getMessaggio()
    {
        return messaggio;
    }
    protected void setMessaggio(String errore)
    {
        messaggio = errore;
    }
    
    public Errore(String etichetta, String messaggio)
    {
	this.nomeCampo = etichetta;
	this.messaggio = messaggio;
    }

}
