package com.accenture.CCFarm.exception;

public class SediException extends Exception
{

    public SediException()
    {
	super();
    }

    public SediException(String message, Throwable cause)
    {
	super(message, cause);
    }

    public SediException(String message)
    {
	super(message);
    }

    public SediException(Throwable cause)
    {
	super(cause);
    }

}
