package com.accenture.CCFarm.valutazione;


public class ValutazioneEsperienzaProf {

	public ValutazioneEsperienzaProf() {
		// TODO Auto-generated constructor stub
	}
	
	
	public void valutaEspCandidato(String idUtente){
		
//		EsercizioProfessionale esercizioProfessionale 
		
		
	}
	
	
//	
//	
//	private void loadPaginaDettaglio(SimulazioneCalcoloBean simBean) throws Exception {
//		ruoli = CaricaRuoli.getRuoli();
//		try {
//			String risultato = SimulazioneCalcoloAction.calcola(this);
//			if(!risultato.equals("") ){
//				setEsitoSimulazione(risultato);
//			}
//		} catch (Exception e) {
//			throw e;
//		}
//		
//				
//    }
//	
//	
//	public static String calcola(SimulazioneCalcoloBean simulazioneCalcoloBean) throws Exception {
//		RisultatiValutazioneEsperienze risultato = new RisultatiValutazioneEsperienze();
//		String risultatoString = "";
//		ArrayList<EsperienzaOriginal> listEsp = new ArrayList<EsperienzaOriginal>();
//		for (int i = 0; i < simulazioneCalcoloBean.getEserciziTable().size(); i++) {
//			EsercizioProfessionale esProf = simulazioneCalcoloBean.getEserciziTable().get(i);
//			EsperienzaOriginal espOr = new EsperienzaOriginal();
//			
//			String codiceCategoria =  esProf.getDescrizioneRuolo().substring(5, 6);
//			espOr.setCodiceCategoria(codiceCategoria);
//			
//			if(esProf.getCodModalitaEs().equals("0"))
//				espOr.setCodiceModalita("P");
//			else
//				espOr.setCodiceModalita("F");
//			if(esProf.getFlagFarmRurale().equals("Si"))
//				espOr.setRurale(true);
//			else
//				espOr.setRurale(false);
//			espOr.setDataInizio(esProf.getDataInizioEs());
//			espOr.setDataFine(esProf.getDataFineEs());
//			
//			String ruoloStringa =  esProf.getDescrizioneRuolo().substring(7,esProf.getDescrizioneRuolo().length() );
//			espOr.setRuolo(ruoloStringa);
//			
//			listEsp.add(espOr);
//		}
//		
//		if(!listEsp.isEmpty()){
//			risultato = com.accenture.punteggi.esperienze.CalcoloPunteggi.calcola(listEsp);
//			
//		}
//		if(risultato != null){
//			risultatoString = risultato.toString();
//		}
//	return risultatoString ;
//}

}
