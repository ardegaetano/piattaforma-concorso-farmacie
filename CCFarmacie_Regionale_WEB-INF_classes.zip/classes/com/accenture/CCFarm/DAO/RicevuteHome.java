package com.accenture.CCFarm.DAO;

// Generated 7-set-2012 11.48.05 by Hibernate Tools 3.4.0.CR1

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class Ricevute.
 * @see com.ccFram.Ricevute
 * @author Hibernate Tools
 */
public class RicevuteHome {

	private static final Log log = LogFactory.getLog(RicevuteHome.class);
	public  static final String SEQUENCE = "sequence";
	public  static final String PARAMETERS = "parameters";
	private static String sequenceName;
	private static int LIMITE_SIZE_N_PROTOCOLLO = 6;
	private static String tipoRicevuta_Domanda = "DD";

	public void persist(Ricevute transientInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("persisting Ricevute instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}finally{
			session.close();
		}
	}
	public boolean insertRicevute(Ricevute ricevute)
	{
		try{
			deleteFromIdCantidatura(ricevute.getId().getIdCandidatura());
		}catch(Exception e){}
		boolean result = false;
		Session session = HibernateUtil.openSession();			
		Transaction sessionTrans = session.getTransaction();			
		try {
			sessionTrans.begin();
			session.save(ricevute);
			sessionTrans.commit();
			log.debug("Operazione Inserimento Ricevuta [OK]");
			result = true;
		} catch (RuntimeException re) {
			log.error("Errore di Inserimento nuova Ricevute");
			throw re;
		}finally{
			session.close();
		}
		return result;
		
	}
	
	public boolean modifyBLOB(Ricevute instance) {
		boolean result = false;
		Session session = HibernateUtil.openSession();			
		Transaction sessionTrans = session.getTransaction();			
		try {
			sessionTrans.begin();
			session.update(instance);
			sessionTrans.commit();
			log.debug("Operazione Modifica Ricevuta [OK]");
			result = true;
		} catch (RuntimeException re) {
			log.error("Errore di Modifica nuova Ricevute");
			throw re;
		}finally{
			session.close();
		}
		return result;
	}
	
	
	public void attachDirty(Ricevute instance) {
		Session session = HibernateUtil.openSession();
		
		try {
			session.saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}finally{
			session.close();
		}
	}

	public void attachClean(Ricevute instance) {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Ricevute instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}finally{
			session.close();
		}
	}

	public void delete(Ricevute persistentInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("deleting Ricevute instance");
		try {
			session.delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}finally{
			session.close();
		}
	}

	public Ricevute merge(Ricevute detachedInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("merging Ricevute instance");
		try {
			Ricevute result = (Ricevute) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}finally{
			session.close();
		}
	}

	public Ricevute findById(java.lang.String id) {
		Session session = HibernateUtil.openSession();
		log.debug("getting Ricevute instance with id: " + id);
		try {
			Ricevute instance = (Ricevute) session.get("com.accenture.CCFarm.DAO.Ricevute", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}finally{
			session.close();
		}
	}
	
	public Ricevute findByCandidatura(String id_candidatura) {
		return findByCandidaturaTipoRicevuta(id_candidatura, tipoRicevuta_Domanda);
	}
	
	public Ricevute findByCandidaturaTipoRicevuta(String id_candidatura, String tipo_ricevuta) {
		Session session = HibernateUtil.openSession();
		Ricevute result = new Ricevute();
		try {
			Query query = session.createQuery("from Ricevute where id.idCandidatura = :idCandidatura and id.tipoRicevuta = :tipoRicevuta ");
			query.setParameter("idCandidatura", id_candidatura);
			query.setParameter("tipoRicevuta", tipo_ricevuta);
			List<Ricevute> lista =  new ArrayList<Ricevute>();
						   lista = query.list();
			if (lista!=null && lista.size()>0)
				result = lista.get(0);
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}finally{
			session.close();
		}
		return result;
	}	
	
	public List<Ricevute> findRicevuteCandidato(String id_candidatura) throws GestioneErroriException {
		
		if(id_candidatura == null)
			return null;
		
		Session session = null;
		
		try {
			session = HibernateUtil.openSession();
			
			Query query = session.createQuery("from Ricevute where id.idCandidatura = :idCandidatura order by dataInvio");
			query.setParameter("idCandidatura", id_candidatura);
			List<Ricevute> results = query.list();
			log.debug("ricercaUtentiCandidati: find by filter successful, result size: "+ results.size());
			
			return results;
		}
		catch(Exception e) {
			
			log.error("RicevuteHome - findRicevuteCandidato fallita", e);
			throw new GestioneErroriException("RicevuteHome - findRicevuteCandidato fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}

	public List findByExample(Ricevute instance) {
		Session session = HibernateUtil.openSession();
		log.debug("finding Ricevute instance by example");
		try {
			List results = session.createCriteria("com.accenture.CCFarm.DAO.Ricevute")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}finally{
			session.close();
		}
	}
	
	public void deleteFromIdCantidatura(String idCandidatura) {
		Session session = HibernateUtil.openSession();
		Transaction tx = session.beginTransaction();
		log.debug("deleting Ricevute instance");
		try {
			
			Query query = session.createSQLQuery("Delete RICEVUTE where ID_CANDIDATURA = '" +idCandidatura +"'" );
			query.executeUpdate();
			tx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
		finally
		{
			session.close();
		}
	}	
	
	

	
	public static String leggiIdSequence(String nomeSequence)  
	{ 
		String result = null;
		Session session = null;
		try
		{ 
			/*
			
			SessionImplementor sim = (SessionImplementor) HibernateUtil.openSession();
			Connection con = sim.connection();
			String sql = "SELECT " + "ID_RICEVUTA_" + nomeSequence +".NEXTVAL FROM DUAL";
			PreparedStatement prest = con.prepareStatement(sql);
			ResultSet rs1 = prest.executeQuery();	
			while (rs1.next()){
				result = rs1.getString(1);	
			}
			while (result.length()<LIMITE_SIZE_N_PROTOCOLLO)
			{
				result = "0" + result;
			}
			con.close();
			*/
			session = HibernateUtil.openSession();
			String sql = "SELECT " + "ID_RICEVUTA_" + nomeSequence +".NEXTVAL FROM DUAL";
			List query =  session.createSQLQuery(sql).list();
			result = query.get(0) +"";
			while (result.length()<LIMITE_SIZE_N_PROTOCOLLO)
			{
				result = "0" + result;
			}				
			
		} catch (RuntimeException e) { 
			e.printStackTrace();
		}
		finally{
			session.close();
			return result;
		}		
	}	
}
