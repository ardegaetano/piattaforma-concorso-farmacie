package com.accenture.CCFarm.DAO;

import java.util.Date;

public class Ricevute implements java.io.Serializable {

	private RicevuteId id;
	
	private String flagInvio;
	private byte[] contenutoFile;
	private Date dataInvio;
	private String numeroProtocollo;
	private String tipoRicevuta;
	
	public RicevuteId getId() {
		return id;
	}
	public void setId(RicevuteId id) {
		this.id = id;
	}
	public String getFlagInvio() {
		return flagInvio;
	}
	public void setFlagInvio(String flagInvio) {
		this.flagInvio = flagInvio;
	}
	public byte[] getContenutoFile() {
		return contenutoFile;
	}
	public void setContenutoFile(byte[] contenutoFile) {
		this.contenutoFile = contenutoFile;
	}
	public Date getDataInvio() {
		return dataInvio;
	}
	public void setDataInvio(Date dataInvio) {
		this.dataInvio = dataInvio;
	}
	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}
	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}
	public String getTipoRicevuta() {
		return tipoRicevuta;
	}
	public void setTipoRicevuta(String tipoRicevuta) {
		this.tipoRicevuta = tipoRicevuta;
	}
	
}
