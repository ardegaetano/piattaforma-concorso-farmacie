package com.accenture.CCFarm.DAO;

public class SpecializzazioneRegStoricoId implements java.io.Serializable {

	private String idStorico;
	private String idSpecializzazione;

	public SpecializzazioneRegStoricoId() {
	}

	public String getIdStorico() {
		return idStorico;
	}

	public void setIdStorico(String idStorico) {
		this.idStorico = idStorico;
	}

	public String getIdSpecializzazione() {
		return idSpecializzazione;
	}

	public void setIdSpecializzazione(String idSpecializzazione) {
		this.idSpecializzazione = idSpecializzazione;
	}
	
}
