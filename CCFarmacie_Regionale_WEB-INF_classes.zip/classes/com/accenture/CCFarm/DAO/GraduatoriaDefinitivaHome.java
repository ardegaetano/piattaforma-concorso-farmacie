package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;

import com.accenture.CCFarm.Bean.UtenteBean;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.Localita;


/**
* Home object for domain model class GraduatoriaDefinitiva.
* @see com.accenture.GraduatoriaDefinitivaListBean.DAO.GraduatoriaDefinitiva
*/
public class GraduatoriaDefinitivaHome {

	private static final Logger log = CommonLogger.getLogger("GraduatoriaDefinitivaHome");

	public void persist(GraduatoriaDefinitiva transientInstance)  throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting GraduatoriaDefinitiva instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("GraduatoriaDefinitivaHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(GraduatoriaDefinitiva instance) throws GestioneErroriException{ 
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty GraduatoriaDefinitiva instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw new GestioneErroriException("GraduatoriaDefinitivaHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(GraduatoriaDefinitiva instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean GraduatoriaDefinitiva instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("GraduatoriaDefinitivaHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(GraduatoriaDefinitiva persistentInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting GraduatoriaDefinitiva instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("GraduatoriaDefinitivaHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public GraduatoriaDefinitiva merge(GraduatoriaDefinitiva detachedInstance)throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging GraduatoriaDefinitiva instance");
		try {
			GraduatoriaDefinitiva result = (GraduatoriaDefinitiva) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("GraduatoriaDefinitivaHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public GraduatoriaDefinitiva findById(java.lang.String id)throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting GraduatoriaDefinitiva instance with id: " + id);
		try {
			GraduatoriaDefinitiva instance = (GraduatoriaDefinitiva) session.get("com.accenture.CCFarm.DAO.GraduatoriaDefinitiva", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("GraduatoriaDefinitivaHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(GraduatoriaDefinitiva instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding GraduatoriaDefinitiva instance by example");
		try {
				List results = session 
					.createCriteria("com.accenture.CCFarm.DAO.GraduatoriaDefinitiva")
					.add(Example.create(instance)).addOrder(Order.asc("indiceTotale")).addOrder(Order.asc("cognome")).addOrder(Order.asc("nome")).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("GraduatoriaDefinitivaHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	
	public List<GraduatoriaDefinitiva> findByElencoGraduatoria(String idRegione) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Utente instance by example");
		try {
			
//			List<Utente> results =  (List<Utente>) session.createQuery("").setString("codRegUtente", idRegione).list();
			//Query query = session.createQuery("from Utente where codRegUtente='010'");
			StringBuffer sb=new StringBuffer();
			
//			sb.append("SELECT ,, , ,U.PRV_NASCITA_UTENTE, U.LUOGO_NASCITA_ESTERA" +
					
//campi                           0                1         2                   3                     4               5            6  		    7               8                 9             10                11           12                    
			sb.append("SELECT G.ID_CANDIDATURA, G.NUMERO_PROTOCOLLO, upper(trim(G.COGNOME)), upper(trim(G.NOME)), G.PUNTEGGIO, G.DATA_NASCITA, G.ETA_MEDIA, G.COD_REGIONALE, G.INDICE_TOTALE, G.INDICE_RELATIVO, G.EXAEQUO , G.EXAEQUO_RISOLTI " +
					 " FROM GRADUATORIA_DEFINITIVA  G   " +
					 " WHERE G.COD_REGIONALE = '"+idRegione+"'" +
					 " ORDER BY upper(trim(U.COGNOME_UTENTE)), upper(trim(U.NOME_UTENTE))" );
							
			List results = session.createSQLQuery(sb.toString()).list();
			List<GraduatoriaDefinitiva> listGradDefin= new ArrayList<GraduatoriaDefinitiva>();
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				GraduatoriaDefinitiva graduatoriaDefinitiva=new GraduatoriaDefinitiva();
				Object[] row = (Object[]) iterator.next(); 
				
				graduatoriaDefinitiva.setIdCandidatura((String)row[0]);

				listGradDefin.add(graduatoriaDefinitiva);
		}
			
			return listGradDefin;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("findByElencoGraduatoria - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	
	public List<String> findByIdListGraduatoria(String idRegione) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Utente instance by example");
		try {
			
			StringBuffer sb=new StringBuffer();
//campi                           0                      1     				  2              3                                 
			sb.append("SELECT G.ID_CANDIDATURA, G.INDICE_TOTALE, upper(trim(G.COGNOME)), upper(trim(G.NOME)) " +
					 " FROM GRADUATORIA_DEFINITIVA  G   " +
					 " WHERE G.COD_REGIONALE = '"+idRegione+"'" +
					 " ORDER BY G.INDICE_TOTALE, upper(trim(G.COGNOME)), upper(trim(G.NOME))" );
							
			List results = session.createSQLQuery(sb.toString()).list();
			List<String> listId= new ArrayList<String>();
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				Object[] row = (Object[]) iterator.next(); 
				listId.add((String)row[0]);
			}
			
			return listId;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("findByElencoGraduatoria - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	
	
	public List<GraduatoriaDefinitiva> findPage(String idRegione, List<String> idCandList) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<UtenteBean> listaCandidature=new ArrayList<UtenteBean>();
	
		String inSelect ="";
		for (int i = 0; i < idCandList.size(); i++) {
			inSelect+="'"+idCandList.get(i)+"',";
		}
		inSelect=inSelect.substring(0, inSelect.length()-1)+")";
		
		String query;
		SQLQuery sqlQuery;
		
		
		try {
			
			session = HibernateUtil.openSession();
//			StringBuffer sb=new StringBuffer();
			
			List<GraduatoriaDefinitiva> graduatoriaList = new ArrayList<GraduatoriaDefinitiva>();
			BigDecimal punteggio = new BigDecimal(0);
			BigDecimal eta = new BigDecimal(0);
		
//			                      0                          1                    2                       3                    4            5             6                7                   8                9              10                11
//			sb.append("SELECT G.ID_CANDIDATURA ,  G.NUMERO_PROTOCOLLO ,  upper(trim(G.COGNOME)),  upper(trim(G.NOME)),  G.PUNTEGGIO, G.DATA_NASCITA,  G.ETA_MEDIA ,  G.COD_REGIONALE,   G.INDICE_TOTALE, G.INDICE_RELATIVO , G.EXAEQUO, G.EXAEQUO_RISOLTI"  +
//					" FROM GRADUATORIA_DEFINITIVA G " +
//					" WHERE   G.ID_CANDIDATURA IN("+inSelect +
//					" ORDER BY G.INDICE_TOTALE, upper(trim(G.COGNOME)), upper(trim(G.NOME)) ");
//			
//			List results = session.createSQLQuery(sb.toString()).list();
			query = "SELECT G.ID_CANDIDATURA ,  G.NUMERO_PROTOCOLLO ,  upper(trim(G.COGNOME)),  upper(trim(G.NOME)),  G.PUNTEGGIO, G.DATA_NASCITA,  G.ETA_MEDIA ,  G.COD_REGIONALE,   G.INDICE_TOTALE, G.INDICE_RELATIVO , G.EXAEQUO, G.EXAEQUO_RISOLTI"  +
					" FROM GRADUATORIA_DEFINITIVA G " +
					" WHERE   G.ID_CANDIDATURA IN("+inSelect +
					" ORDER BY G.INDICE_TOTALE, upper(trim(G.COGNOME)), upper(trim(G.NOME)) ";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);

			List results = sqlQuery.list();
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			
			GraduatoriaDefinitiva graduatoriaDef= null;
			
			for(Object object : results){
				graduatoriaDef = new GraduatoriaDefinitiva();
				Map row = (Map)object;
				
				graduatoriaDef.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
				graduatoriaDef.setCognome((String) row.get("COGNOME"));
				graduatoriaDef.setNome((String) row.get("NOME"));
				punteggio = (BigDecimal)row.get("PUNTEGGIO");
				graduatoriaDef.setPunteggio(punteggio);
				eta = (BigDecimal) row.get("ETA_MEDIA");
				graduatoriaDef.setEtaMedia(eta);
				graduatoriaDef.setDataNascita((String) row.get("DATA_NASCITA"));
				graduatoriaDef.setCodRegione((String) row.get("COD_REGIONALE"));
				graduatoriaDef.setIndiceTotale((BigDecimal) row.get("INDICE_TOTALE"));
				graduatoriaDef.setIndiceRelativo((BigDecimal) row.get("INDICE_RELATIVO"));
				graduatoriaDef.setExAequo((String) row.get("EXAEQUO"));
				graduatoriaDef.setExAequoRisolto((String) row.get("EXAEQUO_RISOLTI"));
				graduatoriaDef.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
				
				graduatoriaList.add(graduatoriaDef);
			}
			
			return graduatoriaList;
			
			
//			UtenteBean utenteSelezionato = null;
//			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
//				utenteSelezionato=new UtenteBean();
//				Object[] row = (Object[]) iterator.next(); 
//				utenteSelezionato.setNomeUtente(((String)row[0]).toUpperCase());
//				utenteSelezionato.setCognomeUtente(((String)row[1]!=null && (!((String)row[1]).equals(""))) ? ((String)row[1]).toUpperCase() : (String)row[1]);
////				utenteSelezionato.setDataNascita(DateUtil.sqlDateToUtilDate((Date) row[2]));
//				utenteSelezionato.setDataNascita((Timestamp) row[2]);
//				String sDenComune = Localita.getDenominazioneComune(((String)row[3]!=null && (!((String)row[3]).equals(""))) ? ((String)row[3]).toUpperCase() : (String)row[3]);
//				utenteSelezionato.setLuogoNascitaUtente((sDenComune!=null && (!sDenComune.equals(""))) ? sDenComune.toUpperCase() : sDenComune);
//				String sDenProv = Localita.getDenominazioneSiglaProvincia( (((String)row[4])!=null && (!((String)row[4]).equals(""))) ? ((String)row[4]).toUpperCase() : (String)row[4]);
//				utenteSelezionato.setProvinciaNascitaUtente((sDenProv!=null && (!sDenProv.equals(""))) ? sDenProv.toUpperCase() : sDenProv);
//				utenteSelezionato.setLuogoNascitaEsteraUtente(((String)row[5]!=null && (!((String)row[5]).equals(""))) ? ((String)row[5]).toUpperCase() : (String)row[5]);
//				utenteSelezionato.setCodiceFiscaleUtente(((String)row[6]).toUpperCase());
//				utenteSelezionato.setRegioneRichiesta(Localita.getDenominazioneRegione((String)row[7]));
//				utenteSelezionato.setIdUtente((String)row[8]);
//				String modalitaCand = (String)row[10];
//				
//				listaCandidature.add(utenteSelezionato);
//			}
//			
//			return listaCandidature;
			
		} catch (RuntimeException re) {
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}finally{
			session.close();
		}
	
	}
	
	
	
	
	
	
	public List<GraduatoriaDefinitiva> findLazyListGraduatoriaDefinitiva(String codReg,int startPage,int maxPerPage)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<GraduatoriaDefinitiva> graduatoriaList = new ArrayList<GraduatoriaDefinitiva>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
	
		//int x = startPage-10;
		//int y = maxPerPage+10;
		
		try{
			session = HibernateUtil.openSession();
			query = "select * from(select rownum as rn,numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita , COD_REGIONALE ,INDICE_TOTALE, INDICE_RELATIVO, EXAEQUO, EXAEQUO_RISOLTI ,ID_CANDIDATURA	"+
										" from GRADUATORIA_DEFINITIVA where cod_regionale='"+codReg+"'" +
					" ORDER BY punteggio DESC,eta_media ASC,cognome ASC,nome ASC)";
					//" where  rn >= '"+startPage+"'"+
					//"and rownum <='"+maxPerPage+"'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			sqlQuery.setFirstResult(startPage);
			sqlQuery.setMaxResults(maxPerPage);
			List result = sqlQuery.list();
			
			GraduatoriaDefinitiva graduatoriaDef= null;
			
			for(Object object : result){
				graduatoriaDef = new GraduatoriaDefinitiva();
				Map row = (Map)object;
				
				graduatoriaDef.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
				graduatoriaDef.setCognome((String) row.get("COGNOME"));
				graduatoriaDef.setNome((String) row.get("NOME"));
				punteggio = (BigDecimal)row.get("PUNTEGGIO");
				graduatoriaDef.setPunteggio(punteggio);
				eta = (BigDecimal) row.get("ETA_MEDIA");
				graduatoriaDef.setEtaMedia(eta);
				graduatoriaDef.setDataNascita((String) row.get("DATA_NASCITA"));
				graduatoriaDef.setCodRegione((String) row.get("COD_REGIONALE"));
				graduatoriaDef.setIndiceTotale((BigDecimal) row.get("INDICE_TOTALE"));
				graduatoriaDef.setIndiceRelativo((BigDecimal) row.get("INDICE_RELATIVO"));
				graduatoriaDef.setExAequo((String) row.get("EXAEQUO"));
				graduatoriaDef.setExAequoRisolto((String) row.get("EXAEQUO_RISOLTI"));
				graduatoriaDef.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
				
				graduatoriaList.add(graduatoriaDef);
			}
			
			return graduatoriaList;
			
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findOrderByGraduatoria: errore findByFilter");
		}finally{
			session.close();
		}
	}
	
	public int searchCount(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from GRADUATORIA_DEFINITIVA where cod_regionale='"+codReg+"'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			
			
			
			List result = sqlQuery.list();
		
			int nCount = result.size();
			//BigDecimal totalRecords = (BigDecimal)sqlQuery.uniqueResult();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}
		finally{
			session.close();
		}
		
	}

	public int searchCountValida(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from GRADUATORIA_DEFINITIVA where cod_regionale='"+codReg+"' and EXAEQUO_RISOLTI = 'F'  ";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			
			
			
			List result = sqlQuery.list();
		
			int nCount = result.size();
			//BigDecimal totalRecords = (BigDecimal)sqlQuery.uniqueResult();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}finally{
			session.close();
		}
		
		
	}
	
	public List<GraduatoriaDefinitiva> findOrderByGraduatoria(String codReg)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<GraduatoriaDefinitiva> graduatoriaList = new ArrayList<GraduatoriaDefinitiva>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
	
		try{
		session = HibernateUtil.openSession();
		query = "select * from(select rownum as rn,id_candidatura,cod_regionale,numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita from graduatoria_definitiva where cod_regionale='"+codReg+"'" +
				" ORDER BY punteggio DESC,eta_media ASC,cognome ASC,nome ASC)";
				
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		List result = sqlQuery.list();
		
		GraduatoriaDefinitiva graduatoria= null;
		
		for(Object object : result){
			graduatoria = new GraduatoriaDefinitiva();
			Map row = (Map)object;
			graduatoria.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
			graduatoria.setCognome((String) row.get("COGNOME"));
			graduatoria.setNome((String) row.get("NOME"));
			punteggio = (BigDecimal)row.get("PUNTEGGIO");
			graduatoria.setPunteggio(punteggio);
			eta = (BigDecimal) row.get("ETA_MEDIA");
			graduatoria.setEtaMedia(eta);
			graduatoria.setDataNascita((String) row.get("DATA_NASCITA"));
			graduatoria.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
			graduatoria.setCodRegione((String) row.get("COD_REGIONALE"));
			graduatoriaList.add(graduatoria);
		}
		
		return graduatoriaList;
		
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findOrderByGraduatoria: errore findByFilter");
		}finally{
			session.close();
		}
	}
	
}
