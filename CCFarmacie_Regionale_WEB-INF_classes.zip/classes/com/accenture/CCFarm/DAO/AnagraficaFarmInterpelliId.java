package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;

public class AnagraficaFarmInterpelliId implements java.io.Serializable {

	private String codRegFarm;
	private BigDecimal idInterpello;
	private String idFarm;

	public AnagraficaFarmInterpelliId() {
	}
	
	public AnagraficaFarmInterpelliId(String codRegFarm,
			BigDecimal idInterpello, String idFarm) {
		this.codRegFarm = codRegFarm;
		this.idInterpello = idInterpello;
		this.idFarm = idFarm;
	}

	public String getCodRegFarm() {
		return codRegFarm;
	}

	public void setCodRegFarm(String codRegFarm) {
		this.codRegFarm = codRegFarm;
	}

	public BigDecimal getIdInterpello() {
		return idInterpello;
	}

	public void setIdInterpello(BigDecimal idInterpello) {
		this.idInterpello = idInterpello;
	}

	public String getIdFarm() {
		return idFarm;
	}

	public void setIdFarm(String idFarm) {
		this.idFarm = idFarm;
	}

}
