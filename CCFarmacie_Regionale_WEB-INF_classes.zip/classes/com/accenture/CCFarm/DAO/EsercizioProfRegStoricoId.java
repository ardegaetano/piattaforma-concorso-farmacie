package com.accenture.CCFarm.DAO;


public class EsercizioProfRegStoricoId implements java.io.Serializable {

	private String idStorico;
	private String idEsercizio;
	
	public EsercizioProfRegStoricoId(){
		
	}
	
	public EsercizioProfRegStoricoId(String idStorico, String idEsercizio){
		this.idStorico = idStorico;
		this.idEsercizio = idEsercizio;
	}

	public String getIdStorico() {
		return idStorico;
	}

	public void setIdStorico(String idStorico) {
		this.idStorico = idStorico;
	}

	public String getIdEsercizio() {
		return idEsercizio;
	}

	public void setIdEsercizio(String idEsercizio) {
		this.idEsercizio = idEsercizio;
	}

	
}