package com.accenture.CCFarm.DAO;
// default package
// Generated Dec 3, 2012 12:08:19 PM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.PrintException;

/**
 * Home object for domain model class ValutazioneEsercizioProf.
 * @see .ValutazioneEsercizioProf
 * @author Hibernate Tools
 */
public class ValutazioneEsercizioProfHome {
	private static final Logger log = CommonLogger.getLogger("AnnullaDomandeScaduteBatch");
	/*private static final Log log = LogFactory
			.getLog(ValutazioneEsercizioProfHome.class);

	private final SessionFactory sessionFactory = getSessionFactory();

	protected SessionFactory getSessionFactory() {
		try {
			return (SessionFactory) new InitialContext()
					.lookup("SessionFactory");
		} catch (Exception e) {
			log.error("Could not locate SessionFactory in JNDI", e);
			throw new IllegalStateException(
					"Could not locate SessionFactory in JNDI");
		}
	}
*/
	/*public void persist(ValutazioneEsercizioProf transientInstance) {
		log.debug("persisting ValutazioneEsercizioProf instance");
		try {
			sessionFactory.getCurrentSession().persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}*/
	
	public void saveOrUpdate(ValutazioneEsercizioProf instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attachingDirty ValutazioneEsercizioProf instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw new GestioneErroriException("ValutazioneEsercizioProf - saveOrUpdate: errore saveOrUpdate");
		}finally{
			session.close();
		}
	}

	/*public void attachDirty(ValutazioneEsercizioProf instance) {
		log.debug("attaching dirty ValutazioneEsercizioProf instance");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(ValutazioneEsercizioProf instance) {
		log.debug("attaching clean ValutazioneEsercizioProf instance");
		try {
			sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}*/

	public void delete(ValutazioneEsercizioProf persistentInstance) throws GestioneErroriException{
		log.debug("deleting ValutazioneEsercizioProf instance");
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
			
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			trx.rollback();
			throw new GestioneErroriException("ValutazioneEsercizioProf - findByExample");
		} finally{
			session.close();
		}
	}

	/*public ValutazioneEsercizioProf merge(
			ValutazioneEsercizioProf detachedInstance) {
		log.debug("merging ValutazioneEsercizioProf instance");
		try {
			ValutazioneEsercizioProf result = (ValutazioneEsercizioProf) sessionFactory
					.getCurrentSession().merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}
*/
	public ValutazioneEsercizioProf findById(ValutazioneEsercizioProfId id) throws GestioneErroriException{
		log.debug("getting ValutazioneEsercizioProf instance with id: " + id);
		Session session = HibernateUtil.openSession();
		try {
			ValutazioneEsercizioProf instance = (ValutazioneEsercizioProf) session.get("com.accenture.CCFarm.DAO.ValutazioneEsercizioProf", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("ValutazioneEsercizioProf - findByExample");
		}finally{
			session.close();
		}
	}

	public List findByExample(ValutazioneEsercizioProf instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding ValutazioneEsercizioProf instance by example");
		try {
			List results = session.createCriteria("com.accenture.CCFarm.DAO.ValutazioneEsercizioProf")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("ValutazioneEsercizioProf - findByExample");
			
		} finally{
			session.close();
		}

	}
	
	public String getSequenceIdEsercizioProfessionale()  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_ESERCIZIO_PROFESSIONALE.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("getSequenceIdEsercizioProfessionale() - "+ PrintException.stack2string(re));
			throw new GestioneErroriException("EsercizioProfHome - getSequenceIdEsercizioProfessionale: errore getSequenceIdEsercizioProfessionale");
		}
		finally{
			session.close();
		}
	}
	
}
