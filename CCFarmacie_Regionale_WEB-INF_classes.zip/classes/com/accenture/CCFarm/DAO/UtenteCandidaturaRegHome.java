package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.accenture.CCFarm.CalcolaPunteggiCandidati.PunteggioCandidato;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.LogUtil;

/**
 * Home object for domain model class UtenteCandidaturaHome
 * 
 * @see com.accenture.CCFarm.DAO.UtenteCandidaturaRegHome
 * @author Hibernate Tools
 */
public class UtenteCandidaturaRegHome {

	private static final Log log = LogFactory.getLog("UtenteCandidaturaRegHome");

	public Object findCountByQuery(String query) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("findCountByQuery inizio");
		try {
			Object nCount = session.createQuery(query).list();
			log.debug("findCountByQuery successful, result size: " + nCount.toString());
			return nCount;
		} catch (RuntimeException re) {
			log.error("findCountByQuery failed", re);
			LogUtil.printException(re);
			GestioneErroriException eccezione = new GestioneErroriException("UtenteRegCandidaturaHome - findCountByQuery: errore nella findCountByQuery di UtenteCandidaturaHome");
			LogUtil.printException(eccezione);
			throw eccezione;
		} finally {
			session.close();
		}
	}

	public List<UtenteCandidaturaReg> findUtenteCandidaturaByQuery(String idCandidatura) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding UtenteCandidatura instance by sqlquery");

		try {
			List<UtenteCandidaturaReg> uteCandidaturaList = new ArrayList<UtenteCandidaturaReg>();
			SQLQuery query = session.createSQLQuery("select u.nome_utente,u.cognome_utente,c.id_utente,c.referente_domanda from candidatura_reg c, utente_reg u where id_candidatura = '" + idCandidatura + "' and c.id_utente = u.id_utente order by c.referente_domanda desc");
			// query.setParameter("id_candidatura", "'"+idCandidatura+"'");
			// query.setString("ID_CANDIDATURA", idCandidatura);

			query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);

			for (Object object : query.list()) {
				Map row = (Map) object;
				Candidatura candidatura = new Candidatura();
				candidatura.setIdCandidatura(idCandidatura);
				UtenteCandidaturaReg utenteCandidatura = new UtenteCandidaturaReg();
				utenteCandidatura.setIdUtente((String) row.get("ID_UTENTE"));
				utenteCandidatura.setNomeUtente((String) row.get("NOME_UTENTE"));
				utenteCandidatura.setCognomeUtente((String) row.get("COGNOME_UTENTE"));
				candidatura.setReferenteDomanda((String) row.get("REFERENTE_DOMANDA"));

				utenteCandidatura.setCandidatura(candidatura);
				uteCandidaturaList.add(utenteCandidatura);
			}

			return uteCandidaturaList;
		} catch (RuntimeException re) {

			throw new GestioneErroriException(re);
		} finally {
			session.close();
		}

	}

	public UtenteCandidaturaReg findById(java.lang.String id) {
		Session session = HibernateUtil.openSession();
		log.debug("getting Utente instance with id: " + id);
		try {
			UtenteCandidaturaReg instance = (UtenteCandidaturaReg) session.get("com.accenture.CCFarm.DAO.UtenteCandidaturaReg", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		} finally {
			session.close();
		}
	}

	//
	// public List findByExample(UtenteCandidatura instance)
	// throws GestioneErroriException {
	// Session session = HibernateUtil.openSession();
	// log.debug("finding Utente instance by example");
	// try {
	// List results = session
	// .createCriteria(
	// "com.accenture.CCFarm.DAO.UtenteCandidatura")
	// .add(Example.create(instance)).list();
	// log.debug("find by example successful, result size: "
	// + results.size());
	// return results;
	// } catch (RuntimeException re) {
	// log.error("find by example failed", re);
	// LogUtil.printException(re);
	// GestioneErroriException eccezione = new GestioneErroriException(
	// "UtenteCandidaturaHome - findByExample: errore nella findByExample di UtenteCandidatura");
	// LogUtil.printException(eccezione);
	// throw eccezione;
	// } finally {
	// session.close();
	// }
	// }
	//
	/*
	 * public void inserisciDomanda(DomandaDao domanda) throws
	 * GestioneErroriException {
	 * 
	 * Session session = HibernateUtil.openSession(); try { boolean bRet =
	 * bAggiornaDomanda(domanda, session); //salvataggio della domanda if(bRet){
	 * boolean bPunteggiOk = bCalcolaPunteggiCandidatura(domanda, session);
	 * if(bPunteggiOk) ripristinoFlag(domanda, session); } } finally {
	 * session.close(); }
	 * 
	 * }
	 */

	
	public boolean bAggiornaDomanda_newB(DomandaDao domanda, String idUserLoggato)
			throws GestioneErroriException {
		
		boolean bRet = true;
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");
		try {
			java.util.Date dataSys= new java.util.Date();
			java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
			
			String idDomanda = domanda.getUtenteCandidatura().getIdUtente();
			Query query;
			String sIdStorico = getSequenceIdStorico();
			if (domanda.getUtenteCandidatura() != null) {
				session.saveOrUpdate(domanda.getUtenteCandidatura());
				//STORICO
				UtenteCandidaturaRegStorico strUtenteCandidaturaReg = new UtenteCandidaturaRegStorico();
				PropertyUtils.copyProperties(strUtenteCandidaturaReg, domanda.getUtenteCandidatura());
				strUtenteCandidaturaReg.setIdStorico(sIdStorico);
				strUtenteCandidaturaReg.setMiUtente(idUserLoggato);
				strUtenteCandidaturaReg.setDataUltimaModifica(oggi);
				session.saveOrUpdate(strUtenteCandidaturaReg);
			}
				
			if (domanda.getRequisitiMinimi() != null) {
				session.saveOrUpdate(domanda.getRequisitiMinimi());
				//STORICO
				RequisitiMinimiRegStorico strReqMinReg = new RequisitiMinimiRegStorico();
				PropertyUtils.copyProperties(strReqMinReg, domanda.getRequisitiMinimi());
				strReqMinReg.setIdStorico(sIdStorico);
				strReqMinReg.setMiUtente(idUserLoggato);
				strReqMinReg.setDataUltimaModifica(oggi);
				session.saveOrUpdate(strReqMinReg);
			}
			if (domanda.getIdoneita() != null){
				IdoneitaReg idoneitaReg = new IdoneitaReg();
				IdoneitaRegHome idoneitaRegHome = new IdoneitaRegHome();
				idoneitaReg = idoneitaRegHome.findById(idDomanda);
				domanda.getIdoneita().setPunteggio(idoneitaReg.getPunteggio());
				domanda.getIdoneita().setPunteggioNaz(idoneitaReg.getPunteggioNaz());
				session.saveOrUpdate(idoneitaReg);
				//STORICO
				IdoneitaRegStorico strIdoneitaReg = new IdoneitaRegStorico();
				PropertyUtils.copyProperties(strIdoneitaReg, idoneitaReg);
				strIdoneitaReg.setIdStorico(sIdStorico);
				strIdoneitaReg.setMiUtente(idUserLoggato);
				strIdoneitaReg.setDataUltimaModifica(oggi);
				session.saveOrUpdate(strIdoneitaReg);
			} 
				
			
			//Query query = session.createQuery("Delete AltraLaureaReg where idDomandaLaurea ='" + idDomanda +"'");
			//query.executeUpdate();
			/*
			if (domanda.getAltraLaurea() != null && domanda.getAltraLaurea().getDescUniSecondaLaurea()!= null && !domanda.getAltraLaurea().getDescUniSecondaLaurea().equals("")){	 
				session.saveOrUpdate(domanda.getAltraLaurea());
			}	
			if (domanda.getDichiarazioneSostitutiva() != null){
				domanda.getDichiarazioneSostitutiva().setElencoDocumenti("");
				session.saveOrUpdate(domanda.getDichiarazioneSostitutiva());
			}
							
			
			// cancella tutti i record relativi all'idUtente specificato
			AltroTitoloReg altroTitoloDel = new AltroTitoloReg();
			altroTitoloDel.setIdDomandaTitolo(idDomanda);
			query = session.createQuery("Delete AltroTitoloReg where idDomandaTitolo ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<AltroTitoloReg> listaAltroTitolo = domanda.getListaAltroTitolo();
			AltroTitoloReg altroTitolo = null;
			for (int i = 0; i < listaAltroTitolo.size(); i++) {
				altroTitolo = listaAltroTitolo.get(i);
				session.saveOrUpdate(altroTitolo);
			}

			// cancella tutti i record relativi all'idUtente specificato
			BorsaStudioReg borsaStudioDel = new BorsaStudioReg();
			borsaStudioDel.setIdDomandaBorsaStudio(idDomanda);
			query = session.createQuery("Delete BorsaStudioReg where idDomandaBorsaStudio ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<BorsaStudioReg> listaBorsaStudio = domanda.getListaBorsaStudio();
			BorsaStudioReg borsaStudio = null;
			for (int i = 0; i < listaBorsaStudio.size(); i++) {
				borsaStudio = listaBorsaStudio.get(i);
				session.saveOrUpdate(borsaStudio);
			}

			// cancella tutti i record relativi all'idUtente specificato
			CorsoAggiornamentoReg corsoAggiornamentoDel = new CorsoAggiornamentoReg();
			corsoAggiornamentoDel.setIdDomandaAgg(idDomanda);
			query = session.createQuery("Delete CorsoAggiornamentoReg where idDomandaAgg ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<CorsoAggiornamentoReg> listaCorsoAggiornamento = domanda.getListaCorsoAggiornamento();
			CorsoAggiornamentoReg corsoAggiornamento;
			for (int i = 0; i < listaCorsoAggiornamento.size(); i++) {
				corsoAggiornamento = listaCorsoAggiornamento.get(i);
				session.saveOrUpdate(corsoAggiornamento);

			}

			// cancella tutti i record relativi all'idUtente specificato
			DottoratoReg dottoratoDel = new DottoratoReg();
			dottoratoDel.setIdDomandaDottorato(idDomanda);
			query = session.createQuery("Delete DottoratoReg where idDomandaDottorato ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<DottoratoReg> listaDottorato = domanda.getListaDottorato();
			DottoratoReg dottorato = null;
			for (int i = 0; i < listaDottorato.size(); i++) {
				dottorato = listaDottorato.get(i);
				session.saveOrUpdate(dottorato);
			}

			// cancella tutti i record relativi all'idUtente specificato
			PubblicazioneReg pubblicazioneDel = new PubblicazioneReg();
			pubblicazioneDel.setIdDomandaPubbl(idDomanda);
			query = session.createQuery("Delete PubblicazioneReg where idDomandaPubbl ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<PubblicazioneReg> listaPubblicazioni = domanda.getListaPubblicazione();
			PubblicazioneReg pubblicazione = null;
			for (int i = 0; i < listaPubblicazioni.size(); i++) {
				pubblicazione = listaPubblicazioni.get(i);
				session.saveOrUpdate(pubblicazione);
			}

			// cancella tutti i record relativi all'idUtente specificato
			SpecializzazioneReg specializzazioneDel = new SpecializzazioneReg();
			specializzazioneDel.setIdDomandaSpec(idDomanda);
			query = session.createQuery("Delete SpecializzazioneReg where idDomandaSpec ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<SpecializzazioneReg> listaSpecializzazioni = domanda.getListaSpecializzazione();
			SpecializzazioneReg specializzazione = null;
			for (int i = 0; i < listaSpecializzazioni.size(); i++) {
				specializzazione = listaSpecializzazioni.get(i);
				session.saveOrUpdate(specializzazione);
			}*/

			/*if (domanda.getAltraLaurea() != null && domanda.getAltraLaurea().getDescUniSecondaLaurea()!= null && !domanda.getAltraLaurea().getDescUniSecondaLaurea().equals("")){	 
				session.saveOrUpdate(domanda.getAltraLaurea());
			}	*/
			if (domanda.getDichiarazioneSostitutiva() != null){
				domanda.getDichiarazioneSostitutiva().setElencoDocumenti("");
				session.saveOrUpdate(domanda.getDichiarazioneSostitutiva());
				//STORICO
				DichiarazioneSostitutivaRegStorico strDichSostReg = new DichiarazioneSostitutivaRegStorico();
				PropertyUtils.copyProperties(strDichSostReg, domanda.getDichiarazioneSostitutiva());
				strDichSostReg.setIdStorico(sIdStorico);
				strDichSostReg.setMiUtente(idUserLoggato);
				strDichSostReg.setDataUltimaModifica(oggi);
				session.saveOrUpdate(strDichSostReg);
			}
			
			//cancella tutti i record relativi all'idUtente specificato
						/*AltraLaureaBisReg altraLaureaBisDel = new AltraLaureaBisReg();
						altraLaureaBisDel.setIdDomandaLaureaBis(idDomanda);
						query = session.createQuery("Delete AltraLaureaBisReg where idDomandaLaureaBis ='" + idDomanda +"'");
						query.executeUpdate();

						ArrayList<AltraLaureaBisReg> listaAltraLaureaBis = domanda.getListaAltraLaureaBis();
						AltraLaureaBisReg altraLaurea = null;
						for (int i = 0; i < listaAltraLaureaBis.size(); i++) {
							altraLaurea = listaAltraLaureaBis.get(i);
							session.saveOrUpdate(altraLaurea);
						}*/

			//gestione documenti da inviare
//        	if(domanda.getListaDocumenti()!=null && domanda.getListaDocumenti().size()>0 ){
//        		
//        		//cancello i docuemnti esistenti in tabella
//    			query = session.createQuery("Delete DocumentoReg where idDomandaDocumento ='" + idDomanda +"'");
//    			query.executeUpdate();
//    			
//    			ArrayList<DocumentoReg> listaDocumenti = domanda.getListaDocumenti();
//    			DocumentoReg documento = null;
//    			for (int i = 0; i < listaDocumenti.size(); i++) {
//    				documento = listaDocumenti.get(i);
//    				session.saveOrUpdate(documento);
//    			}
//        		
//        	}
//        	else { 
//        		//Controlla se i documenti non ci sono elimina su DB eventuali Doc salvati in precedenza
//        		query = session.createQuery("Delete DocumentoReg where idDomandaDocumento ='" + idDomanda +"'");
//    			query.executeUpdate();
//    			log.info("Documento Eliminato per la domanda:"+ idDomanda);
//        	}
			// cancella tutti i record relativi all'idUtente specificato
			EsercizioProfReg esercizioProfDel = new EsercizioProfReg();
			esercizioProfDel.setIdDomandaEs(idDomanda);
			query = session.createQuery("Delete EsercizioProfReg where idDomandaEs ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<EsercizioProfReg> listaEsercizioProf = domanda.getListaEserciziProf();
			EsercizioProfReg esercizioProf = null;
			for (int i = 0; i < listaEsercizioProf.size(); i++) {
				esercizioProf = listaEsercizioProf.get(i);
				session.saveOrUpdate(esercizioProf);
				//STORICO
				EsercizioProfRegStorico strEsercizioProfReg = new EsercizioProfRegStorico();
				PropertyUtils.copyProperties(strEsercizioProfReg, esercizioProf);
				EsercizioProfRegStoricoId idStrEsProf = new EsercizioProfRegStoricoId(sIdStorico, esercizioProf.getIdEsercizio());
				strEsercizioProfReg.setId(idStrEsProf);
				strEsercizioProfReg.setMiUtente(idUserLoggato);
				strEsercizioProfReg.setDataUltimaModifica(oggi);
				session.saveOrUpdate(strEsercizioProfReg);
			}
			
			//Aggiornamento flag 
			CandidaturaReg candidaturaReg = domanda.getCandidaturaReg();
			candidaturaReg.setElabRettifica("Y");
			//candidaturaReg.setElabAutomatica("F"); 
			candidaturaReg.setLastUpdateDate(oggi);
			session.saveOrUpdate(candidaturaReg);
			//STORICO
			CandidaturaRegStorico strCandidaturaReg = new CandidaturaRegStorico();
			PropertyUtils.copyProperties(strCandidaturaReg, candidaturaReg);
			strCandidaturaReg.setIdStorico(sIdStorico);
			strCandidaturaReg.setMiUtente(idUserLoggato);
			strCandidaturaReg.setDataUltimaModifica(oggi);
			session.saveOrUpdate(strCandidaturaReg);
			
			
			/*String codiceRegione = domanda.getUtenteCandidatura().getCodRegUtente();
			
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			DatiBando datiBando = datiBandoHome.findById(codiceRegione);
			datiBando.setFlgPrecalcolato("false");
			session.saveOrUpdate(datiBando);
			*/
			
			//Elimina il record di candidatura dalla Graduatoria
//			query = session.createQuery("Delete Graduatoria where idCandidatura ='" + domanda.getCandidaturaReg().getIdCandidatura() +"'");
//			query.executeUpdate();
			
			
			trx.commit();
			log.info("Salvataggio della domanda avvenuto con successo per la candidatura:"
					+ domanda.getCandidaturaReg().getIdCandidatura());
		} catch (Exception e) {
			bRet = false;
			log.fatal("UtenteCandidaturaRegHome inserisciDomanda failed", e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"UtenteCandidaturaRegHome - inserisciDomanda: errore nell' inserimento della domanda",
					e);
			throw eccezione;
		}
		finally {
			session.close();
		}
		return bRet;
	}
	
	
	public boolean bAggiornaDomanda(DomandaDao domanda) throws GestioneErroriException {

		boolean bRet = true;
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");
		try {
			String idDomanda = domanda.getUtenteCandidatura().getIdUtente();

			if (domanda.getUtenteCandidatura() != null)
				session.saveOrUpdate(domanda.getUtenteCandidatura());

			if (domanda.getRequisitiMinimi() != null)
				session.saveOrUpdate(domanda.getRequisitiMinimi());

			if (domanda.getIdoneita() != null){
				IdoneitaReg idoneitaReg = new IdoneitaReg();
				IdoneitaRegHome idoneitaRegHome = new IdoneitaRegHome();
				idoneitaReg = idoneitaRegHome.findById(idDomanda);
				domanda.getIdoneita().setPunteggio(idoneitaReg.getPunteggio());
				domanda.getIdoneita().setPunteggioNaz(idoneitaReg.getPunteggioNaz());
				session.saveOrUpdate(idoneitaReg);
			} 
				

			Query query = session.createQuery("Delete AltraLaureaReg where idDomandaLaurea ='" + idDomanda + "'");
			query.executeUpdate();
			if (domanda.getAltraLaurea() != null && domanda.getAltraLaurea().getDescUniSecondaLaurea() != null && !domanda.getAltraLaurea().getDescUniSecondaLaurea().equals("")) {
				session.saveOrUpdate(domanda.getAltraLaurea());
			}
			if (domanda.getDichiarazioneSostitutiva() != null) {
				domanda.getDichiarazioneSostitutiva().setElencoDocumenti("");
				session.saveOrUpdate(domanda.getDichiarazioneSostitutiva());
			}

			// gestione documenti da inviare
			if (domanda.getListaDocumenti() != null && domanda.getListaDocumenti().size() > 0) {

				// cancello i docuemnti esistenti in tabella
				query = session.createQuery("Delete DocumentoReg where idDomandaDocumento ='" + idDomanda + "'");
				query.executeUpdate();

				ArrayList<DocumentoReg> listaDocumenti = domanda.getListaDocumenti();
				DocumentoReg documento = null;
				for (int i = 0; i < listaDocumenti.size(); i++) {
					documento = listaDocumenti.get(i);
					session.saveOrUpdate(documento);
				}

			} else {
				// Controlla se i documenti non ci sono elimina su DB eventuali
				// Doc salvati in precedenza
				query = session.createQuery("Delete DocumentoReg where idDomandaDocumento ='" + idDomanda + "'");
				query.executeUpdate();
				log.info("Documento Eliminato per la domanda:" + idDomanda);
			}

			// cancella tutti i record relativi all'idUtente specificato
			AltraLaureaBisReg altraLaureaBisDel = new AltraLaureaBisReg();
			altraLaureaBisDel.setIdDomandaLaureaBis(idDomanda);
			query = session.createQuery("Delete AltraLaureaBisReg where idDomandaLaureaBis ='" + idDomanda + "'");
			query.executeUpdate();

			ArrayList<AltraLaureaBisReg> listaAltraLaureaBis = domanda.getListaAltraLaureaBis();
			AltraLaureaBisReg altraLaurea = null;
			for (int i = 0; i < listaAltraLaureaBis.size(); i++) {
				altraLaurea = listaAltraLaureaBis.get(i);
				session.saveOrUpdate(altraLaurea);
			}

			// cancella tutti i record relativi all'idUtente specificato
			AltroTitoloReg altroTitoloDel = new AltroTitoloReg();
			altroTitoloDel.setIdDomandaTitolo(idDomanda);
			query = session.createQuery("Delete AltroTitoloReg where idDomandaTitolo ='" + idDomanda + "'");
			query.executeUpdate();

			ArrayList<AltroTitoloReg> listaAltroTitolo = domanda.getListaAltroTitolo();
			AltroTitoloReg altroTitolo = null;
			for (int i = 0; i < listaAltroTitolo.size(); i++) {
				altroTitolo = listaAltroTitolo.get(i);
				session.saveOrUpdate(altroTitolo);
			}

			// cancella tutti i record relativi all'idUtente specificato
			BorsaStudioReg borsaStudioDel = new BorsaStudioReg();
			borsaStudioDel.setIdDomandaBorsaStudio(idDomanda);
			query = session.createQuery("Delete BorsaStudioReg where idDomandaBorsaStudio ='" + idDomanda + "'");
			query.executeUpdate();

			ArrayList<BorsaStudioReg> listaBorsaStudio = domanda.getListaBorsaStudio();
			BorsaStudioReg borsaStudio = null;
			for (int i = 0; i < listaBorsaStudio.size(); i++) {
				borsaStudio = listaBorsaStudio.get(i);
				session.saveOrUpdate(borsaStudio);
			}

			// cancella tutti i record relativi all'idUtente specificato
			CorsoAggiornamentoReg corsoAggiornamentoDel = new CorsoAggiornamentoReg();
			corsoAggiornamentoDel.setIdDomandaAgg(idDomanda);
			query = session.createQuery("Delete CorsoAggiornamentoReg where idDomandaAgg ='" + idDomanda + "'");
			query.executeUpdate();

			ArrayList<CorsoAggiornamentoReg> listaCorsoAggiornamento = domanda.getListaCorsoAggiornamento();
			CorsoAggiornamentoReg corsoAggiornamento;
			for (int i = 0; i < listaCorsoAggiornamento.size(); i++) {
				corsoAggiornamento = listaCorsoAggiornamento.get(i);
				session.saveOrUpdate(corsoAggiornamento);

			}

			// cancella tutti i record relativi all'idUtente specificato
			DottoratoReg dottoratoDel = new DottoratoReg();
			dottoratoDel.setIdDomandaDottorato(idDomanda);
			query = session.createQuery("Delete DottoratoReg where idDomandaDottorato ='" + idDomanda + "'");
			query.executeUpdate();

			ArrayList<DottoratoReg> listaDottorato = domanda.getListaDottorato();
			DottoratoReg dottorato = null;
			for (int i = 0; i < listaDottorato.size(); i++) {
				dottorato = listaDottorato.get(i);
				session.saveOrUpdate(dottorato);
			}

			// cancella tutti i record relativi all'idUtente specificato
			PubblicazioneReg pubblicazioneDel = new PubblicazioneReg();
			pubblicazioneDel.setIdDomandaPubbl(idDomanda);
			query = session.createQuery("Delete PubblicazioneReg where idDomandaPubbl ='" + idDomanda + "'");
			query.executeUpdate();

			ArrayList<PubblicazioneReg> listaPubblicazioni = domanda.getListaPubblicazione();
			PubblicazioneReg pubblicazione = null;
			for (int i = 0; i < listaPubblicazioni.size(); i++) {
				pubblicazione = listaPubblicazioni.get(i);
				session.saveOrUpdate(pubblicazione);
			}

			// cancella tutti i record relativi all'idUtente specificato
			SpecializzazioneReg specializzazioneDel = new SpecializzazioneReg();
			specializzazioneDel.setIdDomandaSpec(idDomanda);
			query = session.createQuery("Delete SpecializzazioneReg where idDomandaSpec ='" + idDomanda + "'");
			query.executeUpdate();

			ArrayList<SpecializzazioneReg> listaSpecializzazioni = domanda.getListaSpecializzazione();
			SpecializzazioneReg specializzazione = null;
			for (int i = 0; i < listaSpecializzazioni.size(); i++) {
				specializzazione = listaSpecializzazioni.get(i);
				session.saveOrUpdate(specializzazione);
			}

			// cancella tutti i record relativi all'idUtente specificato
			EsercizioProfReg esercizioProfDel = new EsercizioProfReg();
			esercizioProfDel.setIdDomandaEs(idDomanda);
			query = session.createQuery("Delete EsercizioProfReg where idDomandaEs ='" + idDomanda + "'");
			query.executeUpdate();

			ArrayList<EsercizioProfReg> listaEsercizioProf = domanda.getListaEserciziProf();
			EsercizioProfReg esercizioProf = null;
			for (int i = 0; i < listaEsercizioProf.size(); i++) {
				esercizioProf = listaEsercizioProf.get(i);
				session.saveOrUpdate(esercizioProf);
			}

			// Aggiornamento flag
			java.util.Date dataSys = new java.util.Date();
			java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
			CandidaturaReg candidaturaReg = domanda.getCandidaturaReg();
			candidaturaReg.setElabRettifica("Y");
			// candidaturaReg.setElabAutomatica("F");
			candidaturaReg.setLastUpdateDate(oggi);
			session.saveOrUpdate(candidaturaReg);

			/*
			 * String codiceRegione =
			 * domanda.getUtenteCandidatura().getCodRegUtente();
			 * 
			 * DatiBandoHome datiBandoHome = new DatiBandoHome(); DatiBando
			 * datiBando = datiBandoHome.findById(codiceRegione);
			 * datiBando.setFlgPrecalcolato("false");
			 * session.saveOrUpdate(datiBando);
			 */

			// Elimina il record di candidatura dalla Graduatoria
			query = session.createQuery("Delete Graduatoria where idCandidatura ='" + domanda.getCandidaturaReg().getIdCandidatura() + "'");
			query.executeUpdate();

			trx.commit();
			log.info("Salvataggio della domanda avvenuto con successo per la candidatura:" + domanda.getCandidaturaReg().getIdCandidatura());
		} catch (Exception e) {
			bRet = false;
			log.fatal("UtenteCandidaturaRegHome inserisciDomanda failed", e);
			GestioneErroriException eccezione = new GestioneErroriException("UtenteCandidaturaRegHome - inserisciDomanda: errore nell' inserimento della domanda", e);
			throw eccezione;
		} finally {
			session.close();
		}
		return bRet;
	}
	
	/*public boolean bCalcolaPunteggiCandidatura(DomandaDao domanda)
	{
		DatiBando datiBando = new  DatiBando();
		DatiBandoHome datiBandoHome = new DatiBandoHome();
		
		
		boolean bRet = true;
		Session session = null;
		CandidaturaReg candidaturaReg = domanda.getCandidaturaReg();
		Transaction trx = null;
		try {
            UtenteCandidaturaRegHome utenteCandidaturaHome = new UtenteCandidaturaRegHome();
            ArrayList<UtenteCandidaturaReg> candidature = new ArrayList<UtenteCandidaturaReg>();
            datiBando = datiBandoHome.findById(domanda.getCandidaturaReg().getCodiceRegione());
            candidature = (ArrayList<UtenteCandidaturaReg>) utenteCandidaturaHome.findUtenteCandidaturaByQuery(candidaturaReg.getIdCandidatura());

            for (UtenteCandidaturaReg utente: candidature){
            	session = HibernateUtil.openSession();
            	trx = session.beginTransaction();
            	
            	CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
            	candidaturaReg = candidaturaRegHome.findById(utente.getIdUtente());
            	candidaturaReg.setIdUtente(utente.getIdUtente());
            	candidaturaReg.setErroreElabAutomatica("F");
            	new PunteggioCandidato().calcolaGraduatoriaUtente(utente.getIdUtente(),candidaturaReg.getCodiceRegione(), datiBando, session);
            	session.saveOrUpdate(candidaturaReg);
            	trx.commit();
            	//session.close();
            }
            
            log.info("Calcolo Punteggi avvenuto con successo per la candidatura:"
				+ domanda.getCandidaturaReg().getIdCandidatura());

		} catch (Exception e) {
			bRet = false;
			log.fatal("bCalcolaPunteggiCandidatura failed", e);
			candidaturaReg.setErroreElabAutomatica("T");
			session.saveOrUpdate(candidaturaReg);
			trx.commit();
		}
		finally {
			session.close();
		}
		return bRet;
			
	}*/

	public boolean bCalcolaPunteggiCandidatura_new(DomandaDao domanda, String idUserLoggato) {
		DatiBando datiBando = new DatiBando();
		DatiBandoHome datiBandoHome = new DatiBandoHome();

		boolean bRet = true;
		Session session = null;
		CandidaturaReg candidaturaReg = domanda.getCandidaturaReg();

		Transaction trx = null;
		try {
			String sIdStorico = getSequenceIdStorico();
			java.util.Date dataSys= new java.util.Date();
			java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
			UtenteCandidaturaRegHome utenteCandidaturaHome = new UtenteCandidaturaRegHome();
			ArrayList<UtenteCandidaturaReg> candidature = new ArrayList<UtenteCandidaturaReg>();
			datiBando = datiBandoHome.findById(domanda.getCandidaturaReg().getCodiceRegione());
			// candidature = (ArrayList<UtenteCandidaturaReg>)
			// utenteCandidaturaHome.findUtenteCandidaturaByQuery(candidaturaReg.getIdCandidatura());
			UtenteCandidaturaReg utente = utenteCandidaturaHome.findById(domanda.getCandidaturaReg().getIdUtente());

			session = HibernateUtil.openSession();
			trx = session.beginTransaction();

			candidaturaReg.setIdUtente(utente.getIdUtente());
			candidaturaReg.setErroreElabAutomatica("F");
			new PunteggioCandidato().calcolaGraduatoriaUtente(utente.getIdUtente(), utente.getCodRegUtente(), datiBando, session, sIdStorico, idUserLoggato, oggi);
			session.saveOrUpdate(candidaturaReg);
			//STORICO
			CandidaturaRegStorico candidaturaRegStr = new CandidaturaRegStorico();
			PropertyUtils.copyProperties(candidaturaRegStr, candidaturaReg);
			candidaturaRegStr.setIdStorico(sIdStorico);
			candidaturaRegStr.setMiUtente(idUserLoggato);
			candidaturaRegStr.setDataUltimaModifica(oggi);
			session.saveOrUpdate(candidaturaRegStr);
			
			trx.commit();

			/*
			 * for (UtenteCandidaturaReg utente: candidature){ session =
			 * HibernateUtil.openSession(); trx = session.beginTransaction();
			 * 
			 * CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
			 * candidaturaReg =
			 * candidaturaRegHome.findById(utente.getIdUtente());
			 * candidaturaReg.setIdUtente(utente.getIdUtente());
			 * candidaturaReg.setErroreElabAutomatica("F"); new
			 * PunteggioCandidato
			 * ().calcolaGraduatoriaUtente(utente.getIdUtente()
			 * ,candidaturaReg.getCodiceRegione(), datiBando, session);
			 * session.saveOrUpdate(candidaturaReg); trx.commit();
			 * //session.close(); }
			 */
			log.info("Calcolo Punteggi avvenuto con successo per la candidatura:" + domanda.getCandidaturaReg().getIdCandidatura());

		} catch (Exception e) {
			bRet = false;
			log.fatal("bCalcolaPunteggiCandidatura failed", e);
			candidaturaReg.setErroreElabAutomatica("T");
			session.saveOrUpdate(candidaturaReg);
			trx.commit();
			// if(session!=null && session.isOpen())
			// session.close();
		} finally {
			session.close();
		}
		return bRet;

	}

	/*
	 * public boolean ripristinoFlag(DomandaDao domanda) throws
	 * GestioneErroriException { boolean bRet = true; Session session =
	 * HibernateUtil.openSession(); Transaction trx =
	 * session.beginTransaction(); try { //Aggiornamento flag CandidaturaReg
	 * candidaturaReg = domanda.getCandidaturaReg();
	 * candidaturaReg.setElabAutomatica("T");
	 * session.saveOrUpdate(candidaturaReg);
	 * 
	 * String codiceRegione = domanda.getUtenteCandidatura().getCodRegUtente();
	 * 
	 * DatiBandoHome datiBandoHome = new DatiBandoHome(); DatiBando datiBando =
	 * datiBandoHome.findById(codiceRegione);
	 * datiBando.setFlgPrecalcolato("true"); datiBando.setFlgScarti("false");
	 * session.saveOrUpdate(datiBando);
	 * 
	 * trx.commit();
	 * log.info("ripristinoFlag avvenuto con successo per la candidatura:" +
	 * domanda.getCandidaturaReg().getIdCandidatura()); } catch (Exception e) {
	 * log.fatal("ripristinoFlag failed", e); bRet = false; } finally {
	 * session.close(); } return bRet; }
	 */
	
	public String getSequenceIdStorico() throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_STORICO.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			throw new GestioneErroriException("UtenteCandidaturaRegHome - getSequenceIdStorico: errore getSequenceIdStorico");
		}
		finally{
			session.close();
		}
	}

}
