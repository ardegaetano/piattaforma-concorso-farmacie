package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Bean.DatiUtenza;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.PrintException;
import com.accenture.CCFarm.utility.StaticDefinitions;
import com.accenture.mailer.concorsofarma.GestoreMail;
import com.accenture.mailer.concorsofarma.data.MailBean;

/**
 * Home object for domain model class Utente.
 * @see com.accenture.CCFarm.DAO.Utente
 * @author Hibernate Tools
 */
public class UtenteHome {

//	private static final Log log = LogFactory.getLog(UtenteHome.class);
	private static final Logger log = CommonLogger.getLogger("UtenteHome");

	public void persist(Utente transientInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting Utente instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("UtenteHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(Utente instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("UtenteHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}
	
	public void saveOrUpdate(Utente instance, Session session) throws GestioneErroriException{
		
		log.debug("attaching dirty Utente instance");
		try {
			session.saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("UtenteHome - saveOrUpdate: errore saveOrUpdate");
		}
	}

	public void attachClean(Utente instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Utente instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("UtenteHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(Utente persistentInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting Utente instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("UtenteHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public Utente merge(Utente detachedInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging Utente instance");
		try {
			Utente result = (Utente) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("UtenteHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public Utente findById(java.lang.String id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting Utente instance with id: " + id);
		try {
			Utente instance = (Utente) session.get("com.accenture.CCFarm.DAO.Utente", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("UtenteHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(Utente instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Utente instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.Utente")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("UtenteHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	public String getSequenceIdUtente() throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_UTENTE.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("getSequenceIdUtente() - UtenteHome getSequenceIdSede failed : "+ PrintException.stack2string(re));
			throw new GestioneErroriException("UtenteHome - getSequenceIdUtente: errore getSequenceIdUtente");
		}
		finally{
			session.close();
		}
	}
	
	public String getSequenceIdDomanda() throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_DOMANDA.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("getSequenceIdDomanda() - AnagraficaFarmHome getSequenceIdDomanda failed : "+ PrintException.stack2string(re));
			throw re;
		}
		finally{
			session.close();
		}
	}
	
	public List<DatiUtenza> ricercaUtentiCandidati(DatiUtenza datiUtenza) throws GestioneErroriException {
		
		if(datiUtenza.getCodRegione() == null)
			return null;
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			String hqlSelectString = "SELECT u.id_Utente as idUtente,"+
			" g.numero_Protocollo as nProtocollo,"+
		    " UPPER(u.nome_utente||' '||u.cognome_utente) as nominativo,"+
		    " UPPER(u.codice_fiscale_utente) as codiceFiscale,"+
		    " u.pec_Mail as email,"+
		    " UPPER(r.Referente) as referente,"+
		    " c.modalita_candidatura as codiceTipoCandidatura,"+
		    " ur.pec_Mail as emailOriginale"+
		    " FROM Ricevute g, Candidatura_Reg c, Utente u, Utente_Reg ur,"+
		    " (select (ut.nome_utente||' '||ut.cognome_utente) as Referente, ut.id_utente"+ 
		    " from Candidatura_Reg cr, Utente ut"+ 
		    " where cr.id_Utente = ut.id_Utente and ut.cod_Reg_utente = '"+datiUtenza.getCodRegione()+"') r"+
		    " WHERE u.cod_Reg_utente = '"+datiUtenza.getCodRegione()+"'"+
		    " AND c.id_Candidatura = g.id_Candidatura"+
		    " AND c.id_Utente = u.id_Utente"+
		    " AND u.id_Utente = ur.id_Utente"+
		    " AND g.tipo_Ricevuta = 'DD' "+
		    " AND c.id_Utente = r.id_Utente"+
			" AND (c.MODALITA_CANDIDATURA='S' or c.REFERENTE_DOMANDA='Y')";
			
			//Filtro Nome
			if(datiUtenza.getNomeUtente()!=null && (!datiUtenza.getNomeUtente().equalsIgnoreCase(""))){
				hqlSelectString = hqlSelectString + " AND UPPER(u.nome_utente) like '%"+datiUtenza.getNomeUtente().toUpperCase().trim().replaceAll("'", "''")+"%'";
			}
			
			//Filtro Cognome
			if(datiUtenza.getCognomeUtente()!=null && (!datiUtenza.getCognomeUtente().equalsIgnoreCase(""))){
				hqlSelectString = hqlSelectString + " AND UPPER(u.cognome_utente) like '%"+datiUtenza.getCognomeUtente().toUpperCase().trim().replaceAll("'", "''")+"%'";
			}
			
			//Filtro Protocollo
			if(datiUtenza.getnProtocollo()!=null && (!datiUtenza.getnProtocollo().equalsIgnoreCase(""))){
				hqlSelectString = hqlSelectString + " AND UPPER(g.numero_Protocollo) like '%"+datiUtenza.getnProtocollo().toUpperCase().trim().replaceAll("'", "''")+"%'";
			}
			
			//Filtro Codice Fiscale
			if(datiUtenza.getCodiceFiscale()!=null && (!datiUtenza.getCodiceFiscale().equalsIgnoreCase(""))){
				hqlSelectString = hqlSelectString + " AND UPPER(u.codice_fiscale_utente) = '"+datiUtenza.getCodiceFiscale().toUpperCase().trim().replaceAll("'", "''")+"'";
			}
		   
			
			List<DatiUtenza> listaUtenze = new ArrayList<DatiUtenza>();
			List results = session.createSQLQuery(hqlSelectString).list();
			log.debug("ricercaUtentiCandidati: find by filter successful, result size: "+ results.size());
			
			DatiUtenza utente = null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				utente=new DatiUtenza();
			    
				Object[] row = (Object[]) iterator.next(); 
				utente.setIdUtente((String)row[0]);
				utente.setnProtocollo((String)row[1]);
				utente.setNominativo((String)row[2]);
				utente.setCodiceFiscale((String)row[3]);
				utente.setEmail((String)row[4]);
				String sReferente = (((String)row[5]) !=null && (!((String)row[5]).equalsIgnoreCase(""))) ? (String)row[5] : "-";
				utente.setReferente(sReferente);
				utente.setTipoCandidatura((String)row[6]);
				utente.setEmailOriginale((String)row[7]);
				
				listaUtenze.add(utente);
			}
			
			return listaUtenze;
		}
		catch(Exception e) {
			
			log.error("UtenteHome - ricercaUtentiCandidati fallita", e);
			throw new GestioneErroriException("UtenteHome - ricercaUtentiCandidati fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	
public List<DatiUtenza> ricercaUtenteInterpello(DatiUtenza datiUtenza) throws GestioneErroriException {
		
		if(datiUtenza.getCodRegione() == null)
			return null;
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			String hqlSelectString = "SELECT u.id_Utente as idUtente,"+
			" g.numero_Protocollo as nProtocollo,"+
		    " UPPER(u.nome_utente||' '||u.cognome_utente) as nominativo,"+
		    " UPPER(u.codice_fiscale_utente) as codiceFiscale,"+
		    " u.pec_Mail as email,"+
		    " UPPER(r.Referente) as referente,"+
		    " c.modalita_candidatura as codiceTipoCandidatura, "+
		    " gr.ID_CANDIDATURA, gr.INDICE_TOTALE, gr.ID_INTERPELLO, gr.INDICE_INTERPELLO" +
		    " FROM Ricevute g, Candidatura_Reg c, Utente u, Graduatoria gr, "+
		    " (select (ut.nome_utente||' '||ut.cognome_utente) as Referente, ut.id_utente"+ 
		    " from Candidatura_Reg cr, Utente ut"+ 
		    " where cr.id_Utente = ut.id_Utente and ut.cod_Reg_utente = '"+datiUtenza.getCodRegione()+"') r"+
		    " WHERE u.cod_Reg_utente = '"+datiUtenza.getCodRegione()+"'"+
		    " AND c.id_Candidatura = g.id_Candidatura"+
		    " AND c.id_Utente = u.id_Utente"+
		    " AND g.tipo_Ricevuta = 'DD' "+
		    " AND gr.id_Candidatura = c.id_Candidatura" +
		    " AND c.id_Candidatura = r.id_Utente" +
		    " AND gr.ID_INTERPELLO is not null AND gr.ID_INTERPELLO!=0"+
		    " AND (c.MODALITA_CANDIDATURA='S' or c.REFERENTE_DOMANDA='Y')";
			
			//Filtro Protocollo
			if(datiUtenza.getnProtocollo()!=null && (!datiUtenza.getnProtocollo().equalsIgnoreCase(""))){
				hqlSelectString = hqlSelectString + " AND UPPER(g.numero_Protocollo) like '%"+datiUtenza.getnProtocollo().toUpperCase().trim().replaceAll("'", "''")+"%'";
			}
			
			//Filtro Codice Fiscale
			if(datiUtenza.getCodiceFiscale()!=null && (!datiUtenza.getCodiceFiscale().equalsIgnoreCase(""))){
				hqlSelectString = hqlSelectString + " AND UPPER(u.codice_fiscale_utente) = '"+datiUtenza.getCodiceFiscale().toUpperCase().trim().replaceAll("'", "''")+"'";
			}
		   
			
			List<DatiUtenza> listaUtenze = new ArrayList<DatiUtenza>();
			List results = session.createSQLQuery(hqlSelectString).list();
			log.debug("ricercaUtentiCandidati: find by filter successful, result size: "+ results.size());
			
			DatiUtenza utente = null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				utente=new DatiUtenza();
			    
				Object[] row = (Object[]) iterator.next(); 
				utente.setIdUtente((String)row[0]);
				utente.setnProtocollo((String)row[1]);
				utente.setNominativo((String)row[2]);
				utente.setCodiceFiscale((String)row[3]);
				utente.setEmail((String)row[4]);
				String sReferente = (((String)row[5]) !=null && (!((String)row[5]).equalsIgnoreCase(""))) ? (String)row[5] : "-";
				utente.setReferente(sReferente);
				utente.setTipoCandidatura((String)row[6]);
				utente.setIdCandidatura((String)row[7]);
				utente.setPosizioneGraduatoria(((BigDecimal)row[8]) !=null ? ((BigDecimal)row[8]).toString() : "-"); 
				utente.setNumInterpello(((BigDecimal)row[9]) !=null ? ((BigDecimal)row[9]).toString() : "-");
				utente.setPosizioneInterpello(((BigDecimal)row[10]) !=null ? ((BigDecimal)row[10]).toString() : "-");
				
				listaUtenze.add(utente);
			}
			
			return listaUtenze;
		}
		catch(Exception e) {
			
			log.error("UtenteHome - ricercaUtenteInterpellato fallita", e);
			throw new GestioneErroriException("UtenteHome - ricercaUtenteInterpellato fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
public boolean escludiUtenteInterpello(DatiUtenza datiUtenza, String idCandidaturaSelezionata, String idOperatore) throws GestioneErroriException {
	
	boolean esclusionoRiuscita = false;
	if(datiUtenza.getCodRegione() == null || idCandidaturaSelezionata == null || idCandidaturaSelezionata.equals("")){
		return esclusionoRiuscita;
	}
		
	Session session = HibernateUtil.openSession(); 
    Transaction trx = session.beginTransaction();       
    java.sql.Connection dbConnection = session.connection();
	try {
		
		String updateTableSQL = "UPDATE GRADUATORIA" +
							    " SET ID_INTERPELLO = NULL, "+
							    " INDICE_INTERPELLO = NULL "+
							    " WHERE ID_CANDIDATURA = ?";
		PreparedStatement preparedStatement = dbConnection.prepareStatement(updateTableSQL);
		preparedStatement.setString(1, idCandidaturaSelezionata);
		// execute insert SQL stetement
		preparedStatement .executeUpdate();
		
        updateTableSQL = "UPDATE CANDIDATURA_REG" +
	    		 " SET FLAG_SCELTA_SEDI = NULL, "+
	    		 " FLAG_ABILITA_SCELTA_SEDI = NULL, "+
	    		 " EXCLUDED_INTER_BY = ? ,"+
	    		 " EXCLUDED_INTER_DATE = ? "+
	    		 " WHERE ID_CANDIDATURA = ?";
        preparedStatement = dbConnection.prepareStatement(updateTableSQL);
        preparedStatement.setString(1, idOperatore);
        preparedStatement.setDate(2, new java.sql.Date(System.currentTimeMillis()));
        preparedStatement.setString(3, idCandidaturaSelezionata);
        // execute insert SQL stetement
        preparedStatement .executeUpdate();
		
        updateTableSQL = "UPDATE CANDIDATURA_SEDI" +
	    		 " SET ID_CANDIDATURA = ?,"+
        		 " FLAG_ASSOCIATA = NULL,"+
	    		 " EXCLUDED_DATE = ?"+
	    		 " WHERE ID_CANDIDATURA = ?";
        preparedStatement = dbConnection.prepareStatement(updateTableSQL);
        preparedStatement.setString(1, idCandidaturaSelezionata+"_E");
        preparedStatement.setDate(2, new java.sql.Date(System.currentTimeMillis()));
        preparedStatement.setString(3, idCandidaturaSelezionata);
        // execute insert SQL stetement
        preparedStatement .executeUpdate();
        
		trx.commit();
		esclusionoRiuscita=true;
		log.debug("attach successful");
		return esclusionoRiuscita;
		
	}catch(Exception e) {
		log.error("UtenteHome - ricercaUtenteInterpellato fallita", e);
		throw new GestioneErroriException("UtenteHome - ricercaUtenteInterpellato fallita");
	}
	finally {
		
		if(session != null)
			session.close();
	}
}
	
	public void reinvioCredenzialiPecUtente(Utente utente, String sUtenza, String sNuovaPEC) throws GestioneErroriException {
    	
        Session session = HibernateUtil.openSession(); 
        Transaction trx = session.beginTransaction();       
        java.sql.Connection conn = session.connection();
	        try {
	               //Dichiaro quanto serve per creare ed inviare la mail
	               GestoreMail gestoreMail = new GestoreMail();
	               MailBean mailBean = new MailBean() ;
	               int[] indiciMail = new int[1];
            	   
            	   //OGGETTO MAIL
            	   String sOggettoMail = "";
            	   sOggettoMail = getOggettoMailreinvioCredenziali(utente, sNuovaPEC, sOggettoMail, "");
            	   //Oggetto Mail in Tedesco
            	   if(utente.getCodRegUtente().equals("041")){
            		   sOggettoMail = getOggettoMailreinvioCredenziali(utente, sNuovaPEC, sOggettoMail, ".de");
            	   }
            	   mailBean.setOggettoMail(sOggettoMail);
            	   
            	   
            	   //CORPO MAIL
            	   String sCorpoMail = "";
            	   sCorpoMail = getCorpoMailreinvioCredenziali(utente, sUtenza, sNuovaPEC, sCorpoMail, "");
            	   
            	   //Corpo Mail in Tedesco
            	   if(utente.getCodRegUtente().equals("041")){
            		   sCorpoMail = getCorpoMailreinvioCredenziali(utente, sUtenza, sNuovaPEC, sCorpoMail, ".de");
            	   }
            	   mailBean.setCorpoMail( "<html>" + sCorpoMail + "</htlml>");
            	   
	               ArrayList listaDest = new ArrayList<String>();
	               // invio una mail unica (al nuovo indirizzo)
	               listaDest.add(utente.getPecMail());
	               mailBean.setToAddresses(listaDest);
	               
	               //SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail 
	               indiciMail[0] = gestoreMail.saveMail(mailBean, StaticDefinitions.getAppProperties(), conn);
	               
	                              
	               //Provo ad inviare la mail 
	               try {
	            	   gestoreMail.sendMail(indiciMail[0], StaticDefinitions.getAppProperties(), conn);
	               } catch (Throwable thr) {
	            	   log.error("UtenteHome -  : errore nell' invio della mail " + thr.getMessage(), thr);
	               }
	               
	               //SALVATAGGIO UTENTE
	               if(sNuovaPEC!=null) {
	            	   saveOrUpdate(utente, session);
	               }
	               trx.commit();
	        } catch (Exception e) {
	           trx.rollback();	
               log.error("Errore UtenteHome - reinvioCredenzialiPecUtente" + LogUtil.printException(e));
               throw new GestioneErroriException("UtenteHome - reinvioCredenzialiPecUtente: errore nell' invio della mail (la mail verr� inviata via batch");
        }
        finally {
        	try{	
        	   conn.commit();
        	   } catch (Exception e) {
        		   log.error("Errore UtenteHome - reinvioCredenzialiPecUtente" + LogUtil.printException(e));
        		   //throw new GestioneErroriException("UtenteHome - reinvioCredenzialiPecUtente: errore nell' invio della mail (la mail verr� inviata via batch");
        	   }
               session.close();
        }            
  	}
	
	private String getOggettoMailreinvioCredenziali(Utente utente, String sNuovaPEC, String sOggettoMail, String lingua){
		if(lingua!=null && lingua.equals(".de"))
			sOggettoMail = sOggettoMail + " / ";
		
		String regioneProv =  com.accenture.CCFarm.utility.Localita.getDenominazioneRegione(utente.getCodRegUtente()).toLowerCase();
		regioneProv = regioneProv.substring(0,1).toUpperCase() + regioneProv.substring(1);
 	   
		if(sNuovaPEC!=null) {
			sOggettoMail = sOggettoMail + JSFUtility.getPropertyMessage("utente.invio.credenziali.cambio.pec.oggetto.mail"+lingua, "it")
    		   .replace("<regione>", regioneProv)
    		   .replace("<nominativo>", utente.getNomeUtente()+" "+utente.getCognomeUtente());
		}
		else {
			sOggettoMail = sOggettoMail + JSFUtility.getPropertyMessage("utente.invio.credenziali.oggetto.mail"+lingua, "it")
    		   .replace("<regione>", regioneProv)
    		   .replace("<nominativo>", utente.getNomeUtente()+" "+utente.getCognomeUtente());
		}
		return sOggettoMail;
	}
	
	private String getCorpoMailreinvioCredenziali(Utente utente, String sUtenza, String sNuovaPEC, String corpoMail, String lingua){ 
		
		if(lingua!=null && lingua.equals(".de"))
			corpoMail = corpoMail + "\r\n<br/>\r\n<br/>\r\n<br/>____________________________________________\r\n<br/>\r\n<br/>";
		
		String regioneProv =  com.accenture.CCFarm.utility.Localita.getDenominazioneRegione(utente.getCodRegUtente()).toLowerCase();
		regioneProv = regioneProv.substring(0,1).toUpperCase() + regioneProv.substring(1);
		
		String gentileCliente = null;
		if((utente.getSesso()).equalsIgnoreCase("M"))
			gentileCliente = JSFUtility.getPropertyMessage("utente.gentile.maschio"+lingua, "it") +utente.getNomeUtente()+" "+utente.getCognomeUtente()+", ";
		else
			gentileCliente = JSFUtility.getPropertyMessage("utente.gentile.femmina"+lingua, "it") +utente.getNomeUtente()+" "+utente.getCognomeUtente()+", ";

		String line1 =JSFUtility.getPropertyMessage("utente.invio.credenziali"+lingua, "it")+" "+regioneProv+".";
		String line2 =JSFUtility.getPropertyMessage("utente.invio.credenziali2"+lingua, "it")+" <B>"+sUtenza+"</B>.";
		String line3 =JSFUtility.getPropertyMessage("utente.invio.credenziali3"+lingua, "it");
		
		String line4 = JSFUtility.getPropertyMessage("utente.invio.credenziali.cambio.mail"+lingua, "it");
		String line5 = JSFUtility.getPropertyMessage("utente.invio.credenziali.cambio.mail2"+lingua, "it")+" <B>"+utente.getPecMail()+"</B>.";
		
		String attenzione = JSFUtility.getPropertyMessage("utente.attenzione.gestita"+lingua, "it");
	    
		corpoMail = corpoMail + gentileCliente +"\r\n<br/>\r\n<br/>"+line1+"\r\n<br/>\r\n<br/>"+line2+"\r\n<br/>\r\n<br/>"+line3+"\r\n<br/>\r\n<br/>";
		if(sNuovaPEC!=null){ 
			corpoMail = corpoMail + line4+"\r\n<br/>\r\n<br/>"+line5+"\r\n<br/>\r\n<br/>";
		}
		
		corpoMail = corpoMail + attenzione;
	
	    return corpoMail;
	}
	
	
}
