package com.accenture.CCFarm.DAO;



public class BorsaStudioRegStoricoId implements java.io.Serializable {

	private String idStorico;
	private String idBorsaStudio;
	
	public BorsaStudioRegStoricoId() {
	}
	
	public String getIdStorico() {
		return idStorico;
	}
	public void setIdStorico(String idStorico) {
		this.idStorico = idStorico;
	}

	public String getIdBorsaStudio() {
		return idBorsaStudio;
	}

	public void setIdBorsaStudio(String idBorsaStudio) {
		this.idBorsaStudio = idBorsaStudio;
	}
	
}
