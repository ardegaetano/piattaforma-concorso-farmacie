package com.accenture.CCFarm.DAO;

@SuppressWarnings("serial")
public class Comune implements java.io.Serializable {

	private String codiceComune;
	private String denominazioneEstesa;
	private String denominazione;
	private String codiceProvincia;
	
	public Comune() {}

	public Comune(String codiceComune, String denominazioneEstesa,
			String denominazione, String codiceProvincia) {
		this.codiceComune = codiceComune;
		this.denominazioneEstesa = denominazioneEstesa;
		this.denominazione = denominazione;
		this.codiceProvincia = codiceProvincia;
	}

	public String getCodiceComune() {
		return codiceComune;
	}

	public void setCodiceComune(String codiceComune) {
		this.codiceComune = codiceComune;
	}

	public String getDenominazioneEstesa() {
		return denominazioneEstesa;
	}

	public void setDenominazioneEstesa(String denominazioneEstesa) {
		this.denominazioneEstesa = denominazioneEstesa;
	}

	public String getDenominazione() {
		return denominazione;
	}

	public void setDenominazione(String denominazione) {
		this.denominazione = denominazione;
	}

	public String getCodiceProvincia() {
		return codiceProvincia;
	}

	public void setCodiceProvincia(String codiceProvincia) {
		this.codiceProvincia = codiceProvincia;
	}
}