package com.accenture.CCFarm.DAO;



public class PubblicazioneRegStoricoId implements java.io.Serializable {

	private String idStorico;
	private String idPubblicazione;
	
	public PubblicazioneRegStoricoId() {
	}
	
	public String getIdStorico() {
		return idStorico;
	}
	public void setIdStorico(String idStorico) {
		this.idStorico = idStorico;
	}
	public String getIdPubblicazione() {
		return idPubblicazione;
	}
	public void setIdPubblicazione(String idPubblicazione) {
		this.idPubblicazione = idPubblicazione;
	}
	
}
