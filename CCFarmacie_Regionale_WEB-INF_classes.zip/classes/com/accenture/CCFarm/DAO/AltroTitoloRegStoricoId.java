package com.accenture.CCFarm.DAO;

public class AltroTitoloRegStoricoId implements java.io.Serializable {

	private String idStorico;
	private String idAltroTitolo;

	public AltroTitoloRegStoricoId() {
	}

	public String getIdStorico() {
		return idStorico;
	}

	public void setIdStorico(String idStorico) {
		this.idStorico = idStorico;
	}

	public String getIdAltroTitolo() {
		return idAltroTitolo;
	}

	public void setIdAltroTitolo(String idAltroTitolo) {
		this.idAltroTitolo = idAltroTitolo;
	}
	
}
