package com.accenture.CCFarm.DAO;



// Generated Sep 4, 2012 12:58:22 PM by Hibernate Tools 3.4.0.CR1

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.accenture.CCFarm.Bean.ParafarmacieSearch;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class Parafarmacie.
 * @see CCFarm2.Parafarmacie
 * @author Hibernate Tools
 */
public class ParafarmacieHome {

//	private static final Log log = LogFactory.getLog(ParafarmacieHome.class);
	private static final Logger log = CommonLogger.getLogger("ParafarmacieHome");

   public List findByFilter(ParafarmacieSearch instance) throws GestioneErroriException {
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<ParafarmacieSearch> listaParafarmacie=new ArrayList<ParafarmacieSearch>();
		
		try {
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			sb.append("select parafarmacie.COD_SLO,parafarmacie.DES_SLO,parafarmacie.DES_IND,parafarmacie.COD_CAP,comuni.CODICE_COMUNE,comuni.DENOMINAZIONE_ESTESA,province.CODICE_PROVINCIA,province.DENOMINAZIONE_PROVINCIA,regioni.COD_REG,regioni.denominazione_reg from parafarmacie,comuni,province,regioni where parafarmacie.cod_cmn=comuni.codice_comune(+) AND comuni.CODICE_PROVINCIA=province.CODICE_PROVINCIA(+) AND province.CODICE_REGIONE=regioni.COD_REG(+)");
			if(instance.getCodRegione()!=null&&!instance.getCodRegione().equals("")){
			  sb.append(" AND regioni.COD_REG=");
			  sb.append("'"+instance.getCodRegione()+"'");
			}
			if(instance.getCodCmn()!=null&&!instance.getCodCmn().equals("")){
				  sb.append(" AND comuni.CODICE_COMUNE=");
				  sb.append("'"+instance.getCodCmn()+"'");
			}
			if(instance.getCodProvincia()!=null&&!instance.getCodProvincia().equals("")){
				  sb.append(" AND province.CODICE_PROVINCIA=");
				  sb.append("'"+instance.getCodProvincia()+"'");
			}
			if(instance.getDesInd()!=null&&!instance.getDesInd().equals("")){
				  sb.append(" AND parafarmacie.DES_IND=");
				  sb.append("'"+instance.getDesInd()+"'");
			}
			if(instance.getCodPva()!=null&&!instance.getCodPva().equals("")){
				  sb.append(" AND parafarmacie.COD_PVA=");
				  sb.append("'"+instance.getCodPva()+"'");
			}
			if(instance.getCodCap()!=null&&!instance.getCodCap().equals("")){
				  sb.append(" AND parafarmacie.COD_CAP=");
				  sb.append("'"+instance.getCodCap()+"'");
			}
			  
			List results = session.createSQLQuery(sb.toString()).list();
			
			log.debug("find by example successful, result size: "
					+ results.size());
			ParafarmacieSearch parafarmacia=null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				parafarmacia=new ParafarmacieSearch();
				Object[] row = (Object[]) iterator.next(); 
				parafarmacia.setCodSlo((String)row[0]);
				parafarmacia.setDesSlo((String)row[1]);
				parafarmacia.setDesInd((String)row[2]);
				parafarmacia.setCodCap((String)row[3]);
				parafarmacia.setCodCmn((String)row[4]);
				parafarmacia.setDesComune((String)row[5]);
				parafarmacia.setCodProvincia((String)row[6]);
				parafarmacia.setDesProvincia((String)row[7]);
				parafarmacia.setCodRegione((String)row[8]);
				parafarmacia.setDesRegione((String)row[9]);
				
				listaParafarmacie.add(parafarmacia);
			}
			
			return listaParafarmacie;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("ParafarmacieHome - findByFilter: errore findByFilter");
		}finally{
			session.close();
		}
	}
}
