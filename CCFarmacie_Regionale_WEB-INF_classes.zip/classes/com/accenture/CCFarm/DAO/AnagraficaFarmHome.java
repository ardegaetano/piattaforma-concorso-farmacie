package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

public class AnagraficaFarmHome {

	private static final Logger log = CommonLogger.getLogger("AnagraficaFarmHome");
	
	public void persist(AnagraficaFarm transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting AnagraficaFarm instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - findById: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(AnagraficaFarm instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty AnagraficaFarm instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - findById: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void attachClean(AnagraficaFarm instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean AnagraficaFarm instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - findById: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void delete(AnagraficaFarm persistentInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting AnagraficaFarm instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - findById: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public AnagraficaFarm merge(AnagraficaFarm detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging AnagraficaFarm instance");
		try {
			AnagraficaFarm result = (AnagraficaFarm) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - findById: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public AnagraficaFarm findById(java.lang.String id) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting AnagraficaFarm instance with id: " + id);
		try {
			AnagraficaFarm instance = (AnagraficaFarm) session.get("com.accenture.CCFarm.DAO.AnagraficaFarm", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - findById: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public List findByExample(AnagraficaFarm instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding AnagraficaFarm instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.AnagraficaFarm")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - findById: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	public String getSequenceIdSede() throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_FARM.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("AnagraficaFarmHome getSequenceIdSede failed : "+ re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - findById: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	//ritorna il numero di record in anagrafica associati alla regione specificata
	@SuppressWarnings("rawtypes")
	public Integer numeroSediPerRegione(Session session, String codiceRegione) throws GestioneErroriException {
		
		try {
			
			Criteria criteria = session.createCriteria(AnagraficaFarm.class);
			//condizioni
			criteria.add(Restrictions.eq("codRegFarm", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.rowCount());
			criteria = criteria.setProjection(projectionList);
			List results = criteria.list();
			
			if(results == null || results.isEmpty() || results.get(0) == null)
				return null;
			
			return (Integer) results.get(0);
		}
		catch(Exception e) {
			
			log.error("AnagraficaFarmHome numeroSediPerRegione failed : "+ e.getMessage(), e);
			throw new GestioneErroriException("AnagraficaFarmHome numeroSediPerRegione: " + e);
		}
	}
	
	public void deleteSediPerRegione(String codiceRegione) throws GestioneErroriException {
		
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting AnagraficaFarm instances");
		
		try {
			
			String hqlDeleteString = "DELETE AnagraficaFarm af WHERE af.codRegFarm = :codiceRegione";
			Query query = session.createQuery(hqlDeleteString);
			query.setParameter("codiceRegione", codiceRegione);
			query.executeUpdate();
			trx.commit();
			
			log.debug("delete successful");
			
		}
		catch (RuntimeException re) {
			
			log.error("delete failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("AnagraficaFarmHome - deleteSediPerRegione: "+re);
			throw eccezione;
		}
		finally {
			
			session.close();
		}
	} 
}
