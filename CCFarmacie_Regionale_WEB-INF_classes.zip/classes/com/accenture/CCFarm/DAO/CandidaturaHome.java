package com.accenture.CCFarm.DAO;

// Generated Aug 14, 2012 10:31:12 AM by Hibernate Tools 3.4.0.CR1

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CCFarmLogger;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class Candidatura.
 * 
 * @see CCFarm2.Candidatura
 * @author Hibernate Tools
 */
public class CandidaturaHome {

	// private static final Log log = LogFactory.getLog(CandidaturaHome.class);
	private static final Logger log = CommonLogger.getLogger("CandidaturaHome");

	public List<UtenteReg> listaUtentiXIdCandidatura(String id_candidatura) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		List<UtenteReg> result = new ArrayList<UtenteReg>();
		List<Candidatura> listCandida = null;
		UtenteRegHome utenteDAO = new UtenteRegHome();
		try {
			Query query = session.createQuery("from Candidatura where id_candidatura = :id_candidatura ");
			query.setParameter("id_candidatura", id_candidatura);
			listCandida = query.list();
			for (Candidatura w_cand : listCandida)
			{
					UtenteReg w_utente = null;
					String id_utente = w_cand.getIdUtente();
					w_utente = utenteDAO.findById(id_utente);
					if (w_utente!=null)
					{
						result.add(w_utente);
					}
			}
			
		} catch (Exception e) {
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  [" + id_candidatura + "]", e);
			throw new GestioneErroriException("CandidaturaHome - listaUtentiXIdCandidatura: errore listaUtentiXIdCandidatura");
		}finally{
			session.close();
		}
		return result;
	}
	public void saveOrUpdate(Candidatura instance)
			throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		CCFarmLogger.log("saveOrUpdate Candidatura instance", Level.INFO_INT,
				CandidaturaHome.class);
		try {
			session.saveOrUpdate(instance);

			trx.commit();
			CCFarmLogger.log(
					"Salvataggio avvenuto con successo per la candidatura: idUtente"
							+ instance.getIdUtente(), Level.INFO_INT,
					CandidaturaHome.class);

		} catch (Exception e) {
			trx.rollback();
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", e);
			throw new GestioneErroriException("CandidaturaHome - saveOrUpdate: errore CandidaturaHome - saveOrUpdate: errore nell' aggiornmaneto della candidatura: idUtente");
		} finally {
			session.close();
		}
	}
	
	public void annullaAssociataUpdate(List<Candidatura> listCandAsso, String idUtente) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		CCFarmLogger.log("saveOrUpdate Candidatura instance", Level.INFO_INT, CandidaturaHome.class);
		java.util.Date dataSys= new java.util.Date();
		boolean ok = true;
		
		for (int i = 0; i < listCandAsso.size(); i++) {
			Candidatura instance =  new Candidatura();
			instance = (Candidatura) listCandAsso.get(i);
			instance.setStatoDomanda("A");
			instance.setStatoRegistrazione("A");
			instance.setLastUpdateDateCand(new java.sql.Timestamp(dataSys.getTime()));
			instance.setLastUpdatedByCand(idUtente);
			try {
				session.saveOrUpdate(instance);
				CCFarmLogger.log("Salvataggio avvenuto con successo per la candidatura: idUtente"
								+ instance.getIdUtente(), Level.INFO_INT, CandidaturaHome.class);
				
			} catch (Exception e) {
				trx.rollback();
				log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", e);
				throw new GestioneErroriException("CandidaturaHome - saveOrUpdate: errore nell' aggiornmaneto della candidatura: idUtente");
			}finally{
					trx.commit();
					session.close();	
				
			}

		}	
		
	
	
	}
	
	
	
	
	public UtenteCandidaturaReg findByUserId(String id_utente) throws GestioneErroriException
	{
		UtenteCandidaturaReg result = null;
		CCFarmLogger.log("findByUserId UtenteCandidaturaReg id: " + id_utente, Level.INFO_INT,
				CandidaturaHome.class);
		Session session = HibernateUtil.openSession();
		try {
			session = HibernateUtil.openSession();
			result = (UtenteCandidaturaReg) session.get(
					"com.accenture.CCFarm.DAO.UtenteCandidaturaReg", id_utente);
			if (result == null) {
				CCFarmLogger.log("get failed, no instance found",
						Level.INFO_INT, CandidaturaHome.class);
			} else {
				CCFarmLogger.log("get successful, instance found",
						Level.INFO_INT, CandidaturaHome.class);
			}
			
		} catch (RuntimeException re) {
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", re);
			throw new GestioneErroriException("CandidaturaRegHome - findByUserId: errore nell' findByUserId della candidatura:");
		} finally {
			session.close();
			return result;
		}		
	}		
	public Candidatura findById(java.lang.String id)
			throws GestioneErroriException {
		CCFarmLogger.log("findById Candidatura id: " + id, Level.INFO_INT,
				CandidaturaHome.class);
		Session session = HibernateUtil.openSession();
		try {
			session = HibernateUtil.openSession();
			Candidatura instance = (Candidatura) session.get(
					"com.accenture.CCFarm.DAO.Candidatura", id);
			if (instance == null) {
				CCFarmLogger.log("get failed, no instance found",
						Level.INFO_INT, CandidaturaHome.class);
			} else {
				CCFarmLogger.log("get successful, instance found",
						Level.INFO_INT, CandidaturaHome.class);
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", re);
			throw new GestioneErroriException("CandidaturaHome - findById: errore nell' findById della candidatura:");
		} finally {
			session.close();
		}
	}

	public ArrayList<Candidatura> findByExample(Candidatura instance)
			throws GestioneErroriException {
		CCFarmLogger
				.log("findByExample Candidatura idUtente: "
						+ instance.getIdUtente(), Level.INFO_INT,
						CandidaturaHome.class);
		Session session = HibernateUtil.openSession();
		try {
			session = HibernateUtil.openSession();
			@SuppressWarnings("unchecked")
			ArrayList<Candidatura> results = (ArrayList<Candidatura>) session
					.createCriteria("com.accenture.CCFarm.DAO.Candidatura")
					.add(Example.create(instance)).list();
			CCFarmLogger.log(
					"findByExample successful Candidatura , result size: "
							+ results.size(), Level.INFO_INT,
					CandidaturaHome.class);
			return results;
		} catch (RuntimeException re) {
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", re);
			throw new GestioneErroriException("CandidaturaHome - findByExample: errore nell' findByExample della candidatura:");
		} finally {
			session.close();
		}
	}
	
	
}
