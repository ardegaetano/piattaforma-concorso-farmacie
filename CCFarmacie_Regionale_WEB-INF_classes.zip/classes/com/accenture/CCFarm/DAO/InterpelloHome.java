package com.accenture.CCFarm.DAO;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.transform.Transformers;

import com.accenture.CCFarm.Bean.CandidatoInterpello;
import com.accenture.CCFarm.Bean.CandidatoSedeAssegnataListBean;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.exception.SediException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.Localita;

public class InterpelloHome {

	private static final Logger log = CommonLogger.getLogger("InterpelloHome");
	
	private static final String progressivoInizialeInterpelli = AppProperties.getAppProperties().getProperty("progressivo.iniziale.interpelli");
	private static final String codiceInterpelloPredisposto = AppProperties.getAppProperties().getProperty("codice.interpello.predisposto");
	private static final String codiceInterpelloPubblicato = AppProperties.getAppProperties().getProperty("codice.interpello.pubblicato");
	private static final String codiceInterpelloChiuso = AppProperties.getAppProperties().getProperty("codice.interpello.chiuso");
	private static final String codiceAssegnazionePubblicata = AppProperties.getAppProperties().getProperty("codice.accettazione.pubblicata");
	private static final String flagValoreVero  = AppProperties.getAppProperties().getProperty("flag.valore.vero");
	
	//determina qual � il prossimo progressivo interpello per una data regione
	@SuppressWarnings("rawtypes")
	private BigDecimal prossimoProgressivoInterpello(Session session, String codiceRegione) throws GestioneErroriException {
		
		try {
			
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.max("id.idInterpello"));
			criteria = criteria.setProjection(projectionList);
			List results = criteria.list();
			
			if(results == null || results.isEmpty() || results.get(0) == null)
				return new BigDecimal(progressivoInizialeInterpelli);
			
			BigDecimal maxIdInterpello = (BigDecimal) results.get(0);
			BigDecimal nextValue = new BigDecimal(maxIdInterpello.intValue() + 1);
			
			log.debug("Il prossimo progressivo interpello per la regione " + codiceRegione + "�: " + nextValue.intValue());
			
			return nextValue;
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - individuazione prossimo progressivo interpello per la regione " + codiceRegione + " fallita", e);
			throw new GestioneErroriException("InterpelloHome - individuazione prossimo progressivo interpello per la regione " + codiceRegione + " fallita");
		}
	}
	
	//trova, per la regione specificata, l'interpello con il progressivo pi� alto (pi� recente)
	@SuppressWarnings("unchecked")
	public Interpello determinaInterpelloCorrente(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			DetachedCriteria innerCriteria = DetachedCriteria.forClass(Interpello.class, "interpello");
			//condizioni
			innerCriteria.add(Restrictions.eq("interpello.id.codReg", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.max("interpello.id.idInterpello"));
			innerCriteria = innerCriteria.setProjection(projectionList);
			
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			criteria.add(Subqueries.propertyEq("id.idInterpello", innerCriteria));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			if(results == null || results.isEmpty())
				return null;
			
			return results.get(0);
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - determinazione interpello corrente fallita", e);
			throw new GestioneErroriException("InterpelloHome - determinazione interpello corrente fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//ricerca tutti gli interpelli registrati fino a questo momento per la regione specificata (ordinati per progressivo CRESCENTE)
	@SuppressWarnings("unchecked")
	public List<Interpello> trovaInterpelliPerRegione(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			//ordinamento
			criteria.addOrder(Order.asc("id.idInterpello"));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			if(results == null || results.isEmpty())
				return null;
			
			return results;
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - ricerca interpelli per la regione " + codiceRegione + " fallita", e);
			throw new GestioneErroriException("InterpelloHome - ricerca interpelli per la regione " + codiceRegione + " fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//restituisce true se l'interpello corrente (ultimo inserito) per la regione specificata risulta predisposto o pubblicato
	@SuppressWarnings("unchecked")
	public boolean controllaPresenzaInterpelloInCorso(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			DetachedCriteria innerCriteria = DetachedCriteria.forClass(Interpello.class, "interpello");
			//condizioni
			innerCriteria.add(Restrictions.eq("interpello.id.codReg", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.max("interpello.id.idInterpello"));
			innerCriteria = innerCriteria.setProjection(projectionList);
			
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			criteria.add(Subqueries.propertyEq("id.idInterpello", innerCriteria));
			
			//stato "predisposto" oppure "pubblicato"
			Criterion c1 = Restrictions.eq("stato", codiceInterpelloPredisposto);
			Criterion c2 = Restrictions.eq("stato", codiceInterpelloPubblicato);
			criteria.add(Restrictions.or(c1, c2));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			return (results != null && results.size() > 0);
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito", e);
			throw new GestioneErroriException("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//predispone un nuovo interpello per la regione specificata
	public Interpello predisponiNuovoInterpello(String codiceRegione) throws GestioneErroriException, SediException {
		
		Session session = null;
		Transaction transaction = null;
		
		try {
			
			session = HibernateUtil.openSession();
			transaction = session.beginTransaction();
			transaction.begin();
			
			//determina il progressivo interpello successivo all'ultimo inserito
			BigDecimal idNuovoInterpello = prossimoProgressivoInterpello(session, codiceRegione);
			
			//disabilita il caricamento delle sedi
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			datiBandoHome.disabilitaCaricamentoSedi(session, codiceRegione);
			
			//replica i dati delle sedi associate integrando i dati dell'interpello (implicitamente determina il numero di sedi registrate)
			AnagraficaFarmInterpelliHome anagraficaFarmInterpelliHome = new AnagraficaFarmInterpelliHome();
			int numeroSedi = anagraficaFarmInterpelliHome.memorizzaSediPerInterpello(session,
																					 codiceRegione,
																					 idNuovoInterpello);
			if(numeroSedi == 0)
				throw new SediException("Nessuna sede registrata per la regione: " + Localita.getDenominazioneRegione(codiceRegione));
			
			//crea e salva il record con i dati del nuovo interpello
			InterpelloId id = new InterpelloId(idNuovoInterpello, codiceRegione);
			Interpello nuovoInterpello = new Interpello(id);
			nuovoInterpello.setStato(codiceInterpelloPredisposto);
			nuovoInterpello.setNumeroSedi(new BigDecimal(numeroSedi));
			session.saveOrUpdate(nuovoInterpello);
			
			//elabora gli indici interpello sui record dei candidati in graduatoria
			GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
			List<String> elencoIdCandidatureIdonee = graduatoriaHome.aggiornaIndiciInterpello(session,
																							  codiceRegione,
																							  idNuovoInterpello,
																							  numeroSedi);
			//marca tutte le candidature risultate idonee alla selezione delle sedi
			CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
			candidaturaRegHome.abilitaSceltaSedi(session, codiceRegione, elencoIdCandidatureIdonee);
			
			transaction.commit();
			
			return nuovoInterpello;
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - predisposizione nuovo interpello per la regione " + codiceRegione + " fallita", e);
			
			if(transaction != null)
				transaction.rollback();
			
			if(e instanceof SediException)
				throw (SediException) e;
			else
				throw new GestioneErroriException("InterpelloHome - predisposizione nuovo interpello per la regione " + codiceRegione + " fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//elimina interpello specificato (e relativi dati associati)
	public void eliminaInterpello(Interpello interpelloDaEliminare) throws GestioneErroriException {
		
		Session session = null;
		Transaction transaction = null;
		
		try {
			
			session = HibernateUtil.openSession();
			transaction = session.beginTransaction();
			transaction.begin();
			
			String codiceRegione = interpelloDaEliminare.getId().getCodReg();
			BigDecimal idInterpello = interpelloDaEliminare.getId().getIdInterpello();
			
			//rimuove l'abilitazione eventualmente fornita per l'interpello predisposto alle candidature risultate idonee
			CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
			candidaturaRegHome.resettaSceltaSedi(session, codiceRegione);
			
			//cancella indici interpello sui record dei candidati in graduatoria
			GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
			graduatoriaHome.cancellaIndiciInterpello(session,
													 codiceRegione,
													 idInterpello);
			
			//elimina dati interpello
			session.delete(interpelloDaEliminare);
			
			//elimina i dati delle sedi associate all'interpello
			AnagraficaFarmInterpelliHome anagraficaFarmInterpelliHome = new AnagraficaFarmInterpelliHome();
			anagraficaFarmInterpelliHome.eliminaSediPerInterpello(session,
																  codiceRegione,
																  idInterpello);
			
			//abilita il caricamento delle sedi
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			datiBandoHome.abilitaCaricamentoSedi(session, codiceRegione);
			
			transaction.commit();
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - eliminazione interpello fallita", e);
			
			if(transaction != null)
				transaction.rollback();
			
			throw new GestioneErroriException("InterpelloHome - eliminazione interpello fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<CandidatoInterpello> trovaCandidatiInterpello(Interpello interpello) throws GestioneErroriException {
		
		if(interpello == null)
			return null;
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			//codice regione
			String codiceRegione = interpello.getId().getCodReg();
			//indice interpello
			BigDecimal idInterpello = interpello.getId().getIdInterpello();
			
			String hqlSelectString = "SELECT g.indiceTotale as posizioneGraduatoria,"
								   + " g.indiceInterpello as posizioneInterpello,"
								   + " (g.nome||' '||g.cognome) as nominativo,"
								   + " g.numeroProtocollo as nProtocollo,"
								   + " u.pecMail as email,"
								   + " c.modalitaCandidatura as codiceTipoCandidatura"
								   + " FROM Graduatoria g, CandidaturaReg c, Utente u"
								   + " WHERE g.codRegione = :codiceRegione"
								   + " AND g.idInterpello = :idInterpello"
								   + " AND c.idCandidatura = g.idCandidatura"
								   + " AND ((c.referenteDomanda is null AND c.modalitaCandidatura = 'S') OR (c.referenteDomanda = 'Y' AND c.modalitaCandidatura = 'A'))"
								   + " AND c.idUtente = u.idUtente"
								   + " ORDER BY g.indiceTotale ASC";
			
			Query query = session.createQuery(hqlSelectString);
			
			//impostazione parametri
			query.setParameter("codiceRegione", codiceRegione);
			query.setParameter("idInterpello", idInterpello);
			
			//trasformazione risultato
			query.setResultTransformer(Transformers.aliasToBean(CandidatoInterpello.class));
			
			List<CandidatoInterpello> results = (List<CandidatoInterpello>) query.list();
			
			if(results == null || results.isEmpty())
				return null;
			
			return results;
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - ricerca candidati interpello fallita", e);
			throw new GestioneErroriException("InterpelloHome - ricerca candidati interpello fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//salvataggio/aggiornamento interpello specificato
	public Interpello salvaInterpello(Interpello interpelloDaSalvare) throws GestioneErroriException {
		
		Session session = null;
		Transaction transaction = null;
		
		try {
			
			session = HibernateUtil.openSession();
			transaction = session.beginTransaction();
			transaction.begin();
			session.saveOrUpdate(interpelloDaSalvare);
			transaction.commit();
			
			return interpelloDaSalvare;
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - salvataggio interpello fallito", e);
			
			if(transaction != null)
				transaction.rollback();
			
			throw new GestioneErroriException("InterpelloHome - salvataggio interpello fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//chiusura interpello specificato
	public Interpello chiudiInterpello(Interpello interpelloDaSalvare, DatiBando datiBando) throws GestioneErroriException {
		
		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtil.openSession();
			transaction = session.beginTransaction();
			transaction.begin();
			
			interpelloDaSalvare.setStato(codiceInterpelloChiuso);
			session.saveOrUpdate(interpelloDaSalvare);
			//resetta flag datiBando
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			
			datiBando.setFlgAbilitaCaricaSedi(flagValoreVero);
			datiBando.setFlagInvioInviti(null);
			datiBando.setFlagAbbinamentoSedi(null);
			datiBando.setFlagMancataRispInterpello(null);
			datiBando.setFlagInvioAccettazioneSedi(null);
			datiBando.setFlagMancataAccettazSede(null);
			
			datiBandoHome.saveOrUpdate(session, datiBando);
			
			transaction.commit();
			return interpelloDaSalvare;
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - chiusura interpello fallito", e);
			
			if(transaction != null)
				transaction.rollback();
			
			throw new GestioneErroriException("InterpelloHome - chiusura interpello fallito");
		}
		finally {
			if(session != null)
				session.close();
		}
	}
	
	//pubblicazione interpello specificato
	public Interpello pubblicaInterpello(Interpello interpelloDaPubblicare) throws GestioneErroriException {
		
		Session session = null;
		Transaction transaction = null;
		
		try {
			
			session = HibernateUtil.openSession();
			transaction = session.beginTransaction();
			transaction.begin();
			
			//imposta e salva flag "interpello pubblicato" su record interpello specificato
			interpelloDaPubblicare.setStato(codiceInterpelloPubblicato);
			session.saveOrUpdate(interpelloDaPubblicare);
			
			//imposta flag per attivare batch invio inviti e batch elabora mancate risposte su record dati bando della regione a cui appartiene l'interpello
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			int updatedRows = datiBandoHome.setFlagBatchInvitiEMancataRisp(session, interpelloDaPubblicare.getId().getCodReg());
			if(updatedRows == 0)
				log.warn("Pubblicazione interpello - ATTENZIONE: i flag per i batch 'invio degli inviti' e 'elabora mancate risposte' su DATI BANDO non sono stati settati");
			
			transaction.commit();
			
			return interpelloDaPubblicare;
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - pubblicazione interpello fallita", e);
			
			if(transaction != null)
				transaction.rollback();
			
			throw new GestioneErroriException("InterpelloHome - pubblicazione interpello fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//pubblicazione accettazione specificato
	public Interpello pubblicaAccettazione(Interpello interpello, DatiBando datiBando) throws GestioneErroriException {
		
		Session session = null;
		Transaction transaction = null;
		
		try {
			
			session = HibernateUtil.openSession();
			transaction = session.beginTransaction();
			transaction.begin();
			interpello.setStatoAccettazione(codiceAssegnazionePubblicata);
			session.saveOrUpdate(interpello);
			
			//resetta flag datiBando
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			datiBando.setFlagInvioAccettazioneSedi(flagValoreVero);
			datiBando.setFlagMancataAccettazSede(flagValoreVero);
			datiBandoHome.saveOrUpdate(session, datiBando);
			
			transaction.commit();
			
			return interpello;
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - pubblicazione accettazione fallita", e);
			
			if(transaction != null)
				transaction.rollback();
			
			throw new GestioneErroriException("InterpelloHome - pubblicazione accettazione fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	public Interpello getInterpelloByCandidatura(String codReg, String idCandidatura) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			session = HibernateUtil.openSession();
			
			String hqlSelectString = "SELECT i.id.idInterpello, i.id.codReg,"
					   + " i.dataInizio, i.dataFine, i.stato,"
					   + " i.dataInizioAccettazione, i.dataFineAccettazione, i.statoAccettazione"
					   + " FROM Interpello i, Graduatoria g"
					   + " WHERE i.id.codReg = g.codRegione"
					   + " AND i.id.codReg = :codiceRegione"
					   + " AND g.idInterpello = i.id.idInterpello"
					   + " AND g.idCandidatura = :idCandidatura";

			Query query = session.createQuery(hqlSelectString);

			//impostazione parametri
			query.setParameter("codiceRegione", codReg);
			query.setParameter("idCandidatura", idCandidatura);
			
			//trasformazione risultato
			//query.setResultTransformer(Transformers.aliasToBean(Interpello.class));
			
			List results = query.list();
			
			if(results == null || results.isEmpty())
				return null;
			
			Object[] row = (Object[]) results.get(0);
			Interpello interpello = new Interpello();
			interpello.setId(new InterpelloId((BigDecimal)row[0], (String)row[1]));
			interpello.setDataInizio((Serializable)row[2]);
			interpello.setDataFine((Serializable)row[3]);
			interpello.setStato((String)row[4]);
			interpello.setDataInizioAccettazione((Serializable)row[5]);
			interpello.setDataFineAccettazione((Serializable)row[6]);
			interpello.setStatoAccettazione((String)row[7]);
			
			return interpello;
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - getInterpelloByCandidatura fallito", e);
			throw new GestioneErroriException("InterpelloHome - getInterpelloByCandidatura fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}

	}
	
	//restituisce, per la regione specificata, l'ultimo interpello inserito (se risulta con stato "chiuso" o "pubblicato")
	@SuppressWarnings("unchecked")
	public Interpello determinaInterpelloCorrentePubblicatoChiuso(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			DetachedCriteria innerCriteria = DetachedCriteria.forClass(Interpello.class, "interpello");
			//condizioni
			innerCriteria.add(Restrictions.eq("interpello.id.codReg", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.max("interpello.id.idInterpello"));
			innerCriteria = innerCriteria.setProjection(projectionList);
			
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			criteria.add(Subqueries.propertyEq("id.idInterpello", innerCriteria));
			
			//stato "chiuso" oppure "pubblicato"
			criteria.add(Restrictions.or(Restrictions.eq("stato", codiceInterpelloPredisposto), Restrictions.eq("stato", codiceInterpelloPubblicato)));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			if(results == null || results.isEmpty())
				return null;
			
			return results.get(0);
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito", e);
			throw new GestioneErroriException("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	
}
