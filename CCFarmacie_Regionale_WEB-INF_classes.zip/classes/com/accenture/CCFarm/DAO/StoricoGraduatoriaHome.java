package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;

import com.accenture.CCFarm.Bean.UtenteBean;
import com.accenture.CCFarm.PDFModulo.GestionePDFStampaGraduatoria;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.RicercaSchedeValutazione;
import com.accenture.CCFarm.pageBean.RicercaStoricoGraduatoria;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.UtenteRegioni;


/**
* Home object for domain model class StoricoGraduatoria.
* @see com.accenture.CalcolaTitoli.DAO.StoricoGraduatoria
*/
public class StoricoGraduatoriaHome {
	
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
    UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	String cod_reg = utenteReg.getCodRegione();

	private static final Log log = LogFactory.getLog(StoricoGraduatoriaHome.class);
	
	public void persist(StoricoGraduatoria transientInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("persisting StoricoGraduatoria instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(StoricoGraduatoria instance) {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty StoricoGraduatoria instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public void attachClean(StoricoGraduatoria instance) {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean StoricoGraduatoria instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public void delete(StoricoGraduatoria persistentInstance) {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting StoricoGraduatoria instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public StoricoGraduatoria merge(StoricoGraduatoria detachedInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("merging StoricoGraduatoria instance");
		try {
			StoricoGraduatoria result = (StoricoGraduatoria) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public StoricoGraduatoria findById(StoricoGraduatoriaId id) {
		Session session = HibernateUtil.openSession();
		log.debug("getting StoricoGraduatoria instance with id: " + id);
		try {
			StoricoGraduatoria instance = (StoricoGraduatoria) session.get("com.accenture.CCFarm.DAO.StoricoGraduatoriaId", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}
	
	
	public List findByExample(StoricoGraduatoria instance) {
		Session session = HibernateUtil.openSession();
		log.debug("finding StoricoGraduatoria instance by example");
		try {
			
				List results = session
						.createCriteria("com.accenture.CCFarm.DAO.StoricoGraduatoria")
						.add(Example.create(instance)).
						list();
			
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}
	
	
	
	public List findTipologieGraduatorie(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		
		List<TipoGraduatoria> tipoGraduatoriaList = new ArrayList<TipoGraduatoria>();
		
		try{
			
			session = HibernateUtil.openSession();
			query ="select n_progressivo,data_validazione,stato_graduatoria,data_publicazione from tipologia_graduatoria where cod_regione='"+codReg+"' order by n_progressivo asc";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			
			List result = sqlQuery.list();
			
			String descrizione="";
			
			TipoGraduatoria tipoGraduatoria= null;
			
			for(Object object : result){
				tipoGraduatoria = new TipoGraduatoria();
				Map row = (Map)object;
				tipoGraduatoria.setProgressivo((BigDecimal) row.get("N_PROGRESSIVO"));
				tipoGraduatoria.setDataValutazione((Date) row.get("DATA_VALIDAZIONE"));
				tipoGraduatoria.setStatoGraduatoria((String) row.get("STATO_GRADUATORIA"));
				tipoGraduatoria.setDataPublicazione((Date) row.get("DATA_PUBLICAZIONE"));
				int progressivo = ((BigDecimal) row.get("N_PROGRESSIVO")).intValue();
				
				if (progressivo == 1) descrizione="Graduatoria definitiva";
				else if (progressivo > 1) descrizione="Graduatoria "+(progressivo -1)+"� rettifica";
				
				tipoGraduatoria.setDescrizione(descrizione);
				
				tipoGraduatoriaList.add(tipoGraduatoria);
			}
			
			
			
			return tipoGraduatoriaList;
			
			
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}finally{
			session.close();
		}
		
		
	}
	

	public int findCount(String codReg,String tipoGrad,int primo, int ultimo, String dataValidazione) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			
			String dataQuery="";
			String indiciPosizione="";
			
			if (dataValidazione!=null && !dataValidazione.equalsIgnoreCase("")){
				dataQuery = " and trunc(data_validazione)= to_date( '"+dataValidazione+"', 'dd/mm/yyyy')";
			}
			if (primo>=0 && ultimo>=0 && ultimo >= primo && primo != 0 && ultimo != 0){
				indiciPosizione = " and indice_totale >="+primo+" and  indice_totale <="+ultimo;
			}
			
			query ="select id_candidatura from storico_graduatoria where cod_regionale='"+codReg+"' and n_progressivo = '"+tipoGrad+"'" 
					+ indiciPosizione + dataQuery;
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			
			List result = sqlQuery.list();
		
			int nCount = result.size();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}finally{
			session.close();
		}
		
		
	}
	
	
	
	public List findLazyListStoricoGraduatoria(int startPage, int maxPerPage,String codReg,int primo, int ultimo, String graduatoria, String dataValidazione)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<StoricoGraduatoria> graduatoriaList = new ArrayList<StoricoGraduatoria>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal indice = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
		Date dataVal;
		String dataValString ="";
		String indiciPosizione = "";
		String dataQuery ="";
		if (dataValidazione!=null && !dataValidazione.equalsIgnoreCase("")){
			dataQuery = " and trunc(data_validazione)= to_date( '"+dataValidazione+"', 'dd/mm/yyyy')";
		}
		if (primo>=0 && ultimo>=0 && ultimo >= primo){
			indiciPosizione = "indice_totale >="+primo+" and  indice_totale <="+ultimo+" and ";
		}
		
		try{
		session = HibernateUtil.openSession();
		query = "select indice_totale,numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita, data_validazione, EXAEQUO_COLOR " +
				"from STORICO_GRADUATORIA where " +
				indiciPosizione +
				"cod_regionale='"+codReg+"' and n_progressivo ='"+graduatoria+"'" +
				dataQuery +
				" ORDER BY indice_totale";				
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		sqlQuery.setFirstResult(startPage);
		sqlQuery.setMaxResults(maxPerPage);
		List result = sqlQuery.list();
		
		StoricoGraduatoria storicoGraduatoria= null;
		
		for(Object object : result){
			storicoGraduatoria = new StoricoGraduatoria();
			Map row = (Map)object;
			indice = (BigDecimal)row.get("INDICE_TOTALE");
			storicoGraduatoria.setIndiceTotale(indice);
			storicoGraduatoria.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
			storicoGraduatoria.setCognome((String) row.get("COGNOME"));
			storicoGraduatoria.setNome((String) row.get("NOME"));
			punteggio = (BigDecimal)row.get("PUNTEGGIO");
			storicoGraduatoria.setPunteggio(punteggio);
			eta = (BigDecimal) row.get("ETA_MEDIA");
			dataVal = (Date) row.get("DATA_VALIDAZIONE");
			dataValString = StringUtil.dateToStringDDMMYYYY(dataVal);
			storicoGraduatoria.setDataValidazioneString(dataValString);
			storicoGraduatoria.setEtaMedia(eta);
			storicoGraduatoria.setDataNascita((String) row.get("DATA_NASCITA"));
			storicoGraduatoria.setColorExAequo((String) row.get("EXAEQUO_COLOR"));
			
			graduatoriaList.add(storicoGraduatoria);
		}
		
		return graduatoriaList;
		
		}catch(RuntimeException re){
			log.error("findLazyListStoricoGraduatoria failed", re);
			throw new GestioneErroriException("storicoGraduatoriaHome - findLazyListStoricoGraduatoria: errore findByFilter");
		}finally{
			session.close();
		}
	}
	
	
	public void caricamentoStoricoFromGraduatoria(List<Graduatoria> instance, TipoGraduatoria tipoGraduatoria, TipoGraduatoriaHome tGHome) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("caricamentoStoricoFromGraduatoria dirty StoricoGraduatoria");
		
		try {
//			session = HibernateUtil.openSession();
//			trx = session.beginTransaction();
//			trx.begin();	
			
			//while ((countRow+1)<maxSizeTabel) {
			
				for (Graduatoria graduatoria : instance) {
					
					StoricoGraduatoria storicoGraduatoria = new StoricoGraduatoria();
					StoricoGraduatoriaId idKey = new StoricoGraduatoriaId();
					
					//storicoGraduatoria = storicoGraduatoriaHome.findById(id)
					PropertyUtils.copyProperties(storicoGraduatoria, graduatoria);
					
					idKey.setIdCandidatura(graduatoria.getIdCandidatura());
					idKey.setnProgressivo(""+tipoGraduatoria.getProgressivo());
					storicoGraduatoria.setIdKey(idKey);
					storicoGraduatoria.setnProgressivo(""+tipoGraduatoria.getProgressivo());
					storicoGraduatoria.setDataValidazione(tipoGraduatoria.getDataValutazione());
					storicoGraduatoria.setDataValidazioneString("");
					storicoGraduatoria.setColorExAequo(graduatoria.getColor());
//					storicoGraduatoria.setExAequoRisolto(graduatoria.getExAequoRisolto());
					
//					storicoGraduatoriaHome.saveOrUpdate(storicoGraduatoria);
					session.saveOrUpdate(storicoGraduatoria);
				}
				trx.commit();
				
				GestionePDFStampaGraduatoria gestionePDFStampaGraduatoria = new GestionePDFStampaGraduatoria();
		    	gestionePDFStampaGraduatoria.caricaDatiDaGraduatoriaEntityPDF(tipoGraduatoria.getCodRegione());
		    	gestionePDFStampaGraduatoria.creaGraduatoriaPDF();
	 	    	tipoGraduatoria.setGraduatoriaPDF(gestionePDFStampaGraduatoria.getGraduatoriaPDF());
				tipoGraduatoria.setStatoGraduatoria("V");
				
				tGHome.saveOrUpdate(tipoGraduatoria); 
			
		} catch(Exception e){
			trx.rollback();
			throw new GestioneErroriException("StoricoGraduatoriaHome - caricamentoStoricoFromGraduatoria: errore  ");
		}finally{
			session.close();
		}
	}
	
	
	
	public void updateStoricoFromGraduatoria(List<Graduatoria> instance, TipoGraduatoria tipoGraduatoria, TipoGraduatoriaHome tGHome) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("caricamentoStoricoFromGraduatoria dirty StoricoGraduatoria");
		
		try {
//			session = HibernateUtil.openSession();
//			trx = session.beginTransaction();
//			trx.begin();	
			
			//while ((countRow+1)<maxSizeTabel) {
			
			//elimino quello che c'� gia con quel progressivo
			
			StoricoGraduatoria storicoGraduatoriaDaEliminare = new StoricoGraduatoria();
			storicoGraduatoriaDaEliminare.setCodRegione(tipoGraduatoria.getCodRegione());
			storicoGraduatoriaDaEliminare.setnProgressivo(tipoGraduatoria.getProgressivo().toString());
			session.delete(storicoGraduatoriaDaEliminare);
			
			
			for (Graduatoria graduatoria : instance) {
					
					StoricoGraduatoria storicoGraduatoria = new StoricoGraduatoria();
					StoricoGraduatoriaId idKey = new StoricoGraduatoriaId();
					
					//storicoGraduatoria = storicoGraduatoriaHome.findById(id)
					PropertyUtils.copyProperties(storicoGraduatoria, graduatoria);
					
					idKey.setIdCandidatura(graduatoria.getIdCandidatura());
					idKey.setnProgressivo(""+tipoGraduatoria.getProgressivo());
					storicoGraduatoria.setIdKey(idKey);
					storicoGraduatoria.setnProgressivo(""+tipoGraduatoria.getProgressivo());
					storicoGraduatoria.setDataValidazione(tipoGraduatoria.getDataValutazione());
					storicoGraduatoria.setDataValidazioneString("");
					storicoGraduatoria.setColorExAequo(graduatoria.getColor());
//					storicoGraduatoria.setExAequoRisolto(graduatoria.getExAequoRisolto());
					
//					storicoGraduatoriaHome.saveOrUpdate(storicoGraduatoria);
					session.saveOrUpdate(storicoGraduatoria);
				}
				trx.commit();
				
				GestionePDFStampaGraduatoria gestionePDFStampaGraduatoria = new GestionePDFStampaGraduatoria();
		    	gestionePDFStampaGraduatoria.caricaDatiDaGraduatoriaEntityPDF(tipoGraduatoria.getCodRegione());
		    	gestionePDFStampaGraduatoria.creaGraduatoriaPDF();
	 	    	tipoGraduatoria.setGraduatoriaPDF(gestionePDFStampaGraduatoria.getGraduatoriaPDF());
				tipoGraduatoria.setStatoGraduatoria("V");
				
				tGHome.saveOrUpdate(tipoGraduatoria); 
			
		} catch(Exception e){
			trx.rollback();
			throw new GestioneErroriException("StoricoGraduatoriaHome - caricamentoStoricoFromGraduatoria: errore  ");
		}finally{
			session.close();
		}
	}
	
	public List findSchedeAll(RicercaStoricoGraduatoria scheda) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<String> listaSchede=new ArrayList<String>();
		
		try {
			
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			
//                                        0			        1                    2                    3              4                5    
			sb.append("select U.ID_DOMANDA_UTENTE,G.NUMERO_PROTOCOLLO,U.CODICE_FISCALE_UTENTE,U.COGNOME_UTENTE,U.NOME_UTENTE,C.MODALITA_CANDIDATURA,"+   
//                6             7                8                  9                                10
			"G.PUNTEGGIO,G.OSSERVAZIONI,D.FLAG_CONF_DOC_DIC ,D.DOC_PERVENUTA,TO_DATE (TO_CHAR (G.DATA_ISTRUTTORIA, 'YYYY-MON-DD HH24:MI:SS'),'YYYY-MON-DD HH24:MI:SS' ) " +
            "FROM UTENTE_REG U,GRADUATORIA G,CANDIDATURA_REG C,DICHIARAZIONE_SOSTITUTIVA_REG D" +
			" where (G.ID_CANDIDATURA = U.ID_DOMANDA_UTENTE and U.ID_DOMANDA_UTENTE = C.ID_CANDIDATURA and (C.MODALITA_CANDIDATURA ='S' "+
			"or (C.MODALITA_CANDIDATURA='A' and C.REFERENTE_DOMANDA='Y')) and U.ID_DOMANDA_UTENTE = D.ID_DOMANDA_DIC and U.COD_REG_UTENTE='"+cod_reg+"'");
			
			
			
			
			sb.append(") ORDER BY G.PUNTEGGIO DESC");
		  
			Query query = session.createSQLQuery(sb.toString());
			
			
			List results = query.list();
			 
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				Object[] row = (Object[]) iterator.next(); 
				listaSchede.add((String)row[0]);
			}		
			
			return listaSchede;
			
		}
		catch (RuntimeException re) { 
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}finally{
			session.close();
		}
	
	}
	
	
	
	public List<RicercaStoricoGraduatoria> findPage(RicercaStoricoGraduatoria scheda, List<String> utentiList) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<UtenteBean> listaCandidature=new ArrayList<UtenteBean>();
	
		String inSelect ="";
		String selectExt ="";
		for (int i = 0; i < utentiList.size(); i++) {
			if (i == (utentiList.size() -1)) {
				selectExt = selectExt + "select " +"'"+utentiList.get(i)+"' a from dual ";
			}else {
				selectExt = selectExt + "select " +"'"+utentiList.get(i)+"' a from dual union all ";
			}
			
			
			inSelect+="'"+utentiList.get(i)+"',";
		}
		inSelect=inSelect.substring(0, inSelect.length()-1)+")";
		
		List<RicercaStoricoGraduatoria> listaSchede=new ArrayList<RicercaStoricoGraduatoria>();
		
		try {
					
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			
//                                        0			        1                    2                    3              4                5    
			sb.append("select U.ID_DOMANDA_UTENTE,G.NUMERO_PROTOCOLLO,U.CODICE_FISCALE_UTENTE,U.COGNOME_UTENTE,U.NOME_UTENTE,C.MODALITA_CANDIDATURA,"+   
//                6             7               8                  9                                 10                        
			"G.PUNTEGGIO,G.OSSERVAZIONI,D.FLAG_CONF_DOC_DIC ,D.DOC_PERVENUTA,TO_DATE (TO_CHAR (G.DATA_ISTRUTTORIA, 'YYYY-MON-DD HH24:MI:SS'),'YYYY-MON-DD HH24:MI:SS') " +
            "FROM UTENTE_REG U,GRADUATORIA G,CANDIDATURA_REG C,DICHIARAZIONE_SOSTITUTIVA_REG D" +
			" where (G.ID_CANDIDATURA = U.ID_DOMANDA_UTENTE and U.ID_DOMANDA_UTENTE = C.ID_CANDIDATURA and (C.MODALITA_CANDIDATURA ='S' "+
			"or (C.MODALITA_CANDIDATURA='A' and C.REFERENTE_DOMANDA='Y')) and U.ID_DOMANDA_UTENTE = D.ID_DOMANDA_DIC and U.COD_REG_UTENTE='"+cod_reg+"' "+
			//"AND U.ID_UTENTE IN("+inSelect +"");
			" and exists (  select *  from (   " + selectExt + "  ) utenti  where u.id_utente = utenti.a  )");
			
		
			sb.append(") ORDER BY G.PUNTEGGIO DESC");
		  
			Query query = session.createSQLQuery(sb.toString());
			
			List results = query.list();
			 
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			RicercaStoricoGraduatoria schedaValutazione = null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				schedaValutazione=new RicercaStoricoGraduatoria("noInit");
				Object[] row = (Object[]) iterator.next(); 
				if (!((String)row[2]).toString().contains("*"))				
				schedaValutazione.setCognome((String)row[3]);
				schedaValutazione.setNome((String)row[4]);				
				listaSchede.add(schedaValutazione);
		}
			
			return listaSchede;
			
		} catch (RuntimeException re) {
			log.error("find by filter failed", re);
			throw new GestioneErroriException("SchedaHome - findByFilter: errore findByFilter");
		}finally{
			session.close();
		}
	
	}
	
	
	
	
	
	
	
}
