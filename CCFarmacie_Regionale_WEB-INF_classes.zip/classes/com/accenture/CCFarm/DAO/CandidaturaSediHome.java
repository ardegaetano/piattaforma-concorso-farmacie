package com.accenture.CCFarm.DAO;
import java.math.BigDecimal;
import java.sql.Clob;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.accenture.CCFarm.Bean.CandidatoSedeAssegnataListBean;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

public class CandidaturaSediHome {
	
	private static final Logger log = CommonLogger.getLogger("CandidaturaSediHome");
	
	private static final String flagValoreVero  = AppProperties.getAppProperties().getProperty("flag.valore.vero");
	
	@SuppressWarnings("unchecked")
	public List<CandidaturaSedi> getPreferenzeScelte(String idCandidatura) throws Exception {
		
		Session session = null;
		try {
			
			session = HibernateUtil.openSession();
			Criteria criteria = session.createCriteria(CandidaturaSedi.class);
			//condizioni
			criteria.add(Restrictions.eq("id.idCandidatura", idCandidatura));
			criteria.add(Restrictions.isNull("excludedDate"));
			//ordinamento
			criteria.addOrder(Order.asc("ordineScelta"));
			
			List<CandidaturaSedi> results = (List<CandidaturaSedi>) criteria.list();
			
			log.debug("CandidaturaSediHome - ricerca preferenze sedi avvenuta con successo");
			
			if(results == null || results.isEmpty())
				return null;
			
			return results;
		}
		catch(Exception e) {
			
			log.error("CandidaturaSediHome - ricerca preferenze sedi fallita", e);
			throw e;
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	public void associaCandidati(ArrayList<CandidaturaSedi> candidatureSedi) throws Exception {
		
		Session session = null;
		Transaction trx = null;
		try {
			
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			
			for(int i=0; i<candidatureSedi.size(); i++) {
				
				CandidaturaSedi candidaturaSedi = candidatureSedi.get(i);
				if(candidaturaSedi!=null) {
					candidaturaSedi.setFlagAssociata(flagValoreVero);
					session.saveOrUpdate(candidatureSedi.get(i));
				}
			}
			
			trx.commit();
		}
		catch(Exception e) {
			
			if(trx != null)
				trx.rollback();
			log.error("CandidaturaSediHome - associazione sedi fallita", e);
			throw e;
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<CandidatoSedeAssegnataListBean> getListaSediAbbinate(String codReg, BigDecimal idInterpello) throws GestioneErroriException {
		
		if(codReg == null || idInterpello == null)
			return null;
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			String hqlSelectString = "SELECT G.INDICE_TOTALE as posizioneGraduatoria,"+
				" G.INDICE_INTERPELLO as indiceInterpello,"+
				" SE.DESCR_PRV_FARM as provSede,"+
				" SE.FRAZIONE_FARM as comuneSede,"+
				" SE.N_PROGRESSIVO as ProgressivoSede,"+
				" SE.DESCRIZIONE_SEDE as sedeEstesa,"+
				" (G.NOME||' '||G.COGNOME) as nominativo,"+
				" G.NUMERO_PROTOCOLLO as numeroProtocollo,"+
				" U.PEC_MAIL as mailPEC,"+
				" C.REFERENTE_DOMANDA as tipoPartecipazione,"+
				" UT.DENOMINAZIONE_REG as altraRegionePartecipazione,"+
				" C.FLAG_SCELTA_SEDI as statoPartecipazione"+
				" FROM GRADUATORIA G, CANDIDATURA_REG C, UTENTE_REG UR, UTENTE U,"+
				" (SELECT B.CODICE_FISCALE_UTENTE, R.DENOMINAZIONE_REG"+
					" FROM UTENTE_REG B, CANDIDATURA_REG CDD, REGIONI R"+
					" WHERE B.COD_REG_UTENTE <> '"+codReg+"' AND B.COD_REG_UTENTE= R.COD_REG AND B.ID_UTENTE = CDD.id_utente) UT,"+
				" (SELECT CA.ID_CANDIDATURA, AF.DESCRIZIONE_SEDE, AF.DESCR_PRV_FARM, AF.FRAZIONE_FARM, AF.N_PROGRESSIVO FROM CANDIDATURA_REG CR, CANDIDATURA_SEDI CA, ANAGRAFICA_FARM_INTERPELLI AF"+ 
					" WHERE CA.ID_CANDIDATURA = CR.ID_CANDIDATURA AND CR.FLAG_SCELTA_SEDI = 'true' AND CA.ID_FARM = AF.ID_FARM "+
					" AND AF.COD_REG_FARM = '"+codReg+"' AND AF.ID_INTERPELLO = "+idInterpello+ 
					" AND CA.FLAG_ASSOCIATA='true') SE"+     
				" WHERE G.COD_REGIONALE = '"+codReg+"'"+
				" AND G.ID_INTERPELLO = "+idInterpello+
				" AND C.ID_CANDIDATURA = G.ID_CANDIDATURA"+
				" AND ((C.REFERENTE_DOMANDA is null AND C.MODALITA_CANDIDATURA = 'S') OR (C.REFERENTE_DOMANDA = 'Y' AND C.MODALITA_CANDIDATURA = 'A'))"+
				" AND UR.ID_UTENTE = C.ID_UTENTE"+
				" AND UR.ID_UTENTE = U.ID_UTENTE"+
				" AND U.CODICE_FISCALE_UTENTE = UT.CODICE_FISCALE_UTENTE(+)"+
				" AND C.ID_CANDIDATURA = SE.ID_CANDIDATURA(+)"+
				" ORDER BY G.INDICE_TOTALE ASC";
			
			List<CandidatoSedeAssegnataListBean> listaCandidatiSede=new ArrayList<CandidatoSedeAssegnataListBean>();
			List results = session.createSQLQuery(hqlSelectString).list();
			log.debug("getListaSediAbbinate: find by filter successful, result size: "+ results.size());
			
			CandidatoSedeAssegnataListBean candidato = null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				candidato=new CandidatoSedeAssegnataListBean();
				Object[] row = (Object[]) iterator.next(); 
				candidato.setPosizioneGraduatoria((BigDecimal)row[0]);
				candidato.setIndiceInterpello((BigDecimal)row[1]);
				String sSede = ((String)row[2]!=null && (!((String)row[2]).equals(""))) ? (String)row[2]+" - "+(String)row[3]+" - "+(String)row[4] : "-";
				candidato.setSede(sSede);
				candidato.setSedeEstesa((Clob)(row[5]));
				candidato.setNominativo((String)row[6]);
				candidato.setNumeroProtocollo((String)row[7]);
				candidato.setMailPEC((String)row[8]);
				candidato.setTipoPartecipazione((String)row[9]);
				candidato.setAltraRegionePartecipazione((String)row[10]!=null && (!((String)row[10]).equals("")) ? (String)row[10] : "-");
				candidato.setStatoPartecipazione(((String)row[11]!=null && ((String)row[11]).equals("true")) ? "Preferenza inviata" : "Mancata preferenza");
				
				listaCandidatiSede.add(candidato);
			}
			
			return listaCandidatiSede;
		}
		catch(Exception e) {
			
			log.error("CandidaturaSediHome - getListaSediAbbinate fallita", e);
			throw new GestioneErroriException("CandidaturaSediHome - getListaSediAbbinate fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	public String getNumCandidatiConSedeAssegnata(String codReg, BigDecimal idInterpello) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT COUNT(G.ID_CANDIDATURA) as CANDIDATI_SEDE"+
					" FROM GRADUATORIA G, Anagrafica_Farm_Interpelli af, Candidatura_Sedi cs"+
					" WHERE G.COD_REGIONALE = '"+codReg+"'"+
					" AND G.ID_INTERPELLO = "+idInterpello+
					" AND G.ID_CANDIDATURA = cs.id_Candidatura AND cs.flag_Associata = 'true'"+
					" AND g.cod_Regionale = af.cod_Reg_Farm AND g.id_Interpello = af.id_Interpello"+
					" AND AF.ID_FARM = CS.ID_FARM").list();
			BigDecimal num = (BigDecimal)query.get(0);
			return ""+num;
		} catch (RuntimeException re) {
			throw new GestioneErroriException("CandidaturaSediHome - getNumCandidatiConSede: errore");
		}
		finally{
			session.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	public String getNumCandidatiSenzaSedeAssegnata(String codReg, BigDecimal idInterpello) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT COUNT(G.ID_CANDIDATURA) as CANDIDATI_SENZA_SEDE"+
					" FROM GRADUATORIA G, Candidatura_reg cr"+
					" WHERE G.COD_REGIONALE = '"+codReg+"'"+
					" AND G.ID_INTERPELLO = "+idInterpello+
					" AND G.ID_CANDIDATURA = cr.id_utente"+
					" AND (cr.FLAG_SCELTA_SEDI is null or cr.FLAG_SCELTA_SEDI <>'true')").list();
			BigDecimal num = (BigDecimal)query.get(0);
			return ""+num;
		} catch (RuntimeException re) {
			throw new GestioneErroriException("CandidaturaSediHome - getNumCandidatiConSede: errore");
		}
		finally{
			session.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<CandidatoSedeAssegnataListBean> getListaSediAccettate(String codReg, BigDecimal idInterpello) throws GestioneErroriException {
		
		if(codReg == null || idInterpello == null)
			return null;
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			String hqlSelectString = "SELECT G.INDICE_TOTALE as posizioneGraduatoria,"+
				" G.INDICE_INTERPELLO as indiceInterpello,"+
				" SE.DESCR_PRV_FARM as provSede,"+
				" SE.FRAZIONE_FARM as comuneSede,"+
				" SE.N_PROGRESSIVO as ProgressivoSede,"+
				" SE.DESCRIZIONE_SEDE as sedeEstesa,"+
				" (G.NOME||' '||G.COGNOME) as nominativo,"+
				" G.NUMERO_PROTOCOLLO as numeroProtocollo,"+
				" U.PEC_MAIL as mailPEC,"+
				" C.REFERENTE_DOMANDA as tipoPartecipazione,"+
				" UT.DENOMINAZIONE_REG as altraRegionePartecipazione,"+
				" C.FLAG_SCELTA_SEDI as statoPartecipazione,"+
				" SE.FLAG_CONFERMATA as statoAccettazione"+
				" FROM GRADUATORIA G, CANDIDATURA_REG C, UTENTE_REG UR, UTENTE U,"+
				" (SELECT B.CODICE_FISCALE_UTENTE, R.DENOMINAZIONE_REG"+
					" FROM UTENTE_REG B, CANDIDATURA_REG CDD, REGIONI R"+
					" WHERE B.COD_REG_UTENTE <> '"+codReg+"' AND B.COD_REG_UTENTE= R.COD_REG AND B.ID_UTENTE = CDD.id_utente) UT,"+
				" (SELECT CA.ID_CANDIDATURA, AF.DESCRIZIONE_SEDE, AF.DESCR_PRV_FARM, AF.FRAZIONE_FARM, AF.N_PROGRESSIVO, CA.FLAG_CONFERMATA FROM CANDIDATURA_REG CR, CANDIDATURA_SEDI CA, ANAGRAFICA_FARM_INTERPELLI AF"+ 
					" WHERE CA.ID_CANDIDATURA = CR.ID_CANDIDATURA AND CR.FLAG_SCELTA_SEDI = 'true' AND CA.ID_FARM = AF.ID_FARM "+
					" AND AF.COD_REG_FARM = '"+codReg+"' AND AF.ID_INTERPELLO = "+idInterpello+ 
					" AND CA.FLAG_ASSOCIATA='true') SE"+     
				" WHERE G.COD_REGIONALE = '"+codReg+"'"+
				" AND G.ID_INTERPELLO = "+idInterpello+
				" AND C.ID_CANDIDATURA = G.ID_CANDIDATURA"+
				" AND ((C.REFERENTE_DOMANDA is null AND C.MODALITA_CANDIDATURA = 'S') OR (C.REFERENTE_DOMANDA = 'Y' AND C.MODALITA_CANDIDATURA = 'A'))"+
				" AND UR.ID_UTENTE = C.ID_UTENTE"+
				" AND UR.ID_UTENTE = U.ID_UTENTE"+
				" AND U.CODICE_FISCALE_UTENTE = UT.CODICE_FISCALE_UTENTE(+)"+
				" AND C.ID_CANDIDATURA = SE.ID_CANDIDATURA(+)"+
				" ORDER BY G.INDICE_TOTALE ASC";
			
			List<CandidatoSedeAssegnataListBean> listaCandidatiSede=new ArrayList<CandidatoSedeAssegnataListBean>();
			List results = session.createSQLQuery(hqlSelectString).list();
			log.debug("getListaSediAbbinate: find by filter successful, result size: "+ results.size());
			
			CandidatoSedeAssegnataListBean candidato = null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				candidato=new CandidatoSedeAssegnataListBean();
				Object[] row = (Object[]) iterator.next(); 
				candidato.setPosizioneGraduatoria((BigDecimal)row[0]);
				candidato.setIndiceInterpello((BigDecimal)row[1]);
				String sSede = ((String)row[2]!=null && (!((String)row[2]).equals(""))) ? (String)row[2]+" - "+(String)row[3]+" - "+(String)row[4] : "-";
				candidato.setSede(sSede);
				candidato.setSedeEstesa((Clob)(row[5]));
				candidato.setNominativo((String)row[6]);
				candidato.setNumeroProtocollo((String)row[7]);
				candidato.setMailPEC((String)row[8]);
				candidato.setTipoPartecipazione((String)row[9]);
				candidato.setAltraRegionePartecipazione((String)row[10]!=null && (!((String)row[10]).equals("")) ? (String)row[10] : "-");
				String sStatoPartecipaz = ((String)row[11]!=null && (!((String)row[11]).equals(""))) ? (String)row[11]: null;
				String sStatoAccettaz = ((String)row[12]!=null && (!((String)row[12]).equals(""))) ? (String)row[12]: null;
				String descrPartecipazione = ((sStatoAccettaz!=null &&  sStatoAccettaz.equals("true")) ? "Sede accettata" : 
					(sStatoAccettaz!=null && sStatoAccettaz.equals("false")) ? "Sede rifiutata" : 
					(sStatoPartecipaz == null || !sStatoPartecipaz.equalsIgnoreCase("true")) ? "Mancata preferenza" :
					(sStatoAccettaz==null || sStatoAccettaz.equals("")) ? "Mancata accettazione/rifiuto":"");
					;
				candidato.setStatoPartecipazione(descrPartecipazione);
				if(descrPartecipazione.equals("Sede accettata"))
					candidato.setStyleRowSede("true");
				
				listaCandidatiSede.add(candidato);
			}
			
			return listaCandidatiSede;
		}
		catch(Exception e) {
			
			log.error("CandidaturaSediHome - getListaSediAbbinate fallita", e);
			throw new GestioneErroriException("CandidaturaSediHome - getListaSediAbbinate fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	public String getNumCandidatiConSedeAccettata(String codReg, BigDecimal idInterpello) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT COUNT(G.ID_CANDIDATURA) as CANDIDATI_SEDE"+
					" FROM GRADUATORIA G, Anagrafica_Farm_Interpelli af, Candidatura_Sedi cs"+
					" WHERE G.COD_REGIONALE = '"+codReg+"'"+
					" AND G.ID_INTERPELLO = "+idInterpello+
					" AND G.ID_CANDIDATURA = cs.id_Candidatura AND cs.flag_Confermata = 'true'"+
					" AND g.cod_Regionale = af.cod_Reg_Farm AND g.id_Interpello = af.id_Interpello"+
					" AND AF.ID_FARM = CS.ID_FARM").list();
			
			BigDecimal num = (BigDecimal)query.get(0);
			return ""+num;
		} catch (RuntimeException re) {
			throw new GestioneErroriException("CandidaturaSediHome - getNumCandidatiConSede: errore");
		}
		finally{
			session.close();
		}
	}
	
	@SuppressWarnings("unchecked")
	public String getNumCandidatiSenzaSede(String codReg, BigDecimal idInterpello) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT COUNT(CANDIDATI_SENZA_SEDE) "+
					" FROM (SELECT G.ID_CANDIDATURA as CANDIDATI_SENZA_SEDE"+ 
						" FROM GRADUATORIA G, Candidatura_reg cr"+
						" WHERE G.COD_REGIONALE = '"+codReg+"'"+
						" AND G.ID_INTERPELLO = "+idInterpello+
						" AND G.ID_CANDIDATURA = cr.id_utente"+
						" AND (cr.FLAG_SCELTA_SEDI is null or cr.FLAG_SCELTA_SEDI <>'true' )"+
					" UNION("+         
						" SELECT CA.ID_CANDIDATURA as CANDIDATI_SENZA_SEDE"+
						" FROM CANDIDATURA_REG CR, CANDIDATURA_SEDI CA, ANAGRAFICA_FARM_INTERPELLI AF"+ 
			            " WHERE CA.ID_CANDIDATURA = CR.ID_CANDIDATURA AND CR.FLAG_SCELTA_SEDI = 'true' AND CA.ID_FARM = AF.ID_FARM"+ 
			            " AND AF.COD_REG_FARM = '"+codReg+"' AND AF.ID_INTERPELLO = "+idInterpello+
			            " AND CA.FLAG_ASSOCIATA='true' AND (CA.FLAG_CONFERMATA is null or CA.FLAG_CONFERMATA  <>'true')))").list();
			
			BigDecimal num = (BigDecimal)query.get(0);
			return ""+num;
		} catch (RuntimeException re) {
			throw new GestioneErroriException("CandidaturaSediHome - getNumCandidatiConSede: errore");
		}
		finally{
			session.close();
		}
	}

}
