package com.accenture.CCFarm.DAO;

@SuppressWarnings("serial")
public class Provincia implements java.io.Serializable {

	private String codiceProvincia;
	private String denominazioneProvincia;
	private String siglaAutomobilistica;
	private String codiceRegione;
	
	public Provincia() {}
	
	public Provincia(String codiceProvincia, String denominazioneProvincia,
			String siglaAutomobilistica, String codiceRegione) {
		this.codiceProvincia = codiceProvincia;
		this.denominazioneProvincia = denominazioneProvincia;
		this.siglaAutomobilistica = siglaAutomobilistica;
		this.codiceRegione = codiceRegione;
	}
	
	public String getCodiceProvincia() {
		return codiceProvincia;
	}

	public void setCodiceProvincia(String codiceProvincia) {
		this.codiceProvincia = codiceProvincia;
	}

	public String getDenominazioneProvincia() {
		return denominazioneProvincia;
	}

	public void setDenominazioneProvincia(String denominazioneProvincia) {
		this.denominazioneProvincia = denominazioneProvincia;
	}

	public String getSiglaAutomobilistica() {
		return siglaAutomobilistica;
	}

	public void setSiglaAutomobilistica(String siglaAutomobilistica) {
		this.siglaAutomobilistica = siglaAutomobilistica;
	}

	public String getCodiceRegione() {
		return codiceRegione;
	}

	public void setCodiceRegione(String codiceRegione) {
		this.codiceRegione = codiceRegione;
	}
}