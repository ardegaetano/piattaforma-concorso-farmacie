package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class RequisitiMinimiReg.
 * @see com.accenture.CCFarm.DAO.RequisitiMinimiReg
 * @author Hibernate Tools
 */
public class RequisitiMinimiRegHome {

//	private static final Log log = LogFactory.getLog(RequisitiMinimiHome.class);
	private static final Logger log = CommonLogger.getLogger("RequisitiMinimiHome");
	
	public void persist(RequisitiMinimiReg transientInstance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting RequisitiMinimiReg instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("RequisitiMinimiRegHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(RequisitiMinimiReg instance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty RequisitiMinimiReg instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw new GestioneErroriException("RequisitiMinimiRegHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(RequisitiMinimiReg instance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean RequisitiMinimiReg instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("RequisitiMinimiRegHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(RequisitiMinimiReg persistentInstance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting RequisitiMinimiReg instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("RequisitiMinimiRegHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public RequisitiMinimiReg merge(RequisitiMinimiReg detachedInstance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging RequisitiMinimiReg instance");
		try {
			RequisitiMinimiReg result = (RequisitiMinimiReg) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("RequisitiMinimiRegHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public RequisitiMinimiReg findById(java.lang.String id)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting RequisitiMinimiReg instance with id: " + id);
		try {
			RequisitiMinimiReg instance = (RequisitiMinimiReg) session.get("com.accenture.CCFarm.DAO.RequisitiMinimiReg", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("RequisitiMinimiRegHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(RequisitiMinimiReg instance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding RequisitiMinimiReg instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.RequisitiMinimiReg")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("RequisitiMinimiRegHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
public boolean updateFlagElabManuale(String codRegione) throws GestioneErroriException{
		
		log.debug("update Flag ElabManuale");
		Session session = null;
        String stringaQuery = null;
	
		try {
			
            session = HibernateUtil.openSession();
            Transaction trx = session.beginTransaction();
            
            stringaQuery = "UPDATE REQUISITI_MINIMI_REG SET ELAB_MANUALE_LAUREA='false' ELAB_MANUALE_ABILITAZIONE='false'" +
                           " WHERE COD_REG ='"+codRegione+"'";


              
            Query query = session.createSQLQuery(stringaQuery);
            trx.commit();
            return true;

		} catch (RuntimeException re) {
			log.error("updateFlagElabManuale- update dei flag di elaborazione manuale per rilanciare il batch in modalit� all", re);
			throw new GestioneErroriException("UtenteRegHome - update Flag ElabManuale: errore ");
		}
		finally{
			session.close();
		}
	
	}
}
