package com.accenture.CCFarm.DAO;


@SuppressWarnings("serial")
public class LogIn implements java.io.Serializable {

	private String utenza;
	private String password;
	private String idUtente;
	private String idRegione;
	
	public LogIn() {}
	
	public LogIn(String utenza, String password, String idUtente, String idRegione) {
		super();
		this.utenza = utenza;
		this.password = password;
		this.idUtente = idUtente;
		this.idRegione = idRegione;
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public String getUtenza() {
		return utenza;
	}

	public void setUtenza(String utenza) {
		this.utenza = utenza;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIdRegione() {
		return idRegione;
	}

	public void setIdRegione(String idRegione) {
		this.idRegione = idRegione;
	}

	
	
}