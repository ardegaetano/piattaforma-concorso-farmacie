package com.accenture.CCFarm.DAO;

import java.util.List;


public class Titoli {

	
	
	
	
	public String  parzialeTitolo[];
	
	public String  color[];
	
	
	private List<RequisitiMinimiReg> requisitiMinimiReg;
	
	private List<AltraLaureaReg> altraLaureaReg;
	
	private List<AltraLaureaBisReg> altraLaureaBisReg;
	
	private List<SpecializzazioneReg> specializzazioneReg;
	
	private List<DottoratoReg> dottoratoReg;
	
	private List<BorsaStudioReg> borsaStudioReg;
	
	private List<PubblicazioneReg> pubblicazioneReg;
	
	private List<IdoneitaReg> idoneitaReg;
	
	private List<CorsoAggiornamentoReg> corsoAggiornamentoReg;
	
	private List<AltroTitoloReg> altroTitoloReg;
	
	
	public Titoli() {
		super();
		
		this.parzialeTitolo = new String[9];
		this.color = new String[9];
		
		
		//altraLaureaBisList = new ArrayList<AltraLaureaBisReg>();
		
	}

	public String[] getParzialeTitolo() {
		return parzialeTitolo;
	}

	public void setParzialeTitolo(String[] parzialeTitolo) {
		this.parzialeTitolo = parzialeTitolo;
	}

	public List<RequisitiMinimiReg> getRequisitiMinimiReg() {
		return requisitiMinimiReg;
	}

	public void setRequisitiMinimiReg(List<RequisitiMinimiReg> requisitiMinimiReg) {
		this.requisitiMinimiReg = requisitiMinimiReg;
	}

	public List<AltraLaureaReg> getAltraLaureaReg() {
		return altraLaureaReg;
	}

	public void setAltraLaureaReg(List<AltraLaureaReg> altraLaureaReg) {
		this.altraLaureaReg = altraLaureaReg;
	}

	public List<AltraLaureaBisReg> getAltraLaureaBisReg() {
		return altraLaureaBisReg;
	}

	public void setAltraLaureaBisReg(List<AltraLaureaBisReg> altraLaureaBisReg) {
		this.altraLaureaBisReg = altraLaureaBisReg;
	}

	public List<SpecializzazioneReg> getSpecializzazioneReg() {
		return specializzazioneReg;
	}

	public void setSpecializzazioneReg(List<SpecializzazioneReg> specializzazioneReg) {
		this.specializzazioneReg = specializzazioneReg;
	}

	public List<DottoratoReg> getDottoratoReg() {
		return dottoratoReg;
	}

	public void setDottoratoReg(List<DottoratoReg> dottoratoReg) {
		this.dottoratoReg = dottoratoReg;
	}

	public List<BorsaStudioReg> getBorsaStudioReg() {
		return borsaStudioReg;
	}

	public void setBorsaStudioReg(List<BorsaStudioReg> borsaStudioReg) {
		this.borsaStudioReg = borsaStudioReg;
	}

	public List<PubblicazioneReg> getPubblicazioneReg() {
		return pubblicazioneReg;
	}

	public void setPubblicazioneReg(List<PubblicazioneReg> pubblicazioneReg) {
		this.pubblicazioneReg = pubblicazioneReg;
	}

	public List<IdoneitaReg> getIdoneitaReg() {
		return idoneitaReg;
	}

	public void setIdoneitaReg(List<IdoneitaReg> idoneitaReg) {
		this.idoneitaReg = idoneitaReg;
	}

	public List<CorsoAggiornamentoReg> getCorsoAggiornamentoReg() {
		return corsoAggiornamentoReg;
	}

	public void setCorsoAggiornamentoReg(
			List<CorsoAggiornamentoReg> corsoAggiornamentoReg) {
		this.corsoAggiornamentoReg = corsoAggiornamentoReg;
	}

	public List<AltroTitoloReg> getAltroTitoloReg() {
		return altroTitoloReg;
	}

	public void setAltroTitoloReg(List<AltroTitoloReg> altroTitoloReg) {
		this.altroTitoloReg = altroTitoloReg;
	}

	public String[] getColor() {
		return color;
	}

	public void setColor(String[] color) {
		this.color = color;
	}

	
	
	
	
	
}
