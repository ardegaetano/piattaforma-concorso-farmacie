package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.Date;

@SuppressWarnings("serial")
public class TipoGraduatoria implements java.io.Serializable {

	private TipoGraduatoriaId idKey;


	private String descrizione;
	private String codRegione;
	private String codTipologiaGraduatoria;
	private BigDecimal progressivo;
	private Date dataValutazione;
	private byte[] graduatoriaPDF;
	private byte[] attoAmministrativoPDF;
	private Date dataPublicazione;
	private String statoGraduatoria;
	private String numeroBollettinoUffReg;
	private Date dataBollettinoUffReg;
	
	
	public TipoGraduatoria() {}

	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}

	public String getCodTipologiaGraduatoria() {
		return codTipologiaGraduatoria;
	}

	public void setCodTipologiaGraduatoria(String codTipologiaGraduatoria) {
		this.codTipologiaGraduatoria = codTipologiaGraduatoria;
	}

	public BigDecimal getProgressivo() {
		return progressivo;
	}

	public void setProgressivo(BigDecimal progressivo) {
		this.progressivo = progressivo;
	}

	public Date getDataValutazione() {
		return dataValutazione;
	}

	public void setDataValutazione(Date dataValutazione) {
		this.dataValutazione = dataValutazione;
	}

	public TipoGraduatoriaId getIdKey() {
		return idKey;
	}

	public void setIdKey(TipoGraduatoriaId idKey) {
		this.idKey = idKey;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public byte[] getGraduatoriaPDF() {
		return graduatoriaPDF;
	}

	public void setGraduatoriaPDF(byte[] graduatoriaPDF) {
		this.graduatoriaPDF = graduatoriaPDF;
	}

	public byte[] getAttoAmministrativoPDF() {
		return attoAmministrativoPDF;
	}

	public void setAttoAmministrativoPDF(byte[] attoAmministrativoPDF) {
		this.attoAmministrativoPDF = attoAmministrativoPDF;
	}

	public Date getDataPublicazione() {
		return dataPublicazione;
	}

	public void setDataPublicazione(Date dataPublicazione) {
		this.dataPublicazione = dataPublicazione;
	}

	public String getStatoGraduatoria() {
		return statoGraduatoria;
	}

	public void setStatoGraduatoria(String statoGraduatoria) {
		this.statoGraduatoria = statoGraduatoria;
	}

	public String getNumeroBollettinoUffReg() {
		return numeroBollettinoUffReg;
	}

	public void setNumeroBollettinoUffReg(String numeroBollettinoUffReg) {
		this.numeroBollettinoUffReg = numeroBollettinoUffReg;
	}

	public Date getDataBollettinoUffReg() {
		return dataBollettinoUffReg;
	}

	public void setDataBollettinoUffReg(Date dataBollettinoUffReg) {
		this.dataBollettinoUffReg = dataBollettinoUffReg;
	}
	
	
	
		
}