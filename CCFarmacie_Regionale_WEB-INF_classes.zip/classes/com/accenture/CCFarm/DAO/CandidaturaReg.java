package com.accenture.CCFarm.DAO;

import java.io.Serializable;
import java.util.Date;

public class CandidaturaReg implements java.io.Serializable {

	private String idCandidatura;
	private String idUtente;
	private String codiceRegione;
	private String modalitaCandidatura;
	private String referenteDomanda;
	private String ammesso;
	private String erroreElabAutomatica;
	private String elabRettifica;
	private String elabAutomatica;
	private Serializable lastUpdateDate;
	private String protocolliRiassegnati;
	private Date dataNonAmmissione;
	private String flagSceltaSedi;
	private String flagAbilitaSceltaSedi;
	
	public String getIdCandidatura() {
		return idCandidatura;
	}
	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}
	public String getIdUtente() {
		return idUtente;
	}
	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}
	public String getCodiceRegione() {
		return codiceRegione;
	}
	public void setCodiceRegione(String codiceRegione) {
		this.codiceRegione = codiceRegione;
	}
	public String getModalitaCandidatura() {
		return modalitaCandidatura;
	}
	public void setModalitaCandidatura(String modalitaCandidatura) {
		this.modalitaCandidatura = modalitaCandidatura;
	}
	public String getReferenteDomanda() {
		return referenteDomanda;
	}
	public void setReferenteDomanda(String referenteDomanda) {
		this.referenteDomanda = referenteDomanda;
	}
	public String getAmmesso() {
		return ammesso;
	}
	public void setAmmesso(String ammesso) {
		this.ammesso = ammesso;
	}
	public String getErroreElabAutomatica() {
		return erroreElabAutomatica;
	}
	public void setErroreElabAutomatica(String erroreElabAutomatica) {
		this.erroreElabAutomatica = erroreElabAutomatica;
	}
	public String getElabRettifica() {
		return elabRettifica;
	}
	public void setElabRettifica(String elabRettifica) {
		this.elabRettifica = elabRettifica;
	}
	public String getElabAutomatica() {
		return elabAutomatica;
	}
	public void setElabAutomatica(String elabAutomatica) {
		this.elabAutomatica = elabAutomatica;
	}
	public Serializable getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(Serializable lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	public String getProtocolliRiassegnati() {
		return protocolliRiassegnati;
	}
	public void setProtocolliRiassegnati(String protocolliRiassegnati) {
		this.protocolliRiassegnati = protocolliRiassegnati;
	}
	public Date getDataNonAmmissione() {
		return dataNonAmmissione;
	}
	public void setDataNonAmmissione(Date dataNonAmmissione) {
		this.dataNonAmmissione = dataNonAmmissione;
	}
	public String getFlagSceltaSedi() {
		return flagSceltaSedi;
	}
	public void setFlagSceltaSedi(String flagSceltaSedi) {
		this.flagSceltaSedi = flagSceltaSedi;
	}
	public String getFlagAbilitaSceltaSedi() {
		return flagAbilitaSceltaSedi;
	}
	public void setFlagAbilitaSceltaSedi(String flagAbilitaSceltaSedi) {
		this.flagAbilitaSceltaSedi = flagAbilitaSceltaSedi;
	}
	
}
