package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;



/**
 * Home object for domain model class Pubblicazione.
 * @see com.accenture.CCFarm.DAO.Pubblicazione
 * @author Hibernate Tools
 */
public class PubblicazioneRegHome {

//	private static final Log log = LogFactory.getLog(PubblicazioneHome.class);
	private static final Logger log = CommonLogger.getLogger("PubblicazioneRegHome");

	public void persist(PubblicazioneReg transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting PubblicazioneReg instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("PubblicazioneRegHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(PubblicazioneReg instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty PubblicazioneReg instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw new GestioneErroriException("PubblicazioneRegHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(PubblicazioneReg instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean PubblicazioneReg instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("PubblicazioneRegHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(PubblicazioneReg persistentInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting PubblicazioneReg instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("PubblicazioneRegHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public PubblicazioneReg merge(PubblicazioneReg detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging PubblicazioneReg instance");
		try {
			PubblicazioneReg result = (PubblicazioneReg) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("PubblicazioneRegHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public PubblicazioneReg findById(java.lang.String id) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting PubblicazioneReg instance with id: " + id);
		try {
			PubblicazioneReg instance = (PubblicazioneReg) session.get("com.accenture.CCFarm.DAO.PubblicazioneReg", id);			
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("PubblicazioneRegHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(PubblicazioneReg instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding PubblicazioneReg instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.PubblicazioneReg")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("PubblicazioneRegHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	public String getSequenceIdPubblicazione() throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_PUBBLICAZIONE.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			//log.error("getSequenceIdPubblicazione() - "+ PrintException.stack2string(re));
			throw new GestioneErroriException("PubblicazioneRegHome - getSequenceIdPubblicazione: errore getSequenceIdPubblicazione");
		}
		finally{
			session.close();
		}
	}
	
}
