package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:11 AM by Hibernate Tools 3.4.0.CR1

import java.util.Date;

@SuppressWarnings("serial")
public class DocumentoReg implements java.io.Serializable {

	private String idDocumento;
	private String idDomandaDocumento;
	private String tipoDocumento;

	public DocumentoReg() {
	}

	public DocumentoReg(String idDocumento,String idDomandaDocumento) {
		super();
		this.idDocumento = idDocumento;
		this.idDomandaDocumento= idDomandaDocumento;
	}
	
	public DocumentoReg(String idDocumento, String idDomandaDocumento,
			String tipoDocumento) {
		super();
		this.idDocumento = idDocumento;
		this.idDomandaDocumento = idDomandaDocumento;
		this.tipoDocumento = tipoDocumento;
			}

	public String getIdDocumento() {
		return idDocumento;
	}

	public void setIdDocumento(String idDocumento) {
		this.idDocumento = idDocumento;
	}

	public String getIdDomandaDocumento() {
		return idDomandaDocumento;
	}

	public void setIdDomandaDocumento(String idDomandaDocumento) {
		this.idDomandaDocumento = idDomandaDocumento;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}


}
