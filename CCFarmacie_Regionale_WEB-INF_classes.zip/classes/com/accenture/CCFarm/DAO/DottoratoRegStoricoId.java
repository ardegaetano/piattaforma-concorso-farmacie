package com.accenture.CCFarm.DAO;

public class DottoratoRegStoricoId implements java.io.Serializable {

	private String idStorico;
	private String idDottorato;
	
	public DottoratoRegStoricoId(){
	}

	public String getIdStorico() {
		return idStorico;
	}

	public void setIdStorico(String idStorico) {
		this.idStorico = idStorico;
	}

	public String getIdDottorato() {
		return idDottorato;
	}

	public void setIdDottorato(String idDottorato) {
		this.idDottorato = idDottorato;
	}
	
}