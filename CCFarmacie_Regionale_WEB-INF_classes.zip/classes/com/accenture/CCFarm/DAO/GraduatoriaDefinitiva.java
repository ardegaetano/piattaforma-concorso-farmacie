package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.Date;

@SuppressWarnings("serial")
public class GraduatoriaDefinitiva implements java.io.Serializable {

	private String idCandidatura;
	private String numeroProtocollo;
	private String cognome;
	private String nome;
	private String codRegione;
	private BigDecimal etaMedia;
	private BigDecimal punteggio; 
	private String dataNascita;
	private BigDecimal indiceTotale;
	private BigDecimal indiceRelativo;
	private String exAequo;
	private String exAequoRisolto;
	
	public GraduatoriaDefinitiva() {}
	
	public GraduatoriaDefinitiva(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}
	


	public GraduatoriaDefinitiva(String idCandidatura, String numeroProtocollo, String cognome, String nome, String codRegione, BigDecimal etaMedia, BigDecimal punteggio, String validata, String elaborazione, String versione, String osservazioni,
			Date dataIstruttoria, BigDecimal punteggioTitolo, BigDecimal punteggioEsperienza, BigDecimal punteggioLaurea, BigDecimal punteggioAltraLaurea, BigDecimal punteggioAltraLaureaBis, BigDecimal punteggioIdoneita,
			BigDecimal punteggioIdoneitaNazionale, BigDecimal punteggioAbilitazione, Clob note) {
		super();
		this.idCandidatura = idCandidatura;
		this.numeroProtocollo = numeroProtocollo;
		this.cognome = cognome;
		this.nome = nome;
		this.codRegione = codRegione;
		this.etaMedia = etaMedia;
		this.punteggio = punteggio;
	}

	public String getIdCandidatura() {
		return idCandidatura;
	}

	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}

	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}

	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public BigDecimal getPunteggio() {
		return punteggio;
	}

	public void setPunteggio(BigDecimal punteggio) {
		this.punteggio = punteggio;
	}
 
	
	
	public BigDecimal getIndiceTotale() {
		return indiceTotale;
	}



	public void setIndiceTotale(BigDecimal indiceTotale) {
		this.indiceTotale = indiceTotale;
	}



	public BigDecimal getIndiceRelativo() {
		return indiceRelativo;
	}



	public void setIndiceRelativo(BigDecimal indiceRelativo) {
		this.indiceRelativo = indiceRelativo;
	}



	public String getExAequo() {
		return exAequo;
	}



	public void setExAequo(String exAequo) {
		this.exAequo = exAequo;
	}



	public String getExAequoRisolto() {
		return exAequoRisolto;
	}



	public void setExAequoRisolto(String exAequoRisolto) {
		this.exAequoRisolto = exAequoRisolto;
	}



	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}


	public BigDecimal getEtaMedia() {
		return etaMedia;
	}


	public void setEtaMedia(BigDecimal etaMedia) {
		this.etaMedia = etaMedia;
	}



	public String getDataNascita() {
		return dataNascita;
	}



	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}





}