package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.util.Date;





@SuppressWarnings("serial")
public class AltraLaureaRegStorico implements java.io.Serializable{

	private String idStorico;
	private String miUtente;
	private java.sql.Timestamp dataUltimaModifica;
	
	private String idSecondaLaurea;
	private String descUniSecondaLaurea;
	private Date dataSecondaLaurea;
	private String idDomandaLaurea;
	private String luogoSecondaLaurea;
	private String nazioneSecondaLaurea;
	private String flagEsteroSecondaLaurea;
	private BigDecimal punteggio;
	//private BigDecimal punteggio;
	
	

	public AltraLaureaRegStorico() {
	}


	public AltraLaureaRegStorico(String idSecondaLaurea, String descUniSecondaLaurea,
			Date dataSecondaLaurea, String idDomandaLaurea,
			String luogoSecondaLaurea, String nazioneSecondaLaurea,
			String flagEsteroSecondaLaurea, String valida, String docPervenuta,
			BigDecimal punteggio) {
		super();
		this.idSecondaLaurea = idSecondaLaurea;
		this.descUniSecondaLaurea = descUniSecondaLaurea;
		this.dataSecondaLaurea = dataSecondaLaurea;
		this.idDomandaLaurea = idDomandaLaurea;
		this.luogoSecondaLaurea = luogoSecondaLaurea;
		this.nazioneSecondaLaurea = nazioneSecondaLaurea;
		this.flagEsteroSecondaLaurea = flagEsteroSecondaLaurea;
		this.punteggio = punteggio;
	}





	public String getFlagEsteroSecondaLaurea() {
		return flagEsteroSecondaLaurea;
	}

	public void setFlagEsteroSecondaLaurea(String flagEsteroSecondaLaurea) {
		this.flagEsteroSecondaLaurea = flagEsteroSecondaLaurea;
	}

	public String getIdDomandaLaurea() {
		return this.idDomandaLaurea;
	}

	public void setIdDomandaLaurea(String idDomandaLaurea) {
		this.idDomandaLaurea = idDomandaLaurea;
	}

	public String getIdSecondaLaurea() {
		return idSecondaLaurea;
	}

	public void setIdSecondaLaurea(String idSecondaLaurea) {
		this.idSecondaLaurea = idSecondaLaurea;
	}

	public String getDescUniSecondaLaurea() {
		return descUniSecondaLaurea;
	}

	public void setDescUniSecondaLaurea(String descUniSecondaLaurea) {
		this.descUniSecondaLaurea = descUniSecondaLaurea;
	}

	public Date getDataSecondaLaurea() {
		return dataSecondaLaurea;
	}

	public void setDataSecondaLaurea(Date dataSecondaLaurea) {
		this.dataSecondaLaurea = dataSecondaLaurea;
	}

	public String getLuogoSecondaLaurea() {
		return luogoSecondaLaurea;
	}

	public void setLuogoSecondaLaurea(String luogoSecondaLaurea) {
		this.luogoSecondaLaurea = luogoSecondaLaurea;
	}

	public String getNazioneSecondaLaurea() {
		return nazioneSecondaLaurea;
	}

	public void setNazioneSecondaLaurea(String nazioneSecondaLaurea) {
		this.nazioneSecondaLaurea = nazioneSecondaLaurea;
	}


	public BigDecimal getPunteggio() {
		return punteggio;
	}


	public void setPunteggio(BigDecimal punteggio) {
		this.punteggio = punteggio;
	}


	public String getIdStorico() {
		return idStorico;
	}


	public void setIdStorico(String idStorico) {
		this.idStorico = idStorico;
	}


	public String getMiUtente() {
		return miUtente;
	}


	public void setMiUtente(String miUtente) {
		this.miUtente = miUtente;
	}


	public java.sql.Timestamp getDataUltimaModifica() {
		return dataUltimaModifica;
	}


	public void setDataUltimaModifica(java.sql.Timestamp dataUltimaModifica) {
		this.dataUltimaModifica = dataUltimaModifica;
	}
	
	
}
