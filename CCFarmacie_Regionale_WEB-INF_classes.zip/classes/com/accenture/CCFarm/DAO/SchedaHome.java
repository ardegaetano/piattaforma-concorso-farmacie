package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.accenture.CCFarm.Bean.UtenteBean;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.RicercaSchedeValutazione;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.UtenteRegioni;

/**
 * Home object for domain model class Utente.
 * @see com.accenture.CCFarm.DAO.UtenteReg
 * @author Hibernate Tools
 */
public class SchedaHome {

	private static final Logger log = CommonLogger.getLogger("UtenteHome");
	StringUtil appoggio;

	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
    UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
	String cod_reg = utenteReg.getCodRegione();
	
	
	
	public List<RicercaSchedeValutazione> check_protocollo(RicercaSchedeValutazione scheda) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<String> listaProtocolli=new ArrayList<String>();
		List<RicercaSchedeValutazione> listaSchede=new ArrayList<RicercaSchedeValutazione>();
		try {
			
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();			
			String protocollo="";
				if (scheda.getProtocollo().length()>6){
					protocollo= scheda.getProtocollo().substring(0, 6);
				} else{
					protocollo= scheda.getProtocollo().trim();
				}
				protocollo = protocollo.replace("'", "''").trim();				
				   
				sb.append("select R.ID_RICEVUTA,R.ID_CANDIDATURA"+   		          
		            " FROM RICEVUTE R" +
					" where R.ID_RICEVUTA = '"+protocollo+"' and R.ID_REGIONE='"+cod_reg+"'");
				
				Query query = session.createSQLQuery(sb.toString());
				List results = query.list();
				
				if (results.size() >0){
					
					for (Iterator iterator = results.iterator(); iterator.hasNext();) {
						Object[] row = (Object[]) iterator.next(); 
						listaProtocolli.add((String)row[1]);
					}
					
					StringBuffer sb2=new StringBuffer();						
					sb2.append("select U.ID_DOMANDA_UTENTE,G.NUMERO_PROTOCOLLO, UPPER(U.CODICE_FISCALE_UTENTE), UPPER(U.COGNOME_UTENTE), UPPER(U.NOME_UTENTE),C.MODALITA_CANDIDATURA,"+   
//			                6             7                8                  9                                10
						"G.PUNTEGGIO,G.OSSERVAZIONI,D.FLAG_CONF_DOC_DIC ,D.DOC_PERVENUTA,TO_DATE (TO_CHAR (G.DATA_ISTRUTTORIA, 'YYYY-MON-DD HH24:MI:SS'),'YYYY-MON-DD HH24:MI:SS' ) " +
			            "FROM UTENTE_REG U,GRADUATORIA G,CANDIDATURA_REG C,DICHIARAZIONE_SOSTITUTIVA_REG D" +
			            " where (G.ID_CANDIDATURA = U.ID_DOMANDA_UTENTE and U.ID_DOMANDA_UTENTE = C.ID_CANDIDATURA "+
			            " and C.ID_CANDIDATURA = '"+listaProtocolli.get(0).substring(0, listaProtocolli.get(0).indexOf("_S"))+"' "+
//			            "and (C.MODALITA_CANDIDATURA ='S' or (C.MODALITA_CANDIDATURA='A' and C.REFERENTE_DOMANDA='Y'))"+
						"and U.ID_DOMANDA_UTENTE = D.ID_DOMANDA_DIC and U.COD_REG_UTENTE='"+cod_reg+"'");
						
						
						if(scheda.getDataIstruttoria()!=null){
						  sb2.append(" and trunc (G.DATA_ISTRUTTORIA) = to_date(:dataistruttoria, 'dd/mm/yyyy')");
						}
						
						if(scheda.getCognome()!=null&&!scheda.getCognome().equals("")){
							if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
								  sb2.append(" and UPPER(U.COGNOME_UTENTE) like :cognome");
							}else
							  sb.append(" and UPPER(U.COGNOME_UTENTE) >= :cognome");
						}
						if(scheda.getNome()!=null&&!scheda.getNome().equals("")){
							if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
								  sb2.append(" and UPPER(U.NOME_UTENTE) like :nome");
								}else
							  sb.append(" and UPPER(U.NOME_UTENTE) >= :nome");
							}
						if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
							  sb2.append(" and UPPER(U.COGNOME_UTENTE) like :cognome");
						}
						if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
							  sb2.append(" and UPPER(U.NOME_UTENTE) like :nome");
							}
						
						if(scheda.getCandidaturaRicerca()!=null&&!scheda.getCandidaturaRicerca().equals("-1")){
							if (scheda.getCandidaturaRicerca().equalsIgnoreCase("S"))
							  sb2.append(" and C.MODALITA_CANDIDATURA = :candidaturaRicerca");
							else sb.append(" and (C.MODALITA_CANDIDATURA= :candidaturaRicerca and C.REFERENTE_DOMANDA='Y')");
						}else sb2.append(" and (C.MODALITA_CANDIDATURA ='S' or (C.MODALITA_CANDIDATURA='A' and C.REFERENTE_DOMANDA='Y'))");
						
						if(scheda.getCodiceFiscale()!=null&&!scheda.getCodiceFiscale().equals("")){
							  sb2.append(" and UPPER(U.CODICE_FISCALE_UTENTE) = :codfiscale");
						}
						
						if(scheda.getDocumentazionePrevista()!=null&&!scheda.getDocumentazionePrevista().equals("-1")){
							  if (scheda.getDocumentazionePrevista().equalsIgnoreCase("SI"))
							  sb2.append(" and D.FLAG_CONF_DOC_DIC ='true'");
							  else sb2.append(" and (D.FLAG_CONF_DOC_DIC is null or D.FLAG_CONF_DOC_DIC='false')");
						}
						
						if(scheda.getDocumentazionePervenuta()!=null&&!scheda.getDocumentazionePervenuta().equals("-1")){
							  if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("SI"))
								  sb2.append(" and D.DOC_PERVENUTA ='true'");
							  else if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("NO")) 
								  sb2.append(" and D.DOC_PERVENUTA ='false'");
							  else if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("NULLO")) 
								  sb2.append(" and D.DOC_PERVENUTA ='nullo'");
						}
						
						if(scheda.getCodOsservazioni()!=null&&!scheda.getCodOsservazioni().equals("-1")){
							
							if(scheda.getCodOsservazioni().equals("o_13")){
								sb2.append(" and G.OSSERVAZIONI IS NULL");
							}
							else if(scheda.getCodOsservazioni().equals("o_12")){
								sb2.append(" and G.OSSERVAZIONI IS NOT NULL");
							}
							else if(scheda.getCodOsservazioni().equals("o_06")){
								sb2.append(" and C.ELAB_RETTIFICA ='Y'");
							}
							
							else  sb2.append(" and G.OSSERVAZIONI like :osservazione");
						}
						
						if(scheda.getParametroOrdinamento()!=null&&!scheda.getParametroOrdinamento().equals("")){
						sb2.append(") ORDER BY "+scheda.getParametroOrdinamento());
						}
						else sb2.append(") ORDER BY G.NUMERO_PROTOCOLLO DESC");
					  
						Query query2 = session.createSQLQuery(sb2.toString());
						
						if(scheda.getDataIstruttoria()!=null){
							query2.setParameter("dataistruttoria", StringUtil.dateToStringDDMMYYYY(scheda.getDataIstruttoria()));
							}
									
						if(scheda.getCognome()!=null&&!scheda.getCognome().equals("")){
							if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
								query2.setParameter("cognome", scheda.getCognomeRicerca().toUpperCase());
							}else
								query2.setParameter("cognome", scheda.getCognome().toUpperCase());
						}
						
						if(scheda.getNome()!=null&&!scheda.getNome().equals("")){
							if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
								query2.setParameter("nome", scheda.getNomeRicerca().toUpperCase());
								}else
									query2.setParameter("nome", scheda.getNome().toUpperCase());
						}
						
						if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
							query2.setParameter("cognome", scheda.getCognomeRicerca().toUpperCase());
						}
						
						if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
							query2.setParameter("nome", scheda.getNomeRicerca().toUpperCase());
						}
						
						if(scheda.getCandidaturaRicerca()!=null&&!scheda.getCandidaturaRicerca().equals("-1")){
							  query2.setParameter("candidaturaRicerca", scheda.getCandidaturaRicerca());
						}
						
						if(scheda.getCodiceFiscale()!=null&&!scheda.getCodiceFiscale().equals("")){
							  query2.setParameter("codfiscale", scheda.getCodiceFiscale().toUpperCase());
						}
						
						if(scheda.getCodOsservazioni()!=null&&!scheda.getCodOsservazioni().equals("-1")){
							if(!scheda.getCodOsservazioni().equals("o_12")&& !scheda.getCodOsservazioni().equals("o_13") && !scheda.getCodOsservazioni().equals("o_06")){
								query2.setParameter("osservazione","%"+ scheda.getCodOsservazioni()+"%");
							}
							  
						}
						
						List results2 = query2.list();
						
						log.debug("find by filter successful, result size: "
								+ results.size());
						RicercaSchedeValutazione schedaValutazione = null;
						for (Iterator iterator = results2.iterator(); iterator.hasNext();) {
							schedaValutazione=new RicercaSchedeValutazione("noInit");
							Object[] row = (Object[]) iterator.next(); 
							schedaValutazione.setIdUtente((String)row[0]);
							schedaValutazione.setProtocollo((String)row[1]);
							if (!((String)row[2]).toString().contains("*"))
							schedaValutazione.setCodiceFiscale((String)row[2]);
							schedaValutazione.setCognome((String)row[3]);
							schedaValutazione.setNome((String)row[4]);
							if (((String)row[5]).equals("S")) schedaValutazione.setCandidatura("Singola");
							else schedaValutazione.setCandidatura("Associata");								
							schedaValutazione.setPunteggio(row[6].toString());							
							schedaValutazione.setCodOsservazioni((String)row[7]);								
							if (((String)row[8]).equalsIgnoreCase("true")) schedaValutazione.setDocumentazionePrevista("SI");
							else schedaValutazione.setDocumentazionePrevista("NO");								
							if (row[9] != null){
								if (((String)row[9]).equalsIgnoreCase("true")) schedaValutazione.setDocumentazionePervenuta("SI");
								else if (((String)row[9]).equalsIgnoreCase("false")) schedaValutazione.setDocumentazionePervenuta("NO");					
							}
							else schedaValutazione.setDocumentazionePervenuta("NO");				
							schedaValutazione.setDataIstruttoria_string(StringUtil.dateToStringDDMMYYYY((Date)row[10]));
							
							listaSchede.add(schedaValutazione);
					}		
						
						return listaSchede;
					
					
					
				}
						
				return listaSchede;
			
		}
		catch (RuntimeException re) { 
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}
		finally {
			session.close();
		}
	
	}
	
	
	
	public List findSchedeAll(RicercaSchedeValutazione scheda) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<String> listaSchede=new ArrayList<String>();
		try {
			
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			
//			/* Formatted on 17/04/2014 18:49:41 (QP5 v5.139.911.3011) */
//			  SELECT DISTINCT G.ID_CANDIDATURA
//			    FROM UTENTE_REG U,
//			         GRADUATORIA G,
//			         CANDIDATURA_REG C,
//			            DICHIARAZIONE_SOSTITUTIVA_REG D
//			   WHERE   G.ID_CANDIDATURA = C.ID_CANDIDATURA
//			          AND U.ID_DOMANDA_UTENTE = C.id_utente
//			          AND U.ID_DOMANDA_UTENTE = D.ID_DOMANDA_DIC
//			          AND U.COD_REG_UTENTE = '070'
//			          AND TRIM (UPPER (U.COGNOME_UTENTE)) LIKE '%MAZZOXX%'
//                                        0			        1                    2                    3              4                5    
			sb.append("select DISTINCT G.ID_CANDIDATURA "
					+ "FROM UTENTE_REG U,GRADUATORIA G,CANDIDATURA_REG C,DICHIARAZIONE_SOSTITUTIVA_REG D"
					+ " where G.ID_CANDIDATURA = C.ID_CANDIDATURA and U.ID_DOMANDA_UTENTE = C.ID_UTENTE "
					+ "and U.ID_DOMANDA_UTENTE = D.ID_DOMANDA_DIC and U.COD_REG_UTENTE='"
					+ cod_reg + "'");
			
			
			if(scheda.getDataIstruttoria()!=null){
			  sb.append(" and trunc (G.DATA_ISTRUTTORIA) = to_date(:dataistruttoria, 'dd/mm/yyyy')");
			}
			
			if(scheda.getProtocollo()!=null && !scheda.getProtocollo().equals("") ){
				sb.append(" and G.NUMERO_PROTOCOLLO like :numeroprotocollo");
			}
			
			if(scheda.getCognome()!=null&&!scheda.getCognome().equals("")){
				if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
					  sb.append(" and TRIM(UPPER(U.COGNOME_UTENTE)) like :cognome");
				}else
				  sb.append(" and UPPER(U.COGNOME_UTENTE) >= :cognome");
			}
			if(scheda.getNome()!=null&&!scheda.getNome().equals("")){
				if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
					  sb.append(" and TRIM(UPPER(U.NOME_UTENTE)) like :nome");
					}else
				  sb.append(" and UPPER(U.NOME_UTENTE) >= :nome");
				}
			if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
				  sb.append(" and TRIM(UPPER(U.COGNOME_UTENTE)) like :cognome");
			}
			if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
				  sb.append(" and TRIM(UPPER(U.NOME_UTENTE)) like :nome");
				}
			
			if(scheda.getCandidaturaRicerca()!=null&&!scheda.getCandidaturaRicerca().equals("-1")){
				if (scheda.getCandidaturaRicerca().equalsIgnoreCase("S"))
				  sb.append(" and C.MODALITA_CANDIDATURA = :candidaturaRicerca");
				else sb.append(" and (C.MODALITA_CANDIDATURA= :candidaturaRicerca and C.REFERENTE_DOMANDA='Y')");
			}
			
			if(scheda.getCodiceFiscale()!=null&&!scheda.getCodiceFiscale().equals("")){
				  sb.append(" and UPPER(U.CODICE_FISCALE_UTENTE) = :codfiscale");
			}
			
			if(scheda.getDocumentazionePrevista()!=null&&!scheda.getDocumentazionePrevista().equals("-1")){
				  if (scheda.getDocumentazionePrevista().equalsIgnoreCase("SI"))
				  sb.append(" and D.FLAG_CONF_DOC_DIC ='true'");
				  else sb.append(" and (D.FLAG_CONF_DOC_DIC is null or D.FLAG_CONF_DOC_DIC='false')");
			}
			
			if(scheda.getDocumentazionePervenuta()!=null&&!scheda.getDocumentazionePervenuta().equals("-1")){
				  if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("SI"))
					  sb.append(" and D.DOC_PERVENUTA ='true'");
				  else if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("NO")) 
					  sb.append(" and D.DOC_PERVENUTA ='false'");
				  else if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("NULLO")) 
					  sb.append(" and D.DOC_PERVENUTA ='nullo'");
			}
			
			if(scheda.getCodOsservazioni()!=null&&!scheda.getCodOsservazioni().equals("-1")){
				
				if(scheda.getCodOsservazioni().equals("o_13")){
					sb.append(" and G.OSSERVAZIONI IS NULL");
				}
				else if(scheda.getCodOsservazioni().equals("o_12")){
					sb.append(" and G.OSSERVAZIONI IS NOT NULL");
				}
				else if(scheda.getCodOsservazioni().equals("o_06")){
					sb.append(" and C.ELAB_RETTIFICA ='Y'");
				}
				
				else  sb.append(" and G.OSSERVAZIONI like :osservazione");
			}
			
		/*	if(scheda.getParametroOrdinamento()!=null&&!scheda.getParametroOrdinamento().equals("")){
//				sb.append(") ORDER BY :parametroOrdinamento DESC");
				sb.append("ORDER BY "+scheda.getParametroOrdinamento());
				}
			else sb.append("ORDER BY G.NUMERO_PROTOCOLLO DESC");*/
			
			Query query = session.createSQLQuery(sb.toString());
			
			if(scheda.getProtocollo()!=null&&!scheda.getProtocollo().equals("")){
				String protocollo="";
				if (scheda.getProtocollo().length()>6){
					protocollo= scheda.getProtocollo().substring(0, 6);
				} else{
					protocollo= scheda.getProtocollo().trim();
				}
				protocollo = protocollo.replace("'", "''").trim()+"%";
				query.setParameter("numeroprotocollo", protocollo);
			}		
			
			if(scheda.getDataIstruttoria()!=null){
				query.setParameter("dataistruttoria", StringUtil.dateToStringDDMMYYYY(scheda.getDataIstruttoria()));
				}
						
			if(scheda.getCognome()!=null&&!scheda.getCognome().equals("")){
//				if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
//					query.setParameter("cognome","%"+scheda.getCognomeRicerca().toUpperCase().trim()+"%");
//				}else
					query.setParameter("cognome", "%"+scheda.getCognome().toUpperCase().trim()+"%");
			}
			
			if(scheda.getNome()!=null&&!scheda.getNome().equals("")){
//				if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
//					query.setParameter("nome", "%"+scheda.getNomeRicerca().toUpperCase().trim());
//					}else
						query.setParameter("nome", "%"+scheda.getNome().toUpperCase().trim()+"%");
			}
			
			if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
				query.setParameter("cognome", "%"+scheda.getCognomeRicerca().toUpperCase().trim()+"%");
			}
			
			if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
				query.setParameter("nome", "%"+scheda.getNomeRicerca().toUpperCase().trim()+"%");
			}
			
			if(scheda.getCandidaturaRicerca()!=null&&!scheda.getCandidaturaRicerca().equals("-1")){
				  query.setParameter("candidaturaRicerca", scheda.getCandidaturaRicerca());
			}
			
			if(scheda.getCodiceFiscale()!=null&&!scheda.getCodiceFiscale().equals("")){
				  query.setParameter("codfiscale", scheda.getCodiceFiscale().toUpperCase());
			}
			
			if(scheda.getCodOsservazioni()!=null&&!scheda.getCodOsservazioni().equals("-1")){
				if(!scheda.getCodOsservazioni().equals("o_12")&& !scheda.getCodOsservazioni().equals("o_13") && !scheda.getCodOsservazioni().equals("o_06")){
					query.setParameter("osservazione","%"+ scheda.getCodOsservazioni()+"%");
				}
				  
			}
			
			
			List results = query.list();
			 
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				listaSchede.add((String)iterator.next());
			}		
			
			return listaSchede;
			
		}
		catch (RuntimeException re) { 
			log.error("find by filter failed", re);
			throw new GestioneErroriException("SchedaHome - findByFilter: errore findByFilter");
		}
		finally {
			session.close();
		}
	
	}
	
	
	
	
	public List<RicercaSchedeValutazione> findPage(RicercaSchedeValutazione scheda, List<String> utentiList) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<UtenteBean> listaCandidature=new ArrayList<UtenteBean>();
	
		String inSelect ="";
		// query vecchia
//		for (int i = 0; i < utentiList.size(); i++) {
//			inSelect+="'"+utentiList.get(i)+"',";
//		}
//		inSelect=inSelect.substring(0, inSelect.length()-1)+")";
		String selectExt ="";
		for (int i = 0; i < utentiList.size(); i++) {
			if (i == (utentiList.size() -1)) {
				selectExt = selectExt + "select " +"'"+utentiList.get(i)+"' a from dual ";
			}else {
				selectExt = selectExt + "select " +"'"+utentiList.get(i)+"' a from dual union all ";
			}
			
			
			inSelect+="'"+utentiList.get(i)+"',";
		}
		inSelect=inSelect.substring(0, inSelect.length()-1)+")";
		
		List<RicercaSchedeValutazione> listaSchede=new ArrayList<RicercaSchedeValutazione>();
		
		try {
					
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			
//                                        0			        1                    2                    3              4                5    
			sb.append("select U.ID_DOMANDA_UTENTE,G.NUMERO_PROTOCOLLO, UPPER(U.CODICE_FISCALE_UTENTE), TRIM(UPPER(U.COGNOME_UTENTE)), TRIM(UPPER(U.NOME_UTENTE)),C.MODALITA_CANDIDATURA,"+   
//                6             7               8                  9                                 10                                                                            11
			"G.PUNTEGGIO,G.OSSERVAZIONI,D.FLAG_CONF_DOC_DIC ,D.DOC_PERVENUTA,TO_DATE (TO_CHAR (G.DATA_ISTRUTTORIA, 'YYYY-MON-DD HH24:MI:SS'),'YYYY-MON-DD HH24:MI:SS') ,  C.PROTOCOLLI_RIASSEGNATI " +
            "FROM UTENTE_REG U,GRADUATORIA G,CANDIDATURA_REG C,DICHIARAZIONE_SOSTITUTIVA_REG D" +
			" where (G.ID_CANDIDATURA = U.ID_DOMANDA_UTENTE and U.ID_DOMANDA_UTENTE = C.ID_CANDIDATURA "+
//            "and (C.MODALITA_CANDIDATURA ='S' or (C.MODALITA_CANDIDATURA='A' and C.REFERENTE_DOMANDA='Y'))"+
			" and U.ID_DOMANDA_UTENTE = D.ID_DOMANDA_DIC and U.COD_REG_UTENTE='"+cod_reg+"' "+
			" AND (C.MODALITA_CANDIDATURA = 'S' OR (C.MODALITA_CANDIDATURA = 'A' AND C.REFERENTE_DOMANDA = 'Y'))"+
//			"AND U.ID_UTENTE IN("+inSelect +"");
			" and exists (  select *  from (   " + selectExt + "  ) utenti  where u.id_utente = utenti.a  ))");
			
			if(scheda.getParametroOrdinamento()!=null&&!scheda.getParametroOrdinamento().equals("")){
//				sb.append(") ORDER BY :parametroOrdinamento DESC");
				sb.append("ORDER BY "+scheda.getParametroOrdinamento());
				}
			else sb.append("ORDER BY G.NUMERO_PROTOCOLLO DESC");

			Query query = session.createSQLQuery(sb.toString());
			
			
			List results = query.list();
			 
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			RicercaSchedeValutazione schedaValutazione = null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				schedaValutazione=new RicercaSchedeValutazione("noInit");
				Object[] row = (Object[]) iterator.next(); 
				schedaValutazione.setIdUtente((String)row[0]);
				String protocollo=(String)row[1];
				String protocolloRiassegnati=(String)row[11];
				if(protocolloRiassegnati!=null&& !protocolloRiassegnati.equals("")){
					protocollo= protocollo + " ; " +protocolloRiassegnati;
				}
				schedaValutazione.setProtocollo(protocollo);
				if (!((String)row[2]).toString().contains("*"))
				schedaValutazione.setCodiceFiscale((String)row[2]);
				schedaValutazione.setCognome((String)row[3]);
				schedaValutazione.setNome((String)row[4]);
				if (((String)row[5]).equals("S")) schedaValutazione.setCandidatura("Singola");
				else schedaValutazione.setCandidatura("Associata");								
				schedaValutazione.setPunteggio(row[6].toString());							
				schedaValutazione.setCodOsservazioni((String)row[7]);								
				if(row[8]!=null){
					if (((String)row[8]).equalsIgnoreCase("true")) schedaValutazione.setDocumentazionePrevista("SI");
					else schedaValutazione.setDocumentazionePrevista("NO");								
					
				}else{
					 schedaValutazione.setDocumentazionePrevista("N.D.");
				}
				if (row[9] != null){
					if (((String)row[9]).equalsIgnoreCase("true")) schedaValutazione.setDocumentazionePervenuta("SI");
					else if (((String)row[9]).equalsIgnoreCase("false")) schedaValutazione.setDocumentazionePervenuta("NO");					
				}
				else schedaValutazione.setDocumentazionePervenuta("NO");				
				schedaValutazione.setDataIstruttoria_string(StringUtil.dateToStringDDMMYYYY((Date)row[10]));
				
				listaSchede.add(schedaValutazione);
		}
			
			return listaSchede;
			
		} catch (RuntimeException re) {
			log.error("find by filter failed", re);
			throw new GestioneErroriException("SchedaHome - findByFilter: errore findByFilter");
		}
		finally {
			session.close();
		}
	
	}
	
	
	public List<RicercaSchedeValutazione> findPageNew(RicercaSchedeValutazione scheda, List<String> utentiList) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<UtenteBean> listaCandidature=new ArrayList<UtenteBean>();
	
		String inSelect ="";
		// query vecchia
//		for (int i = 0; i < utentiList.size(); i++) {
//			inSelect+="'"+utentiList.get(i)+"',";
//		}
//		inSelect=inSelect.substring(0, inSelect.length()-1)+")";
		String selectExt ="";
		for (int i = 0; i < utentiList.size(); i++) {
			if (i == (utentiList.size() -1)) {
				selectExt = selectExt + "select " +"'"+utentiList.get(i)+"' a from dual ";
			}else {
				selectExt = selectExt + "select " +"'"+utentiList.get(i)+"' a from dual union all ";
			}
			
			
			inSelect+="'"+utentiList.get(i)+"',";
		}
		inSelect=inSelect.substring(0, inSelect.length()-1)+")";
		
		List<RicercaSchedeValutazione> listaSchede=new ArrayList<RicercaSchedeValutazione>();
		
		try {
					
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			
//                                        0			        1                    2                    3              4                5    
			sb.append("select U.ID_DOMANDA_UTENTE,G.NUMERO_PROTOCOLLO, UPPER(U.CODICE_FISCALE_UTENTE), TRIM(UPPER(U.COGNOME_UTENTE)), TRIM(UPPER(U.NOME_UTENTE)),C.MODALITA_CANDIDATURA,"+   
//                6             7               8                  9                                 10                                                                            11
			"G.PUNTEGGIO,G.OSSERVAZIONI,D.FLAG_CONF_DOC_DIC ,D.DOC_PERVENUTA,TO_DATE (TO_CHAR (G.DATA_ISTRUTTORIA, 'YYYY-MON-DD HH24:MI:SS'),'YYYY-MON-DD HH24:MI:SS') ,  C.PROTOCOLLI_RIASSEGNATI " +
            "FROM UTENTE_REG U,GRADUATORIA G,CANDIDATURA_REG C,DICHIARAZIONE_SOSTITUTIVA_REG D" +
			" where (G.ID_CANDIDATURA = U.ID_DOMANDA_UTENTE and U.ID_DOMANDA_UTENTE = C.ID_CANDIDATURA "+
//            "and (C.MODALITA_CANDIDATURA ='S' or (C.MODALITA_CANDIDATURA='A' and C.REFERENTE_DOMANDA='Y'))"+
			" and U.ID_DOMANDA_UTENTE = D.ID_DOMANDA_DIC and U.COD_REG_UTENTE='"+cod_reg+"' "+
//			"AND U.ID_UTENTE IN("+inSelect +"");
			" and exists (  select *  from (   " + selectExt + "  ) utenti  where u.id_utente = utenti.a  )");
			
			if(scheda.getDataIstruttoria()!=null){
			  sb.append(" and trunc (G.DATA_ISTRUTTORIA) = to_date(:dataistruttoria, 'dd/mm/yyyy')");
			}

			if(scheda.getProtocollo()!=null && !scheda.getProtocollo().equals("") ){
				sb.append(" and G.NUMERO_PROTOCOLLO like :numeroprotocollo");
			}
			
			if(scheda.getCognome()!=null&&!scheda.getCognome().equals("")){
				if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
					  sb.append(" and TRIM(UPPER(U.COGNOME_UTENTE)) like :cognome");
				}else
				  sb.append(" and UPPER(U.COGNOME_UTENTE) >= :cognome");
			}
			if(scheda.getNome()!=null&&!scheda.getNome().equals("")){
				if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
					  sb.append(" and TRIM(UPPER(U.NOME_UTENTE)) like :nome");
					}else
				  sb.append(" and UPPER(U.NOME_UTENTE) >= :nome");
				}
			if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
				  sb.append(" and TRIM(UPPER(U.COGNOME_UTENTE)) like :cognome");
			}
			if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
				  sb.append(" and TRIM(UPPER(U.NOME_UTENTE)) like :nome");
				}
			if(scheda.getCandidaturaRicerca()!=null&&!scheda.getCandidaturaRicerca().equals("-1")){
				if (scheda.getCandidaturaRicerca().equalsIgnoreCase("S"))
				  sb.append(" and C.MODALITA_CANDIDATURA = :candidaturaRicerca");
				else sb.append(" and (C.MODALITA_CANDIDATURA= :candidaturaRicerca and C.REFERENTE_DOMANDA='Y')");
			}else sb.append(" and (C.MODALITA_CANDIDATURA ='S' or (C.MODALITA_CANDIDATURA='A' and C.REFERENTE_DOMANDA='Y'))");

			if(scheda.getCodiceFiscale()!=null&&!scheda.getCodiceFiscale().equals("")){
				  sb.append(" and U.CODICE_FISCALE_UTENTE= :codfiscale");
			}
			
			if(scheda.getCodiceFiscale()!=null&&!scheda.getCodiceFiscale().equals("")){
				  sb.append(" and UPPER(U.CODICE_FISCALE_UTENTE) = :codfiscale");
			}
			if(scheda.getDocumentazionePrevista()!=null&&!scheda.getDocumentazionePrevista().equals("-1")){
				  if (scheda.getDocumentazionePrevista().equalsIgnoreCase("SI"))
				  sb.append(" and D.FLAG_CONF_DOC_DIC ='true'");
				  else sb.append(" and (D.FLAG_CONF_DOC_DIC is null or D.FLAG_CONF_DOC_DIC='false')");
			}
			if(scheda.getDocumentazionePervenuta()!=null&&!scheda.getDocumentazionePervenuta().equals("-1")){
				  if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("SI"))
					  sb.append(" and D.DOC_PERVENUTA ='true'");
				  else if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("NO")) 
					  sb.append(" and D.DOC_PERVENUTA ='false'");
				  else if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("NULLO")) 
					  sb.append(" and D.DOC_PERVENUTA ='nullo'");
			}
//			if(scheda.getCodOsservazioni()!=null&&!scheda.getCodOsservazioni().equals("-1")){
//				  sb.append(" and G.OSSERVAZIONI like :osservazione");
//			}
			if(scheda.getCodOsservazioni()!=null&&!scheda.getCodOsservazioni().equals("-1")){
				
				if(scheda.getCodOsservazioni().equals("o_13")){
					sb.append(" and G.OSSERVAZIONI IS NULL");
				}
				else if(scheda.getCodOsservazioni().equals("o_12")){
					sb.append(" and G.OSSERVAZIONI IS NOT NULL");
				}
				else if(scheda.getCodOsservazioni().equals("o_06")){
					sb.append(" and C.ELAB_RETTIFICA ='Y'");
				}
				
				else  sb.append(" and G.OSSERVAZIONI like :osservazione");
			}
			
//			sb.append(") ORDER BY G.PUNTEGGIO DESC");
//			sb.append(") ORDER BY G.NUMERO_PROTOCOLLO DESC");
//			sb.append(") ORDER BY U.COGNOME_UTENTE DESC");
			if(scheda.getParametroOrdinamento()!=null&&!scheda.getParametroOrdinamento().equals("")){
//				sb.append(") ORDER BY :parametroOrdinamento DESC");
				sb.append(") ORDER BY "+scheda.getParametroOrdinamento());
				}
				else sb.append(") ORDER BY G.NUMERO_PROTOCOLLO DESC");
		  
			Query query = session.createSQLQuery(sb.toString());
			
			if(scheda.getProtocollo()!=null&&!scheda.getProtocollo().equals("")){
				String protocollo="";
				if (scheda.getProtocollo().length()>6){
					protocollo= scheda.getProtocollo().substring(0, 6);
				} else{
					protocollo= scheda.getProtocollo().trim();
				}
				
				protocollo = protocollo.replace("'", "''").trim()+"%";				
				
				query.setParameter("numeroprotocollo", protocollo);
			}
			
			if(scheda.getDataIstruttoria()!=null){
				query.setParameter("dataistruttoria", StringUtil.dateToStringDDMMYYYY(scheda.getDataIstruttoria()));
				}
					
			if(scheda.getCognome()!=null&&!scheda.getCognome().equals("")){
				if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
					query.setParameter("cognome", "%"+scheda.getCognomeRicerca().toUpperCase().trim()+"%");
				}else
					query.setParameter("cognome", "%"+scheda.getCognome().toUpperCase().trim()+"%");
			}
			
			if(scheda.getNome()!=null&&!scheda.getNome().equals("")){
				if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
					query.setParameter("nome", scheda.getNomeRicerca().toUpperCase().trim());
					}else
						query.setParameter("nome", scheda.getNome().toUpperCase().trim());
			}
			
			if(scheda.getCognomeRicerca()!=null&&!scheda.getCognomeRicerca().equals("")){
				query.setParameter("cognome", "%"+scheda.getCognomeRicerca().toUpperCase().trim()+"%");
			}
			
			if(scheda.getNomeRicerca()!=null&&!scheda.getNomeRicerca().equals("")){
				query.setParameter("nome", scheda.getNomeRicerca().toUpperCase().trim());
			}
			
			if(scheda.getCandidaturaRicerca()!=null&&!scheda.getCandidaturaRicerca().equals("-1")){
				  query.setParameter("candidaturaRicerca", scheda.getCandidaturaRicerca());
			}
			
			if(scheda.getCodiceFiscale()!=null&&!scheda.getCodiceFiscale().equals("")){
				  query.setParameter("codfiscale", scheda.getCodiceFiscale().toUpperCase());
			}
			
//			if(scheda.getCodOsservazioni()!=null&&!scheda.getCodOsservazioni().equals("-1")){
//				  query.setParameter("osservazione","%"+ scheda.getCodOsservazioni()+"%");
//			}
			if(scheda.getCodOsservazioni()!=null &&!scheda.getCodOsservazioni().equals("-1")){
				if(!scheda.getCodOsservazioni().equals("o_12") && !scheda.getCodOsservazioni().equals("o_13") && !scheda.getCodOsservazioni().equals("o_06")){
					query.setParameter("osservazione","%"+ scheda.getCodOsservazioni()+"%");
				}
				  
			}

			
			List results = query.list();
			 
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			RicercaSchedeValutazione schedaValutazione = null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				schedaValutazione=new RicercaSchedeValutazione("noInit");
				Object[] row = (Object[]) iterator.next(); 
				schedaValutazione.setIdUtente((String)row[0]);
				String protocollo=(String)row[1];
				String protocolloRiassegnati=(String)row[11];
				if(protocolloRiassegnati!=null&& !protocolloRiassegnati.equals("")){
					protocollo= protocollo + " ; " +protocolloRiassegnati;
				}
				schedaValutazione.setProtocollo(protocollo);
				if (!((String)row[2]).toString().contains("*"))
				schedaValutazione.setCodiceFiscale((String)row[2]);
				schedaValutazione.setCognome((String)row[3]);
				schedaValutazione.setNome((String)row[4]);
				if (((String)row[5]).equals("S")) schedaValutazione.setCandidatura("Singola");
				else schedaValutazione.setCandidatura("Associata");								
				schedaValutazione.setPunteggio(row[6].toString());							
				schedaValutazione.setCodOsservazioni((String)row[7]);								
				if(row[8]!=null){
					if (((String)row[8]).equalsIgnoreCase("true")) schedaValutazione.setDocumentazionePrevista("SI");
					else schedaValutazione.setDocumentazionePrevista("NO");								
					
				}else{
					 schedaValutazione.setDocumentazionePrevista("N.D.");
				}
				if (row[9] != null){
					if (((String)row[9]).equalsIgnoreCase("true")) schedaValutazione.setDocumentazionePervenuta("SI");
					else if (((String)row[9]).equalsIgnoreCase("false")) schedaValutazione.setDocumentazionePervenuta("NO");					
				}
				else schedaValutazione.setDocumentazionePervenuta("NO");				
				schedaValutazione.setDataIstruttoria_string(StringUtil.dateToStringDDMMYYYY((Date)row[10]));
				
				listaSchede.add(schedaValutazione);
		}
			
			return listaSchede;
			
		} catch (RuntimeException re) {
			log.error("find by filter failed", re);
			throw new GestioneErroriException("SchedaHome - findByFilter: errore findByFilter");
		}
		finally {
			session.close();
		}
	
	}
	
	
	
	public void updateTabGraduatoria(RicercaSchedeValutazione scheda) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		
		try
		{	
			session = HibernateUtil.openSession();
			Transaction trx = session.beginTransaction();
			
			StringBuffer sb=new StringBuffer();
			
			String doc_pervenuta ="";
			if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("SI")) doc_pervenuta="true";
			else if(scheda.getDocumentazionePervenuta().equalsIgnoreCase("NO")) doc_pervenuta="false";
			else if(scheda.getDocumentazionePervenuta().equalsIgnoreCase("Non ancora lavorata")) doc_pervenuta="";
			    
			sb.append("update DICHIARAZIONE_SOSTITUTIVA_REG dic set dic.DOC_PERVENUTA='"+doc_pervenuta+"' where dic.ID_DOMANDA_DIC='"+ scheda.getIdUtente() +"'");
			
		    Query query = session.createSQLQuery(sb.toString());
			
			int rowCount = query.executeUpdate();
			
			trx.commit();
		}
		catch (RuntimeException re)
		{
			log.error("find by filter failed", re);
			throw new GestioneErroriException("SchedaHome - findByFilter: errore findByFilter");
		}
		finally
		{
			session.close();
		}
	}
	
	public void updateTabGraduatoria(List<RicercaSchedeValutazione> listaschede) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		
		try
		{	
			session = HibernateUtil.openSession();
			Transaction trx = session.beginTransaction();
			
			for (RicercaSchedeValutazione scheda: listaschede){
			
				StringBuffer sb=new StringBuffer();
				
				String doc_pervenuta ="";
				if (scheda.getDocumentazionePervenuta().equalsIgnoreCase("SI")) doc_pervenuta="true";
				else if(scheda.getDocumentazionePervenuta().equalsIgnoreCase("NO")) doc_pervenuta="false";
				else if(scheda.getDocumentazionePervenuta().equalsIgnoreCase("Non ancora lavorata")) doc_pervenuta="";
				    
				sb.append("update DICHIARAZIONE_SOSTITUTIVA_REG dic set dic.DOC_PERVENUTA='"+doc_pervenuta+"' where dic.ID_DOMANDA_DIC='"+ scheda.getIdUtente() +"'");
				
			    Query query = session.createSQLQuery(sb.toString());
				
				int rowCount = query.executeUpdate();
			
			}

			trx.commit();
		}
		catch (RuntimeException re)
		{
			log.error("find by filter failed", re);
			throw new GestioneErroriException("SchedaHome - findByFilter: errore findByFilter");
		}
		finally
		{
			session.close();
		}
	}
	
}
