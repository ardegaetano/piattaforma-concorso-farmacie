package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.Date;

import com.accenture.CCFarm.utility.StringUtil;

@SuppressWarnings("serial")
public class StoricoGraduatoriaId implements java.io.Serializable {

	
	private String idCandidatura;
	private String nProgressivo;
	
	public StoricoGraduatoriaId(){
		
	}

	public String getIdCandidatura() {
		return idCandidatura;
	}

	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}

	public String getnProgressivo() {
		return nProgressivo;
	}

	public void setnProgressivo(String nProgressivo) {
		this.nProgressivo = nProgressivo;
	}

	
	


}