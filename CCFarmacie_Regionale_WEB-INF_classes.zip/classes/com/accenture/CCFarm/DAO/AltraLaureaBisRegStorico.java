package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.util.Date;

@SuppressWarnings("serial")
public class AltraLaureaBisRegStorico implements java.io.Serializable{
	
	private String idStorico;
	private String miUtente;
	private java.sql.Timestamp dataUltimaModifica;
	
	private String idAltraLaureaBis;
	private String idSecondaLaureaBis;
	private String descUniSecondaLaureaBis;
	private Date dataSecondaLaureaBis;
//	private String flagPresaVisioneBis;
	private String idDomandaLaureaBis;
	private String luogoSecondaLaureaBis;
	private String nazioneSecondaLaureaBis;
    private String flagEsteroSecondaLaureaBis;
    private BigDecimal punteggio;
    
	public AltraLaureaBisRegStorico() {
	}

	
	
	public AltraLaureaBisRegStorico(String idDomandaLaureaBis) {
		this.idDomandaLaureaBis = idDomandaLaureaBis;
	}
	

	public AltraLaureaBisRegStorico(String idAltraLaureaBis,
			String idSecondaLaureaBis, String descUniSecondaLaureaBis,
			Date dataSecondaLaureaBis, String idDomandaLaureaBis,
			String luogoSecondaLaureaBis, String nazioneSecondaLaureaBis,
			String flagEsteroSecondaLaureaBis, String valida,
			String docPervenuta, BigDecimal punteggio) {
		super();
		this.idAltraLaureaBis = idAltraLaureaBis;
		this.idSecondaLaureaBis = idSecondaLaureaBis;
		this.descUniSecondaLaureaBis = descUniSecondaLaureaBis;
		this.dataSecondaLaureaBis = dataSecondaLaureaBis;
		this.idDomandaLaureaBis = idDomandaLaureaBis;
		this.luogoSecondaLaureaBis = luogoSecondaLaureaBis;
		this.nazioneSecondaLaureaBis = nazioneSecondaLaureaBis;
		this.flagEsteroSecondaLaureaBis = flagEsteroSecondaLaureaBis;
		this.punteggio = punteggio;
	}

	public String getIdAltraLaureaBis() {
		return idAltraLaureaBis;
	}

	public String getIdSecondaLaureaBis() {
		return idSecondaLaureaBis;
	}

	public void setIdSecondaLaureaBis(String idSecondaLaureaBis) {
		this.idSecondaLaureaBis = idSecondaLaureaBis;
	}

	public String getDescUniSecondaLaureaBis() {
		return descUniSecondaLaureaBis;
	}

	public void setDescUniSecondaLaureaBis(String descUniSecondaLaureaBis) {
		this.descUniSecondaLaureaBis = descUniSecondaLaureaBis;
	}

	public Date getDataSecondaLaureaBis() {
		return dataSecondaLaureaBis;
	}

	public void setDataSecondaLaureaBis(Date dataSecondaLaureaBis) {
		this.dataSecondaLaureaBis = dataSecondaLaureaBis;
	}

	public String getLuogoSecondaLaureaBis() {
		return luogoSecondaLaureaBis;
	}

	public void setLuogoSecondaLaureaBis(String luogoSecondaLaureaBis) {
		this.luogoSecondaLaureaBis = luogoSecondaLaureaBis;
	}

	public String getNazioneSecondaLaureaBis() {
		return nazioneSecondaLaureaBis;
	}

	public void setNazioneSecondaLaureaBis(String nazioneSecondaLaureaBis) {
		this.nazioneSecondaLaureaBis = nazioneSecondaLaureaBis;
	}

	public void setIdAltraLaureaBis(String idAltraLaureaBis) {
		this.idAltraLaureaBis = idAltraLaureaBis;
	}

	public String getIdDomandaLaureaBis() {
		return idDomandaLaureaBis;
	}

	public void setIdDomandaLaureaBis(String idDomandaLaureaBis) {
		this.idDomandaLaureaBis = idDomandaLaureaBis;
	}

	public String getFlagEsteroSecondaLaureaBis() {
		return flagEsteroSecondaLaureaBis;
	}

	public void setFlagEsteroSecondaLaureaBis(String flagEsteroSecondaLaureaBis) {
		this.flagEsteroSecondaLaureaBis = flagEsteroSecondaLaureaBis;
	}

	public BigDecimal getPunteggio() {
		return punteggio;
	}

	public void setPunteggio(BigDecimal punteggio) {
		this.punteggio = punteggio;
	}



	public String getIdStorico() {
		return idStorico;
	}



	public void setIdStorico(String idStorico) {
		this.idStorico = idStorico;
	}



	public String getMiUtente() {
		return miUtente;
	}



	public void setMiUtente(String miUtente) {
		this.miUtente = miUtente;
	}



	public java.sql.Timestamp getDataUltimaModifica() {
		return dataUltimaModifica;
	}



	public void setDataUltimaModifica(java.sql.Timestamp dataUltimaModifica) {
		this.dataUltimaModifica = dataUltimaModifica;
	}
	
	
}
