package com.accenture.CCFarm.DAO;


import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.primefaces.model.UploadedFile;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.PrintException;


public class DatiBandoHome {

	private static final Logger log = CommonLogger.getLogger("DatiBandoHome");

	private static final String flagValoreFalso = AppProperties.getAppProperties().getProperty("flag.valore.falso");
	private static final String flagValoreVero  = AppProperties.getAppProperties().getProperty("flag.valore.vero");
	
	public void persist(DatiBando transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting DatiBando instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - persist: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(DatiBando instance, UploadedFile fileBando, UploadedFile fileSedi) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty DatiBando instance");
		try {
			if(fileBando!=null)
				instance.setFileBando(Hibernate.createBlob(fileBando.getContents()));
			
			if(fileSedi!=null) {
				InputStream is = null;
				is = fileSedi.getInputstream();
				InputStreamReader isReader = new InputStreamReader(is);
				int len = new Long(fileSedi.getSize()).intValue();
				instance.setFileSedi(Hibernate.createClob((Reader)isReader, len));
			}
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");	
		} catch (Exception re) {
			log.error("attach failed: "+re.getMessage(), re);	
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - saveOrUpdate: "+re);
			throw eccezione;
		}
		finally{
			if(session.isOpen()){
				session.close();
			} else{
				log.info("la sessione non risulta aperta quindo non faccio la chiusura");
			}
		}
	}
	
	public void saveOrUpdate(DatiBando instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty DatiBando instance");
		try {
			
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");	
		} catch (Exception re) {
			log.error("attach failed: "+re.getMessage(), re);	
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - saveOrUpdate: "+re);
			throw eccezione;
		}
		finally{
			if(session.isOpen()){
				session.close();
			} else{
				log.info("la sessione non risulta aperta quindo non faccio la chiusura");
			}
		}
	}
	
	public void saveOrUpdate(Session session, DatiBando instance) throws GestioneErroriException {
		
		log.debug("attaching dirty DatiBando instance");
		try {
			session.saveOrUpdate(instance);
			log.debug("attach successful");	
		} catch (Exception re) {
			log.error("attach failed: "+re.getMessage(), re);	
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - saveOrUpdate: "+re);
			throw eccezione;
		}
	}

	public void attachClean(DatiBando instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean DatiBando instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed: " + re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - attachClean: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void delete(DatiBando persistentInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting DatiBando instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed: "+re, re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - delete: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public DatiBando merge(DatiBando detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging DatiBando instance");
		try {
			DatiBando result = (DatiBando) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed: " + re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - merge: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public DatiBando findById(java.lang.String id) throws GestioneErroriException {
		
		Session session = HibernateUtil.openSession();
		
		log.debug("getting DatiBando instance with id: " + id);
		DatiBando instance = null;
		try {
			instance = (DatiBando) session.get("com.accenture.CCFarm.DAO.DatiBando", id);
			log.info("qry fatta senza eccezioni");
			if (instance == null) {
				log.debug("qry non trovato elemento");
			} else {
				log.debug("qry trovato elemento");
			}
			return instance;
			
		} catch (RuntimeException re) {
			log.error("get failed: " + re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - findById: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}	
		
	}
	
	public List findByExample(DatiBando instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding DatiBando instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.DatiBando")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("DatiBandoHome - findByExample: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	public boolean getFlagPrecalcolataByRegione(String codRegione) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		boolean flag = true;
		
		try {
			
			List query =  session.createSQLQuery("SELECT FLAG_PRECALCOLATA  FROM DATI_BANDO  WHERE COD_REG ='"+codRegione+"'").list();
			
			String flagPrecalcolata = (String)query.get(0);
			
			if (flagPrecalcolata==null || !flagPrecalcolata.equals("true") || flagPrecalcolata.isEmpty()){
				
				flag = false;
			
			}
			
			return flag;
		
		} catch (RuntimeException re) {
			log.error("getFlagPrecalcolataByRegione() - DatiBandoHome getFlagPrecalcolataByRegione failed : "+ PrintException.stack2string(re));
			throw re;
		}
		finally{
			session.close();
		}
	}
	
	//imposta flag per attivare batch invio inviti e batch elabora mancate risposte su record dati bando della regione a cui appartiene l'interpello
	public int setFlagBatchInvitiEMancataRisp(Session session, String codiceRegione) throws GestioneErroriException {
		
		try {
			
			String hqlUpdateString = "UPDATE DatiBando d"
								     + " SET d.flagInvioInviti = :flagInvioInviti, d.flagMancataRispInterpello = :flagMancataRispInterpello"
								   + " WHERE d.codReg = :codiceRegione";
			
			Query query = session.createQuery(hqlUpdateString);
			
			//impostazione parametri
			query.setParameter("flagInvioInviti", flagValoreVero);
			query.setParameter("flagMancataRispInterpello", flagValoreVero);
			query.setParameter("codiceRegione", codiceRegione);
			
			return query.executeUpdate();
		}
		catch(Exception e) {
			
			log.error("DatiBandoHome setFlagBatchInvitiEMancataRisp failed : "+ e.getMessage(), e);
			throw new GestioneErroriException("DatiBandoHome setFlagBatchInvitiEMancataRisp: " + e);
		}
	}
	
	//imposta il flag di abilitazione caricamento sedi a false
	public int disabilitaCaricamentoSedi(Session session, String codiceRegione) throws GestioneErroriException {
		
		try {
			
			String hqlUpdateString = "UPDATE DatiBando d"
								     + " SET d.flgAbilitaCaricaSedi = :flgAbilitaCaricaSedi"
								   + " WHERE d.codReg = :codiceRegione";
			
			Query query = session.createQuery(hqlUpdateString);
			
			//impostazione parametri
			query.setParameter("flgAbilitaCaricaSedi", flagValoreFalso);
			query.setParameter("codiceRegione", codiceRegione);
			
			return query.executeUpdate();
		}
		catch(Exception e) {
			
			log.error("DatiBandoHome disabilitaCaricamentoSedi failed : "+ e.getMessage(), e);
			throw new GestioneErroriException("DatiBandoHome disabilitaCaricamentoSedi: " + e);
		}
	}
	
	//imposta il flag di abilitazione caricamento sedi a true
	public int abilitaCaricamentoSedi(Session session, String codiceRegione) throws GestioneErroriException {
		
		try {
			
			String hqlUpdateString = "UPDATE DatiBando d"
								     + " SET d.flgAbilitaCaricaSedi = :flgAbilitaCaricaSedi"
								   + " WHERE d.codReg = :codiceRegione";
			
			Query query = session.createQuery(hqlUpdateString);
			
			//impostazione parametri
			query.setParameter("flgAbilitaCaricaSedi", flagValoreVero);
			query.setParameter("codiceRegione", codiceRegione);
			
			return query.executeUpdate();
		}
		catch(Exception e) {
			
			log.error("DatiBandoHome abilitaCaricamentoSedi failed : "+ e.getMessage(), e);
			throw new GestioneErroriException("DatiBandoHome abilitaCaricamentoSedi: " + e);
		}
	}
	
}
