package com.accenture.CCFarm.DAO;



@SuppressWarnings("serial")
public class CorsoAggiornamentoRegStoricoId implements java.io.Serializable {

	private String idStorico;
	private String idCorsoAgg;
	
	public CorsoAggiornamentoRegStoricoId(){
	}

	public String getIdStorico() {
		return idStorico;
	}

	public void setIdStorico(String idStorico) {
		this.idStorico = idStorico;
	}

	public String getIdCorsoAgg() {
		return idCorsoAgg;
	}

	public void setIdCorsoAgg(String idCorsoAgg) {
		this.idCorsoAgg = idCorsoAgg;
	}

	
}