package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.Timestamp;
import java.util.Date;

@SuppressWarnings("serial")
public class GraduatoriaStorico implements java.io.Serializable {

	private String idStorico;
	private String miUtente;
	private Timestamp dataUltimaModifica;
	
	private String idCandidatura;
	private String numeroProtocollo;
	private String cognome;
	private String nome;
	private String codRegione;
	private BigDecimal etaMedia;
	private String etaMediaString;
	private BigDecimal punteggio;
	private String punteggioString;
	private String rettifica;
	private String elaborazione;
	private String versione;
	private String osservazioni;
	private Date dataIstruttoria;
	private BigDecimal  punteggioTitolo;
	private BigDecimal  punteggioEsperienza;
	private BigDecimal  punteggioLaurea;
	private BigDecimal  punteggioAltraLaurea;
	private BigDecimal  punteggioAltraLaureaBis;
	private BigDecimal  punteggioIdoneita;
	private BigDecimal  punteggioIdoneitaNazionale;
	//private BigDecimal  punteggioAbilitazione;
	private Clob note;
	private String dataNascita;
	private String exAequo;
	private String exAequoRisolto;
	private int posizione;
	private BigDecimal indiceRelativo;
	private String color;
	private BigDecimal  punteggioSpecDottBorse;
	private BigDecimal  punteggioPubblicazione;
	private BigDecimal  punteggioAbilitazioneCorsiAggAltriTitoli;
	
	private BigDecimal indiceTotale;
	
	private BigDecimal idInterpello;
	private BigDecimal indiceInterpello;
	private String escluso;
	private String motivoEsclusione;
	
	public GraduatoriaStorico() {}

	public String getIdCandidatura() {
		return idCandidatura;
	}

	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}

	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}

	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public BigDecimal getPunteggio() {
		return punteggio;
	}

	public void setPunteggio(BigDecimal punteggio) {
		this.punteggio = punteggio;
	}

	public String getRettifica() {
		return rettifica;
	}

	public void setRettifica(String rettifica) {
		this.rettifica = rettifica;
	}

	public String getElaborazione() {
		return elaborazione;
	}

	public void setElaborazione(String elaborazione) {
		this.elaborazione = elaborazione;
	}

	public String getVersione() {
		return versione;
	}

	public void setVersione(String versione) {
		this.versione = versione;
	}

	public String getOsservazioni() {
		return osservazioni;
	}


	public void setOsservazioni(String osservazioni) {
		this.osservazioni = osservazioni;
	}


	public Date getDataIstruttoria() {
		return dataIstruttoria;
	}

	public void setDataIstruttoria(Date dataIstruttoria) {
		this.dataIstruttoria = dataIstruttoria;
	}

	public BigDecimal getPunteggioTitolo() {
		return punteggioTitolo;
	}

	public void setPunteggioTitolo(BigDecimal punteggioTitolo) {
		this.punteggioTitolo = punteggioTitolo;
	}



	public BigDecimal getPunteggioEsperienza() {
		return punteggioEsperienza;
	}



	public void setPunteggioEsperienza(BigDecimal punteggioEsperienza) {
		this.punteggioEsperienza = punteggioEsperienza;
	}


	public Clob getNote() {
		return note;
	}



	public void setNote(Clob note) {
		this.note = note;
	}

	public BigDecimal getPunteggioLaurea() {
		return punteggioLaurea;
	}


	public void setPunteggioLaurea(BigDecimal punteggioLaurea) {
		this.punteggioLaurea = punteggioLaurea;
	}

	public BigDecimal getPunteggioAltraLaurea() {
		return punteggioAltraLaurea;
	}


	public void setPunteggioAltraLaurea(BigDecimal punteggioAltraLaurea) {
		this.punteggioAltraLaurea = punteggioAltraLaurea;
	}

	public BigDecimal getPunteggioAltraLaureaBis() {
		return punteggioAltraLaureaBis;
	}

	public void setPunteggioAltraLaureaBis(BigDecimal punteggioAltraLaureaBis) {
		this.punteggioAltraLaureaBis = punteggioAltraLaureaBis;
	}

	public BigDecimal getPunteggioIdoneita() {
		return punteggioIdoneita;
	}

	public void setPunteggioIdoneita(BigDecimal punteggioIdoneita) {
		this.punteggioIdoneita = punteggioIdoneita;
	}


//	public BigDecimal getPunteggioAbilitazione() {
//		return punteggioAbilitazione;
//	}
//
//
//	public void setPunteggioAbilitazione(BigDecimal punteggioAbilitazione) {
//		this.punteggioAbilitazione = punteggioAbilitazione;
//	}

	public BigDecimal getPunteggioIdoneitaNazionale() {
		return punteggioIdoneitaNazionale;
	}


	public void setPunteggioIdoneitaNazionale(BigDecimal punteggioIdoneitaNazionale) {
		this.punteggioIdoneitaNazionale = punteggioIdoneitaNazionale;
	}


	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}


	public BigDecimal getEtaMedia() {
		return etaMedia;
	}


	public void setEtaMedia(BigDecimal etaMedia) {
		this.etaMedia = etaMedia;
	}


	public String getExAequo() {
		return exAequo;
	}



	public void setExAequo(String exAequo) {
		this.exAequo = exAequo;
	}



	public String getExAequoRisolto() {
		return exAequoRisolto;
	}



	public void setExAequoRisolto(String exAequoRisolto) {
		this.exAequoRisolto = exAequoRisolto;
	}


	


	public int getPosizione() {
		return posizione;
	}


	public void setPosizione(int posizione) {
		this.posizione = posizione;
	}


	public String getDataNascita() {
		return dataNascita;
	}


	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}
	
	
	public String getEtaMediaString() {
		this.etaMediaString = this.etaMedia.toString().replace(".", ",");
		return etaMediaString;
	}



	public String getPunteggioString() {
		this.punteggioString = this.punteggio.toString().replace(".", ",");
		
		return punteggioString;
	}


	public BigDecimal getPunteggioSpecDottBorse() {
		return punteggioSpecDottBorse;
	}


	public void setPunteggioSpecDottBorse(BigDecimal punteggioSpecDottBorse) {
		this.punteggioSpecDottBorse = punteggioSpecDottBorse;
	}


	public BigDecimal getPunteggioPubblicazione() {
		return punteggioPubblicazione;
	}


	public void setPunteggioPubblicazione(BigDecimal punteggioPubblicazione) {
		this.punteggioPubblicazione = punteggioPubblicazione;
	}


	public BigDecimal getPunteggioAbilitazioneCorsiAggAltriTitoli() {
		return punteggioAbilitazioneCorsiAggAltriTitoli;
	}


	public void setPunteggioAbilitazioneCorsiAggAltriTitoli(
			BigDecimal punteggioAbilitazioneCorsiAggAltriTitoli) {
		this.punteggioAbilitazioneCorsiAggAltriTitoli = punteggioAbilitazioneCorsiAggAltriTitoli;
	}
	
	public BigDecimal getIndiceRelativo() {
		return indiceRelativo;
	}


	public void setIndiceRelativo(BigDecimal indiceRelativo) {
		this.indiceRelativo = indiceRelativo;
	}


	public BigDecimal getIndiceTotale() {
		return indiceTotale;
	}


	public void setIndiceTotale(BigDecimal indiceTotale) {
		this.indiceTotale = indiceTotale;
	}


	public BigDecimal getIdInterpello() {
		return idInterpello;
	}


	public void setIdInterpello(BigDecimal idInterpello) {
		this.idInterpello = idInterpello;
	}


	public BigDecimal getIndiceInterpello() {
		return indiceInterpello;
	}

	public void setIndiceInterpello(BigDecimal indiceInterpello) {
		this.indiceInterpello = indiceInterpello;
	}


	public String getIdStorico() {
		return idStorico;
	}


	public void setIdStorico(String idStorico) {
		this.idStorico = idStorico;
	}


	public String getMiUtente() {
		return miUtente;
	}


	public void setMiUtente(String miUtente) {
		this.miUtente = miUtente;
	}


	public Timestamp getDataUltimaModifica() {
		return dataUltimaModifica;
	}


	public void setDataUltimaModifica(Timestamp dataUltimaModifica) {
		this.dataUltimaModifica = dataUltimaModifica;
	}

	public String getEscluso() {
		return escluso;
	}

	public void setEscluso(String escluso) {
		this.escluso = escluso;
	}

	public String getMotivoEsclusione() {
		return motivoEsclusione;
	}

	public void setMotivoEsclusione(String motivoEsclusione) {
		this.motivoEsclusione = motivoEsclusione;
	}
  	
}