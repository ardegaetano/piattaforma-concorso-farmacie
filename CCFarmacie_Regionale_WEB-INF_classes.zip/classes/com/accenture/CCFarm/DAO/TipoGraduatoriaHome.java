package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;


/**
* Home object for domain model class TipoGraduatoria.
* @see com.accenture.CalcolaTitoli.DAO.TipoGraduatoria
*/
public class TipoGraduatoriaHome {

	private static final Logger log = CommonLogger.getLogger("TipoGraduatoriaHome");
	
	public void persist(TipoGraduatoria transientInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting TipoGraduatoria instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("TipoGraduatoriaHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(TipoGraduatoria instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty TipoGraduatoria instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw new GestioneErroriException("TipoGraduatoriaHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(TipoGraduatoria instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean TipoGraduatoria instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("TipoGraduatoriaHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(TipoGraduatoria persistentInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting TipoGraduatoria instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("TipoGraduatoriaHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public TipoGraduatoria merge(TipoGraduatoria detachedInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging TipoGraduatoria instance");
		try {
			TipoGraduatoria result = (TipoGraduatoria) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("TipoGraduatoriaHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public TipoGraduatoria findById(TipoGraduatoriaId id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting TipoGraduatoria instance with id: " + id);
		try {
			TipoGraduatoria instance = (TipoGraduatoria) session.get("com.accenture.CCFarm.DAO.TipoGraduatoria", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("TipoGraduatoriaHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(TipoGraduatoria instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding TipoGraduatoria instance by example");
		try {
				List results = session
					.createCriteria("com.accenture.CCFarm.DAO.TipoGraduatoria")
					.add(Example.create(instance)).addOrder(Order.asc("codRegione")).addOrder(Order.desc("progressivo")).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("TipoGraduatoriaHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	public TipoGraduatoria findLastPubblicata(String codReg) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding TipoGraduatoria instance by");
		try{
			SQLQuery sqlQuery;
			BigDecimal progressivo = new BigDecimal(0);
			//trova il max progressivo
			//Query query = ;
			//query.setParameter("codRegione", codReg);
			sqlQuery = session.createSQLQuery("select max(n_progressivo) from tipologia_graduatoria where cod_regione="+codReg+" and stato_graduatoria='P'"
					+ " and DATA_PUBLICAZIONE <= sysdate");
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			List result = sqlQuery.list();

			for(Object object : result){
				Map row = (Map)object;
				progressivo = (BigDecimal) row.get("MAX(N_PROGRESSIVO)");
			}
			
			TipoGraduatoriaId id = new TipoGraduatoriaId();
			id.setCodRegione(codReg);
			id.setProgressivo(progressivo);
			return this.findById(id);
		}catch(RuntimeException re){
			log.error("find by example failed", re);
			throw new GestioneErroriException("TipoGraduatoriaHome - findByExample: errore findByExample");
		}
		
	}
}
