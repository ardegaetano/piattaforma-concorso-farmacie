package com.accenture.CCFarm.DAO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CCFarmLogger;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

public class CandidaturaRegHome {

	private static final Logger log = CommonLogger.getLogger("CandidaturaRegHome");
	
	private static final String flagValoreFalso = AppProperties.getAppProperties().getProperty("flag.valore.falso");
	private static final String flagValoreVero  = AppProperties.getAppProperties().getProperty("flag.valore.vero");
	
	private static final String modalitaCandidaturaSingola = AppProperties.getAppProperties().getProperty("modalita.candidatura.singola");
	private static final String modalitaCandidaturaAssociata = AppProperties.getAppProperties().getProperty("modalita.candidatura.associata");
	private static final String flagReferenteCandidatura = AppProperties.getAppProperties().getProperty("flag.referente.candidatura");
	
	@SuppressWarnings("unchecked")
	public List<UtenteReg> listaUtentiXIdCandidatura(String id_candidatura) throws GestioneErroriException {
		
		Session session = HibernateUtil.openSession();
		List<UtenteReg> result = new ArrayList<UtenteReg>();
		List<CandidaturaReg> listCandida = null;
		UtenteRegHome utenteDAO = new UtenteRegHome();
		
		try {
			
			Query query = session.createQuery("from CandidaturaReg where id_candidatura = :id_candidatura ");
			query.setParameter("id_candidatura", id_candidatura);
			listCandida = (List<CandidaturaReg>) query.list();
			for (CandidaturaReg w_cand : listCandida)
			{
					UtenteReg w_utente = null;
					String id_utente = w_cand.getIdUtente();
					w_utente = utenteDAO.findById(id_utente);
					if (w_utente!=null)
					{
						result.add(w_utente);
					}
			}
			
			return result;
		}
		catch (Exception e) {
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  [" + id_candidatura + "]", e);
			throw new GestioneErroriException("CandidaturaRegHome - listaUtentiXIdCandidatura: errore listaUtentiXIdCandidatura");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	public void saveOrUpdate(CandidaturaReg instance)
			throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		CCFarmLogger.log("saveOrUpdate CandidaturaReg instance", Level.INFO_INT,
				CandidaturaRegHome.class);
		try {
			session.saveOrUpdate(instance);

			trx.commit();
			CCFarmLogger.log(
					"Salvataggio avvenuto con successo per la CandidaturaReg: idUtente"
							+ instance.getIdUtente(), Level.INFO_INT,
					CandidaturaRegHome.class);

		} catch (Exception e) {
			
			if(trx != null)
				trx.rollback();
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", e);
			throw new GestioneErroriException("CandidaturaRegHome - saveOrUpdate: errore CandidaturaRegHome - saveOrUpdate: errore nell' aggiornmaneto della candidatura: idUtente");
		} finally {
			session.close();
		}
	}
	
	public void annullaAssociataUpdate(List<CandidaturaReg> listCandAsso, String idUtente) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		CCFarmLogger.log("saveOrUpdate CandidaturaReg instance", Level.INFO_INT, CandidaturaRegHome.class);
		//java.util.Date dataSys= new java.util.Date();
		
		for (int i = 0; i < listCandAsso.size(); i++) {
			CandidaturaReg instance =  new CandidaturaReg();
			instance = (CandidaturaReg) listCandAsso.get(i);
//			instance.setStatoDomanda("A");
//			instance.setStatoRegistrazione("A");
//			instance.setLastUpdateDateCand(new java.sql.Timestamp(dataSys.getTime()));
//			instance.setLastUpdatedByCand(idUtente);
			try {
				session.saveOrUpdate(instance);
				CCFarmLogger.log("Salvataggio avvenuto con successo per la candidatura: idUtente"
								+ instance.getIdUtente(), Level.INFO_INT, CandidaturaRegHome.class);
				
			} catch (Exception e) {
				trx.rollback();
				log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", e);
				throw new GestioneErroriException("CandidaturaHome - saveOrUpdate: errore nell' aggiornmaneto della candidatura: idUtente");
			}finally{
					trx.commit();
					session.close();	
				
			}

		}	
		
	}
	
	public UtenteCandidaturaReg findByUserId(String id_utente) throws GestioneErroriException
	{
		UtenteCandidaturaReg result = null;
		CCFarmLogger.log("findByUserId UtenteCandidaturaReg id: " + id_utente, Level.INFO_INT,
				CandidaturaRegHome.class);
		Session session = null;
		try {
			
			session = HibernateUtil.openSession();
			result = (UtenteCandidaturaReg) session.get(
					"com.accenture.CCFarm.DAO.UtenteCandidaturaReg", id_utente);
			if (result == null) {
				CCFarmLogger.log("get failed, no instance found",
						Level.INFO_INT, CandidaturaRegHome.class);
			} else {
				CCFarmLogger.log("get successful, instance found",
						Level.INFO_INT, CandidaturaRegHome.class);
			}
			
			return result;
		}
		catch (RuntimeException re) {
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", re);
			throw new GestioneErroriException("CandidaturaRegHome - findByUserId: errore nell' findByUserId della candidatura:");
		}
		finally {
			
			if(session != null)
				session.close();
		}		
	}		
	public CandidaturaReg findById(java.lang.String id)
			throws GestioneErroriException {
		CCFarmLogger.log("findById CandidaturaReg id: " + id, Level.INFO_INT,
				CandidaturaRegHome.class);
		Session session = null;
		try {
			
			session = HibernateUtil.openSession();
			CandidaturaReg instance = (CandidaturaReg) session.get(
					"com.accenture.CCFarm.DAO.CandidaturaReg", id);
			if (instance == null) {
				CCFarmLogger.log("get failed, no instance found",
						Level.INFO_INT, CandidaturaRegHome.class);
			} else {
				CCFarmLogger.log("get successful, instance found",
						Level.INFO_INT, CandidaturaRegHome.class);
			}
			return instance;
		}
		catch (RuntimeException re) {
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", re);
			throw new GestioneErroriException("CandidaturaHome - findById: errore nell' findById della candidatura:");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}

	public ArrayList<CandidaturaReg> findByExample(CandidaturaReg instance)
			throws GestioneErroriException {
		CCFarmLogger
				.log("findByExample CandidaturaReg idUtente: "
						+ instance.getIdUtente(), Level.INFO_INT,
						CandidaturaRegHome.class);
		Session session = null;
		try {
			session = HibernateUtil.openSession();
			@SuppressWarnings("unchecked")
			ArrayList<CandidaturaReg> results = (ArrayList<CandidaturaReg>) session
					.createCriteria("com.accenture.CCFarm.DAO.CandidaturaReg")
					.add(Example.create(instance)).list();
			CCFarmLogger.log(
					"findByExample successful CandidaturaReg , result size: "
							+ results.size(), Level.INFO_INT,
					CandidaturaRegHome.class);
			return results;
		} catch (RuntimeException re) {
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", re);
			throw new GestioneErroriException("CandidaturaHome - findByExample: errore nell' findByExample della candidatura:");
		} finally {
			
			if(session != null)
				session.close();
		}
	}
	
	public void aggiornaAmmissione(List<CandidaturaReg> listCandAmmesso, String ammesso) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		CCFarmLogger.log("saveOrUpdate CandidaturaReg instance", Level.INFO_INT, CandidaturaRegHome.class);
		
		try {
			for (int i = 0; i < listCandAmmesso.size(); i++) {
				CandidaturaReg instance =  new CandidaturaReg();
				instance = (CandidaturaReg) listCandAmmesso.get(i);
				instance.setAmmesso(ammesso);
				instance.setDataNonAmmissione(new Date(System.currentTimeMillis()));
					session.saveOrUpdate(instance);
					CCFarmLogger.log("Salvataggio avvenuto con successo per la candidatura: idUtente"
									+ instance.getIdUtente(), Level.INFO_INT, CandidaturaRegHome.class);
			
			}	
			trx.commit();
		} catch (Exception e) {
			trx.rollback();
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", e);
			throw new GestioneErroriException("CandidaturaHome - saveOrUpdate: errore nell' aggiornmaneto della candidatura: idUtente");
		}finally{
			session.close();	
		}

	}
	
	public boolean setErroreElaborazione (String idUtente) throws GestioneErroriException{
		CCFarmLogger.log("setErroreElaborazione Candidatura id: " + idUtente, Level.INFO_INT,
				CandidaturaHome.class);
		Session session = null;
		Transaction trx = null;
		boolean setErroreElab = false;
		try {
			
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			
			Query sqlQuery = session.createQuery("Update CandidaturaReg set erroreElabAutomatica='T' where idUtente='"+idUtente+"'");
			
			sqlQuery.executeUpdate();
			
			trx.commit();
			
			setErroreElab = true;
			return setErroreElab;
			
		}
		catch (RuntimeException re) {
			
			trx.rollback();
			log.error("Errore Update candidatura_reg ", re);
			throw new GestioneErroriException("CandidaturaHome - setErroreElaborazione: errore nel setErroreElaborazione della candidatura:");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//marca tutti i referenti per le candidature specificate nella lista con il flag sedi a "true"
	public void abilitaSceltaSedi(Session session, String codiceRegione, List<String> elencoIdCandidature) throws GestioneErroriException {
		
		try {
			
			if(elencoIdCandidature == null || elencoIdCandidature.isEmpty())
				return;
			
			String hqlUpdateString = "UPDATE CandidaturaReg cr"
								   + " SET cr.flagAbilitaSceltaSedi = :flagAbilitaSceltaSedi"
								   + " WHERE cr.codiceRegione = :codiceRegione"
								   + " AND cr.idCandidatura IN (:ids)"
								   + " AND (cr.modalitaCandidatura = :modalitaCandidaturaSingola"
								   		 + " OR (cr.modalitaCandidatura = :modalitaCandidaturaAssociata AND cr.referenteDomanda = :flagReferenteCandidatura))";
			
			Query query = session.createQuery(hqlUpdateString);
			
			//impostazione parametri
			query.setParameter("flagAbilitaSceltaSedi", flagValoreVero);
			query.setParameter("codiceRegione", codiceRegione);
			query.setParameterList("ids", elencoIdCandidature);
			query.setParameter("modalitaCandidaturaSingola", modalitaCandidaturaSingola);
			query.setParameter("modalitaCandidaturaAssociata", modalitaCandidaturaAssociata);
			query.setParameter("flagReferenteCandidatura", flagReferenteCandidatura);
			
			query.executeUpdate();
		}
		catch(Exception e) {
			
			log.error("CandidaturaRegHome abilitaSceltaSedi() failed", e);
			throw new GestioneErroriException("CandidaturaRegHome abilitaSceltaSedi() failed");
		}
	}
	
	//resetta il flag sedi per tutte le candidature presenti per la regione specificata
	public void resettaSceltaSedi(Session session, String codiceRegione) throws GestioneErroriException {
		
		try {
			
			String hqlUpdateString = "UPDATE CandidaturaReg cr"
								   + " SET cr.flagAbilitaSceltaSedi = :flagAbilitaSceltaSedi"
								   + " WHERE cr.codiceRegione = :codiceRegione";
			
			Query query = session.createQuery(hqlUpdateString);
			
			//impostazione parametri
			query.setParameter("flagAbilitaSceltaSedi", flagValoreFalso);
			query.setParameter("codiceRegione", codiceRegione);
			
			query.executeUpdate();
		}
		catch(Exception e) {
			
			log.error("CandidaturaRegHome resettaSceltaSedi() failed", e);
			throw new GestioneErroriException("CandidaturaRegHome resettaSceltaSedi() failed");
		}
	}
	
	public boolean isCandidaturaEsclusa(CandidaturaReg candidaturaReg) throws GestioneErroriException {
		
		boolean bRet=false;
		if(candidaturaReg.getAmmesso()!=null && candidaturaReg.getAmmesso().equalsIgnoreCase("NO")){
			bRet=true;
		}
		return bRet;
	}	
		
}
