package com.accenture.CCFarm.DAO;

import java.util.ArrayList;

public class DomandaDao {
	
	private UtenteCandidaturaReg utenteCandidatura;
	private CandidaturaReg candidaturaReg;
	private RequisitiMinimiReg requisitiMinimi;
	
	private UtenteReg utente;// � necessario? stessi campi di utenteCandidatura
	// TAB Titoli di Studio
	private AltraLaureaReg altraLaurea;
	private ArrayList<AltraLaureaBisReg> listaAltraLaureaBis;
	private ArrayList <AltroTitoloReg> listaAltroTitolo;
	private ArrayList<BorsaStudioReg> listaBorsaStudio;
	private ArrayList<CorsoAggiornamentoReg> listaCorsoAggiornamento;
	private ArrayList<DottoratoReg> listaDottorato;
	private ArrayList<PubblicazioneReg> listaPubblicazione;
	private ArrayList<SpecializzazioneReg> listaSpecializzazione;
	private IdoneitaReg idoneita;
	// TAB Esercizio professionale
	private EsercizioProfReg esercizioProf;
	private ArrayList<EsercizioProfReg> listaEserciziProf;
	// TAB Versamento e documentazione
	private DichiarazioneSostitutivaReg dichiarazioneSostitutiva;
	private ArrayList<DocumentoReg> listaDocumenti;
	
	public UtenteCandidaturaReg getUtenteCandidatura() {
		return utenteCandidatura;
	}
	public void setUtenteCandidatura(UtenteCandidaturaReg utenteCandidatura) {
		this.utenteCandidatura = utenteCandidatura;
	}
	
	public RequisitiMinimiReg getRequisitiMinimi() {
		return requisitiMinimi;
	}
	public void setRequisitiMinimi(RequisitiMinimiReg requisitiMinimi) {
		this.requisitiMinimi = requisitiMinimi;
	}
	public UtenteReg getUtente() {
		return utente;
	}
	public void setUtente(UtenteReg utente) {
		this.utente = utente;
	}
	public AltraLaureaReg getAltraLaurea() {
		return altraLaurea;
	}
	public void setAltraLaurea(AltraLaureaReg altraLaurea) {
		this.altraLaurea = altraLaurea;
	}
	public ArrayList<AltraLaureaBisReg> getListaAltraLaureaBis() {
		return listaAltraLaureaBis;
	}
	public void setListaAltraLaureaBis(ArrayList<AltraLaureaBisReg> listaAltraLaureaBis) {
		this.listaAltraLaureaBis = listaAltraLaureaBis;
	}
	public ArrayList<AltroTitoloReg> getListaAltroTitolo() {
		return listaAltroTitolo;
	}
	public void setListaAltroTitolo(ArrayList<AltroTitoloReg> listaAltroTitolo) {
		this.listaAltroTitolo = listaAltroTitolo;
	}
	public ArrayList<CorsoAggiornamentoReg> getListaCorsoAggiornamento() {
		return listaCorsoAggiornamento;
	}
	public void setListaCorsoAggiornamento(
			ArrayList<CorsoAggiornamentoReg> listaCorsoAggiornamento) {
		this.listaCorsoAggiornamento = listaCorsoAggiornamento;
	}
	public ArrayList<DottoratoReg> getListaDottorato() {
		return listaDottorato;
	}
	public void setListaDottorato(ArrayList<DottoratoReg> listaDottorato) {
		this.listaDottorato = listaDottorato;
	}
	public IdoneitaReg getIdoneita() {
		return idoneita;
	}
	public ArrayList<BorsaStudioReg> getListaBorsaStudio() {
		return listaBorsaStudio;
	}
	public void setListaBorsaStudio(ArrayList<BorsaStudioReg> listaBorsaStudio) {
		this.listaBorsaStudio = listaBorsaStudio;
	}
	public ArrayList<PubblicazioneReg> getListaPubblicazione() {
		return listaPubblicazione;
	}
	public void setListaPubblicazione(ArrayList<PubblicazioneReg> listaPubblicazione) {
		this.listaPubblicazione = listaPubblicazione;
	}
	public ArrayList<SpecializzazioneReg> getListaSpecializzazione() {
		return listaSpecializzazione;
	}
	public void setListaSpecializzazione(
			ArrayList<SpecializzazioneReg> listaSpecializzazione) {
		this.listaSpecializzazione = listaSpecializzazione;
	}
	public void setIdoneita(IdoneitaReg idoneita) {
		this.idoneita = idoneita;
	}
	public EsercizioProfReg getEsercizioProf() {
		return esercizioProf;
	}
	public void setEsercizioProf(EsercizioProfReg esercizioProf) {
		this.esercizioProf = esercizioProf;
	}
	public ArrayList<EsercizioProfReg> getListaEserciziProf() {
		return listaEserciziProf;
	}
	public void setListaEserciziProf(ArrayList<EsercizioProfReg> listaEserciziProf) {
		this.listaEserciziProf = listaEserciziProf;
	}
	public DichiarazioneSostitutivaReg getDichiarazioneSostitutiva() {
		return dichiarazioneSostitutiva;
	}
	public void setDichiarazioneSostitutiva(
			DichiarazioneSostitutivaReg dichiarazioneSostitutiva) {
		this.dichiarazioneSostitutiva = dichiarazioneSostitutiva;
	}
	public ArrayList<DocumentoReg> getListaDocumenti() {
		return listaDocumenti;
	}
	public void setListaDocumenti(ArrayList<DocumentoReg> listaDocumenti) {
		this.listaDocumenti = listaDocumenti;
	}
	public CandidaturaReg getCandidaturaReg() {
		return candidaturaReg;
	}
	public void setCandidaturaReg(CandidaturaReg candidaturaReg) {
		this.candidaturaReg = candidaturaReg;
	}
	
}
