package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.accenture.CCFarm.Bean.DatiCandidato;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.StaticDefinitions;
import com.accenture.mailer.concorsofarma.GestoreMail;
import com.accenture.mailer.concorsofarma.data.MailBean;

public class GraduatoriaHome {

	private static final Logger log = CommonLogger.getLogger("GraduatoriaHome");
	private static final String flagValoreVero  = AppProperties.getAppProperties().getProperty("flag.valore.vero");
	private static final String flagValoreFalso  = AppProperties.getAppProperties().getProperty("flag.valore.falso");
	private static final String codiceInterpelloPubblicato = AppProperties.getAppProperties().getProperty("codice.interpello.pubblicato");
	private static final String codiceInterpelloChiuso = AppProperties.getAppProperties().getProperty("codice.interpello.chiuso");
	
	public void persist(Graduatoria transientInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting Graduatoria instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("GraduatoriaHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}
	
	public void saveOrUpdate(Graduatoria instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Graduatoria instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw new GestioneErroriException("GraduatoriaHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}
	
	public void saveOrUpdate(Graduatoria instance, Session session) throws GestioneErroriException{
		log.debug("attaching dirty Utente instance");
		try {
			session.saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("GraduatoriaHome - saveOrUpdate: errore saveOrUpdate");
		}
	}

	public void saveOrUpdate(Graduatoria instance, GraduatoriaStorico instanceStr) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Graduatoria instance");
		try {
			session.saveOrUpdate(instance);
			session.saveOrUpdate(instanceStr);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw new GestioneErroriException("GraduatoriaHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(Graduatoria instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Graduatoria instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("GraduatoriaHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(Graduatoria persistentInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting Graduatoria instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("GraduatoriaHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public Graduatoria merge(Graduatoria detachedInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging Graduatoria instance");
		try {
			Graduatoria result = (Graduatoria) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("GraduatoriaHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public Graduatoria findById(java.lang.String id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting Graduatoria instance with id: " + id);
		try {
			Graduatoria instance = (Graduatoria) session.get("com.accenture.CCFarm.DAO.Graduatoria", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(Graduatoria instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Graduatoria instance by example");
		try {
				List results = session
					.createCriteria("com.accenture.CCFarm.DAO.Graduatoria")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	public List<Graduatoria> findByCriteria(Graduatoria graduatoria) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Graduatoria instance by example");
		try {
			Criteria criteria = session.createCriteria(Graduatoria.class);
			if(!graduatoria.getNumeroProtocollo().equalsIgnoreCase("")){
				criteria.add(Restrictions.like("numeroProtocollo", graduatoria.getNumeroProtocollo().toUpperCase().trim()+"%"));
						
			}
			if(!graduatoria.getCognome().equalsIgnoreCase("")){
				criteria.add(Restrictions.eq("cognome", graduatoria.getCognome().toUpperCase().trim()));
			}
			
			if(!graduatoria.getExAequoRisolto().equalsIgnoreCase("")){
				criteria.add(Restrictions.eq("exAequoRisolto", graduatoria.getExAequoRisolto().toUpperCase().trim()));
			}
			
			criteria.add(Restrictions.eq("codRegione", graduatoria.getCodRegione()));
			criteria.addOrder(Order.asc("indiceTotale"));
			return criteria.list();
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
		
	}
	
	
	public List<Graduatoria> findOrderByGraduatoria(String codReg)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<Graduatoria> graduatoriaList = new ArrayList<Graduatoria>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
	
		try{
		session = HibernateUtil.openSession();
		query = "select * from graduatoria where cod_regionale='"+codReg+"'" +
				" ORDER BY punteggio DESC,eta_media ASC, indice_totale ASC,cognome ASC,nome ASC";
				
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		List result = sqlQuery.list();
		
		Graduatoria graduatoria= null;
		
		for(Object object : result){
			graduatoria = new Graduatoria();
			Map row = (Map)object;
		
			graduatoria.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
			graduatoria.setCognome((String) row.get("COGNOME"));
			graduatoria.setNome((String) row.get("NOME"));
			punteggio = (BigDecimal)row.get("PUNTEGGIO");
			graduatoria.setPunteggio(punteggio);
			graduatoria.setRettifica((String)row.get("RETTIFICA"));
			graduatoria.setVersione((String)row.get("VERSIONE"));
			graduatoria.setOsservazioni((String)row.get("OSSERVAZIONI"));
			graduatoria.setPunteggioTitolo((BigDecimal)row.get("PUNTEGGIO_TITOLO"));
			graduatoria.setPunteggioEsperienza((BigDecimal)row.get("PUNTEGGIO_ESPERIENZA"));
			graduatoria.setElaborazione((String)row.get("ELABORAZIONE"));
			graduatoria.setNote((Clob) row.get("NOTE"));
			graduatoria.setPunteggioLaurea((BigDecimal)row.get("PUNTEGGIO_LAUREA"));
			graduatoria.setPunteggioAltraLaurea((BigDecimal)row.get("PUNTEGGIO_ALTRA_LAUREA"));
			graduatoria.setPunteggioAltraLaureaBis((BigDecimal)row.get("PUNTEGGIO_ALTRA_LAUREA_BIS"));
			graduatoria.setPunteggioIdoneita((BigDecimal)row.get("PUNTEGGIO_IDONEITA"));
			graduatoria.setPunteggioAbilitazioneCorsiAggAltriTitoli((BigDecimal)row.get("PUNTEGGIO_ABILITAZIONE"));  //sicuro?
			graduatoria.setPunteggioIdoneitaNazionale((BigDecimal)row.get("PUNTEGGIO_IDONEITA_NAZIONALE"));
			graduatoria.setPunteggioSpecDottBorse((BigDecimal)row.get("PUNTEGGIO_SPEC_DOTT_BORSE"));
			graduatoria.setPunteggioPubblicazione((BigDecimal)row.get("PUNTEGGIO_PUBBLICAZIONE"));
			eta = (BigDecimal) row.get("ETA_MEDIA");
			graduatoria.setEtaMedia(eta);
			graduatoria.setDataNascita((String) row.get("DATA_NASCITA"));
			graduatoria.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
			graduatoria.setCodRegione((String) row.get("COD_REGIONALE"));
			graduatoria.setExAequo((String) row.get("EXAEQUO"));
			graduatoria.setExAequoRisolto((String) row.get("EXAEQUO_RISOLTI"));
			graduatoria.setDataIstruttoria((Timestamp) row.get("DATA_ISTRUTTORIA"));
			graduatoria.setColor((String) row.get("EXAEQUO_COLOR"));
			graduatoria.setIndiceTotale((BigDecimal)row.get("INDICE_TOTALE"));
			graduatoria.setIndiceRelativo((BigDecimal)row.get("INDICE_RELATIVO"));
			graduatoria.setIdInterpello((BigDecimal)row.get("ID_INTERPELLO"));
			graduatoria.setIndiceInterpello((BigDecimal)row.get("INDICE_INTERPELLO"));
			graduatoria.setEscluso((String) row.get("ESCLUSO"));
			graduatoria.setMotivoEsclusione((String) row.get("MOTIVO_ESCLUSIONE"));
			graduatoriaList.add(graduatoria);
		}
		
		return graduatoriaList;
		
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findOrderByGraduatoria: errore findByFilter");
		}finally{
			session.close();
		}
	}
	
	/*public List<Graduatoria> findGraduatoriaForEsclusione(Graduatoria graduatoria) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Graduatoria instance by findGraduatoriaForEsclusione");
		try {
			Criteria criteria = session.createCriteria(Graduatoria.class);
			
			if(graduatoria.getNome()!=null && !graduatoria.getNome().equalsIgnoreCase("")){
				criteria.add(Restrictions.like("nome", graduatoria.getNome().toUpperCase().trim()+'%'));
			}
			if(graduatoria.getCognome()!=null && !graduatoria.getCognome().equalsIgnoreCase("")){
				criteria.add(Restrictions.like("cognome", graduatoria.getCognome().toUpperCase().trim()+'%'));
			}
			if(graduatoria.getNumeroProtocollo()!=null && !graduatoria.getNumeroProtocollo().equalsIgnoreCase("")){
				criteria.add(Restrictions.eq("numeroProtocollo", graduatoria.getNumeroProtocollo().toUpperCase().trim()));
			}
			if(graduatoria.getEscluso()!=null && !graduatoria.getEscluso().equalsIgnoreCase("-1")){
				//Se impostato filtro di ricerca Escluso=false devono essere recuperati tutti gli esclusi a null o a false
				if(graduatoria.getEscluso().equalsIgnoreCase(flagValoreFalso))
					criteria.add(Restrictions.isNull("escluso"));
				else
					criteria.add(Restrictions.eq("escluso", graduatoria.getEscluso().trim()));
			}
			
			criteria.add(Restrictions.eq("codRegione", graduatoria.getCodRegione()));
			criteria.addOrder(Order.asc("nome"));
			
			return criteria.list();
		
		} catch (RuntimeException re) {
			log.error("findGraduatoriaForEsclusione failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findGraduatoriaForEsclusione: errore");
		}
		finally{
			session.close();
		}
		
	}*/
	
	public List<DatiCandidato> findGraduatoriaForEsclusione(DatiCandidato datiCandidato) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding Graduatoria instance by findGraduatoriaForEsclusione");
		try {
				String query = "select g.id_candidatura as idCandidato, upper(trim(g.nome)) as nome, upper(trim(g.cognome)) as cognome,"+
					" upper(trim(u.codice_fiscale_utente)) as codiceFiscale, upper(trim(g.numero_protocollo)) as numeroProtocollo,"+
					" g.escluso as escluso,"+
					" g.motivo_Esclusione as motivoEsclusione"+
					" from graduatoria g, utente_reg u"+
					" where cod_regionale='"+datiCandidato.getCodRegione()+"'"+ 
					" and g.id_candidatura = u.id_utente";
				
				if(datiCandidato.getNome()!=null && !datiCandidato.getNome().equalsIgnoreCase("")){
					query = query + " and upper(trim(g.nome)) like '"+datiCandidato.getNome().toUpperCase().trim()+"%'";
				}
				if(datiCandidato.getCognome()!=null && !datiCandidato.getCognome().equalsIgnoreCase("")){
					query = query + " and upper(trim(g.cognome)) like '"+datiCandidato.getCognome().toUpperCase().trim()+"%'";
				}
				if(datiCandidato.getCodiceFiscale()!=null && !datiCandidato.getCodiceFiscale().equalsIgnoreCase("")){
					query = query + " and upper(trim(u.codice_fiscale_utente)) = '"+datiCandidato.getCodiceFiscale().toUpperCase().trim()+"'";
				}
				if(datiCandidato.getNumeroProtocollo()!=null && !datiCandidato.getNumeroProtocollo().equalsIgnoreCase("")){
					query = query + " and upper(trim(g.numero_protocollo)) like '"+datiCandidato.getNumeroProtocollo().toUpperCase().trim()+"%'";
				}
				if(datiCandidato.getEscluso()!=null && !datiCandidato.getEscluso().equalsIgnoreCase("-1")){
					//Se impostato filtro di ricerca Escluso=false devono essere recuperati tutti gli esclusi a null o a false
					if(datiCandidato.getEscluso().equalsIgnoreCase(flagValoreFalso))
						query = query + " and g.escluso is null";
					else
						query = query + " and g.escluso = '"+datiCandidato.getEscluso().trim()+"'";
				}
				
				query = query + " order by nome, cognome";
				
				SQLQuery sqlQuery = session.createSQLQuery(query);
				sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
				List result = sqlQuery.list();
				List<DatiCandidato> candidatiList = new ArrayList<DatiCandidato>();
				
				for(Object object : result){
					DatiCandidato candidato = new DatiCandidato();
					Map row = (Map)object;
					candidato.setIdCandidato((String) row.get("IDCANDIDATO"));
					candidato.setNome((String) row.get("NOME"));
					candidato.setCognome((String) row.get("COGNOME"));
					candidato.setCodiceFiscale((String) row.get("CODICEFISCALE"));
					candidato.setNumeroProtocollo((String)row.get("NUMEROPROTOCOLLO"));
					candidato.setEscluso((String)row.get("ESCLUSO"));
					candidato.setCodRegione(datiCandidato.getCodRegione());
					String motivoEsclusione = (String)row.get("MOTIVOESCLUSIONE");
					candidato.setMotivoRinuncia(motivoEsclusione!=null && (!motivoEsclusione.equals("")) ? motivoEsclusione : "");
					candidatiList.add(candidato);
				}
				return candidatiList;
				
				
		} catch (RuntimeException re) {
			log.error("findGraduatoriaForEsclusione failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findGraduatoriaForEsclusione: errore");
		}
		finally{
			session.close();
		}
	}
	
	
	public boolean isCandidatoInterpellato(String codReg, String idCandidatura) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			session = HibernateUtil.openSession();
			String query = "SELECT G.ID_CANDIDATURA FROM INTERPELLO I, GRADUATORIA G"+ 
			" WHERE"+   
			" I.COD_REG = G.COD_REGIONALE"+
			" AND I.COD_REG = '"+codReg+"'"+ 
			" AND G.ID_INTERPELLO = I.ID_INTERPELLO"+
			" AND (I.STATO='"+codiceInterpelloPubblicato+"' OR I.STATO='"+codiceInterpelloChiuso+"')"+
			" AND G.ID_CANDIDATURA = '"+idCandidatura+"'";
					
			SQLQuery sqlQuery = session.createSQLQuery(query);
			List result = sqlQuery.list();
			
			return (result != null && result.size() > 0);
		}
		catch(Exception e) {
			
			log.error("GraduatoriaHome - isCandidatoInterpellato fallito", e);
			throw new GestioneErroriException("GraduatoriaHome - isCandidatoInterpellato fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
			
	}
	
	public List<Graduatoria> findLazyListGraduatoria(String codReg,int startPage,int maxPerPage)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<Graduatoria> graduatoriaList = new ArrayList<Graduatoria>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
		
		
		
		//int x = startPage-10;
		//int y = maxPerPage+10;
		try{
		session = HibernateUtil.openSession();
		if(getRettificatiRow(codReg)){
			query = "select * from(select rownum as rn,ID_CANDIDATURA , COD_REGIONALE, numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita,exaequo,exaequo_risolti,exaequo_color,indice_totale from graduatoria where cod_regionale='"+codReg+"'" +
					" ORDER BY  punteggio DESC,eta_media ASC, cognome ASC,nome ASC)";
		}else{
			query = "select * from(select rownum as rn,ID_CANDIDATURA , COD_REGIONALE, numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita,exaequo,exaequo_risolti,exaequo_color,indice_totale from graduatoria where cod_regionale='"+codReg+"'" +
					" ORDER BY punteggio DESC,indice_totale ASC,eta_media ASC, cognome ASC,nome ASC)";
		}
		
		
				//" where  rn >= '"+startPage+"'"+
				//"and rownum <='"+maxPerPage+"'";
		   
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		sqlQuery.setFirstResult(startPage);
		sqlQuery.setMaxResults(maxPerPage);
		List result = sqlQuery.list();
		
		
		Graduatoria graduatoria= null;
		
		for(Object object : result){
			graduatoria = new Graduatoria();
			Map row = (Map)object;
			graduatoria.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
			graduatoria.setCognome((String) row.get("COGNOME"));
			graduatoria.setNome((String) row.get("NOME"));
			punteggio = (BigDecimal)row.get("PUNTEGGIO");
			graduatoria.setPunteggio(punteggio);
			graduatoria.setRettifica((String)row.get("RETTIFICA"));
			graduatoria.setVersione((String)row.get("VERSIONE"));
			graduatoria.setOsservazioni((String)row.get("OSSERVAZIONI"));
			graduatoria.setPunteggioTitolo((BigDecimal)row.get("PUNTEGGIO_TITOLO"));
			graduatoria.setPunteggioEsperienza((BigDecimal)row.get("PUNTEGGIO_ESPERIENZA"));
			graduatoria.setElaborazione((String)row.get("ELABORAZIONE"));
			graduatoria.setNote((Clob) row.get("NOTE"));
			graduatoria.setPunteggioLaurea((BigDecimal)row.get("PUNTEGGIO_LAUREA"));
			graduatoria.setPunteggioAltraLaurea((BigDecimal)row.get("PUNTEGGIO_ALTRA_LAUREA"));
			graduatoria.setPunteggioAltraLaureaBis((BigDecimal)row.get("PUNTEGGIO_ALTRA_LAUREA_BIS"));
			graduatoria.setPunteggioIdoneita((BigDecimal)row.get("PUNTEGGIO_IDONEITA"));
			graduatoria.setPunteggioAbilitazioneCorsiAggAltriTitoli((BigDecimal)row.get("PUNTEGGIO_ABILITAZIONE"));  //sicuro?
			graduatoria.setPunteggioIdoneitaNazionale((BigDecimal)row.get("PUNTEGGIO_IDONEITA_NAZIONALE"));
			graduatoria.setPunteggioSpecDottBorse((BigDecimal)row.get("PUNTEGGIO_SPEC_DOTT_BORSE"));
			graduatoria.setPunteggioPubblicazione((BigDecimal)row.get("PUNTEGGIO_PUBBLICAZIONE"));
			eta = (BigDecimal) row.get("ETA_MEDIA");
			graduatoria.setEtaMedia(eta);
			graduatoria.setDataNascita((String) row.get("DATA_NASCITA"));
			graduatoria.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
			graduatoria.setCodRegione((String) row.get("COD_REGIONALE"));
			graduatoria.setExAequo((String) row.get("EXAEQUO"));
			graduatoria.setExAequoRisolto((String) row.get("EXAEQUO_RISOLTI"));
			graduatoria.setDataIstruttoria((Timestamp) row.get("DATA_ISTRUTTORIA"));
			graduatoria.setColor((String) row.get("EXAEQUO_COLOR"));
			graduatoria.setIndiceTotale((BigDecimal)row.get("INDICE_TOTALE"));
			graduatoria.setIndiceRelativo((BigDecimal)row.get("INDICE_RELATIVO"));
			graduatoria.setIdInterpello((BigDecimal)row.get("ID_INTERPELLO"));
			graduatoria.setIndiceInterpello((BigDecimal)row.get("INDICE_INTERPELLO"));
			graduatoria.setEscluso((String) row.get("ESCLUSO"));
			graduatoria.setMotivoEsclusione((String) row.get("MOTIVO_ESCLUSIONE"));
			graduatoriaList.add(graduatoria);
		}
		
		return graduatoriaList;
		
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findOrderByGraduatoria: errore findByFilter");
		}finally{
			session.close();
			
		}
	}
	
	public List<Graduatoria> findLazyListGradJoinGradDefin(String codReg,int startPage,int maxPerPage)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<Graduatoria> graduatoriaList = new ArrayList<Graduatoria>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
	
		//int x = startPage-10;
		//int y = maxPerPage+10;
		try{
		session = HibernateUtil.openSession();
//		query = "select * from(select rownum as rn,ID_CANDIDATURA , COD_REGIONALE, numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita from graduatoria where cod_regionale='"+codReg+"'" +
//				" ORDER BY punteggio DESC,eta_media ASC,cognome ASC,nome ASC)";
				//" where  rn >= '"+startPage+"'"+
				//"and rownum <='"+maxPerPage+"'";
//JOIN  tra GRADUATORIA e GRADUATORIA_DEFINITIVA		
		query = " select * from(select rownum as rn, G.ID_CANDIDATURA , G.COD_REGIONALE, G.numero_protocollo, G.cognome, G.nome, G.punteggio, G.eta_media, G.data_nascita, G.INDICE_TOTALE, G.INDICE_RELATIVO, G.EXAEQUO, G.EXAEQUO_RISOLTI, G.EXAEQUO_COLOR " +
                " from graduatoria G " + 
				" where G.cod_regionale='"+codReg+"' " +
				" ORDER BY G.punteggio DESC,  G.eta_media ASC, G.INDICE_TOTALE ASC , G.cognome ASC, G.nome ASC)";
	
		
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		sqlQuery.setFirstResult(startPage);
		sqlQuery.setMaxResults(maxPerPage);
		List result = sqlQuery.list();
		
		Graduatoria graduatoria= null;
		
		for(Object object : result){
			graduatoria = new Graduatoria();
			Map row = (Map)object;
			graduatoria.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
			graduatoria.setCognome((String) row.get("COGNOME"));
			graduatoria.setNome((String) row.get("NOME"));
			punteggio = (BigDecimal)row.get("PUNTEGGIO");
			graduatoria.setPunteggio(punteggio);
			graduatoria.setRettifica((String)row.get("RETTIFICA"));
			graduatoria.setVersione((String)row.get("VERSIONE"));
			graduatoria.setOsservazioni((String)row.get("OSSERVAZIONI"));
			graduatoria.setPunteggioTitolo((BigDecimal)row.get("PUNTEGGIO_TITOLO"));
			graduatoria.setPunteggioEsperienza((BigDecimal)row.get("PUNTEGGIO_ESPERIENZA"));
			graduatoria.setElaborazione((String)row.get("ELABORAZIONE"));
			graduatoria.setNote((Clob) row.get("NOTE"));
			graduatoria.setPunteggioLaurea((BigDecimal)row.get("PUNTEGGIO_LAUREA"));
			graduatoria.setPunteggioAltraLaurea((BigDecimal)row.get("PUNTEGGIO_ALTRA_LAUREA"));
			graduatoria.setPunteggioAltraLaureaBis((BigDecimal)row.get("PUNTEGGIO_ALTRA_LAUREA_BIS"));
			graduatoria.setPunteggioIdoneita((BigDecimal)row.get("PUNTEGGIO_IDONEITA"));
			graduatoria.setPunteggioAbilitazioneCorsiAggAltriTitoli((BigDecimal)row.get("PUNTEGGIO_ABILITAZIONE"));  //sicuro?
			graduatoria.setPunteggioIdoneitaNazionale((BigDecimal)row.get("PUNTEGGIO_IDONEITA_NAZIONALE"));
			graduatoria.setPunteggioSpecDottBorse((BigDecimal)row.get("PUNTEGGIO_SPEC_DOTT_BORSE"));
			graduatoria.setPunteggioPubblicazione((BigDecimal)row.get("PUNTEGGIO_PUBBLICAZIONE"));
			eta = (BigDecimal) row.get("ETA_MEDIA");
			graduatoria.setEtaMedia(eta);
			graduatoria.setDataNascita((String) row.get("DATA_NASCITA"));
			graduatoria.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
			graduatoria.setCodRegione((String) row.get("COD_REGIONALE"));
			graduatoria.setExAequo((String) row.get("EXAEQUO"));
			graduatoria.setExAequoRisolto((String) row.get("EXAEQUO_RISOLTI"));
			graduatoria.setDataIstruttoria((Timestamp) row.get("DATA_ISTRUTTORIA"));
			graduatoria.setColor((String) row.get("EXAEQUO_COLOR"));
			graduatoria.setIndiceTotale((BigDecimal)row.get("INDICE_TOTALE"));
			graduatoria.setIndiceRelativo((BigDecimal)row.get("INDICE_RELATIVO"));
			graduatoria.setIdInterpello((BigDecimal)row.get("ID_INTERPELLO"));
			graduatoria.setIndiceInterpello((BigDecimal)row.get("INDICE_INTERPELLO"));
			graduatoria.setEscluso((String) row.get("ESCLUSO"));
			graduatoria.setMotivoEsclusione((String) row.get("MOTIVO_ESCLUSIONE"));
			graduatoriaList.add(graduatoria);
			
		}
		
		return graduatoriaList;
		
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findOrderByGraduatoria: errore findByFilter");
		}finally{
			session.close();
		}
	}
	
	
	public List<Graduatoria> findOrderAllGraduatoria(String codReg)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<Graduatoria> graduatoriaList = new ArrayList<Graduatoria>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
	
		try{
		session = HibernateUtil.openSession();
		query = "select * from(select rownum as rn,id_candidatura,cod_regionale,numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita, indice_totale, INDICE_RELATIVO, EXAEQUO, EXAEQUO_RISOLTI, EXAEQUO_COLOR from graduatoria where cod_regionale='"+codReg+"'" +
				" ORDER BY punteggio DESC,eta_media ASC,indice_totale, cognome ASC,nome ASC)";
				
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		List result = sqlQuery.list();
		
		Graduatoria graduatoria= null;
		
		for(Object object : result){
			graduatoria = new Graduatoria();
			Map row = (Map)object;
			graduatoria.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
			graduatoria.setCognome((String) row.get("COGNOME"));
			graduatoria.setNome((String) row.get("NOME"));
			punteggio = (BigDecimal)row.get("PUNTEGGIO");
			graduatoria.setPunteggio(punteggio);
			graduatoria.setRettifica((String)row.get("RETTIFICA"));
			graduatoria.setVersione((String)row.get("VERSIONE"));
			graduatoria.setOsservazioni((String)row.get("OSSERVAZIONI"));
			graduatoria.setPunteggioTitolo((BigDecimal)row.get("PUNTEGGIO_TITOLO"));
			graduatoria.setPunteggioEsperienza((BigDecimal)row.get("PUNTEGGIO_ESPERIENZA"));
			graduatoria.setElaborazione((String)row.get("ELABORAZIONE"));
			graduatoria.setNote((Clob) row.get("NOTE"));
			graduatoria.setPunteggioLaurea((BigDecimal)row.get("PUNTEGGIO_LAUREA"));
			graduatoria.setPunteggioAltraLaurea((BigDecimal)row.get("PUNTEGGIO_ALTRA_LAUREA"));
			graduatoria.setPunteggioAltraLaureaBis((BigDecimal)row.get("PUNTEGGIO_ALTRA_LAUREA_BIS"));
			graduatoria.setPunteggioIdoneita((BigDecimal)row.get("PUNTEGGIO_IDONEITA"));
			graduatoria.setPunteggioAbilitazioneCorsiAggAltriTitoli((BigDecimal)row.get("PUNTEGGIO_ABILITAZIONE"));  //sicuro?
			graduatoria.setPunteggioIdoneitaNazionale((BigDecimal)row.get("PUNTEGGIO_IDONEITA_NAZIONALE"));
			graduatoria.setPunteggioSpecDottBorse((BigDecimal)row.get("PUNTEGGIO_SPEC_DOTT_BORSE"));
			graduatoria.setPunteggioPubblicazione((BigDecimal)row.get("PUNTEGGIO_PUBBLICAZIONE"));
			eta = (BigDecimal) row.get("ETA_MEDIA");
			graduatoria.setEtaMedia(eta);
			graduatoria.setDataNascita((String) row.get("DATA_NASCITA"));
			graduatoria.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
			graduatoria.setCodRegione((String) row.get("COD_REGIONALE"));
			graduatoria.setExAequo((String) row.get("EXAEQUO"));
			graduatoria.setExAequoRisolto((String) row.get("EXAEQUO_RISOLTI"));
			graduatoria.setDataIstruttoria((Timestamp) row.get("DATA_ISTRUTTORIA"));
			graduatoria.setColor((String) row.get("EXAEQUO_COLOR"));
			graduatoria.setIndiceTotale((BigDecimal)row.get("INDICE_TOTALE"));
			graduatoria.setIndiceRelativo((BigDecimal)row.get("INDICE_RELATIVO"));
			graduatoria.setIdInterpello((BigDecimal)row.get("ID_INTERPELLO"));
			graduatoria.setIndiceInterpello((BigDecimal)row.get("INDICE_INTERPELLO"));
			graduatoria.setEscluso((String) row.get("ESCLUSO"));
			graduatoria.setMotivoEsclusione((String) row.get("MOTIVO_ESCLUSIONE"));
			graduatoriaList.add(graduatoria);
			
		}
		
		return graduatoriaList;
		
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findOrderByGraduatoria: errore findByFilter");
		}finally{
			session.close();
			
		}
	}

	
	
	
	
	public int searchCount(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from graduatoria where cod_regionale='"+codReg+"'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			
			
			
			List result = sqlQuery.list();
		
			int nCount = result.size();
			//BigDecimal totalRecords = (BigDecimal)sqlQuery.uniqueResult();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}finally{
			session.close();
		}
		
		
	}

	public int searchCountIndiceTotale(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from graduatoria where cod_regionale='"+codReg+"' and INDICE_TOTALE > 0";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			
			
			
			List result = sqlQuery.list();
		
			int nCount = result.size();
			//BigDecimal totalRecords = (BigDecimal)sqlQuery.uniqueResult();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}finally{
			session.close();
		}
		
		
	}

	public boolean getRettificatiRow(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from graduatoria where cod_regionale='"+codReg+"' and INDICE_TOTALE is null";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			List result = sqlQuery.list();
		
			if (result.size()>0){
		        return true;	
		    } else{
		    	return false;
		    }
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}finally{
			session.close();
		}
		
		
	}

	public int searchCountExaequoRisolto(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from graduatoria where cod_regionale='"+codReg+"' and EXAEQUO_RISOLTI ='F'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			
			
			
			List result = sqlQuery.list();
		
			int nCount = result.size();
			//BigDecimal totalRecords = (BigDecimal)sqlQuery.uniqueResult();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}
		finally{
			session.close();
		}
		
		
	}
	

	public int getPosizioneExsist(String codReg, BigDecimal posizione ) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from graduatoria where cod_regionale='"+codReg+"' and INDICE_TOTALE = "+ posizione + " and EXAEQUO_COLOR<>'red'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
	
			List result = sqlQuery.list();
		
			int nCount = result.size();
			//BigDecimal totalRecords = (BigDecimal)sqlQuery.uniqueResult();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}
		finally{
			session.close();
		}
		
	}
	
	
	public BigDecimal getNuovoIndiceTotale(Graduatoria graduatoria) throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		BigDecimal indice = new BigDecimal(0);
		String punteggio =  graduatoria.getPunteggio().toString();
		try{
		session = HibernateUtil.openSession();
		query = "select indice_totale from graduatoria where punteggio <= "+punteggio+" and eta_media >="+graduatoria.getEtaMediaString()+" cod_regionale ='"+graduatoria.getCodRegione()+"' order by indice_totale ASC,eta_media DESC,cognome ASC,nome ASC"; 
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		List result = sqlQuery.list();
	
			Map row = (Map)result.get(0);
			indice = (BigDecimal) row.get("INDICE_TOTALE");
		
		
		
		return indice;
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
			}
		finally{
			session.close();
		}
	}
	
	public void updateDiUno(BigDecimal indice,String codReg) throws GestioneErroriException{
		//quelli maggiori di indice
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		Transaction trx = null;
		try{
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			query = "update graduatoria set indice_totale =  indice_totale+1 where cod_regionale='"+codReg+"' and indice_totale >='"+indice.toString()+"'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.executeUpdate();
			trx.commit();
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			trx.rollback();
			throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
			
			}
		finally{
			session.close();
			
		}
	}
	
	public void updateDiMenoUno(BigDecimal nuovo,BigDecimal vecchio,String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		Transaction trx = null;
		try{
			
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			query = "update graduatoria set indice_totale =  indice_totale-1 where cod_regionale='"+codReg+"' and indice_totale >='"+vecchio.toString()+"' and indice_totale<='"+nuovo.toString()+"'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.executeUpdate();
			trx.commit();
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			trx.rollback();
			throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
			}
		finally{
			session.close();
		}
	}
	
	//individua i candidati idonei per l'interpello e ne assegna gli indici
	//restituisce la lista degli id candidatura degli idonei
	@SuppressWarnings("unchecked")
	public List<String> aggiornaIndiciInterpello(Session session, String codiceRegione, BigDecimal idInterpello, Integer numeroSedi) throws GestioneErroriException {
		
		try {
			
			Criteria criteria = session.createCriteria(Graduatoria.class);
			//condizioni
			criteria.add(Restrictions.eq("codRegione", codiceRegione));
			
			//considera solo candidature non escluse (flag "escluso" = null o != "true")
			Criterion testNull = Restrictions.isNull("escluso");
			Criterion testNotTrue = Restrictions.ne("escluso", flagValoreVero);
			criteria.add(Restrictions.or(testNull, testNotTrue));
			
			criteria.add(Restrictions.isNull("idInterpello"));
			criteria.setMaxResults(numeroSedi.intValue());
			//ordinamento per posizione in graduatoria del candidato
			criteria.addOrder(Order.asc("indiceTotale"));
			
			List<Graduatoria> results = (List<Graduatoria>) criteria.list();
			
			if(results == null || results.isEmpty())
				return null;
			
			List<String> elencoIdCandidatureIdonee = new ArrayList<String>();
			
			Graduatoria graduatoriaCorrente = null;
			
			for(int i = 0; i < results.size(); i++) {
				
				graduatoriaCorrente = results.get(i);
				
				if(graduatoriaCorrente != null) {
					
					//se la posizione in graduatoria risulta idonea per l'assegnazione di una sede..
					if(i < numeroSedi) {
						
						//imposta indici per il record corrente
						graduatoriaCorrente.setIdInterpello(idInterpello);
						graduatoriaCorrente.setIndiceInterpello(new BigDecimal(i + 1));
						
						elencoIdCandidatureIdonee.add(graduatoriaCorrente.getIdCandidatura());
					}
					//altrimenti se eccede il numero di sedi messe a disposizione per l'interpello..
					//TODO superfluo ---
					else {
						
						//cancella eventuali indici precedentemente inseriti
						graduatoriaCorrente.setIdInterpello(null);
						graduatoriaCorrente.setIndiceInterpello(null);
					}
					//---
					
					session.saveOrUpdate(graduatoriaCorrente);
				}
			}
			
			return elencoIdCandidatureIdonee;
		}
		catch(Exception e) {
			
			log.error("GraduatoriaHome aggiornaIndiciInterpello() failed", e);
			throw new GestioneErroriException("GraduatoriaHome aggiornaIndiciInterpello() failed");
		}
	}
	
	//cancella gli indici interpello eventualmente riportati in graduatoria per la regione specificata
	@SuppressWarnings("unchecked")
	public void cancellaIndiciInterpello(Session session, String codiceRegione, BigDecimal idInterpello) throws GestioneErroriException {
		
		try {
			
			Criteria criteria = session.createCriteria(Graduatoria.class);
			//condizioni
			criteria.add(Restrictions.eq("codRegione", codiceRegione));
			criteria.add(Restrictions.eq("idInterpello", idInterpello));
			List<Graduatoria> results = (List<Graduatoria>) criteria.list();
			
			if(results == null || results.isEmpty())
				return;
			
			Graduatoria graduatoriaCorrente = null;
			
			for(int i = 0; i < results.size(); i++) {
				
				graduatoriaCorrente = results.get(i);
				
				if(graduatoriaCorrente != null) {
					
					graduatoriaCorrente.setIdInterpello(null);
					graduatoriaCorrente.setIndiceInterpello(null);
					
					session.saveOrUpdate(graduatoriaCorrente);
				}
			}
		}
		catch(Exception e) {
			
			log.error("GraduatoriaHome cancellaIndiciInterpello() failed", e);
			throw new GestioneErroriException("GraduatoriaHome cancellaIndiciInterpello() failed");
		}
	}
	
	public String getSequenceIdStorico() throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_STORICO.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			throw new GestioneErroriException("GraduatoriaHome - getSequenceIdStorico: errore getSequenceIdStorico");
		}
		finally{
			session.close();
		}
	}
	
	public List getUtentiByInterpello(String codiceRegione, BigDecimal idInterpello) {
		Session session = HibernateUtil.openSession();
		log.debug("finding Graduatoria - getUtentiByInterpello");
		try {
				session = HibernateUtil.openSession();
				Criteria criteria = session.createCriteria(Graduatoria.class);
				//condizioni
				criteria.add(Restrictions.eq("codRegione", codiceRegione));
				criteria.add(Restrictions.eq("idInterpello", idInterpello));
				//ordinamento
				criteria.addOrder(Order.asc("indiceInterpello"));
				
				List<Graduatoria> results = (List<Graduatoria>) criteria.list();
				
				log.debug("getUtentiByInterpello successful");
				
				if(results == null || results.isEmpty())
					return null;
				
				return results;
		} catch (RuntimeException re) {
			log.error("getUtentiByInterpello failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}
	
	public void escludiCandidato(Graduatoria graduatoria, MailBean mailBean) throws GestioneErroriException {
    	
        Session session = HibernateUtil.openSession(); 
        Transaction trx = session.beginTransaction();       
        java.sql.Connection conn = session.connection();

	        try {
	               //Dichiaro quanto serve per creare ed inviare la mail
	               GestoreMail gestoreMail = new GestoreMail();
	               Object[] indiciMail = new Object[1];
	               
	               //SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail 
	               indiciMail[0] = gestoreMail.saveMail(mailBean, StaticDefinitions.getAppProperties(), conn);
	               //SALVATAGGIO GRADUATORIA
	             
	               //Provo ad inviare la mail 
	               try {
	            	   gestoreMail.sendMail((Integer)indiciMail[0], StaticDefinitions.getAppProperties(), conn);
	               } catch (Throwable thr) {
	            	   log.error("GraduatoriaHome - escludiCandidato : errore nell' invio della mail " + thr.getMessage(), thr);
	               }
	               if(graduatoria!=null) {
	            	   saveOrUpdate(graduatoria, session);
	            	   
	               }
	               trx.commit();
	        } catch (Exception e) {
               log.error("Errore GraduatoriaHome - escludiCandidato" + LogUtil.printException(e));
               trx.rollback();
               throw new GestioneErroriException("GraduatoriaHome - escludiCandidato: errore nell' invio della mail (la mail verr� inviata via batch");
        }
        finally {
        	try{	
         	   conn.commit();
         	   } catch (Exception e) {
                   log.error("Errore GraduatoriaHome - escludiCandidato" + LogUtil.printException(e));
                   throw new GestioneErroriException("GraduatoriaHome - escludiCandidato: errore nell' invio della mail (la mail verr� inviata via batch");
           	   }
               session.close();
        }            
  	}

}
