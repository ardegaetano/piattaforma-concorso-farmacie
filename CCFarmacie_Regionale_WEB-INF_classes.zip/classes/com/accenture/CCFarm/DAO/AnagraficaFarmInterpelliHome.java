package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.HibernateUtil;

public class AnagraficaFarmInterpelliHome {

	private static final Logger log = CommonLogger.getLogger("AnagraficaFarmInterpelliHome");
	
	public void persist(AnagraficaFarmInterpelli transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting AnagraficaFarmInterpelli instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("AnagraficaFarmInterpelliHome - persist: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(AnagraficaFarmInterpelli instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty AnagraficaFarmInterpelli instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("AnagraficaFarmInterpelliHome - saveOrUpdate: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void attachClean(AnagraficaFarmInterpelli instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean AnagraficaFarmInterpelli instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("AnagraficaFarmInterpelliHome - attachClean: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void delete(AnagraficaFarmInterpelli persistentInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting AnagraficaFarmInterpelli instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("AnagraficaFarmInterpelliHome - delete: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public AnagraficaFarmInterpelli merge(AnagraficaFarmInterpelli detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging AnagraficaFarmInterpelli instance");
		try {
			AnagraficaFarmInterpelli result = (AnagraficaFarmInterpelli) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("AnagraficaFarmInterpelliHome - merge: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	@SuppressWarnings("unchecked")
	public List<AnagraficaFarmInterpelli> findByExample(AnagraficaFarmInterpelli instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding AnagraficaFarmInterpelli instance by example");
		try {
			List<AnagraficaFarmInterpelli> results = (List<AnagraficaFarmInterpelli>) session
					.createCriteria("com.accenture.CCFarm.DAO.AnagraficaFarmInterpelli")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("AnagraficaFarmInterpelliHome - findByExample: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	//replica l'anagrafica delle sedi registrate per una data regione, associandola ad un determinato interpello
	@SuppressWarnings("unchecked")
	public int memorizzaSediPerInterpello(Session session, String codiceRegione, BigDecimal idInterpello) throws GestioneErroriException {
		
		try {
			
			//cancella dati precedenti (se presenti) 
			//TODO superfluo ---
			eliminaSediPerInterpello(session, codiceRegione, idInterpello);
			//---
			
			//recupera le sedi registrate al momento per la regione specificata
			Criteria criteria = session.createCriteria(AnagraficaFarm.class);
			//condizioni
			criteria.add(Restrictions.eq("codRegFarm", codiceRegione));
			List<AnagraficaFarm> sediPerRegione = (List<AnagraficaFarm>) criteria.list();
			
			if(sediPerRegione == null || sediPerRegione.isEmpty()) {
				return 0;
			}
			
			//riporta le sedi trovate sulla tabella sedi interpello, assegnando il progressivo specificato
			AnagraficaFarmInterpelli sedeInterpello = null;
			for(AnagraficaFarm sede : sediPerRegione) {
				
				if(sede != null) {
					
					sedeInterpello = new AnagraficaFarmInterpelli(
							new AnagraficaFarmInterpelliId(codiceRegione, idInterpello, sede.getIdFarm())
					);
					
					PropertyUtils.copyProperties(sedeInterpello, sede);
					sedeInterpello.setLastUpdateDateFarm(DateUtil.getCurrentTimestamp());
					session.saveOrUpdate(sedeInterpello);
				}
			}
			
			return sediPerRegione.size();
		}
		catch(Exception e) {
			
			log.error("AnagraficaFarmInterpelliHome memorizzaSediPerInterpello failed : "+ e.getMessage(), e);
			throw new GestioneErroriException("AnagraficaFarmInterpelliHome memorizzaSediPerInterpello: " + e);
		}
	}
	
	//elimina l'anagrafica sedi registrata per un determinato interpello (ritorna il numero di sedi eliminate)
	public int eliminaSediPerInterpello(Session session, String codiceRegione, BigDecimal idInterpello) throws GestioneErroriException {
		
		try {
			
			//cancella dati precedenti (se presenti)
			String hqlDeleteString = "DELETE AnagraficaFarmInterpelli as afi"
								   + " WHERE afi.id.codRegFarm = :codiceRegione"
								   + " AND afi.id.idInterpello = :idInterpello";
			
			Query deleteQuery = session.createQuery(hqlDeleteString);
			deleteQuery.setParameter("codiceRegione", codiceRegione);
			deleteQuery.setParameter("idInterpello", idInterpello);
			return deleteQuery.executeUpdate();
		}
		catch(Exception e) {
			
			log.error("AnagraficaFarmInterpelliHome eliminaSediPerInterpello failed : "+ e.getMessage(), e);
			throw new GestioneErroriException("AnagraficaFarmInterpelliHome eliminaSediPerInterpello: " + e);
		}
	}
	
	//ritorna il numero di record in anagrafica associati alla coppia <regione, id interpello> specificata
	@SuppressWarnings("rawtypes")
	public Integer numeroSediPerInterpello(Session session, String codiceRegione, BigDecimal idInterpello) throws GestioneErroriException {
		
		try {
			
			Criteria criteria = session.createCriteria(AnagraficaFarmInterpelli.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codRegFarm", codiceRegione));
			criteria.add(Restrictions.eq("id.idInterpello", idInterpello));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.rowCount());
			criteria = criteria.setProjection(projectionList);
			List results = criteria.list();
			
			if(results == null || results.isEmpty() || results.get(0) == null)
				return null;
			
			return (Integer) results.get(0);
		}
		catch(Exception e) {
			
			log.error("AnagraficaFarmInterpelliHome numeroSediPerInterpello failed : "+ e.getMessage(), e);
			throw new GestioneErroriException("AnagraficaFarmInterpelliHome numeroSediPerInterpello: " + e);
		}
	}
	
	public List<AnagraficaFarmInterpelli> getSediByInterpello(String codiceRegione, BigDecimal idInterpello) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding getSediByInterpello instance by example");
		try {
			Criteria criteria = session.createCriteria(AnagraficaFarmInterpelli.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codRegFarm", codiceRegione));
			criteria.add(Restrictions.eq("id.idInterpello", idInterpello));
			List<AnagraficaFarmInterpelli> results = criteria.list();
			
			log.debug("find getSediByInterpello successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find getSediByInterpello failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("AnagraficaFarmInterpelliHome - findByExample: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	public String getNSediNonAssegnate(String codReg, BigDecimal idInterpello) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT COUNT(A.ID_FARM) "+
				" FROM ANAGRAFICA_FARM_INTERPELLI A"+
				" WHERE A.COD_REG_FARM = '"+codReg+"' AND A.ID_INTERPELLO = "+idInterpello+
				" AND A.ID_FARM NOT IN(SELECT AF.ID_FARM"+
					" FROM GRADUATORIA G, Anagrafica_Farm_Interpelli af, Candidatura_Sedi cs"+
					" WHERE G.COD_REGIONALE = '"+codReg+"'"+
					" AND G.ID_INTERPELLO = "+idInterpello+
					" AND G.ID_CANDIDATURA = cs.id_Candidatura AND cs.flag_Confermata = 'true'"+
					" AND g.cod_Regionale = af.cod_Reg_Farm AND g.id_Interpello = af.id_Interpello"+
					" AND AF.ID_FARM = CS.ID_FARM)").list();
			BigDecimal num = (BigDecimal)query.get(0);
			return ""+num;
		} catch (RuntimeException re) {
			throw new GestioneErroriException("AnagraficaFarmInterpelliHome - getNSediNonAssegnate: errore");
		}
		finally{
			session.close();
		}
	}
	
	public List<AnagraficaFarmInterpelli> getSediNonAssegnate(String codReg, BigDecimal idInterpello) throws GestioneErroriException {
		if(codReg == null || idInterpello == null)
			return null;
		
		Session session = null;
		try {
			session = HibernateUtil.openSession();
			
			String hqlSelectString = "SELECT A.PRV_FARM as codIstatProv, "+
			" A.DESCR_PRV_FARM as desProv, "+
			" A.COMUNE_FARM as codIstatComu, "+
			" A.FRAZIONE_FARM as desComu, "+
			" A.N_PROGRESSIVO as nProgCom, "+
			" A.DESCRIZIONE_SEDE as desSede, "+		//CLOB
			" A.DESCRIZIONE_SEDE_DE as desSedeDe, "+ //CLOB
			" A.COD_TIPO_SEDE as tipoSede, "+
			" A.CRITERIO_TOPO_FARM as critTopo, "+
			" A.INDENNITA_AVV as indennitaAvviamento "+
				" FROM ANAGRAFICA_FARM_INTERPELLI A"+
				" WHERE A.COD_REG_FARM = '"+codReg+"' AND A.ID_INTERPELLO = "+idInterpello+
				" AND A.ID_FARM NOT IN(SELECT AF.ID_FARM"+
					" FROM GRADUATORIA G, Anagrafica_Farm_Interpelli af, Candidatura_Sedi cs"+
					" WHERE G.COD_REGIONALE = '"+codReg+"'"+
					" AND G.ID_INTERPELLO = "+idInterpello+
					" AND G.ID_CANDIDATURA = cs.id_Candidatura AND cs.flag_Confermata = 'true'"+
					" AND g.cod_Regionale = af.cod_Reg_Farm AND g.id_Interpello = af.id_Interpello"+
					" AND AF.ID_FARM = CS.ID_FARM)";
			
			List<AnagraficaFarmInterpelli> results = session.createSQLQuery(hqlSelectString).list();
			log.debug("find getSediNonAssegnate successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find getSediNonAssegnate failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("AnagraficaFarmInterpelliHome - getSediNonAssegnate: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
		
	}
	
	
}
