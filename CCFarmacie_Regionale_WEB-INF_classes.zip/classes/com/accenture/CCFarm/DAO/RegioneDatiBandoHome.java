package com.accenture.CCFarm.DAO;

//Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.utility.HibernateUtil;

/**
* Home object for domain model class RegioneDatiBando.
* @see com.accenture.CCFarm.DAO.RegioneDatiBando
* @author Hibernate Tools
*/
public class RegioneDatiBandoHome {

	private static final Log log = LogFactory.getLog(RegioneDatiBandoHome.class);
	
	public void persist(RegioneDatiBando transientInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("persisting RegioneDatiBando instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(RegioneDatiBando instance) {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty RegioneDatiBando instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public void attachClean(RegioneDatiBando instance) {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean RegioneDatiBando instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public void delete(RegioneDatiBando persistentInstance) {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting RegioneDatiBando instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public RegioneDatiBando merge(RegioneDatiBando detachedInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("merging RegioneDatiBando instance");
		try {
			RegioneDatiBando result = (RegioneDatiBando) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public RegioneDatiBando findById(java.lang.String id) {
		Session session = HibernateUtil.openSession();
		log.debug("getting RegioneDatiBando instance with id: " + id);
		try {
			RegioneDatiBando instance = (RegioneDatiBando) session.get("com.accenture.CCFarm.DAO.RegioneDatiBando", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}

	public List findByExample(RegioneDatiBando instance) {
		Session session = HibernateUtil.openSession();
		log.debug("finding RegioneDatiBando instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.RegioneDatiBando")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			
			return results;
			
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
		finally{
			session.close();
		}
	}
}
