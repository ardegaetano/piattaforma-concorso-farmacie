package com.accenture.CCFarm.DAO;

import java.io.Serializable;
import java.math.BigDecimal;


public class CandidaturaSedi implements Serializable
{
	private CandidaturaSediId id;
	private BigDecimal ordineScelta;
	private String flagAssociata;
	private String flagConfermata;
	private Serializable excludedDate;
	//EXCLUDED_DATE
	
	public CandidaturaSedi() {
		
	}
	
	public CandidaturaSedi(CandidaturaSediId id) {
		
		this.id = id;
	}

	public CandidaturaSediId getId() {
		return id;
	}

	public void setId(CandidaturaSediId id) {
		this.id = id;
	}

	public BigDecimal getOrdineScelta() {
		return ordineScelta;
	}

	public void setOrdineScelta(BigDecimal ordineScelta) {
		this.ordineScelta = ordineScelta;
	}

	public String getFlagAssociata() {
		return flagAssociata;
	}

	public void setFlagAssociata(String flagAssociata) {
		this.flagAssociata = flagAssociata;
	}

	public String getFlagConfermata() {
		return flagConfermata;
	}

	public void setFlagConfermata(String flagConfermata) {
		this.flagConfermata = flagConfermata;
	}

	public Serializable getExcludedDate() {
		return excludedDate;
	}

	public void setExcludedDate(Serializable excludedDate) {
		this.excludedDate = excludedDate;
	}
	
}
