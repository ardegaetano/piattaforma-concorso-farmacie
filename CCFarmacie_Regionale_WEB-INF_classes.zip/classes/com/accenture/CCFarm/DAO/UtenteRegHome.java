package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Bean.UtenteBean;
import com.accenture.CCFarm.Bean.UtenteCandidatureBean;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.RicercaCandidati;
import com.accenture.CCFarm.pageBean.RicercaSchedeValutazione;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.OsservazioniUtiliy;
import com.accenture.CCFarm.utility.RecuperaProtocollo;
import com.accenture.CCFarm.utility.StringUtil;

/**
 * Home object for domain model class Utente.
 * @see com.accenture.CCFarm.DAO.UtenteReg
 * @author Hibernate Tools
 */
public class UtenteRegHome {

	private static final Logger log = CommonLogger.getLogger("UtenteHome");

	public UtenteReg findById(java.lang.String id) throws GestioneErroriException{
		Session session = null;
		log.debug("getting Utente instance with id: " + id);
		try {
			session = HibernateUtil.openSession();
			UtenteReg instance = (UtenteReg) session.get("com.accenture.CCFarm.DAO.UtenteReg", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("UtenteHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}
	public List<UtenteReg> findByElencoCandidati(String idRegione) throws GestioneErroriException{
		Session session = null;
		log.debug("finding Utente instance by example");
		try {
			session = HibernateUtil.openSession();
//			List<Utente> results =  (List<Utente>) session.createQuery("").setString("codRegUtente", idRegione).list();
			//Query query = session.createQuery("from Utente where codRegUtente='010'");
			StringBuffer sb=new StringBuffer();
			
//			sb.append("SELECT ,, , ,U.PRV_NASCITA_UTENTE, U.LUOGO_NASCITA_ESTERA" +
					
//campi                           0                1              2                     3                        4                     5                             6  			    7
			sb.append("SELECT U.ID_UTENTE,  upper(trim(U.COGNOME_UTENTE)), upper(trim(U.NOME_UTENTE)),  upper(trim(U.CODICE_FISCALE_UTENTE)) , U.DATA_NASCITA_UTENTE, U.LUOGO_NASCITA_UTENTE , U.LUOGO_NASCITA_ESTERA, U.PRV_NASCITA_UTENTE " +
					 " FROM UTENTE_REG U, CANDIDATURA_REG  C  " +
					 " WHERE U.COD_REG_UTENTE = '"+idRegione+"'" +
					 " AND U.ID_UTENTE = C.id_utente " +
					 " AND C.AMMESSO = 'SI' " +
					 " ORDER BY upper(trim(U.COGNOME_UTENTE)), upper(trim(U.NOME_UTENTE))" );
							
			//query.setString("codRegUtente", idRegione);
			List results = session.createSQLQuery(sb.toString()).list();
			List<UtenteReg> listUtenti= new ArrayList<UtenteReg>();
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				UtenteReg utente=new UtenteReg();
				Object[] row = (Object[]) iterator.next(); 
				utente.setCognomeUtente((String)row[1]);
				utente.setNomeUtente((String)row[2]);
				utente.setCodiceFiscaleUtente((String)row[3]);
				if (utente.getCodiceFiscaleUtente().contains("*")){
					utente.setCodiceFiscaleUtente("");
				}
//				utente.setDataNascitaUtente(DateUtil.sqlDateToUtilDate((Date) row[4]));
				utente.setDataNascitaUtente(((Timestamp) row[4]));
			
				String comuneDNascita = Localita.getDenominazioneComune((String)row[5]);
				String luogoEstero =  (String)row[6];
				String luogoDiNascita= "";
				if (luogoEstero!=null && !luogoEstero.equals("")){
					luogoDiNascita = "Localit� Estera ( "+ luogoEstero + " )";
				} else{
					luogoDiNascita= comuneDNascita + " ("+Localita.getDenominazioneSiglaProvincia((String)row[7])+")";
				}
				utente.setLuogoNascitaUtente(luogoDiNascita);

				listUtenti.add(utente);
		}
			
			return listUtenti;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("UtenteHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	public List findByExample(UtenteReg instance) throws GestioneErroriException{
		Session session = null;
		log.debug("finding Utente instance by example");
		try {
			session = HibernateUtil.openSession();
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.UtenteReg")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("UtenteHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	
	

	
	
	public List<UtenteBean> findByFilter(RicercaCandidati instance) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<UtenteBean> listaCandidature=new ArrayList<UtenteBean>();
	
		try {
			
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			sb.append("SELECT U.NOME_UTENTE, U.COGNOME_UTENTE, U.DATA_NASCITA_UTENTE, U.LUOGO_NASCITA_UTENTE,U.PRV_NASCITA_UTENTE, U.LUOGO_NASCITA_ESTERA, U.CODICE_FISCALE_UTENTE , C.COD_REG_UTENTE, U.ID_UTENTE" +
					" FROM UTENTE_REG U," +
					"  (SELECT B.NOME_UTENTE, B.COGNOME_UTENTE,  B.CODICE_FISCALE_UTENTE, B.COD_REG_UTENTE" +
					"  FROM UTENTE_REG B" +
					"    WHERE B.COD_REG_UTENTE <>'"+instance.getCodReg()+"' ) C " +
					"WHERE U.COD_REG_UTENTE = '"+instance.getCodReg()+"'" +
					"  AND U.CODICE_FISCALE_UTENTE  = C.CODICE_FISCALE_UTENTE(+) ");
						
			if(instance.getNomeRicerca()!=null&&!instance.getNomeRicerca().equals("")){
			  sb.append("   AND U.NOME_UTENTE =");
			  sb.append("'"+instance.getNomeRicerca()+"'");
			}
			if(instance.getCognomeRicerca()!=null&&!instance.getCognomeRicerca().equals("")){
				  sb.append(" AND U.COGNOME_UTENTE=");
				  sb.append("'"+instance.getCognomeRicerca()+"'");
			}
			if(instance.getCodiceFiscaleRicerca()!=null&&!instance.getCodiceFiscaleRicerca().equals("")){
				  sb.append(" AND U.CODICE_FISCALE_UTENTE=");
				  sb.append("'"+instance.getCodiceFiscaleRicerca()+"'");
			}
			
			sb.append(" ORDER BY U.COGNOME_UTENTE, U.NOME_UTENTE");
		    
			List results = session.createSQLQuery(sb.toString()).list();
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			UtenteBean utenteSelezionato = null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				utenteSelezionato=new UtenteBean();
				Object[] row = (Object[]) iterator.next(); 
				utenteSelezionato.setNomeUtente((String)row[0]);
				utenteSelezionato.setCognomeUtente((String)row[1]);
				utenteSelezionato.setDataNascita((Timestamp) row[2]);
				utenteSelezionato.setLuogoNascitaUtente(Localita.getDenominazioneComune((String)row[3]));
				utenteSelezionato.setProvinciaNascitaUtente(Localita.getDenominazioneProvincia((String)row[4]));
				utenteSelezionato.setLuogoNascitaEsteraUtente((String)row[5]);
				utenteSelezionato.setCodiceFiscaleUtente((String)row[6]);
				utenteSelezionato.setRegioneRichiesta(Localita.getDenominazioneRegione((String)row[7]));
				utenteSelezionato.setIdUtente((String)row[8]);
				
								
				listaCandidature.add(utenteSelezionato);
		}
			
			return listaCandidature;
			
		} catch (RuntimeException re) {
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}
		finally{
			session.close();
		}
	
	}
	
	public List<UtenteCandidatureBean> findByFilterCandidatura(RicercaCandidati instance) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<UtenteCandidatureBean> listaCandidature=new ArrayList<UtenteCandidatureBean>();
	
		try {
			
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			
//	campi	                        0              1               2                        3                          4                 5                       6                           7              8                 9              10                11                  
			sb.append("SELECT U.NOME_UTENTE, U.COGNOME_UTENTE, U.DATA_NASCITA_UTENTE, U.LUOGO_NASCITA_UTENTE, U.PRV_NASCITA_UTENTE, U.LUOGO_NASCITA_ESTERA, U.CODICE_FISCALE_UTENTE , C.COD_REG_UTENTE, U.ID_UTENTE, CD.ID_CANDIDATURA , CD.AMMESSO, U.DATA_RILASCIO_DOC " +
					" FROM UTENTE_REG U,  CANDIDATURA_REG CD, " +
					"  (SELECT B.NOME_UTENTE, B.COGNOME_UTENTE,  B.CODICE_FISCALE_UTENTE, B.COD_REG_UTENTE" +
					"  FROM UTENTE_REG B,  CANDIDATURA_REG CDD  " +
					"    WHERE B.COD_REG_UTENTE <>'"+instance.getCodReg()+"' AND B.ID_UTENTE = CDD.id_utente  ) C " +
					"WHERE U.COD_REG_UTENTE = '"+instance.getCodReg()+"'" +
					"  AND U.ID_UTENTE = CD.id_utente "+
					"  AND U.CODICE_FISCALE_UTENTE  = C.CODICE_FISCALE_UTENTE(+) ");
				
			if(instance.getNomeRicerca()!=null&&!instance.getNomeRicerca().equals("")){
//				sb.append("   AND U.NOME_UTENTE =");
				sb.append("   AND UPPER(U.NOME_UTENTE) LIKE");
				sb.append(" '"+instance.getNomeRicerca().toUpperCase().trim()+"%'");
			}
			if(instance.getCognomeRicerca()!=null&&!instance.getCognomeRicerca().equals("")){
//				UPPER(COGNOME_UTENTE) LIKE '%GIORDANO%'  
				sb.append(" AND UPPER(U.COGNOME_UTENTE) LIKE");
				sb.append("'"+instance.getCognomeRicerca().toUpperCase().trim()+"%'");
			}
			if(instance.getCodiceFiscaleRicerca()!=null&&!instance.getCodiceFiscaleRicerca().equals("")){
				  sb.append(" AND UPPER(U.CODICE_FISCALE_UTENTE) =");
				  sb.append(" '"+instance.getCodiceFiscaleRicerca().toUpperCase().trim()+"'");
			}
			
			if(instance.getAmmessoSelezionato()!=null&&!instance.getAmmessoSelezionato().equals("-1")&&!instance.getAmmessoSelezionato().equals("") ){
				  sb.append(" AND  CD.AMMESSO=");
				  sb.append("'"+instance.getAmmessoSelezionato()+"'");
			}
			
//			filtro protocollo si sposta dentro il ciclo
			if(instance.getRegioneSelezionata()!=null&&!instance.getRegioneSelezionata().equals("-1")&&!instance.getRegioneSelezionata().equals("") ){
				  sb.append(" AND  C.COD_REG_UTENTE =");
				  sb.append("'"+instance.getRegioneSelezionata()+"'");
			}
			
			
			sb.append(" ORDER BY U.COGNOME_UTENTE, U.NOME_UTENTE");
		    
			List results = session.createSQLQuery(sb.toString()).list();
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			UtenteCandidatureBean utenteSelezionato = null;
			CandidaturaRegHome candidaturaRegHome= new CandidaturaRegHome();
			HashMap candidatoElaborato = new HashMap();
			RecuperaProtocollo recuperaProtocollo= new RecuperaProtocollo();
			OsservazioniUtiliy osservazioniUtiliy = new OsservazioniUtiliy();
//			UtenteHome utenteHome = new UtenteHome();
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				utenteSelezionato=new UtenteCandidatureBean();
				Object[] row = (Object[]) iterator.next(); 
				
				utenteSelezionato.setIdUtente((String)row[8]);
//				filtro per protocollo
				
				boolean filtroOk = true;
				//il campo filtroOk pu� essere a true quando il filto non � stato richiesto e se richiesto il protocollo � stato trovato.

				String protocollo=null;
//				recupero protocollo da ricevuta
				protocollo = recuperaProtocollo.getProtocolloRegionale(utenteSelezionato.getIdUtente());
			    if (protocollo==null) protocollo="";
			    utenteSelezionato.setProtocolloRicevuta(protocollo);
			    if (protocollo.equals("")){
			    	utenteSelezionato.setScaricaRicevuta("true");
			    } else {
			    	utenteSelezionato.setScaricaRicevuta("false");
			    }
//	protocollo richiesto come filtro e non trovato 
				if(instance.getProtocollo()!=null&&!instance.getProtocollo().equals("") ){
//					if (!instance.getProtocollo().equals(protocollo)){
//						filtroOk =  false;
//					}
					if (!protocollo.toUpperCase().contains(instance.getProtocollo().toUpperCase().trim())) {
//					if (!instance.getProtocollo().toUpperCase().contains(protocollo.toUpperCase())){
						filtroOk =  false;
					}
				}
//	filtro per osservazioni
				if (!instance.getOsservazioniSelezionato().equals("-1")){
					if (instance.getOsservazioniSelezionato().equals("1")){
						filtroOk = osservazioniUtiliy.isOssProvIscAlbo(utenteSelezionato.getIdUtente());
					} else{
						if (instance.getOsservazioniSelezionato().equals("2")){
							filtroOk = osservazioniUtiliy.isOssDAlboDAbil(utenteSelezionato.getIdUtente());
						} else{
							if (instance.getOsservazioniSelezionato().equals("3")){
								filtroOk = osservazioniUtiliy.isOssDDocDNasc(StringUtil.dateToStringDDMMYYYY((Timestamp) row[2]), 
																			 StringUtil.dateToStringDDMMYYYY((Timestamp) row[11]));
							} 
						}
					}
					
				}
		      
				if (filtroOk){
					String altraRegioneConcorso = Localita.getDenominazioneRegione((String)row[7]);
	//		verifico candidatura		
					CandidaturaReg candidaturaReg = new CandidaturaReg();
					candidaturaReg = candidaturaRegHome.findById(utenteSelezionato.getIdUtente());
					boolean aggiungiCandidato = false;
					if(candidaturaReg.getModalitaCandidatura().equalsIgnoreCase("S")){
	//			Singola
						utenteSelezionato.setNomeUtente((String)row[0]);
						utenteSelezionato.setCognomeUtente((String)row[1]);
						utenteSelezionato.setDataNascita((Timestamp) row[2]);
						utenteSelezionato.setLuogoNascitaUtente(Localita.getDenominazioneComune((String)row[3]));
						utenteSelezionato.setProvinciaNascitaUtente(Localita.getDenominazioneSiglaProvincia((String)row[4]));
						utenteSelezionato.setLuogoNascitaEsteraUtente((String)row[5]);
						utenteSelezionato.setCodiceFiscaleUtente((String)row[6]);
						if (utenteSelezionato.getCodiceFiscaleUtente().contains("*")){
							utenteSelezionato.setCodiceFiscaleUtente("");
						}
						utenteSelezionato.setRegioneRichiesta(altraRegioneConcorso);
						utenteSelezionato.setIdUtente((String)row[8]);
						utenteSelezionato.setIdCandidatura((String)row[9]);
						utenteSelezionato.setAmmessoValore((String)row[10]);
						if (utenteSelezionato.getAmmessoValore().equalsIgnoreCase("SI")){
							utenteSelezionato.setAmmesso(true);
						} else {
							utenteSelezionato.setAmmesso(false);
						}
						utenteSelezionato.setAssociata("false");
						utenteSelezionato.setListaAssociati(new ArrayList<UtenteBean>());
						utenteSelezionato.setTipoCandidato("Singolo");
						aggiungiCandidato = true;
					} else{
	//			Associata
						if (!candidatoElaborato.containsKey(candidaturaReg.getIdCandidatura())){
							aggiungiCandidato = true;
							candidatoElaborato.put(candidaturaReg.getIdCandidatura(), new String(" "));
							List<CandidaturaReg> listCandi = new ArrayList<CandidaturaReg>();
							CandidaturaReg candFind= new CandidaturaReg();
	//						carico la scquadra associata	
							candFind.setIdCandidatura(candidaturaReg.getIdCandidatura());
							listCandi = candidaturaRegHome.findByExample(candFind);
							List<UtenteBean> listAss = new ArrayList<UtenteBean>();
							for (int i = 0; i < listCandi.size(); i++) {
								CandidaturaReg cand= new CandidaturaReg();
								cand = listCandi.get(i);
								UtenteReg utente = new UtenteReg();
	//							utente = utenteHome.findById(cand.getIdUtente());
								utente = this.findById(cand.getIdUtente());
								if (cand.getReferenteDomanda()!=null && cand.getReferenteDomanda().equalsIgnoreCase("Y")){
	//sovrascrivo informazione dell'utente Referente								
									utenteSelezionato.setIdUtente(utente.getIdUtente());
									utenteSelezionato.setIdCandidatura(cand.getIdCandidatura());
									utenteSelezionato.setNomeUtente(utente.getNomeUtente());
									utenteSelezionato.setCognomeUtente(utente.getCognomeUtente());
									utenteSelezionato.setDataNascita(utente.getDataNascitaUtente());
									utenteSelezionato.setLuogoNascitaUtente(Localita.getDenominazioneComune(utente.getLuogoNascitaUtente()));
									utenteSelezionato.setProvinciaNascitaUtente(Localita.getDenominazioneSiglaProvincia(utente.getPrvNascitaUtente()));
									utenteSelezionato.setLuogoNascitaEsteraUtente(utente.getLuogoNascitaEstera());
									utenteSelezionato.setCodiceFiscaleUtente(utente.getCodiceFiscaleUtente());
									if (utenteSelezionato.getCodiceFiscaleUtente().contains("*")){
										utenteSelezionato.setCodiceFiscaleUtente("");
									}
									utenteSelezionato.setRegioneRichiesta(altraRegioneConcorso);
									utenteSelezionato.setTipoCandidato("Referente");
									utenteSelezionato.setAmmessoValore(cand.getAmmesso());
									if (utenteSelezionato.getAmmessoValore().equalsIgnoreCase("SI")){
										utenteSelezionato.setAmmesso(true);
									} else {
										utenteSelezionato.setAmmesso(false);
									}
								} else{
	// carico i dati dell'associato al referente
									UtenteBean utenteBean = new UtenteBean();
									utenteBean.setIdUtente(utente.getIdUtente());
									utenteBean.setIdCandidatura(cand.getIdCandidatura());
									utenteBean.setNomeUtente(utente.getNomeUtente());
									utenteBean.setCognomeUtente(utente.getCognomeUtente());
									utenteBean.setDataNascita(utente.getDataNascitaUtente());
									utenteBean.setLuogoNascitaUtente(Localita.getDenominazioneComune(utente.getLuogoNascitaUtente()));
									utenteBean.setProvinciaNascitaUtente(Localita.getDenominazioneSiglaProvincia(utente.getPrvNascitaUtente()));
									utenteBean.setLuogoNascitaEsteraUtente(utente.getLuogoNascitaEstera());
									utenteBean.setCodiceFiscaleUtente(utente.getCodiceFiscaleUtente());
									if (utenteBean.getCodiceFiscaleUtente().contains("*")){
										utenteBean.setCodiceFiscaleUtente("");
									}
									utenteBean.setRegioneRichiesta(altraRegioneConcorso);
									utenteBean.setTipoCandidato("Associato");
								    listAss.add(utenteBean);
								}
								utenteSelezionato.setAssociata("true");
								
							}
							utenteSelezionato.setListaAssociati(listAss);
						}
					}
					
					if (aggiungiCandidato)				
						listaCandidature.add(utenteSelezionato);
				}
		}
			
			return listaCandidature;
			
		} catch (RuntimeException re) {
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}finally{
			session.close();
		}
	
	}
	
	public List<String> findByFilterCandidaturaPaginataID(RicercaCandidati instance) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
//		List<UtenteCandidatureBean> listaCandidature=new ArrayList<UtenteCandidatureBean>();
		List<String> listaIDCandidature=new ArrayList<String>();
		
		try {
			
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			
//	campi	                        0                     1                             2                        3                          4                 5                       6                           7              8                 9              10                11                  
			sb.append("SELECT U.ID_UTENTE,   upper(trim(U.NOME_UTENTE)), upper(trim(U.COGNOME_UTENTE)),  U.DATA_NASCITA_UTENTE , U.DATA_RILASCIO_DOC " +
                    ",D.DOC_PERVENUTA " +
                    ",UT.PEC_CAMBIATA" +
					" FROM UTENTE_REG U,  CANDIDATURA_REG CD,   RICEVUTE  R, REQUISITI_MINIMI_REG RM, " +
					"DICHIARAZIONE_SOSTITUTIVA_REG D, " +
					"UTENTE UT," +
					"  (SELECT B.NOME_UTENTE, B.COGNOME_UTENTE,  B.CODICE_FISCALE_UTENTE, B.COD_REG_UTENTE" +
					"  FROM UTENTE_REG B,  CANDIDATURA_REG CDD  " +
					"    WHERE B.COD_REG_UTENTE <>'"+instance.getCodReg()+"' AND B.ID_UTENTE = CDD.id_utente  ) C " +
					"WHERE U.COD_REG_UTENTE = '"+instance.getCodReg()+"'" +
					"  AND U.ID_UTENTE = CD.id_utente "+
					"  AND U.CODICE_FISCALE_UTENTE  = C.CODICE_FISCALE_UTENTE(+) " +
					"  AND CD.ID_CANDIDATURA = R.ID_CANDIDATURA(+) " +
					"  AND U.ID_UTENTE = D.ID_DOMANDA_DIC  " +
					"  AND U.ID_UTENTE = UT.ID_UTENTE  " +
					"  AND R.TIPO_RICEVUTA = 'DD'" +
					"  AND U.ID_UTENTE = RM.ID_DOMANDA_REQ  ");
					
				
			if(instance.getNomeRicerca()!=null&&!instance.getNomeRicerca().equals("")){
//				sb.append("   AND U.NOME_UTENTE =");
				sb.append("   AND UPPER(trim(U.NOME_UTENTE)) LIKE");
				sb.append(" '"+instance.getNomeRicerca().replace("'", "''").toUpperCase().trim()+"%'");
			}
			if(instance.getCognomeRicerca()!=null&&!instance.getCognomeRicerca().equals("")){
//				UPPER(COGNOME_UTENTE) LIKE '%GIORDANO%'  
				sb.append(" AND UPPER(trim(U.COGNOME_UTENTE)) LIKE");
//				instance.setCognomeRicerca(instance.getCognomeRicerca().replace("'", "''"));
				sb.append("'"+instance.getCognomeRicerca().replace("'", "''").toUpperCase().trim()+"%'");
			}
			if(instance.getCodiceFiscaleRicerca()!=null&&!instance.getCodiceFiscaleRicerca().equals("")){
				  sb.append(" AND UPPER(trim(U.CODICE_FISCALE_UTENTE)) =");
				  sb.append(" '"+instance.getCodiceFiscaleRicerca().replace("'", "''").toUpperCase().trim()+"'");
			}
			
			if(instance.getAmmessoSelezionato()!=null&&!instance.getAmmessoSelezionato().equals("-1")&&!instance.getAmmessoSelezionato().equals("") ){
				  sb.append(" AND  CD.AMMESSO=");
				  sb.append("'"+instance.getAmmessoSelezionato()+"'");
			}
			
			if(instance.getRegioneSelezionata()!=null&&!instance.getRegioneSelezionata().equals("-1")&&!instance.getRegioneSelezionata().equals("") ){
				  sb.append(" AND  C.COD_REG_UTENTE =");
				  sb.append("'"+instance.getRegioneSelezionata()+"'");
			}
			
//			if(instance.getDocumentazionePervenuta()!=null && !instance.getDocumentazionePervenuta().equals("-1") ){
//				if (instance.getDocumentazionePervenuta().equalsIgnoreCase("SI")){
//					sb.append(" AND ( D.DOC_PERVENUTA is null OR D.DOC_PERVENUTA = 'true' )");
//				} else if (instance.getDocumentazionePervenuta().equalsIgnoreCase("NO")){
//					sb.append(" AND D.DOC_PERVENUTA = 'false'");
//				}
//			}
			
			if(instance.getDocumentazionePrevista()!=null && !instance.getDocumentazionePrevista().equals("-1") ){
				if (instance.getDocumentazionePrevista().equalsIgnoreCase("NO")){
					sb.append(" AND ( D.FLAG_CONF_DOC_DIC is null OR D.FLAG_CONF_DOC_DIC = 'false' )");
				} else if (instance.getDocumentazionePrevista().equalsIgnoreCase("SI")){
					sb.append(" AND D.FLAG_CONF_DOC_DIC = 'true'");
				}
			}
			
			if(instance.getDocumentazionePervenuta()!=null && !instance.getDocumentazionePervenuta().equals("-1") ){
				if (instance.getDocumentazionePervenuta().equalsIgnoreCase("NO")){
					sb.append(" AND ( D.DOC_PERVENUTA is null OR D.DOC_PERVENUTA = 'false' )");
				} else if (instance.getDocumentazionePervenuta().equalsIgnoreCase("SI")){
					sb.append(" AND D.DOC_PERVENUTA = 'true'");
				}
			}
			
			if(instance.getRichiestaCambioPEC()!=null && !instance.getRichiestaCambioPEC().equals("-1") ){
				if (instance.getRichiestaCambioPEC().equalsIgnoreCase("NO")){
					sb.append(" AND ( UT.PEC_CAMBIATA is null OR UT.PEC_CAMBIATA = '' )");
				} else if (instance.getRichiestaCambioPEC().equalsIgnoreCase("SI")){
					sb.append(" AND UT.PEC_CAMBIATA = 'Y'");
				}
			}

//			filtro protocollo si sposta dentro il ciclo
			if(instance.getProtocollo()!=null && !instance.getProtocollo().equals("") ){
				sb.append(" AND R.ID_RICEVUTA  LIKE  ");
				String protocollo="";
				if (instance.getProtocollo().length()>6){
					protocollo= instance.getProtocollo().substring(0, 6);
				} else{
					protocollo= instance.getProtocollo().trim();
				}
				sb.append("'"+protocollo.replace("'", "''").trim()+"%'");
			}			

//	filtro per osservazioni
			if (instance.getOsservazioniSelezionato()!=null &&!instance.getOsservazioniSelezionato().equals("-1")){
				if (instance.getOsservazioniSelezionato().equals("1")){
					sb.append(" AND RM.PRV_ATTUALE_ALBO IS NULL ");
				} else{
					if (instance.getOsservazioniSelezionato().equals("2")){
						sb.append(" AND TO_NUMBER(TO_CHAR(RM.DATA_ALBO,'YYYY')) < TO_NUMBER(RM.ANNO_ABILITAZIONE) ");
					} else{
						if (instance.getOsservazioniSelezionato().equals("3")){
							sb.append(" AND U.DATA_NASCITA_UTENTE = U.DATA_RILASCIO_DOC ");
						} else{
							if (instance.getOsservazioniSelezionato().equals("4")){
								sb.append(" AND RM.VOTO_LAUREA IS NULL ");
							} else {
								if (instance.getOsservazioniSelezionato().equals("5")){
									sb.append(" AND RM.VOTO_ABILITAZIONE  IS NULL ");
								}
							}
						}
					}
				}
			}
	
			sb.append(" ORDER BY upper(trim(U.COGNOME_UTENTE)), upper(trim(U.NOME_UTENTE))");
		    
			List results = session.createSQLQuery(sb.toString()).list();
			
			log.debug("find by filter successful, result size: "
					+ results.size());
//			UtenteCandidatureBean utenteSelezionato = null;
			CandidaturaRegHome candidaturaRegHome= new CandidaturaRegHome();
			HashMap candidatoElaborato = new HashMap();
			OsservazioniUtiliy osservazioniUtiliy = new OsservazioniUtiliy();

			RecuperaProtocollo recuperaProtocollo= new RecuperaProtocollo();
//			UtenteHome utenteHome = new UtenteHome();
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
//				utenteSelezionato=new UtenteCandidatureBean();
				String idUtenteSelezionato = new String();
				Object[] row = (Object[]) iterator.next(); 
				idUtenteSelezionato = (String)row[0];
//				utenteSelezionato.setIdUtente((String)row[0]);
//				filtro per protocollo
				
				boolean filtroOk = true;
				//il campo filtroOk pu� essere a true quando il filto non � stato richiesto e se richiesto il protocollo � stato trovato.

				String protocollo=null;
//  recupero protocollo da ricevuta
//				protocollo = recuperaProtocollo.getProtocolloRegionale(idUtenteSelezionato);
//			    if (protocollo==null) protocollo="";
//	protocollo richiesto come filtro e non trovato 
//				if(instance.getProtocollo()!=null&&!instance.getProtocollo().equals("") ){
//					if (!protocollo.toUpperCase().contains(instance.getProtocollo().toUpperCase().trim())) {
//						filtroOk =  false;
//					}
//				}
//	filtro per osservazioni
//				if (!instance.getOsservazioniSelezionato().equals("-1")){
//					if (instance.getOsservazioniSelezionato().equals("1")){
//						filtroOk = osservazioniUtiliy.isOssProvIscAlbo(idUtenteSelezionato);
//					} else{
//						if (instance.getOsservazioniSelezionato().equals("2")){
//							filtroOk = osservazioniUtiliy.isOssDAlboDAbil(idUtenteSelezionato);
//						} else{
//							if (instance.getOsservazioniSelezionato().equals("3")){
//								filtroOk = osservazioniUtiliy.isOssDDocDNasc(StringUtil.dateToStringDDMMYYYY((Timestamp) row[3]), 
//																			 StringUtil.dateToStringDDMMYYYY((Timestamp) row[4]));
//							} 
//						}
//					}
//					
//				}
		      
				if (filtroOk){
	//		verifico candidatura		
					CandidaturaReg candidaturaReg = new CandidaturaReg();
					candidaturaReg = candidaturaRegHome.findById(idUtenteSelezionato);
					boolean aggiungiCandidato = false;
					if(candidaturaReg.getModalitaCandidatura().equalsIgnoreCase("S")){
	//			Singola
					   aggiungiCandidato = true;
					} else{
	//			Associata
						if (!candidatoElaborato.containsKey(candidaturaReg.getIdCandidatura())){
							aggiungiCandidato = true;
							candidatoElaborato.put(candidaturaReg.getIdCandidatura(), new String(" "));
						}
					}
					
					if (aggiungiCandidato)				
						listaIDCandidature.add(idUtenteSelezionato);
				}
		}
			
			return listaIDCandidature;
			
		} catch (RuntimeException re) {
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}finally{
			session.close();
		}
	
	}
	
	
	public List<UtenteCandidatureBean> findByFilterCandidaturaPaginataList(RicercaCandidati instance, List<String> listSelectIn ) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<UtenteCandidatureBean> listaCandidature=new ArrayList<UtenteCandidatureBean>();
	
		try {
			
			session = HibernateUtil.openSession();
			String inSelect ="";
			for (int i = 0; i < listSelectIn.size(); i++) {
				inSelect+="'"+listSelectIn.get(i)+"',";
			}
			inSelect=inSelect.substring(0, inSelect.length()-1)+")";
			
			StringBuffer sb=new StringBuffer();
			
//	campi	                        0                                    1                          2                        3                   4                 5                                6                           7              8                 9              10                11               12                13                   14
			sb.append("SELECT upper(trim(U.NOME_UTENTE)), upper(trim(U.COGNOME_UTENTE)), U.DATA_NASCITA_UTENTE, U.LUOGO_NASCITA_UTENTE, U.PRV_NASCITA_UTENTE, U.LUOGO_NASCITA_ESTERA, upper(U.CODICE_FISCALE_UTENTE) , C.COD_REG_UTENTE, U.ID_UTENTE, CD.ID_CANDIDATURA , CD.AMMESSO, U.DATA_RILASCIO_DOC, D.DOC_PERVENUTA, D.FLAG_CONF_DOC_DIC, CD.PROTOCOLLI_RIASSEGNATI" +
					//    15
					",UT.PEC_CAMBIATA  " +
					" FROM UTENTE_REG U,  CANDIDATURA_REG CD, DICHIARAZIONE_SOSTITUTIVA_REG D, " +
					"UTENTE UT," +
					"  (SELECT B.NOME_UTENTE, B.COGNOME_UTENTE,  B.CODICE_FISCALE_UTENTE, B.COD_REG_UTENTE" +
					"  FROM UTENTE_REG B,  CANDIDATURA_REG CDD " +
					"    WHERE B.COD_REG_UTENTE <>'"+instance.getCodReg()+"' AND B.ID_UTENTE = CDD.id_utente  ) C " +
					"WHERE U.COD_REG_UTENTE = '"+instance.getCodReg()+"'" +
					"  AND U.ID_UTENTE = CD.id_utente "+
					"  AND U.ID_UTENTE = UT.id_utente "+
					"  AND U.ID_UTENTE IN("+inSelect +
					"  AND U.ID_DOMANDA_UTENTE = D.ID_DOMANDA_DIC AND U.CODICE_FISCALE_UTENTE  = C.CODICE_FISCALE_UTENTE(+) ");
				
//			if(instance.getNomeRicerca()!=null&&!instance.getNomeRicerca().equals("")){
////				sb.append("   AND U.NOME_UTENTE =");
//				sb.append("   AND UPPER(U.NOME_UTENTE) LIKE");
//				sb.append(" '"+instance.getNomeRicerca().toUpperCase().trim()+"%'");
//			}
//			if(instance.getCognomeRicerca()!=null&&!instance.getCognomeRicerca().equals("")){
////				UPPER(COGNOME_UTENTE) LIKE '%GIORDANO%'  
//				sb.append(" AND UPPER(U.COGNOME_UTENTE) LIKE");
//				sb.append("'"+instance.getCognomeRicerca().toUpperCase().trim()+"%'");
//			}
//			if(instance.getCodiceFiscaleRicerca()!=null&&!instance.getCodiceFiscaleRicerca().equals("")){
//				  sb.append(" AND UPPER(U.CODICE_FISCALE_UTENTE) =");
//				  sb.append(" '"+instance.getCodiceFiscaleRicerca().toUpperCase().trim()+"'");
//			}
//			
//			if(instance.getAmmessoSelezionato()!=null&&!instance.getAmmessoSelezionato().equals("-1")&&!instance.getAmmessoSelezionato().equals("") ){
//				  sb.append(" AND  CD.AMMESSO=");
//				  sb.append("'"+instance.getAmmessoSelezionato()+"'");
//			}
//			
////			filtro protocollo si sposta dentro il ciclo
//			if(instance.getRegioneSelezionata()!=null&&!instance.getRegioneSelezionata().equals("-1")&&!instance.getRegioneSelezionata().equals("") ){
//				  sb.append(" AND  C.COD_REG_UTENTE =");
//				  sb.append("'"+instance.getRegioneSelezionata()+"'");
//			}
//			
			
			sb.append(" ORDER BY upper(trim(U.COGNOME_UTENTE)), upper(trim(U.NOME_UTENTE))");
		    
			List results = session.createSQLQuery(sb.toString()).list();
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			UtenteCandidatureBean utenteSelezionato = null;
			CandidaturaRegHome candidaturaRegHome= new CandidaturaRegHome();
			HashMap candidatoElaborato = new HashMap();
			RecuperaProtocollo recuperaProtocollo= new RecuperaProtocollo();
			OsservazioniUtiliy osservazioniUtiliy = new OsservazioniUtiliy();
//			UtenteHome utenteHome = new UtenteHome();
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				utenteSelezionato=new UtenteCandidatureBean();
				Object[] row = (Object[]) iterator.next(); 
				
				utenteSelezionato.setIdUtente((String)row[8]);
//				filtro per protocollo
				
				boolean filtroOk = true;
				//il campo filtroOk pu� essere a true quando il filto non � stato richiesto e se richiesto il protocollo � stato trovato.

				String protocollo=null;
//				recupero protocollo da ricevuta
				protocollo = recuperaProtocollo.getProtocolloRegionale(utenteSelezionato.getIdUtente());
			    if (protocollo==null) protocollo="";
			    String protocolloRiassengato= (String)row[14];
			    if(protocolloRiassengato!=null) protocollo=protocollo+" ; " +protocolloRiassengato;
			    utenteSelezionato.setProtocolloRicevuta(protocollo);
//			    if (protocollo.equals("")){
//			    	utenteSelezionato.setScaricaRicevuta("true");
//			    } else {
//			    	utenteSelezionato.setScaricaRicevuta("false");
//			    }
//	protocollo richiesto come filtro e non trovato 
//				if(instance.getProtocollo()!=null&&!instance.getProtocollo().equals("") ){
//					if (!protocollo.toUpperCase().contains(instance.getProtocollo().toUpperCase().trim())) {
//						filtroOk =  false;
//					}
//				}
//	filtro per osservazioni
//				if (!instance.getOsservazioniSelezionato().equals("-1")){
//					if (instance.getOsservazioniSelezionato().equals("1")){
//						filtroOk = osservazioniUtiliy.isOssProvIscAlbo(utenteSelezionato.getIdUtente());
//					} else{
//						if (instance.getOsservazioniSelezionato().equals("2")){
//							filtroOk = osservazioniUtiliy.isOssDAlboDAbil(utenteSelezionato.getIdUtente());
//						} else{
//							if (instance.getOsservazioniSelezionato().equals("3")){
//								filtroOk = osservazioniUtiliy.isOssDDocDNasc(StringUtil.dateToStringDDMMYYYY((Timestamp) row[2]), 
//																			 StringUtil.dateToStringDDMMYYYY((Timestamp) row[11]));
//							} 
//						}
//					}
//					
//				}
//		      
				if (filtroOk){
					String altraRegioneConcorso = Localita.getDenominazioneRegione((String)row[7]);
	//		verifico candidatura		
					CandidaturaReg candidaturaReg = new CandidaturaReg();
					candidaturaReg = candidaturaRegHome.findById(utenteSelezionato.getIdUtente());
					boolean aggiungiCandidato = false;
					if(candidaturaReg.getModalitaCandidatura().equalsIgnoreCase("S")){
	//			Singola 
						utenteSelezionato.setNomeUtente((String)row[0].toString().toUpperCase());
						utenteSelezionato.setCognomeUtente((String)row[1].toString().toUpperCase());
						utenteSelezionato.setDataNascita((Timestamp) row[2]);
						//utenteSelezionato.setDataNascita( (java.util.Date) row[2]);
						utenteSelezionato.setLuogoNascitaUtente(Localita.getDenominazioneComune((String)row[3]));
						utenteSelezionato.setProvinciaNascitaUtente(Localita.getDenominazioneSiglaProvincia((String)row[4]));
						utenteSelezionato.setLuogoNascitaEsteraUtente((String)row[5]);
						utenteSelezionato.setCodiceFiscaleUtente((String)row[6].toString().toUpperCase());
						if (utenteSelezionato.getCodiceFiscaleUtente().contains("*")){
							utenteSelezionato.setCodiceFiscaleUtente("");
						}
						utenteSelezionato.setRegioneRichiesta(altraRegioneConcorso);
						utenteSelezionato.setIdUtente((String)row[8]);
						utenteSelezionato.setIdCandidatura((String)row[9]);
						utenteSelezionato.setAmmessoValore((String)row[10]);
						if (utenteSelezionato.getAmmessoValore().equalsIgnoreCase("SI")){
							utenteSelezionato.setAmmesso(true);
						} else {
							utenteSelezionato.setAmmesso(false);
						}
						
						// ******* aggiunta docpervenuta ***********
//						if(row[12]!=null){
//							if (!((String)row[12]).equalsIgnoreCase("") && ((String)row[12]).equalsIgnoreCase("true"))
//							utenteSelezionato.setDocumentazionePervenuta("SI");
//							else if (!((String)row[12]).equalsIgnoreCase("") && ((String)row[12]).equalsIgnoreCase("false"))
//								utenteSelezionato.setDocumentazionePervenuta("NO");
//						}else utenteSelezionato.setDocumentazionePervenuta("SI");
						
						if(row[12]!=null){
							if (!((String)row[12]).equalsIgnoreCase("") && ((String)row[12]).equalsIgnoreCase("true"))
							utenteSelezionato.setDocumentazionePervenuta("SI");
							else if (!((String)row[12]).equalsIgnoreCase("") && ((String)row[12]).equalsIgnoreCase("false"))
								utenteSelezionato.setDocumentazionePervenuta("NO");
						}else utenteSelezionato.setDocumentazionePervenuta("NO");
						
						if(row[13]!=null){
							if (!((String)row[13]).equalsIgnoreCase("") && ((String)row[13]).equalsIgnoreCase("true"))
							utenteSelezionato.setDocumentazionePrevista("SI");
							else if (!((String)row[13]).equalsIgnoreCase("") && ((String)row[13]).equalsIgnoreCase("false"))
								utenteSelezionato.setDocumentazionePrevista("NO");
						}else utenteSelezionato.setDocumentazionePrevista("NO");
						
						if(row[15]!=null){
							if (!((String)row[15]).equalsIgnoreCase("") && ((String)row[15]).equalsIgnoreCase("Y"))
							utenteSelezionato.setRichiestaCambioPEC("SI");
							else if (((String)row[15]).equalsIgnoreCase(""))
								utenteSelezionato.setRichiestaCambioPEC("NO");
						}else utenteSelezionato.setRichiestaCambioPEC("NO");
						
						// *****************************************
						
						utenteSelezionato.setAssociata("false");
						utenteSelezionato.setListaAssociati(new ArrayList<UtenteBean>());
						utenteSelezionato.setTipoCandidato("Singolo");
						aggiungiCandidato = true;
					} else{
	//			Associata
						if (!candidatoElaborato.containsKey(candidaturaReg.getIdCandidatura())){
							aggiungiCandidato = true;
							candidatoElaborato.put(candidaturaReg.getIdCandidatura(), new String(" "));
							List<CandidaturaReg> listCandi = new ArrayList<CandidaturaReg>();
							CandidaturaReg candFind= new CandidaturaReg();
	//						carico la squadra associata	
							candFind.setIdCandidatura(candidaturaReg.getIdCandidatura());
							listCandi = candidaturaRegHome.findByExample(candFind);
							List<UtenteBean> listAss = new ArrayList<UtenteBean>();
							for (int i = 0; i < listCandi.size(); i++) {
								CandidaturaReg cand= new CandidaturaReg();
								cand = listCandi.get(i);
								UtenteReg utente = new UtenteReg();
	//							utente = utenteHome.findById(cand.getIdUtente());
								utente = this.findById(cand.getIdUtente());
								String booleanPervenuta = this.findDocPervenuta(cand.getIdUtente());
								String docPervenuta ="";
//								if (booleanPervenuta==null || booleanPervenuta.equalsIgnoreCase("true")) docPervenuta="SI";
//								else if (booleanPervenuta.equalsIgnoreCase("false")) docPervenuta="NO";
								if (booleanPervenuta==null || booleanPervenuta.equalsIgnoreCase("false")) docPervenuta="NO";
								else if (booleanPervenuta.equalsIgnoreCase("true")) docPervenuta="SI";
								
								
								String booleanPrevista = this.findDocPrevista(cand.getIdUtente());
								String docPrevista ="";
//								if (booleanPervenuta==null || booleanPervenuta.equalsIgnoreCase("true")) docPervenuta="SI";
//								else if (booleanPervenuta.equalsIgnoreCase("false")) docPervenuta="NO";
								if (booleanPrevista==null || booleanPrevista.equalsIgnoreCase("false")) docPrevista="NO";
								else if (booleanPrevista.equalsIgnoreCase("true")) docPrevista="SI";
								
								String booleanPecCambiata = this.findPec_Cambiata(cand.getIdUtente());
								String pecCambiata ="";
//								if (booleanPervenuta==null || booleanPervenuta.equalsIgnoreCase("true")) docPervenuta="SI";
//								else if (booleanPervenuta.equalsIgnoreCase("false")) docPervenuta="NO";
								if (booleanPecCambiata==null || booleanPecCambiata.equalsIgnoreCase("")) pecCambiata="NO";
								else if (booleanPecCambiata.equalsIgnoreCase("Y")) pecCambiata="SI";
								
								// con questo ID va trovata la documentaziopervenuta su dichiarazionesostitutiva
								// e settata in utenteSelezionato
								
								if (cand.getReferenteDomanda()!=null && cand.getReferenteDomanda().equalsIgnoreCase("Y")){
	//sovrascrivo informazione dell'utente Referente		
									
									if ((instance.getDocumentazionePervenuta() != null && !instance.getDocumentazionePervenuta().equalsIgnoreCase("-1") && !docPervenuta.equalsIgnoreCase(instance.getDocumentazionePervenuta()))
											|| (instance.getDocumentazionePrevista() != null && !instance.getDocumentazionePrevista().equalsIgnoreCase("-1") && !docPrevista.equalsIgnoreCase(instance.getDocumentazionePrevista()))){
										aggiungiCandidato = false;
									}
//									if (instance.getDocumentazionePrevista() != null && !instance.getDocumentazionePrevista().equalsIgnoreCase("-1") && !docPrevista.equalsIgnoreCase(instance.getDocumentazionePrevista())){
//										aggiungiCandidato = false;
//									}
									utenteSelezionato.setDocumentazionePrevista(docPrevista);
									utenteSelezionato.setDocumentazionePervenuta(docPervenuta);
									// AGGIUNTO CAMPO PEC_CAMBIATA
									utenteSelezionato.setRichiestaCambioPEC(pecCambiata);
									
									utenteSelezionato.setIdUtente(utente.getIdUtente());
									utenteSelezionato.setIdCandidatura(cand.getIdCandidatura());
									utenteSelezionato.setNomeUtente(utente.getNomeUtente().toUpperCase());
									utenteSelezionato.setCognomeUtente(utente.getCognomeUtente().toUpperCase());
									utenteSelezionato.setDataNascita(utente.getDataNascitaUtente());
									utenteSelezionato.setLuogoNascitaUtente(Localita.getDenominazioneComune(utente.getLuogoNascitaUtente()));
									utenteSelezionato.setProvinciaNascitaUtente(Localita.getDenominazioneSiglaProvincia(utente.getPrvNascitaUtente()));
									utenteSelezionato.setLuogoNascitaEsteraUtente(utente.getLuogoNascitaEstera());
									utenteSelezionato.setCodiceFiscaleUtente(utente.getCodiceFiscaleUtente().toUpperCase());
									if (utenteSelezionato.getCodiceFiscaleUtente().contains("*")){
										utenteSelezionato.setCodiceFiscaleUtente("");
									}
									utenteSelezionato.setRegioneRichiesta(altraRegioneConcorso);									
									utenteSelezionato.setTipoCandidato("Referente");
									utenteSelezionato.setAmmessoValore(cand.getAmmesso());
									if (utenteSelezionato.getAmmessoValore().equalsIgnoreCase("SI")){
										utenteSelezionato.setAmmesso(true);
									} else {
										utenteSelezionato.setAmmesso(false);
									}

								} else{
	// carico i dati dell'associato al referente
									UtenteBean utenteBean = new UtenteBean();
									utenteBean.setIdUtente(utente.getIdUtente());
									
									// con questo ID va trovata la documentaziopervenuta su dichiarazionesostitutiva
									// e settata in utenteBean
									
//									utenteBean.setDocPervenuta(docPervenuta);
									// AGGIUNTO CAMPO PEC_CAMBIATA
									utenteBean.setRichiestaCambioPEC(pecCambiata);
									
									utenteBean.setIdCandidatura(cand.getIdCandidatura());
									utenteBean.setNomeUtente(utente.getNomeUtente().toUpperCase());
									utenteBean.setCognomeUtente(utente.getCognomeUtente().toUpperCase());
									utenteBean.setDataNascita(utente.getDataNascitaUtente());
									utenteBean.setLuogoNascitaUtente(Localita.getDenominazioneComune(utente.getLuogoNascitaUtente()));
									utenteBean.setProvinciaNascitaUtente(Localita.getDenominazioneSiglaProvincia(utente.getPrvNascitaUtente()));
									utenteBean.setLuogoNascitaEsteraUtente(utente.getLuogoNascitaEstera());
									utenteBean.setCodiceFiscaleUtente(utente.getCodiceFiscaleUtente().toUpperCase());
									if (utenteBean.getCodiceFiscaleUtente().contains("*")){
										utenteBean.setCodiceFiscaleUtente("");
									}
									utenteBean.setRegioneRichiesta(altraRegioneConcorso);
									utenteBean.setTipoCandidato("Associato");
								    listAss.add(utenteBean);
								}
								utenteSelezionato.setAssociata("true");
								
							}
							utenteSelezionato.setListaAssociati(listAss);
						}
					}
					
					if (aggiungiCandidato)				
						listaCandidature.add(utenteSelezionato);
				}
		}
			
			return listaCandidature;
			
		} catch (RuntimeException re) {
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}finally{
			session.close();
		}
	
	}
	
	
	
	public List findCandiatoAll(String idRegione, String funzione) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<String> listaCandidature=new ArrayList<String>();
	
		try {
			
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
//			                           0               1             2          3
			sb.append("SELECT  upper(trim(U.COGNOME_UTENTE)), upper(trim(U.NOME_UTENTE)), U.ID_UTENTE, C.REFERENTE_DOMANDA" +
					 " FROM UTENTE_REG U, CANDIDATURA_REG  C " +
					 " WHERE U.COD_REG_UTENTE = '"+idRegione+"'"  +
					 " AND U.ID_UTENTE = C.id_utente " );
					 
			if(funzione!=null&&funzione.equalsIgnoreCase("STAMPA_CANDIDATI")){
//				  sb.append("   AND C.CANDIDATURA_AMMESSA = 'SI' ");
				  sb.append("   AND C.AMMESSO = 'SI' ");
			}	 
			sb.append("ORDER BY upper(trim(U.COGNOME_UTENTE)), upper(trim(U.NOME_UTENTE))");
			   
			
			List results = session.createSQLQuery(sb.toString()).list();
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
//				String row = (String) iterator.next(); 
//				listaCandidature.add(row);
				Object[] row = (Object[]) iterator.next(); 
				String referente="";
				if (funzione.equals("RICERCA_CANDIDATURE")){
					referente= (String)row[3];
					if (referente==null || referente.equalsIgnoreCase("Y")){		
						listaCandidature.add((String)row[2]);}
				} else{
					listaCandidature.add((String)row[2]);	
				}
				
		}
			
			return listaCandidature;
			
		} catch (RuntimeException re) { 
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}finally{
			session.close();
		}
	
	}
	
	public List<UtenteBean> findPage(String idRegione, List<String> utentiList) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<UtenteBean> listaCandidature=new ArrayList<UtenteBean>();
	
		String inSelect ="";
		for (int i = 0; i < utentiList.size(); i++) {
			inSelect+="'"+utentiList.get(i)+"',";
		}
		inSelect=inSelect.substring(0, inSelect.length()-1)+")";
		
		
		try {
			
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
//			                      0                    1             2                       3                       4                 5                             6                      7             8                9                    10                11
			sb.append("SELECT upper(trim(U.NOME_UTENTE)), upper(trim(U.COGNOME_UTENTE)), U.DATA_NASCITA_UTENTE, U.LUOGO_NASCITA_UTENTE,U.PRV_NASCITA_UTENTE, U.LUOGO_NASCITA_ESTERA, U.CODICE_FISCALE_UTENTE , U.COD_REG_UTENTE, U.ID_UTENTE  ,C.ID_CANDIDATURA, C.MODALITA_CANDIDATURA , C.REFERENTE_DOMANDA"  +
					" FROM UTENTE_REG U  , CANDIDATURA_REG C" +
					" WHERE U.ID_UTENTE = C.ID_UTENTE AND U.ID_UTENTE IN("+inSelect +
					" ORDER BY upper(trim(U.COGNOME_UTENTE)), upper(trim(U.NOME_UTENTE))");
						
			List results = session.createSQLQuery(sb.toString()).list();
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			UtenteBean utenteSelezionato = null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				utenteSelezionato=new UtenteBean();
				Object[] row = (Object[]) iterator.next(); 
				utenteSelezionato.setNomeUtente(((String)row[0]).toUpperCase());
				utenteSelezionato.setCognomeUtente(((String)row[1]!=null && (!((String)row[1]).equals(""))) ? ((String)row[1]).toUpperCase() : (String)row[1]);
//				utenteSelezionato.setDataNascita(DateUtil.sqlDateToUtilDate((Date) row[2]));
				utenteSelezionato.setDataNascita((Timestamp) row[2]);
				String sDenComune = Localita.getDenominazioneComune(((String)row[3]!=null && (!((String)row[3]).equals(""))) ? ((String)row[3]).toUpperCase() : (String)row[3]);
				utenteSelezionato.setLuogoNascitaUtente((sDenComune!=null && (!sDenComune.equals(""))) ? sDenComune.toUpperCase() : sDenComune);
				String sDenProv = Localita.getDenominazioneSiglaProvincia( (((String)row[4])!=null && (!((String)row[4]).equals(""))) ? ((String)row[4]).toUpperCase() : (String)row[4]);
				utenteSelezionato.setProvinciaNascitaUtente((sDenProv!=null && (!sDenProv.equals(""))) ? sDenProv.toUpperCase() : sDenProv);
				utenteSelezionato.setLuogoNascitaEsteraUtente(((String)row[5]!=null && (!((String)row[5]).equals(""))) ? ((String)row[5]).toUpperCase() : (String)row[5]);
				utenteSelezionato.setCodiceFiscaleUtente(((String)row[6]).toUpperCase());
				utenteSelezionato.setRegioneRichiesta(Localita.getDenominazioneRegione((String)row[7]));
				utenteSelezionato.setIdUtente((String)row[8]);
				String modalitaCand = (String)row[10];
				if (modalitaCand.equals("S")){
					utenteSelezionato.setModalitaCandidatura("SINGOLA");
				} else {
					utenteSelezionato.setModalitaCandidatura("ASSOCIATA");
				}
				utenteSelezionato.setCodiceRegione((String)row[7]);
				if (utenteSelezionato.getModalitaCandidatura().equals("ASSOCIATA")){
					String referente = (String)row[11];
					if (referente!=null && referente.equals("Y")){
						utenteSelezionato.setCodiceFiscaleRefCand(utenteSelezionato.getCodiceFiscaleUtente().toUpperCase());
					} else{
						UtenteReg utente = new UtenteReg();
						utente =this.findById((String)row[9]);
						utenteSelezionato.setCodiceFiscaleRefCand(utente.getCodiceFiscaleUtente().toUpperCase());
					}
				} else  {
					utenteSelezionato.setCodiceFiscaleRefCand(utenteSelezionato.getCodiceFiscaleUtente().toUpperCase());
				}
				if (utenteSelezionato.getCodiceFiscaleUtente().contains("*")){
					utenteSelezionato.setCodiceFiscaleUtente(" ");
				}
			
								 
				listaCandidature.add(utenteSelezionato);
		}
			
			return listaCandidature;
			
		} catch (RuntimeException re) {
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}finally{
			session.close();
		}
	
	}

	public List<UtenteBean> findListCandidati(String idRegione) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<UtenteBean> listaCandidature=new ArrayList<UtenteBean>();
		
		
		try {
			
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
//			                      0                    1             2                       3                       4                 5                             6                      7             8                9                    10                11
			sb.append("SELECT upper(trim(U.NOME_UTENTE)), upper(trim(U.COGNOME_UTENTE)), U.DATA_NASCITA_UTENTE, U.LUOGO_NASCITA_UTENTE,U.PRV_NASCITA_UTENTE, U.LUOGO_NASCITA_ESTERA, upper(trim(U.CODICE_FISCALE_UTENTE)) , U.COD_REG_UTENTE, U.ID_UTENTE  ,C.ID_CANDIDATURA, C.MODALITA_CANDIDATURA , C.REFERENTE_DOMANDA"  +
					" FROM UTENTE_REG U  , CANDIDATURA_REG C" +
					" WHERE U.ID_UTENTE = C.ID_UTENTE AND U.COD_REG_UTENTE = '"+idRegione+"'" +
					" ORDER BY upper(trim(U.COGNOME_UTENTE)), upper(trim(U.NOME_UTENTE))");
						
			List results = session.createSQLQuery(sb.toString()).list();
			
			log.debug("find by filter successful, result size: "
					+ results.size());
			UtenteBean utenteSelezionato = null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				utenteSelezionato=new UtenteBean();
				Object[] row = (Object[]) iterator.next(); 
				utenteSelezionato.setNomeUtente((String)row[0]);
				utenteSelezionato.setCognomeUtente((String)row[1]);
				utenteSelezionato.setDataNascita((Timestamp) row[2]);
				utenteSelezionato.setLuogoNascitaUtente(Localita.getDenominazioneComune((String)row[3]));
				utenteSelezionato.setProvinciaNascitaUtente(Localita.getDenominazioneSiglaProvincia((String)row[4]));
				utenteSelezionato.setLuogoNascitaEsteraUtente((String)row[5]);
				utenteSelezionato.setCodiceFiscaleUtente((String)row[6]);
				utenteSelezionato.setRegioneRichiesta(Localita.getDenominazioneRegione((String)row[7]));
				utenteSelezionato.setIdUtente((String)row[8]);
				utenteSelezionato.setIdCandidatura((String)row[9]);
				String modalitaCand = (String)row[10];
				if (modalitaCand.equals("S")){
					utenteSelezionato.setModalitaCandidatura("Singola");
				} else {
					utenteSelezionato.setModalitaCandidatura("Associata");
				}
				utenteSelezionato.setCodiceRegione((String)row[7]);
				if (modalitaCand.equals("A")){
					String referente = (String)row[11];
					if (referente!=null && referente.equals("Y")){
						utenteSelezionato.setCodiceFiscaleRefCand(utenteSelezionato.getCodiceFiscaleUtente());
					} else{
						UtenteReg utente = new UtenteReg();
						utente =this.findById((String)row[9]);
						utenteSelezionato.setCodiceFiscaleRefCand(utente.getCodiceFiscaleUtente());
					}
				} else  {
					utenteSelezionato.setCodiceFiscaleRefCand(utenteSelezionato.getCodiceFiscaleUtente());
				}
				if (utenteSelezionato.getCodiceFiscaleUtente().contains("*")){
					utenteSelezionato.setCodiceFiscaleUtente("");
				}
			
								
				listaCandidature.add(utenteSelezionato);
		}
			
			return listaCandidature;
			
		} catch (RuntimeException re) {
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}finally{
			session.close();
		}
	
	}

	public UtenteBean getUtenteBeanValutazioni(String IdUtente) throws GestioneErroriException{
		log.debug("finding findByFilterAllUtentiRegioni instance by example");
		Session session = null;
		UtenteBean resultBean = null;
	
		try {
			
			session = HibernateUtil.openSession();
			
			String query = null;
			SQLQuery sqlQuery = null;
						
			query ="SELECT U.NOME_UTENTE, U.COGNOME_UTENTE, U.DATA_NASCITA_UTENTE,  U.CODICE_FISCALE_UTENTE , U.ID_UTENTE,U.DATA_RILASCIO_DOC,U.COD_REG_UTENTE,C.ID_CANDIDATURA,C.MODALITA_CANDIDATURA,C.REFERENTE_DOMANDA,C.AMMESSO " +
					"FROM UTENTE_REG U, CANDIDATURA_REG C" +
					" WHERE U.ID_UTENTE = :IdUtente   " +
					" AND C.ID_UTENTE = U.ID_UTENTE" ;
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setParameter("IdUtente", IdUtente);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			List results = sqlQuery.list();
				
			log.debug("findByFilterAllUtentiRegioni successful, result size: "	+ results.size());
			
			for (Object object : results) {
				
				Map row = (Map)object;
				
				resultBean = new UtenteBean();
				
				resultBean.setNomeUtente((String) row.get("NOME_UTENTE"));
				resultBean.setCognomeUtente((String) row.get("COGNOME_UTENTE"));
				resultBean.setDataNascita((Timestamp) row.get("DATA_NASCITA_UTENTE"));
				resultBean.setCodiceFiscaleUtente((String) row.get("CODICE_FISCALE_UTENTE"));
				resultBean.setIdUtente((String) row.get("ID_UTENTE"));
				resultBean.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
				resultBean.setDataRilascioDoc((Timestamp) row.get("DATA_RILASCIO_DOC"));
				resultBean.setModalitaCandidatura((String) row.get("MODALITA_CANDIDATURA"));
				resultBean.setTipoCandidato((String) row.get("REFERENTE_DOMANDA"));
				resultBean.setAmmesso((String) row.get("AMMESSO"));	
				resultBean.setCodiceRegione((String)row.get("COD_REG_UTENTE"));
				
			}
			
				
			return resultBean;
			
		} catch (RuntimeException re) {
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}finally{
			session.close();
		}
	
	}
	
	
	public String findDocPervenuta(String idUtente) throws GestioneErroriException{
		Session session = null;
		log.debug("finding documentazione pervenuta in dichiarazione sostitutiva");
		String docPervenuta="";
		try {
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			sb.append("SELECT DOC_PERVENUTA FROM DICHIARAZIONE_SOSTITUTIVA_REG WHERE ID_DOMANDA_DIC = '"+idUtente+"'"  );
			
			docPervenuta = (String)session.createSQLQuery(sb.toString()).uniqueResult();
			return docPervenuta;	
		} 
		catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("UtenteHome - findDocPervenuta: errore findDocPervenuta");
		}
		finally{
			session.close();
		}
	}
	
	public String findDocPrevista(String idUtente) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding documentazione prevista in dichiarazione sostitutiva");
		String docPrevista="";
		try {
			
			StringBuffer sb=new StringBuffer();
			sb.append("SELECT FLAG_CONF_DOC_DIC FROM DICHIARAZIONE_SOSTITUTIVA_REG WHERE ID_DOMANDA_DIC = '"+idUtente+"'"  );
			
			docPrevista = (String)session.createSQLQuery(sb.toString()).uniqueResult();
			return docPrevista;	
		} 
		catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("UtenteHome - findDocPrevista: errore findDocPrevista");
		}
		finally{
			session.close();
		}
	}
	
	public String findPec_Cambiata(String idUtente) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding PEC_CAMBIATA in UTENTE");
		String pecCambiata="";
		try {
			
			StringBuffer sb=new StringBuffer();
			sb.append("SELECT PEC_CAMBIATA FROM UTENTE WHERE ID_DOMANDA_UTENTE = '"+idUtente+"'"  );
			
			pecCambiata = (String)session.createSQLQuery(sb.toString()).uniqueResult();
			return pecCambiata;	
		} 
		catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("UtenteHome - findDocPrevista: errore findDocPrevista");
		}
		finally{
			session.close();
		}
	}
	
	
	
	public List<String>  check_protocollo(RicercaCandidati ricercaCandidato) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<String> listaProtocolli=new ArrayList<String>();
		List<String> listaIDUtenteCand=new ArrayList<String>();
		try {
			
			session = HibernateUtil.openSession();
			StringBuffer sbChk=new StringBuffer();			
			String protocollo="";
				if (ricercaCandidato.getProtocollo().length()>6){
					protocollo= ricercaCandidato.getProtocollo().substring(0, 6);
				} else{
					protocollo= ricercaCandidato.getProtocollo().trim();
				}
				protocollo = protocollo.replace("'", "''").trim();				
				   
				sbChk.append("select R.ID_RICEVUTA,R.ID_CANDIDATURA"+   		          
		            " FROM RICEVUTE R" +
					" where R.ID_RICEVUTA = '"+protocollo+"' and R.ID_REGIONE='"+ricercaCandidato.getCodReg()+"'");
				
				Query query = session.createSQLQuery(sbChk.toString());
				List resultsChk = query.list();
				
				if (resultsChk.size() >0){
					
					for (Iterator iterator = resultsChk.iterator(); iterator.hasNext();) {
						Object[] row = (Object[]) iterator.next(); 
						listaProtocolli.add((String)row[1]);
					}
					
//				    " and C.ID_CANDIDATURA = '"+listaProtocolli.get(0).substring(0, listaProtocolli.get(0).indexOf("_S"))+"' "+
//			        
					StringBuffer sb=new StringBuffer();
					
//					campi	                        0                     1                             2                        3                          4                 5                       6                           7              8                 9              10                11                  
							sb.append("SELECT U.ID_UTENTE,   upper(trim(U.NOME_UTENTE)), upper(trim(U.COGNOME_UTENTE)),  U.DATA_NASCITA_UTENTE , U.DATA_RILASCIO_DOC " +
				                    ",D.DOC_PERVENUTA " +
									" FROM UTENTE_REG U,  CANDIDATURA_REG CD,   RICEVUTE  R, REQUISITI_MINIMI_REG RM, " +
									"DICHIARAZIONE_SOSTITUTIVA_REG D, " +
									"  (SELECT B.NOME_UTENTE, B.COGNOME_UTENTE,  B.CODICE_FISCALE_UTENTE, B.COD_REG_UTENTE" +
									"  FROM UTENTE_REG B,  CANDIDATURA_REG CDD  " +
									"    WHERE B.COD_REG_UTENTE <>'"+ricercaCandidato.getCodReg()+"' AND B.ID_UTENTE = CDD.id_utente  ) C " +
									"WHERE U.COD_REG_UTENTE = '"+ricercaCandidato.getCodReg()+"'" +
									"  AND U.ID_UTENTE = CD.id_utente "+
									"  AND U.CODICE_FISCALE_UTENTE  = C.CODICE_FISCALE_UTENTE(+) " +
									"  AND CD.ID_CANDIDATURA =   R.ID_CANDIDATURA(+)"+
									"  AND U.ID_UTENTE = D.ID_DOMANDA_DIC  " +
									"  AND U.ID_UTENTE = RM.ID_DOMANDA_REQ  ");
									
								
							if(ricercaCandidato.getNomeRicerca()!=null&&!ricercaCandidato.getNomeRicerca().equals("")){
//								sb.append("   AND U.NOME_UTENTE =");
								sb.append("   AND UPPER(trim(U.NOME_UTENTE)) LIKE");
								sb.append(" '"+ricercaCandidato.getNomeRicerca().replace("'", "''").toUpperCase().trim()+"%'");
							}
							if(ricercaCandidato.getCognomeRicerca()!=null&&!ricercaCandidato.getCognomeRicerca().equals("")){
//								UPPER(COGNOME_UTENTE) LIKE '%GIORDANO%'  
								sb.append(" AND UPPER(trim(U.COGNOME_UTENTE)) LIKE");
//								instance.setCognomeRicerca(instance.getCognomeRicerca().replace("'", "''"));
								sb.append("'"+ricercaCandidato.getCognomeRicerca().replace("'", "''").toUpperCase().trim()+"%'");
							}
							if(ricercaCandidato.getCodiceFiscaleRicerca()!=null&&!ricercaCandidato.getCodiceFiscaleRicerca().equals("")){
								  sb.append(" AND UPPER(trim(U.CODICE_FISCALE_UTENTE)) =");
								  sb.append(" '"+ricercaCandidato.getCodiceFiscaleRicerca().replace("'", "''").toUpperCase().trim()+"'");
							}
							
							if(ricercaCandidato.getAmmessoSelezionato()!=null&&!ricercaCandidato.getAmmessoSelezionato().equals("-1")&&!ricercaCandidato.getAmmessoSelezionato().equals("") ){
								  sb.append(" AND  CD.AMMESSO=");
								  sb.append("'"+ricercaCandidato.getAmmessoSelezionato()+"'");
							}
							
							if(ricercaCandidato.getRegioneSelezionata()!=null&&!ricercaCandidato.getRegioneSelezionata().equals("-1")&&!ricercaCandidato.getRegioneSelezionata().equals("") ){
								  sb.append(" AND  C.COD_REG_UTENTE =");
								  sb.append("'"+ricercaCandidato.getRegioneSelezionata()+"'");
							}
							
//							if(instance.getDocumentazionePervenuta()!=null && !instance.getDocumentazionePervenuta().equals("-1") ){
//								if (instance.getDocumentazionePervenuta().equalsIgnoreCase("SI")){
//									sb.append(" AND ( D.DOC_PERVENUTA is null OR D.DOC_PERVENUTA = 'true' )");
//								} else if (instance.getDocumentazionePervenuta().equalsIgnoreCase("NO")){
//									sb.append(" AND D.DOC_PERVENUTA = 'false'");
//								}
//							}
							
							if(ricercaCandidato.getDocumentazionePrevista()!=null && !ricercaCandidato.getDocumentazionePrevista().equals("-1") ){
								if (ricercaCandidato.getDocumentazionePrevista().equalsIgnoreCase("NO")){
									sb.append(" AND ( D.FLAG_CONF_DOC_DIC is null OR D.FLAG_CONF_DOC_DIC = 'false' )");
								} else if (ricercaCandidato.getDocumentazionePrevista().equalsIgnoreCase("SI")){
									sb.append(" AND D.FLAG_CONF_DOC_DIC = 'true'");
								}
							}
							
							if(ricercaCandidato.getDocumentazionePervenuta()!=null && !ricercaCandidato.getDocumentazionePervenuta().equals("-1") ){
								if (ricercaCandidato.getDocumentazionePervenuta().equalsIgnoreCase("NO")){
									sb.append(" AND ( D.DOC_PERVENUTA is null OR D.DOC_PERVENUTA = 'false' )");
								} else if (ricercaCandidato.getDocumentazionePervenuta().equalsIgnoreCase("SI")){
									sb.append(" AND D.DOC_PERVENUTA = 'true'");
								}
							}

//	filtro protocollo si sposta dentro il ciclo
							if(ricercaCandidato.getProtocollo()!=null && !ricercaCandidato.getProtocollo().equals("") ){
//								sb.append(" AND R.ID_RICEVUTA  LIKE  ");
//								String protocollo="";
//								if (instance.getProtocollo().length()>6){
//									protocollo= instance.getProtocollo().substring(0, 6);
//								} else{
//									protocollo= instance.getProtocollo().trim();
//								}
//								sb.append("'"+protocollo.replace("'", "''").trim()+"%'");
								sb.append(" AND CD.ID_CANDIDATURA =  '"+listaProtocolli.get(0).substring(0, listaProtocolli.get(0).indexOf("_S"))+"' " );
							}			

//					filtro per osservazioni
							if (ricercaCandidato.getOsservazioniSelezionato()!=null &&!ricercaCandidato.getOsservazioniSelezionato().equals("-1")){
								if (ricercaCandidato.getOsservazioniSelezionato().equals("1")){
									sb.append(" AND RM.PRV_ATTUALE_ALBO IS NULL ");
								} else{
									if (ricercaCandidato.getOsservazioniSelezionato().equals("2")){
										sb.append(" AND TO_NUMBER(TO_CHAR(RM.DATA_ALBO,'YYYY')) < TO_NUMBER(RM.ANNO_ABILITAZIONE) ");
									} else{
										if (ricercaCandidato.getOsservazioniSelezionato().equals("3")){
											sb.append(" AND U.DATA_NASCITA_UTENTE = U.DATA_RILASCIO_DOC ");
										} else{
											if (ricercaCandidato.getOsservazioniSelezionato().equals("4")){
												sb.append(" AND RM.VOTO_LAUREA IS NULL ");
											} else {
												if (ricercaCandidato.getOsservazioniSelezionato().equals("5")){
													sb.append(" AND RM.VOTO_ABILITAZIONE  IS NULL ");
												}
											}
										}
									}
								}
							}
					
							sb.append(" ORDER BY upper(trim(U.COGNOME_UTENTE)), upper(trim(U.NOME_UTENTE))");
						    
							List results = session.createSQLQuery(sb.toString()).list();
							
							log.debug("find by filter successful, result size: "
									+ results.size());
//							UtenteCandidatureBean utenteSelezionato = null;
							CandidaturaRegHome candidaturaRegHome= new CandidaturaRegHome();
							HashMap candidatoElaborato = new HashMap();
							OsservazioniUtiliy osservazioniUtiliy = new OsservazioniUtiliy();

							RecuperaProtocollo recuperaProtocollo= new RecuperaProtocollo();
//							UtenteHome utenteHome = new UtenteHome();
							for (Iterator iterator = results.iterator(); iterator.hasNext();) {
//								utenteSelezionato=new UtenteCandidatureBean();
								String idUtenteSelezionato = new String();
								Object[] row = (Object[]) iterator.next(); 
								idUtenteSelezionato = (String)row[0];
//								utenteSelezionato.setIdUtente((String)row[0]);
//								filtro per protocollo
								
								boolean filtroOk = true;
								//il campo filtroOk pu� essere a true quando il filto non � stato richiesto e se richiesto il protocollo � stato trovato.
						      
								if (filtroOk){
					//		verifico candidatura		
									CandidaturaReg candidaturaReg = new CandidaturaReg();
									candidaturaReg = candidaturaRegHome.findById(idUtenteSelezionato);
									boolean aggiungiCandidato = false;
									if(candidaturaReg.getModalitaCandidatura().equalsIgnoreCase("S")){
					//			Singola
									   aggiungiCandidato = true;
									} else{
					//			Associata
										if (!candidatoElaborato.containsKey(candidaturaReg.getIdCandidatura())){
											aggiungiCandidato = true;
											candidatoElaborato.put(candidaturaReg.getIdCandidatura(), new String(" "));
										}
									}
									
									if (aggiungiCandidato)				
										listaIDUtenteCand.add(idUtenteSelezionato);
								}
							}
							
//							return listaIDUtenteCand;

				}
						
				return listaIDUtenteCand;
			
		}
		catch (RuntimeException re) { 
			log.error("find by filter failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilter: errore findByFilter");
		}
		finally {
			session.close();
		}
	
	}
	
	
	
	
}
