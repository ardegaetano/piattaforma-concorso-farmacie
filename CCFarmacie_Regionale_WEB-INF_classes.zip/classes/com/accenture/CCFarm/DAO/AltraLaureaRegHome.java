package com.accenture.CCFarm.DAO;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

public class AltraLaureaRegHome {

	private static final Logger log = CommonLogger.getLogger("AltraLaureaRegHome");
	
	public void saveOrUpdate(AltraLaureaReg instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty AltraLaurea instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw new GestioneErroriException("AltraLaureaRegHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
		
	}
	
	

	public AltraLaureaReg findById(java.lang.String id) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting AltraLaurea instance with id: " + id);
		try {
			AltraLaureaReg instance = (AltraLaureaReg) session.get("com.accenture.CCFarm.DAO.AltraLaureaReg", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			log.debug("L'utente con id"+ id + "non possiede un altra laurea");
			throw new GestioneErroriException("AltraLaureaRegHome - findById: errore findById");
			
		}
		finally{
			session.close();
		}
	}
}
