package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.pageBean.CriteriPunteggiListBean;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class AnagraficaFarm.
 * @see com.accenture.CCFarm.DAO.AnagraficaFarm
 * @author Hibernate Tools
 */
public class CriteriPunteggiHome {

	private static final Logger log = CommonLogger.getLogger("CriteriPunteggiHome");
	
	public void persist(CriteriPunteggi transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting CriteriPunteggi instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - persist: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(CriteriPunteggi instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty CriteriPunteggi instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - saveOrUpdate: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void attachClean(CriteriPunteggi instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean CriteriPunteggi instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - attachClean: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void delete(CriteriPunteggi persistentInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting CriteriPunteggi instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - delete: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public CriteriPunteggi merge(CriteriPunteggi detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging CriteriPunteggi instance");
		try {
			CriteriPunteggi result = (CriteriPunteggi) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - merge: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public CriteriPunteggi findById(CriteriPunteggiId id) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting CriteriPunteggi instance with id: " + id);
		try {
			CriteriPunteggi instance = (CriteriPunteggi) session.get("com.accenture.CCFarm.DAO.CriteriPunteggi", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - findById: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public List findByExample(CriteriPunteggi instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding CriteriPunteggi instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.CriteriPunteggi")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - findByExample: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	public List findByTipoPunteggiLaurea(CriteriPunteggi instance, String idRegione) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding CriteriPunteggi instance by findByTipoPunteggiLaurea");
		try {
			instance.setTipoTitolo(GenericConstants.TIPO_PUNTEGGI_LAUREA);
			instance.setIdRegione(idRegione);
			
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.CriteriPunteggi")
					.add(Example.create(instance)).list();
			log.debug("findByTipoPunteggiLaurea successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("findByTipoPunteggiLaurea failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - findByTipoPunteggiLaurea: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	public List findByTipoPunteggiAbilitazione(CriteriPunteggi instance, String idRegione) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding CriteriPunteggi instance by findByTipoPunteggiAbilitazione");
		try {
			instance.setTipoTitolo(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE);
			instance.setIdRegione(idRegione);
			
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.CriteriPunteggi")
					.add(Example.create(instance)).list();
			log.debug("findByTipoPunteggiAbilitazione successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("findByTipoPunteggiAbilitazione failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - findByTipoPunteggiAbilitazione: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}

	public void deleteLaureaByRegione(String idRegione) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting CriteriPunteggi instance");
		try {
			CriteriPunteggi criteri = new CriteriPunteggi();
			List listaPunteggiLaurea = findByTipoPunteggiLaurea(criteri, idRegione);
		    if(listaPunteggiLaurea.size()>0) {
		    	Iterator iter = listaPunteggiLaurea.iterator();
	    		while(iter.hasNext()){	
	    			CriteriPunteggi persistentInstance = (CriteriPunteggi)iter.next();
	    			session.delete(persistentInstance);
	    		}
	    	}
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - deleteLaureaByRegione: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	public void deleteAbilitazioneByRegione(String idRegione) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting CriteriPunteggi instance");
		try {
			CriteriPunteggi criteri = new CriteriPunteggi();
			List listaPunteggiAbilitazione = findByTipoPunteggiAbilitazione(criteri, idRegione);
		    if(listaPunteggiAbilitazione.size()>0) {
		    	Iterator iter = listaPunteggiAbilitazione.iterator();
	    		while(iter.hasNext()){	
	    			CriteriPunteggi persistentInstance = (CriteriPunteggi)iter.next();
	    			session.delete(persistentInstance);
	    		}
	    	}
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - deleteAbilitazioneByRegione: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	
	public void insertListaLaurea(String idRegione, List<CriteriPunteggiListBean> lista, boolean bValida) throws GestioneErroriException {
		
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty CriteriPunteggi instance");
		try {
			//INSERT
			for(int i=0; i<lista.size(); i++){
				CriteriPunteggiListBean riga = (CriteriPunteggiListBean)lista.get(i);
				CriteriPunteggi critPunteggiDB = new CriteriPunteggi();
				CriteriPunteggiId punteggiId = new CriteriPunteggiId();
				punteggiId.setIdRegione(idRegione);
				punteggiId.setTipoTitolo(GenericConstants.TIPO_PUNTEGGI_LAUREA);
				punteggiId.setVoto(riga.getVoto());
				
				critPunteggiDB.setId(punteggiId);
				String dPunt = riga.getPunteggio().replace(',', '.');
				critPunteggiDB.setPunteggio(new BigDecimal(dPunt));
				critPunteggiDB.setStato((bValida)? "1" : "0");
				
				session.saveOrUpdate(critPunteggiDB); 
			}
			
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - insertListaLaurea: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	public void insertListaAbilitazione(String idRegione, List<CriteriPunteggiListBean> lista, boolean bValida) throws GestioneErroriException {
		
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty CriteriPunteggi instance");
		try {
			//INSERT
			for(int i=0; i<lista.size(); i++){
				CriteriPunteggiListBean riga = (CriteriPunteggiListBean)lista.get(i);
				CriteriPunteggi critPunteggiDB = new CriteriPunteggi();
				CriteriPunteggiId punteggiId = new CriteriPunteggiId();
				punteggiId.setIdRegione(idRegione);
				punteggiId.setTipoTitolo(GenericConstants.TIPO_PUNTEGGI_ABILITAZIONE);
				punteggiId.setVoto(riga.getVoto());
				
				critPunteggiDB.setId(punteggiId);
				String dPunt = riga.getPunteggio().replace(',', '.');
				critPunteggiDB.setPunteggio(new BigDecimal(dPunt));
				critPunteggiDB.setStato((bValida)? "1" : "0");
				
				session.saveOrUpdate(critPunteggiDB); 
			}
			
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed: "+re.getMessage(), re);
			GestioneErroriException eccezione = new GestioneErroriException("CriteriPunteggiHome - insertListaAbilitazione: "+re);
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
		
	
}
