package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.PrintException;

/**
 * Home object for domain model class EsercizioProfReg.
 * @see com.accenture.CCFarm.DAO.EsercizioProfReg
 * @author Hibernate Tools
 */
public class EsercizioProfRegHome {

//	private static final Log log = LogFactory.getLog(EsercizioProfHome.class);
	private static final Logger log = CommonLogger.getLogger("EsercizioProfHome");

	public void persist(EsercizioProfReg transientInstance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting EsercizioProfReg instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("EsercizioProfRegHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(EsercizioProfReg instance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty EsercizioProfReg instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("EsercizioProfRegHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(EsercizioProfReg instance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean EsercizioProfReg instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("EsercizioProfRegHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(EsercizioProfReg persistentInstance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting EsercizioProfReg instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("EsercizioProfRegHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public EsercizioProfReg merge(EsercizioProfReg detachedInstance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging EsercizioProfReg instance");
		try {
			EsercizioProfReg result = (EsercizioProfReg) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("EsercizioProfRegHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public EsercizioProfReg findById(java.lang.String id)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting EsercizioProfReg instance with id: " + id);
		try {
			EsercizioProfReg instance = (EsercizioProfReg) session.get("com.accenture.CCFarm.DAO.EsercizioProfReg", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("EsercizioProfRegHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	
	public EsercizioProfReg findByIdHql(String id)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting Nazioni instance with id: " + id);
		Transaction trx = session.beginTransaction();
		EsercizioProfReg result = new EsercizioProfReg();
		try {
			Query query = session.createQuery("from EsercizioProfReg where idDomandaEs = :idDomandaEs ");
			query.setParameter("idDomandaEs", id);
			if(query.list().isEmpty()){
				result = null;
			}else{
			result = (EsercizioProfReg)query.list().get(0);	
			}
		} catch (Exception e) {
			log.error("Errore Lettura EsercizioProfReg.. da ID_DOCUMENTO  ", e);
			throw new GestioneErroriException("EsercizioProfRegHome - findByIdHql: errore findByIdHql");
		}		
		finally{
			session.close();
			return result;		
		}
	}		
	public List findByExample(EsercizioProfReg instance)  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding EsercizioProfReg instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.EsercizioProfReg")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("EsercizioProfRegHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	
	public String getSequenceIdEsercizioProfessionale()  throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_ESERCIZIO_PROFESSIONALE.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("getSequenceIdEsercizioProfessionale() - "+ PrintException.stack2string(re));
			throw new GestioneErroriException("EsercizioProfRegHome - getSequenceIdEsercizioProfessionale: errore getSequenceIdEsercizioProfessionale");
		}
		finally{
			session.close();
		}
	}
	
}
