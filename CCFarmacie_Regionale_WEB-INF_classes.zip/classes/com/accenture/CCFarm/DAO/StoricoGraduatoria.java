package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.Date;

import com.accenture.CCFarm.utility.StringUtil;

@SuppressWarnings("serial")
public class StoricoGraduatoria implements java.io.Serializable {

	private StoricoGraduatoriaId idKey;
	private String idCandidatura;
	private String numeroProtocollo;
	private String cognome;
	private String nome;
	private String codRegione;
	private BigDecimal etaMedia;
	private BigDecimal punteggio; 
	private String dataNascita;
	private Date dataValidazione;
	private String dataValidazioneString;
	private BigDecimal indiceTotale;
	private BigDecimal indiceRelativo;
	private String nProgressivo;
	private String exAequo;
	private String exAequoRisolto;
	private String colorExAequo;
	
	public StoricoGraduatoria(){
		
	}
	


	public StoricoGraduatoria(String idCandidatura,String numeroProtocollo, String cognome, String nome, String codRegione, BigDecimal etaMedia, 
			BigDecimal punteggio,String dataNascita,Date dataValidazione,String dataValidazioneString,BigDecimal indiceTotale, BigDecimal indiceRelativo,String exAequo,String exAequoRisolto,
			String nProgressivo) {
		super();		
		this.idCandidatura = idCandidatura;
		this.numeroProtocollo = numeroProtocollo;
		this.cognome = cognome;
		this.nome = nome;
		this.codRegione = codRegione;
		this.etaMedia = etaMedia;
		this.punteggio = punteggio;		
		this.dataNascita = dataNascita;	
		this.dataValidazione = dataValidazione;	
		this.dataValidazioneString = dataValidazioneString;
		this.indiceTotale = indiceTotale;	
		this.indiceRelativo = indiceRelativo;
		this.exAequo = exAequo;
		this.exAequoRisolto = exAequoRisolto;
		this.nProgressivo = nProgressivo;
	}



	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}



	public String getIdCandidatura() {
		return idCandidatura;
	}



	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}



	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}



	public String getCognome() {
		return cognome;
	}



	public void setCognome(String cognome) {
		this.cognome = cognome;
	}



	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public String getCodRegione() {
		return codRegione;
	}



	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}



	public BigDecimal getEtaMedia() {
		return etaMedia;
	}



	public void setEtaMedia(BigDecimal etaMedia) {
		this.etaMedia = etaMedia;
	}



	public BigDecimal getPunteggio() {
		return punteggio;
	}



	public void setPunteggio(BigDecimal punteggio) {
		this.punteggio = punteggio;
	}


	public String getDataNascita() {
		return dataNascita;
	}



	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}



	public BigDecimal getIndiceTotale() {
		return indiceTotale;
	}



	public void setIndiceTotale(BigDecimal indiceTotale) {
		this.indiceTotale = indiceTotale;
	}

	
	
	public String getExAequo() {
		return exAequo;
	}



	public void setExAequo(String exAequo) {
		this.exAequo = exAequo;
	}



	public String getExAequoRisolto() {
		return exAequoRisolto;
	}



	public void setExAequoRisolto(String exAequoRisolto) {
		this.exAequoRisolto = exAequoRisolto;
	}



	


	public String getnProgressivo() {
		return nProgressivo;
	}



	public void setnProgressivo(String nProgressivo) {
		this.nProgressivo = nProgressivo;
	}



	public BigDecimal getIndiceRelativo() {
		return indiceRelativo;
	}



	public void setIndiceRelativo(BigDecimal indiceRelativo) {
		this.indiceRelativo = indiceRelativo;
	}



	public Date getDataValidazione() {
		return dataValidazione;
	}



	public void setDataValidazione(Date dataValidazione) {
		this.dataValidazione = dataValidazione;
	}



	public String getDataValidazioneString() {
		return dataValidazioneString;
	}



	public void setDataValidazioneString(String dataValidazioneString) {
		this.dataValidazioneString = dataValidazioneString;
	}



	public StoricoGraduatoriaId getIdKey() {
		return idKey;
	}



	public void setIdKey(StoricoGraduatoriaId idKey) {
		this.idKey = idKey;
	}



	public String getColorExAequo() {
		return colorExAequo;
	}



	public void setColorExAequo(String colorExAequo) {
		this.colorExAequo = colorExAequo;
	}



	

	
	
	
}