package com.accenture.CCFarm.valutazioneEsercizioProf;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.accenture.CCFarm.Bean.Ruolo;
import com.accenture.CCFarm.DAO.CandidaturaReg;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.EsercizioProfReg;
import com.accenture.CCFarm.DAO.EsercizioProfRegHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.RequisitiMinimiReg;
import com.accenture.CCFarm.DAO.RequisitiMinimiRegHome;
import com.accenture.CCFarm.DAO.ValoriCodice;
import com.accenture.CCFarm.DAO.ValoriCodiceHome;
import com.accenture.CCFarm.DAO.ValutazioneEsercizioProf;
import com.accenture.CCFarm.DAO.ValutazioneEsercizioProfHome;
import com.accenture.CCFarm.DAO.ValutazioneEsercizioProfId;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CaricaRuoli;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.punteggi.esperienze.RisultatiValutazioneEsperienze;
import com.accenture.punteggi.esperienze.RisultatiValutazioneEsperienze.Periodo;
import com.accenture.punteggi.esperienze.bean.in.EsperienzaOriginal;
import com.accenture.punteggi.esperienze.ordina.out.oggetti.TreeSetEsperienze;




public class ValutazioneCalcoloEspProf {

	private List<Ruolo> ruoli;
	private HashMap hmRuoli= null;
	private Iterator<com.accenture.punteggi.esperienze.bean.out.EsperienzaOut> iteratorEsperienze = null;
	private TreeSetEsperienze esperienze = new TreeSetEsperienze();
	private String osservazioni = "";
	private HashMap hmOsservaUnica = new HashMap();
	
	SimpleDateFormat fs = new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss");

	private static final Logger log = CommonLogger.getLogger("ValutazioneCalcoloEspProf");

	public ValutazioneCalcoloEspProf() {
		// TODO Auto-generated constructor stub
	}

	public Graduatoria valutaEspCandidato(String idUtente, Session dbSession) throws GestioneErroriException {

		// Recupero i vecchi voti e pulisco la tabella
		ValutazioneEsercizioProf esperienzaProf = new ValutazioneEsercizioProf();
		ValutazioneEsercizioProfId idEsperienzaProf = new ValutazioneEsercizioProfId();
		List<ValutazioneEsercizioProf> listProf = new ArrayList<ValutazioneEsercizioProf>();
		ValutazioneEsercizioProfHome valutazioneEsercizioProfHome = new ValutazioneEsercizioProfHome();

		idEsperienzaProf.setIdUtente(idUtente);
		esperienzaProf.setIdKey(idEsperienzaProf);
		esperienzaProf.setIdUtente(idUtente);
		listProf = valutazioneEsercizioProfHome.findByExample(esperienzaProf);
		if (listProf != null && listProf.size() > 0) {
			for (ValutazioneEsercizioProf valutazioneEsercizioProf : listProf) {
				valutazioneEsercizioProfHome.delete(valutazioneEsercizioProf);
				// dbSession.delete(valutazioneEsercizioProf);
				/*************************************************************/
			}
		}

		// Canidatura utente
		CandidaturaReg candidaturaReg = new CandidaturaReg();
		CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
		candidaturaReg = candidaturaRegHome.findById(idUtente);

		// RecuperaProtocollo recuperaProtocollo = new RecuperaProtocollo();
		RisultatiValutazioneEsperienze risultato = new RisultatiValutazioneEsperienze();
		Graduatoria graduatoria = new Graduatoria();
		// recupero codice ruoli
		if (hmRuoli == null)
			recuperaRuoli();
		EsercizioProfReg esercizioProfReg = new EsercizioProfReg();
		EsercizioProfRegHome esercizioProfRegHome = new EsercizioProfRegHome();
		List<EsercizioProfReg> listEsercizio = new ArrayList<EsercizioProfReg>();
		esercizioProfReg.setIdDomandaEs(idUtente);
		listEsercizio = esercizioProfRegHome.findByExample(esercizioProfReg);
		ArrayList<EsperienzaOriginal> listEsp = new ArrayList<EsperienzaOriginal>();
		try {

			// ciclo per il calcolo delle esperienze professionali
			for (EsercizioProfReg esercizio : listEsercizio) {

				EsperienzaOriginal espOr = new EsperienzaOriginal();
				//
				String descRuolo = (String) hmRuoli.get(esercizio.getCodRuoloEs());

				String codiceCategoria = descRuolo.substring(5, 6);
				espOr.setCodiceCategoria(codiceCategoria);

				if (esercizio.getCodModalitaEs().equals("0"))
					espOr.setCodiceModalita("P");
				else
					espOr.setCodiceModalita("F");
				if (esercizio.getFlagFarmRurale() != null && esercizio.getFlagFarmRurale().equals("Si"))
					espOr.setRurale(true);
				else
					espOr.setRurale(false);
				espOr.setDataInizio(esercizio.getDataInizioEs());
				espOr.setDataFine(esercizio.getDataFineEs());

				String ruoloStringa = descRuolo.substring(7, descRuolo.length());
				espOr.setRuolo(ruoloStringa);

				listEsp.add(espOr);

				// osservazione
				// o_02 Esperienza all'estero
				if (esercizio.getFlagEsteroEs() != null && esercizio.getFlagEsteroEs().equalsIgnoreCase("true")) {
					if (!hmOsservaUnica.containsKey("o_02")) {
						hmOsservaUnica.put("o_02", "");
						osservazioni += " | o_02";
					}
				}

			}
			if (!listEsp.isEmpty()) {
				// calcolo del punteggio delle esperienze professionali
				try {
					risultato = com.accenture.punteggi.esperienze.CalcoloPunteggi.calcola(listEsp);
				} catch (Exception e) {
					throw new GestioneErroriException("Simulazione calcolo errato");
				}
				if (!risultato.equals("")) {

					/*******************************************************************************************************************************************
					 * Il pezzo sotto probabilmente non serve basta salvare solo
					 * il risultato totale per ogni utente commentare tutto e
					 * cambiare il saveOrUpdate passando solo il tottale del
					 * punteggio calcolato per singolo candidato.
					 ******************************************************************************************************************************************/

					int counter = 0;
					for (Periodo periodo : risultato.getArrayPeriodi()) {

						// counter=0;
						while (periodo.hasNextEsperienza()) {
							counter++;
							com.accenture.punteggi.esperienze.bean.out.EsperienzaOut eOut = new com.accenture.punteggi.esperienze.bean.out.EsperienzaOut();
							ValutazioneEsercizioProf prof = new ValutazioneEsercizioProf();
							ValutazioneEsercizioProfId idProf = new ValutazioneEsercizioProfId();

							idProf.setIdUtente(idUtente);
							idProf.setProgressivoEspUtente("" + counter);
							prof.setIdKey(idProf);
							prof.setIdCandidatura(candidaturaReg.getIdCandidatura());
							prof.setDataInizio(DateUtil.utilDateToSQLDate(StringUtil.stringToDate(periodo.getDataDa(), "dd-MM-yyyy")));
							prof.setDataFine(DateUtil.utilDateToSQLDate(StringUtil.stringToDate(periodo.getDataA(), "dd-MM-yyyy")));
							prof.setGiorniPeriodo(new BigDecimal(periodo.getGiorniAnni()[0] + periodo.getGiorniAnni()[1]));
							String votoPuroPeriodo = periodo.getVotoPuroPeriodoFormatted().replace(",", ".");
							prof.setPuntiPeriodo(new BigDecimal(votoPuroPeriodo));
							String maggiorazionePuraPeriodo = periodo.getMaggiorazionePuraPeriodoFormatted().replace(",", ".");
							prof.setMaggiorazionePeriodo(new BigDecimal(maggiorazionePuraPeriodo));

							eOut = periodo.getNextEsperienza();
							prof.setCodiceCategoria(eOut.getCodiceCategoria());
							prof.setDescrizioneRuaolo(eOut.getRuolo());
							ValoriCodice codice = new ValoriCodice();
							ValoriCodiceHome codiceHome = new ValoriCodiceHome();
							codice.setDescrizione("Cat. " + eOut.getCodiceCategoria() + ":" + eOut.getRuolo());
							List<ValoriCodice> listCod = new ArrayList<ValoriCodice>();
							listCod = codiceHome.findByExample(codice);
							prof.setCodiceRuaolo(listCod.get(0).getCodice() == null ? " " : listCod.get(0).getCodice());
							prof.setCodiceModalita(eOut.getCodiceModalita());
							if (eOut.isRurale())
								prof.setRurale("SI");
							else
								prof.setRurale("NO");

							double votoSingolo = Math.floor(((eOut.getVotiInterni()[0] * (periodo.getGiorniAnni()[0] + periodo.getGiorniAnni()[1])) / 365d) * 10000d) / 10000d;
							prof.setPuntiCategoria(new BigDecimal(votoSingolo));
							prof.setPuntiCatGiornoSingolo(new BigDecimal(eOut.getVotiInterni()[0]));

							double votoMaggSingolo = Math.floor(((eOut.getVotiInterni()[1] * (periodo.getGiorniAnni()[0] + periodo.getGiorniAnni()[1])) / 365d) * 10000d) / 10000d;
							prof.setMaggiorazioneCategoria(new BigDecimal(votoMaggSingolo));
							prof.setMaggiorazioneCatGiornoSingolo(new BigDecimal(eOut.getVotiInterni()[0]));

							prof.setElabCommissione("N");

							// valutazioneEsercizioProfHome.saveOrUpdate(prof);
							/****************************************************************************************
							 * Per il saveOrUpdate sotto verificare quanto detto
							 * nel commento sopra
							 ****************************************************************************************/
							dbSession.saveOrUpdate(prof);
							controllaOsservazioni(idUtente, prof);

							// if (counter>2) throw new Exception();
						}
					}

					/*************************************************************************************************
					 * Per quanto detto nel commento sopra qua si dovrebbe
					 * mettere un saveOrUpdate per salvare il punteggio del
					 * singolo candidato. Si deve cambuare la tabella Dao e hbm
					 * della tab in cui savlare i punteggi di ogni eperienza.
					 ************************************************************************************************/

					graduatoria.setOsservazioni(osservazioni);
					graduatoria.setPunteggioEsperienza(new BigDecimal(risultato.getVotoFinale() == null ? "0" : risultato.getVotoFinale().replace(",", ".")));
				} else {
					graduatoria.setOsservazioni("");
					graduatoria.setPunteggioEsperienza(new BigDecimal(0));
				}
			}else {
				graduatoria.setOsservazioni("");
				graduatoria.setPunteggioEsperienza(new BigDecimal(0));
			}
		} catch (Exception e) {
			log.error("Valutazione fallita per l'utente con id : " + idUtente, e);
			throw new GestioneErroriException("ValutazioneEsercizioProf - saveOrUpdate: errore saveOrUpdate");
		}
		return graduatoria;

	}

	public boolean hasNextEsperienza() {
		if (iteratorEsperienze == null)
			iteratorEsperienze = esperienze.iterator();
		return iteratorEsperienze.hasNext();
	}

	public com.accenture.punteggi.esperienze.bean.out.EsperienzaOut getNextEsperienza() {
		return iteratorEsperienze.next();
	}

	public void controllaOsservazioni(String idutente, ValutazioneEsercizioProf prof) throws GestioneErroriException {
		// o_01 Esperienza antecedente alla prima iscrizione all'albo
		RequisitiMinimiReg minimi = new RequisitiMinimiReg();
		RequisitiMinimiRegHome minimiHome = new RequisitiMinimiRegHome();
		minimi = minimiHome.findById(idutente);

		int dataIni = trasformaData(prof.getDataInizio());
		int dataFin = trasformaData(prof.getDataFine());
		int dataAlbo = trasformaData(minimi.getDataAlbo());
		if (dataAlbo >= dataIni && dataAlbo <= dataFin) {
			if (!hmOsservaUnica.containsKey("o_01")) {
				hmOsservaUnica.put("o_01", "");
				osservazioni += " | o_01";
			}
		}
		// o_11 Data inizio dell'esperienza professionale immediatamente
		// successiva alla data di prima iscrizione all'albo
		int dataAlboPiuUno = calcolaData(minimi.getDataAlbo());
		if (dataIni == dataAlboPiuUno) {
			if (!hmOsservaUnica.containsKey("o_11")) {
				hmOsservaUnica.put("o_11", "");
				osservazioni += " | o_11";
			}
		}

	}

	private void recuperaRuoli() throws GestioneErroriException {
		ruoli = CaricaRuoli.getRuoli();
		hmRuoli = new HashMap();

		for (int i = 0; i < ruoli.size(); i++) {
			Ruolo ruolo = new Ruolo();
			ruolo = ruoli.get(i);
			hmRuoli.put(ruolo.getCodice(), ruolo.getDescrizione());
		}

	}

	// restituisce il numero passato come argomento, arrotondato e tagliato alla
	// n-esima cifra decimale
	private static double roundToNDecimal(double number, int n) {
		int shift = (int) Math.pow(10, n);
		return Math.round((double) (number * shift)) / (double) shift;
	}

	public HashMap getHmRuoli() {
		return hmRuoli;
	}

	public void setHmRuoli(HashMap hmRuoli) {
		this.hmRuoli = hmRuoli;
	}

	public List<Ruolo> getRuoli() {
		return ruoli;
	}

	public void setRuoli(List<Ruolo> ruoli) {
		this.ruoli = ruoli;
	}

	private int trasformaData(Date data) {
		String dataString = fs.format(data);
		String dataConfert = dataString.substring(6, 10) + dataString.substring(3, 5) + dataString.substring(0, 2);
		return Integer.parseInt(dataConfert);
	}

	private int recuperaOra(Date data) {
		String dataString = StringUtil.dateToString(data, sdf);
		String dataConfert = dataString.substring(13, 15) + dataString.substring(16, 18) + dataString.substring(19, 21);
		return Integer.parseInt(dataConfert);
	}

	private int trasformaDataSting(String data) {
		// String dataString = fs.format(data);
		String dataConfert = data.substring(6, 10) + data.substring(3, 5) + data.substring(0, 2);
		return Integer.parseInt(dataConfert);
	}

	private int calcolaData(Date data) {
		String dataGregorian = StringUtil.dateToString(data, sdf);

		Calendar cal = Calendar.getInstance();
		String result = "";
		try {
			cal.setTime(data);
			cal.add(Calendar.DATE, +1);
			result = StringUtil.dateToString(cal.getTime(), sdf);
		} catch (Exception e) {
		}

		return trasformaDataSting(result);
	}

	private static String dataTOString(Date w_date) {
		Calendar cal = Calendar.getInstance();
		String result = "";
		try {
			cal.setTime(w_date);
			cal.add(Calendar.DATE, -9);

			// Set time fields to zero
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			SimpleDateFormat formatterOut = new SimpleDateFormat("dd-MM-yyyy");
			result = formatterOut.format(cal.getTime());

		} catch (Exception e) {
		}
		return result;

	}
	
}
