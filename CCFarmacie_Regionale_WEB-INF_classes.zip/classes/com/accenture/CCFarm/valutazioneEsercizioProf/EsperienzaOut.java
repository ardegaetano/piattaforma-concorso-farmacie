package com.accenture.CCFarm.valutazioneEsercizioProf;

import java.util.Date;

import com.accenture.punteggi.esperienze.utils.DateUtils;

public class EsperienzaOut implements Comparable<EsperienzaOut>
{

    private String codiceCategoria = ""; //categoria del ruolo da A ad E
    private boolean rurale = false;
    private String ruolo = "";
    private String codiceModalita = ""; //P o F
    private Date dataGiorno = null;

    private int idEsperienza = 0;
    
    private double votiInterni[] = {0d,0d};

    
    
    public double[] getVotiInterni()
    {
        return votiInterni;
    }

    public void setVotiInterni(double[] votiInterni)
    {
        this.votiInterni = votiInterni;
    }

    public String getRuolo()
    {
	return ruolo;
    }

    public void setRuolo(String ruolo)
    {
	this.ruolo = ruolo;
    }

    public String getCodiceCategoria()
    {
	return codiceCategoria;
    }

    public void setCodiceCategoria(String codiceCategoria)
    {
	this.codiceCategoria = codiceCategoria;
    }

    public boolean isRurale()
    {
	return rurale;
    }

    public void setRurale(boolean rurale)
    {
	this.rurale = rurale;
    }

    public String getCodiceModalita()
    {
	return codiceModalita;
    }

    public void setCodiceModalita(String codiceModalita)
    {
	this.codiceModalita = codiceModalita;
    }

    public int getIdEsperienza()
    {
	return idEsperienza;
    }

    public void setIdEsperienza(int idEsperienza)
    {
	this.idEsperienza = idEsperienza;
    }

    public Date getDataGiorno()
    {
	return dataGiorno;
    }

    public void setDataGiorno(Date dataGiorno)
    {
	this.dataGiorno = dataGiorno;
    }

    @Override
    public int compareTo(EsperienzaOut o)
    {
	int retVal = 0;
	if (codiceCategoria.compareTo(o.getCodiceCategoria()) < 0)
	{
	    retVal = -100000000;
	}
	else if (codiceCategoria.equals(o.getCodiceCategoria()))
	{
	    if (codiceModalita.equals(o.getCodiceModalita()))
	    {
		retVal = 0;
	    }
	    else if (o.getCodiceModalita().equals("P") && codiceModalita.equals("F"))
	    {
		retVal = -1000000;
	    }
	    else
		retVal = 1000000;
	}
	else
	    retVal = 100000000;

	if (retVal == 0)
	{
	    if (isRurale() && !o.isRurale())
	    {
		retVal = -10000;
	    }
	    else if (!isRurale() && o.isRurale())
		retVal = 10000;
	    else
		retVal = 0;
	}

	if (retVal == 0)
	{
	    retVal = (o.getDataGiorno()).compareTo(dataGiorno);
	    if (retVal != 0)
		retVal = 1 * retVal / Math.abs(retVal);
	}

	if (retVal == 0)
	{
	    retVal = idEsperienza - o.getIdEsperienza();
	    if (retVal != 0)
		retVal = 100 * retVal / Math.abs(retVal);
	}

	return retVal;
    }

    public int compareToNoDate(EsperienzaOut o)
    {
	int retVal = 0;
	if (codiceCategoria.compareTo(o.getCodiceCategoria()) < 0)
	{
	    retVal = 10000;
	}
	else if (codiceCategoria.equals(o.getCodiceCategoria()))
	{
	    if (codiceModalita.equals(o.getCodiceModalita()))
	    {
		retVal = 0;
	    }
	    else if (o.getCodiceModalita().equals("F") && codiceModalita.equals("P"))
	    {
		retVal = -1000;
	    }
	    else
		retVal = +1000;
	}
	else
	    retVal = -10000;

	if (retVal == 0)
	{
	    if (isRurale() && !o.isRurale())
	    {
		retVal = 100;
	    }
	}

	if (retVal == 0)
	{
	    retVal = idEsperienza - o.getIdEsperienza();
	    if (retVal != 0)
		retVal /= Math.abs(retVal);
	}

	return retVal;
    }

    @Override
    public String toString()
    {
	return DateUtils.format(dataGiorno) + "--- cat. " + codiceCategoria + " - " + " mod. " + codiceModalita + " - " + ruolo + (isRurale() ? "RURALE" : "");
    }

    public double getMaxVoto(int periodoAnno)
    {
	double retVal = 0;
	char c = codiceCategoria.charAt(0);
	switch (c)
	{
	case 'A':
	    retVal = periodoAnno == 0 ? 2.5d : 1d;
	    break;
	case 'B':
	    retVal = periodoAnno == 0 ? 2.25d : 0.9d;
	    break;
	case 'C':
	    retVal = periodoAnno == 0 ? 2d : 0.75d;
	    break;
	case 'D':
	    retVal = periodoAnno == 0 ? 1.75d : 0.5d;
	    break;
	case 'E':
	    retVal = periodoAnno == 0 ? 1.5d : 0.4;
	    break;

	default:
	    break;
	}
	return retVal;
    }

    public double[] getVoto(int periodoAnno)
    {
	double retValPuro = 0d;
	double retValRurale = 0d;
	double[] retVal = new double[2];
	if (codiceModalita.equals("P"))
	    retValPuro = getMaxVoto(periodoAnno) / 2d;
	else
	    retValPuro = getMaxVoto(periodoAnno);
	if (isRurale())
	{
	    retValRurale = retValPuro * 0.4d;
	}
	retVal[0] = retValPuro;
	retVal[1] = retValRurale;

	return retVal;
    }
}
