package com.accenture.CCFarm.captcha;

import java.awt.Image;

public class CaptchaBean {
	
	private String captchaCode;
	private Image captchaImage;
	
	public String getCaptchaCode() {
		return captchaCode;
	}
	public void setCaptchaCode(String captchaCode) {
		this.captchaCode = captchaCode;
	}
	public Image getCaptchaImage() {
		return captchaImage;
	}
	public void setCaptchaImage(Image captchaImage) {
		this.captchaImage = captchaImage;
	}	
}

