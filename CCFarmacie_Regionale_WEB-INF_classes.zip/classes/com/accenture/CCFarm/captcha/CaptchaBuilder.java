package com.accenture.CCFarm.captcha;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.font.TextLayout;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.util.Random;


public class CaptchaBuilder implements ImageObserver {

	private CaptchaBean captcha;
	//String propPath = "";
	//private static Logger log = null;
	public CaptchaBuilder(){
		
	}
	
	public boolean imageUpdate(Image img, int infoflags, int x, int y,int width,int height){
		return ( infoflags == ImageObserver.ALLBITS ) ? false : true;
	}
	
	public CaptchaBean getCaptcha(String basePath) {
		try{
		//log.info("CaptchaBean | getCaptcha | START");
		RndCaptchaText randomCaptchaText = new RndCaptchaText();
		RndColorText randomColorText = new RndColorText();
		String captchaCode = randomCaptchaText.getText();
		char[] captchaCharArray = captchaCode.toCharArray();
		captchaCode = "";
		for(int i=0; i < captchaCharArray.length; i++) {
			if((captchaCharArray[i] % 2) == 0) {
				String character = captchaCharArray[i] + "";
				captchaCharArray[i] = character.toUpperCase().toCharArray()[0]; 
			}
			captchaCode += captchaCharArray[i];
		}
		//log.info("CaptchaBean | captchaCode | END : "+captchaCode);
		Toolkit tool = Toolkit.getDefaultToolkit();
		//Image imgBackground = tool.getImage(propPath+ConstantsParameter.CAPTCHA_PATH_IMG_BACKGROUND+ConstantsParameter.CAPTCHA_IMG_BACKGROUND_NAME);
		//String imagePath =basePath+"\\WEB-INF\\classes\\resources\\bkgcc.png";
		
		String imagePath =basePath;
		
		Image imgBackground = tool.getImage(imagePath);
		
		
		//BufferedImage bi = new BufferedImage(ConstantsParameter.CAPTCHA_BACKGROUND_WIDTH, ConstantsParameter.CAPTCHA_BACKGROUND_HEIGHT,BufferedImage.TYPE_INT_ARGB);
		BufferedImage bi = new BufferedImage(120, 34,BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = bi.createGraphics();
		//log.info("CaptchaBean | imgBackground | "+imgBackground);
		
		if(imgBackground!=null && g!=null){
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		//Font font = new Font(ConstantsParameter.CAPTCHA_FONT_NAME, CaptchaUtil.getFontStyle(ConstantsParameter.CAPTCHA_FONT_STYLE), ConstantsParameter.CAPTCHA_FONT_SIZE);
		Font font = new Font("EngschriftDIND (True Type)", CaptchaUtil.getFontStyle("PLAIN"), 25);
		g.setFont(font);
		Color c = new Color(CaptchaUtil.getFontColor("000000"));
		g.setColor(c);
		long firstTime = System.currentTimeMillis();
		//log.info("CaptchaBean | firstTime | "+firstTime+" ConstantsParameter.END_CAPTCHA_TIME = "+ConstantsParameter.END_CAPTCHA_TIME);
		
		//while((System.currentTimeMillis()-firstTime)<ConstantsParameter.END_CAPTCHA_TIME && (g.drawImage(imgBackground,0,0,this)== false)){}
		while((System.currentTimeMillis()-firstTime)<5000 && (g.drawImage(imgBackground,0,0,this)== false)){}
		if(g.drawImage(imgBackground,0,0,this)== false){
			//log.warn("CaptchaBean | WHILE ERROE |");
			throw new Exception("Errore Durante il Caricamento dell'immagine Captcha");
		}
		//TextLayout tl = new TextLayout(captchaCode, g.getFont(), g.getFontRenderContext());
		//float startTextX = ConstantsParameter.CAPTCHA_TEXT_LAYOUT_X;
		float startTextX = 5;
		AffineTransform at = new AffineTransform();
		double angle = rndAngleRotation();
		Font theDerivedFont;
		at.rotate(angle);
		theDerivedFont = font.deriveFont(at);
		g.setFont(theDerivedFont);
		Color[] colori = randomColorText.getColor();
		for(int i=0; i < captchaCharArray.length; i++) {
		   TextLayout tl = new TextLayout((captchaCharArray[i] + ""), g.getFont(), g.getFontRenderContext());
		   if(i == 0) {
			   //startTextX = ConstantsParameter.CAPTCHA_TEXT_LAYOUT_X + rndFirstChar();
			   startTextX = 5 + rndFirstChar();
		   }else {
			   startTextX += rnd();
		   }
		   angle = rndAngleRotation();
		   at.rotate(angle);
		   theDerivedFont = font.deriveFont(at);
		   g.setFont(theDerivedFont);
		   g.setColor(colori[i]);
		   //tl.draw(g, startTextX, ConstantsParameter.CAPTCHA_TEXT_LAYOUT_Y);
		   tl.draw(g, startTextX, 25);
		}
		
		//tl.draw(g, startTextX, conf.getTextLayoutY());
		g.dispose();
		//log.info("CaptchaBean | captchaCode | SAVE captchaCode : "+captchaCode+"AND captchaImg");
		//salvataggio in memoria captchaImg e captchaCode
		
		captcha = new CaptchaBean();
		captcha.setCaptchaCode(captchaCode);
		captcha.setCaptchaImage(bi);
		
		
		return captcha;
		}else{
			//log.warn("CaptchaBean | IF ERROR |");
			throw new Exception();
		}
		}catch(Exception e){
			//log.warn("CaptchaBean | captchaCode | ERROR : "+e.getMessage());
			return null;
		}
	}

	private float rnd() {
		return (float) ((Math.random() * 10) + 15);
	}
	
	private float rndFirstChar() {
		return (float) ((Math.random() * 5));
	}
	
	private double rndAngleRotation() {
		try{
		//log.info("rndAngleRotation | init | START");
		int positiveOrNegative;
		Random rand = new Random();
		double radiants = (Math.PI * rand.nextInt(15)) / 180;
		positiveOrNegative = rand.nextInt(2);
		if(positiveOrNegative == 0) {
			return radiants;
		}else{
			return (-1) * radiants;}
		}catch(Exception e){
			//log.warn("rndAngleRotation | init | ERROR : "+e.getMessage());
			return 0 ;
		}
	}
}

