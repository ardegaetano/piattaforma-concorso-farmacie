package com.accenture.CCFarm.captcha;

import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class CaptchaGenerator extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	//private static Logger log = null;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.getCaptchaImage(request, response);
	}
	
	private void getCaptchaImage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//log = Logger.getLogger(CaptchaGenerator.class);
		try {
			
		//log.info("CAPTCHA GENERATOR | check | START");
		CaptchaBuilder captcha = new CaptchaBuilder();
		
        URL url = CaptchaGenerator.class.getResource("/resources/bkgcc.png");
	    
        String basePath =url.getPath();
        
		CaptchaBean c = captcha.getCaptcha(basePath);
		
		ByteArrayOutputStream bas = new ByteArrayOutputStream();
		ImageIO.write((RenderedImage) c.getCaptchaImage(),"png", bas);
		byte[] data = bas.toByteArray();
		//log.info(c.getCaptchaCode());
		//request.getSession().setAttribute(ConstantsParameter.CAPTCHACODE, c.getCaptchaCode());
		request.getSession().setAttribute("captchaCode", c.getCaptchaCode());
		//log.info("CAPTCHA GENERATOR | check | response START");
		response.setHeader("Cache-Control", "no-store");
		response.setHeader("Pragma", "no-cache");
		response.setDateHeader("Expires", 0);
		response.setContentType("image/jpeg");
		ServletOutputStream responseOutputStream = response.getOutputStream();
		//log.info("CAPTCHA GENERATOR | check | response END");
		//log.info("CAPTCHA GENERATOR | check | responseOutputStream START ");
		responseOutputStream.write(data);
		responseOutputStream.flush();
		responseOutputStream.close();
		//log.info("CAPTCHA GENERATOR | check | responseOutputStream CLOSE ");
		//log.info("CAPTCHA GENERATOR | check | END");		
		}catch (Exception e) {
		  //log.warn("CAPTCHA GENERATOR | error | END : "+e.getMessage());
		  //log.info("CAPTCHA GENERATOR | TRY TO REMOVE ATTRIBUTE | START");
		
		//request.getSession().removeAttribute(ConstantsParameter.CAPTCHACODE);
		request.getSession().removeAttribute("captchaCode");
		
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}
}

