package com.accenture.CCFarm.captcha;

import java.awt.Font;

public class CaptchaUtil {
		
	public static int getFontStyle(String style) {
		if(style.equalsIgnoreCase("PLAIN")) {
			return Font.PLAIN;
		}else if(style.equalsIgnoreCase("BOLD")) {
			return Font.BOLD;
		}else if(style.equalsIgnoreCase("ITALIC")) {
			return Font.ITALIC;
		}else {
			return Font.PLAIN;
		}
	}
	
	public static int getFontColor(String fontColor) {
		return Integer.parseInt(fontColor,16);
	}
	
}
