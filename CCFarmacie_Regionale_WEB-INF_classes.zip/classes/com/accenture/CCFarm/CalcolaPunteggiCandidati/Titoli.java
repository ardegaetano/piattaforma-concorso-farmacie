package com.accenture.CCFarm.CalcolaPunteggiCandidati;

import java.util.ArrayList;

import com.accenture.CCFarm.DAO.AltraLaureaBisReg;
import com.accenture.CCFarm.DAO.AltraLaureaReg;
import com.accenture.CCFarm.DAO.AltroTitoloReg;
import com.accenture.CCFarm.DAO.BorsaStudioReg;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoReg;
import com.accenture.CCFarm.DAO.DottoratoReg;
import com.accenture.CCFarm.DAO.IdoneitaReg;
import com.accenture.CCFarm.DAO.PubblicazioneReg;
import com.accenture.CCFarm.DAO.RequisitiMinimiReg;
import com.accenture.CCFarm.DAO.SpecializzazioneReg;




public class Titoli {

	private String referente;
	private String idUtente;
	private String idCandidatura;
	private String nome;
	private String cognome;
	private AltraLaureaReg altraLaurea;
	private  ArrayList<AltraLaureaBisReg> altraLaureaBisList;
	private  ArrayList<AltroTitoloReg> altroTitoloList;
	private  ArrayList<BorsaStudioReg> borsaStudioList;
	private  ArrayList<CorsoAggiornamentoReg> corsoAggiornamentoList;
	private  ArrayList<DottoratoReg> dottoratoList;
	private  ArrayList<IdoneitaReg> idoneitaList;
	private  ArrayList<PubblicazioneReg> pubblicazioneList;
	private RequisitiMinimiReg requisitiMinimi;
	private  ArrayList<SpecializzazioneReg> specializzazioneList;
	private String votoPrimi10Anni;
	private String votoSecondi10Anni;
	
	public Titoli(){
	
		idUtente=null;
		idCandidatura=null;
		altraLaurea = new AltraLaureaReg();
		altraLaureaBisList = new ArrayList<AltraLaureaBisReg>();
		altroTitoloList = new ArrayList<AltroTitoloReg>();
		borsaStudioList = new ArrayList<BorsaStudioReg>();
		corsoAggiornamentoList = new ArrayList<CorsoAggiornamentoReg>();
		dottoratoList = new ArrayList<DottoratoReg>();
		idoneitaList = new ArrayList<IdoneitaReg>();
		pubblicazioneList = new ArrayList<PubblicazioneReg>();
		requisitiMinimi = new RequisitiMinimiReg();
		specializzazioneList = new ArrayList<SpecializzazioneReg>();
		
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public String getIdCandidatura() {
		return idCandidatura;
	}

	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}

	public AltraLaureaReg getAltraLaurea() {
		return altraLaurea;
	}

	public void setAltraLaurea(AltraLaureaReg altraLaurea) {
		this.altraLaurea = altraLaurea;
	}

	public ArrayList<AltraLaureaBisReg> getAltraLaureaBisList() {
		return altraLaureaBisList;
	}

	public void setAltraLaureaBisList(
			ArrayList<AltraLaureaBisReg> altraLaureaBisList) {
		this.altraLaureaBisList = altraLaureaBisList;
	}

	public ArrayList<AltroTitoloReg> getAltroTitoloList() {
		return altroTitoloList;
	}

	public void setAltroTitoloList(ArrayList<AltroTitoloReg> altroTitoloList) {
		this.altroTitoloList = altroTitoloList;
	}

	public ArrayList<BorsaStudioReg> getBorsaStudioList() {
		return borsaStudioList;
	}

	public void setBorsaStudioList(ArrayList<BorsaStudioReg> borsaStudioList) {
		this.borsaStudioList = borsaStudioList;
	}

	public ArrayList<CorsoAggiornamentoReg> getCorsoAggiornamentoList() {
		return corsoAggiornamentoList;
	}

	public void setCorsoAggiornamentoList(
			ArrayList<CorsoAggiornamentoReg> corsoAggiornamentoList) {
		this.corsoAggiornamentoList = corsoAggiornamentoList;
	}

	public ArrayList<DottoratoReg> getDottoratoList() {
		return dottoratoList;
	}

	public void setDottoratoList(ArrayList<DottoratoReg> dottoratoList) {
		this.dottoratoList = dottoratoList;
	}

	public ArrayList<IdoneitaReg> getIdoneitaList() {
		return idoneitaList;
	}

	public void setIdoneitaList(ArrayList<IdoneitaReg> idoneitaList) {
		this.idoneitaList = idoneitaList;
	}

	public ArrayList<PubblicazioneReg> getPubblicazioneList() {
		return pubblicazioneList;
	}

	public void setPubblicazioneList(ArrayList<PubblicazioneReg> pubblicazioneList) {
		this.pubblicazioneList = pubblicazioneList;
	}

	public RequisitiMinimiReg getRequisitiMinimi() {
		return requisitiMinimi;
	}

	public void setRequisitiMinimi(RequisitiMinimiReg requisitiMinimi) {
		this.requisitiMinimi = requisitiMinimi;
	}

	public ArrayList<SpecializzazioneReg> getSpecializzazioneList() {
		return specializzazioneList;
	}

	public void setSpecializzazioneList(
			ArrayList<SpecializzazioneReg> specializzazioneList) {
		this.specializzazioneList = specializzazioneList;
	}

	public String getVotoPrimi10Anni() {
		return votoPrimi10Anni;
	}

	public void setVotoPrimi10Anni(String votoPrimi10Anni) {
		this.votoPrimi10Anni = votoPrimi10Anni;
	}

	public String getVotoSecondi10Anni() {
		return votoSecondi10Anni;
	}

	public void setVotoSecondi10Anni(String votoSecondi10Anni) {
		this.votoSecondi10Anni = votoSecondi10Anni;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getReferente() {
		return referente;
	}

	public void setReferente(String referente) {
		this.referente = referente;
	}

	
	
}
