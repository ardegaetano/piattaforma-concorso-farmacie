package com.accenture.CCFarm.CalcolaPunteggiCandidati;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;

import com.accenture.CCFarm.Bean.UtenteBean;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.UtenteRegHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RecuperaProtocollo;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.valutazioneEsercizioProf.ValutazioneCalcoloEspProf;




public class PunteggioCandidato {
	//metodo verso l'esterno per la valutazione punteggi del candidato - necessita solo dell'ID utente
	public void calcolaGraduatoriaUtente(String idUtente, String codiceRegione,DatiBando datiBando, Session DBsession, String idStorico, String miUtente, Timestamp oggi) throws GestioneErroriException {
		// ricava dati utente a partire dall'ID
		UtenteBean utente = new UtenteRegHome().getUtenteBeanValutazioni(idUtente);

		if (utente != null) {
			try {
				calcolaGraduatoriaUtente(utente, codiceRegione,datiBando, DBsession, idStorico, miUtente, oggi);
			} catch (Exception e) {
				LogUtil.printException(e);
				throw new GestioneErroriException("Eccezione in calcolaGraduatoriaUtente - ID utente: " + idUtente);
			}
		}
	}
			
			//calcola la valutazione per l'utente specificato (titoli ed esperienze professionali) e aggiorna la graduatoria
			//parametri:
			//				1. utente: istanza della classe UtenteBean che contiene i dati del candidato
			//				2. codiceRegione: codice della regione in cui � registrata l'utenza
			//				3. DBSession: sessione del database (auspicabilmente in transazione) tramite la quale leggere/aggiornare i dati
			private void calcolaGraduatoriaUtente(UtenteBean utente, String codiceRegione,DatiBando datiBando, Session DBsession, String idStorico, String miUtente, Timestamp oggi) throws GestioneErroriException {
				// ValutazioneTitoliRegione valutazioneTitoliRegione = new
				// ValutazioneTitoliRegione(); //serve ancora?
				// BigDecimal punteggioTitolo = new BigDecimal(0); //serve ancora?
				
				Date dataFineBando = datiBando.getDataFineBando();
		        SimpleDateFormat sdf = new SimpleDateFormat();
				Graduatoria graduatoriaTitoli = new ElaborazioneTitoliRegione().elaborazioneTitoliPerRegione(utente.getIdUtente(), codiceRegione,datiBando, DBsession);

				graduatoriaTitoli.setIdCandidatura(utente.getIdCandidatura());
				graduatoriaTitoli.setNumeroProtocollo(new RecuperaProtocollo().getProtocolloRegionale(utente.getIdCandidatura()));

				// mi serve anche l'utente per controllare data rilascio doc e
				// dt_nascita in piu il nome e cognome utente
				// elaborazione delle osservazioni relative a dati dell'utente
				String osservazioni = "";
				if (utente.getDataNascita() != null && utente.getDataRilascioDoc() != null) {
					if (utente.getDataNascita().compareTo(utente.getDataRilascioDoc()) == 0) {
						osservazioni = graduatoriaTitoli.getOsservazioni() == null ? "" : graduatoriaTitoli.getOsservazioni();
						osservazioni += " | o_07";
						graduatoriaTitoli.setOsservazioni(osservazioni);
					}
				}

				// Calcolo i punteggi e la graduatoria parziale relativa alle esperienze professionali.
				Graduatoria graduatoriaEsperienze =null;
				if(utente.getModalitaCandidatura().equalsIgnoreCase("A")){
					graduatoriaEsperienze = new Graduatoria();
				}else{
					 graduatoriaEsperienze = new ValutazioneCalcoloEspProf().valutaEspCandidato(utente.getIdUtente(), DBsession);
				}
				
				// Sommo la graduatoria delle esperienze Prof e quelle dei Titoli (merge
				// tra valutazione titoli e valutazione esperienze professionali)
				Graduatoria graduatoriaTotaleUtente = graduatoriaTitoli;
				// Setto le osservazioni totali
				if (graduatoriaTitoli.getOsservazioni() == null) {
					graduatoriaTitoli.setOsservazioni("");
				}
				if (graduatoriaEsperienze.getOsservazioni() == null) {
					graduatoriaEsperienze.setOsservazioni("");
				}
				if (!graduatoriaTitoli.getOsservazioni().equals("") || !graduatoriaEsperienze.getOsservazioni().equals("")) {
					String nomeUtente = utente.getNomeUtente() + " " + utente.getCognomeUtente();
					osservazioni = nomeUtente + graduatoriaTitoli.getOsservazioni() + graduatoriaEsperienze.getOsservazioni() + " # ";
				}
				graduatoriaTotaleUtente.setOsservazioni(osservazioni);
				graduatoriaTotaleUtente.setPunteggioEsperienza(graduatoriaEsperienze.getPunteggioEsperienza());

				java.util.Date dataSys = new java.util.Date();
				graduatoriaTotaleUtente.setDataIstruttoria(new java.sql.Timestamp(dataSys.getTime()));

				if (utente.getIdCandidatura().equals(utente.getIdUtente())) {

					graduatoriaTotaleUtente.setCognome(utente.getCognomeUtente().toUpperCase());
					graduatoriaTotaleUtente.setNome(utente.getNomeUtente().toUpperCase());
				}
				
				sdf = new SimpleDateFormat("dd-MM-yyyy");
				graduatoriaTotaleUtente.setDataNascita(StringUtil.dateToString(utente.getDataNascita(),sdf));
			

				// Aggiorna la graduatoria
//				new GestisciGraduatoria().aggiornaGraduatoria(graduatoriaTotaleUtente, utente.getModalitaCandidatura(), dataFineBando, DBsession);
				new GestisciGraduatoria().aggiornaGraduatoria_newP(graduatoriaTotaleUtente, utente.getModalitaCandidatura(), dataFineBando, DBsession, idStorico, miUtente, oggi);
				
			}

		
}
