package com.accenture.CCFarm.CalcolaPunteggiCandidati;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.Clob;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.hibernate.Hibernate;
import org.hibernate.Session;

import com.accenture.CCFarm.DAO.AltraLaureaBisReg;
import com.accenture.CCFarm.DAO.AltraLaureaBisRegHome;
import com.accenture.CCFarm.DAO.AltraLaureaReg;
import com.accenture.CCFarm.DAO.AltraLaureaRegHome;
import com.accenture.CCFarm.DAO.AltroTitoloReg;
import com.accenture.CCFarm.DAO.AltroTitoloRegHome;
import com.accenture.CCFarm.DAO.BorsaStudioReg;
import com.accenture.CCFarm.DAO.BorsaStudioRegHome;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoReg;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoRegHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DottoratoReg;
import com.accenture.CCFarm.DAO.DottoratoRegHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.IdoneitaReg;
import com.accenture.CCFarm.DAO.IdoneitaRegHome;
import com.accenture.CCFarm.DAO.PubblicazioneReg;
import com.accenture.CCFarm.DAO.PubblicazioneRegHome;
import com.accenture.CCFarm.DAO.RequisitiMinimiReg;
import com.accenture.CCFarm.DAO.RequisitiMinimiRegHome;
import com.accenture.CCFarm.DAO.SpecializzazioneReg;
import com.accenture.CCFarm.DAO.SpecializzazioneRegHome;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.DAO.UtenteReg;
import com.accenture.CCFarm.DAO.UtenteRegHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.DecodoficaVoti;
import com.accenture.CCFarm.utility.StringUtil;

public class ElaborazioneTitoliRegione {

	private HashMap<String, BigDecimal> decodificaVotiLaurea = new HashMap<String, BigDecimal>();

	private HashMap<String, BigDecimal> decodificaVotiAbilitazione = new HashMap<String, BigDecimal>();

	private BigDecimal punteggioLaurea = new BigDecimal(0);

	//private BigDecimal punteggioAbilitazione = new BigDecimal(0);

	private BigDecimal punteggioAltraLaurea = new BigDecimal(0);

	private BigDecimal punteggioAltraLaureaBis = new BigDecimal(0);

	private BigDecimal punteggioIdoneita = new BigDecimal(0);

	private BigDecimal punteggioIdoneitaNazionale = new BigDecimal(0);
	
	private BigDecimal punteggioC = new BigDecimal(0);
	
	private BigDecimal punteggioPubblicazioni = new BigDecimal(0);
	
	private BigDecimal punteggioH = new BigDecimal(0);

	private BigDecimal totaleUtente = new BigDecimal(0);

	private BigDecimal etaMedia = new BigDecimal(0);

	private String osservazioni;

	private AltraLaureaRegHome altraLaureaRegHome = null;

	private AltraLaureaReg altraLaureaReg = null;

	private AltraLaureaBisRegHome altraLaureaBisRegHome = null;

	private ArrayList<AltraLaureaBisReg> altraLaureaBisRegList = null;

	private RequisitiMinimiRegHome requisitiMinimiHome = null;

	private RequisitiMinimiReg requisitiMinimiReg = null;

	private IdoneitaRegHome idoneitaRegHome = null;

	private IdoneitaReg idoneitaReg = null;
	
	private List<SpecializzazioneReg> specializzazioneReg;
	
	private SpecializzazioneRegHome specializzazioneRegHome;
	
	private List<BorsaStudioReg> borsaStudioReg;
	
	private BorsaStudioRegHome borsaStudioRegHome;
	
	private List<DottoratoReg> dottoratoReg;
	
	private DottoratoRegHome dottoratoRegHome;
	
	private List<AltroTitoloReg> altroTitoloReg;
	
	private AltroTitoloRegHome altroTitoloRegHome;
	
	private List<PubblicazioneReg> pubblicazioneReg;
	
	private PubblicazioneRegHome pubblicazioneRegHome;
	
	private List<CorsoAggiornamentoReg> corsoAggiornamentoReg;
	
	private CorsoAggiornamentoRegHome corsoAggiornamentoRegHome;

	private int dataAlbo;

	private int dataAbilitazione;

	private static Properties paramProperties = new Properties();

	private Clob note = null;

	public Graduatoria elaborazioneTitoliPerRegione(String idUtente, String codiceRegione,DatiBando datiBando, Session session) throws GestioneErroriException {

		Graduatoria graduatoria = new Graduatoria();
		osservazioni = "";

		try {

			// recupero le tabelle di decodificavoti per requisitiminimi
			decodificaVotiLaurea = DecodoficaVoti.getCriteriPunteggiLaurea(codiceRegione);

			decodificaVotiAbilitazione = DecodoficaVoti.getCriteriPunteggiVotoAbilitazione(codiceRegione);
			// fine recupero tabelle di decodifica

			// inizio valutazione
			punteggioLaurea = valutazioneLaurea(idUtente, session);
			graduatoria.setPunteggioLaurea(punteggioLaurea);

			punteggioH = valutazioneAbilitazione(idUtente, session);
			graduatoria.setPunteggioAbilitazioneCorsiAggAltriTitoli(punteggioH);

			punteggioAltraLaurea = valutazioneAltraLaurea(idUtente);
			graduatoria.setPunteggioAltraLaurea(punteggioAltraLaurea);

			punteggioAltraLaureaBis = valutazioneAltraLaureaBis(idUtente);
			graduatoria.setPunteggioAltraLaureaBis(punteggioAltraLaureaBis);

			punteggioIdoneita = valutazioneIdoneita(idUtente, session);
			graduatoria.setPunteggioIdoneita(punteggioIdoneita);

			punteggioIdoneitaNazionale = valutazioneIdoneitaNazionale(idUtente, session);
			graduatoria.setPunteggioIdoneitaNazionale(punteggioIdoneitaNazionale);
			
			valutazioneC(idUtente, session);
			graduatoria.setPunteggioSpecDottBorse(punteggioC);
			
			valutazionePubblicazioni(idUtente, session);
			graduatoria.setPunteggioPubblicazione(punteggioPubblicazioni);
			// fine valutazione

			// somma i parziali e genera totala da settare in graduatoria
			totaleUtente = new BigDecimal(0);
			totaleUtente = totaleUtente.add(punteggioAltraLaurea).add(punteggioLaurea).add(punteggioIdoneita).add(punteggioIdoneitaNazionale).add(punteggioAltraLaureaBis).add(punteggioH).add(punteggioC).add(punteggioPubblicazioni);

			if (totaleUtente.compareTo(new BigDecimal(15))> 0) {
				graduatoria.setPunteggio(new BigDecimal(15));
			} else {
				graduatoria.setPunteggioTitolo(totaleUtente);
			}

			Date dataScadenzaBando=datiBando.getDataFineBando();
			
			etaMedia = calcoloEtaMedia(idUtente,dataScadenzaBando,session);
			
			graduatoria.setEtaMedia(etaMedia);

			graduatoria.setOsservazioni(osservazioni);

			graduatoria.setNote(note);
			
			graduatoria.setCodRegione(codiceRegione);

		} catch (Exception e) {

			e.printStackTrace();
			throw new GestioneErroriException("elaborazioneTitoliPerRegione : errore");
		}

		return graduatoria;

	}

	private BigDecimal valutazioneLaurea(String idUtente, Session session) throws GestioneErroriException {
		BigDecimal result = new BigDecimal(0);
		try {

			String votoLaurea = "";
			requisitiMinimiHome = new RequisitiMinimiRegHome();
			requisitiMinimiReg = requisitiMinimiHome.findById(idUtente);

			if (requisitiMinimiReg.getFlgElabManualeLaurea() == null || !requisitiMinimiReg.getFlgElabManualeLaurea().equalsIgnoreCase("true")) {

				// punteggio Laurea
				votoLaurea = requisitiMinimiReg.getVotoLaurea();
				if (votoLaurea != null && votoLaurea.equals("110")) {

					if (requisitiMinimiReg.getFlagLode() != null && requisitiMinimiReg.getFlagLode().equals("true")) {

						if (paramProperties.isEmpty()) {

							paramProperties =  AppProperties.getAppProperties();
						}

						votoLaurea = paramProperties.getProperty("votoLode");

					}

				}
				
				//SETTAGGIO VALORE ESCLUSO per impedire la sovrascrittura accidentale del punteggio con valori errati
				//requisitiMinimiReg.setPunteggioLaurea(decodificaVotiLaurea.get(votoLaurea) == null ? new BigDecimal(0) : decodificaVotiLaurea.get(votoLaurea));
			}
			
			//SALVATAGGIO ESCLUSO per impedire la sovrascrittura accidentale del punteggio con valori errati
			//session.saveOrUpdate(requisitiMinimiReg);
			// requisitiMinimiHome.saveOrUpdate(requisitiMinimiReg);
			
			result = result.add(requisitiMinimiReg.getPunteggioLaurea());
			if(result.compareTo(new BigDecimal("5.0000"))>0){
				result = new BigDecimal("5.0000");
			}
			// controllo le osservazioni
			if (requisitiMinimiReg.getVotoLaurea() == null || requisitiMinimiReg.getVotoLaurea().equals(""))
				osservazioni += " | o_03";

		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new GestioneErroriException("ValutazioneLaurea - errore valutazione laurea", e);
		}

		return result;

	}

	private BigDecimal valutazioneAbilitazione(String idUtente, Session session) throws GestioneErroriException {

		BigDecimal result = new BigDecimal(0);
		requisitiMinimiHome = new RequisitiMinimiRegHome();
		altroTitoloRegHome = new AltroTitoloRegHome();
		altroTitoloReg = new ArrayList();
		dottoratoReg = new ArrayList();
		corsoAggiornamentoRegHome = new CorsoAggiornamentoRegHome();
		dottoratoRegHome = new DottoratoRegHome();
		try {
			requisitiMinimiReg = requisitiMinimiHome.findById(idUtente);
			altroTitoloReg = altroTitoloRegHome.findByExample(new AltroTitoloReg("H",idUtente,""));
			corsoAggiornamentoReg = corsoAggiornamentoRegHome.findByExample(new CorsoAggiornamentoReg(idUtente));
			dottoratoReg = dottoratoRegHome.findByExample(new DottoratoReg("",idUtente,"H"));
			if (requisitiMinimiReg.getFlgElabManualeAbilitazione() == null || !requisitiMinimiReg.getFlgElabManualeAbilitazione().equalsIgnoreCase("true")) {
				// punteggio Abilitzione
				String votoAbilitazione = requisitiMinimiReg.getVotoAbilitazione();
				String baseVotoAbilitazione = requisitiMinimiReg.getBaseVotoAbilitazione();

				String votoCalcolato = getVotoAbilitazioneCalcolato(requisitiMinimiReg.getVotoAbilitazione(), requisitiMinimiReg.getBaseVotoAbilitazione());

				requisitiMinimiReg.setPunteggioAbilitazione(decodificaVotiAbilitazione.get(votoCalcolato) == null ? new BigDecimal(0) : decodificaVotiAbilitazione.get(votoCalcolato));
				// controllare se � stato modificato dalla commissione
				result = requisitiMinimiReg.getPunteggioAbilitazione();
				
			}

			if(altroTitoloReg!=null&&!altroTitoloReg.isEmpty()){
				for(AltroTitoloReg altroTitolo:altroTitoloReg){
					result=result.add(altroTitolo.getPunteggio() == null ? new BigDecimal(0) : altroTitolo.getPunteggio());
				}
			}
			
			if(corsoAggiornamentoReg!=null&&!corsoAggiornamentoReg.isEmpty()){
				for(CorsoAggiornamentoReg corsoAggiornamento : corsoAggiornamentoReg ){
					result=result.add(corsoAggiornamento.getPunteggio() == null ? new BigDecimal(0) : corsoAggiornamento.getPunteggio());
				}
			}
			
			if(dottoratoReg!=null&&!dottoratoReg.isEmpty()){
				for(DottoratoReg dottorato : dottoratoReg ){
					result=result.add(dottorato.getPunteggio() == null ? new BigDecimal(0) : dottorato.getPunteggio());
				}
			}
			// controllo le osservazioni
			if(requisitiMinimiReg.getPunteggioAbilitazione().compareTo(new BigDecimal("0.5000"))>-1){
				osservazioni += " | o_15";
			}
			if (requisitiMinimiReg.getVotoAbilitazione() == null || requisitiMinimiReg.getVotoAbilitazione().equals("")){
				osservazioni += " | o_04";
			}
				

			if (requisitiMinimiReg.getPrvAlbo() == null){
				osservazioni += " | o_09";
			}
				

			// iscrizione all albo deve essere maggiore della data di
			// abilitazione
			if (requisitiMinimiReg.getDataAlbo() != null && requisitiMinimiReg.getAnnoAbilitazione() != null) {

				dataAlbo = Integer.parseInt(StringUtil.dateToStringDDMMYYYY(requisitiMinimiReg.getDataAlbo()).substring(6, 10));
				dataAbilitazione = Integer.parseInt(requisitiMinimiReg.getAnnoAbilitazione());

				if (dataAlbo < dataAbilitazione) {
					osservazioni += " | o_10";
				}
			}
			
			if(result.compareTo(new BigDecimal("0.5000"))>0){
				result = new BigDecimal("0.5000");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new GestioneErroriException("ValutazioneAbilitazione- errore valutazione abilitazione", e);
		}

		return result;
	}

	private BigDecimal valutazioneAltraLaurea(String idUtente) throws GestioneErroriException {
		BigDecimal result = new BigDecimal(0);
		try {
			altraLaureaRegHome = new AltraLaureaRegHome();
			altraLaureaReg = altraLaureaRegHome.findById(idUtente);
			if (altraLaureaReg != null) {
				if(altraLaureaReg.getPunteggio()==null){
					altraLaureaReg.setPunteggio(new BigDecimal("1.5"));
					
				}
				result = result.add(altraLaureaReg.getPunteggio());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new GestioneErroriException("ValutazioneSecondaLaurea - errore valutazione seconda laurea");
		}

		return result;
	}

	private BigDecimal valutazioneAltraLaureaBis(String idUtente) throws GestioneErroriException {
		BigDecimal result = new BigDecimal(0);
		altraLaureaBisRegHome = new AltraLaureaBisRegHome();
		try {
		altraLaureaBisRegList = (ArrayList<AltraLaureaBisReg>) altraLaureaBisRegHome.findByExample(new AltraLaureaBisReg(idUtente));
		if (altraLaureaBisRegList!=null && !altraLaureaBisRegList.isEmpty()){
			
			for(AltraLaureaBisReg altrLaureaBisReg : altraLaureaBisRegList){
				if(altrLaureaBisReg.getPunteggio()==null){
					altrLaureaBisReg.setPunteggio(new BigDecimal("3.5"));
					
				}
				result = result.add(altrLaureaBisReg.getPunteggio());
				
			}
			if(result.compareTo(new BigDecimal("3.5"))>0){
				
				result = new BigDecimal("3.5000");
			}
		}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new GestioneErroriException("ValutazioneAltraLaurea - errore valutazione altra laurea");
			}
		return result;

	}

	private BigDecimal valutazioneIdoneita(String idUtente, Session session) throws GestioneErroriException {
		//BigDecimal result = new BigDecimal(0);
		try {
			
			idoneitaRegHome = new IdoneitaRegHome();
			idoneitaReg = new IdoneitaReg();

			idoneitaReg = idoneitaRegHome.findById(idUtente);
			

			if (idoneitaReg.getFlagIdoneitaSediIdoneita() != null && idoneitaReg.getFlagIdoneitaSediIdoneita().equals("true")) {
				if(idoneitaReg.getPunteggio()==null){
					idoneitaReg.setPunteggio(new BigDecimal("1"));
				}
				punteggioIdoneita = punteggioIdoneita.add(idoneitaReg.getPunteggio());
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new GestioneErroriException("valutazioneIdoneita - errore valutazione Idoneita");
		}

		return punteggioIdoneita;
	}

	private BigDecimal valutazioneIdoneitaNazionale(String idUtente, Session session) throws GestioneErroriException {
		//BigDecimal result = new BigDecimal(0);
		try {
			Utente utente = new Utente();
			UtenteHome utenteHome = new UtenteHome();
			idoneitaRegHome = new IdoneitaRegHome();

			idoneitaReg = idoneitaRegHome.findById(idUtente);
			utente = utenteHome.findById(idUtente);

			if (paramProperties.isEmpty()) {

				paramProperties =  AppProperties.getAppProperties();
			}

			Integer annoValidita = new Integer(paramProperties.getProperty("annoValiditaIdoneitaNaz"));
			String riferimentoIdoneitaNazionale = idoneitaReg.getRifIdoneitaNazionale();

			if ((riferimentoIdoneitaNazionale != null && !riferimentoIdoneitaNazionale.equals(""))) {

				if (idoneitaReg.getAnnoIdoneitaNazionale() != null) {
					
					Integer anno = new Integer(idoneitaReg.getAnnoIdoneitaNazionale());
					if (anno.intValue() > annoValidita.intValue()) {
						// l'idoneita nazionale non � valida
						riferimentoIdoneitaNazionale = "";
						osservazioni += " | o_14";
						note = Hibernate.createClob("L'utente " + utente.getNomeUtente() + " " + utente.getCognomeUtente() + " " + paramProperties.getProperty("notaIdoneita"));
					} else {
						note = null;
						if(idoneitaReg.getPunteggioNaz()==null){
							idoneitaReg.setPunteggioNaz(new BigDecimal("1"));
						}
						punteggioIdoneitaNazionale = punteggioIdoneitaNazionale.add(idoneitaReg.getPunteggioNaz());
					}
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new GestioneErroriException("valutazioneIdoneitaNazionale - errore valutazione Idoneita Nazionale");
		}

		return punteggioIdoneitaNazionale;
	}
	
	private void valutazioneC(String idUtente, Session session) throws GestioneErroriException{
		
		specializzazioneRegHome = new SpecializzazioneRegHome();
		borsaStudioRegHome = new BorsaStudioRegHome();
		altroTitoloRegHome = new AltroTitoloRegHome();
		altroTitoloReg = new ArrayList();
		dottoratoReg = new ArrayList();
		dottoratoRegHome = new DottoratoRegHome();
		try {
			specializzazioneReg = specializzazioneRegHome.findByExample(new SpecializzazioneReg(idUtente));
			borsaStudioReg = borsaStudioRegHome.findByExample(new BorsaStudioReg(idUtente));
			altroTitoloReg = altroTitoloRegHome.findByExample(new AltroTitoloReg("C",idUtente,""));
			dottoratoReg = dottoratoRegHome.findByExample(new DottoratoReg("",idUtente,"C"));
			if(specializzazioneReg!=null&&!specializzazioneReg.isEmpty()){
				for(SpecializzazioneReg specializzazione : specializzazioneReg){
					punteggioC = punteggioC.add(specializzazione.getPunteggio() == null ? new BigDecimal(0) : specializzazione.getPunteggio());
				}
			}
			
			if(borsaStudioReg!=null&&!borsaStudioReg.isEmpty()){
				for(BorsaStudioReg borsaStudio : borsaStudioReg){
					punteggioC = punteggioC.add(borsaStudio.getPunteggio() == null ? new BigDecimal(0) : borsaStudio.getPunteggio());
				}
			}
			
			if(altroTitoloReg!=null&&!altroTitoloReg.isEmpty()){
				for(AltroTitoloReg altroTitolo : altroTitoloReg){
					punteggioC = punteggioC.add(altroTitolo.getPunteggio() == null ? new BigDecimal(0) : altroTitolo.getPunteggio());
				}
			}
			if(dottoratoReg!=null&&!dottoratoReg.isEmpty()){
				for(DottoratoReg dottorato : dottoratoReg ){
					punteggioC=punteggioC.add(dottorato.getPunteggio() == null ? new BigDecimal(0) : dottorato.getPunteggio());
				}
			}
			if(punteggioC.compareTo(new BigDecimal("2.0000"))>0){
				punteggioC = new BigDecimal("2.0000");
			}
			
		} catch (GestioneErroriException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	private void valutazionePubblicazioni(String idUtente, Session session) throws GestioneErroriException{
		
		pubblicazioneRegHome = new PubblicazioneRegHome();
		try {
			pubblicazioneReg = pubblicazioneRegHome.findByExample(new PubblicazioneReg(idUtente));
			if(pubblicazioneReg!=null && !pubblicazioneReg.isEmpty()){
				
				for(PubblicazioneReg pubblicazione: pubblicazioneReg){
					punteggioPubblicazioni = punteggioPubblicazioni.add(pubblicazione.getPunteggio() == null ? new BigDecimal(0) : pubblicazione.getPunteggio());
				}
				
				if(punteggioPubblicazioni.compareTo(new BigDecimal("1.0000"))>0){
					punteggioPubblicazioni = new BigDecimal("1.0000");
				}
			}
		} catch (GestioneErroriException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	

	private BigDecimal calcoloEtaMedia(String idUtente,Date dataScadenzaBando, Session session) throws GestioneErroriException {

		UtenteReg utente = new UtenteReg();
		UtenteRegHome utenteHome = new UtenteRegHome();
		utente = utenteHome.findById(idUtente);
		Date dataNascita =utente.getDataNascitaUtente();
		double differenzaGiorni= (dataScadenzaBando.getTime() - dataNascita.getTime());
		differenzaGiorni = differenzaGiorni / 1000;
		differenzaGiorni = differenzaGiorni / (60 * 60);
		differenzaGiorni = differenzaGiorni / 24;
		differenzaGiorni = differenzaGiorni / 365;
		MathContext MC =new MathContext(6,RoundingMode.HALF_UP);
		BigDecimal etaMediaUtente =new BigDecimal(differenzaGiorni,MC);
		
		return etaMediaUtente;
	}


	
	/*public boolean cancellaGraduatoria(String codRegione,DatiBando datibando) {

		GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
		String query = "";
		boolean result = false;
		try {

			if (datibando.getFlgScarti() == null || !datibando.getFlgScarti().equals("true")) {

				query = "SELECT C.ID_CANDIDATURA " + "FROM UTENTE U, CANDIDATURA_REG C," + " (SELECT * FROM DATI_BANDO WHERE COD_REG ='" + codRegione + "' ) D " + " WHERE U.COD_REG_UTENTE = D.COD_REG "
						+ " AND U.ID_UTENTE = C.ID_UTENTE AND D.STATO ='1' AND D.DATA_FINE_BANDO < SYSDATE AND C.AMMESSO='SI'";

				new RequisitiMinimiRegHome().updateFlagElabManuale(codRegione);
			}

			if (datibando.getFlgScarti() != null && datibando.getFlgScarti().equals("true")) {

				query = "SELECT C.ID_CANDIDATURA " + "FROM UTENTE U, CANDIDATURA_REG C," + " (SELECT *    FROM DATI_BANDO WHERE COD_REG ='" + codRegione + "' ) D " + " WHERE U.COD_REG_UTENTE = D.COD_REG "
						+ " AND U.ID_UTENTE = C.ID_UTENTE AND D.STATO ='1' AND D.DATA_FINE_BANDO < SYSDATE AND C.AMMESSO='SI' AND C.ERR_ELAB_AUTO = 'T'";
			}

			result = graduatoriaHome.deleteValutazioniFromGraduatoria(query);

		} catch (GestioneErroriException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;

	}
*/
	public String getVotoAbilitazioneCalcolato(String votoAbilitazione, String baseVotoAbilitazione) {
		long voto = 0;
		String votoAbilitazioneCalcolato = "";
		if (votoAbilitazione != null && baseVotoAbilitazione != null) {
			voto = Math.round((new Double(votoAbilitazione).doubleValue() / new Double(baseVotoAbilitazione).doubleValue()) * 100);
			votoAbilitazioneCalcolato = new Long(voto).toString();
		}
		return votoAbilitazioneCalcolato;
	}

}
