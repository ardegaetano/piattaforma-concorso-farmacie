package com.accenture.CCFarm.CalcolaPunteggiCandidati;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.Clob;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Hibernate;
import org.hibernate.Session;

import com.accenture.CCFarm.DAO.AltraLaureaBisReg;
import com.accenture.CCFarm.DAO.AltraLaureaBisRegHome;
import com.accenture.CCFarm.DAO.AltraLaureaReg;
import com.accenture.CCFarm.DAO.AltraLaureaRegHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.IdoneitaReg;
import com.accenture.CCFarm.DAO.IdoneitaRegHome;
import com.accenture.CCFarm.DAO.RequisitiMinimiReg;
import com.accenture.CCFarm.DAO.RequisitiMinimiRegHome;
import com.accenture.CCFarm.DAO.UtenteReg;
import com.accenture.CCFarm.DAO.UtenteRegHome;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.DecodoficaVoti;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;

public class ElaborazioneTitoliRegione_old {
	
	private HashMap<String, BigDecimal> decodificaVotiLaurea = new HashMap<String, BigDecimal>();

	private HashMap<String, BigDecimal> decodificaVotiAbilitazione = new HashMap<String, BigDecimal>();

	private BigDecimal punteggioLaurea = new BigDecimal(0);

	private BigDecimal punteggioAbilitazione = new BigDecimal(0);

	private BigDecimal punteggioAltraLaurea = new BigDecimal(0);

	private BigDecimal punteggioAltraLaureaBis = new BigDecimal(0);

	private BigDecimal punteggioIdoneita = new BigDecimal(0);

	private BigDecimal punteggioIdoneitaNazionale = new BigDecimal(0);

	private BigDecimal totaleUtente = new BigDecimal(0);

	private BigDecimal etaMedia = new BigDecimal(0);

	private String osservazioni;

	private AltraLaureaRegHome altraLaureaRegHome = null;

	private AltraLaureaReg altraLaureaReg = null;

	private AltraLaureaBisRegHome altraLaureaBisRegHome = null;

	private ArrayList<AltraLaureaBisReg> altraLaureaBisRegList = null;

	private RequisitiMinimiRegHome requisitiMinimiHome = null;

	private RequisitiMinimiReg requisitiMinimiReg = null;

	private IdoneitaRegHome idoneitaRegHome = null;

	private IdoneitaReg idoneitaReg = null;

	private int dataAlbo;

	private int dataAbilitazione;

	private Clob note = null;

	public Graduatoria elaborazioneTitoliPerRegione(String idUtente, String codiceRegione, Session session) throws GestioneErroriException {

		Graduatoria graduatoria = new Graduatoria();
		osservazioni = "";

		try {

			// recupero le tabelle di decodificavoti per requisitiminimi
			decodificaVotiLaurea = DecodoficaVoti.getCriteriPunteggiLaurea(codiceRegione);

			decodificaVotiAbilitazione = DecodoficaVoti.getCriteriPunteggiVotoAbilitazione(codiceRegione);
			// fine recupero tabelle di decodifica

			// inizio valutazione
			punteggioLaurea = valutazioneLaurea(idUtente, session);
			graduatoria.setPunteggioLaurea(punteggioLaurea);

			punteggioAbilitazione = valutazioneAbilitazione(idUtente, session);
//			graduatoria.setPunteggioAbilitazione(punteggioAbilitazione);
			graduatoria.setPunteggioAbilitazioneCorsiAggAltriTitoli(punteggioAbilitazione);

			punteggioAltraLaurea = valutazioneAltraLaurea(idUtente);
			graduatoria.setPunteggioAltraLaurea(punteggioAltraLaurea);

			punteggioAltraLaureaBis = valutazioneAltraLaureaBis(idUtente);
			graduatoria.setPunteggioAltraLaureaBis(punteggioAltraLaureaBis);

			punteggioIdoneita = valutazioneIdoneita(idUtente, session);
			graduatoria.setPunteggioIdoneita(punteggioIdoneita);

			punteggioIdoneitaNazionale = valutazioneIdoneitaNazionale(idUtente, session);
			graduatoria.setPunteggioIdoneitaNazionale(punteggioIdoneitaNazionale);
			// fine valutazione

			// somma i parziali e genera totala da settare in graduatoria
			totaleUtente = new BigDecimal(0);
			totaleUtente = totaleUtente.add(punteggioAltraLaurea).add(punteggioLaurea).add(punteggioIdoneita).add(punteggioIdoneitaNazionale).add(punteggioAltraLaureaBis).add(punteggioAbilitazione);

			if (totaleUtente.compareTo(new BigDecimal(15)) == 1) {
				graduatoria.setPunteggio(new BigDecimal(15));
			} else {
				graduatoria.setPunteggioTitolo(totaleUtente);
			}
			
			
			FacesContext context = FacesContext.getCurrentInstance();
	    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
	    	HttpSession sessionHttp = req.getSession();
	    	
	       	DatiBando datiBando = (DatiBando)sessionHttp.getAttribute(RepositorySession.DATI_BANDO);
		
	       	Date dataScadenzaBando= datiBando.getDataFineBando();
			
			etaMedia = calcoloEtaMedia(idUtente,dataScadenzaBando,session);
			
			graduatoria.setEtaMedia(etaMedia);// etaMedia = calcoloEtaMedia(idUtente);

			graduatoria.setOsservazioni(osservazioni);

			graduatoria.setNote(note);

		} catch (Exception e) {

			e.printStackTrace();
			throw new GestioneErroriException("elaborazioneTitoliPerRegione : errore");
		}

		return graduatoria;

	}

	private BigDecimal valutazioneLaurea(String idUtente, Session session) throws GestioneErroriException {
		BigDecimal result = new BigDecimal(0);
		try {

			String votoLaurea = "";
			requisitiMinimiHome = new RequisitiMinimiRegHome();
			requisitiMinimiReg = requisitiMinimiHome.findById(idUtente);

			if (requisitiMinimiReg.getFlgElabManualeLaurea() == null || !requisitiMinimiReg.getFlgElabManualeLaurea().equalsIgnoreCase("true")) {

				// punteggio Laurea

				votoLaurea = requisitiMinimiReg.getVotoLaurea();
				if (votoLaurea != null && votoLaurea.equals("110")) {

					if (requisitiMinimiReg.getFlagLode() != null && requisitiMinimiReg.getFlagLode().equals("true")) {

						votoLaurea = AppProperties.getAppProperties().getProperty("votoLode");

					}

				}

				requisitiMinimiReg.setPunteggioLaurea(decodificaVotiLaurea.get(votoLaurea) == null ? new BigDecimal(0) : decodificaVotiLaurea.get(votoLaurea));
			}
			session.saveOrUpdate(requisitiMinimiReg);
			// requisitiMinimiHome.saveOrUpdate(requisitiMinimiReg);
			result = result.add(requisitiMinimiReg.getPunteggioLaurea());

			// controllo le osservazioni
			if (requisitiMinimiReg.getVotoLaurea() == null || requisitiMinimiReg.getVotoLaurea().equals(""))
				osservazioni += " | o_03";

		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new GestioneErroriException("ValutazioneLaurea - errore valutazione laurea", e);
		}

		return result;

	}

	private BigDecimal valutazioneAbilitazione(String idUtente, Session session) throws GestioneErroriException {

		BigDecimal result = new BigDecimal(0);

		try {

			if (requisitiMinimiReg.getFlgElabManualeAbilitazione() == null || !requisitiMinimiReg.getFlgElabManualeAbilitazione().equalsIgnoreCase("false")) {
				// punteggio Abilitzione
				String votoAbilitazione = requisitiMinimiReg.getVotoAbilitazione();
				String baseVotoAbilitazione = requisitiMinimiReg.getBaseVotoAbilitazione();

				String votoCalcolato = getVotoAbilitazioneCalcolato(requisitiMinimiReg.getVotoAbilitazione(), requisitiMinimiReg.getBaseVotoAbilitazione());

				requisitiMinimiReg.setPunteggioAbilitazione(decodificaVotiAbilitazione.get(votoCalcolato) == null ? new BigDecimal(0) : decodificaVotiAbilitazione.get(votoCalcolato));
				// controllare se � stato modificato dalla commissione

				session.saveOrUpdate(requisitiMinimiReg);
			}

			result = requisitiMinimiReg.getPunteggioAbilitazione();

			// controllo le osservazioni

			if (requisitiMinimiReg.getVotoAbilitazione() == null || requisitiMinimiReg.getVotoAbilitazione().equals(""))
				osservazioni += " | o_04";

			if (requisitiMinimiReg.getPrvAlbo() == null)
				osservazioni += " | o_09";

			// iscrizione all albo deve essere maggiore della data di
			// abilitazione
			if (requisitiMinimiReg.getDataAlbo() != null && requisitiMinimiReg.getAnnoAbilitazione() != null) {

				dataAlbo = Integer.parseInt(StringUtil.dateToStringDDMMYYYY(requisitiMinimiReg.getDataAlbo()).substring(6, 10));
				dataAbilitazione = Integer.parseInt(requisitiMinimiReg.getAnnoAbilitazione());

				if (dataAlbo <= dataAbilitazione) {
					osservazioni += " | o_10";
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new GestioneErroriException("ValutazioneAbilitazione- errore valutazione abilitazione", e);
		}

		return result;
	}

	private BigDecimal valutazioneAltraLaurea(String idUtente) throws GestioneErroriException {
		BigDecimal result = new BigDecimal(0);
		try {
			altraLaureaRegHome = new AltraLaureaRegHome();
			altraLaureaReg = altraLaureaRegHome.findById(idUtente);
			if (altraLaureaReg != null) {
				result = new BigDecimal(1.5);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new GestioneErroriException("ValutazioneSecondaLaurea - errore valutazione seconda laurea");
		}

		return result;
	}

	private BigDecimal valutazioneAltraLaureaBis(String idUtente) throws GestioneErroriException {
		BigDecimal result = new BigDecimal(0);
		altraLaureaBisRegHome = new AltraLaureaBisRegHome();
		altraLaureaBisRegList = (ArrayList<AltraLaureaBisReg>) altraLaureaBisRegHome.findByExample(new AltraLaureaBisReg(idUtente));
		if (altraLaureaBisRegList.size() > 0) {
			try {
				result = new BigDecimal(3.5);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new GestioneErroriException("ValutazioneAltraLaurea - errore valutazione altra laurea");
			}
		}
		return result;

	}

	private BigDecimal valutazioneIdoneita(String idUtente, Session session) throws GestioneErroriException {
		BigDecimal result = new BigDecimal(0);
		try {
			UtenteReg utente = new UtenteReg();
			UtenteRegHome utenteHome = new UtenteRegHome();
			idoneitaRegHome = new IdoneitaRegHome();
			idoneitaReg = new IdoneitaReg();

			idoneitaReg = idoneitaRegHome.findById(idUtente);
			utente = utenteHome.findById(idUtente);

			if (idoneitaReg.getFlagIdoneitaSediIdoneita() != null && idoneitaReg.getFlagIdoneitaSediIdoneita().equals("true")) {

				idoneitaReg.setPunteggio(new BigDecimal(1));
				punteggioIdoneita = punteggioIdoneita.add(new BigDecimal(1));
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new GestioneErroriException("valutazioneIdoneita - errore valutazione Idoneita");
		}

		return punteggioIdoneita;
	}

	private BigDecimal valutazioneIdoneitaNazionale(String idUtente, Session session) throws GestioneErroriException {
		BigDecimal result = new BigDecimal(0);
		try {
			UtenteReg utente = new UtenteReg();
			UtenteRegHome utenteHome = new UtenteRegHome();
			idoneitaRegHome = new IdoneitaRegHome();

			idoneitaReg = idoneitaRegHome.findById(idUtente);
			utente = utenteHome.findById(idUtente);

			Integer annoValidita = new Integer(AppProperties.getAppProperties().getProperty("annoValiditaIdoneitaNaz"));
			String riferimentoIdoneitaNazionale = idoneitaReg.getRifIdoneitaNazionale();

			if ((riferimentoIdoneitaNazionale != null && !riferimentoIdoneitaNazionale.equals(""))) {

				if (idoneitaReg.getAnnoIdoneitaNazionale() != null) {
					Integer anno = new Integer(idoneitaReg.getAnnoIdoneitaNazionale());
					if (anno.intValue() < annoValidita.intValue()) {
						// l'idoneita nazionale non � valida
						riferimentoIdoneitaNazionale = "";
						osservazioni += " | o_14";
						note = Hibernate.createClob("L'utente " + utente.getNomeUtente() + " " + utente.getCognomeUtente() + " " + AppProperties.getAppProperties().getProperty("notaIdoneita"));
					} else {
						note = null;
						idoneitaReg.setPunteggio(new BigDecimal(1));
						punteggioIdoneitaNazionale = punteggioIdoneitaNazionale.add(new BigDecimal(1));
					}
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new GestioneErroriException("valutazioneIdoneitaNazionale - errore valutazione Idoneita Nazionale");
		}

		return punteggioIdoneitaNazionale;
	}

	private BigDecimal calcoloEtaMedia(String idUtente, Date dataScadenzaBando, Session session) throws GestioneErroriException {

		UtenteReg utente = new UtenteReg();
		UtenteRegHome utenteHome = new UtenteRegHome();
		utente = utenteHome.findById(idUtente);
		Date dataNascita =utente.getDataNascitaUtente();
		double differenzaGiorni= (dataScadenzaBando.getTime() - dataNascita.getTime());
		differenzaGiorni = differenzaGiorni / 1000;
		differenzaGiorni = differenzaGiorni / (60 * 60);
		differenzaGiorni = differenzaGiorni / 24;
		differenzaGiorni = differenzaGiorni / 365;
		MathContext MC =new MathContext(6,RoundingMode.HALF_UP);
		BigDecimal etaMediaUtente =new BigDecimal(differenzaGiorni,MC);
		
		return etaMediaUtente;
	}

	public String getVotoAbilitazioneCalcolato(String votoAbilitazione, String baseVotoAbilitazione) {
		long voto = 0;
		String votoAbilitazioneCalcolato = "";
		if (votoAbilitazione != null && baseVotoAbilitazione != null) {
			voto = Math.round((new Double(votoAbilitazione).doubleValue() / new Double(baseVotoAbilitazione).doubleValue()) * 100);
			votoAbilitazioneCalcolato = new Long(voto).toString();
		}
		return votoAbilitazioneCalcolato;
	}
}
