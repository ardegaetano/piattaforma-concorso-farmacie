package com.accenture.CCFarm.CalcolaPunteggiCandidati;

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.Date;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;

import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.UtenteReg;
import com.accenture.CCFarm.exception.GestioneErroriException;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.StringUtil;


public class GestisciGraduatoria_old {

	public boolean aggiornaGraduatoria(Graduatoria graduatoriaTotale, String tipoCandidatura, Date dataFineBando,Session dbSession) throws GestioneErroriException {

		boolean ritorno = true;
		Graduatoria graduatoriaParziale = null;
		GraduatoriaHome graduatoriaHome = new GraduatoriaHome();
		BigDecimal punteggioEsperienze = new BigDecimal(0);
		BigDecimal punteggioTotale = new BigDecimal(0);
		List<UtenteReg> listaCandidati;
	    CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
	    DatiBando datiBando = new DatiBando();
	    DatiBandoHome datiBandoHome = new DatiBandoHome();
		String segnalazioni;
		try {
			
			if (tipoCandidatura.equalsIgnoreCase("A")) {

				graduatoriaParziale = graduatoriaHome.findById(graduatoriaTotale.getIdCandidatura());
				if (graduatoriaParziale != null) {

					if (graduatoriaParziale.getPunteggioAltraLaurea().add(graduatoriaTotale.getPunteggioAltraLaurea()).compareTo(new BigDecimal(1.5)) > 0) {
						graduatoriaTotale.setPunteggioAltraLaurea(new BigDecimal(1.5));
					} else {
						graduatoriaTotale.setPunteggioAltraLaurea(graduatoriaParziale.getPunteggioAltraLaurea().add(graduatoriaTotale.getPunteggioAltraLaurea()));
					}

					if (graduatoriaParziale.getPunteggioLaurea().add(graduatoriaTotale.getPunteggioLaurea()).compareTo(new BigDecimal(5)) > 0) {
						graduatoriaTotale.setPunteggioLaurea(new BigDecimal(5));
					} else {
						graduatoriaTotale.setPunteggioLaurea(graduatoriaParziale.getPunteggioLaurea().add(graduatoriaTotale.getPunteggioLaurea()));
					}

					if (graduatoriaParziale.getPunteggioIdoneita().add(graduatoriaTotale.getPunteggioIdoneita()).compareTo(new BigDecimal(1)) > 0) {
						graduatoriaTotale.setPunteggioIdoneita(new BigDecimal(1));
					} else {
						graduatoriaTotale.setPunteggioIdoneita(graduatoriaParziale.getPunteggioIdoneita().add(graduatoriaTotale.getPunteggioIdoneita()));
					}

					if (graduatoriaParziale.getPunteggioIdoneitaNazionale().add(graduatoriaTotale.getPunteggioIdoneitaNazionale()).compareTo(new BigDecimal(1)) > 0) {
						graduatoriaTotale.setPunteggioIdoneitaNazionale(new BigDecimal(1));
					} else {
						graduatoriaTotale.setPunteggioIdoneitaNazionale(graduatoriaParziale.getPunteggioIdoneitaNazionale().add(graduatoriaTotale.getPunteggioIdoneitaNazionale()));
					}

					if (graduatoriaParziale.getPunteggioAltraLaureaBis().add(graduatoriaTotale.getPunteggioAltraLaureaBis()).compareTo(new BigDecimal(3.5)) > 0) {
						graduatoriaTotale.setPunteggioAltraLaureaBis(new BigDecimal(3.5));
					} else {
						graduatoriaTotale.setPunteggioAltraLaureaBis(graduatoriaParziale.getPunteggioAltraLaureaBis().add(graduatoriaTotale.getPunteggioAltraLaureaBis()));
					}

					
					// sostituito abilitazione con aggregato abilitazione + corsi aggirnamento + altri titoli
					
//					if (graduatoriaParziale.getPunteggioAbilitazione().add(graduatoriaTotale.getPunteggioAbilitazione()).compareTo(new BigDecimal(1)) > 0) {
//						graduatoriaTotale.setPunteggioAbilitazione(new BigDecimal(1));
//					} else {
//						graduatoriaTotale.setPunteggioAbilitazione(graduatoriaParziale.getPunteggioAbilitazione().add(graduatoriaTotale.getPunteggioAbilitazione()));
//					}
					
					// aggiungere i controlli su tutti i punteggi degli altri titoli
					
					
					// somma (specializzazioni + dottorati + borse di studio) < 2.0
					
					BigDecimal punteggioSpecDottBorseParziale;				
					BigDecimal punteggioSpecDottBorseTotale;
					
					if (graduatoriaParziale.getPunteggioSpecDottBorse()==null) {
						punteggioSpecDottBorseParziale = new BigDecimal(0);
					}
						else {
							punteggioSpecDottBorseParziale = graduatoriaParziale.getPunteggioSpecDottBorse();
						}
					if (graduatoriaTotale.getPunteggioSpecDottBorse()==null) {
						punteggioSpecDottBorseTotale = new BigDecimal(0);
					}
						else {
							punteggioSpecDottBorseTotale = graduatoriaTotale.getPunteggioSpecDottBorse();
						}
						
					if (punteggioSpecDottBorseParziale.add(punteggioSpecDottBorseTotale).compareTo(new BigDecimal(2)) > 0) {
						graduatoriaTotale.setPunteggioSpecDottBorse(new BigDecimal(2));
					} else {
						graduatoriaTotale.setPunteggioSpecDottBorse(punteggioSpecDottBorseParziale.add(punteggioSpecDottBorseTotale));
					}
					
					
					// somma pubblicazioni < 1.0
					
					BigDecimal punteggioPubblicazioniParziale;				
					BigDecimal punteggioPubblicazioniTotale;
					
					if (graduatoriaParziale.getPunteggioPubblicazione()==null) {
						punteggioPubblicazioniParziale = new BigDecimal(0);
					}
						else {
							punteggioPubblicazioniParziale = graduatoriaParziale.getPunteggioPubblicazione();
						}
					if (graduatoriaTotale.getPunteggioPubblicazione()==null) {
						punteggioPubblicazioniTotale = new BigDecimal(0);
					}
						else {
							punteggioPubblicazioniTotale = graduatoriaTotale.getPunteggioPubblicazione();
						}
						
					if (punteggioPubblicazioniParziale.add(punteggioPubblicazioniTotale).compareTo(new BigDecimal(2)) > 0) {
						graduatoriaTotale.setPunteggioPubblicazione(new BigDecimal(2));
					} else {
						graduatoriaTotale.setPunteggioPubblicazione(punteggioPubblicazioniParziale.add(punteggioPubblicazioniTotale));
					}
					
					
					
					// somma corsi di voto abilitazione + aggiornamento + altri titoli < 0.5
									
					BigDecimal punteggioAbilitCorsiAggAltriTitParziale;				
					BigDecimal punteggioAbilitCorsiAggAltriTitTotale;
					
					if (graduatoriaParziale.getPunteggioAbilitazioneCorsiAggAltriTitoli()==null) {
						punteggioAbilitCorsiAggAltriTitParziale = new BigDecimal(0);
					}
						else {
							punteggioAbilitCorsiAggAltriTitParziale = graduatoriaParziale.getPunteggioAbilitazioneCorsiAggAltriTitoli();
						}
					if (graduatoriaTotale.getPunteggioAbilitazioneCorsiAggAltriTitoli()==null) {
						punteggioAbilitCorsiAggAltriTitTotale = new BigDecimal(0);
					}
						else {
							punteggioAbilitCorsiAggAltriTitTotale = graduatoriaTotale.getPunteggioAbilitazioneCorsiAggAltriTitoli();
						}
						
					if (punteggioAbilitCorsiAggAltriTitParziale.add(punteggioAbilitCorsiAggAltriTitTotale).compareTo(new BigDecimal(2)) > 0) {
						graduatoriaTotale.setPunteggioAbilitazioneCorsiAggAltriTitoli(new BigDecimal(2));
					} else {
						graduatoriaTotale.setPunteggioAbilitazioneCorsiAggAltriTitoli(punteggioAbilitCorsiAggAltriTitParziale.add(punteggioAbilitCorsiAggAltriTitTotale));
					}
					
					

					BigDecimal totaleTitoliCandidatura = new BigDecimal(0);
					totaleTitoliCandidatura = totaleTitoliCandidatura.add(graduatoriaTotale.getPunteggioAltraLaurea()).add(graduatoriaTotale.getPunteggioLaurea()).add(graduatoriaTotale.getPunteggioIdoneita())
							.add(graduatoriaTotale.getPunteggioIdoneitaNazionale()).add(graduatoriaTotale.getPunteggioAltraLaureaBis()
//									.add(graduatoriaTotale.getPunteggioAbilitazione())
									.add(graduatoriaTotale.getPunteggioAbilitazioneCorsiAggAltriTitoli())
									.add(graduatoriaTotale.getPunteggioSpecDottBorse()).add(graduatoriaTotale.getPunteggioPubblicazione())									
									);

					if (totaleTitoliCandidatura.compareTo(new BigDecimal(15)) == 1) {
						graduatoriaTotale.setPunteggioTitolo(new BigDecimal(15));
					} else {
						graduatoriaTotale.setPunteggioTitolo(totaleTitoliCandidatura);
					}

					punteggioEsperienze = punteggioEsperienze.add(graduatoriaTotale.getPunteggioEsperienza()).add(graduatoriaParziale.getPunteggioEsperienza());
					if (punteggioEsperienze.compareTo(new BigDecimal(35)) == 1) {
						graduatoriaTotale.setPunteggioEsperienza(new BigDecimal(35));
					} else {
						graduatoriaTotale.setPunteggioEsperienza(punteggioEsperienze);
					}

					punteggioTotale = punteggioTotale.add(graduatoriaTotale.getPunteggioTitolo().add(graduatoriaTotale.getPunteggioEsperienza()));

					if (punteggioTotale.compareTo(new BigDecimal(50)) == 1) {
						punteggioTotale = new BigDecimal(50);
					}
					graduatoriaTotale.setPunteggio(punteggioTotale);

					if (graduatoriaParziale.getOsservazioni() == null || graduatoriaParziale.getOsservazioni().equals("")) {
						segnalazioni = graduatoriaTotale.getOsservazioni();
					} else {
						segnalazioni = graduatoriaParziale.getOsservazioni() + graduatoriaTotale.getOsservazioni();
					}
					graduatoriaTotale.setOsservazioni(segnalazioni);

					Clob notaTotale = graduatoriaTotale.getNote();
					Clob notaParziale = graduatoriaParziale.getNote();
					String  nota;
					if (notaParziale != null && !notaParziale.getAsciiStream().toString().equals("")) {

						if (notaTotale != null && !notaTotale.getAsciiStream().toString().equals("")) {

 							nota = StringUtil.convertClob(notaParziale) + "\n" + StringUtil.convertClob(notaTotale);
							graduatoriaTotale.setNote(Hibernate.createClob(nota));
						}else{
							graduatoriaTotale.setNote(notaParziale);
						}
						
					}

					if (graduatoriaTotale.getNome() == null || graduatoriaTotale.getNome().equals("")) {

						if (graduatoriaParziale.getNome() != null) {

							graduatoriaTotale.setCognome(graduatoriaParziale.getCognome().toUpperCase());
							graduatoriaTotale.setNome(graduatoriaParziale.getNome().toUpperCase());
						}
					}									
					
					if (graduatoriaParziale.getDataNascita()!=null ){
						 
						graduatoriaTotale.setDataNascita(graduatoriaParziale.getDataNascita().toString()+"; "+graduatoriaTotale.getDataNascita().toString());
												
					}
					
					if (graduatoriaParziale.getEtaMedia()!=null ){
						String id_cand = graduatoriaTotale.getIdCandidatura();
						listaCandidati = (List<UtenteReg>) candidaturaRegHome.listaUtentiXIdCandidatura(id_cand);
						BigDecimal etaMedia;
						BigDecimal etaTotale = new BigDecimal(0);
						for (UtenteReg utente : listaCandidati){
							etaMedia = DateUtil.getEtaMedia(utente.getDataNascitaUtente(),dataFineBando);
							etaTotale = etaTotale.add(etaMedia);							
						}
						etaTotale = etaTotale.divide(new BigDecimal(listaCandidati.size()),4);						
						graduatoriaTotale.setEtaMedia(etaTotale);						
					}
					
					
					// aggiorna graduatoria
					// graduatoriaHome.saveOrUpdate(graduatoriaTotale);
					dbSession.saveOrUpdate(graduatoriaTotale);
				} else {
					// punteggio titoli e punteggio totale
					
										BigDecimal totaleTitoliCandidatura = new BigDecimal(0);
										
										BigDecimal punteggioSpecDottBorseTotale;
										BigDecimal punteggioPubblicazioniTotale;
										BigDecimal punteggioAbilitCorsiAggAltriTitTotale;
										
										
										
										if (graduatoriaTotale.getPunteggioSpecDottBorse()==null) {
											punteggioSpecDottBorseTotale = new BigDecimal(0);
										}
											else {
												punteggioSpecDottBorseTotale = graduatoriaTotale.getPunteggioSpecDottBorse();
											}
										if (graduatoriaTotale.getPunteggioPubblicazione()==null) {
											punteggioPubblicazioniTotale = new BigDecimal(0);
										}
											else {
												punteggioPubblicazioniTotale = graduatoriaTotale.getPunteggioPubblicazione();
											}
										if (graduatoriaTotale.getPunteggioAbilitazioneCorsiAggAltriTitoli()==null) {
											punteggioAbilitCorsiAggAltriTitTotale = new BigDecimal(0);
										}
											else {
												punteggioAbilitCorsiAggAltriTitTotale = graduatoriaTotale.getPunteggioAbilitazioneCorsiAggAltriTitoli();
											}					
					
										
					totaleTitoliCandidatura = totaleTitoliCandidatura.add(graduatoriaTotale.getPunteggioAltraLaurea()).add(graduatoriaTotale.getPunteggioLaurea()).add(graduatoriaTotale.getPunteggioIdoneita())
							.add(graduatoriaTotale.getPunteggioIdoneitaNazionale()).add(graduatoriaTotale.getPunteggioAltraLaureaBis()
//									.add(graduatoriaTotale.getPunteggioAbilitazione()
									.add(punteggioSpecDottBorseTotale).add(punteggioPubblicazioniTotale).add(punteggioAbilitCorsiAggAltriTitTotale));

					if (totaleTitoliCandidatura.compareTo(new BigDecimal(15)) == 1) {
						graduatoriaTotale.setPunteggio(new BigDecimal(15));
					} else {
						graduatoriaTotale.setPunteggioTitolo(totaleTitoliCandidatura);
					}

					
					
					
					punteggioTotale = punteggioTotale.add(graduatoriaTotale.getPunteggioTitolo().add(graduatoriaTotale.getPunteggioEsperienza()));
					graduatoriaTotale.setPunteggio(punteggioTotale);
					// graduatoriaHome.saveOrUpdate(graduatoriaTotale);
					
					
					if (graduatoriaTotale.getEtaMedia()!=null ){
						String id_cand = graduatoriaTotale.getIdCandidatura();
						listaCandidati = (List<UtenteReg>) candidaturaRegHome.listaUtentiXIdCandidatura(id_cand);
						BigDecimal etaMedia;
						BigDecimal etaTotale = new BigDecimal(0);
						for (UtenteReg utente : listaCandidati){
							etaMedia = DateUtil.getEtaMedia(utente.getDataNascitaUtente(),dataFineBando);
							etaTotale = etaTotale.add(etaMedia);							
						}
						etaTotale = etaTotale.divide(new BigDecimal(listaCandidati.size()),4);						
						graduatoriaTotale.setEtaMedia(etaTotale);						
					}
								
					dbSession.saveOrUpdate(graduatoriaTotale);
				}
			} else {
				// punteggio titoli e punteggio totale

				BigDecimal totaleTitoliCandidatura = new BigDecimal(0);
				
				BigDecimal punteggioSpecDottBorseTotale;
				BigDecimal punteggioPubblicazioniTotale;
				BigDecimal punteggioAbilitCorsiAggAltriTitTotale;
				
				
				
				if (graduatoriaTotale.getPunteggioSpecDottBorse()==null) {
					punteggioSpecDottBorseTotale = new BigDecimal(0);
				}
					else {
						punteggioSpecDottBorseTotale = graduatoriaTotale.getPunteggioSpecDottBorse();
					}
				if (graduatoriaTotale.getPunteggioPubblicazione()==null) {
					punteggioPubblicazioniTotale = new BigDecimal(0);
				}
					else {
						punteggioPubblicazioniTotale = graduatoriaTotale.getPunteggioPubblicazione();
					}
				if (graduatoriaTotale.getPunteggioAbilitazioneCorsiAggAltriTitoli()==null) {
					punteggioAbilitCorsiAggAltriTitTotale = new BigDecimal(0);
				}
					else {
						punteggioAbilitCorsiAggAltriTitTotale = graduatoriaTotale.getPunteggioAbilitazioneCorsiAggAltriTitoli();
					}

				totaleTitoliCandidatura = totaleTitoliCandidatura.add(graduatoriaTotale.getPunteggioAltraLaurea()).add(graduatoriaTotale.getPunteggioLaurea()).add(graduatoriaTotale.getPunteggioIdoneita())
						.add(graduatoriaTotale.getPunteggioIdoneitaNazionale()).add(graduatoriaTotale.getPunteggioAltraLaureaBis())
//								.add(graduatoriaTotale.getPunteggioAbilitazione()
								.add(punteggioSpecDottBorseTotale).add(punteggioPubblicazioniTotale).add(punteggioAbilitCorsiAggAltriTitTotale);

				if (totaleTitoliCandidatura.compareTo(new BigDecimal(15)) == 1) {
					graduatoriaTotale.setPunteggio(new BigDecimal(15));
				} else {
					graduatoriaTotale.setPunteggioTitolo(totaleTitoliCandidatura);
				}
				datiBando = datiBandoHome.findById(graduatoriaTotale.getCodRegione());
				
				datiBando.setFlgAbilitaGrad("false");
				datiBandoHome.saveOrUpdate(datiBando);
				graduatoriaTotale.setPunteggioTitolo(totaleTitoliCandidatura);
				
				punteggioTotale = graduatoriaTotale.getPunteggioTitolo().add(graduatoriaTotale.getPunteggioEsperienza());
				graduatoriaTotale.setPunteggio(punteggioTotale);

				graduatoriaTotale.setRettifica("true");
				
				dbSession.saveOrUpdate(graduatoriaTotale);
			}
		} catch (Exception ex) {
			ritorno = false;
			throw new GestioneErroriException("ValutazioneSecondaLaurea - errore valutazione seconda laurea");

		}

		return ritorno;
	}

}
