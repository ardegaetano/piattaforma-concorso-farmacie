function messaggioDiBenvenuto()
{
	var msg=document.getElementById('msgBenvenuto').value;
	msg=msg.replace("<cognome>",document.getElementById('cognomeUtente').value);
	msg=msg.replace("<nome>",document.getElementById('nomeUtente').value);
	
	document.write(msg);
}

function messaggioDichiarazione(parte)
{
	if(parte==0)
	{	
		var msg=document.getElementById('msgRichiestaAmmissione').value;
		msg=msg.replace("<cognome>",document.getElementById('cognomeUtente').value);
		msg=msg.replace("<nome>",document.getElementById('nomeUtente').value);
		//sostituire <regione> in msg con il valore recuperato dalla sessione
		document.write(msg);
		
		document.write("<br>");
		
		msg=document.getElementById('msgConsapevolezzaResponsabilita').value;
		document.write(msg);
	}
	else if(parte==1)
	{
		document.write("<br>");
		
		msg=document.getElementById('msgDichiara').value;
		document.write("<b><u>"+msg+"</u></b>");
	}
}