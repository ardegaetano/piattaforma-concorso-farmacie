package com.accenture.CCFarm.DAO;

// Generated 7-set-2012 11.48.05 by Hibernate Tools 3.4.0.CR1

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class Ricevute.
 * @see com.ccFram.Ricevute
 * @author Hibernate Tools
 */
public class RicevuteHome {

	private static final Log log = LogFactory.getLog(RicevuteHome.class);
	public  static final String SEQUENCE = "sequence";
	public  static final String PARAMETERS = "parameters";
	private static String sequenceName;
	private static int LIMITE_SIZE_N_PROTOCOLLO = 6;


	public void persist(Ricevute transientInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("persisting Ricevute instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}
	public boolean insertRicevute(Ricevute ricevute) {
		
		Session session = null;
		Transaction trx = null;
		
		try {
			
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			
			session.save(ricevute);
			
			trx.commit();
			
			log.debug("Operazione Inserimento Ricevuta [OK]");
			
			return true;
		}
		catch(Exception e) {
			
			if(trx != null)
				trx.rollback();
			
			log.error("Operazione Inserimento Ricevuta FALLITA");
			return false;
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	public boolean modifyBLOB(Ricevute instance) {
		boolean result = false;
		Session session = HibernateUtil.openSession();			
		Transaction sessionTrans = session.getTransaction();			
		try {
			sessionTrans.begin();
			session.update(instance);
			sessionTrans.commit();
			log.debug("Operazione Modifica Ricevuta [OK]");
			result = true;
		} catch (RuntimeException re) {
			log.error("Errore di Modifica nuova Ricevute");
			throw re;
		}finally{
			
			session.close();
		}
		return result;
	}
	
	
	public void attachDirty(Ricevute instance) {
		Session session = HibernateUtil.openSession();
		
		try {
			session.saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Ricevute instance) {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Ricevute instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(Ricevute persistentInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("deleting Ricevute instance");
		try {
			session.delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Ricevute merge(Ricevute detachedInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("merging Ricevute instance");
		try {
			Ricevute result = (Ricevute) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Ricevute findById(java.lang.String id) {
		Session session = HibernateUtil.openSession();
		log.debug("getting Ricevute instance with id: " + id);
		try {
			Ricevute instance = (Ricevute) session.get("com.accenture.CCFarm.DAO.Ricevute", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
	
	public Ricevute findByCandidatura(String id_candidatura) {
		Session session = HibernateUtil.openSession();
		log.debug("finding Ricevute instance by Candidatura");
		
		Ricevute result = null;
		try {
			Query query = session.createQuery("from Ricevute where id.tipoRicevuta='DD' and id.idCandidatura = :idCandidatura ");
			query.setParameter("idCandidatura", id_candidatura);
			List<Ricevute> lista = query.list();
			if(lista!=null && !lista.isEmpty())
			{
				result= new Ricevute();
				result = lista.get(0);
			}
			else
			{
				log.info("cannot find any Ricevute for Candidatura (id: "+id_candidatura+")");
			}
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
		return result;
	}	

	public List findByExample(Ricevute instance) {
		Session session = HibernateUtil.openSession();
		log.debug("finding Ricevute instance by example");
		try {
			List results = session.createCriteria("com.accenture.CCFarm.DAO.Ricevute")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
	
	public void deleteFromIdCantidatura(String idCandidatura) {
		Session session = HibernateUtil.openSession();
		Transaction tx = session.beginTransaction();
		log.debug("deleting Ricevute instance");
		try {
			
			Query query = session.createSQLQuery("Delete RICEVUTE where ID_CANDIDATURA = '" +idCandidatura +"'" );
			query.executeUpdate();
			tx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
		finally
		{
			session.close();
		}
	}	
	
	
	public  List<String> getRicevuteAll()  
	{ 
		List<String> result = new ArrayList<String>();
		Session session = null;
		try
		{ 
				
			
			session = HibernateUtil.openSession();
			
			String query = null; 
			SQLQuery sqlQuery = null;
		
//			query ="SELECT R.ID_CANDIDATURA FROM RICEVUTE R, CANDIDATURA_REG  c  WHERE R.ID_CANDIDATURA=C.ID_CANDIDATURA and R.ID_CANDIDATURA  NOT LIKE '%_S'  group by R.ID_CANDIDATURA ORDER BY R.ID_CANDIDATURA";
//			query ="SELECT R.ID_CANDIDATURA FROM RICEVUTE R, CANDIDATURA_REG  c  WHERE R.ID_CANDIDATURA=C.ID_CANDIDATURA and R.ID_CANDIDATURA  NOT LIKE '%_S' and R.ID_REGIONE='070' group by R.ID_CANDIDATURA ORDER BY R.ID_CANDIDATURA";
			
			query ="SELECT DISTINCT c.ID_CANDIDATURA    FROM  CANDIDATURA_REG c  WHERE  C.ID_UTENTE IN   (SELECT DISTINCT U.ID_UTENTE 	FROM UTENTE_REG U, ESERCIZIO_PROF_REG E " +
			       " WHERE E.ID_DOMANDA_ES = U.ID_UTENTE     AND E.COD_RUOLO_ES IN   ('09_N', '10_N', '11_N', '12_N', '13_N', '14_N', '15_N', '16_N'))"; 
			
			
			
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			List results = sqlQuery.list();
				
			log.debug("findByFilterAllUtentiRegioni successful, result size: "	+ results.size());
			
			for (Object object : results) {
				
				Map row = (Map)object;
				
				String idCandidatura =  (String) row.get("ID_CANDIDATURA");
				result.add(idCandidatura);
				
			}
		} catch (RuntimeException e) { 
			e.printStackTrace();
		}
		finally{
			session.close();
			return result;
		}		
	}	

	
	public static String leggiIdSequence(String nomeSequence)  
	{ 
		String result = null;
		Session session = null;
		try
		{ 
			/*
			
			SessionImplementor sim = (SessionImplementor) HibernateUtil.openSession();
			Connection con = sim.connection();
			String sql = "SELECT " + "ID_RICEVUTA_" + nomeSequence +".NEXTVAL FROM DUAL";
			PreparedStatement prest = con.prepareStatement(sql);
			ResultSet rs1 = prest.executeQuery();	
			while (rs1.next()){
				result = rs1.getString(1);	
			}
			while (result.length()<LIMITE_SIZE_N_PROTOCOLLO)
			{
				result = "0" + result;
			}
			con.close();
			*/
			session = HibernateUtil.openSession();
			String sql = "SELECT " + "ID_RICEVUTA_" + nomeSequence +".NEXTVAL FROM DUAL";
			List query =  session.createSQLQuery(sql).list();
			result = query.get(0) +"";
			while (result.length()<LIMITE_SIZE_N_PROTOCOLLO)
			{
				result = "0" + result;
			}				
			
		} catch (RuntimeException e) { 
			e.printStackTrace();
		}
		finally{
			session.close();
			return result;
		}		
	}	
}
