package com.accenture.CCFarm.DAO;



// Generated Sep 4, 2012 12:58:22 PM by Hibernate Tools 3.4.0.CR1

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class Farmacie.
 * @see CCFarm2.Farmacie
 * @author Hibernate Tools
 */
public class FarmacieHome {
//	private static final Log log = LogFactory.getLog(CandidaturaHome.class);
	private static final Logger log = CommonLogger.getLogger("FarmacieHome");

		public void persist(Farmacie transientInstance) throws GestioneErroriException{
	
			Session session = null;
			try {
				session = HibernateUtil.openSession();
			 	session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("FarmacieHome - persist: errore persist");
		}finally{
			session.close();
		}

	}

	public void attachDirty(Farmacie instance) throws GestioneErroriException{
		log.debug("attaching dirty Farmacie instance");
		Session session = null;
		try {
				session = HibernateUtil.openSession();
			 	session.saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("FarmacieHome - attachDirty: errore attachDirty");
		}finally{
			session.close();
		}
	}

	public void attachClean(Farmacie instance) throws GestioneErroriException{
		log.debug("attaching clean Farmacie instance");
		Session session = null;
		try {
			session = HibernateUtil.openSession();
		 	session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("FarmacieHome - attachClean: errore attachClean");
		}finally{
			session.close();
		}
	}

	public void delete(Farmacie persistentInstance) throws GestioneErroriException{
		log.debug("deleting Farmacie instance");
		Session session = null;
		try {
			session = HibernateUtil.openSession();
		 	session.delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("FarmacieHome - delete: errore delete");
		}finally{
			session.close();
		}
	}

	public Farmacie merge(Farmacie detachedInstance) throws GestioneErroriException{
		log.debug("merging Farmacie instance");
		
			Session session = null;
			try {
				session = HibernateUtil.openSession();
				Farmacie result = (Farmacie)session.merge(detachedInstance);
					
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("FarmacieHome - merge: errore merge");
		}finally{
			session.close();
		}
	}



	public List findByExample(Farmacie instance) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		try {
			session = HibernateUtil.openSession();
			List results = session.createCriteria("com.accenture.CCFarm.DAO.Farmacie")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("FarmacieHome - findByExample: errore findByExample");
		} finally{
			session.close();
		}
	}
	
	public List findByFilter(FarmacieSearch instance) throws GestioneErroriException{
		log.debug("finding Farmacie instance by example");
		Session session = null;
		List<FarmacieSearch> listaFarmacie=new ArrayList<FarmacieSearch>();
	
		try {
			session = HibernateUtil.openSession();
			StringBuffer sb=new StringBuffer();
			sb.append("SELECT farmacie.COD_PF,farmacie.DES_FMC,farmacie.DES_IND,farmacie.DES_CAP,aziende_sanitarie.cod_asl,aziende_sanitarie.DENOMINAZIONE,comuni.CODICE_COMUNE,comuni.DENOMINAZIONE_ESTESA,province.CODICE_PROVINCIA,province.DENOMINAZIONE_PROVINCIA,regioni.COD_REG,regioni.denominazione_reg  " +
						"FROM farmacie,comuni,province,regioni,(select A.COD_REG||A.COD_AZIENDA cod_asl, a.denominazione from aziende_sanitarie a) aziende_sanitarie " +
						"where farmacie.codice_comune = comuni.codice_comune(+) " +
						"AND comuni.CODICE_PROVINCIA = province.CODICE_PROVINCIA(+) AND province.CODICE_REGIONE = regioni.COD_REG(+)" +
						" AND farmacie.COD_USL = aziende_sanitarie.cod_asl (+)");
						
			if(instance.getCodRg()!=null&&!instance.getCodRg().equals("")){
			  sb.append(" AND regioni.COD_REG=");
			  sb.append("'"+instance.getCodRg()+"'");
			}
			if(instance.getCodIstatComu()!=null&&!instance.getCodIstatComu().equals("")){
				  sb.append(" AND comuni.CODICE_COMUNE=");
				  sb.append("'"+instance.getCodIstatComu()+"'");
			}
			if(instance.getCodIstatProv()!=null&&!instance.getCodIstatProv().equals("")){
				  sb.append(" AND province.CODICE_PROVINCIA=");
				  sb.append("'"+instance.getCodIstatProv()+"'");
			}
			if(instance.getIndirizzo()!=null&&!instance.getIndirizzo().equals("")){
				 sb.append(" AND UPPER(farmacie.DES_IND) like ");
			      sb.append("'%"+instance.getIndirizzo().toUpperCase()+"%'");


			}
			if(instance.getpIva()!=null&&!instance.getpIva().equals("")){
				  sb.append(" AND farmacie.COD_PVA=");
				  sb.append("'"+instance.getpIva()+"'");
			}
			if(instance.getCodCap()!=null&&!instance.getCodCap().equals("")){
				  sb.append(" AND farmacie.DES_CAP=");
				  sb.append("'"+instance.getCodCap()+"'");
			}
			
			
			  
			List results = session.createSQLQuery(sb.toString()).list();
			
			log.debug("find by example successful, result size: "
					+ results.size());
			FarmacieSearch farmacia=null;
			for (Iterator iterator = results.iterator(); iterator.hasNext();) {
				farmacia=new FarmacieSearch();
				Object[] row = (Object[]) iterator.next(); 
				farmacia.setIdMinisetro((String)row[0]);
				farmacia.setDesSede((String)row[1]);
				farmacia.setIndirizzo((String)row[2]);
				farmacia.setCodCap((String)row[3]);
				farmacia.setAslRif((String)row[4]);
				farmacia.setAslDenom((String)row[5]);
				farmacia.setCodIstatComu((String)row[6]);
				farmacia.setDesComu((String)row[7]);
				farmacia.setCodIstatProv((String)row[8]);
				farmacia.setDesProv((String)row[9]);
				farmacia.setCodRg((String)row[10]);
				farmacia.setDesReg((String)row[11]);
				
				listaFarmacie.add(farmacia);
			}
			
			return listaFarmacie;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("FarmacieHome - findByFilter: errore findByFilter");
		} finally{
			session.close();
		}
		
	}
	
	
	
}
