package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.RecuperaProtocollo;
import com.accenture.CCFarm.utility.StringUtil;

/**
 * Home object for domain model class Utente.
 * @see com.accenture.CCFarm.DAO.UtenteReg
 * @author Hibernate Tools
 */
public class UtenteRegHome {

	private static final Logger log = CommonLogger.getLogger("UtenteHome");

	public UtenteReg findById(java.lang.String id) throws GestioneErroriException{
		Session session = null;
		log.debug("getting Utente instance with id: " + id);
		try {
			session = HibernateUtil.openSession();
			UtenteReg instance = (UtenteReg) session.get("com.accenture.CCFarm.DAO.UtenteReg", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("UtenteHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}
	
	public List findByExample(UtenteReg instance) throws GestioneErroriException{
		Session session = null;
		log.debug("finding Utente instance by example");
		try {
			session = HibernateUtil.openSession();
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.UtenteReg")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("UtenteHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	
	public void updatePec(String idUtente, String pecMail, Session session) throws GestioneErroriException{
		
		log.debug("update PEC_CAMBIATA in UTENTE_Reg");
		String pecCambiata="";
		try {
			
			StringBuffer sb=new StringBuffer();
			sb.append("update utente_reg u set U.PEC_MAIL = '"+ pecMail +"' where U.ID_UTENTE = '"+idUtente+"'");
		    Query query = session.createSQLQuery(sb.toString());
			int rowCount = query.executeUpdate();
			
		} 
		catch (RuntimeException re) {
			log.error("update PEC_CAMBIATA in UTENTE_reg", re);
			throw new GestioneErroriException("UtenteHome - update PEC_CAMBIATA in UTENTE_reg: errore update PEC_CAMBIATA in UTENTE_reg");
		}
		
	}
	
	
	

	
	
}
