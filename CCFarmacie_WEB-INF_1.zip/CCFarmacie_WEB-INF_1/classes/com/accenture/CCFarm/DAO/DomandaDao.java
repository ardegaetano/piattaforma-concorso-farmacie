package com.accenture.CCFarm.DAO;

import java.util.ArrayList;

public class DomandaDao {
	
	private UtenteCandidatura utenteCandidatura;
	private RequisitiMinimi requisitiMinimi;
	
	private Utente utente;// � necessario? stessi campi di utenteCandidatura
	// TAB Titoli di Studio
	private AltraLaurea altraLaurea;
	private ArrayList<AltraLaureaBis> listaAltraLaureaBis;
	private ArrayList <AltroTitolo> listaAltroTitolo;
	private ArrayList<BorsaStudio> listaBorsaStudio;
	private ArrayList<CorsoAggiornamento> listaCorsoAggiornamento;
	private ArrayList<Dottorato> listaDottorato;
	private ArrayList<Pubblicazione> listaPubblicazione;
	private ArrayList<Specializzazione> listaSpecializzazione;
	private Idoneita idoneita;
	// TAB Esercizio professionale
	private EsercizioProf esercizioProf;
	private ArrayList<EsercizioProf> listaEserciziProf;
	// TAB Versamento e documentazione
	private DichiarazioneSostitutiva dichiarazioneSostitutiva;
	private ArrayList<Documento> listaDocumenti;
	
	public UtenteCandidatura getUtenteCandidatura() {
		return utenteCandidatura;
	}
	public void setUtenteCandidatura(UtenteCandidatura utenteCandidatura) {
		this.utenteCandidatura = utenteCandidatura;
	}
	
	public RequisitiMinimi getRequisitiMinimi() {
		return requisitiMinimi;
	}
	public void setRequisitiMinimi(RequisitiMinimi requisitiMinimi) {
		this.requisitiMinimi = requisitiMinimi;
	}
	public Utente getUtente() {
		return utente;
	}
	public void setUtente(Utente utente) {
		this.utente = utente;
	}
	public AltraLaurea getAltraLaurea() {
		return altraLaurea;
	}
	public void setAltraLaurea(AltraLaurea altraLaurea) {
		this.altraLaurea = altraLaurea;
	}
	public ArrayList<AltraLaureaBis> getListaAltraLaureaBis() {
		return listaAltraLaureaBis;
	}
	public void setListaAltraLaureaBis(ArrayList<AltraLaureaBis> listaAltraLaureaBis) {
		this.listaAltraLaureaBis = listaAltraLaureaBis;
	}
	public ArrayList<AltroTitolo> getListaAltroTitolo() {
		return listaAltroTitolo;
	}
	public void setListaAltroTitolo(ArrayList<AltroTitolo> listaAltroTitolo) {
		this.listaAltroTitolo = listaAltroTitolo;
	}
	public ArrayList<CorsoAggiornamento> getListaCorsoAggiornamento() {
		return listaCorsoAggiornamento;
	}
	public void setListaCorsoAggiornamento(
			ArrayList<CorsoAggiornamento> listaCorsoAggiornamento) {
		this.listaCorsoAggiornamento = listaCorsoAggiornamento;
	}
	public ArrayList<Dottorato> getListaDottorato() {
		return listaDottorato;
	}
	public void setListaDottorato(ArrayList<Dottorato> listaDottorato) {
		this.listaDottorato = listaDottorato;
	}
	public Idoneita getIdoneita() {
		return idoneita;
	}
	public ArrayList<BorsaStudio> getListaBorsaStudio() {
		return listaBorsaStudio;
	}
	public void setListaBorsaStudio(ArrayList<BorsaStudio> listaBorsaStudio) {
		this.listaBorsaStudio = listaBorsaStudio;
	}
	public ArrayList<Pubblicazione> getListaPubblicazione() {
		return listaPubblicazione;
	}
	public void setListaPubblicazione(ArrayList<Pubblicazione> listaPubblicazione) {
		this.listaPubblicazione = listaPubblicazione;
	}
	public ArrayList<Specializzazione> getListaSpecializzazione() {
		return listaSpecializzazione;
	}
	public void setListaSpecializzazione(
			ArrayList<Specializzazione> listaSpecializzazione) {
		this.listaSpecializzazione = listaSpecializzazione;
	}
	public void setIdoneita(Idoneita idoneita) {
		this.idoneita = idoneita;
	}
	public EsercizioProf getEsercizioProf() {
		return esercizioProf;
	}
	public void setEsercizioProf(EsercizioProf esercizioProf) {
		this.esercizioProf = esercizioProf;
	}
	public ArrayList<EsercizioProf> getListaEserciziProf() {
		return listaEserciziProf;
	}
	public void setListaEserciziProf(ArrayList<EsercizioProf> listaEserciziProf) {
		this.listaEserciziProf = listaEserciziProf;
	}
	public DichiarazioneSostitutiva getDichiarazioneSostitutiva() {
		return dichiarazioneSostitutiva;
	}
	public void setDichiarazioneSostitutiva(
			DichiarazioneSostitutiva dichiarazioneSostitutiva) {
		this.dichiarazioneSostitutiva = dichiarazioneSostitutiva;
	}
	public ArrayList<Documento> getListaDocumenti() {
		return listaDocumenti;
	}
	public void setListaDocumenti(ArrayList<Documento> listaDocumenti) {
		this.listaDocumenti = listaDocumenti;
	}
	
}
