package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.PrintException;

/**
* Home object for domain model class LogAccessi.
* @see com.accenture.CCFarm.DAO.LogAccessi
* @author Hibernate Tools
*/
public class LogAccessiHome {

	private static final Logger log = CommonLogger.getLogger("LogAccessiHome");
	
	public void persist(LogAccessi transientInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting LogAccessi instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("LogAccessiHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(LogAccessi instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty LogAccessi instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("LogAccessiHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	
	}

	public void attachClean(LogAccessi instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean LogAccessi instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("LogAccessiHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(LogAccessi persistentInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting LogAccessi instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("LogAccessiHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public LogAccessi merge(LogAccessi detachedInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging LogAccessi instance");
		try {
			LogAccessi result = (LogAccessi) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("LogAccessiHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public LogAccessi findById(String id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting Nazioni instance with id: " + id);
		try {
			LogAccessi instance = (LogAccessi) session.get("com.accenture.CCFarm.DAO.LogAccessi", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("LogAccessiHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(LogAccessi instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Nazioni instance by example");
		try {
				List results = session
					.createCriteria("com.accenture.CCFarm.DAO.LogAccessi")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("LogAccessiHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}

	public String getSequenceIdLog() throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_LOG.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("getSequenceIdLog() - LogAccessiHome failed : "+ PrintException.stack2string(re));
			throw new GestioneErroriException("LogAccessiHome - getSequenceIdLog: errore getSequenceIdLog");
		}
		finally{
			session.close();
		}
	}


}
