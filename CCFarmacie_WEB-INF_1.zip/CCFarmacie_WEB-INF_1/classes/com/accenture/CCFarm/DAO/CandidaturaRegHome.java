package com.accenture.CCFarm.DAO;

// Generated Aug 14, 2012 10:31:12 AM by Hibernate Tools 3.4.0.CR1



import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CCFarmLogger;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class CandidaturaReg.
 * 
 * @see CCFarm2.CandidaturaReg
 * @author Hibernate Tools
 */
public class CandidaturaRegHome {

	private static final Logger log = CommonLogger.getLogger("CandidaturaRegHome");
	
	private static final String flagValoreVero  = AppProperties.getAppProperty("flag.valore.vero");
	
//	public List<UtenteReg> listaUtentiXIdCandidatura(String id_candidatura) throws GestioneErroriException {
//		Session session = HibernateUtil.openSession();
//		Transaction trx = session.beginTransaction();
//		List<UtenteReg> result = new ArrayList<UtenteReg>();
//		List<CandidaturaReg> listCandida = null;
//		UtenteRegHome utenteDAO = new UtenteRegHome();
//		try {
//			Query query = session.createQuery("from CandidaturaReg where id_candidatura = :id_candidatura ");
//			query.setParameter("id_candidatura", id_candidatura);
//			listCandida = query.list();
//			for (CandidaturaReg w_cand : listCandida)
//			{
//					UtenteReg w_utente = null;
//					String id_utente = w_cand.getIdUtente();
//					w_utente = utenteDAO.findById(id_utente);
//					if (w_utente!=null)
//					{
//						result.add(w_utente);
//					}
//			}
//			
//		} catch (Exception e) {
//			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  [" + id_candidatura + "]", e);
//			throw new GestioneErroriException("CandidaturaRegHome - listaUtentiXIdCandidatura: errore listaUtentiXIdCandidatura");
//		} finally {
//			session.close();
//		}
//		return result;
//	}
	public void saveOrUpdate(CandidaturaReg instance)
			throws GestioneErroriException {
		Session session = null;
		Transaction trx = null;
		CCFarmLogger.log("saveOrUpdate CandidaturaReg instance", Level.INFO_INT,
				CandidaturaRegHome.class);
		try {
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			
			session.saveOrUpdate(instance);

			trx.commit();
			CCFarmLogger.log(
					"Salvataggio avvenuto con successo per la CandidaturaReg: idUtente"
							+ instance.getIdUtente(), Level.INFO_INT,
					CandidaturaRegHome.class);

		}
		catch (Exception e) {
			
			if(trx != null)
				trx.rollback();
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", e);
			throw new GestioneErroriException("CandidaturaRegHome - saveOrUpdate: errore CandidaturaRegHome - saveOrUpdate: errore nell' aggiornmaneto della candidatura: idUtente");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
//	
//	public void annullaAssociataUpdate(List<CandidaturaReg> listCandAsso, String idUtente) throws GestioneErroriException {
//		Session session = HibernateUtil.openSession();
//		Transaction trx = session.beginTransaction();
//		CCFarmLogger.log("saveOrUpdate CandidaturaReg instance", Level.INFO_INT, CandidaturaRegHome.class);
//		java.util.Date dataSys= new java.util.Date();
//		boolean ok = true;
//		
//		for (int i = 0; i < listCandAsso.size(); i++) {
//			CandidaturaReg instance =  new CandidaturaReg();
//			instance = (CandidaturaReg) listCandAsso.get(i);
////			instance.setStatoDomanda("A");
////			instance.setStatoRegistrazione("A");
////			instance.setLastUpdateDateCand(new java.sql.Timestamp(dataSys.getTime()));
////			instance.setLastUpdatedByCand(idUtente);
//			try {
//				session.saveOrUpdate(instance);
//				CCFarmLogger.log("Salvataggio avvenuto con successo per la candidatura: idUtente"
//								+ instance.getIdUtente(), Level.INFO_INT, CandidaturaRegHome.class);
//				
//			} catch (Exception e) {
//				trx.rollback();
//				log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", e);
//				throw new GestioneErroriException("CandidaturaHome - saveOrUpdate: errore nell' aggiornmaneto della candidatura: idUtente");
//			}finally{
//					trx.commit();
//					session.close();	
//				
//			}
//
//		}	
//		
//	
//	
//	}
//	
//	
//	
//	
//	public UtenteCandidaturaReg findByUserId(String id_utente) throws GestioneErroriException
//	{
//		UtenteCandidaturaReg result = null;
//		CCFarmLogger.log("findByUserId UtenteCandidaturaReg id: " + id_utente, Level.INFO_INT,
//				CandidaturaRegHome.class);
//		Session session = HibernateUtil.openSession();
//		try {
//			session = HibernateUtil.openSession();
//			result = (UtenteCandidaturaReg) session.get(
//					"com.accenture.CCFarm.DAO.UtenteCandidaturaReg", id_utente);
//			if (result == null) {
//				CCFarmLogger.log("get failed, no instance found",
//						Level.INFO_INT, CandidaturaRegHome.class);
//			} else {
//				CCFarmLogger.log("get successful, instance found",
//						Level.INFO_INT, CandidaturaRegHome.class);
//			}
//			
//		} catch (RuntimeException re) {
//			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", re);
//			throw new GestioneErroriException("CandidaturaRegHome - findByUserId: errore nell' findByUserId della candidatura:");
//		} finally {
//			session.close();
//			return result;
//		}		
//	}		
	public CandidaturaReg findById(java.lang.String id) throws GestioneErroriException {
		
		CCFarmLogger.log("findById CandidaturaReg id: " + id, Level.INFO_INT, CandidaturaRegHome.class);
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			CandidaturaReg instance = (CandidaturaReg) session.get("com.accenture.CCFarm.DAO.CandidaturaReg", id);
			
			if(instance == null) {
				CCFarmLogger.log("get failed, no instance found",
						Level.INFO_INT, CandidaturaRegHome.class);
			}
			else {
				CCFarmLogger.log("get successful, instance found",
						Level.INFO_INT, CandidaturaRegHome.class);
			}
			return instance;
		}
		catch(RuntimeException re) {
			
			log.error("CandidaturaRegHome - findById: errore nella ricerca della candidatura", re);
			throw new GestioneErroriException("CandidaturaRegHome - findById: errore nella ricerca della candidatura");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}

	//restituisce true se per la candidatura associata all'utente specificato risulta impostato il flag "abilita scelta sedi"
	public boolean controllaAbilitazioneSceltaSedi(String idUtente) throws GestioneErroriException {
	
		Session session = null;
		
		try {
			
			CandidaturaReg candidaturaReg = findById(idUtente);
			
			return candidaturaReg != null &&
				   candidaturaReg.getFlagAbilitaSceltaSedi() != null &&
				   candidaturaReg.getFlagAbilitaSceltaSedi().equalsIgnoreCase(flagValoreVero);
		}
		catch(Exception e) {
			
			log.error("controllaAbilitazioneSceltaSedi() failed", e);
			throw new GestioneErroriException("controllaAbilitazioneSceltaSedi() failed");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//imposta il flag "scelta sedi" e resetta il flag "abilita scelta sedi" per l'utente specificato
	public int confermaSceltaSedi(Session session, String idUtente) throws GestioneErroriException {
		
		try {
			
			String hqlUpdateString = "UPDATE CandidaturaReg cr"
								   + " SET cr.flagSceltaSedi = :flagSceltaSedi"
								   + " WHERE cr.idUtente = :idUtente";
			
			Query updateQuery = session.createQuery(hqlUpdateString);
			updateQuery.setParameter("flagSceltaSedi", flagValoreVero);
			updateQuery.setParameter("idUtente", idUtente);
			
			return updateQuery.executeUpdate();
		}
		catch(Exception e) {
			
			log.error("confermaSceltaSedi() failed", e);
			throw new GestioneErroriException("confermaSceltaSedi() failed");
		}
	}

//	public ArrayList<CandidaturaReg> findByExample(CandidaturaReg instance)
//			throws GestioneErroriException {
//		CCFarmLogger
//				.log("findByExample CandidaturaReg idUtente: "
//						+ instance.getIdUtente(), Level.INFO_INT,
//						CandidaturaRegHome.class);
//		Session session = HibernateUtil.openSession();
//		try {
//			session = HibernateUtil.openSession();
//			@SuppressWarnings("unchecked")
//			ArrayList<CandidaturaReg> results = (ArrayList<CandidaturaReg>) session
//					.createCriteria("com.accenture.CCFarm.DAO.CandidaturaReg")
//					.add(Example.create(instance)).list();
//			CCFarmLogger.log(
//					"findByExample successful CandidaturaReg , result size: "
//							+ results.size(), Level.INFO_INT,
//					CandidaturaRegHome.class);
//			return results;
//		} catch (RuntimeException re) {
//			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", re);
//			throw new GestioneErroriException("CandidaturaHome - findByExample: errore nell' findByExample della candidatura:");
//		} finally {
//			session.close();
//		}
//	}
//	
//	public void aggiornaAmmissione(List<CandidaturaReg> listCandAmmesso, String ammesso) throws GestioneErroriException {
//		Session session = HibernateUtil.openSession();
//		Transaction trx = session.beginTransaction();
//		CCFarmLogger.log("saveOrUpdate CandidaturaReg instance", Level.INFO_INT, CandidaturaRegHome.class);
//		
//		try {
//			for (int i = 0; i < listCandAmmesso.size(); i++) {
//				CandidaturaReg instance =  new CandidaturaReg();
//				instance = (CandidaturaReg) listCandAmmesso.get(i);
//				instance.setAmmesso(ammesso);
//					session.saveOrUpdate(instance);
//					CCFarmLogger.log("Salvataggio avvenuto con successo per la candidatura: idUtente"
//									+ instance.getIdUtente(), Level.INFO_INT, CandidaturaRegHome.class);
//			
//			}	
//			trx.commit();
//		} catch (Exception e) {
//			trx.rollback();
//			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", e);
//			throw new GestioneErroriException("CandidaturaHome - saveOrUpdate: errore nell' aggiornmaneto della candidatura: idUtente");
//		}finally{
//			session.close();	
//		}
//
//	}
}
