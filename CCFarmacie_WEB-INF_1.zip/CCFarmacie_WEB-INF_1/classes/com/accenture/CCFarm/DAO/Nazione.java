package com.accenture.CCFarm.DAO;

import java.sql.Date;

@SuppressWarnings("serial")
public class Nazione implements java.io.Serializable {

	private int idNazione;
	private String codIsoNazione;
	private String dscIsoNazione;
	private String dscNazioneEstesa;
	private String flagStatoUe;
	private Date dataInizioVal;
	private Date dataFineVal;
	private String dscNazioneEstesaDe;
	
	public Nazione() {}
	
	public Nazione(int idNazione, String codIsoNazione, String dscIsoNazione,
			String dscNazioneEstesa, String flagStatoUe, Date dataInizioVal,
			Date dataFineVal) {
		super();
		this.idNazione = idNazione;
		this.codIsoNazione = codIsoNazione;
		this.dscIsoNazione = dscIsoNazione;
		this.dscNazioneEstesa = dscNazioneEstesa;
		this.flagStatoUe = flagStatoUe;
		this.dataInizioVal = dataInizioVal;
		this.dataFineVal = dataFineVal;
	}

	public Nazione(int idNazione, String codIsoNazione, String dscIsoNazione,
			String dscNazioneEstesa, String flagStatoUe, Date dataInizioVal,
			Date dataFineVal, String dscNazioneEstesaDe) {
		super();
		this.idNazione = idNazione;
		this.codIsoNazione = codIsoNazione;
		this.dscIsoNazione = dscIsoNazione;
		this.dscNazioneEstesa = dscNazioneEstesa;
		this.flagStatoUe = flagStatoUe;
		this.dataInizioVal = dataInizioVal;
		this.dataFineVal = dataFineVal;
		this.dscNazioneEstesaDe = dscNazioneEstesaDe;
	}

	public int getIdNazione() {
		return idNazione;
	}

	public void setIdNazione(int idNazione) {
		this.idNazione = idNazione;
	}

	public String getCodIsoNazione() {
		return codIsoNazione;
	}

	public void setCodIsoNazione(String codIsoNazione) {
		this.codIsoNazione = codIsoNazione;
	}

	public String getDscIsoNazione() {
		return dscIsoNazione;
	}

	public void setDscIsoNazione(String dscIsoNazione) {
		this.dscIsoNazione = dscIsoNazione;
	}

	public String getDscNazioneEstesa() {
		return dscNazioneEstesa;
	}

	public void setDscNazioneEstesa(String dscNazioneEstesa) {
		this.dscNazioneEstesa = dscNazioneEstesa;
	}

	public String getFlagStatoUe() {
		return flagStatoUe;
	}

	public void setFlagStatoUe(String flagStatoUe) {
		this.flagStatoUe = flagStatoUe;
	}

	public Date getDataInizioVal() {
		return dataInizioVal;
	}

	public void setDataInizioVal(Date dataInizioVal) {
		this.dataInizioVal = dataInizioVal;
	}

	public Date getDataFineVal() {
		return dataFineVal;
	}

	public void setDataFineVal(Date dataFineVal) {
		this.dataFineVal = dataFineVal;
	}

	public String getDscNazioneEstesaDe() {
		return dscNazioneEstesaDe;
	}

	public void setDscNazioneEstesaDe(String dscNazioneEstesaDe) {
		this.dscNazioneEstesaDe = dscNazioneEstesaDe;
	}
}