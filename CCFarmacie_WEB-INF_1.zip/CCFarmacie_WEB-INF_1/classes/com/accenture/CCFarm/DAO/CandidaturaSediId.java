package com.accenture.CCFarm.DAO;

import java.io.Serializable;


public class CandidaturaSediId implements Serializable
{
	private String idCandidatura;
	private String idFarm;
	
	public CandidaturaSediId() {
		
	}
	
	public CandidaturaSediId(String idCandidatura, String idFarm) {
		
		this.idCandidatura = idCandidatura;
		this.idFarm = idFarm;
	}
	
	public String getIdCandidatura() {
		return idCandidatura;
	}

	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}

	public String getIdFarm() {
		return idFarm;
	}

	public void setIdFarm(String idFarm) {
		this.idFarm = idFarm;
	}
}
