package com.accenture.CCFarm.DAO;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
* Home object for domain model class Nazione.
* @see com.accenture.CCFarm.DAO.Nazione
* @author Hibernate Tools
*/
public class NazioneHome {

//	private static final Log log = LogFactory.getLog(NazioneHome.class);
	private static final Logger log = CommonLogger.getLogger("NazioneHome");

	public void persist(Nazione transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting Nazione instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("NazioneHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(Nazione instance) throws GestioneErroriException  {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Nazione instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("NazioneHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(Nazione instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Nazione instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("NazioneHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(Nazione persistentInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting Nazione instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("NazioneHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public Nazione merge(Nazione detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging Nazione instance");
		try {
			Nazione result = (Nazione) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("NazioneHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public Nazione findById(java.lang.String id) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting Nazioni instance with id: " + id);
		try {
			Nazione instance = (Nazione) session.get("com.accenture.CCFarm.DAO.Nazione", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("NazioneHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(Nazione instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding Nazioni instance by example");
		try {
				List results = session
					.createCriteria("com.accenture.CCFarm.DAO.Nazione")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("NazioneHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
}
