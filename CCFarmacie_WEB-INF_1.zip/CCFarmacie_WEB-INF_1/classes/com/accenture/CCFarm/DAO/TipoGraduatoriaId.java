package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.Date;

@SuppressWarnings("serial")
public class TipoGraduatoriaId implements java.io.Serializable {



	private String codRegione;
	private BigDecimal progressivo;
	
	public TipoGraduatoriaId() {}

	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}

	public BigDecimal getProgressivo() {
		return progressivo;
	}

	public void setProgressivo(BigDecimal progressivo) {
		this.progressivo = progressivo;
	}


	
		
}