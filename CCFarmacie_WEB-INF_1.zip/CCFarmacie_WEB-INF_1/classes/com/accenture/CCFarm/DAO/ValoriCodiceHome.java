package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class ValoriCodice.
 * @see com.accenture.CCFarm.DAO.ValoriCodice
 * @author Hibernate Tools
 */
public class ValoriCodiceHome {

//	private static final Log log = LogFactory.getLog(ValoriCodiceHome.class);
	private static final Logger log = CommonLogger.getLogger("ValoriCodiceHome");

	public void persist(ValoriCodice transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting ValoriCodice instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("ValoriCodiceHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(ValoriCodice instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty ValoriCodice instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("ValoriCodiceHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(ValoriCodice instance) throws GestioneErroriException  {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean ValoriCodice instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("ValoriCodiceHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(ValoriCodice persistentInstance) throws GestioneErroriException  {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting ValoriCodice instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("ValoriCodiceHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public ValoriCodice merge(ValoriCodice detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging ValoriCodice instance");
		try {
			ValoriCodice result = (ValoriCodice) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("ValoriCodiceHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public ValoriCodice findById(ValoriCodiceId id) throws GestioneErroriException  {
		Session session = HibernateUtil.openSession();
		log.debug("getting ValoriCodice instance with id: " + id);
		try {
			ValoriCodice instance = (ValoriCodice) session.get(ValoriCodice.class, id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("ValoriCodiceHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(ValoriCodice instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding ValoriCodice instance by example");
		try {
			List results = session
					.createCriteria(ValoriCodice.class)
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("ValoriCodiceHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
}
