package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.PrintException;

/**
 * Home object for domain model class AnagraficaFarm.
 * @see com.accenture.CCFarm.DAO.AnagraficaFarm
 * @author Hibernate Tools
 */
public class AnagraficaFarmHome {

//	private static final Log log = LogFactory.getLog(AnagraficaFarmHome.class);
	private static final Logger log = CommonLogger.getLogger("AnagraficaFarmHome");

	public void persist(AnagraficaFarm transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting AnagraficaFarm instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("AnagraficaFarmHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(AnagraficaFarm instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty AnagraficaFarm instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("AnagraficaFarmHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(AnagraficaFarm instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean AnagraficaFarm instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("AnagraficaFarmHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(AnagraficaFarm persistentInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting AnagraficaFarm instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("AnagraficaFarmHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public AnagraficaFarm merge(AnagraficaFarm detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging AnagraficaFarm instance");
		try {
			AnagraficaFarm result = (AnagraficaFarm) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("AnagraficaFarmHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public AnagraficaFarm findById(java.lang.String id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting AnagraficaFarm instance with id: " + id);
		try {
			AnagraficaFarm instance = (AnagraficaFarm) session.get("com.accenture.CCFarm.DAO.AnagraficaFarm", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("AnagraficaFarmHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(AnagraficaFarm instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding AnagraficaFarm instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.AnagraficaFarm")
					.add(Example.create(instance)).list();
			
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("AnagraficaFarmHome - findByExample: errore nel caricamento del file");
		}
		finally{
			session.close();
		}
		
	}
	
	public List findByExampleOrdered(AnagraficaFarm instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding AnagraficaFarm instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.AnagraficaFarm")
					.addOrder(Order.asc("descrPrvFarm"))
					.addOrder(Order.asc("frazioneFarm"))
					.addOrder(Order.asc("NProgressivo"))
					.add(Example.create(instance)).list();
			
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("AnagraficaFarmHome - findByExample: errore nel caricamento del file");
		}
		finally{
			session.close();
		}
		
	}
	
	public String getSequenceIdSede() throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_FARM.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("getSequenceIdSede() - AnagraficaFarmHome getSequenceIdSede failed : "+ PrintException.stack2string(re));
			throw new GestioneErroriException("AnagraficaFarmHome - getSequenceIdSede: errore getSequenceIdSede");
		}
		finally{
			session.close();
		}
	}
}
