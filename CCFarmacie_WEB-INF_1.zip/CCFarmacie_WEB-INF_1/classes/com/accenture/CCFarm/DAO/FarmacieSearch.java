package com.accenture.CCFarm.DAO;


@SuppressWarnings("serial")
public class FarmacieSearch implements java.io.Serializable {

	private String codIstatProv;
	private String desProv;
	private String codIstatComu;
	private String desComu;
	private String idMinisetro;
	private String desSede;
	private String indirizzo;
	private String codCap;
	private String codRg;
	private String desReg;
	private String pIva;
	private String aslRif;
	private String aslDenom;
	
	public String getCodRg() {
		return codRg;
	}

	public String getpIva() {
		return pIva;
	}

	public void setpIva(String pIva) {
		this.pIva = pIva;
	}

	public void setCodRg(String codRg) {
		this.codRg = codRg;
	}

	public String getDesReg() {
		return desReg;
	}

	public void setDesReg(String desReg) {
		this.desReg = desReg;
	}

	public FarmacieSearch() {}

	public String getCodIstatProv() {
		return codIstatProv;
	}

	public void setCodIstatProv(String codIstatProv) {
		this.codIstatProv = codIstatProv;
	}

	public String getDesProv() {
		return desProv;
	}

	public void setDesProv(String desProv) {
		this.desProv = desProv;
	}

	public String getCodIstatComu() {
		return codIstatComu;
	}

	public void setCodIstatComu(String codIstatComu) {
		this.codIstatComu = codIstatComu;
	}

	public String getDesComu() {
		return desComu;
	}

	public void setDesComu(String desComu) {
		this.desComu = desComu;
	}

	public String getIdMinisetro() {
		return idMinisetro;
	}

	public void setIdMinisetro(String idMinisetro) {
		this.idMinisetro = idMinisetro;
	}

	public String getDesSede() {
		return desSede;
	}

	public void setDesSede(String desSede) {
		this.desSede = desSede;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getCodCap() {
		return codCap;
	}

	public void setCodCap(String codCap) {
		this.codCap = codCap;
	}

	public String getAslRif() {
		return aslRif;
	}

	public void setAslRif(String aslRif) {
		this.aslRif = aslRif;
	}

	public String getAslDenom() {
		return aslDenom;
	}

	public void setAslDenom(String aslDenom) {
		this.aslDenom = aslDenom;
	}
	
	
	
	
}