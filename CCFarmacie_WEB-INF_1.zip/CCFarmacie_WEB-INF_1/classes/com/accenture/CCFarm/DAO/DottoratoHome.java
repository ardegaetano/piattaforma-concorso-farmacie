package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CCFarmLogger;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.PrintException;

/**
 * Home object for domain model class Specializzazione.
 * @see com.accenture.CCFarm.DAO.Specializzazione
 * @author Hibernate Tools
 */
public class DottoratoHome {

//	private static final Log log = LogFactory
//			.getLog(DottoratoHome.class);
	private static final Logger log = CommonLogger.getLogger("DottoratoHome");

	public void persist(Dottorato transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting Dottorato instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("DottoratoHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(Dottorato instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Dottorato instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("DottoratoHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(Dottorato instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Dottorato instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("DottoratoHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(Dottorato persistentInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting Dottorato instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("DottoratoHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public Dottorato merge(Dottorato detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging BorsaStudio instance");
		try {
			Dottorato result = (Dottorato) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("DottoratoHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public Dottorato findById(java.lang.String id) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting Dottorato instance with id: " + id);
		try {
			Dottorato instance = (Dottorato) session.get("com.accenture.CCFarm.DAO.Dottorato", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("DottoratoHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(Dottorato instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding BorsaDottorato instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.Dottorato")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("DottoratoHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	public List<Dottorato> findByExampleHql(String id) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting Nazioni instance with id: " + id);
		Transaction trx = session.beginTransaction();
		List<Dottorato> result = new ArrayList<Dottorato>();
		try {
			Query query = session.createQuery("from Dottorato where idDomandaDottorato = :idDomandaDottorato ");
			query.setParameter("idDomandaDottorato", id);
			result = query.list();		
		} catch (Exception e) {	
			log.error("Errore Lettura Dottorato.. da ID_DOCUMENTO_DOTT", e);
			throw new GestioneErroriException("DottoratoHome - findByExampleHql: errore findByExampleHql");
		}		
		finally{
			session.close();
			return result;		
		}
	}	
	
	public String getSequenceIdDottorato() throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_DOTTORATO.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("getSequenceIdDottorato() - "+ PrintException.stack2string(re));
			throw new GestioneErroriException("DottoratoHome - getSequenceIdDottorato: errore getSequenceIdDottorato");
		}
		finally{
			session.close();
		}
	}
	
	
}
