package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.transform.Transformers;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PDFModulo.AccettazioneRinunciaSedeEntityPdf;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.StaticDefinitions;
import com.accenture.mailer.concorsofarma.GestoreMail;
import com.accenture.mailer.concorsofarma.data.MailBean;

public class AccettazioneRinunciaSedeHome {
	
	private static final Logger logger = CommonLogger.getLogger("AccettazioneRinunciaSedeHome");
	
	private static final String flagValoreVero = AppProperties.getAppProperty("flag.valore.vero");
	
	private static int limiteDimensioneProtocollo = 6;
	private static char paddingCharProtocollo = '0';
	
	public AccettazioneRinunciaSedeHome() {
		
	}
	
	//determina quale sede � stata abbinata dal sistema alla candidatura specificata
	public AnagraficaFarm determinaSedeAbbinata(String idCandidatura) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			DetachedCriteria innerCriteria = DetachedCriteria.forClass(CandidaturaSedi.class, "candidaturaSedi");
			//condizioni
			//id candidatura
			innerCriteria.add(Restrictions.eq("candidaturaSedi.id.idCandidatura", idCandidatura));
			//flag "associata" a true
			innerCriteria.add(Restrictions.eq("candidaturaSedi.flagAssociata", flagValoreVero));
			
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.property("candidaturaSedi.id.idFarm"), "idFarm");
			innerCriteria = innerCriteria.setProjection(projectionList);
			
			Criteria criteria = session.createCriteria(AnagraficaFarm.class);
			//condizioni
			criteria.add(Subqueries.propertyEq("idFarm", innerCriteria));
			
			//AnagraficaFarm result = (AnagraficaFarm)criteria.uniqueResult();
			//return result;			
			return (AnagraficaFarm) criteria.uniqueResult();
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSedeHome - ricerca sede abbinata fallita", e);
			throw new GestioneErroriException("AccettazioneRinunciaSedeHome - ricerca sede abbinata fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//restituisce true se la candidatura associata all'utente specificato risulta abilitata all'accettazione/rifiuto della sede assegnata (flag_scelta_sedi = true e flag_confermata = null)
	//NOTA: test su "flag_scelta_sedi" sul record di candidatura_reg relativo alla candidatura dell'utente: se valorizzato e pari a true significa che l'utente ha gi� espresso una preferenza sulle sedi
	//		test su "flag_confermata" sul record di candidatura_sedi relativo alla sede assegnata all'utente: se valorizzato (per la sede che risulta assegnata) significa che � stata gi� effettuata una scelta (accettazione o rinuncia della stessa)
	public boolean controllaAbilitazioneAccettazioneRinunciaSede(String idUtente) throws GestioneErroriException {
	
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			String hqlString = "SELECT cr.flagSceltaSedi, cs.flagConfermata"
							  + " FROM CandidaturaReg cr, CandidaturaSedi cs"
							 + " WHERE cr.idUtente = :idUtente"
							   + " AND cr.idCandidatura = cs.id.idCandidatura"
							   + " AND cs.flagAssociata = :flagAssociata";
			
			Query query = session.createQuery(hqlString);
			query.setParameter("idUtente", idUtente);
			query.setParameter("flagAssociata", flagValoreVero);
			
			Object[] result = (Object[]) query.uniqueResult();
			
			return result != null && ((String)result[0]).equalsIgnoreCase(flagValoreVero) && result[1] == null;
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSedeHome - controllaAbilitazioneAccettazioneRinunciaSede() failed", e);
			throw new GestioneErroriException("AccettazioneRinunciaSedeHome - controllaAbilitazioneAccettazioneRinunciaSede() failed");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//restituisce il prossimo valore utile per la sequence "ricevuta scelta sedi" propria della regione di candidatura
	public String getIdRicevuta(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		try {
			
			session = HibernateUtil.openSession();
			
			String sqlString = "SELECT ID_RICEVUTA_" + codiceRegione + ".NEXTVAL FROM DUAL";
			Query query = session.createSQLQuery(sqlString);
			BigDecimal idRicevuta = (BigDecimal) query.uniqueResult();
			
			return StringUtils.leftPad(idRicevuta.toString(), limiteDimensioneProtocollo, paddingCharProtocollo);
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSedeHome - GetIdRicevuta() fallito", e);
			throw new GestioneErroriException("AccettazioneRinunciaSedeHome - GetIdRicevuta() fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	public AccettazioneRinunciaSedeEntityPdf getDatiPerRicevuta(String idUtente) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			String sqlQuery= "SELECT U.COD_REG_UTENTE as codiceRegione, "
					
								  + "(SELECT R.denominazione_reg"
								  + " FROM regioni R"
								  + " WHERE R.COD_REG = U.COD_REG_UTENTE) as descRegione, "
								  
								  + "U.COGNOME_UTENTE as cognome, "
							 	  + "U.NOME_UTENTE as nome, "
							 	  + "U.CODICE_FISCALE_UTENTE as codiceFiscale, "
							 	  + "to_char(U.DATA_NASCITA_UTENTE, 'dd/MM/yyyy') as dataNascita, "
							 	  
							 	  + "(SELECT C.denominazione"
								    + " FROM comuni C"
								   + " WHERE C.CODICE_COMUNE = U.LUOGO_NASCITA_UTENTE) as comuneNascita, "
								  
								  + "(SELECT P.denominazione_provincia"
									+ " FROM province P"
								   + " WHERE P.CODICE_PROVINCIA = U.PRV_NASCITA_UTENTE) as provinciaNascita, "
								  
								  + "U.LUOGO_NASCITA_ESTERA as luogoNascitaEstero, "
								  
								  + "U.NAZIONE_NASCITA_UTENTE as codiceStatoNascita, "
								  
								  + "(SELECT dsc_naz_estesa"
								    + " FROM nazioni N"
								   + " WHERE N.COD_ISO_NAZIONE = U.NAZIONE_NASCITA_UTENTE) as statoNascita, "
								  
								  + "G.NUMERO_PROTOCOLLO as numeroProtocolloDomanda, "
								  + "decode(CR.MODALITA_CANDIDATURA, 'S', 'SINGOLA', 'A', 'ASSOCIATA') as modalitaPartecipazione"
                                 
                          + " FROM utente_reg U, candidatura_reg CR, graduatoria G"
                         + " WHERE U.ID_UTENTE = CR.id_utente"
	                       + " AND cr.id_candidatura = G.ID_CANDIDATURA"
	                       + " AND U.ID_UTENTE = :idUtente";
			
			SQLQuery query = session.createSQLQuery(sqlQuery);
			query.addScalar("codiceRegione", Hibernate.STRING);
			query.addScalar("descRegione", Hibernate.STRING);
			query.addScalar("cognome", Hibernate.STRING);
			query.addScalar("nome", Hibernate.STRING);
			query.addScalar("codiceFiscale", Hibernate.STRING);
			query.addScalar("dataNascita", Hibernate.STRING);
			query.addScalar("comuneNascita", Hibernate.STRING);
			query.addScalar("provinciaNascita", Hibernate.STRING);
			query.addScalar("luogoNascitaEstero", Hibernate.STRING);
			query.addScalar("codiceStatoNascita", Hibernate.STRING);
			query.addScalar("statoNascita", Hibernate.STRING);
			query.addScalar("numeroProtocolloDomanda", Hibernate.STRING);
			query.addScalar("modalitaPartecipazione", Hibernate.STRING);
			query.setParameter("idUtente", idUtente);
			query.setResultTransformer(Transformers.aliasToBean(AccettazioneRinunciaSedeEntityPdf.class));
			
			return (AccettazioneRinunciaSedeEntityPdf) query.uniqueResult();
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSedeHome - recupero dei dati per la ricevuta PDF fallito", e);
			throw new GestioneErroriException("AccettazioneRinunciaSedeHome - recupero dei dati per la ricevuta PDF fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	@SuppressWarnings("deprecation")
	public void sendMail(MailBean mailBean) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			Transaction trx = session.beginTransaction();
			
			GestoreMail gestoreMail = new GestoreMail();
			Object[] indiciMail = new Object[1];
			
			indiciMail[0] = gestoreMail.saveMail(mailBean, StaticDefinitions.MAIL_PROPERTIES, session.connection());
			trx.commit();
			//Provo ad inviare la mail 
            try {
            	gestoreMail.sendMail( (Integer) indiciMail[0], StaticDefinitions.MAIL_PROPERTIES, session.connection());
            } catch (Throwable thr) {
            	logger.error("AccettazioneRinunciaSedeHome -  : errore nell' invio della mail " + thr.getMessage(), thr);
            }
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSedeHome - invio ricevuta di accettazione/rinuncia sede fallito", e);
			throw new GestioneErroriException("AccettazioneRinunciaSedeHome - invio ricevuta di accettazione/rinuncia sede fallito");
		}
		finally {
			if(session != null)
				session.close();
		}
	}
}
