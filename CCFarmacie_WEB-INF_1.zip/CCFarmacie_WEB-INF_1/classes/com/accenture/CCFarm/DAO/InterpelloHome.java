package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.HibernateUtil;

public class InterpelloHome {

	private static final Logger log = CommonLogger.getLogger("InterpelloHome");
	
	private static final String codiceInterpelloPredisposto = AppProperties.getAppProperty("codice.interpello.predisposto");
	private static final String codiceInterpelloPubblicato = AppProperties.getAppProperty("codice.interpello.pubblicato");
	private static final String codiceInterpelloChiuso = AppProperties.getAppProperty("codice.interpello.chiuso");

	//restituisce, per la regione specificata, l'ultimo interpello inserito (se risulta con stato "pubblicato")
	@SuppressWarnings("unchecked")
	public Interpello determinaInterpelloCorrente(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			DetachedCriteria innerCriteria = DetachedCriteria.forClass(Interpello.class, "interpello");
			//condizioni
			innerCriteria.add(Restrictions.eq("interpello.id.codReg", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.max("interpello.id.idInterpello"));
			innerCriteria = innerCriteria.setProjection(projectionList);
			
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			criteria.add(Subqueries.propertyEq("id.idInterpello", innerCriteria));
			
			//stato "pubblicato"
			criteria.add(Restrictions.eq("stato", codiceInterpelloPubblicato));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			if(results == null || results.isEmpty())
				return null;
			
			return results.get(0);
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - ricerca ultimo interpello fallita", e);
			throw new GestioneErroriException("InterpelloHome - ricerca ultimo interpello fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//restituisce, per la regione specificata, l'ultimo interpello inserito (se risulta con stato "chiuso" o "pubblicato")
	@SuppressWarnings("unchecked")
	public Interpello determinaInterpelloCorrentePubblicatoChiuso(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			DetachedCriteria innerCriteria = DetachedCriteria.forClass(Interpello.class, "interpello");
			//condizioni
			innerCriteria.add(Restrictions.eq("interpello.id.codReg", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.max("interpello.id.idInterpello"));
			innerCriteria = innerCriteria.setProjection(projectionList);
			
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			criteria.add(Subqueries.propertyEq("id.idInterpello", innerCriteria));
			
			//stato "chiuso" oppure "pubblicato"
			criteria.add(Restrictions.or(Restrictions.eq("stato", codiceInterpelloChiuso), Restrictions.eq("stato", codiceInterpelloPubblicato)));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			if(results == null || results.isEmpty())
				return null;
			
			return results.get(0);
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito", e);
			throw new GestioneErroriException("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//ricerca tutti gli interpelli registrati fino a questo momento per la regione specificata (ordinati per progressivo CRESCENTE)
	@SuppressWarnings("unchecked")
	public List<Interpello> trovaInterpelliPerRegione(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			//ordinamento
			criteria.addOrder(Order.asc("id.idInterpello"));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			if(results == null || results.isEmpty())
				return null;
			
			return results;
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - ricerca interpelli per la regione " + codiceRegione + " fallita", e);
			throw new GestioneErroriException("InterpelloHome - ricerca interpelli per la regione " + codiceRegione + " fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//restituisce true nel caso in cui:
	//- risulti un interpello pubblicato (come ultimo inserito) per la regione specificata
	//- la data di riferimento ricada nel range [data inizio, data fine] definito per l'interpello
	@SuppressWarnings("unchecked")
	public boolean controllaValiditaInterpello(String codiceRegione, Timestamp dataRiferimento) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			DetachedCriteria innerCriteria = DetachedCriteria.forClass(Interpello.class, "interpello");
			//condizioni
			innerCriteria.add(Restrictions.eq("interpello.id.codReg", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.max("interpello.id.idInterpello"));
			innerCriteria = innerCriteria.setProjection(projectionList);
			
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			criteria.add(Subqueries.propertyEq("id.idInterpello", innerCriteria));
			
			//stato "pubblicato"
			criteria.add(Restrictions.eq("stato", codiceInterpelloPubblicato));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			//false: non risultano interpelli pubblicati
			if(results == null || results.isEmpty())
				return false;
			
			Interpello interpello = results.get(0);
			
			return (interpello != null && interpello.getDataInizio() != null && interpello.getDataFine() != null &&
					dataRiferimento != null &&
					dataRiferimento.compareTo((java.sql.Timestamp) interpello.getDataInizio()) >= 0 &&
					dataRiferimento.compareTo((java.sql.Timestamp) interpello.getDataFine()) <= 0);
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - controllo validit� interpello per la regione " + codiceRegione + " fallito", e);
			throw new GestioneErroriException("InterpelloHome - controllo validit� interpello per la regione " + codiceRegione + " fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//restituisce true nel caso in cui:
	//- risulti un interpello pubblicato (come ultimo inserito) per la regione specificata
	//- la data di riferimento ricada nel range [data inizio, data fine] definito per la fase di accettazione/rifiuto sede dell'interpello
	@SuppressWarnings("unchecked")
	public boolean controllaValiditaFaseAccettazioneRinunciaInterpello(String codiceRegione, Timestamp dataRiferimento) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			DetachedCriteria innerCriteria = DetachedCriteria.forClass(Interpello.class, "interpello");
			//condizioni
			innerCriteria.add(Restrictions.eq("interpello.id.codReg", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.max("interpello.id.idInterpello"));
			innerCriteria = innerCriteria.setProjection(projectionList);
			
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			criteria.add(Subqueries.propertyEq("id.idInterpello", innerCriteria));
			
			//stato "pubblicato"
			criteria.add(Restrictions.eq("stato", codiceInterpelloPubblicato));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			//false: non risultano interpelli pubblicati
			if(results == null || results.isEmpty())
				return false;
			
			Interpello interpello = results.get(0);
			
			return (interpello != null && interpello.getDataInizioAccettazione() != null && interpello.getDataFineAccettazione() != null &&
					dataRiferimento != null &&
					dataRiferimento.compareTo((java.sql.Timestamp) interpello.getDataInizioAccettazione()) >= 0 &&
					dataRiferimento.compareTo((java.sql.Timestamp) interpello.getDataFineAccettazione()) <= 0);
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - controllo validit� fase accettazione/rinuncia sede interpello per la regione " + codiceRegione + " fallito", e);
			throw new GestioneErroriException("InterpelloHome - controllo fase accettazione/rinuncia sede interpello per la regione " + codiceRegione + " fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//restituisce true se l'interpello corrente (ultimo inserito) per la regione specificata risulta predisposto o pubblicato
	@SuppressWarnings("unchecked")
	public boolean controllaPresenzaInterpelloInCorso(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			DetachedCriteria innerCriteria = DetachedCriteria.forClass(Interpello.class, "interpello");
			//condizioni
			innerCriteria.add(Restrictions.eq("interpello.id.codReg", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.max("interpello.id.idInterpello"));
			innerCriteria = innerCriteria.setProjection(projectionList);
			
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			criteria.add(Subqueries.propertyEq("id.idInterpello", innerCriteria));
			
			//stato "predisposto" oppure "pubblicato"
			Criterion c1 = Restrictions.eq("stato", codiceInterpelloPredisposto);
			Criterion c2 = Restrictions.eq("stato", codiceInterpelloPubblicato);
			criteria.add(Restrictions.or(c1, c2));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			return (results != null && results.size() > 0);
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito", e);
			throw new GestioneErroriException("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	    //restituisce true se per la regione in oggetto � stata aperta almeno una volta la fade di interpello.
		@SuppressWarnings("unchecked")
		public boolean controllaAvviataFaseInterpello(String codiceRegione) throws GestioneErroriException {
			
			Session session = null;
			
			try {
				
				session = HibernateUtil.openSession();
			
				Criteria criteria = session.createCriteria(Interpello.class);
				//condizioni
				criteria.add(Restrictions.eq("id.codReg", codiceRegione));
				criteria.add (Restrictions.le("dataInizio", new GregorianCalendar().getTime()));
				criteria.add(Restrictions.eq("stato", codiceInterpelloPubblicato));
				
				List<Interpello> results = (List<Interpello>) criteria.list();
				
				return (results != null && results.size() > 0);
			}
			catch(Exception e) {
				
				log.error("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito", e);
				throw new GestioneErroriException("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito");
			}
			finally {
				
				if(session != null)
					session.close();
			}
		}
	
	/*//restituisce true se per la regione specificata risulta un qualsiasi interpello in corso (predisposto o pubblicato)
	@SuppressWarnings("unchecked")
	public boolean controllaPresenzaInterpelliInCorso(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			
			//stato "predisposto" oppure "pubblicato"
			Criterion c1 = Restrictions.eq("stato", codiceInterpelloPredisposto);
			Criterion c2 = Restrictions.eq("stato", codiceInterpelloPubblicato);
			criteria.add(Restrictions.or(c1, c2));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			return (results != null && results.size() > 0); 
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito", e);
			throw new GestioneErroriException("InterpelloHome - controllo presenza interpelli in corso per la regione " + codiceRegione + " fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}*/
	
	//restituisce true se l'interpello corrente (ultimo inserito) per la regione specificata risulta pubblicato
	@SuppressWarnings("unchecked")
	public boolean controllaPresenzaInterpelloPubblicato(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			DetachedCriteria innerCriteria = DetachedCriteria.forClass(Interpello.class, "interpello");
			//condizioni
			innerCriteria.add(Restrictions.eq("interpello.id.codReg", codiceRegione));
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.max("interpello.id.idInterpello"));
			innerCriteria = innerCriteria.setProjection(projectionList);
			
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			criteria.add(Subqueries.propertyEq("id.idInterpello", innerCriteria));
			
			//stato "pubblicato"
			criteria.add(Restrictions.eq("stato", codiceInterpelloPubblicato));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			return (results != null && results.size() > 0);
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - controllo presenza interpelli pubblicati per la regione " + codiceRegione + " fallito", e);
			throw new GestioneErroriException("InterpelloHome - controllo presenza interpelli pubblicati per la regione " + codiceRegione + " fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//restituisce true se l'interpello (Primo) ha rinunce
	@SuppressWarnings("unchecked")
	public boolean controllaPresenzaInterpelloConRinunce(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		String query;
		SQLQuery sqlQuery;
		
		try {
			
			session = HibernateUtil.openSession();
			query = "SELECT COUNT (G.ID_CANDIDATURA) " +
					"FROM INTERPELLO I, GRADUATORIA G " +
					"WHERE I.COD_REG = G.COD_REGIONALE " +
					"AND I.COD_REG = '" + codiceRegione + "' " +
					"AND I.ID_INTERPELLO = 1 " +
					"AND G.INDICE_TOTALE <= I.NUMERO_SEDI " +
					"AND G.ESCLUSO = 'true'";
					
			sqlQuery = session.createSQLQuery(query);
			//sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			BigDecimal conta = (BigDecimal)sqlQuery.uniqueResult();
			return (conta.compareTo(new BigDecimal(0)) > 0);
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - controllo presenza rinunce per primo interpello per la regione " + codiceRegione + " fallito", e);
			throw new GestioneErroriException("InterpelloHome - controllo presenza rinunce per primo interpello per la regione " + codiceRegione + " fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	/*//restituisce true se per la regione specificata risulta un qualsiasi interpello pubblicato
	@SuppressWarnings("unchecked")
	public boolean controllaPresenzaInterpelliPubblicati(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			Criteria criteria = session.createCriteria(Interpello.class);
			//condizioni
			criteria.add(Restrictions.eq("id.codReg", codiceRegione));
			
			//stato "pubblicato"
			criteria.add(Restrictions.eq("stato", codiceInterpelloPubblicato));
			
			List<Interpello> results = (List<Interpello>) criteria.list();
			
			log.debug("controllaPresenzaInterpelliPubblicati() successful");
			
			return (results != null && results.size() > 0); 
		}
		catch(Exception e) {
			
			log.error("InterpelloHome - controllo presenza interpelli pubblicati per la regione " + codiceRegione + " fallito", e);
			throw new GestioneErroriException("InterpelloHome - controllo presenza interpelli pubblicati per la regione " + codiceRegione + " fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}*/
	
}
