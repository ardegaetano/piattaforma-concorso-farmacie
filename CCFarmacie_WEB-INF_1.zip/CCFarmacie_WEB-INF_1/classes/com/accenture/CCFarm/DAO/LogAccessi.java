package com.accenture.CCFarm.DAO;

import java.io.Serializable;

@SuppressWarnings("serial")
public class LogAccessi implements java.io.Serializable {

	private String idLog;
	private String idUtente;
	private Serializable logAccesso;
	
	public LogAccessi() {}
	
	public LogAccessi(String idLog, String idUtente, Serializable logAccesso) {
		super();
		this.idLog = idLog;
		this.idUtente = idUtente;
		this.logAccesso = logAccesso;
	}

	public String getIdLog() {
		return idLog;
	}

	public void setIdLog(String idLog) {
		this.idLog = idLog;
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public Serializable getLogAccesso() {
		return logAccesso;
	}

	public void setLogAccesso(Serializable logAccesso) {
		this.logAccesso = logAccesso;
	}
	
}