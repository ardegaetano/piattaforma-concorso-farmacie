package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CCFarmLogger;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.PrintException;

/**
 * Home object for domain model class AltraLaurea.
 * @see com.accenture.CCFarm.DAO.AltraLaurea
 * @author Hibernate Tools
 */
public class AltraLaureaBisHome {

//	private static final Log log = LogFactory.getLog(AltraLaureaBisHome.class);
	private static final Logger log = CommonLogger.getLogger("AltraLaureaBisHome");

	public void persist(AltraLaurea transientInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting AltraLaureaBis instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("AltraLaureaBisHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(AltraLaureaBis instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty AltraLaureaBis instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("AltraLaureaBisHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(AltraLaureaBis instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean AltraLaureaBis instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("AltraLaureaBisHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(AltraLaureaBis persistentInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting AltraLaureaBis instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("AltraLaureaBisHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public AltraLaureaBis merge(AltraLaureaBis detachedInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging AltraLaureaBis instance");
		try {
			AltraLaureaBis result = (AltraLaureaBis) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("AltraLaureaBisHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public AltraLaureaBis findById(java.lang.String id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting AltraLaureaBis instance with id: " + id);
		try {
			AltraLaureaBis instance = (AltraLaureaBis) session.get("com.accenture.CCFarm.DAO.AltraLaureaBis", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("AltraLaureaBisHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}
	
	public AltraLaureaBis findByIdHql(String id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting Nazioni instance with id: " + id);
		Transaction trx = session.beginTransaction();
		AltraLaureaBis result = new AltraLaureaBis();
		try {
			Query query = session.createQuery("from AltraLaureaBis where idDomandaLaureaBis = :idDomandaLaureaBis ");
			query.setParameter("idDomandaLaureaBis", id);
			result = (AltraLaureaBis)query.list().get(0);		
		} catch (Exception e) {
			CCFarmLogger.log(
					"Errore Lettura AltraLaureaBis.. da ID_DOCUMENTO  [" + id + "]", Level.INFO_INT,
					CandidaturaHome.class);	
		}		
		finally{
			session.close();
			return result;		
		}
	}	

	public List findByExample(AltraLaureaBis instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding AltraLaureaBis instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.AltraLaureaBis")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("AltraLaureaBisHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	public String getSequenceIdAltraLaureaBis() throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_ALTRE_LAUREE_BIS.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("getSequenceIdUtente() - "+ PrintException.stack2string(re));
			throw new GestioneErroriException("AltraLaureaBisHome - getSequenceIdAltraLaureaBis: errore getSequenceIdAltraLaureaBis");
		}
		finally{
			session.close();
		}
	}
	
}
