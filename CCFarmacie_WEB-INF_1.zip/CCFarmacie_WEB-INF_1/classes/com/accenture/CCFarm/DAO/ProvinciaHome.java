package com.accenture.CCFarm.DAO;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
* Home object for domain model class Provincia.
* @see com.accenture.CCFarm.DAO.Provincia
* @author Hibernate Tools
*/
public class ProvinciaHome {

//	private static final Log log = LogFactory.getLog(ProvinciaHome.class);
	private static final Logger log = CommonLogger.getLogger("ProvinciaHome");

	public void persist(Provincia transientInstance)  throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting Provincia instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("ProvinciaHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(Provincia instance)  throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Provincia instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("ProvinciaHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(Provincia instance)  throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Provincia instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("ProvinciaHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(Provincia persistentInstance)  throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting Provincia instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("ProvinciaHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public Provincia merge(Provincia detachedInstance)  throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging Provincia instance");
		try {
			Provincia result = (Provincia) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("ProvinciaHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public Provincia findById(java.lang.String id)  throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting Province instance with id: " + id);
		try {
			Provincia instance = (Provincia) session.get("com.accenture.CCFarm.DAO.Provincia", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("ProvinciaHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(Provincia instance)  throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Province instance by example");
		try {
				List results = session
					.createCriteria("com.accenture.CCFarm.DAO.Provincia")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("ProvinciaHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
}
