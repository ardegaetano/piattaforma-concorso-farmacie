package com.accenture.CCFarm.DAO;

import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CriptDecriptUtil;
import com.accenture.CCFarm.utility.CCFarmLogger;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.LogUtil;

/**
* Home object for domain model class LogIn.
* @see com.accenture.CCFarm.DAO.LogIn
* @author Hibernate Tools
*/
public class LogInHome {

//	private static final Log log = LogFactory.getLog(LogInHome.class);
	private static final Logger log = CommonLogger.getLogger("LogInHome");
	
	public void persist(LogIn transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting LogIn instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			LogUtil.printException(re);
			throw new GestioneErroriException("LogInHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(LogIn instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty LogIn instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			LogUtil.printException(re);
			throw new GestioneErroriException("LogInHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(LogIn instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean LogIn instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			LogUtil.printException(re);
			throw new GestioneErroriException("LogInHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(LogIn persistentInstance) throws GestioneErroriException  {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting LogIn instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			LogUtil.printException(re);
			throw new GestioneErroriException("LogInHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public LogIn merge(LogIn detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging LogIn instance");
		try {
			LogIn result = (LogIn) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("LogInHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public LogIn findById(String id)throws GestioneErroriException  {
		Session session = HibernateUtil.openSession();
		log.debug("getting Nazioni instance with id: " + id);
		try {
			LogIn instance = (LogIn) session.get("com.accenture.CCFarm.DAO.LogIn", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			GestioneErroriException eccezione = new GestioneErroriException(
					"LogInHome - findById: errore nella findById di LogIn");
			throw eccezione;
		}
		finally{
			session.close();
		}
	}
	
	public LogIn findByIdHql(String id) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("getting Nazioni instance with id: " + id);
		Transaction trx = session.beginTransaction();
		LogIn result = new LogIn();
		try {
			Query query = session.createQuery("from LogIn where idUtente = :idUtente ");
			query.setParameter("idUtente", id);
			result = (LogIn)query.list().get(0);		
		} catch (Exception e) {
			CCFarmLogger.log(
					"Errore Lettura LogIn.. da ID_UTENTE  [" + id + "]", Level.INFO_INT,
					CandidaturaHome.class);			
			
		}		
		finally{
			session.close();
			return result;		
		}
	}	

	public List findByExample(LogIn instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding login instance by example");
		try {
				List results = session
					.createCriteria("com.accenture.CCFarm.DAO.LogIn")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("LogInHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
}
