package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.transform.Transformers;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PDFModulo.SceltaSediEntityPdf;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.StaticDefinitions;
import com.accenture.mailer.concorsofarma.GestoreMail;
import com.accenture.mailer.concorsofarma.data.MailBean;

public class ScegliSediHome {
	
	private static final Logger logger = CommonLogger.getLogger("ScegliSediHome");
	
	private static int limiteDimensioneProtocollo = 6;
	private static char paddingCharProtocollo = '0';
	
	private CandidaturaSediHome candidaturaSediHome;
	private CandidaturaRegHome candidaturaRegHome;
	
	public ScegliSediHome() {
		
		candidaturaSediHome = new CandidaturaSediHome();
		candidaturaRegHome = new CandidaturaRegHome();
	}
	
	//carica i dati di tutte le sedi che risultano essere state gi� selezionate dall'utente per l'interpello corrente
	//(ordinamento per ordine di scelta ascendente)
	@SuppressWarnings("unchecked")
	public List<AnagraficaFarm> caricaSediSelezionate(String idCandidatura) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			String sqlQuery = "SELECT f.id_farm as idFarm, "
								   + "f.descr_prv_farm as descrPrvFarm, "
								   + "f.frazione_farm as frazioneFarm, "
								   + "f.n_progressivo as NProgressivo, "
								   + "f.descrizione_sede as descrizioneSede"
							 + " FROM anagrafica_farm f, candidatura_sedi cs"
							+ " WHERE f.id_farm = cs.id_farm"
							  + " AND cs.id_candidatura = :idCandidatura"
						 + " ORDER BY cs.ORDINE_SCELTA ASC";
			
			SQLQuery query = session.createSQLQuery(sqlQuery);
			query.setParameter("idCandidatura", idCandidatura);
			query.addScalar("idFarm",Hibernate.STRING);
			query.addScalar("descrPrvFarm",Hibernate.STRING);
			query.addScalar("frazioneFarm",Hibernate.STRING);
			query.addScalar("NProgressivo",Hibernate.STRING);
			query.addScalar("descrizioneSede",Hibernate.STRING);
			query.setResultTransformer(Transformers.aliasToBean(AnagraficaFarm.class));
			
			return (List<AnagraficaFarm>) query.list();
		}
		catch(Exception e) {
			
			logger.error("ScegliSediHome - caricamento sedi selezionate fallito", e);
			throw new GestioneErroriException("ScegliSediHome - caricamento sedi selezionate fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//salvataggio elenco preferenze sedi, e impostazione flag "flag scelta sedi" a valore positivo
	public void invia(String idCandidatura, List<CandidaturaSedi> candidaturaSediList, String idUtente) throws GestioneErroriException {
		
		Session session = null;
		Transaction trx = null;
		
		try {
			
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			
			candidaturaSediHome.salvaPreferenze(session, idCandidatura, candidaturaSediList);
			
			candidaturaRegHome.confermaSceltaSedi(session, idUtente);
			
			trx.commit();
		}
		catch(Exception e) {
			
			if(trx != null)
				trx.rollback();
			
			logger.error("ScegliSediHome - conferma selezione sedi fallita", e);
			throw new GestioneErroriException("ScegliSediHome - conferma selezione sedi fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}	
	}
	
	//restituisce il prossimo valore utile per la sequence "ricevuta scelta sedi" propria della regione di candidatura
	public String getIdRicevuta(String codiceRegione) throws GestioneErroriException {
		
		Session session = null;
		try {
			
			session = HibernateUtil.openSession();
			
			String sqlString = "SELECT ID_RICEVUTA_" + codiceRegione + ".NEXTVAL FROM DUAL";
			Query query = session.createSQLQuery(sqlString);
			BigDecimal idRicevuta = (BigDecimal) query.uniqueResult();
			
			return StringUtils.leftPad(idRicevuta.toString(), limiteDimensioneProtocollo, paddingCharProtocollo);
		}
		catch(Exception e) {
			
			logger.error("ScegliSediHome - GetIdRicevuta() fallito", e);
			throw new GestioneErroriException("ScegliSediHome - GetIdRicevuta() fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	public SceltaSediEntityPdf getDatiPerRicevuta(String idUtente) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			String sqlQuery= "SELECT to_char((SELECT max(id_interpello) FROM interpello WHERE cod_reg = U.cod_reg_utente)) as numeroInterpello, "
								  
								  + "to_char((SELECT I1.DATA_INIZIO FROM interpello I1 WHERE I1.ID_INTERPELLO = (SELECT max(I.id_interpello) FROM interpello I WHERE I.cod_reg = U.cod_reg_utente) AND I1.COD_REG = U.cod_reg_utente), 'dd/MM/yyyy') as dataInizioInterpello, "
					
								  + "U.COD_REG_UTENTE as codiceRegione, "
					
								  + "(SELECT R.denominazione_reg"
								  + " FROM regioni R"
								  + " WHERE R.COD_REG = U.COD_REG_UTENTE) as descRegione, "
								  
								  + "U.COGNOME_UTENTE as cognome, "
							 	  + "U.NOME_UTENTE as nome, "
							 	  + "U.CODICE_FISCALE_UTENTE as codiceFiscale, "
							 	  + "to_char(U.DATA_NASCITA_UTENTE, 'dd/MM/yyyy') as dataNascita, "
							 	  
							 	  + "(SELECT C.denominazione"
								    + " FROM comuni C"
								   + " WHERE C.CODICE_COMUNE = U.LUOGO_NASCITA_UTENTE) as comuneNascita, "
								  
								  + "(SELECT P.denominazione_provincia"
									+ " FROM province P"
								   + " WHERE P.CODICE_PROVINCIA = U.PRV_NASCITA_UTENTE) as provinciaNascita, "
								  
								  + "U.LUOGO_NASCITA_ESTERA as luogoNascitaEstero, "
								  
								  + "U.NAZIONE_NASCITA_UTENTE as codiceStatoNascita, "
								  
								  + "(SELECT dsc_naz_estesa"
								    + " FROM nazioni N"
								   + " WHERE N.COD_ISO_NAZIONE = U.NAZIONE_NASCITA_UTENTE) as statoNascita, "
								  
								  + "("
								  	+ "(SELECT V.DESCRIZIONE"
								  	  + " FROM valori_codice V"
								  	 + " WHERE V.CODICE = U.TIPO_DOCUMENTO AND V.TIPO_CODICE = 'TIPO_DOC_RICONOSCIMENTO')"
								  	+ "||','||U.NUMERO_DOC||','||U.ENTE_RILASCIO_DOC||','||to_char(U.DATA_RILASCIO_DOC, 'dd/MM/yyyy')"
								  + ") as estremiDocIdentita, "
								  
								  + "G.NUMERO_PROTOCOLLO as numeroProtocolloDomanda, "
								  + "decode(CR.MODALITA_CANDIDATURA, 'S', 'SINGOLA', 'A', 'ASSOCIATA') as modalitaPartecipazione, "
                                  + "to_char(G.INDICE_TOTALE) as posizioneGraduatoria"
                                 
                          + " FROM utente_reg U, candidatura_reg CR, graduatoria G"
                         + " WHERE U.ID_UTENTE = CR.id_utente"
	                       + " AND cr.id_candidatura = G.ID_CANDIDATURA"
	                       + " AND U.ID_UTENTE = :idUtente";
			
			SQLQuery query = session.createSQLQuery(sqlQuery);
			query.addScalar("numeroInterpello", Hibernate.STRING);
			query.addScalar("dataInizioInterpello", Hibernate.STRING);
			query.addScalar("codiceRegione", Hibernate.STRING);
			query.addScalar("descRegione", Hibernate.STRING);
			query.addScalar("cognome", Hibernate.STRING);
			query.addScalar("nome", Hibernate.STRING);
			query.addScalar("codiceFiscale", Hibernate.STRING);
			query.addScalar("dataNascita", Hibernate.STRING);
			query.addScalar("comuneNascita", Hibernate.STRING);
			query.addScalar("provinciaNascita", Hibernate.STRING);
			query.addScalar("luogoNascitaEstero", Hibernate.STRING);
			query.addScalar("codiceStatoNascita", Hibernate.STRING);
			query.addScalar("statoNascita", Hibernate.STRING);
			query.addScalar("estremiDocIdentita", Hibernate.STRING);
			query.addScalar("numeroProtocolloDomanda", Hibernate.STRING);
			query.addScalar("modalitaPartecipazione", Hibernate.STRING);
			query.addScalar("posizioneGraduatoria", Hibernate.STRING);
			query.setParameter("idUtente", idUtente);
			query.setResultTransformer(Transformers.aliasToBean(SceltaSediEntityPdf.class));
			
			return (SceltaSediEntityPdf) query.uniqueResult();
		}
		catch(Exception e) {
			
			logger.error("ScegliSediHome - recupero dei dati per la ricevuta PDF fallito", e);
			throw new GestioneErroriException("ScegliSediHome - recupero dei dati per la ricevuta PDF fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	@SuppressWarnings("deprecation")
	public void sendMail(MailBean mailBean) throws GestioneErroriException {
		
		Session session = null;
		try {
			
			session = HibernateUtil.openSession();
			Transaction trx = session.beginTransaction();
			
			GestoreMail gestoreMail = new GestoreMail();
			Object[] indiciMail = new Object[1];
			
			indiciMail[0] = gestoreMail.saveMail(mailBean, StaticDefinitions.MAIL_PROPERTIES, session.connection());
			trx.commit();
			
			//Provo ad inviare la mail 
            try {
         	   gestoreMail.sendMail((Integer)indiciMail[0], StaticDefinitions.MAIL_PROPERTIES, session.connection());
            } catch (Throwable thr) {
            	logger.error("ScegliSediHome -  : errore nell' invio della mail " + thr.getMessage(), thr);
            }
		}
		catch(Exception e) {
			logger.error("ScegliSediHome - invio ricevuta di avvenuta scelta sedi fallito", e);
			throw new GestioneErroriException("ScegliSediHome - invio ricevuta di avvenuta scelta sedi fallito");
		}
		finally {
			if(session != null)
				session.close();
		}
	}
}
