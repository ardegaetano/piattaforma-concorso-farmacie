package com.accenture.CCFarm.DAO;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
* Home object for domain model class Comune.
* @see com.accenture.CCFarm.DAO.Comune
* @author Hibernate Tools
*/
public class ComuneHome {

//	private static final Log log = LogFactory.getLog(ComuneHome.class);
	private static final Logger log = CommonLogger.getLogger("ComuneHome");
	
	public void persist(Comune transientInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting Comune instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("ComuneHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(Comune instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Comune instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("ComuneHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(Comune instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Comune instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("ComuneHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(Comune persistentInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting Comune instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("ComuneHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public Comune merge(Comune detachedInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging Comune instance");
		try {
			Comune result = (Comune) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("ComuneHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public Comune findById(java.lang.String id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting Comuni instance with id: " + id);
		try {
			Comune instance = (Comune) session.get("com.accenture.CCFarm.DAO.Comune", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("ComuneHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(Comune instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Comuni instance by example");
		try {
				List results = session
					.createCriteria("com.accenture.CCFarm.DAO.Comune")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("ComuneHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
}
