package com.accenture.CCFarm.DAO;

import java.io.Serializable;
import java.sql.Clob;
import java.util.Date;

public class AnagraficaFarmInterpelli implements java.io.Serializable {

	private AnagraficaFarmInterpelliId id;
	private String progressivoFarm;
	private String comuneFarm;
	private String prvFarm;
	private String descrizioneFarm;
	private String NDelibera;
	private String NProgressivo;
	private Clob descrizioneSede;
	private Clob descrizioneSedeDe;
	private String codTipoSede;
	private String frazioneFarm;
	private Date dataDelibera;
	private String idBandoFarm;
	private String createdByFarm;
	private Serializable creationDateFarm;
	private String lastUpdatedByFarm;
	private Serializable lastUpdateDateFarm;
	private String descrPrvFarm;
	private String criterioTopoFarm;
	private String indennitaAvviamento;

	public AnagraficaFarmInterpelli() {
	}
	
	public AnagraficaFarmInterpelli(AnagraficaFarmInterpelliId id) {
		this.id = id;
	}
	
	public AnagraficaFarmInterpelli(AnagraficaFarmInterpelliId id,
			String progressivoFarm, String comuneFarm, String prvFarm,
			String descrizioneFarm, String nDelibera, String nProgressivo,
			Clob descrizioneSede, Clob descrizioneSedeDe, String codTipoSede,
			String frazioneFarm, Date dataDelibera, String idBandoFarm,
			String createdByFarm, Serializable creationDateFarm,
			String lastUpdatedByFarm, Serializable lastUpdateDateFarm,
			String descrPrvFarm, String criterioTopoFarm,
			String indennitaAvviamento) {
		this.id = id;
		this.progressivoFarm = progressivoFarm;
		this.comuneFarm = comuneFarm;
		this.prvFarm = prvFarm;
		this.descrizioneFarm = descrizioneFarm;
		NDelibera = nDelibera;
		NProgressivo = nProgressivo;
		this.descrizioneSede = descrizioneSede;
		this.descrizioneSedeDe = descrizioneSedeDe;
		this.codTipoSede = codTipoSede;
		this.frazioneFarm = frazioneFarm;
		this.dataDelibera = dataDelibera;
		this.idBandoFarm = idBandoFarm;
		this.createdByFarm = createdByFarm;
		this.creationDateFarm = creationDateFarm;
		this.lastUpdatedByFarm = lastUpdatedByFarm;
		this.lastUpdateDateFarm = lastUpdateDateFarm;
		this.descrPrvFarm = descrPrvFarm;
		this.criterioTopoFarm = criterioTopoFarm;
		this.indennitaAvviamento = indennitaAvviamento;
	}

	public AnagraficaFarmInterpelliId getId() {
		return id;
	}

	public void setId(AnagraficaFarmInterpelliId id) {
		this.id = id;
	}

	public String getProgressivoFarm() {
		return progressivoFarm;
	}

	public void setProgressivoFarm(String progressivoFarm) {
		this.progressivoFarm = progressivoFarm;
	}

	public String getComuneFarm() {
		return comuneFarm;
	}

	public void setComuneFarm(String comuneFarm) {
		this.comuneFarm = comuneFarm;
	}

	public String getPrvFarm() {
		return prvFarm;
	}

	public void setPrvFarm(String prvFarm) {
		this.prvFarm = prvFarm;
	}

	public String getDescrizioneFarm() {
		return descrizioneFarm;
	}

	public void setDescrizioneFarm(String descrizioneFarm) {
		this.descrizioneFarm = descrizioneFarm;
	}

	public String getNDelibera() {
		return NDelibera;
	}

	public void setNDelibera(String nDelibera) {
		NDelibera = nDelibera;
	}

	public String getNProgressivo() {
		return NProgressivo;
	}

	public void setNProgressivo(String nProgressivo) {
		NProgressivo = nProgressivo;
	}

	public Clob getDescrizioneSede() {
		return descrizioneSede;
	}

	public void setDescrizioneSede(Clob descrizioneSede) {
		this.descrizioneSede = descrizioneSede;
	}

	public Clob getDescrizioneSedeDe() {
		return descrizioneSedeDe;
	}

	public void setDescrizioneSedeDe(Clob descrizioneSedeDe) {
		this.descrizioneSedeDe = descrizioneSedeDe;
	}

	public String getCodTipoSede() {
		return codTipoSede;
	}

	public void setCodTipoSede(String codTipoSede) {
		this.codTipoSede = codTipoSede;
	}

	public String getFrazioneFarm() {
		return frazioneFarm;
	}

	public void setFrazioneFarm(String frazioneFarm) {
		this.frazioneFarm = frazioneFarm;
	}

	public Date getDataDelibera() {
		return dataDelibera;
	}

	public void setDataDelibera(Date dataDelibera) {
		this.dataDelibera = dataDelibera;
	}

	public String getIdBandoFarm() {
		return idBandoFarm;
	}

	public void setIdBandoFarm(String idBandoFarm) {
		this.idBandoFarm = idBandoFarm;
	}

	public String getCreatedByFarm() {
		return createdByFarm;
	}

	public void setCreatedByFarm(String createdByFarm) {
		this.createdByFarm = createdByFarm;
	}

	public Serializable getCreationDateFarm() {
		return creationDateFarm;
	}

	public void setCreationDateFarm(Serializable creationDateFarm) {
		this.creationDateFarm = creationDateFarm;
	}

	public String getLastUpdatedByFarm() {
		return lastUpdatedByFarm;
	}

	public void setLastUpdatedByFarm(String lastUpdatedByFarm) {
		this.lastUpdatedByFarm = lastUpdatedByFarm;
	}

	public Serializable getLastUpdateDateFarm() {
		return lastUpdateDateFarm;
	}

	public void setLastUpdateDateFarm(Serializable lastUpdateDateFarm) {
		this.lastUpdateDateFarm = lastUpdateDateFarm;
	}

	public String getDescrPrvFarm() {
		return descrPrvFarm;
	}

	public void setDescrPrvFarm(String descrPrvFarm) {
		this.descrPrvFarm = descrPrvFarm;
	}

	public String getCriterioTopoFarm() {
		return criterioTopoFarm;
	}

	public void setCriterioTopoFarm(String criterioTopoFarm) {
		this.criterioTopoFarm = criterioTopoFarm;
	}

	public String getIndennitaAvviamento() {
		return indennitaAvviamento;
	}

	public void setIndennitaAvviamento(String indennitaAvviamento) {
		this.indennitaAvviamento = indennitaAvviamento;
	}

}
