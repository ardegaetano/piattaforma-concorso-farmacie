package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.primefaces.model.UploadedFile;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class DatiBando.
 * @see com.accenture.CCFarm.DAO.DatiBando
 * @author Hibernate Tools
 */
public class RicercaFarmacieHome {

//	private static final Log log = LogFactory.getLog(RicercaFarmacieHome.class);
	private static final Logger log = CommonLogger.getLogger("RicercaFarmacieHome");

	public void persist(DatiBando transientInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("persisting DatiBando instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("RicercaFarmacieHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(DatiBando instance, UploadedFile fileBando, UploadedFile fileLogo, UploadedFile fileSedi) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Logger logger =Logger.getLogger("DatiBandoHome");
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty DatiBando instance");
		try {
			if(fileBando!=null)
//h4				instance.setFileBando(session.getLobHelper().createBlob(fileBando.getContents()));
/*h3*/				instance.setFileBando((fileBando.getContents()));
			if(fileSedi!=null) {
				InputStream is = null;
				try {	
					is = fileSedi.getInputstream();
					InputStreamReader isReader = new InputStreamReader(is);
/*h3*/					int len = new Long(fileSedi.getSize()).intValue();
//h4					instance.setFileSedi(session.getLobHelper().createClob(isReader, fileSedi.getSize()));
/*h3*/					instance.setFileSedi(Hibernate.createClob((Reader)isReader, len));
				} catch (IOException ex) {
					log.error("attach failed", ex);
				}
			}
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("RicercaFarmacieHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			if(session.isOpen()){
				logger.info("sessione aperta vado a chiuderla");
				session.close();
			} else{
				logger.info("la sessione non risulta aperta quindo non faccio la chiusura");
			}
		}
	}

	public void attachClean(DatiBando instance) throws GestioneErroriException  {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean DatiBando instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("RicercaFarmacieHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(DatiBando persistentInstance) throws GestioneErroriException  {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting DatiBando instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("RicercaFarmacieHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public DatiBando merge(DatiBando detachedInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("merging DatiBando instance");
		try {
			DatiBando result = (DatiBando) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("RicercaFarmacieHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public DatiBando findById(java.lang.String id) throws GestioneErroriException {
		
		Session session = HibernateUtil.openSession();
		
		log.debug("getting DatiBando instance with id: " + id);
		DatiBando instance = null;
		Logger logger =Logger.getLogger("HibernateUtil");
		
		try {
			instance = (DatiBando) session.get("com.accenture.CCFarm.DAO.DatiBando", id);
			logger.info("qry fatta senza eccezioni");
			if (instance == null) {
				log.debug("get successful, no instance found");
				logger.info("qry non trovato elemento");
			} else {
				log.debug("get successful, instance found");
				logger.info("qry trovato elemento");
			}
			
		} catch (RuntimeException re) {
			log.error("get failed", re);
			StringWriter strWriter = new StringWriter() ;
			PrintWriter printWriter = new PrintWriter(strWriter);
			re.printStackTrace(printWriter);
			String eccezione = strWriter.toString();
			logger.info(" dati bando home :eccezione : " + eccezione);
			 
			throw new GestioneErroriException("RicercaFarmacieHome - findById: errore findById");
		}
		finally{
			logger.info("sto chiudendo la sessione");
			try{
				if(session != null){
					logger.info("sessione open: " + session.isOpen());
					logger.info("sessione isConnected 1 : " + session.isConnected());
//					session.clear();
					logger.info("sessione isConnected 2 : svuotata");
//					session.disconnect();
					logger.info("sessione isConnected 2 : " + session.isConnected());
					session.close();
					}
				logger.info("la sessione risulta chiusa");
			}catch (Exception re) {
				log.error("get failed", re);
				StringWriter strWriter = new StringWriter() ;
				PrintWriter printWriter = new PrintWriter(strWriter);
				re.printStackTrace(printWriter);
				String eccezione = strWriter.toString();
				logger.info("eccezione nella chiusura della connesione : " + eccezione);
				throw new GestioneErroriException("RicercaFarmacieHome - findById: errore findById");
			}	
		}
		logger.info("pronti per il return");
		
		return instance;
		
	}
	
	public List findByExample(DatiBando instance) throws GestioneErroriException  {
		Session session = HibernateUtil.openSession();
		log.debug("finding DatiBando instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.DatiBando")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("RicercaFarmacieHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
}
