package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

/**
 * Home object for domain model class DichiarazioneSostitutiva.
 * @see com.accenture.CCFarm.DAO.DichiarazioneSostitutiva
 * @author Hibernate Tools
 */
public class DichiarazioneSostitutivaHome {

//	private static final Log log = LogFactory
//			.getLog(DichiarazioneSostitutivaHome.class);
	private static final Logger log = CommonLogger.getLogger("DichiarazioneSostitutivaHome");

	public void persist(DichiarazioneSostitutiva transientInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting DichiarazioneSostitutiva instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("DichiarazioneSostitutivaHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(DichiarazioneSostitutiva instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty DichiarazioneSostitutiva instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("DichiarazioneSostitutivaHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(DichiarazioneSostitutiva instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean DichiarazioneSostitutiva instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("DichiarazioneSostitutivaHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(DichiarazioneSostitutiva persistentInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting DichiarazioneSostitutiva instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("DichiarazioneSostitutivaHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public DichiarazioneSostitutiva merge(
			DichiarazioneSostitutiva detachedInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging DichiarazioneSostitutiva instance");
		try {
			DichiarazioneSostitutiva result = (DichiarazioneSostitutiva) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("DichiarazioneSostitutivaHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public DichiarazioneSostitutiva findById(java.lang.String id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting DichiarazioneSostitutiva instance with id: " + id);
		try {
			DichiarazioneSostitutiva instance = (DichiarazioneSostitutiva) session.get(
							"com.accenture.CCFarm.DAO.DichiarazioneSostitutiva", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("DichiarazioneSostitutivaHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(DichiarazioneSostitutiva instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding DichiarazioneSostitutiva instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.DichiarazioneSostitutiva")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("DichiarazioneSostitutivaHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
}
