package com.accenture.CCFarm.DAO;

public class RicevuteId implements java.io.Serializable {
	
	private String idRicevuta;
	private String idCandidatura; 
	private String idRegione;
	private String tipoRicevuta;
	
	public String getIdRicevuta() {
		return idRicevuta;
	}
	public void setIdRicevuta(String idRicevuta) {
		this.idRicevuta = idRicevuta;
	}
	public String getIdCandidatura() {
		return idCandidatura;
	}
	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}
	public String getIdRegione() {
		return idRegione;
	}
	public void setIdRegione(String idRegione) {
		this.idRegione = idRegione;
	}
	public String getTipoRicevuta() {
		return tipoRicevuta;
	}
	public void setTipoRicevuta(String tipoRicevuta) {
		this.tipoRicevuta = tipoRicevuta;
	}
	
}
