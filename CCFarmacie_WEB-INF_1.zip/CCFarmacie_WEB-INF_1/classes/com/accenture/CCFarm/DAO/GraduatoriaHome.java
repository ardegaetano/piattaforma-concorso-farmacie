package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;


/**
* Home object for domain model class Graduatoria.
* @see com.accenture.CalcolaTitoli.DAO.Graduatoria
*/
public class GraduatoriaHome {

	private static final Logger log = CommonLogger.getLogger("GraduatoriaHome");
	
	public void persist(Graduatoria transientInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting Graduatoria instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("GraduatoriaHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(Graduatoria instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Graduatoria instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw new GestioneErroriException("GraduatoriaHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(Graduatoria instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Graduatoria instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("GraduatoriaHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(Graduatoria persistentInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting Graduatoria instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("GraduatoriaHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public Graduatoria merge(Graduatoria detachedInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging Graduatoria instance");
		try {
			Graduatoria result = (Graduatoria) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("GraduatoriaHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public Graduatoria findById(java.lang.String id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting Graduatoria instance with id: " + id);
		try {
			Graduatoria instance = (Graduatoria) session.get("com.accenture.CCFarm.DAO.Graduatoria", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(Graduatoria instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Graduatoria instance by example");
		try {
				List results = session
					.createCriteria("com.accenture.CCFarm.DAO.Graduatoria")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	public List<Graduatoria> findByCriteria(Graduatoria graduatoria) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Graduatoria instance by example");
		try {
			Criteria criteria = session.createCriteria(Graduatoria.class);
			if(!graduatoria.getNumeroProtocollo().equalsIgnoreCase("")){
				criteria.add(Restrictions.like("numeroProtocollo", graduatoria.getNumeroProtocollo().toUpperCase().trim()+"%"));
						
			}
			if(!graduatoria.getCognome().equalsIgnoreCase("")){
				criteria.add(Restrictions.eq("cognome", graduatoria.getCognome().toUpperCase().trim()));
			}
			
			if(!graduatoria.getExAequoRisolto().equalsIgnoreCase("")){
				criteria.add(Restrictions.eq("exAequoRisolto", graduatoria.getExAequoRisolto().toUpperCase().trim()));
			}
			//criteria.addOrder(Order.desc(""));
			return criteria.list();
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
		
	}
	
	
	public List<Graduatoria> findOrderByGraduatoria(String codReg)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<Graduatoria> graduatoriaList = new ArrayList<Graduatoria>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
	
		try{
		session = HibernateUtil.openSession();
		query = "select * from graduatoria where cod_regionale='"+codReg+"'" +
				" ORDER BY punteggio DESC,eta_media ASC,cognome ASC,nome ASC";
				
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		List result = sqlQuery.list();
		
		Graduatoria graduatoria= null;
		
		for(Object object : result){
			graduatoria = new Graduatoria();
			Map row = (Map)object;
			graduatoria.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
			graduatoria.setCognome((String) row.get("COGNOME"));
			graduatoria.setNome((String) row.get("NOME"));
			punteggio = (BigDecimal)row.get("PUNTEGGIO");
			graduatoria.setPunteggio(punteggio);
			eta = (BigDecimal) row.get("ETA_MEDIA");
			graduatoria.setEtaMedia(eta);
			graduatoria.setOsservazioni((String) row.get("OSSERVAZIONI"));
			graduatoria.setNote((Clob) row.get("NOTE"));
			graduatoria.setDataNascita((String) row.get("DATA_NASCITA"));
			graduatoria.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
			graduatoria.setCodRegione((String) row.get("COD_REGIONALE"));
			graduatoria.setExAequo((String) row.get("EXAEQUO"));
			graduatoria.setExAequoRisolto((String) row.get("EXAEQUO_RISOLTI"));
			graduatoria.setDataIstruttoria((Timestamp) row.get("DATA_ISTRUTTORIA"));
			graduatoria.setColor((String) row.get("EXAEQUO_COLOR"));
			graduatoriaList.add(graduatoria);
		}
		
		return graduatoriaList;
		
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findOrderByGraduatoria: errore findByFilter");
		}finally{
			session.close();
		}
	}

		
	public List<Graduatoria> findLazyListGraduatoria(String codReg,int startPage,int maxPerPage)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<Graduatoria> graduatoriaList = new ArrayList<Graduatoria>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
		
		
		
		//int x = startPage-10;
		//int y = maxPerPage+10;
		try{
		session = HibernateUtil.openSession();
		if(getRettificatiRow(codReg)){
			query = "select * from(select rownum as rn,ID_CANDIDATURA , COD_REGIONALE, numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita,exaequo,exaequo_risolti,exaequo_color,indice_totale from graduatoria where cod_regionale='"+codReg+"'" +
					" ORDER BY  punteggio DESC,eta_media ASC, cognome ASC,nome ASC)";
		}else{
			query = "select * from(select rownum as rn,ID_CANDIDATURA , COD_REGIONALE, numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita,exaequo,exaequo_risolti,exaequo_color,indice_totale from graduatoria where cod_regionale='"+codReg+"'" +
					" ORDER BY punteggio DESC,indice_totale ASC,eta_media ASC, cognome ASC,nome ASC)";
		}
		
		
				//" where  rn >= '"+startPage+"'"+
				//"and rownum <='"+maxPerPage+"'";
		   
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		sqlQuery.setFirstResult(startPage);
		sqlQuery.setMaxResults(maxPerPage);
		List result = sqlQuery.list();
		
		
		Graduatoria graduatoria= null;
		
		for(Object object : result){
			graduatoria = new Graduatoria();
			Map row = (Map)object;
			graduatoria.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
			graduatoria.setCodRegione((String) row.get("COD_REGIONALE"));
			graduatoria.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
			graduatoria.setCognome((String) row.get("COGNOME"));
			graduatoria.setNome((String) row.get("NOME"));
			punteggio = (BigDecimal)row.get("PUNTEGGIO");
			graduatoria.setPunteggio(punteggio);
			eta = (BigDecimal) row.get("ETA_MEDIA");
			graduatoria.setEtaMedia(eta);
			graduatoria.setDataNascita((String) row.get("DATA_NASCITA"));
			graduatoria.setExAequo((String) row.get("EXAEQUO"));
			graduatoria.setExAequoRisolto((String) row.get("EXAEQUO_RISOLTI"));
			graduatoria.setColor((String) row.get("EXAEQUO_COLOR"));
			graduatoria.setIndiceTotale((BigDecimal) row.get("INDICE_TOTALE"));
			graduatoriaList.add(graduatoria);
		}
		
		return graduatoriaList;
		
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findOrderByGraduatoria: errore findByFilter");
		}finally{
			session.close();
			
		}
	}
	
	public List<Graduatoria> findLazyListGradJoinGradDefin(String codReg,int startPage,int maxPerPage)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<Graduatoria> graduatoriaList = new ArrayList<Graduatoria>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
	
		//int x = startPage-10;
		//int y = maxPerPage+10;
		try{
		session = HibernateUtil.openSession();
//		query = "select * from(select rownum as rn,ID_CANDIDATURA , COD_REGIONALE, numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita from graduatoria where cod_regionale='"+codReg+"'" +
//				" ORDER BY punteggio DESC,eta_media ASC,cognome ASC,nome ASC)";
				//" where  rn >= '"+startPage+"'"+
				//"and rownum <='"+maxPerPage+"'";
//JOIN  tra GRADUATORIA e GRADUATORIA_DEFINITIVA		
		query = " select * from(select rownum as rn, G.ID_CANDIDATURA , G.COD_REGIONALE, G.numero_protocollo, G.cognome, G.nome, G.punteggio, G.eta_media, G.data_nascita, G.INDICE_TOTALE, G.INDICE_RELATIVO, G.EXAEQUO, G.EXAEQUO_RISOLTI, G.EXAEQUO_COLOR " +
                " from graduatoria G " + 
				" where G.cod_regionale='"+codReg+"' " +
				" ORDER BY G.punteggio DESC,  G.eta_media ASC, G.INDICE_TOTALE ASC , G.cognome ASC, G.nome ASC)";
	
		
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		sqlQuery.setFirstResult(startPage);
		sqlQuery.setMaxResults(maxPerPage);
		List result = sqlQuery.list();
		
		Graduatoria graduatoria= null;
		
		for(Object object : result){
			graduatoria = new Graduatoria();
			Map row = (Map)object;
			graduatoria.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
			graduatoria.setCodRegione((String) row.get("COD_REGIONALE"));
			graduatoria.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
			graduatoria.setCognome((String) row.get("COGNOME"));
			graduatoria.setNome((String) row.get("NOME"));
			punteggio = (BigDecimal)row.get("PUNTEGGIO");
			graduatoria.setPunteggio(punteggio);
			eta = (BigDecimal) row.get("ETA_MEDIA");
			graduatoria.setEtaMedia(eta);
			graduatoria.setDataNascita((String) row.get("DATA_NASCITA"));
			
			graduatoria.setIndiceTotale((BigDecimal) row.get("INDICE_TOTALE"));
			
			graduatoria.setIndiceRelativo((BigDecimal) row.get("INDICE_RELATIVO"));
			graduatoria.setExAequo((String) row.get("EXAEQUO"));
			graduatoria.setExAequoRisolto((String) row.get("EXAEQUO_RISOLTI"));
			graduatoria.setColor((String) row.get("EXAEQUO_COLOR"));
			
			graduatoriaList.add(graduatoria);
		}
		
		return graduatoriaList;
		
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findOrderByGraduatoria: errore findByFilter");
		}finally{
			session.close();
		}
	}
	
	
	public List<Graduatoria> findOrderAllGraduatoria(String codReg)  throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		List<Graduatoria> graduatoriaList = new ArrayList<Graduatoria>();
		BigDecimal punteggio = new BigDecimal(0);
		BigDecimal eta = new BigDecimal(0);
	
		try{
		session = HibernateUtil.openSession();
		query = "select * from(select rownum as rn,id_candidatura,cod_regionale,numero_protocollo,cognome,nome,punteggio,eta_media,data_nascita, indice_totale, INDICE_RELATIVO, EXAEQUO, EXAEQUO_RISOLTI, EXAEQUO_COLOR from graduatoria where cod_regionale='"+codReg+"'" +
				" ORDER BY punteggio DESC,eta_media ASC,indice_totale, cognome ASC,nome ASC)";
				
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		List result = sqlQuery.list();
		
		Graduatoria graduatoria= null;
		
		for(Object object : result){
			graduatoria = new Graduatoria();
			Map row = (Map)object;
			graduatoria.setNumeroProtocollo((String) row.get("NUMERO_PROTOCOLLO"));
			graduatoria.setCognome((String) row.get("COGNOME"));
			graduatoria.setNome((String) row.get("NOME"));
			punteggio = (BigDecimal)row.get("PUNTEGGIO");
			graduatoria.setPunteggio(punteggio);
			eta = (BigDecimal) row.get("ETA_MEDIA");
			graduatoria.setEtaMedia(eta);
			graduatoria.setDataNascita((String) row.get("DATA_NASCITA"));
			graduatoria.setIdCandidatura((String) row.get("ID_CANDIDATURA"));
			graduatoria.setCodRegione((String) row.get("COD_REGIONALE"));
			graduatoria.setIndiceTotale((BigDecimal)row.get("INDICE_TOTALE"));
			graduatoria.setIndiceRelativo((BigDecimal)row.get("INDICE_RELATIVO"));
			graduatoria.setExAequo((String)row.get("EXAEQUO"));
			graduatoria.setExAequoRisolto((String)row.get("EXAEQUO_RISOLTI"));
			graduatoria.setColor((String)row.get("EXAEQUO_COLOR"));
			
			graduatoriaList.add(graduatoria);
		}
		
		return graduatoriaList;
		
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("GraduatoriaHome - findOrderByGraduatoria: errore findByFilter");
		}finally{
			session.close();
			
		}
	}

	
	
	
	
	public int searchCount(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from graduatoria where cod_regionale='"+codReg+"'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			
			
			
			List result = sqlQuery.list();
		
			int nCount = result.size();
			//BigDecimal totalRecords = (BigDecimal)sqlQuery.uniqueResult();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}finally{
			session.close();
		}
		
		
	}

	public int searchCountIndiceTotale(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from graduatoria where cod_regionale='"+codReg+"' and INDICE_TOTALE > 0";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			
			
			
			List result = sqlQuery.list();
		
			int nCount = result.size();
			//BigDecimal totalRecords = (BigDecimal)sqlQuery.uniqueResult();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}finally{
			session.close();
		}
		
		
	}

	public boolean getRettificatiRow(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from graduatoria where cod_regionale='"+codReg+"' and INDICE_TOTALE is null";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			List result = sqlQuery.list();
		
			if (result.size()>0){
		        return true;	
		    } else{
		    	return false;
		    }
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}finally{
			session.close();
		}
		
		
	}

	public int searchCountExaequoRisolto(String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from graduatoria where cod_regionale='"+codReg+"' and EXAEQUO_RISOLTI ='F'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			
			
			
			List result = sqlQuery.list();
		
			int nCount = result.size();
			//BigDecimal totalRecords = (BigDecimal)sqlQuery.uniqueResult();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}
		finally{
			session.close();
		}
		
		
	}
	

	public int getPosizioneExsist(String codReg, BigDecimal posizione ) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		try{
			session = HibernateUtil.openSession();
			query ="select id_candidatura from graduatoria where cod_regionale='"+codReg+"' and INDICE_TOTALE = "+ posizione + " and EXAEQUO_COLOR<>'red'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
	
			List result = sqlQuery.list();
		
			int nCount = result.size();
			//BigDecimal totalRecords = (BigDecimal)sqlQuery.uniqueResult();
		
			return nCount;
		}catch(RuntimeException re){
		log.error("findByFilterAllUtentiRegioni failed", re);
		throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
		}
		finally{
			session.close();
		}
		
	}
	
	
	public BigDecimal getNuovoIndiceTotale(Graduatoria graduatoria) throws GestioneErroriException{
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		BigDecimal indice = new BigDecimal(0);
		String punteggio =  graduatoria.getPunteggio().toString();
		try{
		session = HibernateUtil.openSession();
		query = "select indice_totale from graduatoria where punteggio <= "+punteggio+" and eta_media >="+graduatoria.getEtaMediaString()+" cod_regionale ='"+graduatoria.getCodRegione()+"' order by indice_totale ASC,eta_media DESC,cognome ASC,nome ASC"; 
		sqlQuery = session.createSQLQuery(query);
		sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		List result = sqlQuery.list();
	
			Map row = (Map)result.get(0);
			indice = (BigDecimal) row.get("INDICE_TOTALE");
		
		
		
		return indice;
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
			}
		finally{
			session.close();
		}
	}
	
	public void updateDiUno(BigDecimal indice,String codReg) throws GestioneErroriException{
		//quelli maggiori di indice
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		Transaction trx = null;
		try{
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			query = "update graduatoria set indice_totale =  indice_totale+1 where cod_regionale='"+codReg+"' and indice_totale >='"+indice.toString()+"'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.executeUpdate();
			trx.commit();
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			trx.rollback();
			throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
			
			}
		finally{
			session.close();
			
		}
	}
	
	public void updateDiMenoUno(BigDecimal nuovo,BigDecimal vecchio,String codReg) throws GestioneErroriException{
		
		String query;
		SQLQuery sqlQuery;
		Session session = null;
		Transaction trx = null;
		try{
			
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			query = "update graduatoria set indice_totale =  indice_totale-1 where cod_regionale='"+codReg+"' and indice_totale >='"+vecchio.toString()+"' and indice_totale<='"+nuovo.toString()+"'";
			sqlQuery = session.createSQLQuery(query);
			sqlQuery.executeUpdate();
			trx.commit();
		}catch(RuntimeException re){
			log.error("findByFilterAllUtentiRegioni failed", re);
			trx.rollback();
			throw new GestioneErroriException("UtenteHome - findByFilterAllUtentiRegioni: errore findByFilter");
			}
		finally{
			session.close();
		}
	}
	
	//restituisce la posizione interpello corrente per la candidatura specificata
	public BigDecimal getIndiceInterpello(String codiceRegione, String idCandidatura) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			Criteria criteria = session.createCriteria(Graduatoria.class);
			//proiezioni
			criteria.setProjection(Projections.property("indiceInterpello"));
			//condizioni
			criteria.add(Restrictions.eq("codRegione", codiceRegione));
			criteria.add(Restrictions.eq("idCandidatura", idCandidatura));
			
			return (BigDecimal) criteria.uniqueResult();
		}
		catch(Exception e) {
			
			log.error("GraduatoriaHome - recupero indice interpello del candidato fallito", e);
			throw new GestioneErroriException("GraduatoriaHome - recupero indice interpello del candidato fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}

	public BigDecimal getIdInterpello(String codiceRegione, String idCandidatura) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			Criteria criteria = session.createCriteria(Graduatoria.class);
			//proiezioni
			criteria.setProjection(Projections.property("idInterpello"));
			//condizioni
			criteria.add(Restrictions.eq("codRegione", codiceRegione));
			criteria.add(Restrictions.eq("idCandidatura", idCandidatura));
			
			return (BigDecimal) criteria.uniqueResult();
		}
		catch(Exception e) {
			
			log.error("GraduatoriaHome - recupero id interpello del candidato fallito", e);
			throw new GestioneErroriException("GraduatoriaHome - recupero id interpello del candidato fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}

	//restituisce la posizione graduatoria totale per la candidatura specificata
	public BigDecimal getIndiceTotaleGraduatoria(String codiceRegione, String idCandidatura) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			Criteria criteria = session.createCriteria(Graduatoria.class);
			//proiezioni
			criteria.setProjection(Projections.property("indiceTotale"));
			//condizioni
			criteria.add(Restrictions.eq("codRegione", codiceRegione));
			criteria.add(Restrictions.eq("idCandidatura", idCandidatura));
			
			return (BigDecimal) criteria.uniqueResult();
		}
		catch(Exception e) {
			
			log.error("GraduatoriaHome - recupero indice totale del candidato fallito", e);
			throw new GestioneErroriException("GraduatoriaHome - recupero indice totale del candidato fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
}
