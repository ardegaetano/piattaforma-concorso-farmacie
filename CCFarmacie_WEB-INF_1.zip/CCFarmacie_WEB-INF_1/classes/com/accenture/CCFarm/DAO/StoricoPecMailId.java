package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;

@SuppressWarnings("serial")
public class StoricoPecMailId implements java.io.Serializable {



	private String idUtente;
	private BigDecimal progressivo;
	
	public StoricoPecMailId() {}


	public String getIdUtente() {
		return idUtente;
	}


	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}


	public BigDecimal getProgressivo() {
		return progressivo;
	}

	public void setProgressivo(BigDecimal progressivo) {
		this.progressivo = progressivo;
	}


	
		
}