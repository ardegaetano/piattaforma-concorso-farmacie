package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Clob;
import java.util.Date;

@SuppressWarnings("serial")
public class StoricoPecMail implements java.io.Serializable {

	private StoricoPecMailId idKey;


	private String idUtente;
	private String oldPecMail;
	private String newPecMail;
	private BigDecimal progressivo;
	private String statoAttivazione;
	
	private Date dataOperazione;
		
	public StoricoPecMail() {}

	public BigDecimal getProgressivo() {
		return progressivo;
	}

	public void setProgressivo(BigDecimal progressivo) {
		this.progressivo = progressivo;
	}

	public StoricoPecMailId getIdKey() {
		return idKey;
	}

	public void setIdKey(StoricoPecMailId idKey) {
		this.idKey = idKey;
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public String getOldPecMail() {
		return oldPecMail;
	}

	public void setOldPecMail(String oldPecMail) {
		this.oldPecMail = oldPecMail;
	}

	public String getNewPecMail() {
		return newPecMail;
	}

	public void setNewPecMail(String newPecMail) {
		this.newPecMail = newPecMail;
	}

	public String getStatoAttivazione() {
		return statoAttivazione;
	}

	public void setStatoAttivazione(String statoAttivazione) {
		this.statoAttivazione = statoAttivazione;
	}

	public Date getDataOperazione() {
		return dataOperazione;
	}

	public void setDataOperazione(Date dataOperazione) {
		this.dataOperazione = dataOperazione;
	}

		
	
		
}