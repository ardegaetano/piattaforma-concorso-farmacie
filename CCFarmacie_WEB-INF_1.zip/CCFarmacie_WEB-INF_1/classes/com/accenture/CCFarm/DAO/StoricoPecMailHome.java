package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;


/**
* Home object for domain model class TipoGraduatoria.
* @see com.accenture.CalcolaTitoli.DAO.TipoGraduatoria
*/
public class StoricoPecMailHome {

	private static final Logger log = CommonLogger.getLogger("StoricoPecHome");
	
	public void persist(StoricoPecMail transientInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting StoricoPecMail instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("StoricoPecHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(StoricoPecMail instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty StoricoPecMail instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			trx.rollback();
			log.error("attach failed", re);
			throw new GestioneErroriException("StoricoPecHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}

	public void attachClean(StoricoPecMail instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean StoricoPecMail instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("StoricoPecHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(StoricoPecMail persistentInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting StoricoPecMail instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("StoricoPecHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public StoricoPecMail merge(StoricoPecMail detachedInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging StoricoPecMail instance");
		try {
			StoricoPecMail result = (StoricoPecMail) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("StoricoPecHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public StoricoPecMail findById(StoricoPecMailId id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting StoricoPecMail instance with id: " + id);
		try {
			StoricoPecMail instance = (StoricoPecMail) session.get("com.accenture.CCFarm.DAO.StoricoPecMailId", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("StoricoPecHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(StoricoPecMail instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding StoricoPecMail instance by example");
		try {
				List results = session
					.createCriteria("com.accenture.CCFarm.DAO.StoricoPecMail")
					.add(Example.create(instance)).addOrder(Order.asc("idUtente")).addOrder(Order.asc("progressivo")).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("StoricoPecHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	

}
