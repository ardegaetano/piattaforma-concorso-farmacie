package com.accenture.CCFarm.DAO;

// Generated 7-set-2012 11.48.05 by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Property;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.util.PropertiesHelper;

import com.accenture.CCFarm.PDFModulo.GestionePDFModuloRicevuta;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.PrintException;

/**
 * Home object for domain model class Ricevute.
 * @see com.ccFram.Ricevute
 * @author Hibernate Tools
 */
public class RicevuteTestHome {

	private static final Log log = LogFactory.getLog(RicevuteTestHome.class);
	public  static final String SEQUENCE = "sequence";
	public  static final String PARAMETERS = "parameters";
	private static String sequenceName;
	private static int LIMITE_SIZE_N_PROTOCOLLO = 6;


	public void persist(RicevuteTest transientInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("persisting Ricevute instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}
	public boolean insertRicevute(RicevuteTest ricevute)
	{
		
		boolean result = false;
		Session session = HibernateUtil.openSession();			
		Transaction sessionTrans = session.getTransaction();			
		try {
			sessionTrans.begin();
			session.save(ricevute);
			sessionTrans.commit();
			log.debug("Operazione Inserimento Ricevuta [OK]");
			result = true;
		} catch (RuntimeException re) {
			log.error("Errore di Inserimento nuova Ricevute");
			throw re;
		} finally {
			session.close();
		}
		
		return result;
	}
	
	public boolean modifyBLOB(RicevuteTest instance) {
		boolean result = false;
		Session session = HibernateUtil.openSession();			
		Transaction sessionTrans = session.getTransaction();			
		try {
			sessionTrans.begin();
			session.update(instance);
			sessionTrans.commit();
			log.debug("Operazione Modifica Ricevuta [OK]");
			result = true;
		} catch (RuntimeException re) {
			log.error("Errore di Modifica nuova Ricevute");
			throw re;
		} finally {
			session.close();
		}
		return result;
	}
	
	
	public void attachDirty(RicevuteTest instance) {
		Session session = HibernateUtil.openSession();
		
		try {
			session.saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(RicevuteTest instance) {
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Ricevute instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(RicevuteTest persistentInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("deleting Ricevute instance");
		try {
			session.delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Ricevute merge(RicevuteTest detachedInstance) {
		Session session = HibernateUtil.openSession();
		log.debug("merging Ricevute instance");
		try {
			Ricevute result = (Ricevute) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public RicevuteTest findById(java.lang.String id) {
		Session session = HibernateUtil.openSession();
		log.debug("getting Ricevute instance with id: " + id);
		try {
			RicevuteTest instance = (RicevuteTest) session.get("com.accenture.CCFarm.DAO.RicevuteTest", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
	
	public RicevuteTest findByCandidatura(String id_candidatura) {
		Session session = HibernateUtil.openSession();
		log.debug("finding Ricevute instance by Candidatura");
		
		RicevuteTest result = new RicevuteTest();
		try {
			Query query = session.createQuery("from RicevuteTest where idKey.idCandidatura = :idCandidatura ");
			query.setParameter("idCandidatura", id_candidatura);
			List<RicevuteTest> lista = query.list();
			if(lista!=null && !lista.isEmpty())
			{
				result = lista.get(0);
			}
			else
			{
				log.info("cannot find any Ricevute for Candidatura (id: "+id_candidatura+")");
			}
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
		return result;
	}	

	public List findByExample(RicevuteTest instance) {
		Session session = HibernateUtil.openSession();
		log.debug("finding Ricevute instance by example");
		try {
			List results = session.createCriteria("com.accenture.CCFarm.DAO.Ricevute")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
	
	public void deleteFromIdCantidatura(String idCandidatura) {
		Session session = HibernateUtil.openSession();
		Transaction tx = session.beginTransaction();
		log.debug("deleting Ricevute instance");
		try {
			
			Query query = session.createSQLQuery("Delete RICEVUTE where ID_CANDIDATURA = '" +idCandidatura +"'" );
			query.executeUpdate();
			tx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
		finally
		{
			session.close();
		}
	}	
	
	

	
	public static String leggiIdSequence(String nomeSequence)  
	{ 
		String result = null;
		Session session = null;
		try
		{ 
			/*
			
			SessionImplementor sim = (SessionImplementor) HibernateUtil.openSession();
			Connection con = sim.connection();
			String sql = "SELECT " + "ID_RICEVUTA_" + nomeSequence +".NEXTVAL FROM DUAL";
			PreparedStatement prest = con.prepareStatement(sql);
			ResultSet rs1 = prest.executeQuery();	
			while (rs1.next()){
				result = rs1.getString(1);	
			}
			while (result.length()<LIMITE_SIZE_N_PROTOCOLLO)
			{
				result = "0" + result;
			}
			con.close();
			*/
			session = HibernateUtil.openSession();
			String sql = "SELECT " + "ID_RICEVUTA_" + nomeSequence +".NEXTVAL FROM DUAL";
			List query =  session.createSQLQuery(sql).list();
			result = query.get(0) +"";
			while (result.length()<LIMITE_SIZE_N_PROTOCOLLO)
			{
				result = "0" + result;
			}				
			
		} catch (RuntimeException e) { 
			e.printStackTrace();
		}
		finally{
			session.close();
			return result;
		}		
	}	
}
