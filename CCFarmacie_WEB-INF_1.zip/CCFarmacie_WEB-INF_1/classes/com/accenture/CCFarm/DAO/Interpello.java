package com.accenture.CCFarm.DAO;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;

public class Interpello implements Serializable {

	private InterpelloId id;
	private Serializable dataInizio;
	private Serializable dataFine;
	private Blob attoAmministrativo;
	private String stato;
	private BigDecimal numeroSedi;
	private Serializable dataInizioAccettazione;
	private Serializable dataFineAccettazione;
	private String statoAccettazione;
	
	public Interpello() {
		
	}

	public Interpello(InterpelloId id) {
		
		this.id = id;
	}

	public Interpello(InterpelloId id, Serializable dataInizio,
			Serializable dataFine, Blob attoAmministrativo, String stato,
			BigDecimal numeroSedi) {
		
		this.id = id;
		this.dataInizio = dataInizio;
		this.dataFine = dataFine;
		this.attoAmministrativo = attoAmministrativo;
		this.stato = stato;
		this.numeroSedi = numeroSedi;
	}

	public InterpelloId getId() {
		return id;
	}

	public void setId(InterpelloId id) {
		this.id = id;
	}

	public Serializable getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(Serializable dataInizio) {
		this.dataInizio = dataInizio;
	}

	public Serializable getDataFine() {
		return dataFine;
	}

	public void setDataFine(Serializable dataFine) {
		this.dataFine = dataFine;
	}

	public Blob getAttoAmministrativo() {
		return attoAmministrativo;
	}

	public void setAttoAmministrativo(Blob attoAmministrativo) {
		this.attoAmministrativo = attoAmministrativo;
	}

	public String getStato() {
		return stato;
	}

	public void setStato(String stato) {
		this.stato = stato;
	}

	public BigDecimal getNumeroSedi() {
		return numeroSedi;
	}

	public void setNumeroSedi(BigDecimal numeroSedi) {
		this.numeroSedi = numeroSedi;
	}

	public Serializable getDataInizioAccettazione() {
		return dataInizioAccettazione;
	}

	public void setDataInizioAccettazione(Serializable dataInizioAccettazione) {
		this.dataInizioAccettazione = dataInizioAccettazione;
	}

	public Serializable getDataFineAccettazione() {
		return dataFineAccettazione;
	}

	public void setDataFineAccettazione(Serializable dataFineAccettazione) {
		this.dataFineAccettazione = dataFineAccettazione;
	}

	public String getStatoAccettazione() {
		return statoAccettazione;
	}

	public void setStatoAccettazione(String statoAccettazione) {
		this.statoAccettazione = statoAccettazione;
	}
	
}
