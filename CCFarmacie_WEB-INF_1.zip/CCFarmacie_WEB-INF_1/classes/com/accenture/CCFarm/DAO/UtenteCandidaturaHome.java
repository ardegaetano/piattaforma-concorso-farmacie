package com.accenture.CCFarm.DAO;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Level;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PDFModulo.GestionePDFModuloRicevuta;
import com.accenture.CCFarm.PDFModulo.GestionePDFModuloRicevutaTedesco;
import com.accenture.CCFarm.utility.CCFarmLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.MatriceProperties;
import com.accenture.CCFarm.utility.MatricePropertiesDe;
import com.accenture.CCFarm.utility.RecuperaProtocollo;
import com.accenture.CCFarm.utility.StaticDefinitions;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.mailer.concorsofarma.GestoreMail;
import com.accenture.mailer.concorsofarma.data.MailBean;

/**
 * Home object for domain model class Utente.
 * 
 * @see com.accenture.CCFarm.DAO.Utente
 * @author Hibernate Tools
 */
public class UtenteCandidaturaHome {

	private static final Log log = LogFactory.getLog(UtenteHome.class);

	public UtenteCandidatura findById(java.lang.String id) {
		Session session = HibernateUtil.openSession();
		log.debug("getting Utente instance with id: " + id);
		try {
			UtenteCandidatura instance = (UtenteCandidatura) session.get(
					"com.accenture.CCFarm.DAO.UtenteCandidatura", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		} finally {
			session.close();
		}
	}

	
	public void annullaDomanda(List<UtenteCandidatura> listCand, String linguaScelta) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		CCFarmLogger.log("saveOrUpdate Candidatura instance", Level.INFO_INT, CandidaturaHome.class);
		java.util.Date dataSys= new java.util.Date();
		boolean ok = true;
		
		
		LogIn logIn = null;
		GestoreMail gestoreMail = new GestoreMail();
		MailBean mailBean = null;
		int[] indiciMail = new int[listCand.size()];
		java.sql.Connection conn = session.connection();
		UtenteCandidatura utenteCandidatura = null;
		
		try {
			for (int i = 0; i < listCand.size(); i++) {
				utenteCandidatura = (UtenteCandidatura) listCand.get(i);
				utenteCandidatura.getCandidatura().setStatoDomanda("A");
				utenteCandidatura.getCandidatura().setStatoRegistrazione("A");
				utenteCandidatura.getCandidatura().setLastUpdateDateCand(new java.sql.Timestamp(dataSys.getTime()));
				utenteCandidatura.getCandidatura().setLastUpdatedByCand(utenteCandidatura.getIdUtente());
			
				session.saveOrUpdate(utenteCandidatura);
				CCFarmLogger.log("Annullamento avvenuto con successo per la candidatura: idUtente" + utenteCandidatura.getIdUtente(), Level.INFO_INT, CandidaturaHome.class);
				mailBean = new MailBean();
				if(linguaScelta.equals("DE")){
					mailBean.setCorpoMail(getCorpoMailAnnullamentoTedesco(utenteCandidatura));
					mailBean.setOggettoMail("Autonome Provinz Bozen -Au�erordentliche Ausschreibung der Apotheken. Eingang des Annullierungsantrages - " + utenteCandidatura.getNomeUtente() + " " + utenteCandidatura.getCognomeUtente() + ".");
					
				}else{
					mailBean.setCorpoMail(getCorpoMailAnnullamento(utenteCandidatura));
					mailBean.setOggettoMail("Regione "+Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente()) + " - Concorso straordinario farmacie. Ricevuta annullamento domanda - " + utenteCandidatura.getNomeUtente() + " " + utenteCandidatura.getCognomeUtente() + ".");
					
				}
				
				ArrayList listaDest = new ArrayList<String>();
				listaDest.add(utenteCandidatura.getPecMail());
				mailBean.setToAddresses(listaDest);
				
				// SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
				indiciMail[i] = gestoreMail.saveMail(mailBean,StaticDefinitions.MAIL_PROPERTIES, conn);				
		     }	
			
			trx.commit();
		} catch (Exception e) {
			trx.rollback();
			log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE  ", e);
			throw new GestioneErroriException("CandidaturaHome - saveOrUpdate: errore nell' aggiornmaneto della candidatura: idUtente");
		}	
		
		for (int i = 0; i < indiciMail.length; i++) {
			try {
				gestoreMail.sendMail(indiciMail[i],	StaticDefinitions.MAIL_PROPERTIES, conn);
			} catch (Throwable thr) {
				log.error("UtenteCandidaturaHome - inserisciCandidatura: errore nell' invio della mail (la mail verr� inviata via batch) " + thr.getMessage(), thr);
			}
		}
	
	}
	
	
	public List findByExample(UtenteCandidatura instance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding Utente instance by example");
		try {
			List results = session.createCriteria("com.accenture.CCFarm.DAO.UtenteCandidatura").add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			LogUtil.printException(re);
			GestioneErroriException eccezione = new GestioneErroriException("UtenteCandidaturaHome - findByExample: errore nella findByExample di UtenteCandidatura");
			LogUtil.printException(eccezione);
			throw eccezione;
		} finally {
			session.close();
		}
	}

	public void annullaRegistazioniCandidatura (String idCandidatura){
		Session session = HibernateUtil.openSession();
		try{
			Query query = session.createQuery("Update Candidatura set STATO_REGISTRAZIONE = 'A' where ID_CANDIDATURA ='" + idCandidatura +"'");
			query.executeUpdate();
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			LogUtil.printException(re);
			GestioneErroriException eccezione = new GestioneErroriException("UtenteCandidaturaHome - annullaRegistazioniCandidatura: errore allumaneto della registrazione di una candidatura");
			LogUtil.printException(eccezione);
			throw re;
		} finally {
			session.close();
		}
	}
	
	public void inserisciDomanda(DomandaDao domanda, boolean isTedesco)
			throws GestioneErroriException {
		MatriceProperties matriceIt = MatriceProperties.getMatricePropertiesIt();
		MatricePropertiesDe matriceDe = MatricePropertiesDe.getMatricePropertiesDe();
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");
		try {
			String idDomanda = domanda.getUtenteCandidatura().getIdUtente();

			if (domanda.getUtenteCandidatura() != null)
				session.saveOrUpdate(domanda.getUtenteCandidatura());
			
			if (domanda.getRequisitiMinimi() != null)
				session.saveOrUpdate(domanda.getRequisitiMinimi());
			
			if (domanda.getIdoneita() != null)
				session.saveOrUpdate(domanda.getIdoneita());
			
			Query query = session.createQuery("Delete AltraLaurea where idDomandaLaurea ='" + idDomanda +"'");
			query.executeUpdate();
			if (domanda.getAltraLaurea() != null && domanda.getAltraLaurea().getDescUniSecondaLaurea()!= null && !domanda.getAltraLaurea().getDescUniSecondaLaurea().equals("")){
				//domanda.getAltraLaurea().setIdSecondaLaurea(matrice.getMatriceProperties(domanda.getAltraLaurea().getIdSecondaLaurea().replace(" ", "_")));
				//domanda.getAltraLaurea().setFlagEsteroSecondaLaurea(matrice.getMatriceProperties(domanda.getAltraLaurea().getFlagEsteroSecondaLaurea().replace(" ", "_")));
				//domanda.getAltraLaurea().setNazioneSecondaLaurea(matrice.getMatriceProperties(domanda.getAltraLaurea().getNazioneSecondaLaurea().replace(" ", "_")));
				session.saveOrUpdate(domanda.getAltraLaurea());
				
			}	
			if (domanda.getDichiarazioneSostitutiva() != null)
				session.saveOrUpdate(domanda.getDichiarazioneSostitutiva());
			
			
			//gestione documenti da inviare
        	if(domanda.getListaDocumenti()!=null && domanda.getListaDocumenti().size()>0 ){
        		
        		//cancello i docuemnti esistenti in tabella
    			query = session.createQuery("Delete Documento where idDomandaDocumento ='" + idDomanda +"'");
    			query.executeUpdate();
    			
    			ArrayList<Documento> listaDocumenti = domanda.getListaDocumenti();
    			Documento documento = null;
    			for (int i = 0; i < listaDocumenti.size(); i++) {
    				documento = listaDocumenti.get(i);
    				session.saveOrUpdate(documento);
    			}
        		
        	}
        	else { 
        		//Controlla se i documenti non ci sono elimina su DB eventuali Doc salvati in precedenza
        		query = session.createQuery("Delete Documento where idDomandaDocumento ='" + idDomanda +"'");
    			query.executeUpdate();
    			log.info("Documento Eliminato per la domanda:"+ idDomanda);
        	}

			// cancella tutti i record relativi all'idUtente specificato
			AltraLaureaBis altraLaureaBisDel = new AltraLaureaBis();
			altraLaureaBisDel.setIdDomandaLaureaBis(idDomanda);
			query = session.createQuery("Delete AltraLaureaBis where idDomandaLaureaBis ='" + idDomanda +"'");
			query.executeUpdate();
			//session.delete(altraLaureaBisDel);

			ArrayList<AltraLaureaBis> listaAltraLaureaBis = domanda.getListaAltraLaureaBis();
			AltraLaureaBis altraLaurea = null;
			for (int i = 0; i < listaAltraLaureaBis.size(); i++) {
				altraLaurea = listaAltraLaureaBis.get(i);
				if(isTedesco){
					altraLaurea.setIdAltraLaureaBis(matriceIt.getMatricePropertiesIt( listaAltraLaureaBis.get(i).getIdAltraLaureaBis().replace(" ", "_")));
					altraLaurea.setFlagEsteroSecondaLaureaBis(matriceIt.getMatricePropertiesIt(listaAltraLaureaBis.get(i).getFlagEsteroSecondaLaureaBis().replace(" ", "_")));
					altraLaurea.setNazioneSecondaLaureaBis(matriceIt.getMatricePropertiesIt(listaAltraLaureaBis.get(i).getNazioneSecondaLaureaBis().replace(" ", "_")));
				}
				session.saveOrUpdate(altraLaurea);
			}

			// cancella tutti i record relativi all'idUtente specificato
			AltroTitolo altroTitoloDel = new AltroTitolo();
			altroTitoloDel.setIdDomandaTitolo(idDomanda);
			query = session.createQuery("Delete AltroTitolo where idDomandaTitolo ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<AltroTitolo> listaAltroTitolo = domanda.getListaAltroTitolo();
			AltroTitolo altroTitolo = null;
			for (int i = 0; i < listaAltroTitolo.size(); i++) {
				altroTitolo = listaAltroTitolo.get(i);
				if(isTedesco){
					altroTitolo.setFlagEsteroAltroTitolo(matriceIt.getMatricePropertiesIt(altroTitolo.getFlagEsteroAltroTitolo().replace(" ", "_")));
					altroTitolo.setEsameFinaleAltroTitolo(matriceIt.getMatricePropertiesIt(altroTitolo.getEsameFinaleAltroTitolo().replace(" ", "_")));
				}
				session.saveOrUpdate(altroTitolo);
			}

			// cancella tutti i record relativi all'idUtente specificato
			BorsaStudio borsaStudioDel = new BorsaStudio();
			borsaStudioDel.setIdDomandaBorsaStudio(idDomanda);
			//session.delete(borsaStudioDel);
			query = session.createQuery("Delete BorsaStudio where idDomandaBorsaStudio ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<BorsaStudio> listaBorsaStudio = domanda.getListaBorsaStudio();
			BorsaStudio borsaStudio = null;
			for (int i = 0; i < listaBorsaStudio.size(); i++) {
				borsaStudio = listaBorsaStudio.get(i);
				if(isTedesco){
					borsaStudio.setFlagEsteroBorsa(matriceIt.getMatricePropertiesIt(borsaStudio.getFlagEsteroBorsa().replace(" ", "_")));
					
					borsaStudio.setNazioneBorsa(matriceIt.getMatricePropertiesIt(borsaStudio.getNazioneBorsa().replace(" ", "_")));
					
				}
				session.saveOrUpdate(borsaStudio);
			}

			// cancella tutti i record relativi all'idUtente specificato
			CorsoAggiornamento corsoAggiornamentoDel = new CorsoAggiornamento();
			corsoAggiornamentoDel.setIdDomandaAgg(idDomanda);
			query = session.createQuery("Delete CorsoAggiornamento where idDomandaAgg ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<CorsoAggiornamento> listaCorsoAggiornamento = domanda.getListaCorsoAggiornamento();
			CorsoAggiornamento corsoAggiornamento;
			for (int i = 0; i < listaCorsoAggiornamento.size(); i++) {
				corsoAggiornamento = listaCorsoAggiornamento.get(i);
				if(isTedesco)
				{
					corsoAggiornamento.setDichiarazioneCorsoAgg(matriceIt.getMatricePropertiesIt(corsoAggiornamento.getDichiarazioneCorsoAgg().replace(" ", "_")));
					corsoAggiornamento.setFlagEsteroCorsoAgg(matriceIt.getMatricePropertiesIt(corsoAggiornamento.getFlagEsteroCorsoAgg().replace(" ", "_")));
				}
				session.saveOrUpdate(corsoAggiornamento);

			}

			// cancella tutti i record relativi all'idUtente specificato
			Dottorato dottoratoDel = new Dottorato();
			dottoratoDel.setIdDomandaDottorato(idDomanda);
			//session.delete(dottoratoDel);
			query = session.createQuery("Delete Dottorato where idDomandaDottorato ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<Dottorato> listaDottorato = domanda.getListaDottorato();
			Dottorato dottorato = null;
			for (int i = 0; i < listaDottorato.size(); i++) {
				dottorato = listaDottorato.get(i);
				if(isTedesco){
					dottorato.setFlagEsteroDottorato(matriceIt.getMatricePropertiesIt(dottorato.getFlagEsteroDottorato().replace(" ", "_")));
					dottorato.setNazioneDottorato(matriceIt.getMatricePropertiesIt(dottorato.getNazioneDottorato().replace(" ", "_")));
				}
				session.saveOrUpdate(dottorato);
			}

			// cancella tutti i record relativi all'idUtente specificato
			Pubblicazione pubblicazioneDel = new Pubblicazione();
			pubblicazioneDel.setIdDomandaPubbl(idDomanda);
			query = session.createQuery("Delete Pubblicazione where idDomandaPubbl ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<Pubblicazione> listaPubblicazioni = domanda.getListaPubblicazione();
			Pubblicazione pubblicazione = null;
			for (int i = 0; i < listaPubblicazioni.size(); i++) {
				pubblicazione = listaPubblicazioni.get(i);
				if(isTedesco){
					pubblicazione.setTipoPubblicazione(matriceIt.getMatricePropertiesIt(pubblicazione.getTipoPubblicazione().replace(" ", "_")));
				}
				session.saveOrUpdate(pubblicazione);
			}

			// cancella tutti i record relativi all'idUtente specificato
			Specializzazione specializzazioneDel = new Specializzazione();
			specializzazioneDel.setIdDomandaSpec(idDomanda);
			query = session.createQuery("Delete Specializzazione where idDomandaSpec ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<Specializzazione> listaSpecializzazioni = domanda.getListaSpecializzazione();
			Specializzazione specializzazione = null;
			for (int i = 0; i < listaSpecializzazioni.size(); i++) {
				specializzazione = listaSpecializzazioni.get(i);
				if(isTedesco){
					specializzazione.setNazioneSpec(matriceIt.getMatricePropertiesIt(specializzazione.getNazioneSpec().replace(" ", "_")));
					specializzazione.setFlagEsteroSpec(matriceIt.getMatricePropertiesIt(specializzazione.getFlagEsteroSpec().replace(" ", "_")));
				}
				session.saveOrUpdate(specializzazione);
			}

			// cancella tutti i record relativi all'idUtente specificato
			EsercizioProf esercizioProfDel = new EsercizioProf();
			esercizioProfDel.setIdDomandaEs(idDomanda);
			query = session.createQuery("Delete EsercizioProf where idDomandaEs ='" + idDomanda +"'");
			query.executeUpdate();

			ArrayList<EsercizioProf> listaEsercizioProf = domanda.getListaEserciziProf();
			EsercizioProf esercizioProf = null;
			for (int i = 0; i < listaEsercizioProf.size(); i++) {
				esercizioProf = listaEsercizioProf.get(i);
				if(isTedesco){
					if(listaEsercizioProf.get(i).getFlagFarmRurale()!=null)
					esercizioProf.setFlagFarmRurale(matriceIt.getMatricePropertiesIt(listaEsercizioProf.get(i).getFlagFarmRurale()));
					
					
				}
				session.saveOrUpdate(esercizioProf);
			}
			

			trx.commit();
			log.info("Salvataggio della domanda avvenuto con successo per la candidatura:"
					+ domanda.getUtenteCandidatura().getCandidatura()
							.getIdCandidatura());

		} catch (Exception e) {
			log.fatal("UtenteCandidaturaHome inserisciDomanda failed", e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"UtenteCandidaturaHome - inserisciDomanda: errore nell' inserimento della domanda",
					e);
			trx.rollback();
			throw eccezione;
		} finally {
			session.close();
		}
	}

	public void inviaDomanda(DomandaDao domanda, boolean isTedesco) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");
		try {
			String idDomanda = domanda.getUtenteCandidatura().getIdUtente();

			domanda.getUtenteCandidatura().getCandidatura().setDataInvioDomanda(DateUtil.utilDateToSQLDate(DateUtil.getCurrentTimestamp()));
			//Inserisco la domanda
			inserisciDomanda(domanda,isTedesco);
			
			//lo stato di completa sulla domanda viene messo in maniera transazionale alla generazione de pdf ed invio mail
			UtenteCandidatura utenteCandidatura = domanda.getUtenteCandidatura();
			utenteCandidatura.getCandidatura().setStatoDomanda("I");
			domanda.setUtenteCandidatura(utenteCandidatura);
			session.saveOrUpdate(utenteCandidatura);
			
			//Creo quanto serve per inviare la mial con il pdf allegato
			GestoreMail gestoreMail = new GestoreMail();
			MailBean mailBean = new MailBean() ;
			int[] indiciMail = new int[1];
			java.sql.Connection conn = session.connection();

			//nel caso di un associata recupero tutti i candidati che fanno parte della domanda
			if(domanda.getUtenteCandidatura().getCandidatura().getModalitaCandidatura().equalsIgnoreCase("A")){
				
				CandidaturaHome candidaturaHome = new CandidaturaHome();
				Candidatura candidatura = new Candidatura();
				candidatura.setIdCandidatura(domanda.getUtenteCandidatura().getCandidatura().getIdCandidatura());
				candidatura.setReferenteDomanda("N");
				List listaCandidati = candidaturaHome.findByExample(candidatura);
				//aggiorno lo stato di tutti i candidati e li metto in Terminata
				if(listaCandidati != null){
					for (int i =0; i< listaCandidati.size(); i++ ){
						candidatura = (Candidatura) listaCandidati.get(i);
						candidatura.setDataInvioDomanda(DateUtil.utilDateToSQLDate(DateUtil.getCurrentTimestamp()));
						candidatura.setStatoDomanda("T");
						session.saveOrUpdate(candidatura);
					}
				}
			}
			
			GestionePDFModuloRicevutaTedesco creaPdfTedesco = null;
			GestionePDFModuloRicevuta creaPdf = null;
			ByteArrayInputStream in = null;
			// Creo il pdf da mandare in allegato alla mail 
			if(isTedesco){
				// Creo il pdf tedesco da mandare in allegato alla mail 
				creaPdfTedesco = new GestionePDFModuloRicevutaTedesco();
				creaPdfTedesco.caricaDatiDaUtentePerEntityPDF(domanda.getUtenteCandidatura().getIdUtente());
				creaPdfTedesco.creaRicevutaPDF();
				in = new ByteArrayInputStream(creaPdfTedesco.getImgRicevutaPDF());
				//recupero numero protocollo
				RecuperaProtocollo recuperaProtocollo = new RecuperaProtocollo();
				String protocollo = recuperaProtocollo.getProtocollo(idDomanda);
				mailBean.setOggettoMail("Autonome Provinz Bozen - Au�erordentliche Ausschreibung f�r Apotheken. Versandbest�tigung der Bewerbung  - Protokollnummer  "+protocollo+" - " + utenteCandidatura.getNomeUtente() + " " + utenteCandidatura.getCognomeUtente() + ".");
				//Creo la mail
				mailBean.setCorpoMail(getCorpoMailTedesco(utenteCandidatura));
			}else{
				creaPdf = new GestionePDFModuloRicevuta();
				creaPdf.caricaDatiDaUtentePerEntityPDF(domanda.getUtenteCandidatura().getIdUtente());
				creaPdf.creaRicevutaPDF();
				in = new ByteArrayInputStream(creaPdf.getImgRicevutaPDF());
				//recupero numero protocollo
				RecuperaProtocollo recuperaProtocollo = new RecuperaProtocollo();
				String protocollo = recuperaProtocollo.getProtocollo(idDomanda);
				mailBean.setOggettoMail("Regione "+Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente()) + " - Concorso straordinario farmacie. Ricevuta invio domanda - numero protocollo "+protocollo+" - " + utenteCandidatura.getNomeUtente() + " " + utenteCandidatura.getCognomeUtente() + ".");
				//Creo la mail
				mailBean.setCorpoMail(getCorpoMail(utenteCandidatura));
			}
			
			
						

			

			
			ArrayList listaDest = new ArrayList<String>();
			listaDest.add(utenteCandidatura.getPecMail());
			mailBean.setToAddresses(listaDest);
			
			mailBean.addAllegato("Ricevuta", in , "application/pdf");
			//Bisogna settare gli allegati
			
		     //SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail 
			indiciMail[0] = gestoreMail.saveMail(mailBean, StaticDefinitions.MAIL_PROPERTIES, conn);
			
			trx.commit();
			
			try {
				gestoreMail.sendMail(indiciMail[0],	StaticDefinitions.MAIL_PROPERTIES, conn);
			} catch (Throwable thr) {
				log.error(	"UtenteCandidaturaHome - inserisciCandidatura: errore nell' invio della mail (la mail verr� inviata via batch) " + thr.getMessage(), thr);
			}
			
			
			log.info("Salvataggio della domanda avvenuto con successo per la candidatura:" 	+ domanda.getUtenteCandidatura().getCandidatura().getIdCandidatura());

		} catch (Exception e) {
			log.fatal("UtenteCandidaturaHome inserisciDomanda failed", e);
			GestioneErroriException eccezione = new GestioneErroriException("UtenteCandidaturaHome - inserisciDomanda: errore nell' inserimento della domanda", e);
			throw eccezione;
		} finally {
			session.close();
		}

	}
	
	public String getCorpoMail(UtenteCandidatura utenteCandidatura){ 
		
		String gentileCliente = "Gentile�"+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" ,  ";
		String laSuaDomanda =" in allegato a questa mail pu� trovare la ricevuta della domanda da lei inviata per la partecipazione al concorso per l'assegnazione delle sedi farmaceutiche della regione   "+ Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente())+" .";
		String pdf = "<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+laSuaDomanda+" "+"</htlml>";
				
		return pdf;
			 
		
	}
	
	
 public String getCorpoMailTedesco(UtenteCandidatura utenteCandidatura){ 
		
		String gentileCliente = "Sehr geehrter / Sehr geehrte �"+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" ,  ";
		String laSuaDomanda =" dieser E-Mail liegt die Best�tigung Ihrer gesendeten Bewerbung f�r die Ausschreibung f�r die Zuweisung von Apothekensitzen der Autonomen Provinz Bozen bei.";
		String pdf = "<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+laSuaDomanda+" "+"</htlml>";
				
		return pdf;
			 
		
	}
	 
	public String getCorpoMailAnnullamento(UtenteCandidatura utenteCandidatura){ 
			
			RicevuteHome ricevuteDAO = new RicevuteHome();
			Ricevute ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
			String id_ricevuta_inserito = "";
			if(ricevuta!=null){
				
				id_ricevuta_inserito = (ricevuta.getId()!=null) ? ricevuta.getId().getIdRicevuta() : null;
			}
			String gentileCliente = "Gentile Dott./Dott.ssa�"+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" ,";
			String localita = "Regione ";
			if(utenteCandidatura.getCodRegUtente().equals("041") || utenteCandidatura.getCodRegUtente().equals("042")){
				localita = "Provincia autonoma ";
			}
			String laSuaDomanda = "";
			if(ricevuta!= null && ricevuta.getId() != null && ricevuta.getId().getIdRegione() != null) {
				String dateInvio = StringUtil.dateToStringDDMMYYYY(ricevuta.getDataInvio());
				String numero_protocollo_ricevuta = id_ricevuta_inserito + " - " + dateInvio +  " - " + utenteCandidatura.getCodRegUtente();
				
				laSuaDomanda =" la sua domanda di partecipazione al concorso per l'assegnazione delle sedi farmaceutiche per la " + localita  + Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente())+" con protocollo N. " + numero_protocollo_ricevuta +" e data invio "+dateInvio+" � stata annullata.";
			}else{
				 laSuaDomanda =" la sua domanda di partecipazione al concorso per l'assegnazione delle sedi farmaceutiche per la " + localita  + Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente()) +" � stata annullata.";
			}
			String nuovaDomanda = "L'inserimento di una nuova candidatura per la stessa Regione o la stessa Provincia Autonoma pu� essere effettuato esclusivamente a seguito di una nuova registrazione alla piattaforma." ;
			String mail = "<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+laSuaDomanda+"\r\n<br/>"+ nuovaDomanda + "</htlml>";
					
			return mail;	 
			
		}
	
	
	
	
	
	public String getCorpoMailAnnullamentoTedesco(UtenteCandidatura utenteCandidatura){ 
		
		RicevuteHome ricevuteDAO = new RicevuteHome();
		Ricevute ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
		String id_ricevuta_inserito = "";
		if(ricevuta!=null){
			
			 id_ricevuta_inserito = (ricevuta.getId()!=null) ? ricevuta.getId().getIdRicevuta() : null;
		}
		String gentileCliente = "Sehr geehrter Herr / Frau"+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" ,";
		String localita = "Regione ";
		if(utenteCandidatura.getCodRegUtente().equals("041") || utenteCandidatura.getCodRegUtente().equals("042")){
			localita = "Provincia autonoma ";
		}
		String laSuaDomanda = "";
		if(ricevuta!= null && ricevuta.getId() != null && ricevuta.getId().getIdRegione() != null) {
			String dateInvio = StringUtil.dateToStringDDMMYYYY(ricevuta.getDataInvio());
			String numero_protocollo_ricevuta = id_ricevuta_inserito + " - " + dateInvio +  " - " + utenteCandidatura.getCodRegUtente();
			
			laSuaDomanda =" Ihre Bewerbung f�r die au�erordentliche Ausschreibung f�r die Zuweisung von Apothekensitzen f�r die Autonomen Provinz Bozen -  Protokollnummer: " + numero_protocollo_ricevuta +" und Einreichdatum "+dateInvio+" wurde annulliert.";
		}else{
			 laSuaDomanda ="Ihre Bewerbung f�r die au�erordentliche Ausschreibung f�r die Zuweisung von Apothekensitzen f�r die Autonomen Provinz Bozen  wurde annulliert.";
		}
		String nuovaDomanda = "Die Eingabe einer neuen Bewerbung f�r die gleiche Region oder gleiche autonome Provinz kann nur nach einer neuen Anmeldung bei der Plattform erfolgen." ;
		String mail = "<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+laSuaDomanda+"\r\n<br/>"+ nuovaDomanda + "</htlml>";
				
		return mail;	 
		
	}

	
	
	
	
	
	

	
		public void cambioPassword(UtenteCandidatura instance) throws GestioneErroriException {
			
			Session session = HibernateUtil.openSession();
			Transaction trx = session.beginTransaction();
			log.debug("attaching dirty Utente instance");
			try {
				
				LogIn logIn = new LogIn();
				GestoreMail gestoreMail = new GestoreMail();
				MailBean mailBean = null;
				
				java.sql.Connection conn = session.connection();
            
				logIn = instance.getLogIn();
				session.saveOrUpdate(instance);
			    // salvataggio dei dati di login
				session.saveOrUpdate(logIn);
				mailBean = instance.getMailBean();
				// SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
				try {
				int indice = gestoreMail.saveMail(mailBean,	StaticDefinitions.MAIL_PROPERTIES, conn);

				trx.commit();
				log.info("Salvataggio richiesta e mail avvenuto con successo per la candidatura:"
						+ instance.getCandidatura().getIdCandidatura());

						gestoreMail.sendMail(indice, StaticDefinitions.MAIL_PROPERTIES, conn);
						
					} catch (Throwable thr) {
						log.error(
								"UtenteCandidaturaHome - inserisciCandidatura: errore nell' invio della mail (la mail verr� inviata via batch) "
										+ thr.getMessage(), thr);
					}
				

			} catch (Exception e) {
				log.fatal("UtenteCandidaturaHome inserisciCandidatura failed", e);
				GestioneErroriException eccezione = new GestioneErroriException(
						"UtenteCandidaturaHome - inserisciCandidatura: errore nell' inserimento della candidatuira",
						e);
				throw eccezione;
			}finally {
				session.close();
			}
		}

	
		public void inserisciCandidatura(ArrayList<UtenteCandidatura> instance)	throws GestioneErroriException {
			Session session = HibernateUtil.openSession();
			Transaction trx = session.beginTransaction();
			
			log.debug("attaching dirty Utente instance");
		try {
			UtenteCandidatura utenteCandidatura = null;
			LogIn logIn = null;
			GestoreMail gestoreMail = new GestoreMail();
			MailBean mailBean = null;
			int[] indiciMail = new int[instance.size()];
			java.sql.Connection conn = session.connection();

			for (int i = 0; i < instance.size(); i++) {
				utenteCandidatura = instance.get(i);
				logIn = utenteCandidatura.getLogIn();
				session.saveOrUpdate(utenteCandidatura);
				// salvataggio dei dati di login
				session.saveOrUpdate(logIn);
				mailBean = utenteCandidatura.getMailBean();
				// SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
				indiciMail[i] = gestoreMail.saveMail(mailBean,StaticDefinitions.MAIL_PROPERTIES, conn);

			}

			trx.commit();
			log.info("Salvataggio richiesta e mail avvenuto con successo per la candidatura:"
					+ utenteCandidatura.getCandidatura().getIdCandidatura());

			for (int i = 0; i < indiciMail.length; i++) {
				try {
					gestoreMail.sendMail(indiciMail[i],
							StaticDefinitions.MAIL_PROPERTIES, conn);
				} catch (Throwable thr) {
					log.error(
							"UtenteCandidaturaHome - inserisciCandidatura: errore nell' invio della mail (la mail verr� inviata via batch) "
									+ thr.getMessage(), thr);
				}
			}

		} catch (Exception e) {
			log.fatal("UtenteCandidaturaHome inserisciCandidatura failed", e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"UtenteCandidaturaHome - inserisciCandidatura: errore nell' inserimento della candidatuira",
					e);
			throw eccezione;
		} finally {
			session.close();
		}
	}
		
		
		public void inviaNuovaPec(UtenteCandidatura utenteCandidatura)	throws GestioneErroriException {
			Session session = HibernateUtil.openSession();
			Transaction trx = session.beginTransaction();
			
			log.debug("attaching dirty UtenteCandidatura instance");
		try {
			StoricoPecMailHome storicoPecH = new StoricoPecMailHome ();
			StoricoPecMail storicoPecM = new StoricoPecMail ();
			StoricoPecMailId storicoPecMI = new StoricoPecMailId ();
			List<StoricoPecMail> listPecMail = new ArrayList<StoricoPecMail>();
			storicoPecM.setIdUtente(utenteCandidatura.getIdUtente());
			listPecMail = storicoPecH.findByExample(storicoPecM);
			
			if (listPecMail==null || listPecMail.size()==0){
				
				BigDecimal prog =new BigDecimal (1);
				storicoPecMI.setIdUtente(utenteCandidatura.getIdUtente());
				storicoPecMI.setProgressivo(prog);
				storicoPecM.setIdKey(storicoPecMI);
				storicoPecM.setIdUtente(utenteCandidatura.getIdUtente());
				storicoPecM.setProgressivo(prog);
				storicoPecM.setNewPecMail(utenteCandidatura.getNewPecMail());
				storicoPecM.setOldPecMail(utenteCandidatura.getPecMail());
				storicoPecM.setStatoAttivazione("F");
				storicoPecM.setDataOperazione(null);

			
			}else{
				
				storicoPecM = listPecMail.get(listPecMail.size()-1);
				BigDecimal prog = new BigDecimal(storicoPecM.getProgressivo().intValue()+1);
				storicoPecMI.setIdUtente(utenteCandidatura.getIdUtente());
				storicoPecMI.setProgressivo(prog);
				storicoPecM.setIdKey(storicoPecMI);
				storicoPecM.setIdUtente(utenteCandidatura.getIdUtente());
				storicoPecM.setProgressivo(prog);
				storicoPecM.setNewPecMail(utenteCandidatura.getNewPecMail());
				storicoPecM.setOldPecMail(utenteCandidatura.getPecMail());
				storicoPecM.setStatoAttivazione("F");
				storicoPecM.setDataOperazione(null);
				storicoPecM.setIdKey(storicoPecMI);
				
			}
			// Inserimento nella tabella STORICO_PEC_MAIL
			storicoPecH.saveOrUpdate(storicoPecM);

			GestoreMail gestoreMail = new GestoreMail();
			MailBean mailBean = null;
			//int[] indiciMail = new int[utente.size()];
			java.sql.Connection conn = session.connection();

				mailBean = utenteCandidatura.getMailBean();
				// SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
				int indiciMail = gestoreMail.saveMail(mailBean,StaticDefinitions.MAIL_PROPERTIES, conn);

			trx.commit();
			log.info("Invio mail avvenuto con successo");

				try {
					gestoreMail.sendMail(indiciMail,
							StaticDefinitions.MAIL_PROPERTIES, conn);
				} catch (Throwable thr) {
					log.error(
							"UtenteCandidaturaHome - inviaNuovaPec: errore nell' invio della mail (la mail verr� inviata via batch) "
									+ thr.getMessage(), thr);
				}

		} catch (Exception e) {
			log.fatal("UtenteCandidaturaHome inviaNuovaPec failed", e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"UtenteCandidaturaHome - inviaNuovaPec failed",
					e);
			throw eccezione;
		} finally {
			session.close();
		}
	}

	public void confermaCandidatura(UtenteCandidatura utenteCandidatura,
			MailBean mailBean) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");

		try {
			GestoreMail gestoreMail = new GestoreMail();
			int indiceMail;
			java.sql.Connection conn = session.connection();

			session.saveOrUpdate(utenteCandidatura);

			// SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
			indiceMail = gestoreMail.saveMail(mailBean,
					StaticDefinitions.MAIL_PROPERTIES, conn);

			trx.commit();
			log.info("Salvataggio richiesta e mail avvenuto con successo per la candidatura:"
					+ utenteCandidatura.getCandidatura().getIdCandidatura());

			try {
				gestoreMail.sendMail(indiceMail,
						StaticDefinitions.MAIL_PROPERTIES, conn);
			} catch (Throwable thr) {
				log.error(
						"UtenteCandidaturaHome - confermaCandidatura: errore nell' invio della mail (la mail verr� inviata via batch) "
								+ thr.getMessage(), thr);
			}

		} catch (Exception e) {
			log.fatal("UtenteCandidaturaHome confermaCandidatura failed", e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"UtenteCandidaturaHome - confermaCandidatura: errore nella conferma della candidatuira",
					e);
			throw eccezione;
		} finally {
			session.close();
		}
	}
	
	public void confermaNuovaPec(String idUtente,
			MailBean mailBean) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");

		try {
			GestoreMail gestoreMail = new GestoreMail();
			int indiceMail;
			java.sql.Connection conn = session.connection();
			
			java.util.Date dataOggi = new Date(System.currentTimeMillis());
		    java.sql.Date dataOggisql = new  java.sql.Date(dataOggi.getTime());
		        
			UtenteHome utHome = new UtenteHome();
			Utente utente = utHome.findById(idUtente);
			String newPEC = utente.getNewPecMail();
			utente.setPecMail(newPEC);
			utente.setNewPecMail("");
			utente.setRichiestaCambioPecMailDate(dataOggisql);
			utente.setRichiestaCambioPecMail("A");
			utente.setPecCambiata("Y");
			
			// update su tabella UTENTE
			utHome.saveOrUpdate(utente, session);
			
			//update su tabella UTENTE_REG
			UtenteRegHome utregHome = new UtenteRegHome();
			utregHome.updatePec(idUtente, newPEC, session);
			trx.commit();

		} catch (Exception e) {
			log.fatal("UtenteCandidaturaHome confermaNuovaPec failed", e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"UtenteCandidaturaHome - confermaNuovaPec: errore nella conferma della nuova PEC",
					e);
			throw eccezione;
		} finally {
			session.close();
		}
	}
	
	public void annullaNuovaPec(String idUtente/*,
			MailBean mailBean*/) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");

		try {
//			GestoreMail gestoreMail = new GestoreMail();
//			int indiceMail;
//			java.sql.Connection conn = session.connection();
		
			UtenteHome utHome = new UtenteHome();
			Utente utente = utHome.findById(idUtente);
//			utente.setNewPecMail("");
			utente.setRichiestaCambioPecMail("");
//			utente.setRichiestaCambioPecMailDate(null);
			utHome.saveOrUpdate(utente);

			// SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
//			indiceMail = gestoreMail.saveMail(mailBean,
//					StaticDefinitions.MAIL_PROPERTIES, conn);

			trx.commit();
			log.info("Rifiuto nuova pec avvenuto con successo");

//			try {
//				gestoreMail.sendMail(indiceMail,
//						StaticDefinitions.MAIL_PROPERTIES, conn);
//				
//				
//			} catch (Throwable thr) {
//				log.error(
//						"UtenteCandidaturaHome - annullaNuovaPec: errore nell' invio della mail (la mail verr� inviata via batch) "
//								+ thr.getMessage(), thr);
//			}

		} catch (Exception e) {
			log.fatal("UtenteCandidaturaHome annullaNuovaPec failed", e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"UtenteCandidaturaHome - annullaNuovaPec: errore nell' annullamento della nuova PEC",
					e);
			throw eccezione;
		} finally {
			session.close();
		}
	}

	public List findByQuery(String query) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		log.debug("finding Utente instance by example");
		// query =
		// "select u from UtenteCandidatura u where u.codiceFiscaleUtente = 'AAA2' and (u.candidatura.statoRegistrazione ='I' or u.candidatura.statoRegistrazione ='C')";
		/*
		 * "select c,d from Content c,Category d where c.categoryId=d.categoryId and c.contentId in ("
		 * + queryIds +
		 * ") and c.contractEnd > SYSDATE and c.contractStart <= SYSDATE "+
		 * " and exists (select cf from ContentPlatform cf where cf.compId.contentId=c.contentId and cf.compId.platform='"
		 * +channel+"' and cf.isPublished='Y')").list();
		 */
		try {
			List<UtenteCandidatura> returnObj = session.createQuery(query).list();
			log.debug("find by example successful, result size: "+ returnObj.size());
			return returnObj;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			LogUtil.printException(re);
			GestioneErroriException eccezione = new GestioneErroriException("UtenteCandidaturaHome - findByExample: errore nella findByExample di UtenteCandidatura");
			LogUtil.printException(eccezione);
			throw eccezione;
		} finally {
			session.close();
		}
	}

}
