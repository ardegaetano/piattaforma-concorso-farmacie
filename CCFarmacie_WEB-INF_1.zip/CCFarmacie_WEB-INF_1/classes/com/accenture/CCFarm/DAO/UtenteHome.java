package com.accenture.CCFarm.DAO;

// Generated Jul 25, 2012 10:18:12 AM by Hibernate Tools 3.4.0.CR1

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AESCryptoLongUtil;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.PrintException;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.StaticDefinitions;
import com.accenture.mailer.concorsofarma.GestoreMail;
import com.accenture.mailer.concorsofarma.data.MailBean;

/**
 * Home object for domain model class Utente.
 * @see com.accenture.CCFarm.DAO.Utente
 * @author Hibernate Tools
 */
public class UtenteHome {

	
//	private static final Log log = LogFactory.getLog(UtenteHome.class);
	private static final Logger log = CommonLogger.getLogger("UtenteHome");

	public void persist(Utente transientInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("persisting Utente instance");
		try {
			session.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw new GestioneErroriException("UtenteHome - persist: errore persist");
		}
		finally{
			session.close();
		}
	}

	public void saveOrUpdate(Utente instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");
		try {
			session.saveOrUpdate(instance);
			trx.commit();
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("UtenteHome - saveOrUpdate: errore saveOrUpdate");
		}
		finally{
			session.close();
		}
	}
	
	public void saveOrUpdate(Utente instance, Session session) throws GestioneErroriException{
		
		log.debug("attaching dirty Utente instance");
		try {
			session.saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("UtenteHome - saveOrUpdate: errore saveOrUpdate");
		}
		
	}

	public void attachClean(Utente instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("attaching clean Utente instance");
		try {
			session.lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw new GestioneErroriException("UtenteHome - attachClean: errore attachClean");
		}
		finally{
			session.close();
		}
	}

	public void delete(Utente persistentInstance) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("deleting Utente instance");
		try {
			session.delete(persistentInstance);
			trx.commit();
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw new GestioneErroriException("UtenteHome - delete: errore delete");
		}
		finally{
			session.close();
		}
	}

	public Utente merge(Utente detachedInstance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("merging Utente instance");
		try {
			Utente result = (Utente) session.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw new GestioneErroriException("UtenteHome - merge: errore merge");
		}
		finally{
			session.close();
		}
	}

	public Utente findById(java.lang.String id) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("getting Utente instance with id: " + id);
		try {
			Utente instance = (Utente) session.get("com.accenture.CCFarm.DAO.Utente", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw new GestioneErroriException("UtenteHome - findById: errore findById");
		}
		finally{
			session.close();
		}
	}

	public List findByExample(Utente instance) throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		log.debug("finding Utente instance by example");
		try {
			List results = session
					.createCriteria("com.accenture.CCFarm.DAO.Utente")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw new GestioneErroriException("UtenteHome - findByExample: errore findByExample");
		}
		finally{
			session.close();
		}
	}
	
	public String getSequenceIdUtente() throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_UTENTE.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("getSequenceIdUtente() - UtenteHome getSequenceIdSede failed : "+ PrintException.stack2string(re));
			throw new GestioneErroriException("UtenteHome - getSequenceIdUtente: errore getSequenceIdUtente");
		}
		finally{
			session.close();
		}
	}
	
	public String getSequenceIdDomanda() throws GestioneErroriException{
		Session session = HibernateUtil.openSession();
		try {
			List query =  session.createSQLQuery("SELECT ID_DOMANDA.nextval as id FROM dual").list();
			BigDecimal num = (BigDecimal)query.get(0);
			
			return ""+num;
		} catch (RuntimeException re) {
			log.error("getSequenceIdDomanda() - AnagraficaFarmHome getSequenceIdDomanda failed : "+ PrintException.stack2string(re));
			throw re;
		}
		finally{
			session.close();
		}
	}
	
	
	
	
    public void invioMailRichModificaPec(Utente utente,String aesKey) throws GestioneErroriException {
    	
    	
        Session session = HibernateUtil.openSession();        
        java.util.Date dataSys= new java.util.Date();
        boolean ok = true;        
  
	        try {
	                      	
	               //Dichiaro quanto serve per creare ed inviare la mail
	               GestoreMail gestoreMail = new GestoreMail();
	               MailBean mailBean = new MailBean() ;
	               int[] indiciMail = new int[1];
	               java.sql.Connection conn = session.connection();
	               
	               //Creo la mail
	               mailBean.setCorpoMail(getCorpoMailNewPec(utente,aesKey));
	               
	               HttpSession session1=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	           		String lingua= (String)session1.getAttribute("linguaScelta");
	           	
	               if(lingua.equals("de")){
	            	   
	            	   mailBean.setOggettoMail("Autonome Provinz Bozen - Antrag auf �nderung der zertifizierten E-Mailadresse f�r den Bewerber " + utente.getCognomeUtente() +" "+ utente.getNomeUtente());
	               }
	               else{
	               String regioneProv =  com.accenture.CCFarm.utility.Localita.getDenominazioneRegione(utente.getCodRegUtente().toLowerCase());
	         	   regioneProv = "Regione " + regioneProv.substring(0,1).toUpperCase() + regioneProv.substring(1);
	         	   
	               if(utente.getCodRegUtente().equals("041")){
	     			  regioneProv =" Provincia autonoma di Bolzano";
	     		   }
	               if(utente.getCodRegUtente().equals("042")){
	     			  regioneProv =" Provincia autonoma di Trento";
	     		   }
	//               mailBean.setOggettoMail("Comunicazione dell�avvenuta pubblicazione della graduatoria per la " + regioneProv + "-" + utenteMailVO.getCognome() + " " + utenteMailVO.getNome());
	               mailBean.setOggettoMail(regioneProv + " - Richiesta di modifica dell'indirizzo di posta elettronica certificata per il candidato " + utente.getCognomeUtente() +" "+ utente.getNomeUtente());
	               }
	               ArrayList listaDest = new ArrayList<String>();
	               
	               // invio una mail unica (al nuovo indirizzo)
	               //listaDest.add(utente.getPecMail());
	               listaDest.add(utente.getNewPecMail());
	               mailBean.setToAddresses(listaDest);
	        
	               
	               
	             //SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail 
	               indiciMail[0] = gestoreMail.saveMail(mailBean, StaticDefinitions.getMailProperties(), conn);
	               
	               
	               //Provo ad inviare la mail 
		               try {
		            	     
		                      gestoreMail.sendMail(indiciMail[0],     StaticDefinitions.getMailProperties(), conn);
		               } catch (Throwable thr) {
		                      log.error(   "UtenteHome - invioMailRichModificaMailPEC : errore nell' invio della mail " + thr.getMessage(), thr);
		               }
	               
	        } catch (Exception e) {
               log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE" + LogUtil.printException(e));
               throw new GestioneErroriException("UtenteCandidaturaRegHome - invioMailPubblicazione: errore nell' invio della mail (la mail verr� inviata via batch");
        }
        
        finally {
               session.close();
        }            
  
  }
	
    
    
public String getCorpoMailNewPec(Utente utente,String aesKey){ 
		
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	String lingua= (String)session.getAttribute("linguaScelta");
		String utenza= utente.getIdUtente()+"$"+utente.getNewPecMail();
		String token = AESCryptoLongUtil.encrypt(utenza,aesKey,128);
		String gentileCliente = null;
	
		if((utente.getSesso()).equalsIgnoreCase("M")){
		
			gentileCliente = JSFUtility.getPropertyMessage("utente.gentile.maschio", lingua) +utente.getNomeUtente()+" "+utente.getCognomeUtente()+" ";
		
		}else {
		
			gentileCliente = JSFUtility.getPropertyMessage("utente.gentile.femmina", lingua) +utente.getNomeUtente()+" "+utente.getCognomeUtente()+" ";
	 
		}

		String line1 =JSFUtility.getPropertyMessage("utente.modifica.pec", lingua) +Localita.getDenominazioneRegione(utente.getCodRegUtente())+ JSFUtility.getPropertyMessage("utente.acquisita", lingua);
		String line2 =JSFUtility.getPropertyMessage("utente.nuovo.indirizzo", lingua);
		String attivazione =JSFUtility.getPropertyMessage("utente.attivare.link", lingua);
		String linkAtt =" <a href= \"" +AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") + "/ConfermaRegistrazioneNuovaPec?token="  + token +"&action=attiva&lingua="+lingua+"\"/>" + AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") +"/ConfermaRegistrazioneNuovaPec?token=" + token +"&action=attiva&lingua="+lingua+"</a>";	 
		
		String click =JSFUtility.getPropertyMessage("utente.copiare.lnk", lingua);
		//String rifiuto =JSFUtility.getPropertyMessage("utente.non.richiesto.cambio", lingua);
		//String linkRifiuto =" <a href= \"" +AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") + "/ConfermaRegistrazioneNuovaPec?token="  + token +"&action=annulla&lingua="+lingua+"\"/>" + AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") +"/ConfermaRegistrazioneNuovaPec?token=" + token +"&action=annulla&lingua="+lingua+"</a>";		
		
		String attenzione = JSFUtility.getPropertyMessage("utente.attenzione.gestita", lingua);
	    String corpoMail = "<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+line1+"\r\n<br/>\r\n<br/>"+line2+"\r\n<br/>\r\n<br/>"+utente.getNewPecMail()+"\r\n<br/>\r\n<br/>"+attivazione+"\r\n<br/>\r\n<br/>"+linkAtt+"\r\n<br/>\r\n<br/>"+click+"\r\n<br/>\r\n<br/>"+
		
				// tolto link rifiuto
				//rifiuto+"\r\n<br/>\r\n<br/>"+linkRifiuto+"\r\n<br/>\r\n<br/>"+
				attenzione+"</htlml>";
	    System.out.println(corpoMail);
	    return corpoMail;
	}
    
    
    //Non cancellare
    

 /*   private String getCorpoMailUno(Utente utente){ 
  	  
  	  String regioneProv =  com.accenture.CCFarm.utility.Localita.getDenominazioneRegione(utente.getCodRegUtente()).toLowerCase();
  	  regioneProv = regioneProv.substring(0,1).toUpperCase() + regioneProv.substring(1);
  	  
  	  String testoMail;
  	  String testoFisso; 	 
  		 
  	  if(!utente.getCodRegUtente().equals("041") && !utente.getCodRegUtente().equals("042")){
  	  
  		   testoMail = "Gentile Dott/ssa "+utente.getNomeUtente()+" "+utente.getCognomeUtente()+", \r\n<br/>" +
  	      		" abbiamo ricevuto la sua richiesta di modifica dell'indirizzo di posta elettronica certificata (PEC);" +
  	      		" a seguito di controlli da parte del sistema riguardo la correttezza e la validita' dell'indirizzo PEC" +
  	      		" inserito, ricever� un'ulteriore email per confermare il cambio di PEC; solo a seguito di conferma" +
  	      		" il nuovo indirizzo PEC andr� a sostituire il vecchio indirizzo e sar� utilizzato per qualsiasi successiva" +
  	      		" comunicazione. Potr� seguire tutte le fasi successive all'inoltro della richiesta di modifica "+
  	      		" dell'indirizzo PEC, accedendo con le proprie credenziali alla piattaforma."+
	  	      	"<br/>I messaggi visualizzati saranno:"+			
	  	        "<br/>1) 'Richiesta CAMBIO Pec presa in carico';"+
	  	      	"<br/><b>in caso di esito positivo:</b>"+		
				"<br/>2) 'Accedi alla nuova casella pec per concludere il cambio pec';"+
				"<br/>3) 'Il cambio PEC � stato confermato';"+
				"<br/><b>in caso di inserimento di un indirizzo non corretto o non ancora attivo:</b>"+
				"<br/>2) 'L'indirizzo PEC indicato non � corretto o non � attivo";
  		   
  		// la richiesta di cambio PEC presentata da Mario Rossi in data xx/xx/xxxx � stata presa in carico dal sistema in data xx/xx/xxxx
  		   
  		   
  		   
  		   testoFisso = " .";
  	  
  	  }else{
  		  if(!utente.getCodRegUtente().equals("041")){
  			  regioneProv =" Provincia autonoma di Bolzano";
  		  }else{
  			  regioneProv =" Provincia autonoma di Trento";
  		  }
  		  testoMail = "Gentile Dott/ssa "+utente.getNomeUtente()+" "+utente.getCognomeUtente()+", \r\n<br/>" +
  				" abbiamo ricevuto la sua richiesta di modifica dell'indirizzo di posta elettronica certificata (PEC);" +
  	      		" a seguito di controlli da parte del sistema riguardo la correttezza e la validita' dell'indirizzo di " +
  	      		" posta inserito, ricever� un'ulteriore email per confermare il cambio di PEC; solo a seguito di conferma" +
  	      		" il nuovo indirizzo di posta andr� a sostituire il vecchio indirizzo e sar� utilizzato per qualsiasi successiva" +
  	      		" comunicazione. Il candidato potr� seguire tutte le fasi successive all'inoltro della richiesta di modifica "+
  	      		" dell'indirizzo PEC, accedendo con le proprie credenziali alla piattaforma."+
	  	      	"<br/>I messaggi visualizzati saranno:"+			
	  	        "<br/>1) 'Richiesta CAMBIO Pec presa in carico';"+
	  	      	"<br/><b>in caso di esito positivo:</b>"+		
				"<br/>2) 'Accedi alla nuova casella pec per concludere il cambio pec';"+
				"<br/>3) 'Il cambio PEC � stato confermato';"+
				"<br/><b>in caso di inserimento di un indirizzo non corretto o non ancora attivo:</b>"+
				"<br/>2) 'L'indirizzo PEC indicato non � corretto o non � attivo";
  		   testoFisso = " .";
  	    }
        
        
  	  
  		String mail = "<html>"+testoMail +"\r\n<br/>\r\n<br/>"+testoFisso+"</htlml>";

  	  
         
          return mail;    
          
    }
    */
    
	public void confermaNuovaPec(String idUtente,
			MailBean mailBean) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");

		try {
			GestoreMail gestoreMail = new GestoreMail();
			int indiceMail;
			java.sql.Connection conn = session.connection();
			
//			StoricoPecMailHome storicoPecH = new StoricoPecMailHome ();
//			StoricoPecMail storicoPecM = new StoricoPecMail ();
//			storicoPecM.setIdUtente(idUtente);
//			List<StoricoPecMail> listPecMail = new ArrayList<StoricoPecMail>();
//			StoricoPecMailId storicoPecMId = new StoricoPecMailId ();
//			listPecMail = storicoPecH.findByExample(storicoPecM);
//			java.util.Date sysdate= new java.util.Date();
//			storicoPecM = listPecMail.get(listPecMail.size()-1);
//			storicoPecM.setDataOperazione(sysdate);
//			storicoPecM.setStatoAttivazione("T");
//			storicoPecMId.setIdUtente(idUtente);
//			storicoPecMId.setProgressivo(storicoPecM.getProgressivo());
//			storicoPecM.setIdKey(storicoPecMId);
			
			UtenteHome utHome = new UtenteHome();
			Utente utente = utHome.findById(idUtente);
			utente.setPecMail(utente.getNewPecMail());
			utente.setNewPecMail("");
			utente.setRichiestaCambioPecMail("");
			
			// update su tabella UTENTE
			utHome.saveOrUpdate(utente);
			
			// update su tabella STORICO_PEC_MAIL
//			storicoPecH.saveOrUpdate(storicoPecM);
			
			

			// SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
			indiceMail = gestoreMail.saveMail(mailBean,
					StaticDefinitions.MAIL_PROPERTIES, conn);

			trx.commit();
			log.info("Salvataggio nuova pec e invio mail attivazione avvenuto con successo");

			try {
				gestoreMail.sendMail(indiceMail,
						StaticDefinitions.MAIL_PROPERTIES, conn);
				
				
			} catch (Throwable thr) {
				log.error(
						"UtenteCandidaturaHome - confermaNuovaPec: errore nell' invio della mail (la mail verr� inviata via batch) "
								+ thr.getMessage(), thr);
			}

		} catch (Exception e) {
			log.fatal("UtenteCandidaturaHome confermaNuovaPec failed", e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"UtenteCandidaturaHome - confermaNuovaPec: errore nella conferma della nuova PEC",
					e);
			throw eccezione;
		} finally {
			session.close();
		}
	}
	
	public void annullaNuovaPec(String idUtente,
			MailBean mailBean) throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		log.debug("attaching dirty Utente instance");

		try {
			GestoreMail gestoreMail = new GestoreMail();
			int indiceMail;
			java.sql.Connection conn = session.connection();
			
			// update su tabella STORICO_PEC_MAIL
//			StoricoPecMailHome storicoPecH = new StoricoPecMailHome ();
//			StoricoPecMail storicoPecM = new StoricoPecMail ();
//			storicoPecM.setIdUtente(idUtente);
//			List<StoricoPecMail> listPecMail = new ArrayList<StoricoPecMail>();
//			StoricoPecMailId storicoPecMId = new StoricoPecMailId ();
//			listPecMail = storicoPecH.findByExample(storicoPecM);
//			java.util.Date sysdate= new java.util.Date();
//			storicoPecM = listPecMail.get(listPecMail.size()-1);
//			storicoPecM.setDataOperazione(sysdate);
//			storicoPecM.setStatoAttivazione("A");
//			storicoPecMId.setIdUtente(idUtente);
//			storicoPecMId.setProgressivo(storicoPecM.getProgressivo());
//			storicoPecM.setIdKey(storicoPecMId);			
//			storicoPecH.saveOrUpdate(storicoPecM);
			
			UtenteHome utHome = new UtenteHome();
			Utente utente = utHome.findById(idUtente);
			//utente.setPecMail(utente.getNewPecMail());
			utente.setNewPecMail("");
			utente.setRichiestaCambioPecMail("");

			// SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
			indiceMail = gestoreMail.saveMail(mailBean,
					StaticDefinitions.MAIL_PROPERTIES, conn);

			trx.commit();
			log.info("Salvataggio nuova pec e invio mail attivazione avvenuto con successo");

			try {
				gestoreMail.sendMail(indiceMail,
						StaticDefinitions.MAIL_PROPERTIES, conn);
				
				
			} catch (Throwable thr) {
				log.error(
						"UtenteCandidaturaHome - annullaNuovaPec: errore nell' invio della mail (la mail verr� inviata via batch) "
								+ thr.getMessage(), thr);
			}

		} catch (Exception e) {
			log.fatal("UtenteCandidaturaHome annullaNuovaPec failed", e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"UtenteCandidaturaHome - annullaNuovaPec: errore nell' annullamento della nuova PEC",
					e);
			throw eccezione;
		} finally {
			session.close();
		}
	}
    
    
    
//    
//    public void invioMailDue(Utente utente) throws GestioneErroriException {
//        Session session = HibernateUtil.openSession();
////        Transaction trx = session.beginTransaction();
////        CCFarmLogger.log("saveOrUpdate Candidatura instance", Level.INFO_INT, CandidaturaHome.class);
//        java.util.Date dataSys= new java.util.Date();
//        boolean ok = true;
//        
//  
//        try {
//        	
//               //Dichiaro quanto serve per creare ed inviare la mail
//               GestoreMail gestoreMail = new GestoreMail();
//               MailBean mailBean = new MailBean() ;
//               int[] indiciMail = new int[1];
//               java.sql.Connection conn = session.connection();
//               
//               //Creo la mail
//               mailBean.setCorpoMail(getCorpoMailUno(utente));
//               
//               String regioneProv =  com.accenture.CCFarm.utility.Localita.getDenominazioneRegione(utente.getCodRegUtente()).toLowerCase();
//         	   regioneProv = "regione " + regioneProv.substring(0,1).toUpperCase() + regioneProv.substring(1);
//         	   
//               if(utente.getCodRegUtente().equals("041")){
//     			  regioneProv =" Provincia autonoma di Bolzano";
//     		   }
//               if(utente.getCodRegUtente().equals("042")){
//     			  regioneProv =" Provincia autonoma di Trento";
//     		   }
////               mailBean.setOggettoMail("Comunicazione dell�avvenuta pubblicazione della graduatoria per la " + regioneProv + "-" + utenteMailVO.getCognome() + " " + utenteMailVO.getNome());
//               mailBean.setOggettoMail("Comunicazione dell�avvenuta pubblicazione della graduatoria per la " + regioneProv );
//               
//               ArrayList listaDest = new ArrayList<String>();
//               listaDest.add(utente.getPecMail());
//               mailBean.setToAddresses(listaDest);
//        
//               
//               
//             //SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail 
//               indiciMail[0] = gestoreMail.saveMail(mailBean, StaticDefinitions.getMailProperties(), conn);
//               
//               
//               //Provo ad inviare la mail 
//               try {
//            	     
//                      gestoreMail.sendMail(indiciMail[0],     StaticDefinitions.getMailProperties(), conn);
//               } catch (Throwable thr) {
//                      log.error(   "UtenteCandidaturaRegHome - invioMailPubblicazione : errore nell' invio della mail (la mail verr� inviata via batch) " + thr.getMessage(), thr);
//               }
//               
////               CCFarmLogger.log("Salvataggio avvenuto con successo per la candidatura: idUtente"+ utenteCandidatura.getIdUtente(), Level.INFO_INT, CandidaturaHome.class);
//               
//        } catch (Exception e) {
//               log.error("Errore Lettura ID_CANDIDATURA.. da ID_UTENTE" + LogUtil.printException(e));
//               throw new GestioneErroriException("UtenteCandidaturaRegHome - invioMailPubblicazione: errore nell' invio della mail (la mail verr� inviata via batch");
//        }
//        
//        finally {
//               session.close();
//        }            
//  
//  }
//	
//
//    private String getCorpoMailDue(Utente utente){ 
//  	  
////  	  DatiBandoHome datiBandoHome = new DatiBandoHome();
////  	  DatiBando datiBando ;
////  	  String dataChiusuraBando = "";
////  	  try{
////  		  datiBando = datiBandoHome.findById(utenteMailVO.getIdRegione());
////  		 
////  		  dataChiusuraBando = " (ore 18:00 del " +  StringUtil.dateToStringDDMMYYYY(datiBando.getDataFineBando()) +   "),";
////  	   }catch(Exception e){
////  		   log.error("Errore nel recupero del bando regionale per l'utente con id = "+utenteMailVO.getIdRegione() + LogUtil.printException(e));
////  	   }
////          
//  	  
//  	  String regioneProv =  com.accenture.CCFarm.utility.Localita.getDenominazioneRegione(utente.getCodRegUtente()).toLowerCase();
//  	  regioneProv = regioneProv.substring(0,1).toUpperCase() + regioneProv.substring(1);
//  	  
//  	  String testoMail;
//  	  String testoFisso; 	 
//  		 
//  	  if(!utente.getCodRegUtente().equals("041") && !utente.getCodRegUtente().equals("042")){
//  	  
//  		   testoMail = "Gentile Dott/ssa "+utente.getNomeUtente()+" "+utente.getCognomeUtente()+", \r\n<br/>" +
//  	      		" le comunichiamo che la Commissione della " + regioneProv +
//  	      		" in data  ha pubblicato la graduatoria del concorso farmacie"+". \r\n<br/>" +
//  	      		" � possibile consultare l�atto amministrativo e la graduatoria sulla home Page del concorso farmacia .";
//  		   testoFisso = " .";
//  	  
//  	  }else{
//  		  if(!utente.getCodRegUtente().equals("041")){
//  			  regioneProv =" Provincia autonoma di Bolzano";
//  		  }else{
//  			  regioneProv =" Provincia autonoma di Trento";
//  		  }
//  		  testoMail = "Gentile Dott/ssa "+utente.getNomeUtente()+" "+utente.getCognomeUtente()+", \r\n<br/>" +
//  	      		" le comunichiamo che la Commissione della " + regioneProv +
//  	      		" in data ha pubblicato la graduatoria del concorso farmacie"+". \r\n<br/>" +
//  	      		" � possibile consultare l�atto amministrativo e la graduatoria sulla home Page del concorso farmacia .";
//  		   testoFisso = " .";
//  	    }
//        
//        
//  	  
//  		String mail = "<html>"+testoMail +"\r\n<br/>\r\n<br/>"+testoFisso+"</htlml>";
//
//  	  
//         
//          return mail;    
//          
//    }
//
//	
	
 
	
}
