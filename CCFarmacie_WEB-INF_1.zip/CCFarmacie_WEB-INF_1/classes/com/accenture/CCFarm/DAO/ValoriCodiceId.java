package com.accenture.CCFarm.DAO;

public class ValoriCodiceId implements java.io.Serializable {

	private String codice;	
	private String tipoCodice;
	
	
	public String getCodice() {
		return codice;
	}
	public void setCodice(String codice) {
		this.codice = codice;
	}
	public String getTipoCodice() {
		return tipoCodice;
	}
	public void setTipoCodice(String tipoCodice) {
		this.tipoCodice = tipoCodice;
	}

}
