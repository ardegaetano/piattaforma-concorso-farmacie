package com.accenture.CCFarm.DAO;

//import java.io.*;
//import java.lang.reflect.*;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class RicercaFarmacie
{	
	private List<String> regioni;
	private List<String> province;
	private List<String> comuni;
	private String indirizzo="";
	
	
	public List<String> getRegioni() {
		return regioni;
	}
	public void setRegioni(List<String> regioni) {
		this.regioni = regioni;
	}
	public List<String> getProvince() {
		return province;
	}
	public void setProvince(List<String> province) {
		this.province = province;
	}
	public List<String> getComuni() {
		return comuni;
	}
	public void setComuni(List<String> comuni) {
		this.comuni = comuni;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	


}