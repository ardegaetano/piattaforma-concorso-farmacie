package com.accenture.CCFarm.DAO;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.HibernateUtil;

public class CandidaturaSediHome {

	private static final Logger logger = CommonLogger.getLogger("CandidaturaSediHome");
	
	private static final String flagValoreFalso = AppProperties.getAppProperty("flag.valore.falso");
	private static final String flagValoreVero = AppProperties.getAppProperty("flag.valore.vero");
	
	//salvataggio elenco preferenze sedi
	public void salva(String idCandidatura, List<CandidaturaSedi> candidaturaSediList) throws GestioneErroriException {
		
		Session session = null;
		Transaction trx = null;
		
		try {
			
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			
			salvaPreferenze(session, idCandidatura, candidaturaSediList);
			
			trx.commit();
		}
		catch(Exception e) {
			
			if(trx != null)
				trx.rollback();
			
			logger.error("CandidaturaSediHome - salvataggio fallito", e);
			throw new GestioneErroriException("CandidaturaSediHome - salvataggio fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	//salvataggio elenco preferenze sedi
	public void salvaPreferenze(Session session, String idCandidatura, List<CandidaturaSedi> candidaturaSediList) throws GestioneErroriException {
		
		try {
			
			//cancellazione preferenze precedenti
			String hqlDeleteString = "DELETE CandidaturaSedi cs WHERE cs.id.idCandidatura = :idCandidatura";
			Query deleteQuery = session.createQuery(hqlDeleteString);
			deleteQuery.setParameter("idCandidatura", idCandidatura);
			deleteQuery.executeUpdate();
			
			//salvataggio preferenze correnti
			for(CandidaturaSedi candidaturaSedi : candidaturaSediList) {
				
				session.saveOrUpdate(candidaturaSedi);
			}
		}
		catch(Exception e) {
			
			logger.error("CandidaturaSediHome - salvataggio preferenze sedi selezionate fallito", e);
			throw new GestioneErroriException("CandidaturaSediHome - salvataggio preferenze sedi selezionate fallito");
		}
	}
	
	//determina se per la candidatura specificata � stata gi� confermata una sede
	public String determinaSceltaConfermata(String idCandidatura) throws GestioneErroriException {
		
		Session session = null;
		
		try {
			
			session = HibernateUtil.openSession();
			
			Criteria criteria = session.createCriteria(CandidaturaSedi.class);
			//condizioni
			//id candidatura
			criteria.add(Restrictions.eq("id.idCandidatura", idCandidatura));
			//flag "associata" a true
			criteria.add(Restrictions.eq("flagAssociata", flagValoreVero));
			
			//proiezioni
			ProjectionList projectionList = Projections.projectionList();
			projectionList = projectionList.add(Projections.property("flagConfermata"), "flagConfermata");
			criteria = criteria.setProjection(projectionList);
			
			return (String) criteria.uniqueResult();
		}
		catch(Exception e) {
			
			logger.error("CandidaturaSediHome - ricerca scelta confermata fallita", e);
			throw new GestioneErroriException("CandidaturaSediHome - ricerca scelta confermata fallita");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
	
	public void salvaSceltaSede(String idCandidatura, boolean sedeAccettata) throws GestioneErroriException {
		
		Session session = null;
		Transaction trx = null;
		
		try {
			
			session = HibernateUtil.openSession();
			trx = session.beginTransaction();
			
			String hqlUpdateString = "UPDATE CandidaturaSedi cs SET cs.flagConfermata = :flagConfermata"
								   + " WHERE cs.id.idCandidatura = :idCandidatura"
								     + " AND cs.flagAssociata = :flagAssociata";
			
			Query updateQuery = session.createQuery(hqlUpdateString);
			
			updateQuery.setParameter("flagConfermata", (!sedeAccettata) ? flagValoreFalso
																		:
																		  flagValoreVero);
			updateQuery.setParameter("idCandidatura", idCandidatura);
			updateQuery.setParameter("flagAssociata", flagValoreVero);
			
			updateQuery.executeUpdate();
			
			trx.commit();
		}
		catch(Exception e) {
			
			if(trx != null)
				trx.rollback();
			
			logger.error("CandidaturaSediHome - salvataggio decisione fallito", e);
			throw new GestioneErroriException("CandidaturaSediHome - salvataggio decisione fallito");
		}
		finally {
			
			if(session != null)
				session.close();
		}
	}
}
