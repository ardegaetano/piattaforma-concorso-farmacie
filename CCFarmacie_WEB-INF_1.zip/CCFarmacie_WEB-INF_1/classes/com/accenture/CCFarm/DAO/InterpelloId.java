package com.accenture.CCFarm.DAO;

import java.math.BigDecimal;


public class InterpelloId implements java.io.Serializable {

	private BigDecimal idInterpello;
	private String codReg;
	
	public InterpelloId() {
		
	}

	public InterpelloId(BigDecimal idInterpello, String codReg) {
		
		this.idInterpello = idInterpello;
		this.codReg = codReg;
	}

	public BigDecimal getIdInterpello() {
		return idInterpello;
	}

	public void setIdInterpello(BigDecimal idInterpello) {
		this.idInterpello = idInterpello;
	}

	public String getCodReg() {
		return codReg;
	}

	public void setCodReg(String codReg) {
		this.codReg = codReg;
	}
	
}
