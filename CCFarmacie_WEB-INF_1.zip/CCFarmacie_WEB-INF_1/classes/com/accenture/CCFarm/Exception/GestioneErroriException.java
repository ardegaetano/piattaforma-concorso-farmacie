package com.accenture.CCFarm.Exception;



public class GestioneErroriException extends Exception
{

    public GestioneErroriException()
    {
	super();
    }

    public GestioneErroriException(String message, Throwable cause)
    {
	super(message, cause);
    }

    public GestioneErroriException(String message)
    {
	super(message);
    }

    public GestioneErroriException(Throwable cause)
    {
	super(cause);
    }

}
