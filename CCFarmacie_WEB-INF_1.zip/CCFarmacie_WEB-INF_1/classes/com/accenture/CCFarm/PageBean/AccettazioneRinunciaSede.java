package com.accenture.CCFarm.PageBean;

import java.sql.Timestamp;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.AnagraficaFarm;
import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.AccettazioneRinunciaSedeAction;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.StringUtil;

@ManagedBean(name = "accettazioneRinunciaSede", eager = true)
@ViewScoped
public class AccettazioneRinunciaSede {
	
	private Logger logger = CommonLogger.getLogger("AccettazioneRinunciaSede");
	private static final String pageError = "errorPageGenerica.jsf";
	
	private AccettazioneRinunciaSedeAction accettazioneRinunciaSedeAction;
	
	private String linguaScelta;
	
	private String idRegione;
	
	private Utente utente;
	
	private Candidatura candidatura;
	
	private String numeroProtocolloDomanda;
	
	private Interpello interpello;
	
	private String dataFineAccettazioneString;
	
	private AnagraficaFarm sedeAssegnata;
	
	private String opzioneSelezionata;// "A" sede accettata - "R" sede rinunciata
	
	private boolean sceltaEffettuata;// "false" decisione non ancora confermata - "true" decisione confermata
	
	private String avvisoFaseNonAttiva;
	
	private String avvisoTermineScaduto;
	
	private String avvisoInvioAvvenuto;
	
	private String dataOdierna;
	
	private String fraseDifferenzaDate;
	
	public AccettazioneRinunciaSede(boolean test) {
		
	}
	
	public AccettazioneRinunciaSede() throws GestioneErroriException {
		
		try {
			
			init();
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSede() - costruzione del bean fallita", e);
			throw new GestioneErroriException("AccettazioneRinunciaSede() - costruzione del bean fallita");
		}
	}
	
	private void init() throws GestioneErroriException {
	
		try {
			
			setLinguaScelta((String) JSFUtility.getFacesContext().getExternalContext().getSessionMap().get("linguaScelta"));
			setAvvisoFaseNonAttiva(StringUtil.getPropertyMessage("accettazioneRinunciaSede.fase.non.attiva", linguaScelta));
			setAvvisoTermineScaduto(StringUtil.getPropertyMessage("accettazioneRinunciaSede.termine.scaduto", linguaScelta));
			setAvvisoInvioAvvenuto(StringUtil.getPropertyMessage("accettazioneRinunciaSede.invio.avvenuto", linguaScelta));
			
			accettazioneRinunciaSedeAction = new AccettazioneRinunciaSedeAction();
			
			accettazioneRinunciaSedeAction.init(this);
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSede - inizializzazione fallita", e);
			throw new GestioneErroriException("AccettazioneRinunciaSede - inizializzazione fallita");
		}
	}

	public void rinunciaSede() {
		
		try {
			
			setOpzioneSelezionata("R");
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSede - scelta di rinuncia fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public boolean isSedeRinunciata() {
		
		return getOpzioneSelezionata() != null && getOpzioneSelezionata().equals("R");
	}
	
	public void accettazioneSede() {
		
		try {
			
			setOpzioneSelezionata("A");
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSede - scelta di accettazione fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public boolean isSedeAccettata() {
		
		return getOpzioneSelezionata() != null && getOpzioneSelezionata().equals("A");
	}
	
	private boolean validaConfermaScelta() {
		
		Timestamp istanteCorrente = DateUtil.getCurrentTimestamp(); 
		
		/* **TEST** anticipa la data inizio di 2 giorni
		Calendar c = Calendar.getInstance();
		c.setTime(new Date(((Timestamp) interpello.getDataInizioAccettazione()).getTime()));
		c.add(Calendar.DATE, -2);
		if(istanteCorrente.before(c.getTime())) {
		*/
		if(istanteCorrente.before((Timestamp) interpello.getDataInizioAccettazione())) {
			
			JSFUtility.addWarningMessage("", getAvvisoFaseNonAttiva());
			return false;
		}
		
		if(istanteCorrente.after((Timestamp) interpello.getDataFineAccettazione())) {
			
			JSFUtility.addWarningMessage("", getAvvisoTermineScaduto());
			return false;
		}
		
		return true;
	}
	
	public void confermaScelta() {
		
		try {
			
			if(validaConfermaScelta()) {
				
				accettazioneRinunciaSedeAction.salvaScelta(this);
				JSFUtility.addInfoMessage("", avvisoInvioAvvenuto, false);
			}
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSede - conferma scelta effettuata fallita", e);
			JSFUtility.redirect(pageError);
		}
	}

	public String getLinguaScelta() {
		return linguaScelta;
	}

	public void setLinguaScelta(String linguaScelta) {
		this.linguaScelta = linguaScelta;
	}

	public String getIdRegione() {
		return idRegione;
	}

	public void setIdRegione(String idRegione) {
		this.idRegione = idRegione;
	}

	public Utente getUtente() {
		return utente;
	}

	public void setUtente(Utente utente) {
		this.utente = utente;
	}

	public Candidatura getCandidatura() {
		return candidatura;
	}

	public void setCandidatura(Candidatura candidatura) {
		this.candidatura = candidatura;
	}

	public String getNumeroProtocolloDomanda() {
		return numeroProtocolloDomanda;
	}

	public void setNumeroProtocolloDomanda(String numeroProtocolloDomanda) {
		this.numeroProtocolloDomanda = numeroProtocolloDomanda;
	}

	public Interpello getInterpello() {
		return interpello;
	}

	public void setInterpello(Interpello interpello) {
		this.interpello = interpello;
	}

	public String getDataFineAccettazioneString() {
		return dataFineAccettazioneString;
	}

	public void setDataFineAccettazioneString(String dataFineAccettazioneString) {
		this.dataFineAccettazioneString = dataFineAccettazioneString;
	}

	public AnagraficaFarm getSedeAssegnata() {
		return sedeAssegnata;
	}

	public void setSedeAssegnata(AnagraficaFarm sedeAssegnata) {
		this.sedeAssegnata = sedeAssegnata;
	}

	public String getOpzioneSelezionata() {
		return opzioneSelezionata;
	}

	public void setOpzioneSelezionata(String opzioneSelezionata) {
		this.opzioneSelezionata = opzioneSelezionata;
	}

	public boolean isSceltaEffettuata() {
		return sceltaEffettuata;
	}

	public void setSceltaEffettuata(boolean sceltaEffettuata) {
		this.sceltaEffettuata = sceltaEffettuata;
	}

	public String getAvvisoFaseNonAttiva() {
		return avvisoFaseNonAttiva;
	}

	public void setAvvisoFaseNonAttiva(String avvisoFaseNonAttiva) {
		this.avvisoFaseNonAttiva = avvisoFaseNonAttiva;
	}

	public String getAvvisoTermineScaduto() {
		return avvisoTermineScaduto;
	}

	public void setAvvisoTermineScaduto(String avvisoTermineScaduto) {
		this.avvisoTermineScaduto = avvisoTermineScaduto;
	}

	public String getAvvisoInvioAvvenuto() {
		return avvisoInvioAvvenuto;
	}

	public void setAvvisoInvioAvvenuto(String avvisoInvioAvvenuto) {
		this.avvisoInvioAvvenuto = avvisoInvioAvvenuto;
	}

	public String getDataOdierna() {
		return dataOdierna;
	}

	public void setDataOdierna(String dataOdierna) {
		this.dataOdierna = dataOdierna;
	}

	public String getFraseDifferenzaDate() {
		return fraseDifferenzaDate;
	}

	public void setFraseDifferenzaDate(String fraseDifferenzaDate) {
		this.fraseDifferenzaDate = fraseDifferenzaDate;
	}
	
	
}
