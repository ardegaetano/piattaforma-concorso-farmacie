package com.accenture.CCFarm.PageBean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.action.HomeRegioneAction;

@ManagedBean
@SessionScoped
public class HomeRegioneBean {

	HomeRegioneAction regAction = null;
	
	private String regione;
	private String username;
	private String codRegione;

	public HomeRegioneBean(){
		this.init();
	}
	
	public void init(){  
		regAction = new HomeRegioneAction(); //init Al suo interno
		regAction.loadPaginaInserimento(this);
	}

	public String getRegione() {
		return regione;
	}

	public void setRegione(String regione) {
		this.regione = regione;
	}


	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	public HomeRegioneAction getRegAction() {
		return regAction;
	}

	public void setRegAction(HomeRegioneAction regAction) {
		this.regAction = regAction;
	}

	public String getCodRegione() {
		return codRegione;
	}

	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}

	public void logout()
	{	
		((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).invalidate();
	}

}
