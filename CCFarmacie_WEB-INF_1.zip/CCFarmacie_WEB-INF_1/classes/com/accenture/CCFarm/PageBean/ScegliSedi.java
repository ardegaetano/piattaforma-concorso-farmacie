package com.accenture.CCFarm.PageBean;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;
import org.primefaces.model.DualListModel;

import com.accenture.CCFarm.DAO.AnagraficaFarm;
import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.ScegliSediAction;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.StringUtil;

@ManagedBean(name = "scegliSedi", eager = true)
@ViewScoped
public class ScegliSedi {
	
	private Logger logger = CommonLogger.getLogger("ScegliSedi");
	private static final String pageError = "errorPageGenerica.jsf";
	
	private String linguaScelta;
	private String avvisoSelezioneSediNonValida;
	private String avvisoTermineScadutoSalvataggio;
	private String avvisoTermineScadutoInvio;
	private String avvisoInvioPreferenzeAvvenuto;
	private String avvisoSalvaAvvenuto;
	
	private ScegliSediAction scegliSediAction;
	
	private DualListModel<AnagraficaFarm> sedi;
	
	private Map<String, AnagraficaFarm> anagraficaFarmMap;
	
	private List<AnagraficaFarm> sediSelezionate;
	
	private String idRegione;
	
	private Utente utente;
	
	private Candidatura candidatura;
	
	private String numSediSelezionabili; //indice Interpello
	
	private String numSediSelezionate;
	
	private String numSediConcorso;
	
	private String flagSedi;
	
	private AnagraficaFarm selectedFarm;
	
	private Interpello interpello;
	
	private String numeroInterpello;
	
	private String dataInizioInterpello;
	
	private String dataFineInterpello;
	
	private String dataOdierna;
	
	private String fraseDifferenzaDate;
	
	private String posizioneGraduatoria; //indice totale (graduatoria)
	
	private boolean flagInterpelloRinunce = false;
	
	public ScegliSedi() throws GestioneErroriException {
		
		try {
			
			init();
		}
		catch(Exception e) {
			
			logger.error("ScegliSedi() - costruzione del bean fallita", e);
			throw new GestioneErroriException("ScegliSedi() - costruzione del bean fallita");
		}
	}
	
	private void init() throws GestioneErroriException {
	
		try {
			
			setLinguaScelta((String) JSFUtility.getFacesContext().getExternalContext().getSessionMap().get("linguaScelta"));
			setAvvisoSelezioneSediNonValida(StringUtil.getPropertyMessage("scegliSedi.validator.pickList", linguaScelta));
			setAvvisoTermineScadutoSalvataggio(StringUtil.getPropertyMessage("scegliSedi.termine.scaduto.salvataggio.preferenze", linguaScelta));
			setAvvisoTermineScadutoInvio(StringUtil.getPropertyMessage("scegliSedi.termine.scaduto.invio.preferenze", linguaScelta));
			setAvvisoInvioPreferenzeAvvenuto(StringUtil.getPropertyMessage("scegliSedi.invio.preferenze.avvenuto", linguaScelta));
			setAvvisoSalvaAvvenuto(StringUtil.getPropertyMessage("scegliSedi.salva.avvenuto", linguaScelta));
			
			//recupera data e orario correnti
			//Date dataOdierna = DateUtil.getDataOdierna();
			Timestamp istanteCorrente = DateUtil.getCurrentTimestamp();
			//setDataOdierna(StringUtil.dateToString(dataOdierna, "dd/MM/yyyy"));
			setDataOdierna(StringUtil.timestampToString(istanteCorrente, "dd/MM/yyyy HH:mm:ss"));
			
			scegliSediAction = new ScegliSediAction();
			
			scegliSediAction.init(this);
			
			scegliSediAction.caricaSedi(this);
		}
		catch(Exception e) {
			
			logger.error("ScegliSedi - inizializzazione fallita", e);
			throw new GestioneErroriException("ScegliSedi - inizializzazione fallita");
		}
	}
	
	private boolean validaSalvataggioSceltaSedi() {
		
		if(DateUtil.getCurrentTimestamp().after((Timestamp) interpello.getDataFine())) {
			
			JSFUtility.addWarningMessage("", avvisoTermineScadutoSalvataggio);
			return false;
		}
		
		if(getSedi().getTarget().size() > Integer.parseInt(numSediSelezionabili)) {
			
			JSFUtility.addWarningMessage("", avvisoSelezioneSediNonValida);
			return false;
		}
		
		return true;
	}
	
	public void salva() {
		
		try {
			
			if(validaSalvataggioSceltaSedi()) {
				
				scegliSediAction.salva(this);
				JSFUtility.addInfoMessage("", avvisoSalvaAvvenuto, false);
			}
		}
		catch(Exception e) {
			
			logger.error("ScegliSedi - salvataggio della selezione fallito", e);
			JSFUtility.redirect(pageError);
		}
		
	}
	
	private boolean validaConfermaSceltaSedi() {
		
		if(DateUtil.getCurrentTimestamp().after((Timestamp) interpello.getDataFine())) {
			
			JSFUtility.addWarningMessage("", avvisoTermineScadutoInvio);
			return false;
		}
		
		if(getSedi().getTarget().size() != Integer.parseInt(numSediSelezionabili)) {
			
			JSFUtility.addWarningMessage("", avvisoSelezioneSediNonValida);
			return false;
		}
		
		return true;
	}
	
	//aggiorna l'elenco delle sedi selezionate recuperando gli elementi dalla sezione "target" della picklist
	public void recuperaSedi() {
		
		if(validaConfermaSceltaSedi()) {
			
			setSediSelezionate(sedi.getTarget());
			setNumSediSelezionate(String.valueOf(sediSelezionate.size()));
			JSFUtility.executeScript("dlg.show();");
		}
	}
	
	public void invia() {
		
		try {
			
			scegliSediAction.invia(this);
			JSFUtility.addInfoMessage("", avvisoInvioPreferenzeAvvenuto, false);
		}
		catch(Exception e) {
			
			logger.error("ScegliSedi - conferma della selezione fallita", e);
			JSFUtility.redirect(pageError);
		}
	}
	
	public String getLinguaScelta() {
		return linguaScelta;
	}

	public void setLinguaScelta(String linguaScelta) {
		this.linguaScelta = linguaScelta;
	}

	public String getAvvisoSelezioneSediNonValida() {
		return avvisoSelezioneSediNonValida;
	}

	public void setAvvisoSelezioneSediNonValida(String avvisoSelezioneSediNonValida) {
		this.avvisoSelezioneSediNonValida = avvisoSelezioneSediNonValida;
	}

	public String getAvvisoTermineScadutoSalvataggio() {
		return avvisoTermineScadutoSalvataggio;
	}

	public void setAvvisoTermineScadutoSalvataggio(
			String avvisoTermineScadutoSalvataggio) {
		this.avvisoTermineScadutoSalvataggio = avvisoTermineScadutoSalvataggio;
	}

	public String getAvvisoTermineScadutoInvio() {
		return avvisoTermineScadutoInvio;
	}

	public void setAvvisoTermineScadutoInvio(String avvisoTermineScadutoInvio) {
		this.avvisoTermineScadutoInvio = avvisoTermineScadutoInvio;
	}

	public String getAvvisoInvioPreferenzeAvvenuto() {
		return avvisoInvioPreferenzeAvvenuto;
	}

	public void setAvvisoInvioPreferenzeAvvenuto(
			String avvisoInvioPreferenzeAvvenuto) {
		this.avvisoInvioPreferenzeAvvenuto = avvisoInvioPreferenzeAvvenuto;
	}

	public DualListModel<AnagraficaFarm> getSedi() {
		return sedi;
	}

	public void setSedi(DualListModel<AnagraficaFarm> sedi) {
		this.sedi = sedi;
	}

	public Map<String, AnagraficaFarm> getAnagraficaFarmMap() {
		return anagraficaFarmMap;
	}

	public void setAnagraficaFarmMap(Map<String, AnagraficaFarm> anagraficaFarmMap) {
		this.anagraficaFarmMap = anagraficaFarmMap;
	}

	public List<AnagraficaFarm> getSediSelezionate() {
		return sediSelezionate;
	}

	public void setSediSelezionate(List<AnagraficaFarm> sediSelezionate) {
		this.sediSelezionate = sediSelezionate;
	}

	public String getIdRegione() {
		return idRegione;
	}

	public void setIdRegione(String idRegione) {
		this.idRegione = idRegione;
	}

	public Utente getUtente() {
		return utente;
	}

	public void setUtente(Utente utente) {
		this.utente = utente;
	}

	public Candidatura getCandidatura() {
		return candidatura;
	}

	public void setCandidatura(Candidatura candidatura) {
		this.candidatura = candidatura;
	}

	public String getNumSediSelezionabili() {
		return numSediSelezionabili;
	}

	public void setNumSediSelezionabili(String numSediSelezionabili) {
		this.numSediSelezionabili = numSediSelezionabili;
	}

	public String getNumSediSelezionate() {
		return numSediSelezionate;
	}

	public void setNumSediSelezionate(String numSediSelezionate) {
		this.numSediSelezionate = numSediSelezionate;
	}

	public String getNumSediConcorso() {
		return numSediConcorso;
	}

	public void setNumSediConcorso(String numSediConcorso) {
		this.numSediConcorso = numSediConcorso;
	}

	public String getFlagSedi() {
		return flagSedi;
	}

	public void setFlagSedi(String flagSedi) {
		this.flagSedi = flagSedi;
	}

	public AnagraficaFarm getSelectedFarm() {
		return selectedFarm;
	}

	public void setSelectedFarm(AnagraficaFarm selectedFarm) {
		this.selectedFarm = selectedFarm;
	}

	public Interpello getInterpello() {
		return interpello;
	}

	public void setInterpello(Interpello interpello) {
		this.interpello = interpello;
	}

	public String getNumeroInterpello() {
		return numeroInterpello;
	}

	public void setNumeroInterpello(String numeroInterpello) {
		this.numeroInterpello = numeroInterpello;
	}

	public String getDataInizioInterpello() {
		return dataInizioInterpello;
	}

	public void setDataInizioInterpello(String dataInizioInterpello) {
		this.dataInizioInterpello = dataInizioInterpello;
	}

	public String getDataFineInterpello() {
		return dataFineInterpello;
	}

	public void setDataFineInterpello(String dataFineInterpello) {
		this.dataFineInterpello = dataFineInterpello;
	}

	public String getAvvisoSalvaAvvenuto() {
		return avvisoSalvaAvvenuto;
	}

	public void setAvvisoSalvaAvvenuto(String avvisoSalvaAvvenuto) {
		this.avvisoSalvaAvvenuto = avvisoSalvaAvvenuto;
	}

	public String getDataOdierna() {
		return dataOdierna;
	}

	public void setDataOdierna(String dataOdierna) {
		this.dataOdierna = dataOdierna;
	}
	
	public String getFraseDifferenzaDate() {
		return fraseDifferenzaDate;
	}

	public void setFraseDifferenzaDate(String fraseDifferenzaDate) {
		this.fraseDifferenzaDate = fraseDifferenzaDate;
	}

	public String getPosizioneGraduatoria() {
		return posizioneGraduatoria;
	}

	public void setPosizioneGraduatoria(String posizioneGraduatoria) {
		this.posizioneGraduatoria = posizioneGraduatoria;
	}

	public boolean isFlagInterpelloRinunce() {
		return flagInterpelloRinunce;
	}

	public void setFlagInterpelloRinunce(boolean flagInterpelloRinunce) {
		this.flagInterpelloRinunce = flagInterpelloRinunce;
	}
}
