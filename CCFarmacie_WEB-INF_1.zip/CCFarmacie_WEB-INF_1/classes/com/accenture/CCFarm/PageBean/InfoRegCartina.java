package com.accenture.CCFarm.PageBean;

import com.accenture.CCFarm.DAO.RegioneDatiBando;

public class InfoRegCartina {
	private String dataIni ="";
	private String dataFin="";
	private String stat="";
	private RegioneDatiBando regioneDatiBando;
	private String coloreRegione="";
	
	
	public String getStat() {
		return stat;
	}
	public void setStat(String stat) {
		this.stat = stat;
	}
	
	
	
	public RegioneDatiBando getRegioneDatiBando() {
		return regioneDatiBando;
	}
	public void setRegioneDatiBando(RegioneDatiBando regioneDatiBando) {
		this.regioneDatiBando = regioneDatiBando;
	}
	public String getColoreRegione() {
		return coloreRegione;
	}
	public void setColoreRegione(String coloreRegione) {
		this.coloreRegione = coloreRegione;
	}
	public String getDataIni() {
		return dataIni;
	}
	public void setDataIni(String dataIni) {
		this.dataIni = dataIni;
	}
	public String getDataFin() {
		return dataFin;
	}
	public void setDataFin(String dataFin) {
		this.dataFin = dataFin;
	}

	
	
	
	
}
