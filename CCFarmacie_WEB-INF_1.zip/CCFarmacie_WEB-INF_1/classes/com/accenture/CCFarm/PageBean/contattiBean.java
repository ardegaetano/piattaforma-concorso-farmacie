package com.accenture.CCFarm.PageBean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.RegioneDatiBando;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PDFModulo.GestionePDFModuloRicevuta;
import com.accenture.CCFarm.action.HomeCandidatoAction;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RepositorySession;


@ManagedBean
@RequestScoped
public class contattiBean {
	
	private String msgAmministrativo="";
	
	private FacesContext context =null;
	private HttpSession session= null; 
	private HttpServletRequest request=null; 
	
	Logger logger = CommonLogger.getLogger("HomeCandidatoBean");
	
	public contattiBean(){
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	
	public void init() {  
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		context = FacesContext.getCurrentInstance();
    	request = (HttpServletRequest) context.getExternalContext().getRequest();
    	session = request.getSession();
    	DatiBando datiBando = (DatiBando) session.getAttribute(RepositorySession.DATI_BANDO);
    	String codiceRegione=(String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_REGIONE);   
    	
    	msgAmministrativo = "";
    	
    	if(lingua.equals("de")){
    		
    		msgAmministrativo = " F�r Verwaltungsfragen k�nnen Sie sich unter der Nummer 0471 418070 oder �ber die E-Mailadresse gesundheitssprengel@provinz.bz.it/distrettisanitari@provincia.bz.it von Montag bis Freitag, 08:30 bis 12:15 und von 14:30 bis 16:30 Uhr, an das Amt f�r Gesundheitssprengel wenden. ";
    	}  
    	else{
     	
	    	if (datiBando.getUfficioBando()!=null && !datiBando.getUfficioBando().equals("")){
	    		msgAmministrativo +=JSFUtility.getPropertyMessage("contattiBean.mess.amministrativo", lingua) /* "Per chiarimenti amministrativi l'ufficio di competenza � "*/ 
	    				+ datiBando.getUfficioBando();
	    		if (datiBando.getTelefonoBando()!=null && !datiBando.getTelefonoBando().equals("")){
	    			msgAmministrativo += JSFUtility.getPropertyMessage("contattiBean.mess.amministrativo.telefono", lingua) /*" contattabile al numero di telefono "*/
	    					+ datiBando.getTelefonoBando();}
	    		if (codiceRegione.equals("041")){
	    			msgAmministrativo +=JSFUtility.getPropertyMessage("contattiBean.mess.amministrativo.mail", lingua) /*" alla mail "*/
	    					+ "gesundheitssprengel@provinz.bz.it/distrettisanitari@provincia.bz.it";}
	    		}
	    	    else if (datiBando.getMailBando()!=null && !datiBando.getMailBando().equals("")){
	    			msgAmministrativo +=JSFUtility.getPropertyMessage("contattiBean.mess.amministrativo.mail", lingua) /*" alla mail "*/
	    					+ datiBando.getMailBando() ;}
	    		if (datiBando.getDisponibilitaBando()!=null && !datiBando.getDisponibilitaBando().equals("")){
	    			msgAmministrativo +=JSFUtility.getPropertyMessage("contattiBean.mess.amministrativo.da", lingua) /*", da "*/
	    					+ datiBando.getDisponibilitaBando();}
	    	}
    		
    	}
    	
       	
    	
    	
	


	public String getMsgAmministrativo() {
		return msgAmministrativo;
	}


	public void setMsgAmministrativo(String msgAmministrativo) {
		this.msgAmministrativo = msgAmministrativo;
	}


	
	
	
}
