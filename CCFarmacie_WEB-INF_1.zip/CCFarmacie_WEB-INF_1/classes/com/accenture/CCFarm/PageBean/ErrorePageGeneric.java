package com.accenture.CCFarm.PageBean;


import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.utility.JSFUtility;


@ManagedBean
@SessionScoped
public class ErrorePageGeneric {
	
	//utente
	private String returnString;
	private String messaggioErrore = null;
	HttpServletRequest req =null;
	
	public ErrorePageGeneric(){
		
			this.init();
		
	}
		
	
	public void init()  {  

		FacesContext context = FacesContext.getCurrentInstance();
    	req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
//    	String idMsgError = (String) session.getAttribute(RepositorySession.IDMSG_ERROR_GEN);
//    	if (idMsgError==null){
//    		idMsgError="XXX";
//    	}
//    	returnString = (String) session.getAttribute(RepositorySession.RETURN_ERROR_GEN);
//    	if (returnString==null){
//    		returnString="";
//    	}
//    	
////        if (idMsgError.equals("00")){
////	    	messaggioErrore = "";
////	    	returnString=".jsf";
////	    } 
////
////        if (idMsgError.equals("00")){
////	    	messaggioErrore = "";
////	    	returnString=".jsf";
////	    } 
////
////        if (idMsgError.equals("00")){
////	    	messaggioErrore = "";
////	    	returnString=".jsf";
////	    } 
//
//	    if (idMsgError.equals("XXX")){
//	    	messaggioErrore = "Si e' verificato un' errore si prega di riprovare piu' tardi o di contattare l'assistenza tecnica.";
////	    	returnString="homeCandidato.jsf";
//	    }
//	    
//	    
	}

	
	
	public void indietro() {
		
		req.getSession().invalidate();
		JSFUtility.redirect("cartinaItalia.jsp");
//		response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/cartinaItalia.jsp");
		

	}
	
	
	
	public String getMessaggioErrore() {
		return messaggioErrore;
	}


	public void setMessaggioErrore(String messaggioErrore) {
		this.messaggioErrore = messaggioErrore;
	}


	public String getReturnString() {
		return returnString;
	}


	public void setReturnString(String returnString) {
		this.returnString = returnString;
	}


	
	
}
