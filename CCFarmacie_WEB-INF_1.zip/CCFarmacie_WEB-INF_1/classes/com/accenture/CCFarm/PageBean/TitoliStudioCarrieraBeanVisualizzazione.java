package com.accenture.CCFarm.PageBean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.AltraLaureaBis;
import com.accenture.CCFarm.Bean.AltroTitolo;
import com.accenture.CCFarm.Bean.BorsaStudio;
import com.accenture.CCFarm.Bean.CorsoAgg;
import com.accenture.CCFarm.Bean.Dottorato;
import com.accenture.CCFarm.Bean.Pubblicazione;
import com.accenture.CCFarm.Bean.Specializzazione;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutiva;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.TitoliStudioAction;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.MatriceProperties;
import com.accenture.CCFarm.utility.MatricePropertiesDe;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;


@ManagedBean
@SessionScoped
public class TitoliStudioCarrieraBeanVisualizzazione {
	Logger logger = CommonLogger.getLogger("TitoliStudioCarrieraBeanVisualizzazione");
		
	//Seconda laurea
		private String idSecondaLaurea;
		private String descUniSecondaLaurea;
		private String luogoSecondaLaurea;
		private Date dataSecondaLaurea;
		private String dataSecondaLaureaString;
		private String nazioneSecondaLaurea;
		private String flagEsteroSecondaLaurea;
	
	
		private boolean secLaureaValidRequired = false;
		private boolean idoneitaValidRequired = false;
		private boolean idonNazValidRequired = false;
		
		//idoneita
		private String flagIdoneitaSediIdoneita;
		private String estremiIdoneita;
		private Date dataIdoneita;
		private String dataIdoneitaString;
		private String rifIdoneitaNazionale;
		private String annoIdoneitaNazionale;
		
		private String elencoDoc ="";
		private int elencoDocSize;
		
		ArrayList<AltraLaureaBis> listaAltreLaureeBis;
		ArrayList<Specializzazione> listaSpecializzazioni;
		ArrayList<BorsaStudio> listaBorseStudio;
		ArrayList<Dottorato> listaDottorati;
		ArrayList<AltroTitolo> listaAltriTitoli;
		ArrayList<CorsoAgg> listaCorsiAgg;
		ArrayList<Pubblicazione> listaPubblicazioni;
		private AltraLaureaBis altraLaureaBis;
		private AltraLaureaBis altraLaureaBisSelezionata;
		private Specializzazione specializzazione;
		private Specializzazione specializzazioneSelezionata;
		private BorsaStudio borsaStudio;
		private BorsaStudio borsaStudioSelezionata;
		private Dottorato dottorato;
		private Dottorato dottoratoSelezionato;
		private AltroTitolo altroTitolo;
		private AltroTitolo altroTitoloSelezionato;
		private CorsoAgg corsoAgg;
		private CorsoAgg corsoAggSelezionato;
		private Pubblicazione pubblicazione;
		private Pubblicazione pubblicazioneSelezionata;
		private DichiarazioneSostitutiva dichiarazioneSostitutiva;
		
		private boolean visualizzaPanelBancario=false;
	    private boolean visualizzaPanelPostale=false;
	    private boolean visualizzaPanelDocumenti=true;
	    private boolean visualizzaPanelVersamenti = true;
	    private boolean visualizzaDichiarazione = false;
	    private DatiBando datiBando;
		private String tipologiaVersamento;
		private String contributoPartecipazione;
		private boolean mostraPanelBancario=false;
		private boolean mostraPanelPostale=false;
		
		private String dataInizioCorsoReg;
		private String dataInizioPubblicazioneReg;
		
		 MatriceProperties matriceIt = MatriceProperties.getMatricePropertiesIt();
		 MatricePropertiesDe matriceDe = MatricePropertiesDe.getMatricePropertiesDe();
		
		TitoliStudioAction titoliStudioAction;
		
		private SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		
		public TitoliStudioCarrieraBeanVisualizzazione() {
			titoliStudioAction=new TitoliStudioAction();
			listaAltreLaureeBis = new ArrayList<AltraLaureaBis>();
			listaSpecializzazioni = new ArrayList<Specializzazione>();
			listaBorseStudio = new ArrayList<BorsaStudio>();
			listaDottorati = new ArrayList<Dottorato>();
			listaAltriTitoli = new ArrayList<AltroTitolo>();
			listaCorsiAgg = new ArrayList<CorsoAgg>();
			listaPubblicazioni = new ArrayList<Pubblicazione>();
			altraLaureaBis = new AltraLaureaBis();
			altraLaureaBisSelezionata = new AltraLaureaBis();
			specializzazione = new Specializzazione();
			borsaStudio = new BorsaStudio();
			dottorato = new Dottorato();
			altroTitolo = new AltroTitolo(); 
			corsoAgg = new CorsoAgg();
			pubblicazione = new Pubblicazione();
			dichiarazioneSostitutiva = new DichiarazioneSostitutiva();
		}

		
		public void controllaPubbl(){
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta"); 
			boolean isTedesco = false;
			if(lingua.equals("de")){
				 isTedesco = true;
			}
			elencoDoc="";
			ArrayList<String> listaDoc = new ArrayList<String>();
			// controllo su Altra Laurea, e liste Corsi,Altri Titoli ,Dottorato,Borse di studio ,Specializzazioni,Altra laurea bis 
			if (this.flagEsteroSecondaLaurea!=null&&(this.flagEsteroSecondaLaurea.equalsIgnoreCase("Si")||this.flagEsteroSecondaLaurea.equalsIgnoreCase("Ja"))){
				if(isTedesco){
					listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.seclaurea", lingua)+ " "+matriceDe.getMatricePropertiesDe(this.idSecondaLaurea.replace(" ", "_")));
				}
				else{
				listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.seclaurea", lingua)+ this.idSecondaLaurea);
				}
				//listaDoc.add("documentazione relativa alla Seconda laurea in  "+ this.idSecondaLaurea);
				//this.setVisualizzaPanelVersamenti(false);
			}		
			
			if(listaAltreLaureeBis!=null){
				Iterator iterator = listaAltreLaureeBis.iterator();
				while(iterator.hasNext()){
					altraLaureaBis = (AltraLaureaBis)iterator.next();
					if (altraLaureaBis.getFlagEsteroSecondaLaureaBis()!=null && (altraLaureaBis.getFlagEsteroSecondaLaureaBis().equalsIgnoreCase("Si")||altraLaureaBis.getFlagEsteroSecondaLaureaBis().equalsIgnoreCase("Ja"))){
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.seclaurea", lingua)+ this.altraLaureaBis.getIdAltraLaureaBis());
						//listaDoc.add("documentazione relativa alla Seconda laurea in  "+ this.altraLaureaBis.getIdAltraLaureaBis());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaAltriTitoli!=null){
				Iterator iterator = listaAltriTitoli.iterator();
				while(iterator.hasNext()){
					altroTitolo = (AltroTitolo)iterator.next();
					if (altroTitolo.getFlagEsteroAltroTitolo()!=null && (altroTitolo.getFlagEsteroAltroTitolo().equalsIgnoreCase("Si")||altroTitolo.getFlagEsteroAltroTitolo().equalsIgnoreCase("Ja"))){
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.altro.titolo", lingua)+ this.altroTitolo.getDescAltroTitolo());
						//listaDoc.add("documentazione relativa ad altro titolo di studio "+ this.altroTitolo.getDescAltroTitolo());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaBorseStudio!=null){
				Iterator iterator = listaBorseStudio.iterator();
				while(iterator.hasNext()){
					borsaStudio = (BorsaStudio)iterator.next();
					if (borsaStudio.getFlagEsteroBorsa()!=null &&(borsaStudio.getFlagEsteroBorsa().equalsIgnoreCase("Si")||borsaStudio.getFlagEsteroBorsa().equalsIgnoreCase("Ja"))){
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.borsa.studio", lingua)+ this.borsaStudio.getDenominazioneBorsa());
						//listaDoc.add("documentazione relativa alla borsa di studio "+ this.borsaStudio.getDenominazioneBorsa());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaCorsiAgg!=null){
				Iterator iterator = listaCorsiAgg.iterator();
				while(iterator.hasNext()){
					corsoAgg = (CorsoAgg)iterator.next();
					if (corsoAgg.getFlagEsteroCorsoAgg()!=null && (corsoAgg.getFlagEsteroCorsoAgg().equalsIgnoreCase("Si")||corsoAgg.getFlagEsteroCorsoAgg().equalsIgnoreCase("Ja"))){
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.corso.aggiornamento", lingua)+ this.corsoAgg.getTitoloCorsoAgg());
						//listaDoc.add("documentazione relativa al corso di aggiornamento "+ this.corsoAgg.getTitoloCorsoAgg());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaDottorati!=null){
				Iterator iterator = listaDottorati.iterator();
				while(iterator.hasNext()){
					dottorato = (Dottorato)iterator.next();
					if (dottorato.getFlagEsteroDottorato()!=null&&(dottorato.getFlagEsteroDottorato().equalsIgnoreCase("Si")||dottorato.getFlagEsteroDottorato().equalsIgnoreCase("Ja"))){
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.dottorato", lingua)+ this.dottorato.getDenominazioneDottorato());
						//listaDoc.add("documentazione relativa al dottorato "+ this.dottorato.getDenominazioneDottorato());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaSpecializzazioni!=null){
				Iterator iterator = listaSpecializzazioni.iterator();
				while(iterator.hasNext()){
					specializzazione = (Specializzazione)iterator.next();
					if (specializzazione.getFlagEsteroSpec()!=null && (specializzazione.getFlagEsteroSpec().equalsIgnoreCase("Si")||specializzazione.getFlagEsteroSpec().equalsIgnoreCase("Ja"))){
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.specializzazione", lingua)+ this.specializzazione.getDenominazioneSpec());
						//listaDoc.add("documentazione relativa alla specializzazione "+ this.specializzazione.getDenominazioneSpec());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaPubblicazioni!=null){
				Iterator iterator = listaPubblicazioni.iterator();
				while(iterator.hasNext()){
					pubblicazione = (Pubblicazione)iterator.next();
					listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.pubblicazione", lingua)+ this.pubblicazione.getTitoloPubblicazione());
						//listaDoc.add("documentazione relativa alla pubblicazione "+ this.pubblicazione.getTitoloPubblicazione());
						//this.setVisualizzaPanelVersamenti(false);
				}
			}

			datiBando=(DatiBando)GetSessionUtility.getSessionAttribute(RepositorySession.DATI_BANDO);
			
			if(datiBando!=null)
			{
				contributoPartecipazione=datiBando.getContributoPartecipazione();
				tipologiaVersamento=datiBando.getEstremiPagamento();
			}
			
			if(listaDoc.size()==0)
			{
				if(contributoPartecipazione!=null && contributoPartecipazione.equals("1"))
					this.setVisualizzaPanelVersamenti(true);
				else
					this.setVisualizzaPanelVersamenti(false);
					
				this.setVisualizzaPanelDocumenti(false);
			}
			else
			{
				this.setVisualizzaPanelVersamenti(false);
				
				this.setVisualizzaPanelDocumenti(true);
				
				listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.copia.doc.riconoscimento", lingua));
			}	
			
			boolean documentiOrVersamenti=false;
			
			if(visualizzaPanelDocumenti)
			{
				//se sono previsti documenti
				
				mostraPanelBancario=false;
				mostraPanelPostale=false;
				
				visualizzaDichiarazione=false;
				
				dichiarazioneSostitutiva.setIban("");
				dichiarazioneSostitutiva.setNumeroUffPostale("");
				
				documentiOrVersamenti=true;
			}
			else if(visualizzaPanelVersamenti)
			{
				//se sono previsti solo versamenti
				
				if(dichiarazioneSostitutiva!=null)
				{
					//se � nota la tipologia del pagamento
					
					if(dichiarazioneSostitutiva.getIban()!=null && !dichiarazioneSostitutiva.getIban().equals(""))
					{
						mostraPanelBancario=true;
						dichiarazioneSostitutiva.setNumeroUffPostale("");
						mostraPanelPostale=false;
					}
					else if(dichiarazioneSostitutiva.getNumeroUffPostale()!=null && !dichiarazioneSostitutiva.getNumeroUffPostale().equals(""))
					{
						mostraPanelBancario=false;
						dichiarazioneSostitutiva.setIban("");
						mostraPanelPostale=true;
					}
					
					visualizzaDichiarazione=false;
					
					documentiOrVersamenti=true;
				}
			}
			
			if(!documentiOrVersamenti)
			{
				//se non sono previsti ne  versamenti ne documenti
				
				mostraPanelBancario=false;
				
				mostraPanelPostale=false;
				
				visualizzaPanelDocumenti=false;
				
				visualizzaDichiarazione=true;
			}
			
			elencoDoc=elencoDoc+listaDoc.toString().substring(1, listaDoc.toString().lastIndexOf("]"));
			elencoDocSize = elencoDoc.length();
		}
			
		public boolean init(String idUtente)
		{
			boolean result = false;
			
			try {
				result = titoliStudioAction.loadPaginaInserimentoVisualizzazione(idUtente,this);
				controllaPubbl();
				return result;
			} catch (GestioneErroriException e) {
				logger.error("TitoliStudioCarrieraBeanVisualizzazione - init: " + e.getMessage());	
				JSFUtility.redirect("errorPageGenerica.jsf");
				return false;
			}
		}
		
		public DichiarazioneSostitutiva getDichiarazioneSostitutiva() {
			return dichiarazioneSostitutiva;
		}


		public void setDichiarazioneSostitutiva(
				DichiarazioneSostitutiva dichiarazioneSostitutiva) {
			this.dichiarazioneSostitutiva = dichiarazioneSostitutiva;
		}


		//inizializza il bean a partire dal relativo bean in compilazione
		public void init(TitoliStudioCarrieraBean titoliStudioCarrieraBean) throws Exception
		{
			titoliStudioAction.loadPaginaInserimentoVisualizzazione(titoliStudioCarrieraBean,this);
		
		}
		
		public boolean isVisualizzaPanelVersamenti() {
			return visualizzaPanelVersamenti;
		}

		public void setVisualizzaPanelVersamenti(boolean visualizzaPanelVersamenti) {
			this.visualizzaPanelVersamenti = visualizzaPanelVersamenti;
		}
		
		public boolean isVisualizzaDichiarazione() {
			return visualizzaDichiarazione;
		}


		public void setVisualizzaDichiarazione(boolean visualizzaDichiarazione) {
			this.visualizzaDichiarazione = visualizzaDichiarazione;
		}


		public boolean isVisualizzaPanelDocumenti() {
			return visualizzaPanelDocumenti;
		}


		public void setVisualizzaPanelDocumenti(boolean visualizzaPanelDocumenti) {
			this.visualizzaPanelDocumenti = visualizzaPanelDocumenti;
		}


		public boolean isIdoneitaValidRequired() {
			return idoneitaValidRequired;
		}


		public void setIdoneitaValidRequired(boolean idoneitaValidRequired) {
			this.idoneitaValidRequired = idoneitaValidRequired;
		}

		public String getIdSecondaLaurea() {
			return idSecondaLaurea;
		}

		public String getElencoDoc() {
			return elencoDoc;
		}

		public void setElencoDoc(String elencoDoc) {
			this.elencoDoc = elencoDoc;
		}
		
		public int getElencoDocSize() {
			return elencoDocSize;
		}
		
		public void setElencoDocSize(int elencoDocSize) {
			this.elencoDocSize = elencoDocSize;
		}


		public void setIdSecondaLaurea(String idSecondaLaurea) {
			this.idSecondaLaurea = idSecondaLaurea;
		}

		public String getDescUniSecondaLaurea() {
			return descUniSecondaLaurea;
		}

		public void setDescUniSecondaLaurea(String descUniSecondaLaurea) {
			this.descUniSecondaLaurea = descUniSecondaLaurea;
		}

		public String getLuogoSecondaLaurea() {
			return luogoSecondaLaurea;
		}

		public void setLuogoSecondaLaurea(String luogoSecondaLaurea) {
			this.luogoSecondaLaurea = luogoSecondaLaurea;
		}

		public Date getDataSecondaLaurea() {
			return dataSecondaLaurea;
		}
		
		public void setDataSecondaLaurea(Date dataSecondaLaurea) {
			if(dataSecondaLaurea!=null)
				dataSecondaLaureaString=StringUtil.dateToStringDDMMYYYY(dataSecondaLaurea);
			this.dataSecondaLaurea = dataSecondaLaurea;
		}
		
		public String getDataSecondaLaureaString() {
			return dataSecondaLaureaString;
		}


		public void setDataSecondaLaureaString(String dataSecondaLaureaString) {
			this.dataSecondaLaureaString = dataSecondaLaureaString;
		}
		
		public String getNazioneSecondaLaurea() {
			return nazioneSecondaLaurea;
		}


		public void setNazioneSecondaLaurea(String nazioneSecondaLaurea) {
			this.nazioneSecondaLaurea = nazioneSecondaLaurea;
		}

		public String getFlagEsteroSecondaLaurea() {
			return flagEsteroSecondaLaurea;
		}


		public void setFlagEsteroSecondaLaurea(String flagEsteroSecondaLaurea) {
			this.flagEsteroSecondaLaurea = flagEsteroSecondaLaurea;
		}


		public boolean isSecLaureaValidRequired() {
			return secLaureaValidRequired;
		}


		public void setSecLaureaValidRequired(boolean secLaureaValidRequired) {
			this.secLaureaValidRequired = secLaureaValidRequired;
		}


		public AltraLaureaBis getAltraLaureaBis() {
			return altraLaureaBis;
		}


		public void setAltraLaureaBis(AltraLaureaBis altraLaureaBis) {
			this.altraLaureaBis = altraLaureaBis;
		}


		public AltraLaureaBis getAltraLaureaBisSelezionata() {
			return altraLaureaBisSelezionata;
		}


		public void setAltraLaureaBisSelezionata(
				AltraLaureaBis altraLaureaBisSelezionata) {
			this.altraLaureaBisSelezionata = altraLaureaBisSelezionata;
		}


		public Specializzazione getSpecializzazione() {
			return specializzazione;
		}


		public void setSpecializzazione(Specializzazione specializzazione) {
			this.specializzazione = specializzazione;
		}


		public Specializzazione getSpecializzazioneSelezionata() {
			return specializzazioneSelezionata;
		}


		public void setSpecializzazioneSelezionata(
				Specializzazione specializzazioneSelezionata) {
			this.specializzazioneSelezionata = specializzazioneSelezionata;
		}


		public BorsaStudio getBorsaStudio() {
			return borsaStudio;
		}


		public void setBorsaStudio(BorsaStudio borsaStudio) {
			this.borsaStudio = borsaStudio;
		}


		public BorsaStudio getBorsaStudioSelezionata() {
			return borsaStudioSelezionata;
		}


		public void setBorsaStudioSelezionata(BorsaStudio borsaStudioSelezionata) {
			this.borsaStudioSelezionata = borsaStudioSelezionata;
		}


		public Dottorato getDottorato() {
			return dottorato;
		}


		public void setDottorato(Dottorato dottorato) {
			this.dottorato = dottorato;
		}


		public Dottorato getDottoratoSelezionato() {
			return dottoratoSelezionato;
		}


		public void setDottoratoSelezionato(Dottorato dottoratoSelezionato) {
			this.dottoratoSelezionato = dottoratoSelezionato;
		}


		public AltroTitolo getAltroTitolo() {
			return altroTitolo;
		}


		public void setAltroTitolo(AltroTitolo altroTitolo) {
			this.altroTitolo = altroTitolo;
		}


		public AltroTitolo getAltroTitoloSelezionato() {
			return altroTitoloSelezionato;
		}


		public void setAltroTitoloSelezionato(AltroTitolo altroTitoloSelezionato) {
			this.altroTitoloSelezionato = altroTitoloSelezionato;
		}


		public CorsoAgg getCorsoAgg() {
			return corsoAgg;
		}


		public void setCorsoAgg(CorsoAgg corsoAgg) {
			this.corsoAgg = corsoAgg;
		}


		public CorsoAgg getCorsoAggSelezionato() {
			return corsoAggSelezionato;
		}


		public void setCorsoAggSelezionato(CorsoAgg corsoAggSelezionato) {
			this.corsoAggSelezionato = corsoAggSelezionato;
		}


		public Pubblicazione getPubblicazione() {
			return pubblicazione;
		}


		public void setPubblicazione(Pubblicazione pubblicazione) {
			this.pubblicazione = pubblicazione;
		}


		public Pubblicazione getPubblicazioneSelezionata() {
			return pubblicazioneSelezionata;
		}


		public void setPubblicazioneSelezionata(Pubblicazione pubblicazioneSelezionata) {
			this.pubblicazioneSelezionata = pubblicazioneSelezionata;
		}


		public List<AltraLaureaBis> getListaAltreLaureeBis() {
			return listaAltreLaureeBis;
		}


		public void setListaAltreLaureeBis(ArrayList<AltraLaureaBis> listaAltreLaureeBis) {
			this.listaAltreLaureeBis = listaAltreLaureeBis;
		}



		public List<Specializzazione> getListaSpecializzazioni() {
			return listaSpecializzazioni;
		}


		public void setListaSpecializzazioni(
				ArrayList<Specializzazione> listaSpecializzazioni) {
			this.listaSpecializzazioni = listaSpecializzazioni;
		}


		public List<BorsaStudio> getListaBorseStudio() {
			return listaBorseStudio;
		}


		public void setListaBorseStudio(ArrayList<BorsaStudio> listaBorseStudio) {
			this.listaBorseStudio = listaBorseStudio;
		}


		public List<Dottorato> getListaDottorati() {
			return listaDottorati;
		}


		public void setListaDottorati(ArrayList<Dottorato> listaDottorati) {
			this.listaDottorati = listaDottorati;
		}


		public List<AltroTitolo> getListaAltriTitoli() {
			return listaAltriTitoli;
		}


		public void setListaAltriTitoli(ArrayList<AltroTitolo> listaAltriTitoli) {
			this.listaAltriTitoli = listaAltriTitoli;
		}


		public List<CorsoAgg> getListaCorsiAgg() {
			return listaCorsiAgg;
		}


		public void setListaCorsiAgg(ArrayList<CorsoAgg> listaCorsiAgg) {
			this.listaCorsiAgg = listaCorsiAgg;
		}


		public List<Pubblicazione> getListaPubblicazioni() {
			return listaPubblicazioni;
		}


		public void setListaPubblicazioni(ArrayList<Pubblicazione> listaPubblicazioni) {
			this.listaPubblicazioni = listaPubblicazioni;
		}
       
		public boolean isIdonNazValidRequired() {
			return idonNazValidRequired;
		}


		public void setIdonNazValidRequired(boolean idonNazValidRequired) {
			this.idonNazValidRequired = idonNazValidRequired;
		}


		public String getFlagIdoneitaSediIdoneita() {
			return flagIdoneitaSediIdoneita;
		}


		public void setFlagIdoneitaSediIdoneita(String flagIdoneitaSediIdoneita) {
			this.flagIdoneitaSediIdoneita = flagIdoneitaSediIdoneita;
		}


		public String getEstremiIdoneita() {
			return estremiIdoneita;
		}


		public void setEstremiIdoneita(String estremiIdoneita) {
			this.estremiIdoneita = estremiIdoneita;
		}


		public Date getDataIdoneita() {
			return dataIdoneita;
		}


		public void setDataIdoneita(Date dataIdoneita) {
			if(dataIdoneita!=null)
				dataIdoneitaString=StringUtil.dateToStringDDMMYYYY(dataIdoneita);
			this.dataIdoneita = dataIdoneita;
		}
		
		public String getDataIdoneitaString() {
			return dataIdoneitaString;
		}

		public void setDataIdoneitaString(String dataIdoneitaString) {
			this.dataIdoneitaString = dataIdoneitaString;
		}

		public String getRifIdoneitaNazionale() {
			return rifIdoneitaNazionale;
		}

		public void setRifIdoneitaNazionale(String rifIdoneitaNazionale) {
			this.rifIdoneitaNazionale = rifIdoneitaNazionale;
		}

		public String getAnnoIdoneitaNazionale() {
			return annoIdoneitaNazionale;
		}

		public void setAnnoIdoneitaNazionale(String annoIdoneitaNazionale) {
			this.annoIdoneitaNazionale = annoIdoneitaNazionale;
		}


		public boolean isVisualizzaPanelBancario() {
			return visualizzaPanelBancario;
		}


		public void setVisualizzaPanelBancario(boolean visualizzaPanelBancario) {
			this.visualizzaPanelBancario = visualizzaPanelBancario;
		}


		public boolean isVisualizzaPanelPostale() {
			return visualizzaPanelPostale;
		}


		public void setVisualizzaPanelPostale(boolean visualizzaPanelPostale) {
			this.visualizzaPanelPostale = visualizzaPanelPostale;
		}


		public DatiBando getDatiBando() {
			return datiBando;
		}


		public void setDatiBando(DatiBando datiBando) {
			this.datiBando = datiBando;
		}


		public String getTipologiaVersamento() {
			return tipologiaVersamento;
		}


		public void setTipologiaVersamento(String tipologiaVersamento) {
			this.tipologiaVersamento = tipologiaVersamento;
		}


		public String getContributoPartecipazione() {
			return contributoPartecipazione;
		}


		public void setContributoPartecipazione(String contributoPartecipazione) {
			this.contributoPartecipazione = contributoPartecipazione;
		}


		public boolean isMostraPanelBancario() {
			return mostraPanelBancario;
		}


		public void setMostraPanelBancario(boolean mostraPanelBancario) {
			this.mostraPanelBancario = mostraPanelBancario;
		}


		public boolean isMostraPanelPostale() {
			return mostraPanelPostale;
		}


		public void setMostraPanelPostale(boolean mostraPanelPostale) {
			this.mostraPanelPostale = mostraPanelPostale;
		}


		public String getDataInizioCorsoReg() {
			return dataInizioCorsoReg;
		}


		public void setDataInizioCorsoReg(String dataInizioCorsoReg) {
			this.dataInizioCorsoReg = dataInizioCorsoReg;
		}


		public String getDataInizioPubblicazioneReg() {
			return dataInizioPubblicazioneReg;
		}


		public void setDataInizioPubblicazioneReg(String dataInizioPubblicazioneReg) {
			this.dataInizioPubblicazioneReg = dataInizioPubblicazioneReg;
		}

		
		
		
}
