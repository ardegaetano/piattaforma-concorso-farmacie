package com.accenture.CCFarm.PageBean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.accenture.CCFarm.Bean.ComuneSelect;
import com.accenture.CCFarm.Bean.NazioneSelect;
import com.accenture.CCFarm.Bean.ProvinciaSelect;
import com.accenture.CCFarm.Bean.RegioneSelect;
import com.accenture.CCFarm.DAO.FarmacieSearch;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.RicercaFarmacieAction;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;


@ManagedBean
@SessionScoped
public class RicercaFarmacieBean
{
	//membri per le localit� --------------------------------------------------------------------------------------------------------------
	private List<NazioneSelect> nazioniSelect;
	private List<RegioneSelect> regioniSelect;
	private HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect;
	private HashMap<String, ArrayList<ComuneSelect>> comuniSelect;
	private ArrayList<ComuneSelect> comuniList;
	private ArrayList<ProvinciaSelect> provinceList;
	private boolean attivaProvincia=true;
	private boolean attivaComune = true;
	
	private String regioneSelezionata,provinciaSelezionata,comuneSelezionato;
	//--------------------------------------------------------------------------------------------------------------
	private String indirizzo="";
	private String partitaIVA="";
	private String codCap="";
	private FarmacieSearch farmaciaSelected;
	private List<FarmacieSearch>  listaFarmacie;
	RicercaFarmacieAction ricercaFarmacieAction;
	Logger logger = CommonLogger.getLogger("RicercaFarmacieBean");
	
	
	public RicercaFarmacieBean(){
		
		 listaFarmacie= new ArrayList<FarmacieSearch>();
		 ricercaFarmacieAction =new RicercaFarmacieAction();
		 init();
		
	}	
	

	public void init(){
		
		 setRegioniSelect(Localita.getRegioni());
		
	}
	
	
	
	public void regioneCambiata(javax.faces.event.AjaxBehaviorEvent event)
	{
		String sourceId=event.getComponent().getId();
		//carica tutti le province appartenenti alla regione selezionata
		if(sourceId.equals("regione")){
			 setProvinceSelect(Localita.getProvince(regioneSelezionata));
			 provinceList=provinceSelect.get(regioneSelezionata);
			 setAttivaProvincia(false);
			 setAttivaComune(true);
			 RequestContext.getCurrentInstance().update(JSFUtility.getClientId("provincia"));
	}
		}
	
	public void provinciaCambiata(javax.faces.event.AjaxBehaviorEvent event)
	{
		String sourceId=event.getComponent().getId();
		//carica tutti i comuni appartenenti alla provincia selezionata
		if(sourceId.equals("provincia")){
			setComuniSelect(Localita.getComuni(provinciaSelezionata));
			comuniList=comuniSelect.get(provinciaSelezionata);
			setAttivaComune(false);
			RequestContext.getCurrentInstance().update(JSFUtility.getClientId("comune"));
		}
		}
	

	public void ricercaFrama(){
		try{
			setListaFarmacie(ricercaFarmacieAction.ricerca(this));
			FarmacieSearch farmacieSearch = new FarmacieSearch();
			farmacieSearch.setCodCap("44");
			farmacieSearch.setDesComu("comune1");
			farmacieSearch.setDesSede("sede3");
			listaFarmacie.add(farmacieSearch);
		RequestContext.getCurrentInstance().update(JSFUtility.getClientId("risultatoRicerca"));
		} catch (GestioneErroriException e) {
			logger.error("RicercaFarmacieBean - ricercaFrama: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
		
		
	}
	
	public void selezionaFarmacia(){
		
			Localita localita= new Localita();
			String indirizzso = farmaciaSelected.getIndirizzo();
			String cap = farmaciaSelected.getCodCap();
			String regione = localita.getDenominazioneRegione(farmaciaSelected.getCodRg());
			String provincia =  localita.getDenominazioneProvincia(farmaciaSelected.getCodIstatProv());
			String comune = localita.getDenominazioneComune(farmaciaSelected.getCodIstatComu()); 
			String aslRif = farmaciaSelected.getAslRif();
		
		}
	
	
	public List<NazioneSelect> getNazioniSelect() {
		return nazioniSelect;
	}

	public void setNazioniSelect(List<NazioneSelect> nazioniSelect) {
		this.nazioniSelect = nazioniSelect;
	}

	public List<RegioneSelect> getRegioniSelect() {
		return regioniSelect;
	}

	public void setRegioniSelect(List<RegioneSelect> regioniSelect) {
		this.regioniSelect = regioniSelect;
	}

	public HashMap<String, ArrayList<ProvinciaSelect>> getProvinceSelect() {
		return provinceSelect;
	}

	public void setProvinceSelect(
			HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect) {
		this.provinceSelect = provinceSelect;
	}

	public HashMap<String, ArrayList<ComuneSelect>> getComuniSelect() {
		return comuniSelect;
	}

	public void setComuniSelect(
			HashMap<String, ArrayList<ComuneSelect>> comuniSelect) {
		this.comuniSelect = comuniSelect;
	}

	public ArrayList<ComuneSelect> getComuniList() {
		return comuniList;
	}

	public void setComuniList(ArrayList<ComuneSelect> comuniList) {
		this.comuniList = comuniList;
	}

	public ArrayList<ProvinciaSelect> getProvinceList() {
		return provinceList;
	}

	public void setProvinceList(ArrayList<ProvinciaSelect> provinceList) {
		this.provinceList = provinceList;
	}

	public String getRegioneSelezionata() {
		return regioneSelezionata;
	}

	public void setRegioneSelezionata(String regioneSelezionata) {
		this.regioneSelezionata = regioneSelezionata;
	}

	

	public String getProvinciaSelezionata() {
		return provinciaSelezionata;
	}


	public void setProvinciaSelezionata(String provinciaSelezionata) {
		this.provinciaSelezionata = provinciaSelezionata;
	}


	public String getComuneSelezionato() {
		return comuneSelezionato;
	}

	public void setComuneSelezionato(String comuneSelezionato) {
		this.comuneSelezionato = comuneSelezionato;
	}
	//--------------------------------------------------------------------------------------------------------------
		
	public String getIndirizzo() {
		return indirizzo;
	}


	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}


	public RicercaFarmacieAction getRicercaFarmacieAction() {
		return ricercaFarmacieAction;
	}


	public void setRicercaFarmacieAction(RicercaFarmacieAction ricercaFarmacieAction) {
		this.ricercaFarmacieAction = ricercaFarmacieAction;
	}


	public String getPartitaIVA() {
		return partitaIVA;
	}


	public void setPartitaIVA(String partitaIVA) {
		this.partitaIVA = partitaIVA;
	}

	
	
	

	public List<FarmacieSearch> getListaFarmacie() {
		return listaFarmacie;
	}


	public void setListaFarmacie(List<FarmacieSearch> listaFarmacie) {
		this.listaFarmacie = listaFarmacie;
	}


	public boolean isAttivaProvincia() {
		return attivaProvincia;
	}

	public void setAttivaProvincia(boolean attivaProvincia) {
		this.attivaProvincia = attivaProvincia;
	}

	public boolean isAttivaComune() {
		return attivaComune;
	}

	public void setAttivaComune(boolean attivaComune) {
		this.attivaComune = attivaComune;
	}
	

	public String getCodCap() {
		return codCap;
	}

	public void setCodCap(String codCap) {
		this.codCap = codCap;
	}

	
	
	public FarmacieSearch getFarmaciaSelected() {
		return farmaciaSelected;
	}


	public void setFarmaciaSelected(FarmacieSearch farmaciaSelected) {
		this.farmaciaSelected = farmaciaSelected;
	}


	//ritorna l'istanza sessione http corrente 
	private HttpSession getSessionScope(){
			return (HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		}
		//ritorna l'oggetto in sessione individuato da "attribute"
	private Object getSessionAttribute(String attribute){
			return getSessionScope().getAttribute(attribute);
		}
	
}