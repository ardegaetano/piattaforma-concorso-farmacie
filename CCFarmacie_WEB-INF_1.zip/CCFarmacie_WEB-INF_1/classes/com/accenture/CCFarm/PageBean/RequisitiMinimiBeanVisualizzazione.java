package com.accenture.CCFarm.PageBean;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.ComuneSelect;
import com.accenture.CCFarm.Bean.NazioneSelect;
import com.accenture.CCFarm.Bean.ProvinciaSelect;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.RequisitiMinimiAction;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.StringUtil;

@ManagedBean
@RequestScoped
public class RequisitiMinimiBeanVisualizzazione
{
	//dati relativi alle localit�
	private HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect;
	private HashMap<String, ArrayList<ComuneSelect>> comuniSelect;
	private List<NazioneSelect> nazioniSEEList;
	private ArrayList<ProvinciaSelect> provinceList;
	private ArrayList<ComuneSelect> comuniResidenzaList,comuniElettoraliList;
	
	private String regioneSelezionata,provinciaSelezionata,comuneSelezionato;
	
	//Tabelle del db coinvolte: "Utente","RequisitiMinimi","Nazioni","Province","Comuni"
	//Dati Anagrafici
	private String cognomeUtente;
	private String nomeUtente;
	private Date dataNascitaUtente;
	private String dataNascitaString;
	private String sesso;
	
	private String nazioneNascitaUtente;
	private String luogoNascitaUtente;
	private String luogoNascitaEstera;
	private String prvNascitaUtente;
	private String codiceFiscaleUtente;
	private String estremiDocumentoIdentitaUtente;
	
	//Dati Residenza
	private String nazioneResidenzaUtente;
	private String localitaResidenzaEstera;
	private String indirizzoResidenza;
	private String prvAttualeAlbo;
	private String prvResidenzaUtente;
	private String comuneResidenzaUtente;
	private String capResidenzaUtente;
	private String nTelefonoUtente;
	private String nCellulareUtente;
	private String pecMail;
	
	//Fattispecie di appartenenza
	private String fattispecieAppartenenza;
	
	//Cittadinanza e Diritti Civili e Politici
	private String statoUe;
	private String provinciaListaElettorale;
	private String comuneListaElettorale;
	private String flagDirittiPoliticiCivili;
	
	//Iscrizione all'albo professionale dei Farmacisti
	private String flagIscrizioneAlbo;
	private String prvAlbo;
	private Date dataAlbo;
	private String dataAlboString;
	private String NAlbo;
	
	//Per la sola PA di Bolzano
	private boolean isBolzano;
	private String attestato;
	
	//Laurea Principale
	private String codTipoLaurea;
	private String descrUniversita;
	private String luogoLaurea;
	private Date dataLaurea;
	private String dataLaureaString;
	private String votoLaurea;
	private String baseVotoLaurea;
	private String flagLode;
	
	//Abilitazione
	private String descrUniAbilitazione;
	private String luogoUniAbilitazione;
	private String annoAbilitazione;
	private String votoAbilitazione;
	private String baseVotoAbilitazione;
	private String nazioneAbilitazione;
	private String estremiAbilitazioneEstera;
	
	//Condanne e procedimenti Penali
	private String flagNnCondannePenali;
	
	//Titolarit� di farmacia
	private String flagNnCessioneFarm;
	
	//Limite alla partecipazione
	private String flagNnPartecipazioneMultipla;
	
	RequisitiMinimiAction requisitiMinimiAction;
	Logger logger = CommonLogger.getLogger("RequisitiMinimiBeanVisualizzazione");
	
	private String linguaScelta="it";
	
	public RequisitiMinimiBeanVisualizzazione()
	{
		requisitiMinimiAction=new RequisitiMinimiAction();
	}
	
	public boolean init(String idUtente)
	{
		try
		{
			//inizializza localit�
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			if(lingua!=null){
				linguaScelta=lingua;
			}
			
			
			return requisitiMinimiAction.initVisualizzazione(idUtente,this);
		}
		catch (GestioneErroriException e)
		{
			logger.error("RequisitiMinimiBeanVisualizzazione - init: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
			return false;
		}
	}
	
	//inizializza il bean a partire dal relativo bean in compilazione
	public void init(RequisitiMinimiBean requisitiMinimiBean) throws Exception
	{
		requisitiMinimiAction.initVisualizzazione(requisitiMinimiBean,this);
	}
	
	//------------------------------------------------------------------------------------------------------------
	
	public HashMap<String, ArrayList<ComuneSelect>> getComuniSelect() {
		return comuniSelect;
	}
	
	public HashMap<String, ArrayList<ProvinciaSelect>> getProvinceSelect() { 
		return provinceSelect;
	}

	public void setProvinceSelect(
			HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect) {
		this.provinceSelect = provinceSelect;
	}

	public void setComuniSelect(
			HashMap<String, ArrayList<ComuneSelect>> comuniSelect) {
		this.comuniSelect = comuniSelect;
	}
	
	public List<NazioneSelect> getNazioniSEEList() {
		return nazioniSEEList;
	}
	
	public void setNazioniSEEList(List<NazioneSelect> nazioniSEEList) {
		this.nazioniSEEList = nazioniSEEList;
	}

	public ArrayList<ProvinciaSelect> getProvinceList() {
		return provinceList;
	}
	
	public void setProvinceList(ArrayList<ProvinciaSelect> provinceList) {
		this.provinceList = provinceList;
	}
	
	public ArrayList<ComuneSelect> getComuniResidenzaList() {
		return comuniResidenzaList;
	}

	public void setComuniResidenzaList(ArrayList<ComuneSelect> comuniResidenzaList) {
		this.comuniResidenzaList = comuniResidenzaList;
	}

	public ArrayList<ComuneSelect> getComuniElettoraliList() {
		return comuniElettoraliList;
	}

	public void setComuniElettoraliList(ArrayList<ComuneSelect> comuniElettoraliList) {
		this.comuniElettoraliList = comuniElettoraliList;
	}
	
	//-----------------
	
	public String getRegioneSelezionata() {
		return regioneSelezionata;
	}

	public void setRegioneSelezionata(String regioneSelezionata) {
		this.regioneSelezionata = regioneSelezionata;
	}

	public String getProvinciaSelezionata() {
		return provinciaSelezionata;
	}

	public void setProvinciaSelezionata(String provinciaSelezionata) {
		this.provinciaSelezionata = provinciaSelezionata;
	}

	public String getComuneSelezionato() {
		return comuneSelezionato;
	}

	public void setComuneSelezionato(String comuneSelezionato) {
		this.comuneSelezionato = comuneSelezionato;
	}
	
	public String getCognomeUtente() {
		return cognomeUtente;
	}

	public void setCognomeUtente(String cognomeUtente) {
		this.cognomeUtente = cognomeUtente;
	}

	public String getNomeUtente() {
		return nomeUtente;
	}

	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}

	public Date getDataNascitaUtente() {
		return dataNascitaUtente;
	}
	
	public void setDataNascitaUtente(Date dataNascitaUtente) {
		if(dataNascitaUtente!=null)
			dataNascitaString=StringUtil.dateToStringDDMMYYYY(dataNascitaUtente);
		this.dataNascitaUtente = dataNascitaUtente;
	}
	
	public String getDataNascitaString() {
		return dataNascitaString;
	}

	public void setDataNascitaString(String dataNascitaString) {
		this.dataNascitaString = dataNascitaString;
	}
	
	public String getSesso() {
		return sesso;
	}

	public void setSesso(String sesso) {
		this.sesso = sesso;
	}

	public String getPrvNascitaUtente() {
		return prvNascitaUtente;
	}

	public void setPrvNascitaUtente(String prvNascitaUtente) {
		this.prvNascitaUtente = prvNascitaUtente;
	}

	public String getCodiceFiscaleUtente() {
		return codiceFiscaleUtente;
	}

	public void setCodiceFiscaleUtente(String codiceFiscaleUtente) {
		this.codiceFiscaleUtente = codiceFiscaleUtente;
	}
	
	public String getEstremiDocumentoIdentitaUtente() {
		return estremiDocumentoIdentitaUtente;
	}

	public void setEstremiDocumentoIdentitaUtente(
			String estremiDocumentoIdentitaUtente) {
		this.estremiDocumentoIdentitaUtente = estremiDocumentoIdentitaUtente;
	}

	public String getIndirizzoResidenza() {
		return indirizzoResidenza;
	}

	public void setIndirizzoResidenza(String indirizzoResidenza) {
		this.indirizzoResidenza = indirizzoResidenza;
	}
	
	public String getPrvResidenzaUtente() {
		return prvResidenzaUtente;
	}

	public void setPrvResidenzaUtente(String prvResidenzaUtente) {
		this.prvResidenzaUtente = prvResidenzaUtente;
	}

	public String getComuneResidenzaUtente() {
		return comuneResidenzaUtente;
	}

	public void setComuneResidenzaUtente(String comuneResidenzaUtente) {
		this.comuneResidenzaUtente = comuneResidenzaUtente;
	}

	public String getCapResidenzaUtente() {
		return capResidenzaUtente;
	}

	public void setCapResidenzaUtente(String capResidenzaUtente) {
		this.capResidenzaUtente = capResidenzaUtente;
	}

	public String getnTelefonoUtente() {
		return nTelefonoUtente;
	}

	public void setnTelefonoUtente(String nTelefonoUtente) {
		this.nTelefonoUtente = nTelefonoUtente;
	}

	public String getnCellulareUtente() {
		return nCellulareUtente;
	}

	public void setnCellulareUtente(String nCellulareUtente) {
		this.nCellulareUtente = nCellulareUtente;
	}

	public String getPecMail() {
		return pecMail;
	}

	public void setPecMail(String pecMail) {
		this.pecMail = pecMail;
	}

	public String getFattispecieAppartenenza() {
		return fattispecieAppartenenza;
	}

	public void setFattispecieAppartenenza(String fattispecieAppartenenza) {
		this.fattispecieAppartenenza = fattispecieAppartenenza;
	}

	public String getStatoUe() {
		return statoUe;
	}

	public void setStatoUe(String statoUe) {
		this.statoUe = statoUe;
	}
	
	public String getProvinciaListaElettorale() {
		return provinciaListaElettorale;
	}

	public void setProvinciaListaElettorale(String provinciaListaElettorale) {
		this.provinciaListaElettorale = provinciaListaElettorale;
	}

	public String getComuneListaElettorale() {
		return comuneListaElettorale;
	}

	public void setComuneListaElettorale(String comuneListaElettorale) {
		this.comuneListaElettorale = comuneListaElettorale;
	}

	public String getFlagDirittiPoliticiCivili() {
		return flagDirittiPoliticiCivili;
	}

	public void setFlagDirittiPoliticiCivili(String flagDirittiPoliticiCivili) {
		this.flagDirittiPoliticiCivili = flagDirittiPoliticiCivili;
	}

	public String getFlagIscrizioneAlbo() {
		return flagIscrizioneAlbo;
	}

	public void setFlagIscrizioneAlbo(String flagIscrizioneAlbo) {
		this.flagIscrizioneAlbo = flagIscrizioneAlbo;
	}
	
	public String getPrvAlbo() {
		return prvAlbo;
	}

	public void setPrvAlbo(String prvAlbo) {
		this.prvAlbo = prvAlbo;
	}

	public Date getDataAlbo() {
		return dataAlbo;
	}
	
	public void setDataAlbo(Date dataAlbo) {
		if(dataAlbo!=null)
			dataAlboString = StringUtil.dateToStringDDMMYYYY(dataAlbo);
		this.dataAlbo = dataAlbo;
	}

	public String getNAlbo() {
		return NAlbo;
	}

	public void setNAlbo(String nAlbo) {
		NAlbo = nAlbo;
	}
	
	public boolean getIsBolzano() {
		return isBolzano;
	}

	public void setIsBolzano(boolean isBolzano) {
		this.isBolzano = isBolzano;
	}

	public String getAttestato() {
		return attestato;
	}

	public void setAttestato(String attestato) {
		this.attestato = attestato;
	}

	public String getCodTipoLaurea() {
		return codTipoLaurea;
	}

	public void setCodTipoLaurea(String codTipoLaurea) {
		this.codTipoLaurea = codTipoLaurea;
	}

	public String getDescrUniversita() {
		return descrUniversita;
	}

	public void setDescrUniversita(String descrUniversita) {
		this.descrUniversita = descrUniversita;
	}

	public String getLuogoLaurea() {
		return luogoLaurea;
	}

	public void setLuogoLaurea(String luogoLaurea) {
		this.luogoLaurea = luogoLaurea;
	}

	public Date getDataLaurea() {
		return dataLaurea;
	}

	public void setDataLaurea(Date dataLaurea) {
		if(dataLaurea!=null)
			dataLaureaString = StringUtil.dateToStringDDMMYYYY(dataLaurea);
		this.dataLaurea = dataLaurea;
	}

	public String getFlagLode() {
		return flagLode;
	}

	public void setFlagLode(String flagLode) {
		this.flagLode = flagLode;
	}

	public String getDescrUniAbilitazione() {
		return descrUniAbilitazione;
	}

	public void setDescrUniAbilitazione(String descrUniAbilitazione) {
		this.descrUniAbilitazione = descrUniAbilitazione;
	}

	public String getLuogoUniAbilitazione() {
		return luogoUniAbilitazione;
	}

	public void setLuogoUniAbilitazione(String luogoUniAbilitazione) {
		this.luogoUniAbilitazione = luogoUniAbilitazione;
	}


	public String getNazioneAbilitazione() {
		return nazioneAbilitazione;
	}

	public void setNazioneAbilitazione(String nazioneAbilitazione) {
		this.nazioneAbilitazione = nazioneAbilitazione;
	}
	
	public String getEstremiAbilitazioneEstera() {
		return estremiAbilitazioneEstera;
	}

	public void setEstremiAbilitazioneEstera(String estremiAbilitazioneEstera) {
		this.estremiAbilitazioneEstera = estremiAbilitazioneEstera;
	}

	public String getFlagNnCondannePenali() {
		return flagNnCondannePenali;
	}

	public void setFlagNnCondannePenali(String flagNnCondannePenali) {
		this.flagNnCondannePenali = flagNnCondannePenali;
	}

	public String getFlagNnCessioneFarm() {
		return flagNnCessioneFarm;
	}

	public void setFlagNnCessioneFarm(String flagNnCessioneFarm) {
		this.flagNnCessioneFarm = flagNnCessioneFarm;
	}

	public String getFlagNnPartecipazioneMultipla() {
		return flagNnPartecipazioneMultipla;
	}

	public void setFlagNnPartecipazioneMultipla(String flagNnPartecipazioneMultipla) {
		this.flagNnPartecipazioneMultipla = flagNnPartecipazioneMultipla;
	}

	public RequisitiMinimiAction getRequisitiMinimiAction() {
		return requisitiMinimiAction;
	}

	public void setRequisitiMinimiAction(RequisitiMinimiAction requisitiMinimiAction) {
		this.requisitiMinimiAction = requisitiMinimiAction;
	}

	public String getLuogoNascitaEstera() {
		return luogoNascitaEstera;
	}

	public void setLuogoNascitaEstera(String luogoNascitaEstera) {
		this.luogoNascitaEstera = luogoNascitaEstera;
	}

	public String getNazioneNascitaUtente() {
		return nazioneNascitaUtente;
	}

	public void setNazioneNascitaUtente(String nazioneNascitaUtente) {
		this.nazioneNascitaUtente = nazioneNascitaUtente;
	}

	public String getLuogoNascitaUtente() {
		return luogoNascitaUtente;
	}

	public void setLuogoNascitaUtente(String luogoNascitaUtente) {
		this.luogoNascitaUtente = luogoNascitaUtente;
	}

	public String getVotoLaurea() {
		return votoLaurea;
	}

	public void setVotoLaurea(String votoLaurea) {
		this.votoLaurea = votoLaurea;
	}

	public String getBaseVotoLaurea() {
		return baseVotoLaurea;
	}

	public void setBaseVotoLaurea(String baseVotoLaurea) {
		this.baseVotoLaurea = baseVotoLaurea;
	}

	public String getAnnoAbilitazione() {
		return annoAbilitazione;
	}

	public void setAnnoAbilitazione(String annoAbilitazione) {
		this.annoAbilitazione = annoAbilitazione;
	}

	public String getVotoAbilitazione() {
		return votoAbilitazione;
	}

	public void setVotoAbilitazione(String votoAbilitazione) {
		this.votoAbilitazione = votoAbilitazione;
	}

	public String getBaseVotoAbilitazione() {
		return baseVotoAbilitazione;
	}

	public void setBaseVotoAbilitazione(String baseVotoAbilitazione) {
		this.baseVotoAbilitazione = baseVotoAbilitazione;
	}

	public String getDataAlboString() {
		return dataAlboString;
	}

	public void setDataAlboString(String dataAlboString) {
		this.dataAlboString = dataAlboString;
	}

	public String getDataLaureaString() {
		return dataLaureaString;
	}

	public void setDataLaureaString(String dataLaureaString) {
		this.dataLaureaString = dataLaureaString;
	}

	public String getNazioneResidenzaUtente() {
		return nazioneResidenzaUtente;
	}

	public void setNazioneResidenzaUtente(String nazioneResidenzaUtente) {
		this.nazioneResidenzaUtente = nazioneResidenzaUtente;
	}

	public String getLocalitaResidenzaEstera() {
		return localitaResidenzaEstera;
	}

	public void setLocalitaResidenzaEstera(String localitaResidenzaEstera) {
		this.localitaResidenzaEstera = localitaResidenzaEstera;
	}

	public String getPrvAttualeAlbo() {
		return prvAttualeAlbo;
	}

	public void setPrvAttualeAlbo(String prvAttualeAlbo) {
		this.prvAttualeAlbo = prvAttualeAlbo;
	}

	public String getLinguaScelta() {
		return linguaScelta;
	}

	public void setLinguaScelta(String linguaScelta) {
		this.linguaScelta = linguaScelta;
	}

	
	
}