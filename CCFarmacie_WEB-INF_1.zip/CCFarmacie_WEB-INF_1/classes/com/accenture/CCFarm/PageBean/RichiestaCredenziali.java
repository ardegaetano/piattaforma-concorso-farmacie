package com.accenture.CCFarm.PageBean;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.ComuneSelect;
import com.accenture.CCFarm.Bean.DocumentoIdentita;
import com.accenture.CCFarm.Bean.NazioneSelect;
import com.accenture.CCFarm.Bean.ProvinciaSelect;
import com.accenture.CCFarm.Bean.RegioneSelect;
import com.accenture.CCFarm.Bean.UtenteAssociato;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.RichiestaCredenzialiAction;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.HelpDe;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.TabellaDecodifica;

@ManagedBean
@SessionScoped
public class RichiestaCredenziali {
	
	//dati per il captcha -------------
	private String captchaCode;
	private String captchaGenerator;
	//---------------------------------
	
	private String codTipoDomanda;
	private String codTipoUtente;
	private String modalitaPartecipazione;
	
	//utente
	private String nomeUtente;
	private String cognomeUtente;
	private java.util.Date dataNascitaUtente;
	private String nazioneNascitaUtente;
	private String prvNascitaUtente;
	private String luogoNascitaUtente;
	private String luogoNascitaEstera;
	private String sesso;
	private String codiceFiscaleUtente;
	private String pecMail;
	
	private String replicaPecMail;
	
	private String flagCodiceFiscaleItaliano = "true";
	
	//documento
	private String tipoDocumento;
	private String numeroDoc;
	private String enteRilascioDoc;
	private java.util.Date dataRilascioDoc;
	
	//associato
	private boolean aggiungiAssociato=true;
	private UtenteAssociato utenteAssociato;
	private UtenteAssociato utenteSelezionato;
	private ArrayList<UtenteAssociato> listaAssociati;
	
	//dati localita'
	private List<NazioneSelect> nazioniSelect;
	private List<RegioneSelect> regioneSelect;
	private HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect;
	private HashMap<String, ArrayList<ComuneSelect>> comuniSelect;
	private ArrayList<ComuneSelect> comuniList,comuniListAssociato;
	private ArrayList<ProvinciaSelect> provinceList,provinceListAssociato;
	private List<DocumentoIdentita> documentiIdentita;

	private String regioneRichiesta;
	
	private boolean flagAccettazioneTermini = false;
	private boolean mostraTabella= false;
	
	private ArrayList<RichiestaCredenziali> richiesteCredenziali;
	private RichiestaCredenzialiAction richiestaCredenzialiAction;
	
	private String messaggioErrore = null;
	private String[] listaHelp;
	
	private String regioneSelezionata,provinciaSelezionata,comuneSelezionato;
	Logger logger = CommonLogger.getLogger("ConsultaSediBean");
	
	public RichiestaCredenziali()
	{
		 captchaGenerator=AppProperties.getAppProperty("bck_immage_path");
		 
		 utenteAssociato = new UtenteAssociato();
		 listaAssociati = new ArrayList<UtenteAssociato>();
		 richiestaCredenzialiAction = new RichiestaCredenzialiAction();
		 
		 HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		 String lingua= (String)session.getAttribute("linguaScelta");
		 
		//init Help
		 if(lingua.equals("it")){
			 setListaHelp(Help.caricaHelpDatiRegistrazione());
		 }else{
			 setListaHelp(HelpDe.caricaHelpDatiRegistrazione());
		 }
	}
	
	public boolean salvaCredenziali() throws GestioneErroriException
	{
		boolean result=false;
		
		RichiestaCredenzialiAction richiestaCredenzialiAction = new RichiestaCredenzialiAction();
		richiesteCredenziali = new ArrayList<RichiestaCredenziali>();
		try
		{
//			richiestaCredenzialiAction.checkRichiestaCredenziali(this);
			richiestaCredenzialiAction.insertRichiestaCredenziali(this);
			result = true;
		}
		catch(Exception e)
		{
			LogUtil.printException(e);
			GestioneErroriException eccezione = new GestioneErroriException("RichiestaCredenziali - salvaCredenziali: errore nell' inserimento delle credenziali");
			LogUtil.printException(eccezione);
			
			throw eccezione;
		}
		
		return result;
	}
	
	public boolean initLocalita() throws GestioneErroriException{
	    setNazioniSelect(Localita.getNazioni());
	    setProvinceSelect(Localita.getProvince("0"));
	    provinceList=provinceSelect.get("0");
	    provinceListAssociato=provinceSelect.get("0");
	   
	    try{
	    	documentiIdentita=TabellaDecodifica.getDocumentoIdentita();
	    }catch(Exception e){
	    	
	    	LogUtil.printException(e);
			GestioneErroriException eccezione = new GestioneErroriException("RichiestaCredenziali - caricamento dati: errore nel caricamento dei documenti");
			LogUtil.printException(eccezione);
			
			throw eccezione;
	    }
	    
	  return true;
	}
	
	public void nazioneCambiata(javax.faces.event.AjaxBehaviorEvent event)
	{
    	String sourceId=event.getComponent().getId();
    	
		if(sourceId.equals("statoNascita"))
		{
			prvNascitaUtente=null;
			luogoNascitaUtente=null;
			
			JSFUtility.update("pannelloLocalitaEstera");
			JSFUtility.update("pannelloComuni");
			setCodiceFiscaleUtente("");
		}
		if(sourceId.equals("statoNascitaAssociato"))
		{
			utenteAssociato.setPrvNascitaUtenteAssociato(null);
			utenteAssociato.setLuogoNascitaUtenteAssociato(null);
			
			JSFUtility.update("pannelloLocalitaEsteraAssociato");
			JSFUtility.update("pannelloComuniAssociato");
			utenteAssociato.setCodiceFiscaleUtenteAssociato("");
		}
	}
		
	public void provinciaCambiata(javax.faces.event.AjaxBehaviorEvent event)
	{
		String sourceId=event.getComponent().getId();
		
		//carica tutti i comuni appartenenti alla provincia selezionata
		
		if(sourceId.equals("prvNascita"))
		{
			setComuniSelect(Localita.getComuni(prvNascitaUtente));
			comuniList=comuniSelect.get(prvNascitaUtente);
			
			JSFUtility.update("comuneNascita");
		}
		if(sourceId.equals("prvNascitaUtenteAssociato"))
		{
			setComuniSelect(Localita.getComuni(utenteAssociato.getPrvNascitaUtenteAssociato()));
			comuniListAssociato=comuniSelect.get(utenteAssociato.getPrvNascitaUtenteAssociato());
			 
			JSFUtility.update("comuneNascitaUtenteAssociato");
			
		}
	}
	
	public void aggiornaCFAssociato()
	{
		utenteAssociato.setCodiceFiscaleUtenteAssociato("");
	}
	
	public void eliminaAssociato()
	{
		for(int i=0;i<listaAssociati.size();i++)
		{
			if(utenteSelezionato.getCodiceFiscaleUtenteAssociato()==listaAssociati.get(i).getCodiceFiscaleUtenteAssociato())
			{
				listaAssociati.remove(i);
			}
		}
		aggiungiNuovoAssociatoButton();
	}
	
	public void modificaAssociato()
	{
		try
		{
			BeanUtils.copyProperties(utenteAssociato, utenteSelezionato);
			for(int i=0;i<listaAssociati.size();i++)
			{
				if(utenteSelezionato.getCodiceFiscaleUtenteAssociato()==listaAssociati.get(i).getCodiceFiscaleUtenteAssociato())
				{
					listaAssociati.remove(i);
				}
			}
			
		}
		catch (IllegalAccessException e)
		{
			e.printStackTrace();
		}
		catch (InvocationTargetException e)
		{
			e.printStackTrace();
		}
	}
	
	public ArrayList<UtenteAssociato> aggiungiUtente() throws GestioneErroriException{
		UtenteAssociato utente2 = new UtenteAssociato();
		try
		{
			//Controllo e Generazione CF stranieri Associati
			if(!utenteAssociato.getNazioneNascitaUtenteAssociato().equals("IT")){ //Per nazione nascita diversa da Italia
				if(!utenteAssociato.getFlagCodiceFiscaleItalianoAssociato().equals("true")) { //Non in possesso di un codice fiscale Italiano
					String sCFCalc = StringUtil.generaCodiceFiscaleStraniero(utenteAssociato.getCognomeUtenteAssociato(), 
							utenteAssociato.getNomeUtenteAssociato(), 
							utenteAssociato.getDataNascitaAssociato(), 
							utenteAssociato.getNazioneNascitaUtenteAssociato(), 
							utenteAssociato.getLuogoNascitaEsteraUtenteAssociato(),
							utenteAssociato.getSessoAssociato());
					utenteAssociato.setCodiceFiscaleUtenteAssociato(sCFCalc);
				}
			}
			
			
			BeanUtils.copyProperties(utente2, utenteAssociato);
			listaAssociati.add(utente2);
			setMostraTabella(true);
			 
		}
		catch (IllegalAccessException e)
		{
			e.printStackTrace();
		}catch (InvocationTargetException e)
		{
			e.printStackTrace();
		}catch (Exception e)
		{
			throw new GestioneErroriException("RichiestaCredenziali - aggiungiUtente: errore aggiungiUtente");
		}

		return listaAssociati;
	}
	
	public void aggiungiNuovoAssociatoButton()
	{			
		utenteAssociato.setCodiceFiscaleUtenteAssociato("");
		utenteAssociato.setCognomeUtenteAssociato("");
		utenteAssociato.setDataNascitaAssociato(null);
		utenteAssociato.setDataNascitaAssociatoString("");
		utenteAssociato.setDataRilascioDocAssociato(null);
		utenteAssociato.setEnteRilascioDocAssociato("");
		utenteAssociato.setLuogoNascitaUtenteAssociato("");
		utenteAssociato.setNumeroDocAssociato("");
		utenteAssociato.setNomeUtenteAssociato("");
		utenteAssociato.setPecMailAssociato("");
		utenteAssociato.setSessoAssociato("");
		utenteAssociato.setNazioneNascitaUtenteAssociato("");
		utenteAssociato.setPrvNascitaUtenteAssociato("");
		utenteAssociato.setTipoDocumentoAssociato("");
		utenteAssociato.setLuogoNascitaEsteraUtenteAssociato("");
	}
	
	public boolean CheckUsers(){
		try {
			return richiestaCredenzialiAction.checkRichiestaCredenziali(this);
		}catch (GestioneErroriException e) {
			logger.error("RichiestaCredenziali - RichiestaCredenziali: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
		    return false;
		}
	}
	
	public String getCaptchaCode() {
		return captchaCode;
	}

	public void setCaptchaCode(String captchaCode) {
		this.captchaCode = captchaCode;
	}
	
	public String getCaptchaGenerator() {
		return captchaGenerator;
	}

	public void setCaptchaGenerator(String captchaGenerator) {
		this.captchaGenerator = captchaGenerator;
	}
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	public String getEnteRilascioDoc() {
		return enteRilascioDoc;
	}
	
	public void setEnteRilascioDoc(String enteRilascioDoc) {
		this.enteRilascioDoc = enteRilascioDoc;
	}
	
	public java.util.Date getDataRilascioDoc() {
		return dataRilascioDoc;
	}

	public void setDataRilascioDoc(java.util.Date dataRilascioDoc) {
		this.dataRilascioDoc = dataRilascioDoc;
	}

	public String getNumeroDoc() {
		return numeroDoc;
	}
	
	public void setNumeroDoc(String numeroDoc) {
		this.numeroDoc = numeroDoc;
	}
	
	public String getCodTipoDomanda() {
		return codTipoDomanda;
	}
	
	public void setCodTipoDomanda(String codTipoDomanda) {
		this.codTipoDomanda = codTipoDomanda;
	}
	
	public String getCodTipoUtente() {
		return codTipoUtente;
	}
	
	public void setCodTipoUtente(String codTipoUtente) {
		this.codTipoUtente = codTipoUtente;
	}
	
	public String getModalitaPartecipazione() {
		return modalitaPartecipazione;
	}
	
	public void setModalitaPartecipazione(String modalitaPartecipazione) {
		this.modalitaPartecipazione = modalitaPartecipazione;
	}
	public String getNomeUtente() {
		return nomeUtente;
	}
	
	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}
	
	public String getCognomeUtente() {
		return cognomeUtente;
	}
	
	public void setCognomeUtente(String cognomeUtente) {
		this.cognomeUtente = cognomeUtente;
	}
	
	public String getSesso() {
		return sesso;
	}
	
	public void setSesso(String sesso) {
		this.sesso = sesso;
	}
	
	public String getCodiceFiscaleUtente() {
		return codiceFiscaleUtente;
	}
	
	public void setCodiceFiscaleUtente(String codiceFiscaleUtente) {
		this.codiceFiscaleUtente = codiceFiscaleUtente;
	}
	
	public String getPecMail() {
		return pecMail;
	}
	
	public void setPecMail(String pecMail) {
		//imposta il nuovo valore (eliminando gli spazi)
		if(pecMail!=null)
		{
			this.pecMail=pecMail.trim();
		}
		else
		{
			this.pecMail=null;
		}
	}
	
	public String getReplicaPecMail() {
		return replicaPecMail;
	}

	public void setReplicaPecMail(String replicaPecMail) {
		//imposta il nuovo valore (eliminando gli spazi)
		if(replicaPecMail!=null)
		{
			this.replicaPecMail = replicaPecMail.trim();
		}
		else
		{
			this.replicaPecMail=null;
		}
	}

	public boolean isAggiungiAssociato() {
		return aggiungiAssociato;
	}

	public void setAggiungiAssociato(boolean aggiungiAssociato) {
		this.aggiungiAssociato = aggiungiAssociato;
	}
	
	public java.util.Date getDataNascitaUtente() {
		return dataNascitaUtente;
	}

	public void setDataNascitaUtente(java.util.Date dataNascitaUtente) {
		this.dataNascitaUtente = dataNascitaUtente;
	}
	
	public String getNazioneNascitaUtente() {
		return nazioneNascitaUtente;
	}

	public void setNazioneNascitaUtente(String nazioneNascitaUtente) {		
		this.nazioneNascitaUtente = nazioneNascitaUtente;
	}
	
	public String getPrvNascitaUtente() {
		return prvNascitaUtente;
	}

	public void setPrvNascitaUtente(String prvNascitaUtente) {
		this.prvNascitaUtente = prvNascitaUtente;
	}
	
	public String getLuogoNascitaUtente() {
		return luogoNascitaUtente;
	}

	public void setLuogoNascitaUtente(String luogoNascitaUtente) {
		this.luogoNascitaUtente = luogoNascitaUtente;
	}

	public UtenteAssociato getUtenteAssociato() {
		return utenteAssociato;
	}

	public void setUtenteAssociato(UtenteAssociato utenteAssociato) {
		this.utenteAssociato = utenteAssociato;
	}

	public ArrayList<UtenteAssociato> getListaAssociati() {
		return listaAssociati;
	}

	public void setListaAssociati(ArrayList<UtenteAssociato> listaAssociati) {
		this.listaAssociati = listaAssociati;
	}

	public boolean isMostraTabella() {
		return mostraTabella;
	}

	public void setMostraTabella(boolean mostraTabella) {
		this.mostraTabella = mostraTabella;
	}

	public UtenteAssociato getUtenteSelezionato() {
		return utenteSelezionato;
	}

	public void setUtenteSelezionato(UtenteAssociato utenteSelezionato) {
		this.utenteSelezionato = utenteSelezionato;
	}

	public ArrayList<RichiestaCredenziali> getRichiesteCredenziali() {
		return richiesteCredenziali;
	}

	public void setRichiesteCredenziali(
			ArrayList<RichiestaCredenziali> richiesteCredenziali) {
		this.richiesteCredenziali = richiesteCredenziali;
	}

	public RichiestaCredenzialiAction getRichiestaCredenzialiAction() {
		return richiestaCredenzialiAction;
	}

	public void setRichiestaCredenzialiAction(
			RichiestaCredenzialiAction richiestaCredenzialiAction) {
		this.richiestaCredenzialiAction = richiestaCredenzialiAction;
	}

	public String getRegioneSelezionata() {
		return regioneSelezionata;
	}

	public void setRegioneSelezionata(String regioneSelezionata) {
		this.regioneSelezionata = regioneSelezionata;
	}

	public String getProvinciaSelezionata() {
		return provinciaSelezionata;
	}

	public void setProvinciaSelezionata(String provinciaSelezionata) {
		this.provinciaSelezionata = provinciaSelezionata;
	}

	public String getComuneSelezionato() {
		return comuneSelezionato;
	}

	public void setComuneSelezionato(String comuneSelezionato) {
		this.comuneSelezionato = comuneSelezionato;
	}
	
	public List<NazioneSelect> getNazioniSelect() {
		return nazioniSelect;
	}

	public void setNazioniSelect(List<NazioneSelect> nazioniSelect) {
		this.nazioniSelect = nazioniSelect;
	}

	public List<RegioneSelect> getRegioneSelect() {
		return regioneSelect;
	}

	public void setRegioneSelect(List<RegioneSelect> regioneSelect) {
		this.regioneSelect = regioneSelect;
	}

	public HashMap<String, ArrayList<ProvinciaSelect>> getProvinceSelect() {
		return provinceSelect;
	}

	public void setProvinceSelect(
			HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect) {
		this.provinceSelect = provinceSelect;
	}

	public HashMap<String, ArrayList<ComuneSelect>> getComuniSelect() {
		return comuniSelect;
	}

	public void setComuniSelect(
			HashMap<String, ArrayList<ComuneSelect>> comuniSelect) {
		this.comuniSelect = comuniSelect;
	}

	public ArrayList<ComuneSelect> getComuniList() {
		return comuniList;
	}

	public void setComuniList(ArrayList<ComuneSelect> comuniList) {
		this.comuniList = comuniList;
	}
	
	public ArrayList<ComuneSelect> getComuniListAssociato() {
		return comuniListAssociato;
	}

	public void setComuniListAssociato(ArrayList<ComuneSelect> comuniListAssociato) {
		this.comuniListAssociato = comuniListAssociato;
	}

	public ArrayList<ProvinciaSelect> getProvinceListAssociato() {
		return provinceListAssociato;
	}

	public void setProvinceListAssociato(
			ArrayList<ProvinciaSelect> provinceListAssociato) {
		this.provinceListAssociato = provinceListAssociato;
	}

	public String getRegioneRichiesta() {
		return regioneRichiesta;
	}

	public void setRegioneRichiesta(String regioneRichiesta) {
		this.regioneRichiesta = regioneRichiesta;
	}

	public ArrayList<ProvinciaSelect> getProvinceList() {
		return provinceList;
	}

	public void setProvinceList(ArrayList<ProvinciaSelect> provinceList) {
		this.provinceList = provinceList;
	}
	
	public boolean getFlagAccettazioneTermini() {
		return flagAccettazioneTermini;
	}

	public void setFlagAccettazioneTermini(boolean flagAccettazioneTermini) {
		this.flagAccettazioneTermini = flagAccettazioneTermini;
	}
	
	public String getLuogoNascitaEstera() {
		return luogoNascitaEstera;
	}

	public void setLuogoNascitaEstera(String luogoNascitaEstera) {
		this.luogoNascitaEstera = luogoNascitaEstera;
	}
	
	public String getMessaggioErrore() {
		return messaggioErrore;
	}

	public void setMessaggioErrore(String messaggioErrore) {
		this.messaggioErrore = messaggioErrore;
	}
	
	public String[] getListaHelp() {
		return listaHelp;
	}

	public void setListaHelp(String[] listaHelp) {
		this.listaHelp = listaHelp;
	}

	public List<DocumentoIdentita> getDocumentiIdentita() {
		return documentiIdentita;
	}

	public void setDocumentiIdentita(List<DocumentoIdentita> documentiIdentita) {
		this.documentiIdentita = documentiIdentita;
	}

	public String getFlagCodiceFiscaleItaliano() {
		return flagCodiceFiscaleItaliano;
	}

	public void setFlagCodiceFiscaleItaliano(String flagCodiceFiscaleItaliano) {
		this.flagCodiceFiscaleItaliano = flagCodiceFiscaleItaliano;
	}
	
}