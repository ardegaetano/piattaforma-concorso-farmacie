package com.accenture.CCFarm.PageBean;


import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.DAO.RegioneDatiBando;
import com.accenture.CCFarm.utility.RepositorySession;


@ManagedBean
@RequestScoped
public class ErroreLoginCandidato {
	
	//utente
	private String returnString;
	private String messaggioErrore = null;
	
	
	
	public ErroreLoginCandidato(){
		try {
			this.init();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
		
	
	public void init() throws IllegalAccessException, InvocationTargetException {  

		FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	String idMsgError = (String) session.getAttribute(RepositorySession.IDMSG_ERROR_LOGIN);
    	if (idMsgError==null){
    		idMsgError="errore generico";
    	}
    	returnString = (String) session.getAttribute(RepositorySession.RETURN_ERROR_LOGIN);
    	if (returnString==null){
    		returnString="/loginCandidato";
    	}
    	
	    if (idMsgError.equals("00")){
	    	messaggioErrore = "Digitare correttamente User e Password";
//	    	returnString="loginCandidato.jsp";
	    } 
	    if (idMsgError.equals("01")){
	    	messaggioErrore = "Autenticazione non avvenuta, riprovare";
//	    	returnString="loginCandidato.jsp";
	    }
	    if (idMsgError.equals("02")){
	    	RegioneDatiBando bando= new RegioneDatiBando();
	    	bando = (RegioneDatiBando) session.getAttribute(RepositorySession.REGIONI_DATI_BANDO);
	    	messaggioErrore = "Utenza di accesso non corrisponde con la regione "+ bando.getDenominazioneReg();
//	    	returnString="loginCandidato.jsp";
	    }
	    if (idMsgError.equals("03")){
	    	ArrayList ldescrMsgError = (ArrayList) session.getAttribute(RepositorySession.DESCR_MSG_ERROR_CANDIDATI_NON_REGISTRATI);
	    	if(ldescrMsgError!=null && ldescrMsgError.size()>0){
	    		if(ldescrMsgError.size()==1) //Unico elemento
	    			messaggioErrore = "L'associato "+((String)ldescrMsgError.get(0)).toUpperCase()+" non ha completato la registrazione."; 
	    		else {
	    			messaggioErrore = "Gli associati:";
		    		for(int i=0; i<ldescrMsgError.size(); i++){
		    			String sDescr = " "+((String)ldescrMsgError.get(i)).toUpperCase()+", ";
		    			messaggioErrore = messaggioErrore + sDescr;
		    		}
		    		messaggioErrore = messaggioErrore + "non hanno completato la registrazione.";
	    		}	
	    		messaggioErrore = messaggioErrore + " Si prega di verificare  che la procedura sia stata completata correttamente da tutti i componenti dell'associazione";
	    	}	
	    	//messaggioErrore = "Uno o pi� associati non hanno completato la registrazione. Si prega di verificare  che la procedura sia stata completata correttamente da tutti i componenti dell'associazione";
//	    	returnString="loginCandidato.jsp";
	    }
	    if (idMsgError.equals("04")){
	    	messaggioErrore = "Bando Scaduto. Non � possibili accedere all�area riservata.";
//	    	returnString="loginCandidato.jsp";
	    }
	    if (idMsgError.equals("05I")){
	    	messaggioErrore = "Candidatura incompleta. Controllare la registrazione .";
//	    	returnString="loginCandidato.jsp";
	    }
	    if (idMsgError.equals("05R")){
	    	messaggioErrore = "Accesso ad una candidatura rifiutata. Non � possibile proseguire con l'autenticazione di questa Utenza";
//	    	returnString="loginCandidato.jsp";
	    }
	    if (idMsgError.equals("05A")){
	    	messaggioErrore = "Accesso ad una candidatura annullata. Non � possibile proseguire con l'autenticazione di questa Utenza";
//	    	returnString="loginCandidato.jsp";
	    }
	}

	
	
	
	
	
	
	public String getMessaggioErrore() {
		return messaggioErrore;
	}


	public void setMessaggioErrore(String messaggioErrore) {
		this.messaggioErrore = messaggioErrore;
	}


	public String getReturnString() {
		return returnString;
	}


	public void setReturnString(String returnString) {
		this.returnString = returnString;
	}


	
	
}
