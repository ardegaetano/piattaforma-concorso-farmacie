package com.accenture.CCFarm.PageBean;

import java.sql.Date;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.action.DichiarazioneSostitutivaAction;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;

public class DichiarazioneSostitutivaBeanVisualizzazione {

	private Date dataOperazione;
	private String dataOperazioneString;
	private String iban;
	private String cro;
	private Date dataVersamento;
	private String dataVersamentoString;
	private String numeroUffPostale;
	private String progressivoOperazione;
	private String flagDichiarazione;
	private String elencoDocumenti;
	
	private DatiBando datiBando;
	private String tipologiaVersamento;
	
	DichiarazioneSostitutivaAction dichiarazioneSostitutivaAction;
	
	public DichiarazioneSostitutivaBeanVisualizzazione()
	{
		dichiarazioneSostitutivaAction=new DichiarazioneSostitutivaAction();
	}
	
	//restituisce il tipo di versamento specificato nel bando - "Bancario" o "Postale"
	private void determinaTipologiaVersamento() throws Exception
	{
		datiBando=(DatiBando)GetSessionUtility.getSessionAttribute(RepositorySession.DATI_BANDO);
		if(datiBando!=null)
		{
			tipologiaVersamento=datiBando.getEstremiPagamento();
		}
		else
			throw new Exception("[Impossibile determinare tipologia versamento]");
	}
	
	public boolean init(String idUtente) throws Exception
	{
		determinaTipologiaVersamento();
		return dichiarazioneSostitutivaAction.loadPaginaInserimentoVisualizzazione(idUtente,this);
	}
	
	//inizializza il bean a partire dal relativo bean in compilazione
	public void init(DichiarazioneSostitutivaBean dichiarazioneSostitutivaBean) throws Exception
	{
		dichiarazioneSostitutivaAction.loadPaginaInserimentoVisualizzazione(dichiarazioneSostitutivaBean,this);
	}
	
	public Date getDataOperazione() {
		return dataOperazione;
	}

	public void setDataOperazione(Date dataOperazione) {
		if(dataOperazione!=null)
			dataOperazioneString=StringUtil.dateToStringDDMMYYYY(dataOperazione);
		this.dataOperazione = dataOperazione;
	}
	
	public String getDataOperazioneString() {
		return dataOperazioneString;
	}

	public void setDataOperazioneString(String dataOperazioneString) {
		this.dataOperazioneString = dataOperazioneString;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public String getCro() {
		return cro;
	}

	public void setCro(String cro) {
		this.cro = cro;
	}

	public Date getDataVersamento() {
		return dataVersamento;
	}

	public void setDataVersamento(Date dataVersamento) {
		if(dataVersamento!=null)
			dataVersamentoString=StringUtil.dateToStringDDMMYYYY(dataVersamento);
		this.dataVersamento = dataVersamento;
	}
	
	public String getDataVersamentoString() {
		return dataVersamentoString;
	}

	public void setDataVersamentoString(String dataVersamentoString) {
		this.dataVersamentoString = dataVersamentoString;
	}

	public String getNumeroUffPostale() {
		return numeroUffPostale;
	}

	public void setNumeroUffPostale(String numeroUffPostale) {
		this.numeroUffPostale = numeroUffPostale;
	}

	public String getProgressivoOperazione() {
		return progressivoOperazione;
	}

	public void setProgressivoOperazione(String progressivoOperazione) {
		this.progressivoOperazione = progressivoOperazione;
	}

	public String getFlagDichiarazione() {
		return flagDichiarazione;
	}

	public void setFlagDichiarazione(String flagDichiarazione) {
		this.flagDichiarazione = flagDichiarazione;
	}

	public String getElencoDocumenti() {
		return elencoDocumenti;
	}

	public void setElencoDocumenti(String elencoDocumenti) {
		this.elencoDocumenti = elencoDocumenti;
	}
	public String getTipologiaVersamento() {
		return tipologiaVersamento;
	}

	public void setTipologiaVersamento(String tipologiaVersamento) {
		this.tipologiaVersamento = tipologiaVersamento;
	}
	
}
