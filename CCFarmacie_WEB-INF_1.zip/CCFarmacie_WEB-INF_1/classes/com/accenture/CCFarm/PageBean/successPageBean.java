package com.accenture.CCFarm.PageBean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.RegioneDatiBando;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PDFModulo.GestionePDFModuloRicevuta;
import com.accenture.CCFarm.action.HomeCandidatoAction;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RepositorySession;


@ManagedBean
@RequestScoped
public class successPageBean {
	
	private String breadCrumb="";
	private String msgH3="";
	private String msgP1="";
	private String msgP2="";
	
	private FacesContext context =null;
	private HttpSession session= null; 
	private HttpServletRequest request=null; 
	
	Logger logger = CommonLogger.getLogger("HomeCandidatoBean");
	
	public successPageBean(){
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	
	public void init() {  
		context = FacesContext.getCurrentInstance();
    	request = (HttpServletRequest) context.getExternalContext().getRequest();
    	session = request.getSession();
    	Candidatura candidatura = (Candidatura) session.getAttribute(RepositorySession.CANDIDATURA);
    	String idUtente = (String) session.getAttribute(RepositorySession.ID_UTENTE);

		String lingua= (String)session.getAttribute("linguaScelta");
    	
    	if (candidatura.getReferenteDomanda()!=null&&!candidatura.getReferenteDomanda().equals("Y") ){
//    		associato non referente
    		breadCrumb = "> "+JSFUtility.getPropertyMessage("successPageBean.conferma.inserimento.domanda", lingua);
//    		breadCrumb = "> Conferma inserimento domanda";
    		msgH3 = JSFUtility.getPropertyMessage("successPageBean.domanda.completata", lingua);
//    		msgH3 = "La sua domanda � stata completata con successo";
    		msgP1="";
    		msgP2="";
    	} else{
    		breadCrumb = "> "+JSFUtility.getPropertyMessage("successPageBean.conferma.invio.domanda", lingua);
//    		breadCrumb = "> Conferma invio domanda";
    		msgH3 = JSFUtility.getPropertyMessage("successPageBean.invio.riuscito", lingua);
//    		msgH3 = "Invio riuscito.";
    		msgP1=JSFUtility.getPropertyMessage("successPageBean.conferma.email", lingua);
//    		msgP1="A breve ricever� una email di conferma sul proprio indirizzo PEC.";
    		msgP2=JSFUtility.getPropertyMessage("successPageBean.conferma.allegato", lingua);
//    		msgP2="In allegato trover� la ricevuta della domanda (in formato PDF).";
    		
    	}
    	
	}
	
	public String getBreadCrumb() {
		return breadCrumb;
	}

	public void setBreadCrumb(String breadCrumb) {
		this.breadCrumb = breadCrumb;
	}

	public String getMsgH3() {
		return msgH3;
	}


	public void setMsgH3(String msgH3) {
		this.msgH3 = msgH3;
	}


	public String getMsgP1() {
		return msgP1;
	}


	public void setMsgP1(String msgP1) {
		this.msgP1 = msgP1;
	}


	public String getMsgP2() {
		return msgP2;
	}


	public void setMsgP2(String msgP2) {
		this.msgP2 = msgP2;
	}


	public FacesContext getContext() {
		return context;
	}


	public void setContext(FacesContext context) {
		this.context = context;
	}


	public HttpSession getSession() {
		return session;
	}


	public void setSession(HttpSession session) {
		this.session = session;
	}


	public HttpServletRequest getRequest() {
		return request;
	}


	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	
	
	
}
