package com.accenture.CCFarm.PageBean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;


@ManagedBean
@SessionScoped
public class ErroreBean {
	private String messaggioErrore;
	private String areaErrore;

	public String getAreaErrore() {
		return areaErrore;
	}

	public void setAreaErrore(String areaErrore) {
		this.areaErrore = areaErrore;
	}

	public String getMessaggioErrore() {
		return messaggioErrore;
	}

	public void setMessaggioErrore(String messaggioErrore) {
		this.messaggioErrore = messaggioErrore;
	} 
	
	public ErroreBean(){
		FacesContext context = FacesContext.getCurrentInstance();
		HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
		Registrazione registrazione  = (Registrazione)context.getApplication().getVariableResolver().resolveVariable(context,	"registrazione"); 
		if (registrazione!= null)
			messaggioErrore = registrazione.getRichiestaCredenziali().getCognomeUtente();
		
		areaErrore = "Settare l'area di errore";
		
	}
	
	
}
