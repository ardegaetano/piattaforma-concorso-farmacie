package com.accenture.CCFarm.PageBean;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.EsercizioProfessionale;
import com.accenture.CCFarm.DAO.EsercizioProf;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.EsercizioProfAction;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;

@ManagedBean
@SessionScoped
public class EsercizioProfBeanVisualizzazione
{
	
	ArrayList<EsercizioProfessionale> listaEserciziProfessionali;
	EsercizioProfAction esercizioProfAction = new EsercizioProfAction();
	Logger logger = CommonLogger.getLogger("EsercizioProfBeanVisualizzazione");
	
	public EsercizioProfBeanVisualizzazione() 
	{
		esercizioProfAction=new EsercizioProfAction();
		listaEserciziProfessionali = new ArrayList<EsercizioProfessionale>();
	}
	
	public boolean init(String idUtente)
	{

	    try {
			return esercizioProfAction.loadPaginaInserimentoVisualizzazione(idUtente,this);
		} catch (GestioneErroriException e) {
			logger.error("EsercizioProfBeanVisualizzazione - init: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
			return false;
		}
		  
	}
	
	//inizializza il bean a partire dal relativo bean in compilazione
	public void init(EsercizioProfBean esercizioProfBean) throws Exception
	{ try {
		esercizioProfAction.loadPaginaInserimentoVisualizzazione(esercizioProfBean,this);
	} catch (GestioneErroriException e) {
		logger.error("EsercizioProfBeanVisualizzazione - init: " + e.getMessage());	
		JSFUtility.redirect("errorPageGenerica.jsf");
		
	}
	}
	
	public List<EsercizioProf> getListaInserimento() {
	  
	  List<EsercizioProf> listaInserimento = new ArrayList<EsercizioProf>();
		EsercizioProf esercizioProf;
	  
	  try {
	  for(int i=0;i<listaEserciziProfessionali.size();i++){
		  	esercizioProf = new EsercizioProf();
			BeanUtils.copyProperties(esercizioProf, listaEserciziProfessionali.get(i));
			listaInserimento.add(esercizioProf);
	  		}
		  } catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		  } catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
	  }
	  
	  return listaInserimento;
  }


public ArrayList<EsercizioProfessionale> getListaEserciziProfessionali() {
	return listaEserciziProfessionali;
}


public void setListaEserciziProfessionali(
		ArrayList<EsercizioProfessionale> listaEserciziProfessionali) {
	this.listaEserciziProfessionali = listaEserciziProfessionali;
}
  
  
	
}