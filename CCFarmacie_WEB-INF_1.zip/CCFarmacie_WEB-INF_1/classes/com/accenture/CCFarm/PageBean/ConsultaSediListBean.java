package com.accenture.CCFarm.PageBean;


@SuppressWarnings("serial")
public class ConsultaSediListBean implements java.io.Serializable {

	private String codIstatProv;
	private String desProv;
	private String codIstatComu;
	private String desComu;
	private String nProgCom;
	private String desSede;
	private String desSedeDe;
	private String tipoSede;
	private String critTopo;
	private String indennitaAvviamento;
	private boolean lingua;
//	private String contenzioso;
	
	public ConsultaSediListBean() {}

	public String getCodIstatProv() {
		return codIstatProv;
	}

	public void setCodIstatProv(String codIstatProv) {
		this.codIstatProv = codIstatProv;
	}

	public String getDesProv() {
		return desProv;
	}

	public void setDesProv(String desProv) {
		this.desProv = desProv;
	}

	public String getCodIstatComu() {
		return codIstatComu;
	}

	public void setCodIstatComu(String codIstatComu) {
		this.codIstatComu = codIstatComu;
	}

	public String getDesComu() {
		return desComu;
	}

	public void setDesComu(String desComu) {
		this.desComu = desComu;
	}

	public String getnProgCom() {
		return nProgCom;
	}

	public void setnProgCom(String nProgCom) {
		this.nProgCom = nProgCom;
	}

	public String getDesSede() {
		return desSede;
	}

	public void setDesSede(String desSede) {
		this.desSede = desSede;
	}

	public String getTipoSede() {
		return tipoSede;
	}

	public void setTipoSede(String tipoSede) {
		this.tipoSede = tipoSede;
	}

	public String getCritTopo() {
		return critTopo;
	}

	public void setCritTopo(String critTopo) {
		this.critTopo = critTopo;
	}

	public String getIndennitaAvviamento() {
		return indennitaAvviamento;
	}

	public void setIndennitaAvviamento(String indennitaAvviamento) {
		this.indennitaAvviamento = indennitaAvviamento;
	}

	public String getDesSedeDe() {
		return desSedeDe;
	}

	public void setDesSedeDe(String desSedeDe) {
		this.desSedeDe = desSedeDe;
	}

	public boolean isLingua() {
		return lingua;
	}

	public void setLingua(boolean lingua) {
		this.lingua = lingua;
	}

	
	
	

//	public String getContenzioso() {
//		return contenzioso;
//	}
//
//	public void setContenzioso(String contenzioso) {
//		this.contenzioso = contenzioso;
//	}
	
	
}