package com.accenture.CCFarm.PageBean;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.event.FlowEvent;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.DomandaDao;
import com.accenture.CCFarm.DAO.RegioneDatiBando;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.DAO.UtenteCandidaturaHome;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.DomandaAction;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.ControlloBandoScaduto;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.HelpDe;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.TabellaDecodifica;

@ManagedBean
@SessionScoped
public class Domanda
{
	private boolean flagVerifica;

	// dati per il captcha -------------
	private String captchaCode;
	private String captchaGenerator;
	private boolean flagAutorizzo;
	private boolean flaConsapevole;
	// ---------------------------------

	private String idUtente;
	private String tipologiaUtente;// pu� assumere i valori: singolo, referente, associato
	private String codiceRegione, denominazioneRegione;
	private String messaggioErrore;
	
	private boolean modalitaDemo;
	private boolean isTedesco=false;
	
	public boolean isTedesco() {
		return isTedesco;
	}

	public void setTedesco(boolean isTedesco) {
		this.isTedesco = isTedesco;
	}

	private String oldWizardStep;
	private String currentWizardStep;
	private String newWizardStep;
	
	private boolean mostraPulsanteInvio;
	private String testoPulsanteInvio;
	
	// sotto-bean di pagina
	private RequisitiMinimiBean requisitiMinimiBean;
	private TitoliStudioCarrieraBean titoliStudioCarrieraBean;
	private EsercizioProfBean esercizioProfBean;
	private DichiarazioneSostitutivaBean dichiarazioneSostitutivaBean;

	/*
	 * // countDown private String annoCD = ""; private String meseCD = "";
	 * private String giornoCD = ""; private String oreCD = ""; private String
	 * minCD = ""; private String secCD = ""; private String descBread = "none";
	 */

	private RegioneDatiBando regioneDatiBando = null;
	private Candidatura candidatura = null;
	private String statoCandidatura = "";
	private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss");

	Logger logger = CommonLogger.getLogger("Domanda");

	private DomandaAction domandaAction;

	public Domanda()
	{
		try
		{
			captchaGenerator = AppProperties.getAppProperty("bck_immage_path");
			
			trovaDatiRegione();
			
			requisitiMinimiBean = new RequisitiMinimiBean();
			titoliStudioCarrieraBean = new TitoliStudioCarrieraBean();
			esercizioProfBean = new EsercizioProfBean();
			dichiarazioneSostitutivaBean = new DichiarazioneSostitutivaBean();
	
			domandaAction = new DomandaAction();
	
			init();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
	}
	
	private void trovaIDUtente() throws Exception
	{
		if(!modalitaDemo)
		{
			idUtente=(String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_UTENTE);
		}
		else
		{
			idUtente="demo";//** deve coincidere con quello caricato sul db **
		}
		
		if(idUtente==null)
			throw new Exception("[Impossibile individuare Utente loggato]");
	}

	private void determinaTipologiaUtente() throws Exception
	{
		if(!modalitaDemo)
		{
			tipologiaUtente=domandaAction.determinaTipologiaUtente(idUtente);
		}
		else
		{
			tipologiaUtente="fantasma";
		}
	}
	
	// recupera dalla sessione il codice regione
	private void determinaStatoCandidatura() throws Exception
	{
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		 
		if(!modalitaDemo)
		{
			candidatura=(Candidatura)GetSessionUtility.getSessionAttribute(RepositorySession.CANDIDATURA);
			if(candidatura!=null)
			{
				statoCandidatura=TabellaDecodifica.decodificaStatoCandidatura(candidatura.getStatoDomanda(),lingua);
			}
		}
		else
		{
			statoCandidatura="Demo";
		}
		
		if(statoCandidatura==null || statoCandidatura.equals(""))
			throw new Exception("[ Impossibile determinare lo stato della domanda per l'associato (id:"+idUtente+") ]");
	}
	
	// recupera dalla sessione il codice regione
	private void trovaDatiRegione() throws Exception
	{
		codiceRegione = (String) GetSessionUtility.getSessionAttribute(RepositorySession.ID_REGIONE);
		if(codiceRegione == null)
			throw new Exception("[Impossibile individuare codice Regione]");

		regioneDatiBando = (RegioneDatiBando) GetSessionUtility.getSessionAttribute(RepositorySession.REGIONI_DATI_BANDO);
		if (regioneDatiBando == null)
			throw new Exception("[Impossibile individuare regioniDatiBando]");

		denominazioneRegione = regioneDatiBando.getDenominazioneReg();
		if (denominazioneRegione == null)
			throw new Exception("[Impossibile individuare denominazione Regione]");
	}
	
	public void init()
	{
		try
		{
			//determina modalit� di navigazione della pagina
			String navigazioneDemo=(String)GetSessionUtility.getSessionAttribute("navigazioneDemo");
			if(navigazioneDemo!=null && navigazioneDemo.equals("navigazioneDemo"))
			{
				modalitaDemo=true;
				
				//una volta avviata la modalit� demo, rimuovi la traccia dalla sessione
				//(necessario per far si che i successivi caricamenti della pagina di compilazione non riavvengano in mod. demo)
				GetSessionUtility.removeSessionAttribute("navigazioneDemo");
			}
			else
			{
				modalitaDemo=false;
			}
			
			trovaIDUtente();
			determinaTipologiaUtente();
			determinaStatoCandidatura();
			
			/*
			 * //inizializza dati per il countdown String dataGregorian =
			 * StringUtil
			 * .dateToString(regioneDatiBando.getDatiBando().getDataFineBando
			 * (),sdf); annoCD = dataGregorian.substring(6, 10); meseCD =
			 * dataGregorian.substring(3, 5); giornoCD =
			 * dataGregorian.substring(0, 2); oreCD =
			 * dataGregorian.substring(13, 15); minCD =
			 * dataGregorian.substring(16, 18); secCD =
			 * dataGregorian.substring(19, 21);
			 * 
			 * String idRegione = (String)
			 * GetSessionUtility.getSessionAttribute(
			 * RepositorySession.ID_REGIONE); ControlloBandoScaduto scaduto =
			 * new ControlloBandoScaduto(); boolean scadOK =
			 * scaduto.controllaScadenza(idRegione); if (scadOK) descBread=
			 * "block"; else descBread= "none";
			 */
			
			//inizializza frasi per l'Help
			 
			 HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			 String lingua= (String)session.getAttribute("linguaScelta");
			 
			//init Help
			if(lingua.equals("it")){
				requisitiMinimiBean.setListaHelp(Help.caricaHelpDatiCandidato());
				requisitiMinimiBean.setListaHelpTitoli(Help.caricaHelpTitoliDiStudio());
				requisitiMinimiBean.setListaHelpEsercizio(Help.caricaHelpEsercizioProfessionale());
				requisitiMinimiBean.setListaHelpVersamento(Help.caricaHelpDatiVersamento());
			}else{
				requisitiMinimiBean.setListaHelp(HelpDe.caricaHelpDatiCandidato());
				requisitiMinimiBean.setListaHelpTitoli(HelpDe.caricaHelpTitoliDiStudio());
				requisitiMinimiBean.setListaHelpEsercizio(HelpDe.caricaHelpEsercizioProfessionale());
				requisitiMinimiBean.setListaHelpVersamento(HelpDe.caricaHelpDatiVersamento());
			}
			//inizializza tutti e 4 i sotto-bean
			
			// tab 1
			requisitiMinimiBean.init(idUtente);
			
			// tab 2
			titoliStudioCarrieraBean.init(idUtente);
			titoliStudioCarrieraBean.titoliStudioAction.setUtenteCandidatura(requisitiMinimiBean.requisitiMinimiAction.getUtenteCandidatura());
			
			// tab 3
			esercizioProfBean.init(idUtente,codiceRegione);
			
			// tab 4
			dichiarazioneSostitutivaBean.init(idUtente);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
	}

	private DomandaDao getUpdatedDomanda(String statoDomanda)
	{
		// ricava il timestamp dell'orario corrente
		Timestamp now = DateUtil.getCurrentTimestamp();
		
		// popola i bean del database
		
		// tab 1
		requisitiMinimiBean.updateDAO(idUtente, now);
		
		// tab 2
		titoliStudioCarrieraBean.updateDAO(idUtente);
		
		// tab 3
		esercizioProfBean.updateDAO(idUtente);
		
		// tab 4
		dichiarazioneSostitutivaBean.updateDAO(idUtente);
		
		UtenteCandidatura utenteCandidatura = requisitiMinimiBean.requisitiMinimiAction
				.getUtenteCandidatura();
		utenteCandidatura.getCandidatura().setStatoDomanda(statoDomanda);
		
		// se il popolamento dei bean del db � andato a buon fine (nessuna
		// eccezione a runtime)..
		// ..procedi col salvataggio dei dati
		
		DomandaDao domanda = new DomandaDao();
		
		// dati tab 1
		domanda.setUtenteCandidatura(utenteCandidatura);
		domanda.setRequisitiMinimi(requisitiMinimiBean.requisitiMinimiAction
				.getRequisitiMinimi());
		
		// dati tab 2
		domanda.setAltraLaurea(titoliStudioCarrieraBean.titoliStudioAction
				.getAltraLaurea());
		domanda.setListaAltraLaureaBis(titoliStudioCarrieraBean.titoliStudioAction
				.getAltreLaureeBis());
		domanda.setListaAltroTitolo(titoliStudioCarrieraBean.titoliStudioAction
				.getAltriTitoli());
		domanda.setListaBorsaStudio(titoliStudioCarrieraBean.titoliStudioAction
				.getBorseStudio());
		domanda.setListaCorsoAggiornamento(titoliStudioCarrieraBean.titoliStudioAction
				.getCorsiAggiornamento());
		domanda.setListaDottorato(titoliStudioCarrieraBean.titoliStudioAction
				.getDottorati());
		domanda.setListaPubblicazione(titoliStudioCarrieraBean.titoliStudioAction
				.getPubblicazioni());
		domanda.setListaSpecializzazione(titoliStudioCarrieraBean.titoliStudioAction
				.getSpecializzazioni());
		domanda.setIdoneita(titoliStudioCarrieraBean.titoliStudioAction
				.getIdoneita());

		// dati tab 3
		domanda.setListaEserciziProf(esercizioProfBean.esercizioProfAction
				.getEserciziProf());

		// dati tab 4
		domanda.setDichiarazioneSostitutiva(dichiarazioneSostitutivaBean.dichiarazioneSostitutivaAction
				.getDichiarazioneSostitutiva());
		domanda.setListaDocumenti(dichiarazioneSostitutivaBean.dichiarazioneSostitutivaAction.getListaDocumenti());

		return domanda;
	}

	private void salvaDatiDomanda(String statoDomanda,boolean isTedesco) throws GestioneErroriException
	{
		// esegui transazione per salvare i dati sul db
		UtenteCandidaturaHome utenteCandidaturaHome = new UtenteCandidaturaHome();
		utenteCandidaturaHome.inserisciDomanda(getUpdatedDomanda(statoDomanda),isTedesco);
	}
	
	private void aggiornaStatoCandidaturaInSessione(String statoCandidatura)
	{
		candidatura=(Candidatura)((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false))
					.getAttribute(RepositorySession.CANDIDATURA);
		
		candidatura.setStatoDomanda(statoCandidatura);
		
		((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false))
					  .setAttribute(RepositorySession.CANDIDATURA,candidatura);
	}
	
	private String recuperaStatoCandidaturaInSessione()
	{
		Candidatura candidatura=(Candidatura)GetSessionUtility.getSessionAttribute(RepositorySession.CANDIDATURA);
		if(candidatura==null)
			return null;
		
		return candidatura.getStatoDomanda();
	}
	
	private String recuperaIdCandidaturaInSessione()
	{
		Candidatura candidatura=(Candidatura)GetSessionUtility.getSessionAttribute(RepositorySession.CANDIDATURA);
		if(candidatura==null)
			return null;
		
		return candidatura.getIdCandidatura();
	}
	//procede con l'invio della domanda, se sussistono tutte le condizioni per poterlo fare
	private void inviaDomanda()
	{
		boolean isTedesco = false;
		try {
		Candidatura candidatura = (Candidatura) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute(RepositorySession.CANDIDATURA);
		String idRegione = (String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute(RepositorySession.ID_REGIONE);
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		if(lingua.equals("de"))
		{
			isTedesco = true;
		}else 
		{
			isTedesco = false;
		}
		ControlloBandoScaduto controllaBando = new ControlloBandoScaduto();
		// Se dai controlli precedneti la data di invio risulta valida proseguo
		// con gli altri controlli altrimenti visualizzo la pag di errore
		// opportuna
		if(controllaBando.controllaScadenza(idRegione))
		{
			if(!candidatura.getStatoDomanda().equalsIgnoreCase("I"))
			{
				// esegui transazione per salvare i dati sul db e per generare
				// la ricevuta pdf
				UtenteCandidaturaHome utenteCandidaturaHome = new UtenteCandidaturaHome();
				utenteCandidaturaHome.inviaDomanda(getUpdatedDomanda("B"), isTedesco);
				// Se arrivo a questo punto vuol dire che l'invio � andato a
				// buon fine quindi cambio lo stato della domanda nel bean in
				// sessione
				
				aggiornaStatoCandidaturaInSessione("I");
				
				JSFUtility.redirect("successPage.jsf");
			}
			else
			{
			
				// Pagina di errore con messaggio la domanda gi� risulta inviata
				this.setMessaggioErrore(JSFUtility.getPropertyMessage("domandaBean.errore.domanda.inviata", lingua));//"La domanda risulta gi� inviata"
				JSFUtility.redirect("errorPageDomanda.jsf");
			}
		}
		else
		{
			// Pagina di errore con messaggio la domanda gi� risulta inviata
			this.setMessaggioErrore(JSFUtility.getPropertyMessage("domandaBean.errore.domanda.non.piu.inviata", lingua));
			JSFUtility.redirect("errorPageDomanda.jsf");
		}
		
		}
		catch(Exception e){
			e.printStackTrace();
			JSFUtility.redirect("errorPage.jsf");
		}
	}

	// procede al salvataggio parziale dei dati
	public void salvaDomanda()
	{
		try
		{
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			//recupera lo stato corrente della candidatura
//			String statoDomanda=recuperaStatoCandidaturaInSessione();
			CandidaturaHome candidaturaHome = new CandidaturaHome();
			Candidatura     candidatura     = new Candidatura();
			String idCandidatura=recuperaIdCandidaturaInSessione();
			candidatura = candidaturaHome.findById(idCandidatura);
			
			String statoDomanda= candidatura.getStatoDomanda();
			
			//se la domanda non risulta in bozza..
			if(!(statoDomanda!=null && statoDomanda.equalsIgnoreCase("B")))
			{
				//..impedisci l'operazione di salvataggio
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("domandaBean.errore.imp.mod.domanda", lingua));
				/*"Attenzione","Non � possibile modificare una domanda gi� inviata"*/
				JSFUtility.scrollTo("form:msgs");
				return;
			}
			
			boolean controlliSuperati=true;
			
			//controlla che i dati del tab 1 siano stati correttamente inseriti
			if(!requisitiMinimiBean.controllaCampi())
				controlliSuperati=false;

			// se si � nel tab 2..
			if(currentWizardStep != null && currentWizardStep.equalsIgnoreCase("tabTitoliStudio"))
			{
				if(!titoliStudioCarrieraBean.controllaCampi() || !titoliStudioCarrieraBean.controllaSecondaLaurea())
					controlliSuperati=false;
			}

			// se si � nel tab 3..
			if(currentWizardStep != null && currentWizardStep.equalsIgnoreCase("tabEsercizioProfessionale")) {
				if(!esercizioProfBean.controllaCampi())
					controlliSuperati=false;
			}

			// se si � nel tab 4..
			if(currentWizardStep != null && currentWizardStep.equalsIgnoreCase("tabDichiarazioneSostitutiva")) {
				// ..controlla che i suoi dati siano stati correttamente
				// inseriti

				if(titoliStudioCarrieraBean.isVisualizzaPanelVersamenti())
				{
					if(!dichiarazioneSostitutivaBean.controllaDate())
						controlliSuperati=false;
				}
				/*else if(titoliStudioCarrieraBean.isVisualizzaPanelDocumenti())
				{
					if(!dichiarazioneSostitutivaBean.controllaFlag())
						controlliSuperati=false;
				}*/
				else if(!titoliStudioCarrieraBean.isVisualizzaPanelDocumenti())//Per NO contributo partecipazione
					dichiarazioneSostitutivaBean.setTipiPagamento("");
				
			}
			
			if(controlliSuperati)
			{
				//salva domanda in stato "Bozza"
				if(lingua.equalsIgnoreCase("de")){
					this.isTedesco=true;
				}
				salvaDatiDomanda("B",isTedesco);
				
				JSFUtility.addInfoMessage(JSFUtility.getPropertyMessage("salvataggio.riuscito", lingua),"",false);
			}
			
			JSFUtility.scrollTo("form:msgs");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
	}

	// restituisce true solo se sono rispettate le condizioni perliminari per procedere all'invio/inserimento della domanda corrente
	private boolean controllaRequisitiDomanda()
	{
		ControlloBandoScaduto controllo = new ControlloBandoScaduto();
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		try
		{
			// se il bando non � scaduto
			if(controllo.controllaScadenza(codiceRegione))
			{
				// se il tab requisiti minimi � stato compilato per intero
				if(requisitiMinimiBean.isCompletato())
				{
					// controlla che i dati dell'ultimo tab siano corretti
					if(titoliStudioCarrieraBean.isVisualizzaPanelVersamenti())
					{
						if(!dichiarazioneSostitutivaBean.controllaDate())
							return false;
					}
					/*if(titoliStudioCarrieraBean.isVisualizzaPanelDocumenti())
					{
						if(!dichiarazioneSostitutivaBean.controllaFlag())
							return false;
					}*/
					
					return true;
				}
				else
				{

					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("domandaBean.errore.no.requisiti.minimi", lingua));
					/* "Attenzione","I dati relativi ai requisiti minimi di ammissione non sono completi" */
					JSFUtility.scrollTo("form:msgs");
				}
			}
			else
			{
				JSFUtility.addWarningMessage("",JSFUtility.getPropertyMessage("domandaBean.errore.no.requisiti.minimi", lingua));
				// "Il termine per la presentazione della domanda � scaduto."
				JSFUtility.scrollTo("form:msgs");
			}
		}
		catch(GestioneErroriException e)
		{
			logger.error("Domanda - controllo validit� bando: " + e);
			LogUtil.printException(e);
			JSFUtility.redirect("errorPageGenerica.jsf");
		}

		return false;
	}

	// restituisce true solo se per la domanda corrente sono rispettate tutte le
	// condizioni necessarie per il suo invio
	private boolean controlloAbilitaInvio() throws GestioneErroriException
	{
		boolean result = true;
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");

		if(tipologiaUtente.equals("referente"))
		{
			UtenteCandidatura utenteCandidatura = requisitiMinimiBean.getRequisitiMinimiAction().getUtenteCandidatura();
			Candidatura candidatura = utenteCandidatura.getCandidatura();
			String idCandidatura = candidatura.getIdCandidatura();
			Candidatura candidaturaAssociata = new Candidatura();
			candidaturaAssociata.setIdCandidatura(idCandidatura);

			CandidaturaHome candidaturaHome = new CandidaturaHome();
			List<Candidatura> candidatureAssociate = candidaturaHome.findByExample(candidaturaAssociata);
			for (int i = 0; i < candidatureAssociate.size(); i++)
			{
				candidaturaAssociata = candidatureAssociate.get(i);
				String statoDomandaAssociato = candidaturaAssociata.getStatoDomanda();
				
				if(!candidaturaAssociata.getReferenteDomanda().equals("Y"))
				{
					if(statoDomandaAssociato.equals("B"))
					{
						Utente associato = new UtenteHome().findById(candidaturaAssociata.getIdUtente());
						JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),
								JSFUtility.getPropertyMessage("domandaBean.attenzione.utente.associato", lingua)
										+ associato.getNomeUtente()
										+ " "
										+ associato.getCognomeUtente()
										+ JSFUtility.getPropertyMessage("domandaBean.attenzione.incompleto.inserimento", lingua));
						/* "Attenzione", "L'utente associato "+" non ha ancora completato l'inserimento dei suoi dati"  */
						JSFUtility.scrollTo("form:msgs");
						result = false;
						break;
					}
				}
			}
		}

		return result;
	}

	private boolean controllaCondizioniNecessarie()
	{
		try
		{
			if(controllaInvioGiaEffettuato())
			{
				
				if(controllaRequisitiDomanda())
				{
					if (!tipologiaUtente.equals("referente") || (tipologiaUtente.equals("referente") && controlloAbilitaInvio()))
						return true;
				}
				return false;
			}
			
			return false;
		}
		
		catch(Exception e)
		{
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			e.printStackTrace();
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("domandaBean.attenzione.problema.controllo.req", lingua));
			/* "Attenzione" "Si � verificato un problema nel controllo dei requisiti" */
			return false;
		}
	}
	
	public boolean controllaInvioGiaEffettuato() throws GestioneErroriException
	{
		try
		{
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			idUtente = (String) GetSessionUtility.getSessionAttribute(RepositorySession.ID_UTENTE);
		
			boolean result = true;
			
			UtenteCandidaturaHome utenteCandidaturaHome = new UtenteCandidaturaHome();
			ArrayList<UtenteCandidatura> listaCandidatureAssociate = new ArrayList<UtenteCandidatura>();
			UtenteCandidatura utenteCandidatura = new UtenteCandidatura();
			CandidaturaHome candidaturaHome = new CandidaturaHome();
			
			ArrayList<UtenteCandidatura> listaCandidature = new ArrayList<UtenteCandidatura>();
			//tramite l'utente candidatura vado a oprenderer gli associati se ci sono
			
			ArrayList<String> listaCodiciFiscali = new ArrayList<String>();
			
			utenteCandidatura = utenteCandidaturaHome.findById(idUtente);
		
			
			//prendo gli associati del mio utente
			
			if(utenteCandidatura.getCandidatura().getModalitaCandidatura().equals("A"))
			{
				Candidatura candidatura = new Candidatura();
				String query = "select u from UtenteCandidatura u where u.candidatura.idCandidatura='"+utenteCandidatura.getCandidatura().getIdCandidatura()+"'";
						
				listaCandidatureAssociate = (ArrayList<UtenteCandidatura>) utenteCandidaturaHome.findByQuery(query);
			
				for(UtenteCandidatura utenteCandidaturaAss : listaCandidatureAssociate)
				{
					String codiceFiscale2 = utenteCandidaturaAss.getCodiceFiscaleUtente();
					listaCodiciFiscali.add(codiceFiscale2);			
				}
			}else{	
				listaCodiciFiscali.add(utenteCandidatura.getCodiceFiscaleUtente());
			}
			
			String messaggioErrore = null;
			for (int i=0;i<listaCodiciFiscali.size();i++)
			{
				String query = "select u from UtenteCandidatura u where UPPER(u.codiceFiscaleUtente) = '"+listaCodiciFiscali.get(i).toUpperCase()+"' and (u.candidatura.statoDomanda ='I' or u.candidatura.statoDomanda ='T')";
				
				listaCandidature = (ArrayList<UtenteCandidatura>) utenteCandidaturaHome.findByQuery(query);
				
				if(listaCandidature.size()>1)
				{
					
					
					if(utenteCandidatura.getCandidatura().getModalitaCandidatura().equals("A"))
					{
						messaggioErrore = JSFUtility.getPropertyMessage("domandaBean.attenzione.partecipante.due.domande", lingua);
						//messaggioErrore = "Non � possibile inviare la domanda in quanto uno dei partecipanti ha gi� inviato due domande";
					}
					else
					{
						messaggioErrore = JSFUtility.getPropertyMessage("domandaBean.attenzione.utente.due.domande", lingua);
						//messaggioErrore = "Per questo utente risultano gi� inviate due domande di partecipazione al concorso";
					}
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua), messaggioErrore);
					//"Attenzione"
					result = false;
					break;
				 }
				else
				{
					if(listaCandidature.size()>0)
					{
						UtenteCandidatura utenteCandidaturaTestReg = new UtenteCandidatura();
						utenteCandidaturaTestReg = listaCandidature.get(0);
						if(utenteCandidaturaTestReg.getCodRegUtente().equals((String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute(RepositorySession.ID_REGIONE)))
						{
							
							
							if(utenteCandidaturaTestReg.getCandidatura().getModalitaCandidatura().equals("A"))
							{
								messaggioErrore = JSFUtility.getPropertyMessage("domandaBean.attenzione.partecipanti.gia.presenti.regione", lingua);

//								messaggioErrore = "Uno o pi� partecipanti al concorso hanno gi� inviato una domanda di partecipazione al concorso per questa regione";
							}
							else
							{
								messaggioErrore = JSFUtility.getPropertyMessage("domandaBean.attenzione.utente.domanda.regione", lingua);

//								messaggioErrore = "L'utente ha gi� inviato una domanda di partecipazione per questa regione";
							}
							JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),messaggioErrore);
							result = false;
							break;
						}
					}
				}
			}
			if (result){
				result = controlloInvioPerNominativo(utenteCandidatura);
			}
			
			return result;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new GestioneErroriException();
		}
	}
	
	public boolean controlloInvioPerNominativo(UtenteCandidatura utenteCandidaturaInvia) throws GestioneErroriException{
		boolean result = true;
		UtenteCandidaturaHome utenteCandidaturaHome = new UtenteCandidaturaHome();
		ArrayList<UtenteCandidatura> listaCandidature= new ArrayList<UtenteCandidatura>();
	
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		try
			{
			
			if(utenteCandidaturaInvia.getCandidatura().getModalitaCandidatura().equals("A"))
			{
				Candidatura candidatura = new Candidatura();
				String query = "select u from UtenteCandidatura u where u.candidatura.idCandidatura='"+utenteCandidaturaInvia.getCandidatura().getIdCandidatura()+"'";
						
				listaCandidature = (ArrayList<UtenteCandidatura>) utenteCandidaturaHome.findByQuery(query);
			
			} else {
	//			in caso di singola candidatura 
				listaCandidature.add(utenteCandidaturaInvia);
			}
			
			String messaggioErrore = null;
			for (int i=0;i<listaCandidature.size();i++)
			{
				UtenteCandidatura candidatura = new UtenteCandidatura();
				candidatura = listaCandidature.get(i);
				
				String nomeCandidato = candidatura.getNomeUtente().toUpperCase().trim();
				
				if(nomeCandidato.contains("'")){
				
					nomeCandidato = StringUtil.replaceApice(nomeCandidato);
				}
				
				String cognomeCandidato = candidatura.getCognomeUtente().toUpperCase().trim();
				
				if(cognomeCandidato.contains("'")){
				
					cognomeCandidato = StringUtil.replaceApice(cognomeCandidato);
				}
				
				
				String query = "select u from UtenteCandidatura u where UPPER(trim(u.cognomeUtente)) = '"+cognomeCandidato+"'"+
						                                                " and UPPER(trim(u.nomeUtente)) = '"+nomeCandidato+"'"+
						                                                " and u.dataNascitaUtente = to_date('"+candidatura.getDataNascitaUtente()+"','yyyy-MM-dd')"+
						                                                " and (u.candidatura.statoDomanda ='I' or u.candidatura.statoDomanda ='T')";
				List<UtenteCandidatura> lista = new ArrayList<UtenteCandidatura>();
				lista = (ArrayList<UtenteCandidatura>) utenteCandidaturaHome.findByQuery(query);
				
				if(lista.size()>1)
				{
					//	nel caso sono state fatte gi� due invii				
					if(candidatura.getCandidatura().getModalitaCandidatura().equals("A"))
					{
						messaggioErrore = JSFUtility.getPropertyMessage("domandaBean.attenzione.partecipante.due.domande", lingua);
//						messaggioErrore = "Non � possibile inviare la domanda in quanto uno dei partecipanti ha gi� inviato due domande";
					}
					else
					{
						messaggioErrore = JSFUtility.getPropertyMessage("domandaBean.attenzione.utente.due.domande", lingua);
//						messaggioErrore = "Per questo utente risultano gi� inviate due domande di partecipazione al concorso";
					}
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua), messaggioErrore);
					// "Attenzione"
					result = false;
					break;
				 }
				else
				{
					if(lista.size()>0)
					{
						//	nel caso in cui � stato gi� fatto un invio sulla stessa regione					
						UtenteCandidatura uCandidatura=null;
						uCandidatura = lista.get(0);
						if(uCandidatura.getCodRegUtente().equals((String) ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute(RepositorySession.ID_REGIONE)))
						{
							if(uCandidatura.getCandidatura().getModalitaCandidatura().equals("A"))
							{
								messaggioErrore = JSFUtility.getPropertyMessage("domandaBean.attenzione.partecipanti.gia.presenti.regione", lingua);
//								messaggioErrore = "Uno o pi� partecipanti al concorso hanno gi� inviato una domanda di partecipazione al concorso per questa regione";
							}
							else
							{
								messaggioErrore = JSFUtility.getPropertyMessage("domandaBean.attenzione.utente.domanda.regione", lingua);
//								messaggioErrore = "L'utente ha gi� inviato una domanda di partecipazione per questa regione";
							}
							JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),messaggioErrore);
							// "Attenzione"
							result = false;
							break;
						}
					}
				}
			}
			
			return result;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			throw new GestioneErroriException();
		}
	}

	//verifica se ci sono tutte le condizioni per procedere ad un completamento o all'invio di una domanda
	public void controllaDati()
	{
		if(controllaCondizioniNecessarie())
		{
			//cerca in sessione il bean per la visualizzazione della domanda
			DomandaVisualizzazione domandaVisualizzazione=(DomandaVisualizzazione)GetSessionUtility.getSessionAttribute("domandaVisualizzazione");
			if(domandaVisualizzazione!=null)
			{
				// se gi� presente, forza il ricaricamento dei dati
				// (necessario per evitare che mostri in riepilogo dati non corrispondenti alle ultime modifiche)
				domandaVisualizzazione.init();
			}
			else
			{
				//se non � presente, ne crea una nuova istanza e la setta in sessione
				domandaVisualizzazione=new DomandaVisualizzazione();
				GetSessionUtility.setSessionAttribute("domandaVisualizzazione",domandaVisualizzazione);
			}
			
			JSFUtility.redirect("riepilogoDomanda.jsf");
		}
		else
		{
			JSFUtility.executeScript("blockUI.hide()");
		}
	}
	
	public void indietro()
	{
		JSFUtility.redirect("compilaDomanda.jsf");
		mostraPulsanteInvio = false;
	}
	
	public void controllaFlagVerifica()
	{
		if(!flagVerifica)
		{
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			JSFUtility.addWarningMessage("",JSFUtility.getPropertyMessage("domandaBean.attenzione.casella.dati.inseriti", lingua));
					//"E' necessario spuntare la casella di dichiarazione sulla verifica dei dati inseriti");
		}
		else
		{
			 JSFUtility.executeScript("confirmation.show()");
		}
	}
	
	public void prosegui()
	{
		JSFUtility.redirect("confermaDomanda.jsf");
	}

	private boolean controllaCaptcha()
	{
		String correctCaptcha = (String) GetSessionUtility.getSessionAttribute("captchaCode");

		if(correctCaptcha != null && captchaCode != null && captchaCode.equals(correctCaptcha))
			return true;
		return false;
	}

	public void confermaDomanda()
	{
		boolean invioBloccato=false;
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		if(getFlaConsapevole() && getFlagAutorizzo())
		{
			// controlla se il captcha inserito � corretto
			if (controllaCaptcha())
			{
				// controlla nuovamente che tutte le condizioni necessarie per l'invio siano soddisfatte
				if (controllaCondizioniNecessarie())
				{
					if(tipologiaUtente.equals("associato"))
					{
						// se l'utente � un associato, procedi con "completa inserimento"
						completaInserimento();
					}
					else
					{
						// se l'utente � un singolo o un referente, procedi con "invia"
						inviaDomanda();
					}
				}
				else
				{
					invioBloccato=true;
				}
			}
			else
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("domandaBean.attenzione.codice.errato", lingua));
				// "Attenzione","Il codice inserito non � corretto"
				setCaptchaCode(null);
				invioBloccato=true;
			}
		}
		else
		{
			JSFUtility.addInfoMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("domandaBean.attenzione.caselle.mancanti", lingua),false);
			//"Attenzione","La casella di dichiarazione e la casella di autorizzazione al trattamento dei dati devono essere entrambe spuntate "
			setCaptchaCode(null);
			invioBloccato=true;
		}
		
		if(invioBloccato)
		{
			JSFUtility.executeScript("blockUI.hide()");
		}
	}

	// procede con la chiusura dell'inserimento (da parte di un associato), se
	// sussistono tutte le condizioni per poterlo fare
	private void completaInserimento()
	{
		try
		{
			//salva domanda in stato "Completata"
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			if(lingua.equals("de")){
			  isTedesco=true;
			}else{
				isTedesco=false;
			}
			salvaDatiDomanda("C",isTedesco);
			aggiornaStatoCandidaturaInSessione("C");
			
			JSFUtility.redirect("successPage.jsf");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			JSFUtility.redirect("errorPage.jsf");
		}
	}

	
//	private void inviaDomanda()
//	{
//		try
//		{
//			// salva domanda in stato "Inviata" e genera ricevuta pdf
//			eseguiInvioDomanda();
//			//JSFUtility.redirect("successPage.jsf");
//		}
//		catch (Exception e)
//		{
//			e.printStackTrace();
//			JSFUtility.redirect("errorPage.jsf");
//		}
//	}

	// ------------------------------------------------------------------------------------------------------------------------------

	// gestisce il passaggio tra un tab e l'altro del wizard
	public String handleFlow(FlowEvent event)
	{
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		oldWizardStep = event.getOldStep();
		newWizardStep = event.getNewStep();

		// passaggio al tab 2
		if (newWizardStep != null && newWizardStep.equalsIgnoreCase("tabTitoliStudio"))
		{
			// controlla che tutte i campi siano stati valorizzati correttamente
			if (!requisitiMinimiBean.controllaCampi())
			{
				// se il controllo fallisce -> blocca sul tab corrente e sposta il focus sull'area messaggi
				JSFUtility.scrollTo("form:msgs");
				
				currentWizardStep=oldWizardStep;
				return oldWizardStep;
			}
			// se i controlli sono stati superati
			titoliStudioCarrieraBean.setDataNascitaUtente(requisitiMinimiBean.getDataNascitaUtente());
			titoliStudioCarrieraBean.setDataPrimaLaurea(requisitiMinimiBean.getDataLaurea());
			titoliStudioCarrieraBean.setDescPrimaLaurea(requisitiMinimiBean.getCodTipoLaurea());
		}

		// passaggio al tab 3
		if (newWizardStep != null && newWizardStep.equalsIgnoreCase("tabEsercizioProfessionale"))
		{
			// passa la data di iscrizione albo al bean esercizio professionale

			titoliStudioCarrieraBean.controllaPubbl();
			
			//titoliStudioCarrieraBean.controllaSecondaLaurea();
			
			
			/*if(titoliStudioCarrieraBean.isVisualizzaPanelDocumenti())
			{
				dichiarazioneSostitutivaBean.setIban("");
				dichiarazioneSostitutivaBean.setCro("");
				dichiarazioneSostitutivaBean.setDataOperazione(null);
				dichiarazioneSostitutivaBean.setProgressivoOperazione("");
				dichiarazioneSostitutivaBean.setNumeroUffPostale("");
				dichiarazioneSostitutivaBean.setDataVersamento(null);
			}	
			else if(titoliStudioCarrieraBean.isMostraPanelBancario())
			{
				dichiarazioneSostitutivaBean.setProgressivoOperazione("");
				dichiarazioneSostitutivaBean.setNumeroUffPostale("");
			}
			else if(titoliStudioCarrieraBean.isMostraPanelPostale())
			{
				dichiarazioneSostitutivaBean.setIban("");
				dichiarazioneSostitutivaBean.setCro("");
				
			}*/
			
			if (!titoliStudioCarrieraBean.controllaCampi() || !titoliStudioCarrieraBean.controllaSecondaLaurea())
			{
				JSFUtility.scrollTo("form:msgs");
				
				currentWizardStep=oldWizardStep;
				return oldWizardStep;
			}

			esercizioProfBean.setDataIscrizioneAlbo(requisitiMinimiBean.getDataAlbo());
			esercizioProfBean.setDataNascitaUtente(requisitiMinimiBean.getDataNascitaUtente());
		}

		// passaggio al tab 4
		if (newWizardStep != null && newWizardStep.equalsIgnoreCase("tabDichiarazioneSostitutiva"))
		{
			if(!esercizioProfBean.controllaCampi())
			{
				JSFUtility.scrollTo("form:msgs");
				
				currentWizardStep=oldWizardStep;
				return oldWizardStep;
			}
			
			mostraPulsanteInvio = true;
			
			if(tipologiaUtente.equals("associato"))
			{
				testoPulsanteInvio=StringUtil.getPropertyMessage("pulsante.inserimento.completato",lingua);
			}
			else
			{
				testoPulsanteInvio=StringUtil.getPropertyMessage("pulsante.invia",lingua);
			}
			
			dichiarazioneSostitutivaBean.setTipologiaVersamento(titoliStudioCarrieraBean.getTipologiaVersamento());
			
			//Tipologia Versamento da REGIONE combinata
		    if(!titoliStudioCarrieraBean.isVisualizzaPanelDocumenti() && dichiarazioneSostitutivaBean.getTipologiaVersamento()!=null && dichiarazioneSostitutivaBean.getTipologiaVersamento().equals("Bancario/Postale"))
		    {
			    if(dichiarazioneSostitutivaBean.getIban()!=null && (!dichiarazioneSostitutivaBean.getIban().equals("")))
			    {
			    	dichiarazioneSostitutivaBean.setTipiPagamento("0"); //Bancario
			    }
			    else if (dichiarazioneSostitutivaBean.getNumeroUffPostale()!=null && (!dichiarazioneSostitutivaBean.getNumeroUffPostale().equals("")))
			    {
			    	dichiarazioneSostitutivaBean.setTipiPagamento("1"); //Postale
			    }
			    else
			    {
			    	dichiarazioneSostitutivaBean.setTipiPagamento(""); //Default
			    }
		    }
		    else
		    {
		    	dichiarazioneSostitutivaBean.setTipiPagamento(""); //Default
		    }
		    
			dichiarazioneSostitutivaBean.setElencoDocumenti(titoliStudioCarrieraBean.getElencoDoc());
			
		}
		else
		{
			mostraPulsanteInvio = false;
		}
		JSFUtility.update("pannelloPulsanteInvio");

		JSFUtility.scrollTo("messaggioIniziale");
		
		currentWizardStep=newWizardStep;
		return newWizardStep;
	}

	public RequisitiMinimiBean getRequisitiMinimiBean() {
		return requisitiMinimiBean;
	}

	public void setRequisitiMinimiBean(RequisitiMinimiBean requisitiMinimiBean) {
		this.requisitiMinimiBean = requisitiMinimiBean;
	}

	public TitoliStudioCarrieraBean getTitoliStudioCarrieraBean() {
		return titoliStudioCarrieraBean;
	}

	public void setTitoliStudioCarrieraBean(
			TitoliStudioCarrieraBean titoliStudioCarrieraBean) {
		this.titoliStudioCarrieraBean = titoliStudioCarrieraBean;
	}

	public EsercizioProfBean getEsercizioProfBean() {
		return esercizioProfBean;
	}

	public void setEsercizioProfBean(EsercizioProfBean esercizioProfBean) {
		this.esercizioProfBean = esercizioProfBean;
	}

	public DichiarazioneSostitutivaBean getDichiarazioneSostitutivaBean() {
		return dichiarazioneSostitutivaBean;
	}

	public void setDichiarazioneSostitutivaBean(
			DichiarazioneSostitutivaBean dichiarazioneSostitutivaBean) {
		this.dichiarazioneSostitutivaBean = dichiarazioneSostitutivaBean;
	}

	public DomandaAction getDomandaAction() {
		return domandaAction;
	}

	public void setDomandaAction(DomandaAction domandaAction) {
		this.domandaAction = domandaAction;
	}

	public boolean isFlagVerifica() {
		return flagVerifica;
	}

	public void setFlagVerifica(boolean flagVerifica) {
		this.flagVerifica = flagVerifica;
	}

	public String getCaptchaCode() {
		return captchaCode;
	}

	public void setCaptchaCode(String captchaCode) {
		this.captchaCode = captchaCode;
	}

	public String getCaptchaGenerator() {
		return captchaGenerator;
	}

	public void setCaptchaGenerator(String captchaGenerator) {
		this.captchaGenerator = captchaGenerator;
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public String getTipologiaUtente() {
		return tipologiaUtente;
	}

	public void setTipologiaUtente(String tipologiaUtente) {
		this.tipologiaUtente = tipologiaUtente;
	}

	public String getCodiceRegione() {
		return codiceRegione;
	}

	public void setCodiceRegione(String codiceRegione) {
		this.codiceRegione = codiceRegione;
	}

	public String getDenominazioneRegione() {
		return denominazioneRegione;
	}

	public void setDenominazioneRegione(String denominazioneRegione) {
		this.denominazioneRegione = denominazioneRegione;
	}

	public String getMessaggioErrore() {
		return messaggioErrore;
	}

	public void setMessaggioErrore(String messaggioErrore) {
		this.messaggioErrore = messaggioErrore;
	}
	
	public boolean isModalitaDemo() {
		return modalitaDemo;
	}

	public void setModalitaDemo(boolean modalitaDemo) {
		this.modalitaDemo = modalitaDemo;
	}

	public String getOldWizardStep() {
		return oldWizardStep;
	}

	public void setOldWizardStep(String oldWizardStep) {
		this.oldWizardStep = oldWizardStep;
	}
	
	public String getCurrentWizardStep() {
		return currentWizardStep;
	}

	public void setCurrentWizardStep(String currentWizardStep) {
		this.currentWizardStep = currentWizardStep;
	}

	public String getNewWizardStep() {
		return newWizardStep;
	}

	public void setNewWizardStep(String newWizardStep) {
		this.newWizardStep = newWizardStep;
	}
	
	public boolean getMostraPulsanteInvio() {
		return mostraPulsanteInvio;
	}

	public void setMostraPulsanteInvio(boolean mostraPulsanteInvio) {
		this.mostraPulsanteInvio = mostraPulsanteInvio;
	}

	public String getTestoPulsanteInvio() {
		return testoPulsanteInvio;
	}

	public void setTestoPulsanteInvio(String testoPulsanteInvio) {
		this.testoPulsanteInvio = testoPulsanteInvio;
	}
	
	public RegioneDatiBando getRegioneDatiBando() {
		return regioneDatiBando;
	}

	public void setRegioneDatiBando(RegioneDatiBando regioneDatiBando) {
		this.regioneDatiBando = regioneDatiBando;
	}
	
	public Candidatura getCandidatura() {
		return candidatura;
	}

	public void setCandidatura(Candidatura candidatura) {
		this.candidatura = candidatura;
	}

	public SimpleDateFormat getSdf() {
		return sdf;
	}

	public void setSdf(SimpleDateFormat sdf) {
		this.sdf = sdf;
	}

	/*
	 * public String getAnnoCD() { return annoCD; }
	 * 
	 * public void setAnnoCD(String annoCD) { this.annoCD = annoCD; }
	 * 
	 * public String getMeseCD() { return meseCD; }
	 * 
	 * public void setMeseCD(String meseCD) { this.meseCD = meseCD; }
	 * 
	 * public String getGiornoCD() { return giornoCD; }
	 * 
	 * public void setGiornoCD(String giornoCD) { this.giornoCD = giornoCD; }
	 * 
	 * public String getOreCD() { return oreCD; }
	 * 
	 * public void setOreCD(String oreCD) { this.oreCD = oreCD; }
	 * 
	 * public String getMinCD() { return minCD; }
	 * 
	 * public void setMinCD(String minCD) { this.minCD = minCD; }
	 * 
	 * public String getSecCD() { return secCD; }
	 * 
	 * public void setSecCD(String secCD) { this.secCD = secCD; }
	 */

	public String getStatoCandidatura() {
		return statoCandidatura;
	}

	public void setStatoCandidatura(String statoCandidatura) {
		this.statoCandidatura = statoCandidatura;
	}

	/*
	 * public String getDescBread() { return descBread; }
	 * 
	 * public void setDescBread(String descBread) { this.descBread = descBread;
	 * }
	 */

	public boolean getFlagAutorizzo() {
		return flagAutorizzo;
	}

	public void setFlagAutorizzo(boolean flagAutorizzo) {
		this.flagAutorizzo = flagAutorizzo;
	}

	public boolean getFlaConsapevole() {
		return flaConsapevole;
	}

	public void setFlaConsapevole(boolean flaConsapevole) {
		this.flaConsapevole = flaConsapevole;
	}

}