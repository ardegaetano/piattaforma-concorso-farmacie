package com.accenture.CCFarm.PageBean;

import java.util.Random;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import com.accenture.CCFarm.action.LoginPrimoAccessoAction;
import com.accenture.CCFarm.utility.StringUtil;


@ManagedBean
@RequestScoped
public class LoginBean {
	private String userid; 
	private String password;
	
	
	public String redirectLogin(){
		return  "loginPage";
		
	}
	
	public String autentica(){
		return  "loginPage";
		
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
