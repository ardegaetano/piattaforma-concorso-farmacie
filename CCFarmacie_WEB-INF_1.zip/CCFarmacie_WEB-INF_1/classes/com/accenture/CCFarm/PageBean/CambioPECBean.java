package com.accenture.CCFarm.PageBean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.CambioPECAction;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;


@ManagedBean
@SessionScoped
public class CambioPECBean {
	private String user; 
	private String oldPec;
	private String newPec;
	private String newPecConfirm;
	
	//dati per il captcha -------------
	private String captchaCode;
	private String captchaGenerator;
	//---------------------------------
	
	private boolean flagAccettazioneTermini = false;

	Logger logger = CommonLogger.getLogger("CambioPECBean");
	

	
	public CambioPECBean() {
	

				init();
				captchaGenerator=AppProperties.getAppProperty("bck_immage_path");
	
	}
	
	
	public void init()   {  
    	
		FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	session = req.getSession();
    	String idUtente= (String) session.getAttribute(RepositorySession.ID_UTENTE);
    	String userSession = (String) session.getAttribute(RepositorySession.USER_SESSION);

			try {

				user = userSession;
				UtenteHome utHome = new UtenteHome();
				Utente utente = utHome.findById(idUtente);
				oldPec = utente.getPecMail();
				newPec = null;
				newPecConfirm = null;
				captchaCode = null;
				
			} catch (GestioneErroriException e) {
				
				logger.error("CambioPECBean - init: " + e.getMessage());	
			}
		
		
	}
	
	public void cambioPec(){
		
		session.removeAttribute("cambioPECBean");
		JSFUtility.redirect("cambioPEC.jsf");
	}

	public void confermaPec(){
		
		session.setAttribute(RepositorySession.NEW_PEC_EMAIL, newPec);
		JSFUtility.redirect("confermaRegistrazioneNewPec.jsf");
	}

	public void registraNewPec() throws GestioneErroriException {
		

//		if(getFlagAccettazioneTermini())
//		{
			if(controllaCaptcha())
			{

								try {
									CambioPECAction cambioPECAction = new CambioPECAction ();
									if(cambioPECAction.inviaNewPec()){
										JSFUtility.redirect("RegistrazionePecOk.jsf");
									}
								} catch (GestioneErroriException e) {
									GestioneErroriException eccezione = new GestioneErroriException("CambioPECBean - registraNewPec: errore nell' invio nuova PEC");
									throw eccezione;
								}
			}
			else
			{
				//JSFUtility.addWarningMessage("Attenzione", "Il codice inserito non � corretto");
				String lingua= (String)session.getAttribute("linguaScelta");
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("registrazione.codice.non.corretto", lingua));//"Attenzione", "Il codice inserito non � corretto"
				setCaptchaCode(null);
				
			}
//		}
//		else
//		{
//			JSFUtility.addInfoMessage("Attenzione", "La casella di dichiarazione deve essere spuntata",false);
//			
//		}
	
	}
	
	
	
	
	public void controllaPecVerifica()
	{
		
			 JSFUtility.executeScript("confirmation.show()");
		}
	
	
	private boolean controllaCaptcha()
	
	{
		String correctCaptcha=(String)GetSessionUtility.getSessionAttribute("captchaCode");
		
		System.out.println("captcha corretto: "+correctCaptcha);
		System.out.println("captcha inserito: "+getCaptchaCode());
		
		if(correctCaptcha!=null && getCaptchaCode()!=null && getCaptchaCode().equals(correctCaptcha))
			return true;
		return false;
	}
	
	public String getUser() {
		return user;
	}


	public void setUser(String user) {
		this.user = user;
	}


	public String getOldPec() {
		return oldPec;
	}


	public void setOldPec(String oldPec) {
		this.oldPec = oldPec;
	}


	public String getNewPec() {
		return newPec;
	}


	public void setNewPec(String newPec) {
		this.newPec = newPec;
	}


	public String getNewPecConfirm() {
		return newPecConfirm;
	}


	public void setNewPecConfirm(String newPecConfirm) {
		if(newPecConfirm!=null)
		{
			this.newPecConfirm=newPecConfirm.trim();
		}
		else
		{
			this.newPecConfirm=null;
		}
	}
	
	public boolean getFlagAccettazioneTermini() {
		return flagAccettazioneTermini;
	}


	public void setFlagAccettazioneTermini(boolean flagAccettazioneTermini) {
		this.flagAccettazioneTermini = flagAccettazioneTermini;
	}


	HttpSession session =null;
	public String getCaptchaCode() {
		return captchaCode;
	}


	public void setCaptchaCode(String captchaCode) {
		this.captchaCode = captchaCode;
	}


	public String getCaptchaGenerator() {
		return captchaGenerator;
	}


	public void setCaptchaGenerator(String captchaGenerator) {
		this.captchaGenerator = captchaGenerator;
	}
		
}
