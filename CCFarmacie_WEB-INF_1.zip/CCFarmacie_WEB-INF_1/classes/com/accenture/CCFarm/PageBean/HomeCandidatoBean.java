package com.accenture.CCFarm.PageBean;

import java.io.IOException;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.model.StreamedContent;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaReg;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.RegioneDatiBando;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.DAO.UtenteCandidaturaHome;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PDFModulo.GestionePDFModuloRicevuta;
import com.accenture.CCFarm.action.HomeCandidatoAction;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;


@ManagedBean
@ViewScoped
public class HomeCandidatoBean {
//  private final String pulsanteStampa = "none";  // hidden se nel css utilizzi visibility
	private String pulsanteContatti = "none";
	private String imgContatti = "none";
	private String cursContatti = "cursor:default";



	private String visContatti = "true";
	private String pulsanteModPsw = "none";
	private String pulsanteModPec = "none";
	private String imgModPsw = "../images/layout/btn_modifica_password.png";
	private String imgModPec ="../images/layout/modificaPEC.png";



	private String visModPsw = "true";

	private String visModPec = "false";
	private String showPecMess1 = "";
	private String showPecMess2 = "";
	private String showPecMess3 = "";
	private String pecMessTypeOp = "";
	private String pecMessTypeEsito = "";
	
	private String pulsanteAnnulla = "none";
	private String imgAnnulla = "none";
	private String visAnnulla = "true";
	private String pulsanteGesrisciDom = "none";
	private String imgGesrisciDom = "none";
	private String linkGesrisciDom = "none";
	private String visGesrisciDom = "true";
	private String pulsanteStampaRic = "none";
	private String imgStampaRic = "none";
	private String visStampaRic = "true";
	private String pulsanteVisDomAss = "none";
	private String imgVisDomAss = "none";
	private String visVisDomAss = "true";
	
	private String pulsanteVisSceltaSedi="none";
	private String imgVisSceltaSedi = "none";
	private String visVisSceltaSedi = "true";
	
	private String pulsanteVisAccettazioneRinunciaSede="none";
	private String imgVisAccettazioneRinunciaSede = "none";
	private String visAccettazioneRinunciaSede = "true";
	
	private String msgAssociata="";
	private String esitoAnnullaDom="";
	
	private RegioneDatiBando regioneDatiBando= null;
	private Candidatura candidatura = null;
	private String statoBando="";
	private String idUtente="";
	//private String pecMail = null; 
	private String statoRichModPecMail = null;


	private FacesContext context =null;
	private HttpSession session= null; 
	private HttpServletRequest request=null; 
	
	Logger logger = CommonLogger.getLogger("HomeCandidatoBean");
	HomeCandidatoAction action= null;
	private StreamedContent fileDownLoad;
 
	
	public HomeCandidatoBean(){
		try {
			init();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	
	public void init() throws GestioneErroriException {  
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		action = new HomeCandidatoAction();
		
		UtenteHome utenteHome = new UtenteHome();
		
		context = FacesContext.getCurrentInstance();
    	//HttpSession session = (HttpSession)context.getExternalContext().getSession(true);
		request = (HttpServletRequest) context.getExternalContext().getRequest();
    
    	session = request.getSession();

    	regioneDatiBando =  (RegioneDatiBando) session.getAttribute(RepositorySession.REGIONI_DATI_BANDO);
    	candidatura = (Candidatura) session.getAttribute(RepositorySession.CANDIDATURA);
       	statoBando = (String) session.getAttribute(RepositorySession.STATO_BANDO_REGIONE);
    	idUtente = (String) session.getAttribute(RepositorySession.ID_UTENTE);
			
    	pulsanteContatti = "block";
    	
    	imgContatti = JSFUtility.getPropertyMessage("immagini.pulsante.contatti", lingua);
//    	imgContatti = "../images/layout/btn_contatti.png";
    	visContatti = "false";
    	
    	pulsanteModPsw = "block";

    	imgModPsw =  JSFUtility.getPropertyMessage("immagini.pulsante.modpass", lingua);
//    	imgModPsw = "../images/layout/btn_modifica_password.png";
    	visModPsw = "false";
    
    	statoRichModPecMail = recuperaStatoRichPecMail();  
    	
    	pulsanteModPec = "block";
    	
    	if (regioneDatiBando.getDatiBando().getAbilitaRichModPec()!=null && regioneDatiBando.getDatiBando().getAbilitaRichModPec().equalsIgnoreCase("true")){
    		// pulsante abilitato
    		CandidaturaReg candidaturaReg = new CandidaturaReg();
    		CandidaturaRegHome candidaturaRegHome = new CandidaturaRegHome();
    		try {
				candidaturaReg= candidaturaRegHome.findById(idUtente);
			} catch (GestioneErroriException e) {
				e.printStackTrace();
			}
    		if (candidaturaReg!=null && candidaturaReg.getAmmesso()!=null && candidaturaReg.getAmmesso().equalsIgnoreCase("SI")){
    		
    			visModPec = "true";	
    		} else{
    			visModPec = "false";
    		}
    		
    	}
//    	if (regioneDatiBando.getDatiBando().getAbilitaRichModPec()==null || regioneDatiBando.getDatiBando().getAbilitaRichModPec().equalsIgnoreCase("false")){
//    		// pulsante disabilitato
//    		visModPec = "false";
//    	}
    	
//    	imgModPec = "../images/layout/modificaPEC.png";
//    	visModPec = "false";
    	
    	msgAssociata="";
    	pulsanteAnnulla = "block";
    	if (statoBando!=null){
	    	if (!statoBando.equalsIgnoreCase("R")	){
	    		if (candidatura.getModalitaCandidatura().equalsIgnoreCase("S")){
	//candidatura singola
	    			//if (candidatura.getStatoDomanda().equalsIgnoreCase("B")){
	    				//Pulsante abilitato per stato domanda bozza
	    				imgAnnulla = JSFUtility.getPropertyMessage("immagini.pulsante.annulla.domanda", lingua);
//	    				imgAnnulla = "../images/layout/btn_annulla_domanda.png";
		    	    	visAnnulla = "false";
	    			/*} else {
					//  pulsante bloccato per candidatura associata ma non referente  				
	    		    	imgAnnulla = "../images/layout/btn_annulla_domanda_dis.png";
	    		    	visAnnulla = "true";
	    			}*/
		        } else{
	//candidatura in Associata
		        	if (candidatura.getReferenteDomanda().equalsIgnoreCase("Y")){
		        		//if (candidatura.getStatoDomanda().equalsIgnoreCase("B") ){
		        			//Pulsante abilitato candidatura associata per il referente se stato domanda e' Bozza
	        				msgAssociata = JSFUtility.getPropertyMessage("homeCandidatoBean.utenze.collegate", lingua);
//		        			msgAssociata=" e tutte le utenze collegate alla domanda in Associata";
		        			imgAnnulla = JSFUtility.getPropertyMessage("immagini.pulsante.annulla.domanda.dis", lingua);
//		        			imgAnnulla = "../images/layout/btn_annulla_domanda.png";
		        	    	visAnnulla = "false";	
		        		/*} else {
		        			//  pulsante bloccato per candidatura associata ma non referente  				
		    		    	imgAnnulla = "../images/layout/btn_annulla_domanda_dis.png";
		    		    	visAnnulla = "true";
		        		}*/
		        	} else {
	//  pulsante bloccato per candidatura associata ma non referente  				
	        			imgAnnulla = JSFUtility.getPropertyMessage("immagini.pulsante.annulla.domanda.dis", lingua);
//	    		    	imgAnnulla = "../images/layout/btn_annulla_domanda_dis.png";
	    		    	visAnnulla = "true";
	    			}
	    		}
	    	} else {
	//Pulsante non abilitato
    			imgAnnulla = JSFUtility.getPropertyMessage("immagini.pulsante.annulla.domanda.dis", lingua);
//    		imgAnnulla = "../images/layout/btn_annulla_domanda_dis.png";
		    	visAnnulla = "true";
	    		
	    	}
    	}    	
    	pulsanteGesrisciDom = "block";
    	imgGesrisciDom =  JSFUtility.getPropertyMessage("immagini.pulsante.gestisci.domanda", lingua);
//    	imgGesrisciDom = "../images/layout/btn_gestisci_domanda.png";
    	visGesrisciDom = "false";
    	if (statoBando!=null)
    	{
	    	if(!statoBando.equalsIgnoreCase("R"))
	    	{
	    		//domanda modificabile  
	    		if(candidatura.getStatoDomanda().equalsIgnoreCase("B"))
	    		{
	    			linkGesrisciDom="compilaDomanda.jsf";	
	    		}
	    		else
	    		{
	    			//domanda non modificabile   in visualizzazione 		
	    			linkGesrisciDom="visualizzaDomanda.jsf" ;
	    		}
	    	}
	    	else
	    	{
	    		//domanda non modificabile   in visualizzazione 		
	    		linkGesrisciDom="visualizzaDomanda.jsf" ;
	    	}
    	}
    
    	pulsanteStampaRic = "block";
    	pulsanteModPec = "block";
    	if (candidatura!=null)
    	{
	    	if(candidatura.getStatoDomanda().equalsIgnoreCase("I")||candidatura.getStatoDomanda().equalsIgnoreCase("T")){
	//stampa abilitata
	    		imgStampaRic = JSFUtility.getPropertyMessage("immagini.pulsante.stampa.ricevuta", lingua);
//	    		imgStampaRic = "../images/layout/btn_stampa_ricevuta.png";
		    	visStampaRic = "false";
		    	imgModPec = JSFUtility.getPropertyMessage("immagini.pulsante.modifica.pec", lingua);
//		    	imgModPec = "../images/layout/modificaPEC.png";
		    	
		    	if (statoRichModPecMail!=null && statoRichModPecMail.equalsIgnoreCase("I")){
		    		visModPec = "true";// pulsante disabilitato
		    		showPecMess1 ="true"; 
		    		pecMessTypeOp="1";// mess 'Richiesta presa in carico'
		    		showPecMess2 ="false";
		    		showPecMess3 ="false";
		    	}
		    	if (statoRichModPecMail!=null && statoRichModPecMail.equalsIgnoreCase("W")){
		    		visModPec = "true";// pulsante disabilitato
		    		showPecMess1 ="true"; 
		    		pecMessTypeOp="2";// mess 'Richiesta in attesa di conferma'
		    		showPecMess2 ="false";
		    		showPecMess3 ="false";
		    	}
		    	if (statoRichModPecMail!=null && statoRichModPecMail.equalsIgnoreCase("R")){
		    		visModPec = "true";// pulsante abilitato
		    		showPecMess2 ="true";
		    		showPecMess1 ="false";
		    		showPecMess3 ="false";
		    		pecMessTypeEsito="2";// mess 'Richiesta rifiutata'
		    		Utente uteApp = new Utente();
		    		try{
		    			uteApp = utenteHome.findById(idUtente);
			    		uteApp.setRichiestaCambioPecMail("");
			    	    utenteHome.saveOrUpdate(uteApp);
		    		}
		    		catch(Exception e){
		    			
		    		}
		    				    	   
		    	}
		    	if (statoRichModPecMail!=null && statoRichModPecMail.equalsIgnoreCase("F")){
		    		visModPec = "true";// pulsante abilitato
		    		showPecMess2 ="false";
		    		showPecMess1 ="false";
		    		showPecMess3 ="true";// mess 'Richiesta fallita'		    		
		    		Utente uteApp = new Utente();
		    		try{
		    			uteApp = utenteHome.findById(idUtente);
			    		uteApp.setRichiestaCambioPecMail("");
			    	    utenteHome.saveOrUpdate(uteApp);
		    		}
		    		catch(Exception e){
		    			
		    		}
		    				    	   
		    	}
		    	if (statoRichModPecMail!=null && statoRichModPecMail.equalsIgnoreCase("A")){
		    		visModPec = "true";// pulsante abilitato
		    		showPecMess2 ="true";
		    		showPecMess1 ="false";
		    		showPecMess3 ="false";
		    		pecMessTypeEsito="1";// mess 'Richiesta accettata'
		    		Utente uteApp = new Utente();
		    		try{
		    			uteApp = utenteHome.findById(idUtente);
			    		uteApp.setRichiestaCambioPecMail("");
			    	    utenteHome.saveOrUpdate(uteApp);
		    		}
		    		catch(Exception e){
		    			
		    		}
		    				    	   
		    	}
//		    	if (statoRichModPecMail==null || statoRichModPecMail.equalsIgnoreCase("")){
//		    		visModPec = "false";
//		    		showPecMess ="false";
//		    				    	   
//		    	}
//		    	visModPec = "false";
	    	} else {
	//  stampa non abilitata  		
	    		imgStampaRic =JSFUtility.getPropertyMessage("immagini.pulsante.stampa.ricevuta", lingua);
//	    		imgStampaRic = "../images/layout/btn_stampa_ricevuta_dis.png";
		    	visStampaRic = "true";
		    	imgModPec = JSFUtility.getPropertyMessage("immagini.pulsante.modifica.pec", lingua);
//		    	imgModPec = "../images/layout/modificaPEC.png";
		    	visModPec = "false";
		    	showPecMess1 ="false";
		    	showPecMess2 ="false";
	    	}
    	}
    	imgVisDomAss = JSFUtility.getPropertyMessage("immagini.pulsante.visualizza.domande", lingua);
//    	imgVisDomAss = "../images/layout/btn_visualizza_domande.png";
    	if (candidatura!=null)
    	{    	
	    	if (candidatura.getModalitaCandidatura().equalsIgnoreCase("A")){
	    		pulsanteVisDomAss = "block";
	    		visVisDomAss = "false";
	    	} else{
	    		pulsanteVisDomAss = "none";
	    		visVisDomAss = "true";
	        }
    	
    	
	    	if (candidatura.getStatoDomanda().equals("A") && candidatura.getStatoRegistrazione().equals("A")){
	    		imgModPsw = JSFUtility.getPropertyMessage("immagini.pulsante.modifica.password.dis", lingua);
//	    		imgModPsw = "../images/layout/btn_modifica_password_dis.png";
	        	visModPsw = "true";
	        	imgAnnulla = JSFUtility.getPropertyMessage("immagini.pulsante.annulla.domanda.dis", lingua);
//	        	imgAnnulla = "../images/layout/btn_annulla_domanda_dis.png";
		    	visAnnulla = "true";
		    	imgGesrisciDom = JSFUtility.getPropertyMessage("immagini.pulsante.gestisci.domanda.dis", lingua);
//		    	imgGesrisciDom = "../images/layout/btn_gestisci_domanda_dis.png";
		    	visGesrisciDom = "true";
		    	imgStampaRic = JSFUtility.getPropertyMessage("immagini.pulsante.stampa.ricevuta.dis", lingua);
//		    	imgStampaRic = "../images/layout/btn_stampa_ricevuta_dis.png";
		    	visStampaRic = "true";
		    	imgVisDomAss = JSFUtility.getPropertyMessage("immagini.pulsante.annulla.domanda.dis", lingua);
//		    	imgVisDomAss = "../images/layout/btn_visualizza_domande_dis.png";
		    	visVisDomAss = "true";
		    	imgModPec = JSFUtility.getPropertyMessage("immagini.pulsante.modifica.pec", lingua);
//		    	imgModPec = "../images/layout/modificaPEC.png";
		    	visModPec = "false";
		    	showPecMess1 ="false";
		    	showPecMess2 ="false";
	    	}
    	}
    	
    	//controlla se al momento l'utente risulta abilitato alla scelta delle sedi
    	if(action.controllaAbilitazioneSceltaSedi(regioneDatiBando.getCodReg(), idUtente)) {
    		
    		//pulsante scelta sedi visibile solo nel caso in cui l'utente risulti abilitato all'espressione di preferenze sulle sedi
			pulsanteVisSceltaSedi = "block";
			imgVisSceltaSedi = JSFUtility.getPropertyMessage("immagini.pulsante.sceltaSedi", lingua);
			visVisSceltaSedi = "false";
    	}
    	else {
    		
    		//pulsante scelta sedi nascosto nel caso in cui l'utente NON risulti abilitato alla scelta delle sedi
			pulsanteVisSceltaSedi = "none";
			imgVisSceltaSedi = JSFUtility.getPropertyMessage("immagini.pulsante.sceltaSedi", lingua);
			visVisSceltaSedi = "true";
    	}
    	
    	//controlla se al momento l'utente risulta abilitato all'accettazione/rinuncia della sede assagnatagli
    	if(action.controllaAbilitazioneAccettazioneRinunciaSede(regioneDatiBando.getCodReg(), idUtente)) {
    		
    		//pulsante accetta/rinuncia sede visibile solo nel caso in cui l'utente risulti abilitato all'accettazione/rinuncia della sede
			pulsanteVisAccettazioneRinunciaSede = "block";
			imgVisAccettazioneRinunciaSede = JSFUtility.getPropertyMessage("immagini.pulsante.accettazioneRinunciaSede", lingua);
			visAccettazioneRinunciaSede = "false";
    	}
    	else {
    		
    		//pulsante accetta/rinuncia sede nascosto nel caso in cui l'utente NON risulti abilitato all'accettazione/rinuncia della sede
    		pulsanteVisAccettazioneRinunciaSede = "none";
    		imgVisAccettazioneRinunciaSede = JSFUtility.getPropertyMessage("immagini.pulsante.accettazioneRinunciaSede", lingua);
    		visAccettazioneRinunciaSede = "true";
    	}
	}

	
	public void sendGestisciDom(){
		((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).removeAttribute("domandaVisualizzazione");
		((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).removeAttribute("domanda");
		
		JSFUtility.redirect(linkGesrisciDom);
//  	    return linkGesrisciDom;
	}
	
	public void scegliSedi() {
		
		JSFUtility.redirect("scegliSedi.jsf");
	}
	
	public void accettazioneRinunciaSede() {
		
		JSFUtility.redirect("accettazioneRinunciaSede.jsf");
	}
	
	public void contatti(){
		
		JSFUtility.redirect("contatti.jsf");
//  	    return linkGesrisciDom;
	}
	public void confermaAnnullaDom(){
		
		JSFUtility.redirect("confermaAnnullaDom.jsf");
//  	    return linkGesrisciDom;
	}
	
	public void listaPartecipantiAssociazione(){
		
		JSFUtility.redirect("listaPartecipantiAssociazione.jsf");
//  	    return linkGesrisciDom;
	}
	
	
	public void cambioPassword(){
		JSFUtility.redirect("loginCambioPassword.jsf");
//		return "loginCambioPassword.jsf";
	}
	
	@SuppressWarnings("unchecked")
	public void annullaDomanda() {
	
		boolean annullaEsegito= false;
		
		UtenteCandidaturaHome utenteCandidaturaHome = new UtenteCandidaturaHome();
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String linguaScelta= (String)session.getAttribute("linguaScelta");
		
		try{
			
			if (!candidatura.getModalitaCandidatura().equals("A") || (candidatura.getReferenteDomanda()!=null && candidatura.getReferenteDomanda().equalsIgnoreCase("Y"))){
				// Annulliamo tutta la candidatura e mandiamo una mail di avviso a tutti gli utenti che fanno parte della candidatura
				
				List<UtenteCandidatura> listaUtenteCandidati = (List<UtenteCandidatura>) utenteCandidaturaHome.findByQuery("select u from UtenteCandidatura u where u.candidatura.idCandidatura='" + candidatura.getIdCandidatura() + "'");
				
				utenteCandidaturaHome.annullaDomanda(listaUtenteCandidati, linguaScelta);
				annullaEsegito = true;
			}
		}catch(Exception ex){
			
		}
		
		
		
		if (annullaEsegito){
			esitoAnnullaDom = JSFUtility.getPropertyMessage("homeCandidatoBean.esito.anndom.corretta", linguaScelta);
//			esitoAnnullaDom="Annullamento domanda eseguito correttamente";
		} else{
			esitoAnnullaDom = JSFUtility.getPropertyMessage("homeCandidatoBean.esito.anndom.errata", linguaScelta);
//			esitoAnnullaDom="La funzione di Annullamento domanda non � stata eseguita!!! Riprovare in seguito";
		}
		
		JSFUtility.redirect("AnnullaDomEsito.jsf");
	}
	
	public String recuperaStatoRichPecMail()
	{
		String app="";
		try{
			app = action.getStatoRichMailPec(this, idUtente);
		} catch (GestioneErroriException e) {
			logger.error("HomeCandidatoBean - recuperaStatoRichPecMail: " + e.getMessage());
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
		return app;
	}
	
	public void caricaFileDownLoad()
	{
		try{
			action.caricaFileDownload(this);
		} catch (GestioneErroriException e) {
			logger.error("HomeCandidatoBean - caricaFileDownload: " + e.getMessage());
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
	}
	
	public String caricaRicevuta()
	{
	   GestionePDFModuloRicevuta gestionePDFModuloRicevuta= new GestionePDFModuloRicevuta();
//	   Utente utente = new Utente();
//	   utente.setIdUtente(idUtente);
	   
	   gestionePDFModuloRicevuta.ristampaRicevutaIdUtentePDF(candidatura.getIdCandidatura());
//	   gestionePDFModuloRicevuta.initEntityPDFromEntityUtente(utente);
	   gestionePDFModuloRicevuta.downloadFile();
	   
	   return null;
		
	}
//	
//	public void addMessage(String Intestazione, String summary) {
//		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,Intestazione, summary);
//		FacesContext.getCurrentInstance().addMessage(null, message);
//	}
//	
//	public void addMessageError(String summary) {
//		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN,"ATTENZIONE", summary);
//		FacesContext.getCurrentInstance().addMessage(null, message);
//	}

	public void esitoDomandaAnnulla(){
        
        
        HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
            
        try {
                response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/cartinaItalia.jsp");
        } catch (IOException e) {
                e.printStackTrace();
        }
        
	}

	public String getPulsanteContatti() {
		return pulsanteContatti;
	}


	public String getMsgAssociata() {
		return msgAssociata;
	}


	public void setMsgAssociata(String msgAssociata) {
		this.msgAssociata = msgAssociata;
	}


	public HttpSession getSession() {
		return session;
	}


	public void setSession(HttpSession session) {
		this.session = session;
	}


	public String getLinkGesrisciDom() {
		return linkGesrisciDom;
	}


	public void setLinkGesrisciDom(String linkGesrisciDom) {
		this.linkGesrisciDom = linkGesrisciDom;
	}


	public String getPulsanteVisDomAss() {
		return pulsanteVisDomAss;
	}


	public void setPulsanteVisDomAss(String pulsanteVisDomAss) {
		this.pulsanteVisDomAss = pulsanteVisDomAss;
	}


	public String getImgVisDomAss() {
		return imgVisDomAss;
	}


	public void setImgVisDomAss(String imgVisDomAss) {
		this.imgVisDomAss = imgVisDomAss;
	}


	public String getCursContatti() {
		return cursContatti;
	}


	public void setCursContatti(String cursContatti) {
		this.cursContatti = cursContatti;
	}


	public String getImgContatti() {
		return imgContatti;
	}


	public void setImgContatti(String imgContatti) {
		this.imgContatti = imgContatti;
	}


	public void setPulsanteContatti(String pulsanteContatti) {
		this.pulsanteContatti = pulsanteContatti;
	}


	public String getPulsanteModPsw() {
		return pulsanteModPsw;
	}


	public void setPulsanteModPsw(String pulsanteModPsw) {
		this.pulsanteModPsw = pulsanteModPsw;
	}


	public String getImgModPsw() {
		return imgModPsw;
	}


	public void setImgModPsw(String imgModPsw) {
		this.imgModPsw = imgModPsw;
	}


	public String getPulsanteAnnulla() {
		return pulsanteAnnulla;
	}


	public void setPulsanteAnnulla(String pulsanteAnnulla) {
		this.pulsanteAnnulla = pulsanteAnnulla;
	}


	public String getImgAnnulla() {
		return imgAnnulla;
	}


	public void setImgAnnulla(String imgAnnulla) {
		this.imgAnnulla = imgAnnulla;
	}

	public String getPulsanteGesrisciDom() {
		return pulsanteGesrisciDom;
	}


	public void setPulsanteGesrisciDom(String pulsanteGesrisciDom) {
		this.pulsanteGesrisciDom = pulsanteGesrisciDom;
	}


	public String getImgGesrisciDom() {
		return imgGesrisciDom;
	}


	public void setImgGesrisciDom(String imgGesrisciDom) {
		this.imgGesrisciDom = imgGesrisciDom;
	}


	public String getPulsanteStampaRic() {
		return pulsanteStampaRic;
	}


	public void setPulsanteStampaRic(String pulsanteStampaRic) {
		this.pulsanteStampaRic = pulsanteStampaRic;
	}


	public String getImgStampaRic() {
		return imgStampaRic;
	}


	public void setImgStampaRic(String imgStampaRic) {
		this.imgStampaRic = imgStampaRic;
	}


	public RegioneDatiBando getRegioneDatiBando() {
		return regioneDatiBando;
	}


	public void setRegioneDatiBando(RegioneDatiBando regioneDatiBando) {
		this.regioneDatiBando = regioneDatiBando;
	}


	public Candidatura getCandidatura() {
		return candidatura;
	}


	public void setCandidatura(Candidatura candidatura) {
		this.candidatura = candidatura;
	}


	public String getStatoBando() {
		return statoBando;
	}


	public void setStatoBando(String statoBando) {
		this.statoBando = statoBando;
	}


	public String getIdUtente() {
		return idUtente;
	}


	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}


	public FacesContext getContext() {
		return context;
	}


	public void setContext(FacesContext context) {
		this.context = context;
	}


	public HttpServletRequest getRequest() {
		return request;
	}


	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}


	public String getVisContatti() {
		return visContatti;
	}


	public void setVisContatti(String visContatti) {
		this.visContatti = visContatti;
	}


	public String getVisModPsw() {
		return visModPsw;
	}


	public void setVisModPsw(String visModPsw) {
		this.visModPsw = visModPsw;
	}


	public String getVisAnnulla() {
		return visAnnulla;
	}


	public void setVisAnnulla(String visAnnulla) {
		this.visAnnulla = visAnnulla;
	}


	public String getVisGesrisciDom() {
		return visGesrisciDom;
	}


	public void setVisGesrisciDom(String visGesrisciDom) {
		this.visGesrisciDom = visGesrisciDom;
	}


	public String getVisStampaRic() {
		return visStampaRic;
	}


	public void setVisStampaRic(String visStampaRic) {
		this.visStampaRic = visStampaRic;
	}


	public void setVisVisDomAss(String visVisDomAss) {
		this.visVisDomAss = visVisDomAss;
	}
	
	public String getVisVisDomAss() {
		   ((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).removeAttribute("domandaVisualizzazione");
		   ((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).removeAttribute("idUtenteAssociato");
			return visVisDomAss;
		}


	public HomeCandidatoAction getAction() {
		return action;
	}


	public void setAction(HomeCandidatoAction action) {
		this.action = action;
	}


	public StreamedContent getFileDownLoad() {
		return fileDownLoad;
	}


	public void setFileDownLoad(StreamedContent fileDownLoad) {
		this.fileDownLoad = fileDownLoad;
	}


	public String getEsitoAnnullaDom() {
		return esitoAnnullaDom;
	}


	public void setEsitoAnnullaDom(String esitoAnnullaDom) {
		this.esitoAnnullaDom = esitoAnnullaDom;
	}
	
	
	public String getPulsanteModPec() {
		return pulsanteModPec;
	}


	public void setPulsanteModPec(String pulsanteModPec) {
		this.pulsanteModPec = pulsanteModPec;
	}
	
	public String getImgModPec() {
		return imgModPec;
	}


	public void setImgModPec(String imgModPec) {
		this.imgModPec = imgModPec;
	}


	public String getVisModPec() {
		return visModPec;
	}


	public void setVisModPec(String visModPec) {
		this.visModPec = visModPec;
	}


	public String getShowPecMess1() {
		return showPecMess1;
	}


	public void setShowPecMess1(String showPecMess1) {
		this.showPecMess1 = showPecMess1;
	}


	public String getShowPecMess2() {
		return showPecMess2;
	}


	public void setShowPecMess2(String showPecMess2) {
		this.showPecMess2 = showPecMess2;
	}


	public String getShowPecMess3() {
		return showPecMess3;
	}


	public void setShowPecMess3(String showPecMess3) {
		this.showPecMess3 = showPecMess3;
	}


	public String getPecMessTypeOp() {
		return pecMessTypeOp;
	}


	public void setPecMessTypeOp(String pecMessTypeOp) {
		this.pecMessTypeOp = pecMessTypeOp;
	}


	public String getPecMessTypeEsito() {
		return pecMessTypeEsito;
	}


	public void setPecMessTypeEsito(String pecMessTypeEsito) {
		this.pecMessTypeEsito = pecMessTypeEsito;
	}


	public String getStatoRichModPecMail() {
		return statoRichModPecMail;
	}


	public void setStatoRichModPecMail(String statoRichModPecMail) {
		this.statoRichModPecMail = statoRichModPecMail;
	}


	public String getPulsanteVisSceltaSedi() {
		return pulsanteVisSceltaSedi;
	}


	public void setPulsanteVisSceltaSedi(String pulsanteVisSceltaSedi) {
		this.pulsanteVisSceltaSedi = pulsanteVisSceltaSedi;
	}


	public String getImgVisSceltaSedi() {
		return imgVisSceltaSedi;
	}


	public void setImgVisSceltaSedi(String imgVisSceltaSedi) {
		this.imgVisSceltaSedi = imgVisSceltaSedi;
	}


	public String getVisVisSceltaSedi() {
		return visVisSceltaSedi;
	}


	public void setVisVisSceltaSedi(String visVisSceltaSedi) {
		this.visVisSceltaSedi = visVisSceltaSedi;
	}


	public String getPulsanteVisAccettazioneRinunciaSede() {
		return pulsanteVisAccettazioneRinunciaSede;
	}


	public void setPulsanteVisAccettazioneRinunciaSede(
			String pulsanteVisAccettazioneRinunciaSede) {
		this.pulsanteVisAccettazioneRinunciaSede = pulsanteVisAccettazioneRinunciaSede;
	}


	public String getImgVisAccettazioneRinunciaSede() {
		return imgVisAccettazioneRinunciaSede;
	}


	public void setImgVisAccettazioneRinunciaSede(
			String imgVisAccettazioneRinunciaSede) {
		this.imgVisAccettazioneRinunciaSede = imgVisAccettazioneRinunciaSede;
	}


	public String getVisAccettazioneRinunciaSede() {
		return visAccettazioneRinunciaSede;
	}


	public void setVisAccettazioneRinunciaSede(String visAccettazioneRinunciaSede) {
		this.visAccettazioneRinunciaSede = visAccettazioneRinunciaSede;
	}
	
}
