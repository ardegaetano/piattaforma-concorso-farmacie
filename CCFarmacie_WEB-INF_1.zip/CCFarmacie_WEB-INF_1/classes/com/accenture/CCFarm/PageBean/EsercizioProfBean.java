package com.accenture.CCFarm.PageBean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.accenture.CCFarm.Bean.ComuneSelect;
import com.accenture.CCFarm.Bean.EsercizioProfessionale;
import com.accenture.CCFarm.Bean.ParafarmacieSearch;
import com.accenture.CCFarm.Bean.ProvinciaSelect;
import com.accenture.CCFarm.Bean.RegioneSelect;
import com.accenture.CCFarm.Bean.Ruolo;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.FarmacieSearch;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.EsercizioProfAction;
import com.accenture.CCFarm.utility.CaricaRuoli;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.Help;
import com.accenture.CCFarm.utility.HelpDe;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.StringUtil;


@ManagedBean
@SessionScoped
public class EsercizioProfBean
{
	
	private String idEsercizio;
	private String idDomandaEs;
	private String codRuoloEs;
	
	private boolean isRuoloCategoriaCDE;
	
	private String descrizioneRuolo;
	private String denEsercizio;
	
	private String flagEstero;
	
	private String indirizzoEs;
	private String capEs;
	private String comuneEs;
	private String comuneEsDescr;
	private String flagFarmRurale;
	private String regEs;
	private String regEsDescr;
	private String prvEs;
	private String prvEsDescr;
	private String aslEs;
	private String aslDenom;
	private Date dataInizioEs;
	private Date dataFineEs;
	private String codModalitaEs;
	private String codCategoriaEs;
	
	private ArrayList<String> regioniList;
	
	private List<RegioneSelect> regioniSelect;
	private HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect;
	private HashMap<String, ArrayList<ComuneSelect>> comuniSelect;
	private ArrayList<ProvinciaSelect> provinceList;
	private ArrayList<ComuneSelect> comuniList;
	
	private List<Ruolo> ruoli;
	private Ruolo ruoloSelezionato;
	private Domanda domanda;
	
	private String[]listaHelpRicercaFarm;
	private String[]listaHelpRicercaParaFarm;
	
	private Date dataNascitaUtente;
	private Date dataIscrizioneAlbo;
	
    Date data_pubb_appoggio;
    Date dataPubblicazioneBando;
    String codiceRegione;
    
//	Date dataNascitaUtente = new Date (System.currentTimeMillis());
//	Date dataIscrizioneAlbo = new Date (System.currentTimeMillis());
//	Date data_pubb_appoggio = new Date (System.currentTimeMillis());
//	Date dataPubblicazioneBando = new Date (System.currentTimeMillis());
    
	//ricerca farmacie
	
	private boolean attivaProvincia=true;
	private boolean attivaComune = true;
	private boolean ricercaFarmacieBoolean=false;
	private boolean elencoFarmacieBoolean=false;
	private String indirizzo="";
	private String partitaIVA="";
	private String codCap="";
	private FarmacieSearch farmaciaSelected;
	private List<FarmacieSearch>  listaFarmacie;
	private String regioneSelezionata,provinciaSelezionata,comuneSelezionato;
	//private boolean ricercaFarmacieReq=false;
	private boolean abilitaRicercaFarmacieButton=false;
	
	private boolean disabilitaRicercaButton = true;
	private boolean disabilitaRicercaParaButton = true;
	private boolean showListFarma = false;
	private boolean showListPara = false;
	
	//ricerca parafarmacie
	private boolean ricercaParafarmacieBoolean=false;
	private boolean elencoParafarmacieBoolean=false;
	private ParafarmacieSearch parafarmaciaSelected;
    private String indirizzoParafarmacie="";
	private String partitaIVAParafarmacie="";
	private String codCapParafarmacie="";
	private String farmacieSelectedParafarmacie="";
	private List<ParafarmacieSearch>  listaParafarmacie;
	private boolean attivaProvinciaParafarmacie=true;
	private boolean attivaComuneParafarmacie = true;
	private boolean validRequired = false;
	private boolean abilitaRicercaParafarmacieButton=false;
	
	private String regioneSelezionataParafarmacia,provinciaSelezionataParafarmacia,comuneSelezionatoParafarmacia;
	//--------------------------------------------------------------------------------------------------------------
	
	
	EsercizioProfAction esercizioProfAction;
	
	private boolean aggiungiPannelloRicercaBoolean=false;
	
	ArrayList<EsercizioProfessionale> listaEserciziProfessionali;
	private EsercizioProfessionale esercizioProfessionale;
	private EsercizioProfessionale esercizioProfessionaleSelezionato;
	
	private SimpleDateFormat sdf = new SimpleDateFormat();
     
	Logger logger = CommonLogger.getLogger("EsercizioProfBean");
	
	
	public EsercizioProfBean()
	{
		try
		{
			findDateBando();
			
			initListaRegioni();
			
			setRegioniSelect(Localita.getRegioni());
			esercizioProfAction=new EsercizioProfAction();
			listaEserciziProfessionali = new ArrayList<EsercizioProfessionale>();
			ruoli = CaricaRuoli.getRuoli();
		}
		catch (GestioneErroriException e)
		{
			logger.error("EsercizioProfBean - init: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf"); 
		}
	}
	
	private void findDateBando()
    {
	  data_pubb_appoggio = ((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataInizioPubblicazioni();
      dataPubblicazioneBando = ((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataPubblicazioneBando();
    }
	
	private void initListaRegioni()
	{
		//popola la lista delle aree geografiche con le regioni italiane e le nazioni dello spazio economico europeo
		regioniSelect=Localita.getRegioni();
			
		//pre-popola una lookup list con i nomi di tutte le regioni italiane (in MAIUSCOLO)
		regioniList=new ArrayList<String>();
		
		for(RegioneSelect regione : regioniSelect)
		{
			if(regione!=null)
			{
				regioniList.add(regione.getDescrizione().toUpperCase());
			}
		}
	}
	
	public boolean controllaCorrettezzaRegione()
	{
        if(regEs==null)
        	return false;
		
		List<String> areaGeoList=regioniList;
		
		//se la regione inserita non compare tra quelle previste
		if(!areaGeoList.contains(regEs.toUpperCase()))
        {
        	String suggerimento=StringUtil.trovaSuggerimento(regEs,areaGeoList);
        	
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
        	JSFUtility.addWarningMessage("",regEs+": "+
        			JSFUtility.getPropertyMessage("esercizioProfBean.regione.inesistente", lingua) +
					((suggerimento!=null)?"("+JSFUtility.getPropertyMessage("esercizioProfBean.stavi.cercando", lingua) + suggerimento+")":""),"form:msgs");
        	
        	
//        	JSFUtility.addWarningMessage("",regEs+": "+
//        									"Regione inesistente "+
//        									((suggerimento!=null)?"("+"forse stavi cercando: "+suggerimento+")":""),"form:msgs");
        	return false;
        }
		
        return true;
	}
	
	public void eseProfValidReq(javax.faces.event.AjaxBehaviorEvent event){
		
		if(flagEstero==null || flagEstero.equalsIgnoreCase("false"))
		{
			this.setValidRequired(true);
			String sourceId=event.getComponent().getId();
			
			if(sourceId.equals("tipologiaEs"))
			{
				//ricerca farmacia
				if(codCategoriaEs.equals("0"))
				{
					//chiudi pannello ricerca parafarmacia
					ricercaParafarmacieClose();
					
					setAbilitaRicercaFarmacieButton(true);
					setAbilitaRicercaParafarmacieButton(false);
				}
				//ricerca parafarmacia
				else if(codCategoriaEs.equals("3"))
				{
					//chiudi pannello ricerca farmacia
					ricercaFarmacieClose();
					
					setAbilitaRicercaFarmacieButton(false);
					setAbilitaRicercaParafarmacieButton(true);
				}
				else
				{
					//chiudi pannello ricerca farmacia e pannello ricerca parafarmacia
					ricercaFarmacieClose();
					ricercaParafarmacieClose();
					
					setAbilitaRicercaFarmacieButton(false);
					setAbilitaRicercaParafarmacieButton(false);
				}
			}
			
			JSFUtility.update("eseProfPanel5");
			JSFUtility.update("ricercaEserciziBox");
		}
	}

	public void aggiungiAltroEseProf()
	{	
		try
		{
			listaEserciziProfessionali = aggiungiEsProf();
			JSFUtility.update("panelAggEsercizioProf");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public boolean controllaValori_agg()
	{
		if (!(this.codRuoloEs!=null && !this.codRuoloEs.equalsIgnoreCase(""))) 
			return false; 
										
		if(!(this.denEsercizio!=null && !this.denEsercizio.equalsIgnoreCase(""))) 
			return false;
		
		if(!(this.indirizzoEs!=null && !this.indirizzoEs.equalsIgnoreCase(""))) 
			return false;
		
		if(!(this.capEs!=null && !this.capEs.equalsIgnoreCase(""))) 
			return false;
		
		if(!(this.comuneEs!=null && !this.comuneEs.equalsIgnoreCase(""))) 
			return false;
		
		//se l'esperienza non � estera ed � relativa ad un ruolo diverso dalle categorie C-D-E..
		if((flagEstero==null || flagEstero.equalsIgnoreCase("false")) && !isRuoloCategoriaCDE)
		{
			//..controlla la valorizzazione della ruralit�
			if(!(this.flagFarmRurale!=null && !this.flagFarmRurale.equalsIgnoreCase(""))) 
				return false;
		}
		
		if(!(this.regEs!=null && !this.regEs.equalsIgnoreCase(""))) 
			return false;
		
		//controlla se il campo provincia � valorizzato (solo nel caso in cui la check "estero" non � spuntata)
		if(flagEstero==null || flagEstero.equalsIgnoreCase("false"))
		{
			if(!(this.prvEs!=null && !this.prvEs.equalsIgnoreCase(""))) 
				return false;
		}
			
		if(!(this.dataInizioEs!=null )) 
			return false;
						
		if(!(this.dataFineEs!=null )) 
			return false;
							
		if(!(this.codModalitaEs!=null && !this.codModalitaEs.equalsIgnoreCase(""))) 
			return false;

		if(!(this.codCategoriaEs!=null && !this.codCategoriaEs.equalsIgnoreCase(""))) 
			return false;
						
			return true;
	}
	
	
	public boolean controllaValori(){
		
		if(			
			!((this.codRuoloEs== null || this.codRuoloEs.equalsIgnoreCase(""))&&
			(this.denEsercizio== null || this.denEsercizio.equalsIgnoreCase(""))&&
			(this.indirizzoEs== null || this.indirizzoEs.equalsIgnoreCase(""))&&
			
			(this.capEs== null || this.capEs.equalsIgnoreCase(""))&&
			
			(this.comuneEs== null || this.comuneEs.equalsIgnoreCase(""))&&
			(this.flagFarmRurale==null || this.flagFarmRurale.equalsIgnoreCase("")) &&
			(this.regEs==null || this.regEs.equalsIgnoreCase("")) &&
			(this.prvEs==null || this.prvEs.equalsIgnoreCase("")) &&
			(this.dataInizioEs == null) &&
			(this.dataFineEs == null) &&
			(this.codModalitaEs == null || this.codModalitaEs.equalsIgnoreCase("")) &&
			(this.codCategoriaEs == null || this.codCategoriaEs.equalsIgnoreCase("")))
			
			&&
			
		    !((this.codRuoloEs!=null && !this.codRuoloEs.equalsIgnoreCase(""))&&			
			(this.denEsercizio!=null && !this.denEsercizio.equalsIgnoreCase(""))&&
			(this.indirizzoEs!=null && !this.indirizzoEs.equalsIgnoreCase(""))&&
			
			(this.capEs!=null && !this.capEs.equalsIgnoreCase(""))&&
			
			(this.comuneEs!=null && !this.comuneEs.equalsIgnoreCase(""))&&
			(this.flagFarmRurale!=null && !this.flagFarmRurale.equalsIgnoreCase("")) &&
			(this.regEs!=null && !this.regEs.equalsIgnoreCase("")) &&
			(this.prvEs!=null && !this.prvEs.equalsIgnoreCase("")) &&
			(this.dataInizioEs !=null) &&
			(this.dataFineEs !=null) &&
			(this.codModalitaEs!=null && !this.codModalitaEs.equalsIgnoreCase("")) &&
			(this.codCategoriaEs!=null && !this.codCategoriaEs.equalsIgnoreCase("")))
		   )
				
				return false;
			
	return true;
}
	
	
	public ArrayList<EsercizioProfessionale> aggiungiEsProf() throws GestioneErroriException{
    
		boolean mostraMessaggi=false;
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		if(!controllaValori_agg())
		{
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("esercizioProfBean.attenzione.esercizio.professionale", lingua));
//			JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi obbligatori di 'Esercizio Professionale'");
			mostraMessaggi=true;
		}
        else if(validaData(this.getDataInizioEs(),dataNascitaUtente) || validaData(this.getDataFineEs(),dataNascitaUtente))
        {
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("esercizioProfBean.attenzione.dataEsercizio.post.datanascita", lingua));
//			JSFUtility.addWarningMessage("Attenzione","Le date di inizio e fine esercizio professionale devono essere successive alla data di nascita utente");
			mostraMessaggi=true;
		}
        else if(validaData_2(this.getDataFineEs(),this.getDataInizioEs()))
        {
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("esercizioProfBean.attenzione.datafineesep.post.datainizioep", lingua));
//			JSFUtility.addWarningMessage("Attenzione","La data di fine esercizio professionale dev'essere successiva o uguale alla data di inizio");
			mostraMessaggi=true;
        }
		//controllo data inizio es. prof.: data inizio >= data iscr. albo (solo se l'esperienza � italiana e se il ruolo in questione � di categoria A o B)
        else if((flagEstero==null || flagEstero.equalsIgnoreCase("false")) && this.getCodRuoloEs().endsWith("Y") && validaData_2(this.getDataInizioEs(),dataIscrizioneAlbo))
        {
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("esercizioProfBean.attenzione.dataep.pre.dataalbo", lingua));
//			JSFUtility.addWarningMessage("Attenzione","Per i ruoli Cat.A e Cat.B la data di inizio esercizio professionale non pu� essere precedente alla data di iscrizione all'albo");
			mostraMessaggi=true;
		}
		//per la liguria le date relative all'esperienza prof. devono essere strettamente antecedenti alla data di pubblicazione del bando
        else if(codiceRegione.equals("070") && (validaData(dataPubblicazioneBando,this.getDataInizioEs()) || validaData(dataPubblicazioneBando,this.getDataFineEs())))
        {
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("esercizioProfBean.attenzione.dateep.pre.dataalbo", lingua));
//			JSFUtility.addWarningMessage("Attenzione","Le date di inizio e fine esercizio professionale devono essere antecedenti alla data di pubblicazione del bando");
			mostraMessaggi=true;
		}
		//per tutte le altre regioni le date non devono essere successive alla pubblicazione
        else if(validaData_2(dataPubblicazioneBando,this.getDataInizioEs()) || validaData_2(dataPubblicazioneBando,this.getDataFineEs()))
        {
        	JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("esercizioProfBean.attenzione.dateep.pre.dataalbo2", lingua));
//        	JSFUtility.addWarningMessage("Attenzione","Le date di inizio e fine esercizio professionale non devono essere successive alla data di pubblicazione del bando");
			mostraMessaggi=true;
        }
        else
        {
        	boolean prosegui=true;
        	
        	//se il flag � valorizzato a "false" - esperienza italiana - controlla la correttezza del campo regione
        	if(flagEstero==null || flagEstero.equalsIgnoreCase("false"))
        	{
        		prosegui=controllaCorrettezzaRegione();
        	}
        	
            if(prosegui)
            {
        	
	        	EsercizioProfessionale esercizioProfessionale = new EsercizioProfessionale();
		        sdf = new SimpleDateFormat("dd-MM-yyyy");
		       
		        esercizioProfessionale.setDataInizioStringa(StringUtil.dateToString(this.getDataInizioEs(),sdf));
		        esercizioProfessionale.setDataInizioEs(this.getDataInizioEs());
		        esercizioProfessionale.setDataFineStringa(StringUtil.dateToString(this.getDataFineEs(),sdf));
		        esercizioProfessionale.setDataFineEs(getDataFineEs());
		        esercizioProfessionale.setCodModalitaEs(this.getCodModalitaEs());
		        
		        
		        if(lingua.equals("de")){
		        	
		        	if(this.getCodModalitaEs().equals("0")){
			        	 esercizioProfessionale.setModalitaTempoDescr("Teilzeit");  
			        }
			        if(this.getCodModalitaEs().equals("1")){
			        	 esercizioProfessionale.setModalitaTempoDescr("Vollzeit");
			        }
			       
			        esercizioProfessionale.setCodRuoloEs(this.getCodRuoloEs());
			        esercizioProfessionale.setDescrizioneRuolo(CaricaRuoli.decodificaRuolo(this.getCodRuoloEs(), "de")); 
			        
			        if(this.getCodCategoriaEs().equals("0")){
			        	esercizioProfessionale.setTipologiaEsercizioDescrizione("Apotheke");
			          }
			        if(this.getCodCategoriaEs().equals("1")){
			        	esercizioProfessionale.setTipologiaEsercizioDescrizione("Andere");
			         }
			        if(this.getCodCategoriaEs().equals("3")){
			         	 esercizioProfessionale.setTipologiaEsercizioDescrizione("Kommerzieller Betrieb L.248/2006");
			         }
		        	
		        }else{
		        	
			        if(this.getCodModalitaEs().equals("0")){
			        	 esercizioProfessionale.setModalitaTempoDescr("Tempo parziale");  
			        }
			        if(this.getCodModalitaEs().equals("1")){
			        	 esercizioProfessionale.setModalitaTempoDescr("Tempo pieno");
			        }
			       
			        esercizioProfessionale.setCodRuoloEs(this.getCodRuoloEs());
			        esercizioProfessionale.setDescrizioneRuolo(CaricaRuoli.decodificaRuolo(this.getCodRuoloEs(), "it")); 
			        
			        if(this.getCodCategoriaEs().equals("0")){
			        	esercizioProfessionale.setTipologiaEsercizioDescrizione("Farmacia");
			          }
			        if(this.getCodCategoriaEs().equals("1")){
			        	esercizioProfessionale.setTipologiaEsercizioDescrizione("Altro");
			         }
			        if(this.getCodCategoriaEs().equals("3")){
			         	 esercizioProfessionale.setTipologiaEsercizioDescrizione("Esercizio commerciale L.248/2006");
			         }
		        }
		        
		        esercizioProfessionale.setCodCategoriaEs(this.getCodCategoriaEs());
		        
		        esercizioProfessionale.setFlagEstero(this.getFlagEstero());
		        
		        esercizioProfessionale.setDenEsercizio(this.getDenEsercizio());
		        esercizioProfessionale.setIndirizzoEs(this.getIndirizzoEs());
		        esercizioProfessionale.setCapEs(this.getCapEs());
		        esercizioProfessionale.setRegEs(this.getRegEs());
		        esercizioProfessionale.setRegDescrizione(this.getRegEsDescr());
		        
		        if(this.getPrvEs()==null || this.getPrvEs().equals(""))
		        {
		        	esercizioProfessionale.setPrvEs("-");
		        }
		        else
		        {
		        	esercizioProfessionale.setPrvEs(this.getPrvEs());
		        }
		        
		        esercizioProfessionale.setPrvDescrizione(this.getPrvEsDescr());
		        esercizioProfessionale.setComuneEs(this.getComuneEs());
		        esercizioProfessionale.setComuneDescrizione(this.getComuneEsDescr());
		        
		        if(this.getAslEs()==null || this.getAslEs().equals(""))
		        {
		        	esercizioProfessionale.setAslEs("-");
		        }
		        else
		        {
		        	esercizioProfessionale.setAslEs(this.getAslEs());	            
		        }
		      
		        if(this.getFlagFarmRurale()==null || this.getFlagFarmRurale().equals(""))
		        {
		        	esercizioProfessionale.setFlagFarmRurale("-");
		        }
		        else
		        { 
		        	 if(lingua.equals("de")){   
		        		if(this.getFlagFarmRurale().equals("Si")){
		        		esercizioProfessionale.setFlagFarmRurale("Ja");
		        		}
		        		 if(this.getFlagFarmRurale().equals("No")){
			        		esercizioProfessionale.setFlagFarmRurale("Nein");
			        	}
		        	}else {
		        		if(this.getFlagFarmRurale().equals("Si")){
				        esercizioProfessionale.setFlagFarmRurale("Si");
				  		}
		        		if(this.getFlagFarmRurale().equals("No")){
		        		esercizioProfessionale.setFlagFarmRurale("No");
		        	
		        	
				      	}
             	   }
	           }		
		     
		        
		        listaEserciziProfessionali.add(esercizioProfessionale);
		        
		        setDataFineEs(null);
		        setDataInizioEs(null);
		        setAslEs("");
		        setAslDenom("");
		        setCodCategoriaEs("");
		        setCodModalitaEs("");
		        setCodRuoloEs("");
		        setComuneEs("");
		        setComuneEsDescr("");
		        setRegEs("");
		        setRegEsDescr("");
		        setPrvEs("");
		        setPrvEsDescr("");
		        setDenEsercizio("");
		        setFlagFarmRurale("");
		        setIndirizzoEs("");
		        setCapEs("");
            }
		}
	
	if(mostraMessaggi)
	{
		JSFUtility.scrollTo("form:msgs");
	}
	
	return listaEserciziProfessionali;
}

	public void eliminaEsercizioProfessionale(){
		
		for(int i=0;i<listaEserciziProfessionali.size();i++){
			if(esercizioProfessionaleSelezionato.getDataFineEs()==listaEserciziProfessionali.get(i).getDataFineEs() &
			   esercizioProfessionaleSelezionato.getDataInizioEs()==listaEserciziProfessionali.get(i).getDataInizioEs() &
			   esercizioProfessionaleSelezionato.getAslEs()==listaEserciziProfessionali.get(i).getAslEs() &
			   esercizioProfessionaleSelezionato.getCodCategoriaEs()==listaEserciziProfessionali.get(i).getCodCategoriaEs() &
		       esercizioProfessionaleSelezionato.getCodModalitaEs()==listaEserciziProfessionali.get(i).getCodModalitaEs() &
		       esercizioProfessionaleSelezionato.getCodRuoloEs()==listaEserciziProfessionali.get(i).getCodRuoloEs() &
		       esercizioProfessionaleSelezionato.getComuneEs()==listaEserciziProfessionali.get(i).getComuneEs() &
		       esercizioProfessionaleSelezionato.getDenEsercizio()==listaEserciziProfessionali.get(i).getDenEsercizio() &
		       esercizioProfessionaleSelezionato.getFlagFarmRurale()==listaEserciziProfessionali.get(i).getFlagFarmRurale() &
		       esercizioProfessionaleSelezionato.getIndirizzoEs()==listaEserciziProfessionali.get(i).getIndirizzoEs() &
		       esercizioProfessionaleSelezionato.getCapEs()==listaEserciziProfessionali.get(i).getCapEs() &
		       esercizioProfessionaleSelezionato.getPrvEs()==listaEserciziProfessionali.get(i).getPrvEs() & 
		       esercizioProfessionaleSelezionato.getRegEs()==listaEserciziProfessionali.get(i).getRegEs())
				    {
					listaEserciziProfessionali.remove(i);
					}
			}
		
		}
	
	
	public boolean controllaCampi(){

		if(!controllaValori()){
			
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("esercizioProfBean.attenzione.campi.tutti", lingua));
//			JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi e premere 'Aggiungi Esercizio Professionale'");
			JSFUtility.scrollTo("form:msgs");
			return false;
		}

		
		return true;
		
	}
	
	public boolean init(String idUtente,String codRegione)
	{
		try
		{
			codiceRegione=codRegione;
			
			return esercizioProfAction.loadPaginaInserimento(idUtente,this);
		}
		catch(GestioneErroriException e)
		{
			logger.error("EsercizioProfBean - init: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
			return false;
		}
	}
	
	public boolean updateDAO(String idUtente)
	{
		try {
			return esercizioProfAction.updateDAO(idUtente,this);
		} catch (GestioneErroriException e) {
			logger.error("EsercizioProfBean - updateDAO: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
			return false;
		}
	}
	
	
	boolean validaData(Date data, Date dataVerifica)
	{	
		Calendar dataBando = Calendar.getInstance();
		dataBando.setTime(data);
		dataBando.set(Calendar.HOUR_OF_DAY,0);//imposta l'orario a mezzanotte
		
		Calendar dataDaVerificare = Calendar.getInstance();
		dataDaVerificare.setTime(dataVerifica);
		dataDaVerificare.set(Calendar.HOUR_OF_DAY,0);//imposta l'orario a mezzanotte

		if(dataDaVerificare.before(dataBando))
		{
			return false;
		}

		return true;
	}
	
	boolean validaData_2(Date data, Date dataVerifica)
	{	
		Calendar dataBando = Calendar.getInstance();
		dataBando.setTime(data);
		dataBando.set(Calendar.HOUR_OF_DAY,0);//imposta l'orario a mezzanotte
		
		Calendar dataDaVerificare = Calendar.getInstance();
		dataDaVerificare.setTime(dataVerifica);
		dataDaVerificare.set(Calendar.HOUR_OF_DAY,0);//imposta l'orario a mezzanotte
		
		/*SimpleDateFormat df = new SimpleDateFormat();
        df.applyPattern("dd/MM/yyyy - hh:mm");
		
		System.out.println("data bando: "+df.format(dataBando.getTime()));
		System.out.println("data inserita: "+df.format(dataDaVerificare.getTime())); */
		
		if(dataDaVerificare.before(dataBando) || dataDaVerificare.equals(dataBando))
		{
			return false;
		}
		
		return true;
	}
	
	
	public void abilitaBottoneRicerca(javax.faces.event.AjaxBehaviorEvent event)
	{
		String sourceId=event.getComponent().getId();
		
		if(sourceId.equals("comuneRicerca") || this.capEs!= null || !this.capEs.equalsIgnoreCase("")){
			this.setDisabilitaRicercaButton(false);
			 RequestContext.getCurrentInstance().update(JSFUtility.getClientId("bottoneRicerca"));
	}
		if(sourceId.equals("comuneRicercaParafarmacie")){
			this.setDisabilitaRicercaParaButton(false);
			 RequestContext.getCurrentInstance().update(JSFUtility.getClientId("bottoneRicercaPara"));
	}
		
	}
	
	
	public void regioneCambiata(javax.faces.event.AjaxBehaviorEvent event)
	{
		String sourceId=event.getComponent().getId();
		//carica tutti le province appartenenti alla regione selezionata
		if(sourceId.equals("regioneRicerca")){
			 setProvinceSelect(Localita.getProvince(regioneSelezionata));
			 provinceList=provinceSelect.get(regioneSelezionata);
			 setAttivaProvincia(false);
			 setAttivaComune(true);
			 RequestContext.getCurrentInstance().update(JSFUtility.getClientId("provinciaRicerca"));
	}
		if(sourceId.equals("regioneRicercaParafarmacie")){
			 setProvinceSelect(Localita.getProvince(regioneSelezionataParafarmacia));
			 provinceList=provinceSelect.get(regioneSelezionataParafarmacia);
			 setAttivaProvinciaParafarmacie(false);
			 setAttivaComuneParafarmacie(true);
			 RequestContext.getCurrentInstance().update(JSFUtility.getClientId("provinciaRicercaParafarmacie"));
	}
		}
	
	public void ricercaFarmacieOpen(){
		
		ricercaParafarmacieClose();
		
		setAbilitaRicercaFarmacieButton(false);
		setAbilitaRicercaParafarmacieButton(false);
		
		provinceSelect=null;
		setAttivaProvincia(true);
		setAttivaComune(true);
		
		setRicercaFarmacieBoolean(true);
		//Gestione Help
		 
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		 
		//init Help
		if(lingua.equals("it")){
			setListaHelpRicercaFarm(Help.caricaHelpRicercaFarmacie());
		}else{
			setListaHelpRicercaFarm(HelpDe.caricaHelpRicercaFarmacie());
		}
	}
	
	public void ricercaFarmacieClose(){
		
		// ripulisce il panel Ricerca Farmacie
		setDisabilitaRicercaButton(true);
		setRegioneSelezionata(null);
		setProvinciaSelezionata(null);
		setComuneSelezionato(null);
		setIndirizzo(null);
		setCodCap(null);
		setPartitaIVA(null);
		setListaFarmacie(null);
		setShowListFarma(false);

		setAbilitaRicercaFarmacieButton(true);
		setAbilitaRicercaParafarmacieButton(false);
		
		setRicercaFarmacieBoolean(false);
	}
	
	public void ricercaParafarmacieOpen(){
		
		ricercaFarmacieClose();
		setAbilitaRicercaFarmacieButton(false);
		setAbilitaRicercaParafarmacieButton(false);
		
		provinceSelect=null;
		setAttivaProvinciaParafarmacie(true);
		setAttivaComuneParafarmacie(true);
		
		setRicercaParafarmacieBoolean(true);
		//Gestione Help
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		 
		//init Help
		if(lingua.equals("it")){
			setListaHelpRicercaParaFarm(Help.caricaHelpRicercaFarmacie());
		}else{
			setListaHelpRicercaParaFarm(HelpDe.caricaHelpRicercaFarmacie());
		}
		
			
	}
	
	public void ricercaParafarmacieClose(){
		
		// ripulisce il panel Ricerca Parafarmacie
		setDisabilitaRicercaParaButton(true);
		setRegioneSelezionataParafarmacia(null);
		setProvinciaSelezionataParafarmacia(null);
		setComuneSelezionatoParafarmacia(null);
		setIndirizzoParafarmacie(null);
		setCodCapParafarmacie(null);
		setPartitaIVAParafarmacie(null);
		setListaParafarmacie(null);
		setShowListPara(false);
		
		setAbilitaRicercaFarmacieButton(false);
		setAbilitaRicercaParafarmacieButton(true);
		
		setRicercaParafarmacieBoolean(false);
	}
	
	public void provinciaCambiata(javax.faces.event.AjaxBehaviorEvent event)
	{
		String sourceId=event.getComponent().getId();
		//carica tutti i comuni appartenenti alla provincia selezionata
		if(sourceId.equals("provinciaRicerca")){
			setComuniSelect(Localita.getComuni(provinciaSelezionata));
			comuniList=comuniSelect.get(provinciaSelezionata);
			 setAttivaComune(false);
			RequestContext.getCurrentInstance().update(JSFUtility.getClientId("comuneRicerca"));
		}
		if(sourceId.equals("provinciaRicercaParafarmacie")){
			setComuniSelect(Localita.getComuni(provinciaSelezionataParafarmacia));
			comuniList=comuniSelect.get(provinciaSelezionataParafarmacia);
			 setAttivaComuneParafarmacie(false);
			RequestContext.getCurrentInstance().update(JSFUtility.getClientId("comuneRicercaParafarmacie"));
		}
		}
	
	public void ricercaFarma(){
		
		if (!((regioneSelezionata==null || regioneSelezionata.equalsIgnoreCase(""))&&
			(provinciaSelezionata==null || provinciaSelezionata.equalsIgnoreCase("")) &&
			(comuneSelezionato==null || comuneSelezionato.equalsIgnoreCase("")) &&
			(codCap==null || codCap.equalsIgnoreCase("")) &&
			(indirizzo==null || indirizzo.equalsIgnoreCase("")) &&
			(partitaIVA==null || partitaIVA.equalsIgnoreCase(""))))
			
			{
		
		List<FarmacieSearch> lista;
			try {
				lista = esercizioProfAction.ricerca(this);
				setListaFarmacie(lista);
				setElencoFarmacieBoolean(true);
				
				setShowListFarma(true);
	
			} catch (GestioneErroriException e) {
				logger.error("EsercizioProfBean - init: " + e.getMessage());	
				JSFUtility.redirect("errorPageGenerica.jsf");
			}

			RequestContext.getCurrentInstance().update(JSFUtility.getClientId("risultatoRicerca"));
	  		
	   }
		else {
			
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("esercizioProfBean.attenzione.specifiche.ricerca", lingua));
//			JSFUtility.addWarningMessage("Attenzione","Specificare 'Regione','Provincia','Comune' oppure 'CAP'");
			JSFUtility.scrollTo("form:msgs");
		}
	}
	
	public void ricercaParafarmacie(){
		
		if (!((regioneSelezionataParafarmacia==null || regioneSelezionataParafarmacia.equalsIgnoreCase(""))&&
				(provinciaSelezionataParafarmacia==null || provinciaSelezionataParafarmacia.equalsIgnoreCase("")) &&
				(comuneSelezionatoParafarmacia==null || comuneSelezionatoParafarmacia.equalsIgnoreCase("")) &&
				(codCapParafarmacie==null || codCapParafarmacie.equalsIgnoreCase("")) &&
				(indirizzoParafarmacie==null || indirizzoParafarmacie.equalsIgnoreCase("")) &&
				(partitaIVAParafarmacie==null || partitaIVAParafarmacie.equalsIgnoreCase(""))))
				
				{
		
			try{
				List<ParafarmacieSearch> lista = esercizioProfAction.ricercaParafarmacie(this);
				setListaParafarmacie(lista);
				setElencoParafarmacieBoolean(true);
				
				setShowListPara(true);
		
			
			} catch (GestioneErroriException e) {
				logger.error("EsercizioProfBean - init: " + e.getMessage());	
				JSFUtility.redirect("errorPageGenerica.jsf");
			}
			
			RequestContext.getCurrentInstance().update(JSFUtility.getClientId("risultatoRicercaParafarmacie"));
			
		}
		else {
			
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("esercizioProfBean.attenzione.specifiche.ricerca", lingua));
//			JSFUtility.addWarningMessage("Attenzione","Specificare 'Regione','Provincia','Comune' oppure 'CAP'");
			JSFUtility.scrollTo("form:msgs");
		}
}
	
	public void selezionaFarmacia(){
        
       
        setDenEsercizio(farmaciaSelected.getDesSede());
        setIndirizzoEs(farmaciaSelected.getIndirizzo());
        setCapEs(farmaciaSelected.getCodCap());
        setRegEsDescr(Localita.getDenominazioneRegione(farmaciaSelected.getCodRg()));
        setRegEs(Localita.getDenominazioneRegione(farmaciaSelected.getCodRg()));
        setPrvEs(Localita.getDenominazioneProvincia(farmaciaSelected.getCodIstatProv()));
        setPrvEsDescr(Localita.getDenominazioneProvincia(farmaciaSelected.getCodIstatProv()));
        setComuneEs(Localita.getDenominazioneComune(farmaciaSelected.getCodIstatComu())); 
        setComuneEsDescr(Localita.getDenominazioneComune(farmaciaSelected.getCodIstatComu()));
        setAslEs(farmaciaSelected.getAslRif());
        setAslDenom(farmaciaSelected.getAslDenom());
        setRicercaFarmacieBoolean(false);
        setElencoFarmacieBoolean(false);
        
        setAbilitaRicercaFarmacieButton(true);
        setAbilitaRicercaParafarmacieButton(false);
		
		// ripulisce il panel Ricerca Farmacie
		setDisabilitaRicercaButton(true);
		setRegioneSelezionata(null);
		setProvinciaSelezionata(null);
		setComuneSelezionato(null);
		setIndirizzo(null);
		setCodCap(null);
		setPartitaIVA(null);
		setListaFarmacie(null);
		setShowListFarma(false);
		
		
        JSFUtility.update("panelAggEsProf");
        
  }
  
  public void selezionaParafarmacia(){
        
        
        setIndirizzoEs(parafarmaciaSelected.getDesInd());
        setCapEs(parafarmaciaSelected.getCodCap());
        setDenEsercizio(parafarmaciaSelected.getDesSlo());
        setRegEs(parafarmaciaSelected.getDesRegione());
        setRegEsDescr(parafarmaciaSelected.getDesRegione());
        setPrvEs(parafarmaciaSelected.getDesProvincia());
        setPrvEsDescr(parafarmaciaSelected.getDesProvincia());
        setComuneEs(parafarmaciaSelected.getDesComune()); 
        setComuneEsDescr(parafarmaciaSelected.getDesComune());
        setRicercaParafarmacieBoolean(false);
        
		setAbilitaRicercaFarmacieButton(false);
		setAbilitaRicercaParafarmacieButton(true);
		
		// ripulisce il panel Ricerca Parafarmacie
		setDisabilitaRicercaParaButton(true);
		setRegioneSelezionataParafarmacia(null);
		setProvinciaSelezionataParafarmacia(null);
		setComuneSelezionatoParafarmacia(null);
		setIndirizzoParafarmacie(null);
		setCodCapParafarmacie(null);
		setPartitaIVAParafarmacie(null);
		setListaParafarmacie(null);
		setShowListPara(false);
		
		JSFUtility.update("panelAggEsProf");
  }
  
  	public void ruoloCambiato(AjaxBehaviorEvent event)
  	{
  		//determina il codice del ruolo selezionato
  		int codNumber=Integer.parseInt(codRuoloEs.substring(0,codRuoloEs.indexOf("_")));
  		
  		//se il ruolo selezionato appartiene alla categoria C,D,E..
  		if(codNumber>=4 && codNumber<=17)
  		{
  			//..nascondi i campi asl e ruralit�
  			isRuoloCategoriaCDE=true;
  			setAslEs(null);
  	  		setFlagFarmRurale(null);
  		}
  		else
  		{
  			//..altrimenti ripristinali
  			isRuoloCategoriaCDE=false;
  		}
  		
  		JSFUtility.update("aslEssLabel");
  		JSFUtility.update("aslEss");
  		
  		JSFUtility.update("farmaciaruraleLabel");
  		JSFUtility.update("farmaciarurale");
  	}
  
  	public void flagEsteroCambiato(AjaxBehaviorEvent event)
  	{
  		if(flagEstero!=null && flagEstero.equalsIgnoreCase("true"))
  		{
			//nascondi sezioni ricerca farmacie e ricerca parafarmacie
  			setRicercaFarmacieBoolean(false);
			setRicercaParafarmacieBoolean(false);
  		}
  		
  		//reset selezione categoria esercizio
  		setCodCategoriaEs(null);
		
  		//nascondi pulsanti ricerca farmacie e ricerca parafarmacie
		setAbilitaRicercaFarmacieButton(false);
		setAbilitaRicercaParafarmacieButton(false);
  		
  		//cancella i campi relativi alla localit�
  		setIndirizzoEs(null);
  		setCapEs(null);
  		setRegEs(null);
  		setPrvEs(null);
  		setComuneEs(null);
  		setAslEs(null);
  		setFlagFarmRurale(null);
  		
  		//aggiorna componenti maschera
  		
  		JSFUtility.update("eseProfPanel5");
  		JSFUtility.update("ricercaEserciziBox");
  		JSFUtility.update("indirizzoEss");
  		
  		JSFUtility.update("capEssLabel");
  		JSFUtility.update("capEss");
  		
  		JSFUtility.update("regioneEssLabel");
  		JSFUtility.update("regioneEss");
  		
  		JSFUtility.update("provinciaEssLabel");
  		JSFUtility.update("provinciaEss");
  		
  		JSFUtility.update("comuneEssLabel");
  		JSFUtility.update("comuneEss");
  		
  		JSFUtility.update("aslEssLabel");
  		JSFUtility.update("aslEss");
  		
  		JSFUtility.update("farmaciaruraleLabel");
  		JSFUtility.update("farmaciarurale");
  	}
	
	public boolean aggiungiPannelloRicerca(){
		aggiungiPannelloRicercaBoolean = true;
		return aggiungiPannelloRicercaBoolean;
	}	
	
	public void codCategoriaEsCambiato(){
		JSFUtility.update("pannelloAssociato");
	}
	
	public String getIdEsercizio() {
		return idEsercizio;
	}
	public void setIdEsercizio(String idEsercizio) {
		this.idEsercizio = idEsercizio;
	}
	public String getIdDomandaEs() {
		return idDomandaEs;
	}
	public void setIdDomandaEs(String idDomandaEs) {
		this.idDomandaEs = idDomandaEs;
	}
	public String getCodRuoloEs() {
		return codRuoloEs;
	}
	public void setCodRuoloEs(String codRuoloEs) {
		this.codRuoloEs = codRuoloEs;
	}
	
	public boolean getIsRuoloCategoriaCDE() {
		return isRuoloCategoriaCDE;
	}

	public void setIsRuoloCategoriaCDE(boolean isRuoloCategoriaCDE) {
		this.isRuoloCategoriaCDE = isRuoloCategoriaCDE;
	}

	public String getDenEsercizio() {
		return denEsercizio;
	}
	public void setDenEsercizio(String denEsercizio) {
		this.denEsercizio = denEsercizio;
	}
	
	public String getFlagEstero() {
		return flagEstero;
	}

	public void setFlagEstero(String flagEstero) {
		this.flagEstero = flagEstero;
	}

	public String getComuneEs() {
		return comuneEs;
	}
	public void setComuneEs(String comuneEs) {
		this.comuneEs = comuneEs;
	}
	public String getIndirizzoEs() {
		return indirizzoEs;
	}
	public String getAslEs() {
		return aslEs;
	}
	public void setAslEs(String aslEs) {
		this.aslEs = aslEs;
	}
	public void setIndirizzoEs(String indirizzoEs) {
		this.indirizzoEs = indirizzoEs;
	}
	public String getFlagFarmRurale() {
		return flagFarmRurale;
	}
	public String getCapEs() {
		return capEs;
	}
	public void setCapEs(String capEs) {
		if(capEs!=null)
		{
			this.capEs = capEs.trim();
		}
		else
		{
			this.capEs = null;
		}
	}
	public String getRegEs() {
		return regEs;
	}
	public void setRegEs(String regEs) {
		this.regEs = regEs;
	}
	public void setFlagFarmRurale(String flagFarmRurale) {
		this.flagFarmRurale = flagFarmRurale;
	}
	public String getPrvEs() {
		return prvEs;
	}
	public void setPrvEs(String prvEs) {
		this.prvEs = prvEs;
	}
	public Date getDataInizioEs() {
		return dataInizioEs;
	}
	public void setDataInizioEs(Date dataInizioEs) {
		this.dataInizioEs = dataInizioEs;
	}
	public Date getDataFineEs() {
		return dataFineEs;
	}
	public void setDataFineEs(Date dataFineEs) {
		this.dataFineEs = dataFineEs;
	}
	public String getCodModalitaEs() {
		return codModalitaEs;
	}
	public void setCodModalitaEs(String codModalitaEs) {
		this.codModalitaEs = codModalitaEs;
	}
	public String getCodCategoriaEs() {
		return codCategoriaEs;
	}
	public void setCodCategoriaEs(String codCategoriaEs) {
		this.codCategoriaEs = codCategoriaEs;
	}
	
	public ArrayList<String> getRegioniList() {
		return regioniList;
	}

	public void setRegioniList(ArrayList<String> regioniList) {
		this.regioniList = regioniList;
	}

	public ArrayList<EsercizioProfessionale> getListaEserciziProfessionali() {
		return listaEserciziProfessionali;
	}

	public void setListaEserciziProfessionali(
			ArrayList<EsercizioProfessionale> listaEserciziProfessionali) {
		this.listaEserciziProfessionali = listaEserciziProfessionali;
	}

	public EsercizioProfessionale getEsercizioProfessionale() {
		return esercizioProfessionale;
	}

	public void setEsercizioProfessionale(
			EsercizioProfessionale esercizioProfessionale) {
		this.esercizioProfessionale = esercizioProfessionale;
	}
	
	public List<RegioneSelect> getRegioniSelect() {
		return regioniSelect;
	}



	public void setRegioniSelect(List<RegioneSelect> regioniSelect) {
		this.regioniSelect = regioniSelect;
	}



	public HashMap<String, ArrayList<ProvinciaSelect>> getProvinceSelect() {
		return provinceSelect;
	}



	public void setProvinceSelect(
			HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect) {
		this.provinceSelect = provinceSelect;
	}



	public HashMap<String, ArrayList<ComuneSelect>> getComuniSelect() {
		return comuniSelect;
	}



	public void setComuniSelect(
			HashMap<String, ArrayList<ComuneSelect>> comuniSelect) {
		this.comuniSelect = comuniSelect;
	}



	public ArrayList<ComuneSelect> getComuniList() {
		return comuniList;
	}



	public void setComuniList(ArrayList<ComuneSelect> comuniList) {
		this.comuniList = comuniList;
	}



	public ArrayList<ProvinciaSelect> getProvinceList() {
		return provinceList;
	}



	public void setProvinceList(ArrayList<ProvinciaSelect> provinceList) {
		this.provinceList = provinceList;
	}



	public boolean isAttivaProvincia() {
		return attivaProvincia;
	}



	public void setAttivaProvincia(boolean attivaProvincia) {
		this.attivaProvincia = attivaProvincia;
	}



	public boolean isAttivaComune() {
		return attivaComune;
	}



	public void setAttivaComune(boolean attivaComune) {
		this.attivaComune = attivaComune;
	}



	public String getRegioneSelezionata() {
		return regioneSelezionata;
	}



	public void setRegioneSelezionata(String regioneSelezionata) {
		this.regioneSelezionata = regioneSelezionata;
	}



	public String getProvinciaSelezionata() {
		return provinciaSelezionata;
	}



	public void setProvinciaSelezionata(String provinciaSelezionata) {
		this.provinciaSelezionata = provinciaSelezionata;
	}



	public String getComuneSelezionato() {
		return comuneSelezionato;
	}



	public void setComuneSelezionato(String comuneSelezionato) {
		this.comuneSelezionato = comuneSelezionato;
	}



	public String getIndirizzo() {
		return indirizzo;
	}



	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}



	public String getPartitaIVA() {
		return partitaIVA;
	}



	public void setPartitaIVA(String partitaIVA) {
		this.partitaIVA = partitaIVA;
	}



	public String getCodCap() {
		return codCap;
	}



	public void setCodCap(String codCap) {
		this.codCap = codCap;
	}



	public FarmacieSearch getFarmaciaSelected() {
		return farmaciaSelected;
	}



	public void setFarmaciaSelected(FarmacieSearch farmaciaSelected) {
		this.farmaciaSelected = farmaciaSelected;
	}



	public List<FarmacieSearch> getListaFarmacie() {
		return listaFarmacie;
	}



	public void setListaFarmacie(List<FarmacieSearch> listaFarmacie) {
		this.listaFarmacie = listaFarmacie;
	}



	public EsercizioProfAction getEsercizioProfAction() {
		return esercizioProfAction;
	}



	public void setEsercizioProfAction(EsercizioProfAction esercizioProfAction) {
		this.esercizioProfAction = esercizioProfAction;
	}


	public boolean isValidRequired() {
		return validRequired;
	}


	public void setValidRequired(boolean validRequired) {
		this.validRequired = validRequired;
	}


	public boolean isAggiungiPannelloRicercaBoolean() {
		return aggiungiPannelloRicercaBoolean;
	}


	public void setAggiungiPannelloRicercaBoolean(
			boolean aggiungiPannelloRicercaBoolean) {
		this.aggiungiPannelloRicercaBoolean = aggiungiPannelloRicercaBoolean;
	}


	public boolean isRicercaFarmacieBoolean() {
		return ricercaFarmacieBoolean;
	}


	public void setRicercaFarmacieBoolean(boolean ricercaFarmacieBoolean) {
		this.ricercaFarmacieBoolean = ricercaFarmacieBoolean;
	}


	public boolean isElencoFarmacieBoolean() {
		return elencoFarmacieBoolean;
	}
	


	public EsercizioProfessionale getEsercizioProfessionaleSelezionato() {
		return esercizioProfessionaleSelezionato;
	}



	public void setEsercizioProfessionaleSelezionato(
			EsercizioProfessionale esercizioProfessionaleSelezionato) {
		this.esercizioProfessionaleSelezionato = esercizioProfessionaleSelezionato;
	}

	public void setElencoFarmacieBoolean(boolean elencoFarmacieBoolean) {
		this.elencoFarmacieBoolean = elencoFarmacieBoolean;
	}


	public boolean isRicercaParafarmacieBoolean() {
		return ricercaParafarmacieBoolean;
	}


	public void setRicercaParafarmacieBoolean(boolean ricercaParafarmacieBoolean) {
		this.ricercaParafarmacieBoolean = ricercaParafarmacieBoolean;
	}


	public boolean isElencoParafarmacieBoolean() {
		return elencoParafarmacieBoolean;
	}


	public void setElencoParafarmacieBoolean(boolean elencoParafarmacieBoolean) {
		this.elencoParafarmacieBoolean = elencoParafarmacieBoolean;
	}


	public String getRegioneSelezionataParafarmacia() {
		return regioneSelezionataParafarmacia;
	}


	public void setRegioneSelezionataParafarmacia(
			String regioneSelezionataParafarmacia) {
		this.regioneSelezionataParafarmacia = regioneSelezionataParafarmacia;
	}


	public String getProvinciaSelezionataParafarmacia() {
		return provinciaSelezionataParafarmacia;
	}


	public void setProvinciaSelezionataParafarmacia(
			String provinciaSelezionataParafarmacia) {
		this.provinciaSelezionataParafarmacia = provinciaSelezionataParafarmacia;
	}


	public String getComuneSelezionatoParafarmacia() {
		return comuneSelezionatoParafarmacia;
	}


	public void setComuneSelezionatoParafarmacia(
			String comuneSelezionatoParafarmacia) {
		this.comuneSelezionatoParafarmacia = comuneSelezionatoParafarmacia;
	}


	public String getIndirizzoParafarmacie() {
		return indirizzoParafarmacie;
	}


	public void setIndirizzoParafarmacie(String indirizzoParafarmacie) {
		this.indirizzoParafarmacie = indirizzoParafarmacie;
	}


	public String getPartitaIVAParafarmacie() {
		return partitaIVAParafarmacie;
	}


	public void setPartitaIVAParafarmacie(String partitaIVAParafarmacie) {
		this.partitaIVAParafarmacie = partitaIVAParafarmacie;
	}


	public String getCodCapParafarmacie() {
		return codCapParafarmacie;
	}


	public void setCodCapParafarmacie(String codCapParafarmacie) {
		this.codCapParafarmacie = codCapParafarmacie;
	}


	public String getFarmacieSelectedParafarmacie() {
		return farmacieSelectedParafarmacie;
	}


	public void setFarmacieSelectedParafarmacie(String farmacieSelectedParafarmacie) {
		this.farmacieSelectedParafarmacie = farmacieSelectedParafarmacie;
	}


	public boolean isAttivaProvinciaParafarmacie() {
		return attivaProvinciaParafarmacie;
	}


	public void setAttivaProvinciaParafarmacie(boolean attivaProvinciaParafarmacie) {
		this.attivaProvinciaParafarmacie = attivaProvinciaParafarmacie;
	}


	public boolean isAttivaComuneParafarmacie() {
		return attivaComuneParafarmacie;
	}


	public void setAttivaComuneParafarmacie(boolean attivaComuneParafarmacie) {
		this.attivaComuneParafarmacie = attivaComuneParafarmacie;
	}


	public List<ParafarmacieSearch> getListaParafarmacie() {
		return listaParafarmacie;
	}


	public void setListaParafarmacie(List<ParafarmacieSearch> listaParafarmacie) {
		this.listaParafarmacie = listaParafarmacie;
	}


	public ParafarmacieSearch getParafarmaciaSelected() {
		return parafarmaciaSelected;
	}


	public void setParafarmaciaSelected(ParafarmacieSearch parafarmaciaSelected) {
		this.parafarmaciaSelected = parafarmaciaSelected;
	}


	public String getComuneEsDescr() {
		return comuneEsDescr;
	}


	public void setComuneEsDescr(String comuneEsDescr) {
		this.comuneEsDescr = comuneEsDescr;
	}


	public String getRegEsDescr() {
		return regEsDescr;
	}


	public void setRegEsDescr(String regEsDescr) {
		this.regEsDescr = regEsDescr;
	}


	public String getPrvEsDescr() {
		return prvEsDescr;
	}


	public void setPrvEsDescr(String prvEsDescr) {
		this.prvEsDescr = prvEsDescr;
	}


	public String getAslDenom() {
		return aslDenom;
	}


	public void setAslDenom(String aslDenom) {
		this.aslDenom = aslDenom;
	}


	public List<Ruolo> getRuoli() {
		return ruoli;
	}


	public void setRuoli(List<Ruolo> ruoli) {
		this.ruoli = ruoli;
	}


	public String getDescrizioneRuolo() {
		return descrizioneRuolo;
	}


	public void setDescrizioneRuolo(String descrizioneRuolo) {
		this.descrizioneRuolo = descrizioneRuolo;
	}


	public Ruolo getRuoloSelezionato() {
		return ruoloSelezionato;
	}


	public void setRuoloSelezionato(Ruolo ruoloSelezionato) {
		this.ruoloSelezionato = ruoloSelezionato;
	}


	public boolean isAbilitaRicercaFarmacieButton() {
		return abilitaRicercaFarmacieButton;
	}


	public void setAbilitaRicercaFarmacieButton(boolean abilitaRicercaFarmacieButton) {
		this.abilitaRicercaFarmacieButton = abilitaRicercaFarmacieButton;
	}


	public boolean isAbilitaRicercaParafarmacieButton() {
		return abilitaRicercaParafarmacieButton;
	}


	public void setAbilitaRicercaParafarmacieButton(
			boolean abilitaRicercaParafarmacieButton) {
		this.abilitaRicercaParafarmacieButton = abilitaRicercaParafarmacieButton;
	}


	public Domanda getDomanda() {
		return domanda;
	}


	public void setDomanda(Domanda domanda) {
		this.domanda = domanda;
	}

	public String[] getListaHelpRicercaFarm() {
		return listaHelpRicercaFarm;
	}

	public void setListaHelpRicercaFarm(String[] listaHelpRicercaFarm) {
		this.listaHelpRicercaFarm = listaHelpRicercaFarm;
	}


	public String[] getListaHelpRicercaParaFarm() {
		return listaHelpRicercaParaFarm;
	}


	public void setListaHelpRicercaParaFarm(String[] listaHelpRicercaParaFarm) {
		this.listaHelpRicercaParaFarm = listaHelpRicercaParaFarm;
	}


	public boolean isDisabilitaRicercaButton() {
		return disabilitaRicercaButton;
	}


	public void setDisabilitaRicercaButton(boolean disabilitaRicercaButton) {
		this.disabilitaRicercaButton = disabilitaRicercaButton;
	}


	public boolean isDisabilitaRicercaParaButton() {
		return disabilitaRicercaParaButton;
	}


	public void setDisabilitaRicercaParaButton(boolean disabilitaRicercaParaButton) {
		this.disabilitaRicercaParaButton = disabilitaRicercaParaButton;
	}


	
	public Date getDataNascitaUtente() {
		return dataNascitaUtente;
	}


	public void setDataNascitaUtente(Date dataNascitaUtente) {
		this.dataNascitaUtente = dataNascitaUtente;
	}


	public Date getDataIscrizioneAlbo() {
		return dataIscrizioneAlbo;
	}


	public void setDataIscrizioneAlbo(Date dataIscrizioneAlbo) {
		this.dataIscrizioneAlbo = dataIscrizioneAlbo;
	}


	public boolean isShowListFarma() {
		return showListFarma;
	}


	public void setShowListFarma(boolean showListFarma) {
		this.showListFarma = showListFarma;
	}


	public boolean isShowListPara() {
		return showListPara;
	}


	public void setShowListPara(boolean showListPara) {
		this.showListPara = showListPara;
	}


}