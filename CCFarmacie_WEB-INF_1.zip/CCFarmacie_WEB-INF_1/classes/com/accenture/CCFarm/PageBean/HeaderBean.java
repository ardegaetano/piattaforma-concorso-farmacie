package com.accenture.CCFarm.PageBean;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;


@ManagedBean
@RequestScoped

@SuppressWarnings("serial")
public class HeaderBean implements Serializable {
	private String logoCodRegione = "";
	private String nome = "";
	private String cognome= "";
	private String nominativo = "";
	
	private HttpSession session= null; 
	
	public HeaderBean(){
		try {
			this.init();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void init() throws IllegalAccessException, InvocationTargetException {  
    	
		FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	session = req.getSession();

    	logoCodRegione=  (String) session.getAttribute(RepositorySession.ID_REGIONE);
    	if (logoCodRegione==null) logoCodRegione="";
        
    	nome =   (String) session.getAttribute(RepositorySession.NOME_UTENTE);
    	if (nome==null) nome="";
    	cognome=   (String) session.getAttribute(RepositorySession.COGNOME_UTENTE);
    	if (cognome==null) cognome="";
    	
    	nominativo = nome+" "+cognome;
    	
    	
    	
	}
	
	public String backLoginCandidato ()
	{

		String linguaScelta = (String) GetSessionUtility.getSessionAttribute("linguaScelta");
		((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).removeAttribute(RepositorySession.registrazione);
        if(linguaScelta!=null&&linguaScelta.equalsIgnoreCase("de"))
         JSFUtility.redirect("loginCandidato_de.jsf");
        else	
		 JSFUtility.redirect("loginCandidato.jsf");
		return null;
	}

	public String getLogoCodRegione() {
		return logoCodRegione;
	}


	public void setLogoCodRegione(String logoCodRegione) {
		this.logoCodRegione = logoCodRegione;
	}


	public HttpSession getSession() {
		return session;
	}


	public void setSession(HttpSession session) {
		this.session = session;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCognome() {
		return cognome;
	}


	public void setCognome(String cognome) {
		this.cognome = cognome;
	}


	public String getNominativo() {
		return nominativo;
	}


	public void setNominativo(String nominativo) {
		this.nominativo = nominativo;
	}

	
	
	
	
}
