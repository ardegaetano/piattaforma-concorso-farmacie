package com.accenture.CCFarm.PageBean;

import java.io.Serializable;
import java.util.Random;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.DAO.UtenteCandidaturaHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.LoginPrimoAccessoAction;
import com.accenture.CCFarm.utility.CriptDecriptUtil;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.mailer.concorsofarma.data.MailBean;


@ManagedBean
@RequestScoped

@SuppressWarnings("serial")
public class LoginPrimoAccessoBean implements Serializable {
	private String idUtenteSession;
	private String user; 
	private String oldPassword;
	private String newPassword;
	private String newPasswordConfirm;
	private String idRegione;
	private String primoAccesso;
	
	Logger logger = CommonLogger.getLogger("LoginPrimoAccessoBean");
	LoginPrimoAccessoAction loginPrimoAccessoAction=null;
	HttpSession session =null;
	
	public LoginPrimoAccessoBean(){
	
			this.init();
		
	}
	
	
	public void init() {  
    	
		FacesContext context = FacesContext.getCurrentInstance();
    	//HttpSession session = (HttpSession)context.getExternalContext().getSession(true);
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	session = req.getSession();
    	
		
		loginPrimoAccessoAction=new LoginPrimoAccessoAction();
		
		loginPrimoAccessoAction.loadPagina(this);
		
	}
		
	public String redirectLogin(){
		return  "homeCandidato";
		
	}
	
	private boolean controllaComplessitaPWD(){
		
		if(newPassword.length()< 8 || newPassword.length() > 18){
			return false;
		}
		String caratteriSpeciali ="@*;:-#.,|!?";
		String numerici = "0123456789";
		
		String caratttereDaVerificare ;
		boolean trovatoCarattereSepciale = false;
		boolean trovatoNumero = false; 
		for(int i=0; i<newPassword.length(); i++){
			caratttereDaVerificare = newPassword.substring(i, i+1);
			if (caratteriSpeciali.contains(caratttereDaVerificare)){
				trovatoCarattereSepciale = true;
			}
			if (numerici.contains(caratttereDaVerificare)){
				trovatoNumero = true;
			}
		}
		
		if(!trovatoNumero || !trovatoCarattereSepciale){
			return false;
		}
		
		String pwdmaiuscolo = newPassword.toUpperCase();
		if(pwdmaiuscolo.equals(newPassword)){
			return false;
		}
		
		String pwdminuscolo = newPassword.toLowerCase();
		if(pwdminuscolo.equals(newPassword)){
			return false;
		}
		
		return true;
	}

	public void autentica()
	{
		String sMsg = "";
		boolean ok=false;
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		try
		{
			if(newPassword!=null && newPasswordConfirm!= null &&
			   !newPassword.trim().equals("") && !newPasswordConfirm.trim().equals("") &&
			   newPassword.equals(newPasswordConfirm))
			{
				//Controllare che la pwd rispetti le regole di sicurezza
				if(!controllaComplessitaPWD())
				{
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("bean.psw.non.valida", lingua));
					newPassword="";
					newPasswordConfirm="";
				}
				else
				{
					loginPrimoAccessoAction.autenticaPrimoAccesso(this);
					
					String primoAccesso=(String)session.getAttribute(RepositorySession.PRIMO_ACCESSO);
					if(primoAccesso!=null && primoAccesso.toUpperCase().equals("SI"))
					{
						sMsg=JSFUtility.getPropertyMessage("bean.conserva.credenziali", lingua);
					}
					else
					{
						session.setAttribute(RepositorySession.PRIMO_ACCESSO, "NO");
					}
					
					ok=true;
				}
			}
			else
			{
				sMsg=JSFUtility.getPropertyMessage("bean.corrispondenza.psw.conferma", lingua);
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),sMsg);
				newPassword="";
				newPasswordConfirm="";
			}
		}
		catch (Exception e)
		{
    		logger.error("LoginPrimoAccessoBean - autentica: " + e.getMessage());	
    		JSFUtility.redirect("errorPageGenerica.jsf");
		}
		
		if(ok)
		{
			JSFUtility.addInfoMessage(JSFUtility.getPropertyMessage("bean.psw.aggiornata", lingua),"",true);
			if(!sMsg.equals(""))
				JSFUtility.addInfoMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),sMsg,true);
			
			JSFUtility.redirect("homeCandidato.jsf");
		}
		
	}
	
	public void nuovaPassword()
	{
		//salva nuova password nel db  e modificail flag primo accesso
		//invia mail
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		LoginPrimoAccessoAction loginAction = new LoginPrimoAccessoAction();
		UtenteCandidatura utenteCandidatura = new UtenteCandidatura();
		UtenteCandidaturaHome utenteCandidaturaHome = new UtenteCandidaturaHome();
		LoginPrimoAccessoBean loginBean = new LoginPrimoAccessoBean();
		MailBean mailBean;
		LogIn login = new LogIn();
		String newPassword="";
		Candidatura candidatura;
		
		//controlla utenza
		try
		{
			loginBean = loginAction.verificaUtenza(this);
		}
		catch(GestioneErroriException e1)
		{
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("bean.codice.utente.errato = ", lingua));
			return;
		}
			
		
		//genera password
		if(loginBean.getUser()!=null && !loginBean.getUser().equals("")){
			utenteCandidaturaHome = new UtenteCandidaturaHome();
			utenteCandidatura = utenteCandidaturaHome.findById(loginBean.getIdUtenteSession());
			boolean candidaturaAttiva = true;
		    if(utenteCandidatura.getCandidatura().getStatoRegistrazione().equalsIgnoreCase("A")){
		    	candidaturaAttiva = false;
		    	JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("bean.utenza.non.attiva", lingua));
		    }
		    if(utenteCandidatura.getCandidatura().getStatoRegistrazione().equalsIgnoreCase("I")){
		    	candidaturaAttiva = false;
		    	JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("bean.registrazione.non.terminata", lingua));
		    }
		    
		    if(candidaturaAttiva){
		    	newPassword = StringUtil.generateString(new Random(), loginBean.getNewPassword(), 10);
				
				utenteCandidatura=utenteCandidaturaHome.findById(loginBean.getIdUtenteSession());
				    	
				//setto flag primo accesso e nuova password
				candidatura = utenteCandidatura.getCandidatura();
				candidatura.setFlgPrimoAccesso("Y");
				utenteCandidatura.setCandidatura(candidatura);
				
				login.setIdRegione(loginBean.getIdRegione());
				login.setIdUtente(loginBean.getIdUtenteSession());
				login.setPassword(newPassword);
				login.setUtenza(loginBean.getUser());
				utenteCandidatura.setLogIn(login);
				
				mailBean = new MailBean();
				mailBean.getToAddresses().add(utenteCandidatura.getPecMail());
				
				
				//oggetto mail -----
				String codiceRegione=utenteCandidatura.getCodRegUtente();
				
				if(lingua.equals("de")){
					mailBean.setOggettoMail("Beantragung eines neuen Passwortes f�r die Autonome Provinz Bozen");
				}else{
					String oggettoMail="Richiesta nuova Password - Per la ";
					
						if(!codiceRegione.equals("041") && !codiceRegione.equals("042"))
						{
							oggettoMail=oggettoMail+"Regione ";
						}
						mailBean.setOggettoMail(oggettoMail+Localita.getDenominazioneRegione(codiceRegione));
				}

				//-------------------
				
				
				getCorpoMail(utenteCandidatura, mailBean);
						
				utenteCandidatura.setMailBean(mailBean);
				
				try
				{
					utenteCandidaturaHome.cambioPassword(utenteCandidatura);
					
					//se tutto � andato a buon fine, mostra messaggio di avviso
					JSFUtility.addInfoMessage("",JSFUtility.getPropertyMessage("bean.nuova.psw.generata", lingua),false);
				}
				catch(GestioneErroriException e)
				{
					e.printStackTrace();
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("bean.codice.utente.errato = ", lingua));
				}
		    }
			
		}	
		else
		{
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("bean.codice.utente.errato", lingua));
		}

	}
	
	public void getCorpoMail(UtenteCandidatura utenteCandidatura, MailBean mailBean){ 
		
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		String aesKey = AppProperties.getAppProperty("aesKey");
		String pwdDecriptata  = CriptDecriptUtil.decriptToken(utenteCandidatura.getLogIn().getPassword(), aesKey);
		
		String gentileCliente = JSFUtility.getPropertyMessage("bean.gentile", lingua) +utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente();
		String laSuaPassword = JSFUtility.getPropertyMessage("bean.psw.accesso", lingua) + Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente()) +JSFUtility.getPropertyMessage("bean.�", lingua);
		String attivazione = JSFUtility.getPropertyMessage("bean.modifica.psw", lingua);
		String navigazione = JSFUtility.getPropertyMessage("bean.navigazione.browser", lingua);
		//modificare il link-->home page
		
		String linkAccesso =" <a href= \"" +AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") + "/jsp/cartinaItalia.jsp\"/>"+ AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") +"/jsp/cartinaItalia.jsp</a>";
		
		mailBean.setCorpoMail("<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+laSuaPassword+"\r\n<br/>\r\n<br/>"+pwdDecriptata+"\r\n<br/>\r\n<br/>"+attivazione+"\r\n<br/>\r\n<br/>"+navigazione+" \r\n<br/>\r\n<br/> "+linkAccesso+"</htlml>");
		
	
	}
	
	public String redirectError(){
		return  "errorPage";
		
	}
	
	public String getPrimoAccesso() {
		return primoAccesso;
	}


	public void setPrimoAccesso(String primoAccesso) {
		this.primoAccesso = primoAccesso;
	}


	public String getIdUtenteSession() {
		return idUtenteSession;
	}


	public void setIdUtenteSession(String idUtenteSession) {
		this.idUtenteSession = idUtenteSession;
	}


	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getNewPasswordConfirm() {
		return newPasswordConfirm;
	}

	public void setNewPasswordConfirm(String newPasswordConfirm) {
		this.newPasswordConfirm = newPasswordConfirm;
	}


	public String getIdRegione() {
		return idRegione;
	}


	public void setIdRegione(String idRegione) {
		this.idRegione = idRegione;
	}

}
