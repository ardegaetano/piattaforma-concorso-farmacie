package com.accenture.CCFarm.PageBean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.io.BufferedInputStream;
import com.accenture.CCFarm.PDFModulo.GestionePDFModuloRicevuta;


@ManagedBean
@SessionScoped
public class GestionePDFDomandaBean {
	
	private final String pulsanteStampa = "none";  // hidden se nel css utilizzi visibility
	
	public String getPulsanteStampa() {
		return pulsanteStampa;
	}

	public String stampaDomanda()
	{
		
		try {
			GestionePDFModuloRicevuta gestionePDFModulo = new GestionePDFModuloRicevuta();
			//gestionePDFModulo.creaDomandaPDF();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "creatoPDF";
	}	
	
	
	
	public String ristampaRicevutaPDF()
	{
		
		try {
			GestionePDFModuloRicevuta gestionePDFModulo = new GestionePDFModuloRicevuta();
			gestionePDFModulo.ristampaRicevutaIdUtentePDF("307");
			gestionePDFModulo.downloadFile();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "creatoPDF";
	}
	
	
}
