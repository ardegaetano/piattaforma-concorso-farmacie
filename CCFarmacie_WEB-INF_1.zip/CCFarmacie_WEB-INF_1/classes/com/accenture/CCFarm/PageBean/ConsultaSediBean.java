package com.accenture.CCFarm.PageBean;

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.accenture.CCFarm.Bean.ComuneSelect;
import com.accenture.CCFarm.Bean.ProvinciaSelect;
import com.accenture.CCFarm.DAO.AnagraficaFarm;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.ConsultaSediAction;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.MatricePropertiesDe;


@ManagedBean
@SessionScoped
public class ConsultaSediBean implements Serializable {

//	Logger logger =Logger.getLogger("ConsultaSediBean");
	Logger logger = CommonLogger.getLogger("ConsultaSediBean");
	ConsultaSediAction consultaSediAction =new ConsultaSediAction(); 
	List<ConsultaSediListBean> listFarm = null;
	private ConsultaSediListBean consultaSediListBean;
	private String regioniDesc;
	private String numeroSediDisponibili;
	private String dataAggiornamentoSedi;
	private List listAnaFarm;
//	private List<Provincia> province;
//	private List<String> provinceFiltrate;
//	private List<Comune> comuni;
//	private List<String> comuneFiltrate;
	private String numeroProgressivo;
	
	
//	localit�
	private HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect;
	private HashMap<String, ArrayList<ComuneSelect>> comuniSelect;
	private ArrayList<ComuneSelect> comuniList;
	private ArrayList<ProvinciaSelect> provinceList;
//	private boolean attivaProvincia=true;
//	private boolean attivaComune = true;
	
	private String provinciaSelezionata;
	private String comuneSelezionato;
	
	
	
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	private String lingua= (String)session.getAttribute("linguaScelta");
	private boolean hideDesc=false;
	String idRegione="";
	
	MatricePropertiesDe matriceDe = MatricePropertiesDe.getMatricePropertiesDe(); 
	 
	public ConsultaSediBean(){

		this.init();
	}


	public void init() {  
		
		try {
			consultaSediAction.loadPaginaInserimento(this);
			listFarm = new ArrayList<ConsultaSediListBean>();
			
			
		} catch (GestioneErroriException e) {
			logger.error("ConsultaSediBean - init: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
		
	}

	public void provinciaCambiata(){
//		this.init();
		
//		if (comuniList!=null){
//			comuniList.clear();	
//		}
		numeroProgressivo=null;
		listFarm.clear();
		//carica tutti i comuni appartenenti alla provincia selezionata
		if (!provinciaSelezionata.equalsIgnoreCase("-1")){
			setComuniSelect(Localita.getComuni(provinciaSelezionata));
			comuniList=comuniSelect.get(provinciaSelezionata);
			RequestContext.getCurrentInstance().update(JSFUtility.getClientId("comune"));
		}
	
	}
	
	public void comuneCambiato(){
		numeroProgressivo=null;
		listFarm.clear();
	
	}
	
	public String indietro(){
		((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).removeAttribute("consultaSediBean");
		String lingua=(String)((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("linguaScelta");
		if(lingua.equals("de"))
		 JSFUtility.redirect("loginCandidato_de.jsp");
		else	
		 JSFUtility.redirect("loginCandidato.jsp");
		return null;
	}
		
	public String avvioRicerca(){
		FacesContext context = FacesContext.getCurrentInstance();
    	//HttpSession session = (HttpSession)context.getExternalContext().getSession(true);
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	idRegione = (String) session.getAttribute("ID_REGIONE");
		listFarm = new ArrayList<ConsultaSediListBean>();
		for (int i = 0; i < listAnaFarm.size(); i++) {
			AnagraficaFarm anagraficaFarm =new AnagraficaFarm();
			anagraficaFarm= (AnagraficaFarm) listAnaFarm.get(i);
			ConsultaSediListBean  consultaSediList = new ConsultaSediListBean();
			boolean filtroOk = true;
			
			if (numeroProgressivo!=null && !numeroProgressivo.equals("")){
				if (!numeroProgressivo.equalsIgnoreCase(anagraficaFarm.getNProgressivo())){
					filtroOk = false;
				}
			}
					
			if(provinciaSelezionata!=null      && 
			   !provinciaSelezionata.equals("")&& 
			   !provinciaSelezionata.equals("-1")){
				if (!provinciaSelezionata.equals(anagraficaFarm.getPrvFarm())){
					filtroOk = false;
				}
			}
			if(comuneSelezionato!=null       &&
			   !comuneSelezionato.equals("") &&
			   !comuneSelezionato.equals("-1") ){
				if (!comuneSelezionato.equals(anagraficaFarm.getComuneFarm())){
					filtroOk = false;
				}
			}
	
		    if (filtroOk){
		    	  if(lingua.equalsIgnoreCase("de")){
		    		  consultaSediList.setLingua(true);
		    	  }
		    	caricoFramList(consultaSediList, anagraficaFarm);
		    }
		    if(lingua.equalsIgnoreCase("de")){
		    	this.setHideDesc(true);
			}
		    
		
		}
		
		
		int gg =listFarm.size();
		
 		return "consultaSedi";
	}
	
	private void caricoFramList(ConsultaSediListBean  consultaSediList, AnagraficaFarm anagraficaFarm){
		try{
			
			//if true linguaScelta = tedesco
			boolean lingua = consultaSediList.isLingua();
	    	
			consultaSediList.setCodIstatProv(anagraficaFarm.getPrvFarm()==null?"":anagraficaFarm.getPrvFarm());
			String desProvince = anagraficaFarm.getPrvFarm()==null?"":anagraficaFarm.getPrvFarm()+" - ";
			desProvince += consultaSediAction.getDesProvincia(anagraficaFarm.getPrvFarm());
			consultaSediList.setDesProv(desProvince);
			
			
			
			consultaSediList.setCodIstatComu(anagraficaFarm.getComuneFarm()==null?"":anagraficaFarm.getComuneFarm());
			String desComuni = anagraficaFarm.getComuneFarm()==null?"":anagraficaFarm.getComuneFarm()+" - ";
			desComuni += consultaSediAction.getDesComuini(anagraficaFarm.getComuneFarm());
			consultaSediList.setDesComu(desComuni);
			
			if(idRegione.equalsIgnoreCase("041")){
				consultaSediList.setDesProv(anagraficaFarm.getDescrPrvFarm());
				consultaSediList.setDesComu(anagraficaFarm.getFrazioneFarm());
			}
			
			
			
			
			consultaSediList.setnProgCom(anagraficaFarm.getNProgressivo()==null?"":anagraficaFarm.getNProgressivo());
			
	//campo clob                     
			if (anagraficaFarm.getDescrizioneSede()!=null){
//		        char[] charBufferNote = new char[2048];
//		        int charLettiNote = -1;
//		        StringBuffer fileNote = new StringBuffer();        
//		        Clob oraClobNote = anagraficaFarm.getDescrizioneSede();                                                                
//		        Reader isNote;
//				try {
//					isNote = oraClobNote.getCharacterStream();
//					while ((charLettiNote = isNote.read(charBufferNote))>-1)
//					{
//					        for (int i = 0; i<charLettiNote; i++)
//					        {
//					                fileNote.append(charBufferNote[i]);
//					        }
//					        int u = 0;
//					}
//					isNote.close();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (SQLException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
				
		        consultaSediList.setDesSede(anagraficaFarm.getDescrizioneSede());
			}else{
				consultaSediList.setDesSede("");
			}
			if (anagraficaFarm.getDescrizioneSedeDe()!=null){
//		        char[] charBufferNote = new char[2048];
//		        int charLettiNote = -1;
//		        StringBuffer fileNote = new StringBuffer();        
//		        Clob oraClobNote = anagraficaFarm.getDescrizioneSedeDe();                                                                
//		        Reader isNote;
//				try {
//					isNote = oraClobNote.getCharacterStream();
//					while ((charLettiNote = isNote.read(charBufferNote))>-1)
//					{
//					        for (int i = 0; i<charLettiNote; i++)
//					        {
//					                fileNote.append(charBufferNote[i]);
//					        }
//					        int u = 0;
//					}
//					isNote.close();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (SQLException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
				
		        consultaSediList.setDesSedeDe(anagraficaFarm.getDescrizioneSedeDe());
			}else{
				consultaSediList.setDesSedeDe("");
			}
				
			if(lingua){
				consultaSediList.setTipoSede(anagraficaFarm.getCodTipoSede()==null?"":matriceDe.getMatricePropertiesDe(anagraficaFarm.getCodTipoSede().replace(" ", "_")));
				consultaSediList.setCritTopo(anagraficaFarm.getCriterioTopoFarm()==null?"":matriceDe.getMatricePropertiesDe(anagraficaFarm.getCriterioTopoFarm().replace(" ", "_")));
		//		consultaSediList.setContenzioso(anagraficaFarm.getContenziosoFarm());
				//consultaSediList.setContenzioso(anagraficaFarm.getContenziosoFarm());
				
				consultaSediList.setIndennitaAvviamento(anagraficaFarm.getIndennitaAvviamento()==null?"":matriceDe.getMatricePropertiesDe(anagraficaFarm.getIndennitaAvviamento().replace(" ", "_")));
			}else{
	        consultaSediList.setTipoSede(anagraficaFarm.getCodTipoSede()==null?"":anagraficaFarm.getCodTipoSede());
			consultaSediList.setCritTopo(anagraficaFarm.getCriterioTopoFarm()==null?"":anagraficaFarm.getCriterioTopoFarm());
	//		consultaSediList.setContenzioso(anagraficaFarm.getContenziosoFarm());
			//consultaSediList.setContenzioso(anagraficaFarm.getContenziosoFarm());
			
			consultaSediList.setIndennitaAvviamento(anagraficaFarm.getIndennitaAvviamento()==null?"":anagraficaFarm.getIndennitaAvviamento());
		
			}
			listFarm.add(consultaSediList);
		
		} catch (GestioneErroriException e) {
			logger.error("ConsultaSediBean - caricoFramList: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
		
		
	}
	
	
	
	
	
	public String getRegioniDesc() {
		return regioniDesc;
	}

	public void setRegioniDesc(String regioniDesc) {
		this.regioniDesc = regioniDesc;
	}

	public String getNumeroSediDisponibili() {
		return numeroSediDisponibili;
	}

	public void setNumeroSediDisponibili(String numeroSediDisponibili) {
		this.numeroSediDisponibili = numeroSediDisponibili;
	}

	public List getListAnaFarm() {
		return listAnaFarm;
	}

	public void setListAnaFarm(List listAnaFarm) {
		this.listAnaFarm = listAnaFarm;
	}

	public String getProvinciaSelezionata() {
		return provinciaSelezionata;
	}

	public void setProvinciaSelezionata(String provinciaSelezionata) {
		this.provinciaSelezionata = provinciaSelezionata;
	}


	public String getComuneSelezionato() {
		return comuneSelezionato;
	}

	public void setComuneSelezionato(String comuneSelezionato) {
		this.comuneSelezionato = comuneSelezionato;
	}


	 public String getNumeroProgressivo() {
		return numeroProgressivo;
	}

	public void setNumeroProgressivo(String numeroProgressivo) {
		this.numeroProgressivo = numeroProgressivo;
	}

	public List<ConsultaSediListBean> getListFarm() {
		return listFarm;
	}

	public void setListFarm(List<ConsultaSediListBean> listFarm) {
		this.listFarm = listFarm;
	}


	public ConsultaSediListBean getConsultaSediListBean() {
		return consultaSediListBean;
	}


	public void setConsultaSediListBean(ConsultaSediListBean consultaSediListBean) {
		this.consultaSediListBean = consultaSediListBean;
	}


	public ConsultaSediAction getConsultaSediAction() {
		return consultaSediAction;
	}


	public void setConsultaSediAction(ConsultaSediAction consultaSediAction) {
		this.consultaSediAction = consultaSediAction;
	}


	public HashMap<String, ArrayList<ProvinciaSelect>> getProvinceSelect() {
		return provinceSelect;
	}


	public void setProvinceSelect(
			HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect) {
		this.provinceSelect = provinceSelect;
	}


	public HashMap<String, ArrayList<ComuneSelect>> getComuniSelect() {
		return comuniSelect;
	}


	public void setComuniSelect(
			HashMap<String, ArrayList<ComuneSelect>> comuniSelect) {
		this.comuniSelect = comuniSelect;
	}


	public ArrayList<ComuneSelect> getComuniList() {
		return comuniList;
	}


	public void setComuniList(ArrayList<ComuneSelect> comuniList) {
		this.comuniList = comuniList;
	}


	public ArrayList<ProvinciaSelect> getProvinceList() {
		return provinceList;
	}


	public void setProvinceList(ArrayList<ProvinciaSelect> provinceList) {
		this.provinceList = provinceList;
	}


	public String getLingua() {
		return lingua;
	}


	public void setLingua(String lingua) {
		this.lingua = lingua;
	}


	public boolean isHideDesc() {
		return hideDesc;
	}


	public void setHideDesc(boolean hideDesc) {
		this.hideDesc = hideDesc;
	}


	public String getDataAggiornamentoSedi() {
		return dataAggiornamentoSedi;
	}


	public void setDataAggiornamentoSedi(String dataAggiornamentoSedi) {
		this.dataAggiornamentoSedi = dataAggiornamentoSedi;
	}

	

}
