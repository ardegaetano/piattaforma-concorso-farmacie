package com.accenture.CCFarm.PageBean;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.UtenteAssociato;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.ControlloBandoScaduto;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;

@ManagedBean
@SessionScoped
public class Registrazione {
	
	private RichiestaCredenziali richiestaCredenziali;
	Logger logger = CommonLogger.getLogger("ConsultaSediBean");
	
	boolean disabilitaAssociato = true;
	private List<UtenteAssociato> listaUtentiAssociati;
	private boolean aggiungiNuovoAssociatoBoolean = false;
		
	public Registrazione()
	{
		try {
			
			listaUtentiAssociati = new ArrayList<UtenteAssociato>();
			richiestaCredenziali = new RichiestaCredenziali();
			richiestaCredenziali.initLocalita();
			String linguaScelta = (String) GetSessionUtility.getSessionAttribute("linguaScelta");
			
		} catch (GestioneErroriException e) {
			logger.error("Registrazione - caricamento dati pagina: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
		
	}
	
	//listeners --------------------------------------------------
	
	public void modalitaCambiata(javax.faces.event.AjaxBehaviorEvent event)
	{
		JSFUtility.update("pannelloAssociato");
	}
	
	//------------------------------------------------------------
	
	private boolean controllaCaptcha()
	{
		String correctCaptcha=(String)GetSessionUtility.getSessionAttribute("captchaCode");
		
		System.out.println("captcha corretto: "+correctCaptcha);
		System.out.println("captcha inserito: "+richiestaCredenziali.getCaptchaCode());
		
		if(correctCaptcha!=null && richiestaCredenziali.getCaptchaCode()!=null && richiestaCredenziali.getCaptchaCode().equals(correctCaptcha))
			return true;
		return false;
	}
	
	public void prosegui()
	{
		String sMsg = "";
		boolean ok= true;
		
		//Controllo e Generazione CF stranieri
		if(!richiestaCredenziali.getNazioneNascitaUtente().equals("IT")){ //Per nazione nascita diversa da Italia
			if(!richiestaCredenziali.getFlagCodiceFiscaleItaliano().equals("true")) { //Non in possesso di un codice fiscale Italiano
				String sCFCalc = StringUtil.generaCodiceFiscaleStraniero(richiestaCredenziali.getCognomeUtente(), 
						 richiestaCredenziali.getNomeUtente(), 
						 richiestaCredenziali.getDataNascitaUtente(), 
						 richiestaCredenziali.getNazioneNascitaUtente(), 
						 richiestaCredenziali.getLuogoNascitaEstera(),
						 richiestaCredenziali.getSesso());
				richiestaCredenziali.setCodiceFiscaleUtente(sCFCalc);
			}
		}
		
		//Controllo CF Italiano
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		
		if((richiestaCredenziali.getNazioneNascitaUtente().equals("IT") || richiestaCredenziali.getFlagCodiceFiscaleItaliano().equals("true")) &&
				(richiestaCredenziali.getCodiceFiscaleUtente().length()<16)) 
		{
			sMsg = JSFUtility.getPropertyMessage("registazione.16.caratteri", lingua);//Il codice fiscale deve essere di 16 caratteri
			addMessageError(sMsg);
			ok= false;
		} 
		else if (richiestaCredenziali.getModalitaPartecipazione().equals("A") ){
			if (listaUtentiAssociati==null || (listaUtentiAssociati!=null && listaUtentiAssociati.size()==0)){
				sMsg = JSFUtility.getPropertyMessage("registrazione.inserire.associato", lingua);//Per il tipo domanda scelto bisogna inserire almeno un Associato
				addMessageError(sMsg);
				ok= false;
			}
		} 
		
		if (ok)JSFUtility.redirect("confermaRegistrazione.jsf");
	}
	
	public void aggiornaCF()
	{
		richiestaCredenziali.setCodiceFiscaleUtente("");
	}
		
	public String indietroLogIn()
	{
		String linguaScelta = (String) GetSessionUtility.getSessionAttribute("linguaScelta");
		((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).removeAttribute(RepositorySession.registrazione);
        if(linguaScelta!=null&&linguaScelta.equalsIgnoreCase("de"))
         JSFUtility.redirect("loginCandidato_de.jsp");
        else	
		 JSFUtility.redirect("loginCandidato.jsp");
		return null;
	}
	
	public void registra()
	{
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		if(richiestaCredenziali.getFlagAccettazioneTermini())
		{
			if(controllaCaptcha())
			{
				String codRegioneSelezionata=(String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_REGIONE);
				
				if(codRegioneSelezionata!=null && !codRegioneSelezionata.equals(""))
				{
					richiestaCredenziali.setRegioneRichiesta(codRegioneSelezionata);
					try
					{
						ControlloBandoScaduto controllo = new ControlloBandoScaduto();
						if(controllo.controllaScadenza(codRegioneSelezionata))
						{
							if(richiestaCredenziali.CheckUsers())
							{
								if(richiestaCredenziali.salvaCredenziali()){
									((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).removeAttribute(RepositorySession.registrazione);
									JSFUtility.redirect("RegistrazioneOk.jsf");
								}
							}
							else{
								JSFUtility.addWarningMessage("",richiestaCredenziali.getMessaggioErrore());
								richiestaCredenziali.setCaptchaCode(null);
								
								
							}	
						}
						else
						{
							richiestaCredenziali.setMessaggioErrore(JSFUtility.getPropertyMessage("registrazione.bando.scaduto", lingua));//Attenzione, il bando � scaduto
							JSFUtility.redirect("errorPageRegistrazione.jsf");
						}
					}
					catch(Exception e)
					{
						LogUtil.printException(e);
						richiestaCredenziali.setMessaggioErrore(JSFUtility.getPropertyMessage("registrazione.eccezione.generica", lingua));//Eccezione generica in fase di registrazione
						JSFUtility.redirect("errorPageRegistrazione.jsf");
					}
				}
				else
				{
					richiestaCredenziali.setMessaggioErrore(JSFUtility.getPropertyMessage("registrazione.scegliere.regione", lingua));//Attenzione, prima di registarti devi scegliere una regione
					JSFUtility.redirect("errorPageRegistrazione.jsf");
				}
			}
			else
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("registrazione.codice.non.corretto", lingua));//"Attenzione", "Il codice inserito non � corretto"
				richiestaCredenziali.setCaptchaCode(null);
				
			}
		}
		else
		{
			JSFUtility.addInfoMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("registrazione.spuntare.casella", lingua),false);//"Attenzione", "La casella di dichiarazione deve essere spuntata",false);
			
		}
		
	}
	
	
	public void addMessage(String Intestazione, String summary) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO,Intestazione, summary);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
	
	

	public void addMessageError(String summary) {
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN,JSFUtility.getPropertyMessage("bean.attenzione", lingua), summary);
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
	
	
	public String deleteAssociato()
	{
		richiestaCredenziali.eliminaAssociato();
		return null;
	}
	
	public String modificaAssociato()
	{
		setAggiungiNuovoAssociatoBoolean(true);
		richiestaCredenziali.modificaAssociato();
		return null;
	}
	
	public String aggiungiNuovoAssociato()
	{
		System.out.println("aggiungi nuovo associato");
		
		setAggiungiNuovoAssociatoBoolean(true);
		richiestaCredenziali.aggiungiNuovoAssociatoButton();
		JSFUtility.redirect("registrazione.jsf#form:pannelloAssociato");
		return null;
	}
	
	public String aggiungiAssociato()
	{
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		System.out.println("aggiungi associato");
		try {
			UtenteAssociato utAss = richiestaCredenziali.getUtenteAssociato();
			//Controllo CF Italiano
			if((utAss.getNazioneNascitaUtenteAssociato().equals("IT") || utAss.getFlagCodiceFiscaleItalianoAssociato().equals("true")) && 
			 (utAss.getCodiceFiscaleUtenteAssociato().length()<16)) 
			{
				String sMsg = JSFUtility.getPropertyMessage("registazione.associato.codice.16.caratteri", lingua); //"Il codice fiscale dell'associato deve essere di 16 caratteri";
				addMessageError(sMsg);
			}
			else {
				setAggiungiNuovoAssociatoBoolean(false);
				listaUtentiAssociati = richiestaCredenziali.aggiungiUtente();
				JSFUtility.redirect("registrazione.jsf#form:pannelloAssociato");
			}
		} catch (GestioneErroriException e) {
			logger.error("Registrazione - aggiungiAssociato: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
		return null;
	}
	
	//-----------------------------------------------------------------------
	
	public RichiestaCredenziali getRichiestaCredenziali()
	{
		return richiestaCredenziali;
	}

	public void setRichiestaCredenziali(RichiestaCredenziali richiestaCredenziali) {
		this.richiestaCredenziali = richiestaCredenziali;
	}
	
	public boolean isDisabilitaAssociato() {
		return disabilitaAssociato;
	}

	public void setDisabilitaAssociato(boolean disabilitaAssociato) {
		this.disabilitaAssociato = disabilitaAssociato;
	}

	public ArrayList<UtenteAssociato> getListaUtentiAssociati() {
		return (ArrayList<UtenteAssociato>) listaUtentiAssociati;
	}

	public void setListaUtentiAssociati(ArrayList<UtenteAssociato> listaUtentiAssociati) {
		this.listaUtentiAssociati = listaUtentiAssociati;
	}

	public boolean isAggiungiNuovoAssociatoBoolean() {
		return aggiungiNuovoAssociatoBoolean;
	}

	public void setAggiungiNuovoAssociatoBoolean(boolean aggiungiNuovoAssociatoBoolean) {
		this.aggiungiNuovoAssociatoBoolean = aggiungiNuovoAssociatoBoolean;
	}

 }