package com.accenture.CCFarm.PageBean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.utility.AppProperties;

@ManagedBean
@RequestScoped
public class ConfermaRegistrazione {
	
	private String regione;
	private String lingua;
	
	//Testo per Msg Attivazione OK in Tedesco
	private String attivazionePecMsg_de;
	private String attivazionePecTitolo_de;
	private String attivazionePecTesto_de;
	private String attivazionePecTestoChiudiFinestra_de;
	
	private String attivazionePecErrore;
	//Testo per Msg Attivazione KO 
	private String attivazionePecKo;
	//Testo per Msg Attivazione KO Link non attivo
	private String attivazionePecLinkNonAttivo;
	//Testo per Msg Attivazione KO Link non attivo
	private String attivazionePecNonAttuale;
	
	public String getRegione() {
		return regione;
	}

	public void setRegione(String regione) {
		this.regione = regione;
	}

	public String getLingua() {
		return lingua;
	}

	public void setLingua(String lingua) {
		this.lingua = lingua;
	}

	public String getAttivazionePecMsg_de() {
		return attivazionePecMsg_de;
	}

	public void setAttivazionePecMsg_de(String attivazionePecMsg_de) {
		this.attivazionePecMsg_de = attivazionePecMsg_de;
	}

	public String getAttivazionePecTitolo_de() {
		return attivazionePecTitolo_de;
	}

	public void setAttivazionePecTitolo_de(String attivazionePecTitolo_de) {
		this.attivazionePecTitolo_de = attivazionePecTitolo_de;
	}

	public String getAttivazionePecTesto_de() {
		return attivazionePecTesto_de;
	}

	public void setAttivazionePecTesto_de(String attivazionePecTesto_de) {
		this.attivazionePecTesto_de = attivazionePecTesto_de;
	}

	public String getAttivazionePecTestoChiudiFinestra_de() {
		return attivazionePecTestoChiudiFinestra_de;
	}

	public void setAttivazionePecTestoChiudiFinestra_de(
			String attivazionePecTestoChiudiFinestra_de) {
		this.attivazionePecTestoChiudiFinestra_de = attivazionePecTestoChiudiFinestra_de;
	}

	public String getAttivazionePecErrore() {
		return attivazionePecErrore;
	}

	public void setAttivazionePecErrore(String attivazionePecErrore) {
		this.attivazionePecErrore = attivazionePecErrore;
	}

	public String getAttivazionePecKo() {
		return attivazionePecKo;
	}

	public void setAttivazionePecKo(String attivazionePecKo) {
		this.attivazionePecKo = attivazionePecKo;
	}

	public String getAttivazionePecLinkNonAttivo() {
		return attivazionePecLinkNonAttivo;
	}

	public void setAttivazionePecLinkNonAttivo(String attivazionePecLinkNonAttivo) {
		this.attivazionePecLinkNonAttivo = attivazionePecLinkNonAttivo;
	}

	public String getAttivazionePecNonAttuale() {
		return attivazionePecNonAttuale;
	}

	public void setAttivazionePecNonAttuale(String attivazionePecNonAttuale) {
		this.attivazionePecNonAttuale = attivazionePecNonAttuale;
	}

	public ConfermaRegistrazione(){
		
		regione = (String) ((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute(AppProperties.getAppProperty("idRegioneRegistrata"));
		lingua = (String) ((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("lingua");
		
		if(lingua!=null && lingua.equals("de")) { //Testo per Bolzano
			attivazionePecMsg_de = "Die neue PEC-Adresse wurde erfolgreich aktiviert";
			attivazionePecTitolo_de ="Aktivierungsbest�tigung";
			attivazionePecTesto_de ="Sehr geehrter Bewerber, Ihre neue PEC-Adresse f�r die Region Autonome Provinz Bozen wurde aktiviert.";
			attivazionePecTestoChiudiFinestra_de ="Bitte schlie�en Sie dieses Fenster";
			
			attivazionePecErrore = " Fehler"; //Errore
			//Testo per Msg Attivazione KO (Si � verificato un errore in fase di attivazione della nuova Pec)
			attivazionePecKo = "Bei der Aktivierung der neuen PEC-Adresse ist ein Fehler aufgetreten.";
			//Testo per Msg Attivazione KO Link non attivo (Attenzione il link cliccato non � pi� attivo)
			attivazionePecLinkNonAttivo = "Achtung, der angeklickte Link ist nicht mehr aktiv.";
			//Testo per Msg Attivazione KO Link non attivo (Attenzione la Pec inserita non corrisponde a quella attuale)
			attivazionePecNonAttuale = "Achtung, die angegebene PEC-Adresse stimmt nicht mit der aktuellen �berein.";
					
		}
		
	}
	
}
