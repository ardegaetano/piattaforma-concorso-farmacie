package com.accenture.CCFarm.PageBean;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.accenture.CCFarm.Bean.AltraLaureaBis;
import com.accenture.CCFarm.Bean.AltroTitolo;
import com.accenture.CCFarm.Bean.BorsaStudio;
import com.accenture.CCFarm.Bean.CorsoAgg;
import com.accenture.CCFarm.Bean.Dottorato;
import com.accenture.CCFarm.Bean.Pubblicazione;
import com.accenture.CCFarm.Bean.Specializzazione;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.TitoliStudioAction;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.MatriceProperties;
import com.accenture.CCFarm.utility.MatricePropertiesDe;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;


@ManagedBean
@SessionScoped
public class TitoliStudioCarrieraBean {
	Logger logger = CommonLogger.getLogger("TitoliStudioCarrieraBean");
	//Seconda laurea
		private String idSecondaLaurea;
		private String descUniSecondaLaurea;
		private String luogoSecondaLaurea;
		private Date dataSecondaLaurea;
		private String nazioneSecondaLaurea;
		private String flagEsteroSecondaLaurea;
	
	
	//Seconda laurea bis
		private String idAltraLaureaBis;
		private String descUniSecondaLaureaBis;
		private String luogoSecondaLaureaBis;
		private Date dataSecondaLaureaBis;
		private String nazioneSecondaLaureaBis;
		private String flagEsteroSecondaLaureaBis;
	
	
	//Specializzazioni
		private String denominazioneSpec;
		private String descrFacoltaSpec;
		private String descrUniversitaSpec;
		private String luogoSpec;
		private String nazioneSpec;
		private String durataSpec;
		private String flagEsteroSpec;
		
		
	
	// Borse di studio	
		private String denominazioneBorsa;
		private String descrFacoltaBorsa;
		private String descrUniversitaBorsa;
		private String luogoBorsa;
		private String nazioneBorsa;
		private Date   dataInizioBorsa;
		private Date   dataFineBorsa;
		private String flagEsteroBorsa;
	
	
		
	// Dottorato	
		private String denominazioneDottorato;
		private String descrFacoltaDottorato;
		private String descrUniversitaDottorato;
		private String luogoDottorato;
		private String nazioneDottorato;
		private Date   dataInizioDottorato;
		private Date   dataFineDottorato;
		private String flagEsteroDottorato;
		
		
		
	//Altri titoli
		private String descAltroTitolo;
		private String durataAltroTitolo;
		private String rilascioAltroTitolo;
		private Date dataRilascioAltroTitolo;
		private String esameFinaleAltroTitolo;
		private String noteAltroTitolo;
		private String flagEsteroAltroTitolo;
		
		
		
	//idoneita
		private String flagIdoneitaSediIdoneita;
		private String estremiIdoneita;
		private Date dataIdoneita;
		private String rifIdoneitaNazionale;
		private String annoIdoneitaNazionale;
			
		
	
	//corsi aggiornamento
		private String titoloCorsoAgg;
		private String organizzatoCorsoAgg;
		private Date   dataInizioCorsoAgg;
		private Date   dataFineCorsoAgg;
		private String totOreCorsoAgg;
		private String dichiarazioneCorsoAgg;
		private String flagEsteroCorsoAgg;
		
		private String dataInizioCorsoReg;
	
	
	

	// Pubblicazioni
		private String tipoPubblicazione;
		private String autorePubblicazione;
		private String titoloPubblicazione;
		private String editorePubblicazione;
		private String codIsbn;
		private Date dataPubblicazione;
		
		private String dataInizioPubblicazioneReg;
		
		private String elencoDoc ="";
		
		private String descPrimaLaurea;
		
		ArrayList<AltraLaureaBis> listaAltreLaureeBis;
		ArrayList<Specializzazione> listaSpecializzazioni;
		ArrayList<BorsaStudio> listaBorseStudio;
		ArrayList<Dottorato> listaDottorati;
		ArrayList<AltroTitolo> listaAltriTitoli;
		ArrayList<CorsoAgg> listaCorsiAgg;
		ArrayList<Pubblicazione> listaPubblicazioni;
		private AltraLaureaBis altraLaureaBis;
		private AltraLaureaBis altraLaureaBisSelezionata;
		private Specializzazione specializzazione;
		private Specializzazione specializzazioneSelezionata;
		private BorsaStudio borsaStudio;
		private BorsaStudio borsaStudioSelezionata;
		private Dottorato dottorato;
		private Dottorato dottoratoSelezionato;
		private AltroTitolo altroTitolo;
		private AltroTitolo altroTitoloSelezionato;
		private CorsoAgg corsoAgg;
		private CorsoAgg corsoAggSelezionato;
		private Pubblicazione pubblicazione;
		private Pubblicazione pubblicazioneSelezionata;
		
		TitoliStudioAction titoliStudioAction;
		
	    private boolean visualizzaPanelBancario=false;
	    private boolean visualizzaPanelPostale=false;
	    private boolean visualizzaPanelDocumenti=true;
	    private boolean visualizzaPanelVersamenti = true;
	    private boolean visualizzaDichiarazione = false;
	    private DatiBando datiBando;
		private String tipologiaVersamento;
		private String contributoPartecipazione;
		private boolean mostraPanelBancario=false;
		private boolean mostraPanelPostale=false;
		private boolean mostraListaPagamenti=false;
		private String tipiPagamento;
		
	    private Date dataNascitaUtente;
	    private Date dataPrimaLaurea;

	    Date data_corso_appoggio;
	    Date data_pubb_appoggio;
	    
	    Date dataPubblicazioneBando;
	    Date dataScadenzaBando;
	    
	    private int elencoDocSize;
	    
	    MatriceProperties matriceIt = MatriceProperties.getMatricePropertiesIt();
	    MatricePropertiesDe matriceDe = MatricePropertiesDe.getMatricePropertiesDe();
	   
	   private void findDateBando()
	   {
			data_corso_appoggio=((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataInizioCorsi();
			data_pubb_appoggio=((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataInizioPubblicazioni();
			dataPubblicazioneBando=((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataPubblicazioneBando();
			dataScadenzaBando=((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataFineBando();
	   }

		public TitoliStudioCarrieraBean() {
			findDateBando();
			
			titoliStudioAction=new TitoliStudioAction();
			listaAltreLaureeBis = new ArrayList<AltraLaureaBis>();
			listaSpecializzazioni = new ArrayList<Specializzazione>();
			listaBorseStudio = new ArrayList<BorsaStudio>();
			listaDottorati = new ArrayList<Dottorato>();
			listaAltriTitoli = new ArrayList<AltroTitolo>();
			listaCorsiAgg = new ArrayList<CorsoAgg>();
			listaPubblicazioni = new ArrayList<Pubblicazione>();
			altraLaureaBis = new AltraLaureaBis();
			altraLaureaBisSelezionata = new AltraLaureaBis();
			specializzazione = new Specializzazione();
			borsaStudio = new BorsaStudio();
			dottorato = new Dottorato();
			altroTitolo = new AltroTitolo(); 
			corsoAgg = new CorsoAgg();
			pubblicazione = new Pubblicazione();
		}
		
		public void controllaPubbl(){
			
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			boolean isTedesco = false;
				if(lingua.equals("de")){
					 isTedesco = true;
				}
			elencoDoc="";
			ArrayList<String> listaDoc = new ArrayList<String>();
			// controllo su Altra Laurea, e liste Corsi,Altri Titoli ,Dottorato,Borse di studio ,Specializzazioni,Altra laurea bis 
			if (this.flagEsteroSecondaLaurea!=null&&(this.flagEsteroSecondaLaurea.equalsIgnoreCase("si")||this.flagEsteroSecondaLaurea.equalsIgnoreCase("ja"))){
				
				if(isTedesco){
					listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.seclaurea", lingua)+ " "+matriceDe.getMatricePropertiesDe(this.idSecondaLaurea.replace(" ", "_")));
				}
				else{
					listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.seclaurea", lingua)+ " "+this.idSecondaLaurea);
				}
//				listaDoc.add("documentazione relativa alla Seconda laurea in  "+ this.idSecondaLaurea);
				//this.setVisualizzaPanelVersamenti(false);
			}		
			
			if(listaAltreLaureeBis!=null){
				Iterator iterator = listaAltreLaureeBis.iterator();
				while(iterator.hasNext()){
					altraLaureaBis = (AltraLaureaBis)iterator.next();
					if (altraLaureaBis.getFlagEsteroSecondaLaureaBis().equalsIgnoreCase("si")||altraLaureaBis.getFlagEsteroSecondaLaureaBis().equalsIgnoreCase("ja")){
						
							listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.seclaurea", lingua)+" "+ this.altraLaureaBis.getIdAltraLaureaBis());

						}
							//listaDoc.add("documentazione relativa alla Seconda laurea in  "+ this.altraLaureaBis.getIdAltraLaureaBis());
						//this.setVisualizzaPanelVersamenti(false);
					}
			}
			
			if(listaAltriTitoli!=null){
				Iterator iterator = listaAltriTitoli.iterator();
				while(iterator.hasNext()){
					altroTitolo = (AltroTitolo)iterator.next();
					if (altroTitolo.getFlagEsteroAltroTitolo().equalsIgnoreCase("si")||altroTitolo.getFlagEsteroAltroTitolo().equalsIgnoreCase("ja")){
						
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.altro.titolo", lingua)+ " "+this.altroTitolo.getDescAltroTitolo());
//						listaDoc.add("documentazione relativa ad altro titolo di studio "+ this.altroTitolo.getDescAltroTitolo());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaBorseStudio!=null){
				Iterator iterator = listaBorseStudio.iterator();
				while(iterator.hasNext()){
					borsaStudio = (BorsaStudio)iterator.next();
					if (borsaStudio.getFlagEsteroBorsa().equalsIgnoreCase("si")||borsaStudio.getFlagEsteroBorsa().equalsIgnoreCase("ja")){
						
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.borsa.studio", lingua)+" "+ this.borsaStudio.getDenominazioneBorsa());
//						listaDoc.add("documentazione relativa alla borsa di studio "+ this.borsaStudio.getDenominazioneBorsa());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaCorsiAgg!=null){
				Iterator iterator = listaCorsiAgg.iterator();
				while(iterator.hasNext()){
					corsoAgg = (CorsoAgg)iterator.next();
					if (corsoAgg.getFlagEsteroCorsoAgg().equalsIgnoreCase("si")||corsoAgg.getFlagEsteroCorsoAgg().equalsIgnoreCase("ja")){
						
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.corso.aggiornamento", lingua)+" "+ this.corsoAgg.getTitoloCorsoAgg());
//						listaDoc.add("documentazione relativa al corso di aggiornamento "+ this.corsoAgg.getTitoloCorsoAgg());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaDottorati!=null){
				Iterator iterator = listaDottorati.iterator();
				while(iterator.hasNext()){
					dottorato = (Dottorato)iterator.next();
					if (dottorato.getFlagEsteroDottorato().equalsIgnoreCase("si")||dottorato.getFlagEsteroDottorato().equalsIgnoreCase("ja")){
						
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.dottorato", lingua)+ " "+this.dottorato.getDenominazioneDottorato());
//						listaDoc.add("documentazione relativa al dottorato "+ this.dottorato.getDenominazioneDottorato());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaSpecializzazioni!=null){
				Iterator iterator = listaSpecializzazioni.iterator();
				while(iterator.hasNext()){
					specializzazione = (Specializzazione)iterator.next();
					if (specializzazione.getFlagEsteroSpec().equalsIgnoreCase("si")||specializzazione.getFlagEsteroSpec().equalsIgnoreCase("ja")){
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.specializzazione", lingua)+ " "+this.specializzazione.getDenominazioneSpec());						
//						listaDoc.add("documentazione relativa alla specializzazione "+ this.specializzazione.getDenominazioneSpec());
						//this.setVisualizzaPanelVersamenti(false);
					}
				}
			}
			
			if(listaPubblicazioni!=null){
				Iterator iterator = listaPubblicazioni.iterator();
				while(iterator.hasNext()){
					pubblicazione = (Pubblicazione)iterator.next();
						
						listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.documentazione.pubblicazione", lingua)+ " "+this.pubblicazione.getTitoloPubblicazione());
//						listaDoc.add("documentazione relativa alla pubblicazione "+ this.pubblicazione.getTitoloPubblicazione());
						//this.setVisualizzaPanelVersamenti(false);
				}
			}

			datiBando=(DatiBando)GetSessionUtility.getSessionAttribute(RepositorySession.DATI_BANDO);
			
			if(datiBando!=null)
			{
				contributoPartecipazione=datiBando.getContributoPartecipazione();
				tipologiaVersamento=datiBando.getEstremiPagamento();
			}
			
			if(listaDoc.size()==0)
			{
				if(contributoPartecipazione!=null && contributoPartecipazione.equals("1"))
					this.setVisualizzaPanelVersamenti(true);
				else
					this.setVisualizzaPanelVersamenti(false);
					
				this.setVisualizzaPanelDocumenti(false);
			}
			else
			{
				this.setVisualizzaPanelVersamenti(false);
				
				this.setVisualizzaPanelDocumenti(true);
				listaDoc.add(JSFUtility.getPropertyMessage("titoliStudioBean.copia.doc.riconoscimento", lingua));
//				listaDoc.add("copia del documento di riconoscimento in corso di validit�.");
			}	
			
			boolean documentiOrVersamenti=false;
			
			if(visualizzaPanelDocumenti)
			{
				//se sono previsti documenti
				
				mostraPanelBancario=false;
				mostraPanelPostale=false;
				mostraListaPagamenti=false;
				
				visualizzaDichiarazione=false;
				
				documentiOrVersamenti=true;
			}
			else if(visualizzaPanelVersamenti)
			{
				//se sono previsti solo versamenti
				
				if(tipologiaVersamento!=null)
				{
					//se � nota la tipologia del pagamento
					
					if(tipologiaVersamento.toUpperCase().equals("BANCARIO"))
					{
						mostraPanelBancario=true;
						mostraPanelPostale=false;
						mostraListaPagamenti=false;
					}
					else if(tipologiaVersamento.toUpperCase().equals("POSTALE"))
					{
						mostraPanelBancario=false;
						mostraPanelPostale=true;
						mostraListaPagamenti=false;
					}
					else if(tipologiaVersamento.toUpperCase().equals("BANCARIO/POSTALE"))
					{
						mostraListaPagamenti=true;
						mostraPanelBancario=false;
						mostraPanelPostale=false;
					}
					
					visualizzaDichiarazione=false;
					
					documentiOrVersamenti=true;
				}
			}
			
			if(!documentiOrVersamenti)
			{
				//se non � previsto nessun versamento e nessun documento da inviare in modalita cartacea
				
				mostraPanelBancario=false;
				mostraPanelPostale=false;
				mostraListaPagamenti=false;
				
				visualizzaPanelDocumenti=false;
				
				visualizzaDichiarazione=true;
			}
			
			for(int i=0; i<listaDoc.size(); i++)
			{
               if(i == (listaDoc.size()-1))
               {
            	   elencoDoc += listaDoc.get(i);
               }
               else
               {
            	   elencoDoc += listaDoc.get(i) + '|';
               }
			}

			
			//elencoDoc=elencoDoc+listaDoc.toString().substring(1, listaDoc.toString().lastIndexOf("]"));
			elencoDocSize = elencoDoc.length();
		}
		
		
		public boolean controllaSecondaLaurea(){
			
			if (this.idSecondaLaurea!= null && this.idSecondaLaurea.equals(descPrimaLaurea)) 
			{
				HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
				String lingua= (String)session.getAttribute("linguaScelta"); 
				
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.laureasec.div.laureaprin", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La laurea selezionata in 'Seconda laurea in farmacia o CTF ' non pu� essere uguale alla laurea principale");
				JSFUtility.scrollTo("form:msgs");
				return false;
			}
			return true;
		}
		
		public boolean controllaCampi(){
			
			
			
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			// controlli su tutti i panel
			
			// controlli su seconda laurea
			if(
					
					!((this.descUniSecondaLaurea==null||this.descUniSecondaLaurea.equalsIgnoreCase(""))&&
					(this.luogoSecondaLaurea==null||this.luogoSecondaLaurea.equalsIgnoreCase(""))&&
					(this.idSecondaLaurea==null||this.idSecondaLaurea.equalsIgnoreCase(""))&&
					this.dataSecondaLaurea==null&&
					(this.nazioneSecondaLaurea==null||this.nazioneSecondaLaurea.equalsIgnoreCase(""))&&
					(this.flagEsteroSecondaLaurea==null||this.flagEsteroSecondaLaurea.equalsIgnoreCase("")))
					&&
				    !(!this.descUniSecondaLaurea.equalsIgnoreCase("")&& this.descUniSecondaLaurea!=null &&
					!this.luogoSecondaLaurea.equalsIgnoreCase("")&& this.luogoSecondaLaurea!= null &&
					this.idSecondaLaurea!=null && !this.idSecondaLaurea.equalsIgnoreCase("") &&
					this.dataSecondaLaurea!=null&& 
					!this.nazioneSecondaLaurea.equalsIgnoreCase("")&& this.nazioneSecondaLaurea != null &&
					!this.flagEsteroSecondaLaurea.equalsIgnoreCase("") && this.flagEsteroSecondaLaurea != null)
					
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.campi.seconda.laurea", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Seconda laurea'");
				JSFUtility.scrollTo("form:msgs");
				return false;
			}
			
			if(this.getDataSecondaLaurea()!=null) {
				
					if(validaData(this.getDataSecondaLaurea(),this.getDataNascitaUtente()))
				
					{
						JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.datanascita.min.datalaurea", lingua));
//						JSFUtility.addWarningMessage("Attenzione","La data di nascita utente deve essere antecedente la data conseguimento laurea");
						JSFUtility.scrollTo("form:msgs");
						return false;
					}
					
					if(validaData_2(dataScadenzaBando,this.getDataSecondaLaurea()))
						
					{
						JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.datalaurea.succ.datascadBando", lingua));
//						JSFUtility.addWarningMessage("Attenzione","La data di conseguimento laurea utente non pu� essere successiva alla data di scadenza del bando");
						JSFUtility.scrollTo("form:msgs");
						return false;
					}	
			}
			
			
			// controlli su seconda laurea bis
			if(
					
					!((this.idAltraLaureaBis==null||this.idAltraLaureaBis.equalsIgnoreCase(""))&&
					(this.descUniSecondaLaureaBis==null||this.descUniSecondaLaureaBis.equalsIgnoreCase(""))&&
					(this.luogoSecondaLaureaBis==null||this.luogoSecondaLaureaBis.equalsIgnoreCase(""))&&
					this.dataSecondaLaureaBis==null&&
					(this.nazioneSecondaLaureaBis==null||this.nazioneSecondaLaureaBis.equalsIgnoreCase(""))&&
					(this.flagEsteroSecondaLaureaBis==null||this.flagEsteroSecondaLaureaBis.equalsIgnoreCase("")))

					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.bis.seconda.laurea.pulsante", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'bis Seconda laurea' e premere il pulsante 'Aggiungi Altra Laurea in elenco' ");
				JSFUtility.scrollTo("form:msgs");
				return false;
			}
			
			// controlli su specializzazioni
			if(
					
					!((this.denominazioneSpec==null||this.denominazioneSpec.equalsIgnoreCase(""))&&
					(this.descrFacoltaSpec==null||this.descrFacoltaSpec.equalsIgnoreCase(""))&&
					(this.descrUniversitaSpec==null||this.descrUniversitaSpec.equalsIgnoreCase(""))&&
					(this.luogoSpec==null||this.luogoSpec.equalsIgnoreCase(""))&&
					(this.nazioneSpec==null||this.nazioneSpec.equalsIgnoreCase(""))&&
					(this.durataSpec==null||this.durataSpec.equalsIgnoreCase(""))&&
					(this.flagEsteroSpec==null||this.flagEsteroSpec.equalsIgnoreCase("")))
					
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.specializzazioni.pulsante", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Specializzazioni' e premere il pulsante 'Aggiungi Specializzazione in elenco'");
				JSFUtility.scrollTo("form:msgs");
				return false;
			}
			
			// controlli su borse di studio
			if(

					!((this.denominazioneBorsa==null||this.denominazioneBorsa.equalsIgnoreCase(""))&&
					(this.descrFacoltaBorsa==null||this.descrFacoltaBorsa.equalsIgnoreCase(""))&&
					(this.descrUniversitaBorsa==null||this.descrUniversitaBorsa.equalsIgnoreCase(""))&&					
					(this.luogoBorsa==null||this.luogoBorsa.equalsIgnoreCase(""))&&
					(this.nazioneBorsa==null||this.nazioneBorsa.equalsIgnoreCase(""))&&
					this.dataInizioBorsa==null&&
					this.dataFineBorsa==null&&
					(this.flagEsteroBorsa==null||this.flagEsteroBorsa.equalsIgnoreCase("")))
					
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.borse.studio.pulsante", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Borse di studio' e premere il pulsante 'Aggiungi Borsa di studio in elenco'");
				JSFUtility.scrollTo("form:msgs");
				return false;
			}
			
			// controlli su dottorati
			if(

					!((this.denominazioneDottorato==null||this.denominazioneDottorato.equalsIgnoreCase(""))&&
					(this.descrFacoltaDottorato==null||this.descrFacoltaDottorato.equalsIgnoreCase(""))&&
					(this.descrUniversitaDottorato==null||this.descrUniversitaDottorato.equalsIgnoreCase(""))&&
					(this.luogoDottorato==null||this.luogoDottorato.equalsIgnoreCase(""))&&
					(this.nazioneDottorato==null||this.nazioneDottorato.equalsIgnoreCase(""))&&
					this.dataInizioDottorato==null&&
					this.dataFineDottorato==null&&
					(this.flagEsteroDottorato==null||this.flagEsteroDottorato.equalsIgnoreCase("")))

					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dottorati.pulsante", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Dottorati' e premere il pulsante 'Aggiungi Dottorato in elenco'");
				JSFUtility.scrollTo("form:msgs");
				return false;
			}
			
			// controlli su altri titoli
			if(

					!((this.descAltroTitolo==null||this.descAltroTitolo.equalsIgnoreCase(""))&&
					(this.durataAltroTitolo==null||this.durataAltroTitolo.equalsIgnoreCase(""))&&
					(this.rilascioAltroTitolo==null||this.rilascioAltroTitolo.equalsIgnoreCase(""))&&
					this.dataRilascioAltroTitolo==null&&
					(this.esameFinaleAltroTitolo==null||this.esameFinaleAltroTitolo.equalsIgnoreCase(""))&&
					(this.noteAltroTitolo==null||this.noteAltroTitolo.equalsIgnoreCase(""))&&
					(this.flagEsteroAltroTitolo==null||this.flagEsteroAltroTitolo.equalsIgnoreCase("")))
				
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.altriTitoli.pulsante", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Altri titoli' e premere il pulsante 'Aggiungi Altro Titolo in elenco'");
				JSFUtility.scrollTo("form:msgs");
				return false;
			}
			
			// controlli su idoneit�
			if(

					!((this.flagIdoneitaSediIdoneita==null||this.flagIdoneitaSediIdoneita.equalsIgnoreCase("false"))&&
					(this.estremiIdoneita==null||this.estremiIdoneita.equalsIgnoreCase(""))&&
					this.dataIdoneita==null)
					&&
				    !(this.flagIdoneitaSediIdoneita!=null && !this.flagIdoneitaSediIdoneita.equalsIgnoreCase("false")&&
					 this.estremiIdoneita!=null && !this.estremiIdoneita.equalsIgnoreCase("")&&
					  this.dataIdoneita!=null)
					
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.idoneita", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Idoneit�'");
				JSFUtility.scrollTo("form:msgs");
				return false;
			}
			
			if(this.getDataIdoneita()!=null){ 
				
				if(validaData(this.getDataIdoneita(),dataNascitaUtente))
				
				{
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataProv.min.dataNascita", lingua));
//					JSFUtility.addWarningMessage("Attenzione","La data Atto Provvedimento deve essere successiva alla data di nascita");
					JSFUtility.scrollTo("form:msgs");
					return false;
				}
					
				if(validaData_2(dataScadenzaBando,this.getDataIdoneita()))
					
				{
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataAtto.min.dataScadBando", lingua));
//					JSFUtility.addWarningMessage("Attenzione","La data Atto Provvedimento non pu� essere successiva alla data di scadenza del bando");
					JSFUtility.scrollTo("form:msgs");
					return false;
				}	
			}
			
			
			// controlli su idoneit� nazionale
			if(

					!((this.rifIdoneitaNazionale==null||this.rifIdoneitaNazionale.equalsIgnoreCase(""))&&
					(this.annoIdoneitaNazionale==null||this.annoIdoneitaNazionale.equalsIgnoreCase("")))
					&&
				    !(this.rifIdoneitaNazionale!=null && !this.rifIdoneitaNazionale.equalsIgnoreCase("")&&
							this.annoIdoneitaNazionale!=null && !this.annoIdoneitaNazionale.equalsIgnoreCase(""))
					
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.idoneita.nazionale", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Idoneit� nazionale'");
				return false;
			}
			
			if(!this.annoIdoneitaNazionale.equalsIgnoreCase("")){ 
				
				if(new Integer(this.getAnnoIdoneitaNazionale()) < DateUtil.getYearFromDate(dataNascitaUtente))
				
				{
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.annoIdoneita.min.dataNascita", lingua));
//					JSFUtility.addWarningMessage("Attenzione","L'anno di idoneit� nazionale deve essere successivo alla data di nascita");
					JSFUtility.scrollTo("form:msgs");
					return false;
				}
					
				if(new Integer(this.getAnnoIdoneitaNazionale()) > DateUtil.getYearFromDate(dataPubblicazioneBando))
					
				{
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.annoIdoneita.min.annoPublBando", lingua));
//					JSFUtility.addWarningMessage("Attenzione","L'anno di idoneit� nazionale deve essere antecedente o uguale all'anno di pubblicazione del bando");
					JSFUtility.scrollTo("form:msgs");
					return false;
				}	
			}
			
			// controlli su corsi aggiornamento
			if(

					!((this.titoloCorsoAgg==null||this.titoloCorsoAgg.equalsIgnoreCase(""))&&
					(this.organizzatoCorsoAgg==null||this.organizzatoCorsoAgg.equalsIgnoreCase(""))&&
					this.dataInizioCorsoAgg==null&&
					this.dataFineCorsoAgg==null&&
					(this.totOreCorsoAgg==null||this.totOreCorsoAgg.equalsIgnoreCase(""))&&
					(this.dichiarazioneCorsoAgg==null||this.dichiarazioneCorsoAgg.equalsIgnoreCase(""))&&
					(this.flagEsteroCorsoAgg==null||this.flagEsteroCorsoAgg.equalsIgnoreCase("")))
					
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.corsi.aggiornamento.pulsante", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Corsi di aggiornamento' e premere il pulsante 'Aggiungi Corso di aggiornamento in elenco'");
				JSFUtility.scrollTo("form:msgs");
				return false;
			}
			
			// controlli su corsi pubblicazioni
			if(

					!((this.tipoPubblicazione==null||this.tipoPubblicazione.equalsIgnoreCase(""))&&
					(this.autorePubblicazione==null||this.autorePubblicazione.equalsIgnoreCase(""))&&
					(this.titoloPubblicazione==null||this.titoloPubblicazione.equalsIgnoreCase(""))&&
					(this.editorePubblicazione==null||this.editorePubblicazione.equalsIgnoreCase(""))&&
					(this.codIsbn==null||this.codIsbn.equalsIgnoreCase(""))&&
					this.dataPubblicazione==null)
				
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.pubblicazioni.pulsante", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Pubblicazioni' e premere il pulsante 'Aggiungi Pubblicazione in elenco'");
				JSFUtility.scrollTo("form:msgs");
				return false;
			}
			
			return true;
			
		}

		public void aggiungiAltraLaurea(){
				
			try {
				
					System.out.println("aggiungiAltraLaurea");					
					listaAltreLaureeBis = aggiungiLaurea();						
					RequestContext.getCurrentInstance().update(JSFUtility.getClientId("panelAggLauree"));

			     }
			
				catch (Exception e){
					System.out.println("Eccezione ***************** " +e);
					e.printStackTrace();
				}
		}
		
		
		
		public ArrayList<AltraLaureaBis> aggiungiLaurea(){
			
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			if(
				
				(!((this.idAltraLaureaBis==null||this.idAltraLaureaBis.equalsIgnoreCase(""))&&
						(this.descUniSecondaLaureaBis==null||this.descUniSecondaLaureaBis.equalsIgnoreCase(""))&&
						(this.luogoSecondaLaureaBis==null||this.luogoSecondaLaureaBis.equalsIgnoreCase(""))&&
						this.dataSecondaLaureaBis==null&&
						(this.nazioneSecondaLaureaBis==null||this.nazioneSecondaLaureaBis.equalsIgnoreCase(""))&&
						(this.flagEsteroSecondaLaureaBis==null||this.flagEsteroSecondaLaureaBis.equalsIgnoreCase("")))
				&&
			    !(this.idAltraLaureaBis!=null && !this.idAltraLaureaBis.equalsIgnoreCase("")&&
				this.descUniSecondaLaureaBis!=null && !this.descUniSecondaLaureaBis.equalsIgnoreCase("")&&
				this.luogoSecondaLaureaBis!=null && !this.luogoSecondaLaureaBis.equalsIgnoreCase("")&&
				this.dataSecondaLaureaBis!=null&&
				this.nazioneSecondaLaureaBis!=null && !this.nazioneSecondaLaureaBis.equalsIgnoreCase("")&&
				this.flagEsteroSecondaLaureaBis!=null && !this.flagEsteroSecondaLaureaBis.equalsIgnoreCase("")))
				||
				((this.idAltraLaureaBis==null||this.idAltraLaureaBis.equalsIgnoreCase(""))&&
						(this.descUniSecondaLaureaBis==null||this.descUniSecondaLaureaBis.equalsIgnoreCase(""))&&
						(this.luogoSecondaLaureaBis==null||this.luogoSecondaLaureaBis.equalsIgnoreCase(""))&&
						this.dataSecondaLaureaBis==null&&
						(this.nazioneSecondaLaureaBis==null||this.nazioneSecondaLaureaBis.equalsIgnoreCase(""))&&
						(this.flagEsteroSecondaLaureaBis==null||this.flagEsteroSecondaLaureaBis.equalsIgnoreCase("")))
				
				)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.bis.seconda.laurea", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'bis Seconda laurea'");
				JSFUtility.scrollTo("form:msgs");
			}
			
			else if(validaData(this.getDataSecondaLaureaBis(),this.getDataNascitaUtente())){
				
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataNascita.pre.dataSecLaurea", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data di nascita utente deve essere antecedente la data di conseguimento seconda laurea'");
				JSFUtility.scrollTo("form:msgs");
			}
				
			else if(validaData_2(dataScadenzaBando,this.getDataSecondaLaureaBis())){
				
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataSecLaurea.pre.dataScadBando", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data della seconda laurea non pu� essere successiva alla data di scadenza del bando");
				JSFUtility.scrollTo("form:msgs");
			}
					
			else 
			{
			AltraLaureaBis altraLaureaBis = new AltraLaureaBis();
		
			try {
				BeanUtils.copyProperties(altraLaureaBis,this);
				altraLaureaBis.setDataSecondaLaureaBisStringa(StringUtil.dateToStringDDMMYYYY(this.getDataSecondaLaureaBis()));
				//se tedesco prendi il valore della desc in tedesco e settalo nell' ogetto altralaureab�s
			
				if(lingua.equalsIgnoreCase("de")){
					String combo = altraLaureaBis.getIdAltraLaureaBis().replace(" ", "_");
					
					String id = matriceDe.getMatricePropertiesDe(combo).toString();
					altraLaureaBis.setIdAltraLaureaBis(id);
					altraLaureaBis.setFlagEsteroSecondaLaureaBis(matriceDe.getMatricePropertiesDe(altraLaureaBis.getFlagEsteroSecondaLaureaBis().replace(" ", "_")));
					altraLaureaBis.setNazioneSecondaLaureaBis(matriceDe.getMatricePropertiesDe(altraLaureaBis.getNazioneSecondaLaureaBis().replace(" ", "_")));
				}
				listaAltreLaureeBis.add(altraLaureaBis);
				
				this.setIdAltraLaureaBis("");
				this.setDescUniSecondaLaureaBis("");
				this.setLuogoSecondaLaureaBis("");
				this.setDataSecondaLaureaBis(null);
				this.setNazioneSecondaLaureaBis("");
				this.setFlagEsteroSecondaLaureaBis("");
				 
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
		}			 
		
			
			return listaAltreLaureeBis;
		}
		
		
		public void eliminaAltraLaurea(){
			
			for(int i=0;i<listaAltreLaureeBis.size();i++){
				if(altraLaureaBisSelezionata.getDataSecondaLaureaBis()==listaAltreLaureeBis.get(i).getDataSecondaLaureaBis() &
				   altraLaureaBisSelezionata.getDescUniSecondaLaureaBis()==listaAltreLaureeBis.get(i).getDescUniSecondaLaureaBis() &
				   altraLaureaBisSelezionata.getIdAltraLaureaBis()==listaAltreLaureeBis.get(i).getIdAltraLaureaBis() &
				   altraLaureaBisSelezionata.getLuogoSecondaLaureaBis()==listaAltreLaureeBis.get(i).getLuogoSecondaLaureaBis() &
				   altraLaureaBisSelezionata.getNazioneSecondaLaureaBis()==listaAltreLaureeBis.get(i).getNazioneSecondaLaureaBis() &
				   altraLaureaBisSelezionata.getFlagEsteroSecondaLaureaBis()==listaAltreLaureeBis.get(i).getFlagEsteroSecondaLaureaBis())
					    {
						listaAltreLaureeBis.remove(i);
						}
				}
			
			}
		
		
		
		
		public void aggiungiAltraSpecializzazione(){
			
			try {
				
				System.out.println("aggiungiAltraSpecializzazione");
				listaSpecializzazioni = aggiungiSpecializzazione();				
				RequestContext.getCurrentInstance().update(JSFUtility.getClientId("panelAggSpecializzazioni"));
			}
			
				catch (Exception e){
					System.out.println("Eccezione ***************** " +e);
					e.printStackTrace();
				}
		}
		
		
		public ArrayList<Specializzazione> aggiungiSpecializzazione(){
						
			if(
					
					(!((this.denominazioneSpec==null||this.denominazioneSpec.equalsIgnoreCase(""))&&
							(this.descrFacoltaSpec==null||this.descrFacoltaSpec.equalsIgnoreCase(""))&&
							(this.descrUniversitaSpec==null||this.descrUniversitaSpec.equalsIgnoreCase(""))&&
							(this.luogoSpec==null||this.luogoSpec.equalsIgnoreCase(""))&&
							(this.nazioneSpec==null||this.nazioneSpec.equalsIgnoreCase(""))&&
							(this.durataSpec==null||this.durataSpec.equalsIgnoreCase(""))&&
							(this.flagEsteroSpec==null||this.flagEsteroSpec.equalsIgnoreCase("")))
					&&
				    !(this.denominazioneSpec!=null && !this.denominazioneSpec.equalsIgnoreCase("")&&
							this.descrFacoltaSpec!=null && !this.descrFacoltaSpec.equalsIgnoreCase("")&&
							this.descrUniversitaSpec!=null && !this.descrUniversitaSpec.equalsIgnoreCase("")&&
							this.luogoSpec!=null && !this.luogoSpec.equalsIgnoreCase("")&&
							this.nazioneSpec!=null && !this.nazioneSpec.equalsIgnoreCase("")&&
							this.durataSpec!=null && !this.durataSpec.equalsIgnoreCase("")&&
							this.flagEsteroSpec!=null && !this.flagEsteroSpec.equalsIgnoreCase("")))
	                ||
	                ((this.denominazioneSpec==null||this.denominazioneSpec.equalsIgnoreCase(""))&&
	    					(this.descrFacoltaSpec==null||this.descrFacoltaSpec.equalsIgnoreCase(""))&&
	    					(this.descrUniversitaSpec==null||this.descrUniversitaSpec.equalsIgnoreCase(""))&&
	    					(this.luogoSpec==null||this.luogoSpec.equalsIgnoreCase(""))&&
	    					(this.nazioneSpec==null||this.nazioneSpec.equalsIgnoreCase(""))&&
	    					(this.durataSpec==null||this.durataSpec.equalsIgnoreCase(""))&&
	    					(this.flagEsteroSpec==null||this.flagEsteroSpec.equalsIgnoreCase("")))
					
					)
			{
				HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
				String lingua= (String)session.getAttribute("linguaScelta");
				
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.specializzazioni", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Specializzazioni'");
				JSFUtility.scrollTo("form:msgs");
			}
			
			else {
				
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
				
			Specializzazione specializzazione = new Specializzazione();
			try {
				BeanUtils.copyProperties(specializzazione,this);
				
				if(lingua.equalsIgnoreCase("de")){
				
					specializzazione.setNazioneSpec(matriceDe.getMatricePropertiesDe(specializzazione.getNazioneSpec().replace(" ", "_")));
					specializzazione.setFlagEsteroSpec(matriceDe.getMatricePropertiesDe(specializzazione.getFlagEsteroSpec().replace(" ", "_")));
				}
				
				listaSpecializzazioni.add(specializzazione);
				
				this.setDenominazioneSpec("");
				this.setDescrFacoltaSpec("");
				this.setDescrUniversitaSpec("");
				this.setLuogoSpec("");
				this.setNazioneSpec("");
				this.setDurataSpec("");
				this.setFlagEsteroSpec("");
				 
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}			 
		

			return listaSpecializzazioni;
		}
		
		
		public void eliminaSpecializzazione(){
			
			for(int i=0;i<listaSpecializzazioni.size();i++){
				if(specializzazioneSelezionata.getDenominazioneSpec()==listaSpecializzazioni.get(i).getDenominazioneSpec() &
				   specializzazioneSelezionata.getDurataSpec()==listaSpecializzazioni.get(i).getDurataSpec() &
				   specializzazioneSelezionata.getDescrFacoltaSpec()==listaSpecializzazioni.get(i).getDescrFacoltaSpec() &
				   specializzazioneSelezionata.getDescrUniversitaSpec()==listaSpecializzazioni.get(i).getDescrUniversitaSpec() &
				   specializzazioneSelezionata.getLuogoSpec()==listaSpecializzazioni.get(i).getLuogoSpec() &
				   specializzazioneSelezionata.getNazioneSpec()==listaSpecializzazioni.get(i).getNazioneSpec() &
				   specializzazioneSelezionata.getFlagEsteroSpec()==listaSpecializzazioni.get(i).getFlagEsteroSpec())
					    {
					listaSpecializzazioni.remove(i);
						}
				}
			
			}
		
		
		
		
		public void aggiungiAltraBorsaStudio(){
			
			try {
				
				System.out.println("aggiungiAltraBorsaStudio");				 
			    listaBorseStudio = aggiungiBorsaStudio();
				RequestContext.getCurrentInstance().update(JSFUtility.getClientId("panelAggBorse"));
				
			}
			
				catch (Exception e){
					System.out.println("Eccezione ***************** " +e);
					e.printStackTrace();
				}
		}
		
		
		public ArrayList<BorsaStudio> aggiungiBorsaStudio(){
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			if(
					
					(!((this.denominazioneBorsa==null||this.denominazioneBorsa.equalsIgnoreCase(""))&&
							(this.descrFacoltaBorsa==null||this.descrFacoltaBorsa.equalsIgnoreCase(""))&&
							(this.descrUniversitaBorsa==null||this.descrUniversitaBorsa.equalsIgnoreCase(""))&&					
							(this.luogoBorsa==null||this.luogoBorsa.equalsIgnoreCase(""))&&
							(this.nazioneBorsa==null||this.nazioneBorsa.equalsIgnoreCase(""))&&
							this.dataInizioBorsa==null&&
							this.dataFineBorsa==null&&
							(this.flagEsteroBorsa==null||this.flagEsteroBorsa.equalsIgnoreCase("")))
					&&
				    !(this.denominazioneBorsa!= null && !this.denominazioneBorsa.equalsIgnoreCase("")&&
							this.descrFacoltaBorsa!=null && !this.descrFacoltaBorsa.equalsIgnoreCase("")&&
							this.descrUniversitaBorsa!=null && !this.descrUniversitaBorsa.equalsIgnoreCase("")&&					
							this.luogoBorsa!=null && !this.luogoBorsa.equalsIgnoreCase("")&&
							this.nazioneBorsa!=null && !this.nazioneBorsa.equalsIgnoreCase("")&&
							this.dataInizioBorsa!=null&&
							this.dataFineBorsa!=null&&
							this.flagEsteroBorsa!=null && !this.flagEsteroBorsa.equalsIgnoreCase("")))
					||
					((this.denominazioneBorsa==null||this.denominazioneBorsa.equalsIgnoreCase(""))&&
							(this.descrFacoltaBorsa==null||this.descrFacoltaBorsa.equalsIgnoreCase(""))&&
							(this.descrUniversitaBorsa==null||this.descrUniversitaBorsa.equalsIgnoreCase(""))&&					
							(this.luogoBorsa==null||this.luogoBorsa.equalsIgnoreCase(""))&&
							(this.nazioneBorsa==null||this.nazioneBorsa.equalsIgnoreCase(""))&&
							this.dataInizioBorsa==null&&
							this.dataFineBorsa==null&&
							(this.flagEsteroBorsa==null||this.flagEsteroBorsa.equalsIgnoreCase("")))
					
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.borse.studio", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Borse di studio'");
				JSFUtility.scrollTo("form:msgs");
			}
			
			else if(validaData(this.getDataFineBorsa(),this.getDataInizioBorsa())){
				
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataInBorsa.pre.dataFineBorsa", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data inizio borsa di studio deve essere antecedente la data fine borsa di studio");
				JSFUtility.scrollTo("form:msgs");
			}
				
			else if(validaData_2(dataScadenzaBando,this.getDataFineBorsa())){
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataBorsa.pre.dataScadBando", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data della  borsa di studio non pu� essere successiva alla data di scadenza del bando");
				JSFUtility.scrollTo("form:msgs");
			}
			else if((validaData(this.getDataInizioBorsa(),this.getDataNascitaUtente()))||validaData(this.getDataFineBorsa(),this.getDataNascitaUtente())){
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dateBorsa.post.dataNascita", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Le date di inizio e fine  borsa di studio devono essere successive  alla data di nascita utente");
				JSFUtility.scrollTo("form:msgs");
			}
			else {
			
			BorsaStudio borsaStudio = new BorsaStudio();
			try {
				BeanUtils.copyProperties(borsaStudio,this);
				
				if(lingua.equalsIgnoreCase("de")){
					borsaStudio.setNazioneBorsa(matriceDe.getMatricePropertiesDe(borsaStudio.getNazioneBorsa().replace(" ", "_")));
					borsaStudio.setFlagEsteroBorsa(matriceDe.getMatricePropertiesDe(borsaStudio.getFlagEsteroBorsa().replace(" ", "_")));
				}
				
				borsaStudio.setDataFineBorsaStringa(StringUtil.dateToStringDDMMYYYY(this.getDataFineBorsa()));
				borsaStudio.setDataInizioBorsaStringa(StringUtil.dateToStringDDMMYYYY(this.getDataInizioBorsa()));
				listaBorseStudio.add(borsaStudio);
				
				this.setDenominazioneBorsa("");
				this.setDescrFacoltaBorsa("");
				this.setDescrUniversitaBorsa("");
				this.setLuogoBorsa("");
				this.setNazioneBorsa("");
				this.setDataInizioBorsa(null);
				this.setDataFineBorsa(null);
				this.setFlagEsteroBorsa("");
				 
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			
		}
			
			return listaBorseStudio;
		}
		
		
		
		public void eliminaBorsaStudio(){
			
			for(int i=0;i<listaBorseStudio.size();i++){
				if(borsaStudioSelezionata.getDataFineBorsa()==listaBorseStudio.get(i).getDataFineBorsa() &
				   borsaStudioSelezionata.getDataInizioBorsa()==listaBorseStudio.get(i).getDataInizioBorsa() &
				   borsaStudioSelezionata.getDenominazioneBorsa()==listaBorseStudio.get(i).getDenominazioneBorsa() &
				   borsaStudioSelezionata.getDescrFacoltaBorsa()==listaBorseStudio.get(i).getDescrFacoltaBorsa() &
				   borsaStudioSelezionata.getDescrUniversitaBorsa()==listaBorseStudio.get(i).getDescrUniversitaBorsa() &
				   borsaStudioSelezionata.getLuogoBorsa()==listaBorseStudio.get(i).getLuogoBorsa() &
				   borsaStudioSelezionata.getNazioneBorsa()==listaBorseStudio.get(i).getNazioneBorsa() &
				   borsaStudioSelezionata.getFlagEsteroBorsa()==listaBorseStudio.get(i).getFlagEsteroBorsa())
					    {
					listaBorseStudio.remove(i);
						}
				}
			
			}
		
		
		
		public void aggiungiAltroDottorato(){
			
			try {
				
				System.out.println("aggiungiAltroCorsoAgg");				
				listaDottorati = aggiungiDottorato();
				RequestContext.getCurrentInstance().update(JSFUtility.getClientId("panelAggDottorati"));
				
			   }
			
				catch (Exception e){
					System.out.println("Eccezione ***************** " +e);
					e.printStackTrace();
				}
		}
		
		
		public ArrayList<Dottorato> aggiungiDottorato(){
			
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			if(
					
					(!((this.denominazioneDottorato==null||this.denominazioneDottorato.equalsIgnoreCase(""))&&
							(this.descrFacoltaDottorato==null||this.descrFacoltaDottorato.equalsIgnoreCase(""))&&
							(this.descrUniversitaDottorato==null||this.descrUniversitaDottorato.equalsIgnoreCase(""))&&
							(this.luogoDottorato==null||this.luogoDottorato.equalsIgnoreCase(""))&&
							(this.nazioneDottorato==null||this.nazioneDottorato.equalsIgnoreCase(""))&&
							this.dataInizioDottorato==null&&
							this.dataFineDottorato==null&&
							(this.flagEsteroDottorato==null||this.flagEsteroDottorato.equalsIgnoreCase("")))
					
					&&
				    !(this.denominazioneDottorato!=null && !this.denominazioneDottorato.equalsIgnoreCase("")&&
							this.descrFacoltaDottorato!=null && !this.descrFacoltaDottorato.equalsIgnoreCase("")&&
							this.descrUniversitaDottorato!=null && !this.descrUniversitaDottorato.equalsIgnoreCase("")&&
							this.luogoDottorato!=null && !this.luogoDottorato.equalsIgnoreCase("")&&
							this.nazioneDottorato!=null && !this.nazioneDottorato.equalsIgnoreCase("")&&
							this.dataInizioDottorato!=null&&
							this.dataFineDottorato!=null&&
							this.flagEsteroDottorato!=null && !this.flagEsteroDottorato.equalsIgnoreCase("")))
					||
					((this.denominazioneDottorato==null||this.denominazioneDottorato.equalsIgnoreCase(""))&&
							(this.descrFacoltaDottorato==null||this.descrFacoltaDottorato.equalsIgnoreCase(""))&&
							(this.descrUniversitaDottorato==null||this.descrUniversitaDottorato.equalsIgnoreCase(""))&&
							(this.luogoDottorato==null||this.luogoDottorato.equalsIgnoreCase(""))&&
							(this.nazioneDottorato==null||this.nazioneDottorato.equalsIgnoreCase(""))&&
							this.dataInizioDottorato==null&&
							this.dataFineDottorato==null&&
							(this.flagEsteroDottorato==null||this.flagEsteroDottorato.equalsIgnoreCase("")))
					
					
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dottorati", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Dottorati'");
				JSFUtility.scrollTo("form:msgs");
			}
			
			else if(validaData(this.getDataFineDottorato(),this.getDataInizioDottorato())){
				
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataInDottorato.pre.dataFineDottorato", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data inizio dottorato deve essere antecedente la data fine dottorato.");
				JSFUtility.scrollTo("form:msgs");
			}
				
			else if(validaData_2(dataScadenzaBando,this.getDataFineDottorato())){
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataDottorato.pre.dataScadBando", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data del dottorato non pu� essere successiva alla data di scadenza del bando");
				JSFUtility.scrollTo("form:msgs");
			}
			else if((validaData(this.getDataInizioDottorato(),this.getDataNascitaUtente()))||validaData(this.getDataFineDottorato(),this.getDataNascitaUtente())){
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dateDottorato.post.dataNascita", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Le date di inizio e fine  dottorato devono essere successive  alla data di nascita utente");
				JSFUtility.scrollTo("form:msgs");
			}
			else {
			
			Dottorato dottorato = new Dottorato();
			try {
				BeanUtils.copyProperties(dottorato,this);
				if(lingua.equalsIgnoreCase("de")){
					dottorato.setNazioneDottorato(matriceDe.getMatricePropertiesDe(dottorato.getNazioneDottorato().replace(" ", "_")));
					dottorato.setFlagEsteroDottorato(matriceDe.getMatricePropertiesDe(dottorato.getFlagEsteroDottorato().replace(" ", "_")));
				}
				dottorato.setDataInizioDottoratoStringa(StringUtil.dateToStringDDMMYYYY(this.getDataInizioDottorato()));
				dottorato.setDataFineDottoratoStringa(StringUtil.dateToStringDDMMYYYY(this.getDataFineDottorato()));
				listaDottorati.add(dottorato);
				
				this.setDenominazioneDottorato("");
				this.setDescrFacoltaDottorato("");
				this.setDescrUniversitaDottorato("");
				this.setLuogoDottorato("");
				this.setNazioneDottorato("");
				this.setDataInizioDottorato(null);
				this.setDataFineDottorato(null);
				this.setFlagEsteroDottorato("");
				 
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
				
		}
			
			return listaDottorati;
		}
		
		
		
		public void eliminaDottorato(){
			
			for(int i=0;i<listaDottorati.size();i++){
				if(dottoratoSelezionato.getDataFineDottorato()==listaDottorati.get(i).getDataFineDottorato() &
				   dottoratoSelezionato.getDataInizioDottorato()==listaDottorati.get(i).getDataInizioDottorato() &
				   dottoratoSelezionato.getDenominazioneDottorato()==listaDottorati.get(i).getDenominazioneDottorato() &
				   dottoratoSelezionato.getDescrFacoltaDottorato()==listaDottorati.get(i).getDescrFacoltaDottorato() &
				   dottoratoSelezionato.getDescrUniversitaDottorato()==listaDottorati.get(i).getDescrUniversitaDottorato()&
				   dottoratoSelezionato.getLuogoDottorato()==listaDottorati.get(i).getLuogoDottorato() &
				   dottoratoSelezionato.getNazioneDottorato()==listaDottorati.get(i).getNazioneDottorato() &
				   dottoratoSelezionato.getFlagEsteroDottorato()==listaDottorati.get(i).getFlagEsteroDottorato())	
					    {
					listaDottorati.remove(i);
						}
				}
			
			}
		
		
		
		public void aggiungiAltroTitolo(){
			
			try {
				
				System.out.println("aggiungiAltroTitolo");
				listaAltriTitoli = aggiungiTitolo();			
				RequestContext.getCurrentInstance().update(JSFUtility.getClientId("panelAggAltriTitoli"));
				
			}
			
				catch (Exception e){
					System.out.println("Eccezione ***************** " +e);
					e.printStackTrace();
				}
		}
		
		
		public ArrayList<AltroTitolo> aggiungiTitolo(){
			
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			if(					
					
					(!((this.descAltroTitolo==null||this.descAltroTitolo.equalsIgnoreCase(""))&&
							(this.durataAltroTitolo==null||this.durataAltroTitolo.equalsIgnoreCase(""))&&
							(this.rilascioAltroTitolo==null||this.rilascioAltroTitolo.equalsIgnoreCase(""))&&
							this.dataRilascioAltroTitolo==null&&
							(this.esameFinaleAltroTitolo==null||this.esameFinaleAltroTitolo.equalsIgnoreCase(""))&&
							(this.flagEsteroAltroTitolo==null||this.flagEsteroAltroTitolo.equalsIgnoreCase("")))
					&&
				    !(this.descAltroTitolo!=null && !this.descAltroTitolo.equalsIgnoreCase("")&&
							this.durataAltroTitolo!=null && !this.durataAltroTitolo.equalsIgnoreCase("")&&
							this.rilascioAltroTitolo!=null && !this.rilascioAltroTitolo.equalsIgnoreCase("")&&
							this.dataRilascioAltroTitolo!=null&&
							this.esameFinaleAltroTitolo!=null && !this.esameFinaleAltroTitolo.equalsIgnoreCase("")&&
							this.flagEsteroAltroTitolo!=null && !this.flagEsteroAltroTitolo.equalsIgnoreCase("")))
					||
					((this.descAltroTitolo==null||this.descAltroTitolo.equalsIgnoreCase(""))&&
							(this.durataAltroTitolo==null||this.durataAltroTitolo.equalsIgnoreCase(""))&&
							(this.rilascioAltroTitolo==null||this.rilascioAltroTitolo.equalsIgnoreCase(""))&&
							this.dataRilascioAltroTitolo==null&&
							(this.esameFinaleAltroTitolo==null||this.esameFinaleAltroTitolo.equalsIgnoreCase(""))&&
							(this.flagEsteroAltroTitolo==null||this.flagEsteroAltroTitolo.equalsIgnoreCase("")))
					
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.altriTitoli", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Altri titoli' ad eccezione del campo 'Note'");
				JSFUtility.scrollTo("form:msgs");
			}
			
			else if(validaData(this.getDataRilascioAltroTitolo(),this.getDataNascitaUtente())){
				
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataCons.post.dataNascita", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data Conseguimento Altro titolo deve essere successiva alla data di nascita");
				JSFUtility.scrollTo("form:msgs");
			}
			else if(validaData_2(dataScadenzaBando,this.getDataRilascioAltroTitolo())){
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataTitolo.pre.dataScadBando", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data del titolo non pu� essere successiva alla data di scadenza del bando");
				JSFUtility.scrollTo("form:msgs");
			}
			else {
				
			AltroTitolo altroTitolo = new AltroTitolo();
			try {
				BeanUtils.copyProperties(altroTitolo,this);
				if(lingua.equalsIgnoreCase("de")){
					String combo = altroTitolo.getEsameFinaleAltroTitolo();
					combo.replace(" ", "_");
					String id = matriceDe.getMatricePropertiesDe(combo).toString();
					altroTitolo.setEsameFinaleAltroTitolo(matriceDe.getMatricePropertiesDe(altroTitolo.getEsameFinaleAltroTitolo().replace(" ", "_")));
					altroTitolo.setFlagEsteroAltroTitolo(matriceDe.getMatricePropertiesDe(altroTitolo.getFlagEsteroAltroTitolo().replace(" ", "_")));
				}
				altroTitolo.setDataRilascioAltroTitoloStringa(StringUtil.dateToStringDDMMYYYY(this.getDataRilascioAltroTitolo()));
				listaAltriTitoli.add(altroTitolo);
				
				this.setDescAltroTitolo("");
				this.setDurataAltroTitolo("");
				this.setRilascioAltroTitolo("");
				this.setDataRilascioAltroTitolo(null);
				this.setEsameFinaleAltroTitolo("");
				this.setNoteAltroTitolo("");
				this.setFlagEsteroAltroTitolo("");
				 
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
					 
		}
			
			return listaAltriTitoli;
		}
		
		
		
		public void eliminaAltroTitolo(){
			
			for(int i=0;i<listaAltriTitoli.size();i++){
				if(altroTitoloSelezionato.getDataRilascioAltroTitolo()==listaAltriTitoli.get(i).getDataRilascioAltroTitolo() &
				   altroTitoloSelezionato.getDurataAltroTitolo()==listaAltriTitoli.get(i).getDurataAltroTitolo() &
			       altroTitoloSelezionato.getDescAltroTitolo()==listaAltriTitoli.get(i).getDescAltroTitolo() &
				   altroTitoloSelezionato.getEsameFinaleAltroTitolo()==listaAltriTitoli.get(i).getEsameFinaleAltroTitolo() &
				   altroTitoloSelezionato.getRilascioAltroTitolo()==listaAltriTitoli.get(i).getRilascioAltroTitolo() &
				   altroTitoloSelezionato.getFlagEsteroAltroTitolo()==listaAltriTitoli.get(i).getFlagEsteroAltroTitolo())
					    {
					listaAltriTitoli.remove(i);
						}
				}
			
			}
		

	
		public void aggiungiAltroCorsoAgg(){
			
			try {
							
				System.out.println("aggiungiAltroCorsoAgg");
				listaCorsiAgg = aggiungiCorsoAgg();				
				RequestContext.getCurrentInstance().update(JSFUtility.getClientId("panelAggCorsi"));
				
			}
			
				catch (Exception e){
					System.out.println("Eccezione ***************** " +e);
					e.printStackTrace();
				}
		}
		
		
		public ArrayList<CorsoAgg> aggiungiCorsoAgg(){
			
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			if(

					(!((this.titoloCorsoAgg==null||this.titoloCorsoAgg.equalsIgnoreCase(""))&&
							(this.organizzatoCorsoAgg==null||this.organizzatoCorsoAgg.equalsIgnoreCase(""))&&
							this.dataInizioCorsoAgg==null&&
							this.dataFineCorsoAgg==null&&
							(this.totOreCorsoAgg==null||this.totOreCorsoAgg.equalsIgnoreCase(""))&&
							(this.dichiarazioneCorsoAgg==null||this.dichiarazioneCorsoAgg.equalsIgnoreCase(""))&&
							(this.flagEsteroCorsoAgg==null||this.flagEsteroCorsoAgg.equalsIgnoreCase("")))
					&&
				    !(this.titoloCorsoAgg!=null && !this.titoloCorsoAgg.equalsIgnoreCase("")&&
							this.organizzatoCorsoAgg!=null && !this.organizzatoCorsoAgg.equalsIgnoreCase("")&&
							this.dataInizioCorsoAgg!=null&&
							this.dataFineCorsoAgg!=null&&
							this.totOreCorsoAgg!=null && !this.totOreCorsoAgg.equalsIgnoreCase("")&&
							this.dichiarazioneCorsoAgg!=null && !this.dichiarazioneCorsoAgg.equalsIgnoreCase("")&&
							this.flagEsteroCorsoAgg!=null && !this.flagEsteroCorsoAgg.equalsIgnoreCase("")))
					||
					((this.titoloCorsoAgg==null||this.titoloCorsoAgg.equalsIgnoreCase(""))&&
							(this.organizzatoCorsoAgg==null||this.organizzatoCorsoAgg.equalsIgnoreCase(""))&&
							this.dataInizioCorsoAgg==null&&
							this.dataFineCorsoAgg==null&&
							(this.totOreCorsoAgg==null||this.totOreCorsoAgg.equalsIgnoreCase(""))&&
							(this.dichiarazioneCorsoAgg==null||this.dichiarazioneCorsoAgg.equalsIgnoreCase(""))&&
							(this.flagEsteroCorsoAgg==null||this.flagEsteroCorsoAgg.equalsIgnoreCase("")))
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.corsi.aggiornamento", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Corsi di aggiornamento'");
				JSFUtility.scrollTo("form:msgs");
			}
			
			else if(validaData(this.getDataInizioCorsoAgg(),this.getDataNascitaUtente())){
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataNascita.pre.dataIniCorso", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data di nascita dev'essere antecedente la data di inizio corso");
				JSFUtility.scrollTo("form:msgs");
			}
				
			else if(validaData_2(dataPubblicazioneBando,this.getDataFineCorsoAgg())){
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataFineCorso.post.dataPubBando", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data di fine corso non pu� essere successiva alla data di pubblicazione del bando");
				JSFUtility.scrollTo("form:msgs");
			}
			else if (validaData(dataInizioCorsoAgg,data_corso_appoggio)){
				
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataInCorso.pre.dataValidita", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data di inizio del corso deve essere successiva alla data di validit� indicata sul bando");
				JSFUtility.scrollTo("form:msgs");
			}
			else if (validaData(dataInizioCorsoAgg,dataPrimaLaurea)){
				
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataInCorso.post.dataPrimaLaurea", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data di inizio del corso deve essere successiva alla data di conseguimento Prima Laurea");
				JSFUtility.scrollTo("form:msgs");
			}
			else {
				
					
				CorsoAgg corsoAgg = new CorsoAgg();
				try {
					BeanUtils.copyProperties(corsoAgg,this);
					if(lingua.equalsIgnoreCase("de")){
						corsoAgg.setDichiarazioneCorsoAgg(matriceDe.getMatricePropertiesDe(corsoAgg.getDichiarazioneCorsoAgg().replace(" ", "_")));
						corsoAgg.setFlagEsteroCorsoAgg(matriceDe.getMatricePropertiesDe(corsoAgg.getFlagEsteroCorsoAgg().replace(" ", "_")));
					}
					corsoAgg.setDataInizioCorsoAggStringa(StringUtil.dateToStringDDMMYYYY(this.getDataInizioCorsoAgg()));
					corsoAgg.setDataFineCorsoAggStringa(StringUtil.dateToStringDDMMYYYY(this.getDataFineCorsoAgg()));
					listaCorsiAgg.add(corsoAgg);
					
					this.setTitoloCorsoAgg("");
					this.setOrganizzatoCorsoAgg("");
					this.setDataInizioCorsoAgg(null);
					this.setDataFineCorsoAgg(null);
					this.setTotOreCorsoAgg("");
					this.setDichiarazioneCorsoAgg("");
					this.setFlagEsteroCorsoAgg("");
					 
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				}
		
			return listaCorsiAgg;
		}
		
		
		
		public void eliminaCorsoAgg(){
			
			for(int i=0;i<listaCorsiAgg.size();i++){
				if(corsoAggSelezionato.getDichiarazioneCorsoAgg()==listaCorsiAgg.get(i).getDichiarazioneCorsoAgg() &
				   corsoAggSelezionato.getTotOreCorsoAgg()==listaCorsiAgg.get(i).getTotOreCorsoAgg() &
				   corsoAggSelezionato.getDataInizioCorsoAgg()==listaCorsiAgg.get(i).getDataInizioCorsoAgg() &&
				   corsoAggSelezionato.getDataFineCorsoAgg()==listaCorsiAgg.get(i).getDataFineCorsoAgg() &&
				   corsoAggSelezionato.getOrganizzatoCorsoAgg()==listaCorsiAgg.get(i).getOrganizzatoCorsoAgg() &
				   corsoAggSelezionato.getTitoloCorsoAgg()==listaCorsiAgg.get(i).getTitoloCorsoAgg() &
				   corsoAggSelezionato.getFlagEsteroCorsoAgg()==listaCorsiAgg.get(i).getFlagEsteroCorsoAgg())
					    {
					listaCorsiAgg.remove(i);
						}
				}
			
			}
		
		
		public void aggiungiAltraPubblicazione(){
			
			try {
				
				System.out.println("aggiungiAltraPubblicazione");
				listaPubblicazioni = aggiungiPubblicazione();
				RequestContext.getCurrentInstance().update(JSFUtility.getClientId("panelAggPubblicazioni"));
				
			}
			
				catch (Exception e){
					System.out.println("Eccezione ***************** " +e);
					e.printStackTrace();
				}
		}
		
		
		public ArrayList<Pubblicazione> aggiungiPubblicazione(){
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			if(

					(!((this.tipoPubblicazione==null||this.tipoPubblicazione.equalsIgnoreCase(""))&&
							(this.autorePubblicazione==null||this.autorePubblicazione.equalsIgnoreCase(""))&&
							(this.titoloPubblicazione==null||this.titoloPubblicazione.equalsIgnoreCase(""))&&
							(this.editorePubblicazione==null||this.editorePubblicazione.equalsIgnoreCase(""))&&
							this.dataPubblicazione==null)
					&&
				    !(this.tipoPubblicazione!=null && !this.tipoPubblicazione.equalsIgnoreCase("")&&
					this.autorePubblicazione!=null && !this.autorePubblicazione.equalsIgnoreCase("")&&
					this.titoloPubblicazione!=null && !this.titoloPubblicazione.equalsIgnoreCase("")&&
					this.editorePubblicazione!=null && !this.editorePubblicazione.equalsIgnoreCase("")&&
					this.dataPubblicazione!=null))
					||
					((this.tipoPubblicazione==null||this.tipoPubblicazione.equalsIgnoreCase(""))&&
							(this.autorePubblicazione==null||this.autorePubblicazione.equalsIgnoreCase(""))&&
							(this.titoloPubblicazione==null||this.titoloPubblicazione.equalsIgnoreCase(""))&&
							(this.editorePubblicazione==null||this.editorePubblicazione.equalsIgnoreCase(""))&&
							this.dataPubblicazione==null)
					
					)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.pubblicazione", lingua));
//				JSFUtility.addWarningMessage("Attenzione","E' necessario compilare tutti i campi relativi a 'Pubblicazioni' ad eccezione del campo 'ISSN/ISBN'");
				JSFUtility.scrollTo("form:msgs");
			}
			
			else if(validaData(this.getDataPubblicazione(),this.getDataNascitaUtente())){
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataNascita.pre.dataPubblicazione", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data di nascita utente deve essere antecedente la data di pubblicazione");
				JSFUtility.scrollTo("form:msgs");
			}
			else if(validaData_2(dataPubblicazioneBando, dataPubblicazione)){
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataPubblicazione.pre.dataBando", lingua));
//					JSFUtility.addWarningMessage("Attenzione","La data di pubblicazione non pu� essere successiva alla data di pubblicazione del bando");
					JSFUtility.scrollTo("form:msgs");
			}
			else if(validaData(dataPubblicazione,data_pubb_appoggio)){
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("titoliStudioBean.attenzione.dataPubblicazione.pre.dataValiBando", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La data di pubblicazione deve essere successiva alla data di validit� indicata nel bando");
				JSFUtility.scrollTo("form:msgs");
		}
			else	{
			
			Pubblicazione pubblicazione = new Pubblicazione();
			try {
				BeanUtils.copyProperties(pubblicazione,this);
				if(lingua.equalsIgnoreCase("de")){
					String combo = pubblicazione.getTipoPubblicazione().replace(" ", "_");
					String id = matriceDe.getMatricePropertiesDe(combo).toString();
					pubblicazione.setTipoPubblicazione(matriceDe.getMatricePropertiesDe(pubblicazione.getTipoPubblicazione().replace(" ", "_")));
				}
				pubblicazione.setDataPubblicazioneStringa(StringUtil.dateToStringDDMMYYYY(this.getDataPubblicazione()));
				listaPubblicazioni.add(pubblicazione);
				
				this.setTipoPubblicazione("");
				this.setAutorePubblicazione("");
				this.setTitoloPubblicazione("");
				this.setEditorePubblicazione("");
				this.setCodIsbn("");
				this.setDataPubblicazione(null);
				 
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
		}
			
			return listaPubblicazioni;
		}
		
		
		public void eliminaPubblicazione(){
			
			for(int i=0;i<listaPubblicazioni.size();i++){
				if(pubblicazioneSelezionata.getAutorePubblicazione()==listaPubblicazioni.get(i).getAutorePubblicazione() &
				   pubblicazioneSelezionata.getCodIsbn()==listaPubblicazioni.get(i).getCodIsbn() &
				   pubblicazioneSelezionata.getDataPubblicazione()==listaPubblicazioni.get(i).getDataPubblicazione() &
				   pubblicazioneSelezionata.getEditorePubblicazione()==listaPubblicazioni.get(i).getEditorePubblicazione() &
				   pubblicazioneSelezionata.getTipoPubblicazione()==listaPubblicazioni.get(i).getTipoPubblicazione() &
				   pubblicazioneSelezionata.getTitoloPubblicazione()==listaPubblicazioni.get(i).getTitoloPubblicazione())
					    {
					listaPubblicazioni.remove(i);
						}
				}
			
			}
		
		boolean validaData(Date data, Date dataVerifica)
		{	
			Calendar dataBando = Calendar.getInstance();
			dataBando.setTime(data);
			dataBando.set(Calendar.HOUR_OF_DAY,0);//imposta l'orario a mezzanotte
			
			Calendar dataDaVerificare = Calendar.getInstance();
			dataDaVerificare.setTime(dataVerifica);
			dataDaVerificare.set(Calendar.HOUR_OF_DAY,0);//imposta l'orario a mezzanotte

			if(dataDaVerificare.before(dataBando))
			{
				return false;
			}

			return true;
		}
		
		boolean validaData_2(Date data, Date dataVerifica)
		{	
			Calendar dataBando = Calendar.getInstance();
			dataBando.setTime(data);
			dataBando.set(Calendar.HOUR_OF_DAY,0);//imposta l'orario a mezzanotte
			
			Calendar dataDaVerificare = Calendar.getInstance();
			dataDaVerificare.setTime(dataVerifica);
			dataDaVerificare.set(Calendar.HOUR_OF_DAY,0);//imposta l'orario a mezzanotte
			
			if(dataDaVerificare.before(dataBando) || dataDaVerificare.equals(dataBando))
			{
				return false;
			}
			
			return true;
		}
		
		public boolean init(String idUtente)
		{
			try {
				return titoliStudioAction.loadPaginaInserimento(idUtente,this);
			} catch (GestioneErroriException e) {
				logger.error("TitoliStudioCarrieraBean - init: " + e.getMessage());	
				JSFUtility.redirect("errorPageGenerica.jsf");
				return false;
			}
		}
		
		public boolean updateDAO(String idDomanda)
		{
			try {
				return titoliStudioAction.updateDAO(idDomanda,this);
			} catch (GestioneErroriException e) {
				logger.error("TitoliStudioCarrieraBean - updateDAO: " + e.getMessage());	
				JSFUtility.redirect("errorPageGenerica.jsf");
				return false;
			}
		}
		
		public boolean isVisualizzaPanelVersamenti() {
			return visualizzaPanelVersamenti;
		}


		public void setVisualizzaPanelVersamenti(boolean visualizzaPanelVersamenti) {
			this.visualizzaPanelVersamenti = visualizzaPanelVersamenti;
		}


		public boolean isVisualizzaPanelDocumenti() {
			return visualizzaPanelDocumenti;
		}


		public void setVisualizzaPanelDocumenti(boolean visualizzaPanelDocumenti) {
			this.visualizzaPanelDocumenti = visualizzaPanelDocumenti;
		}

		public String getIdSecondaLaurea() {
			return idSecondaLaurea;
		}


		public String getElencoDoc() {
			return elencoDoc;
		}

		public String getElencoDocText()
		{
			return (elencoDoc.replace('|',',')).replaceAll(",",", ");
		}

		public void setElencoDoc(String elencoDoc) {
			this.elencoDoc = elencoDoc;
		}


		public String getTipoPubblicazione() {
			return tipoPubblicazione;
		}




		public void setTipoPubblicazione(String tipoPubblicazione) {
			this.tipoPubblicazione = tipoPubblicazione;
		}




		public String getAutorePubblicazione() {
			return autorePubblicazione;
		}




		public void setAutorePubblicazione(String autorePubblicazione) {
			this.autorePubblicazione = autorePubblicazione;
		}




		public String getTitoloPubblicazione() {
			return titoloPubblicazione;
		}




		public void setTitoloPubblicazione(String titoloPubblicazione) {
			this.titoloPubblicazione = titoloPubblicazione;
		}




		public String getEditorePubblicazione() {
			return editorePubblicazione;
		}




		public void setEditorePubblicazione(String editorePubblicazione) {
			this.editorePubblicazione = editorePubblicazione;
		}




		public Date getDataPubblicazione() {
			return dataPubblicazione;
		}




		public void setDataPubblicazione(Date dataPubblicazione) {
			this.dataPubblicazione = dataPubblicazione;
		}




		public String getTitoloCorsoAgg() {
			return titoloCorsoAgg;
		}




		public void setTitoloCorsoAgg(String titoloCorsoAgg) {
			this.titoloCorsoAgg = titoloCorsoAgg;
		}




		public String getOrganizzatoCorsoAgg() {
			return organizzatoCorsoAgg;
		}




		public void setOrganizzatoCorsoAgg(String organizzatoCorsoAgg) {
			this.organizzatoCorsoAgg = organizzatoCorsoAgg;
		}


		public Date getDataInizioCorsoAgg() {
			return dataInizioCorsoAgg;
		}


		public void setDataInizioCorsoAgg(Date dataInizioCorsoAgg) {
			this.dataInizioCorsoAgg = dataInizioCorsoAgg;
		}


		public Date getDataFineCorsoAgg() {
			return dataFineCorsoAgg;
		}


		public void setDataFineCorsoAgg(Date dataFineCorsoAgg) {
			this.dataFineCorsoAgg = dataFineCorsoAgg;
		}


		public String getDichiarazioneCorsoAgg() {
			return dichiarazioneCorsoAgg;
		}




		public void setDichiarazioneCorsoAgg(String dichiarazioneCorsoAgg) {
			this.dichiarazioneCorsoAgg = dichiarazioneCorsoAgg;
		}




		public String getFlagIdoneitaSediIdoneita() {
			return flagIdoneitaSediIdoneita;
		}




		public void setFlagIdoneitaSediIdoneita(String flagIdoneitaSediIdoneita) {
			this.flagIdoneitaSediIdoneita = flagIdoneitaSediIdoneita;
		}




		public String getEstremiIdoneita() {
			return estremiIdoneita;
		}




		public void setEstremiIdoneita(String estremiIdoneita) {
			this.estremiIdoneita = estremiIdoneita;
		}




		public String getRifIdoneitaNazionale() {
			return rifIdoneitaNazionale;
		}




		public void setRifIdoneitaNazionale(String rifIdoneitaNazionale) {
			this.rifIdoneitaNazionale = rifIdoneitaNazionale;
		}


		public String getDescAltroTitolo() {
			return descAltroTitolo;
		}




		public void setDescAltroTitolo(String descAltroTitolo) {
			this.descAltroTitolo = descAltroTitolo;
		}


		public String getRilascioAltroTitolo() {
			return rilascioAltroTitolo;
		}




		public void setRilascioAltroTitolo(String rilascioAltroTitolo) {
			this.rilascioAltroTitolo = rilascioAltroTitolo;
		}




		public Date getDataRilascioAltroTitolo() {
			return dataRilascioAltroTitolo;
		}




		public String getDurataAltroTitolo() {
			return durataAltroTitolo;
		}


		public void setDurataAltroTitolo(String durataAltroTitolo) {
			this.durataAltroTitolo = durataAltroTitolo;
		}


		public String getAnnoIdoneitaNazionale() {
			return annoIdoneitaNazionale;
		}


		public void setAnnoIdoneitaNazionale(String annoIdoneitaNazionale) {
			this.annoIdoneitaNazionale = annoIdoneitaNazionale;
		}


		public String getTotOreCorsoAgg() {
			return totOreCorsoAgg;
		}


		public void setTotOreCorsoAgg(String totOreCorsoAgg) {
			this.totOreCorsoAgg = totOreCorsoAgg;
		}


		public void setDataRilascioAltroTitolo(Date dataRilascioAltroTitolo) {
			this.dataRilascioAltroTitolo = dataRilascioAltroTitolo;
		}




		public String getEsameFinaleAltroTitolo() {
			return esameFinaleAltroTitolo;
		}




		public void setEsameFinaleAltroTitolo(String esameFinaleAltroTitolo) {
			this.esameFinaleAltroTitolo = esameFinaleAltroTitolo;
		}


        
		public String getNoteAltroTitolo() {
			return noteAltroTitolo;
		}

		
		
		public void setNoteAltroTitolo(String noteAltroTitolo) {
			this.noteAltroTitolo = noteAltroTitolo;
		}

		
		
		public String getDenominazioneDottorato() {
			return denominazioneDottorato;
		}




		public void setDenominazioneDottorato(String denominazioneDottorato) {
			this.denominazioneDottorato = denominazioneDottorato;
		}




		public String getDescrFacoltaDottorato() {
			return descrFacoltaDottorato;
		}




		public void setDescrFacoltaDottorato(String descrFacoltaDottorato) {
			this.descrFacoltaDottorato = descrFacoltaDottorato;
		}




		public String getDescrUniversitaDottorato() {
			return descrUniversitaDottorato;
		}




		public void setDescrUniversitaDottorato(String descrUniversitaDottorato) {
			this.descrUniversitaDottorato = descrUniversitaDottorato;
		}




		public String getLuogoDottorato() {
			return luogoDottorato;
		}




		public void setLuogoDottorato(String luogoDottorato) {
			this.luogoDottorato = luogoDottorato;
		}




		public String getNazioneDottorato() {
			return nazioneDottorato;
		}




		public void setNazioneDottorato(String nazioneDottorato) {
			this.nazioneDottorato = nazioneDottorato;
		}




		public Date getDataInizioDottorato() {
			return dataInizioDottorato;
		}




		public void setDataInizioDottorato(Date dataInizioDottorato) {
			this.dataInizioDottorato = dataInizioDottorato;
		}




		public Date getDataFineDottorato() {
			return dataFineDottorato;
		}




		public void setDataFineDottorato(Date dataFineDottorato) {
			this.dataFineDottorato = dataFineDottorato;
		}




		public String getDenominazioneBorsa() {
			return denominazioneBorsa;
		}




		public void setDenominazioneBorsa(String denominazioneBorsa) {
			this.denominazioneBorsa = denominazioneBorsa;
		}




		public String getDescrFacoltaBorsa() {
			return descrFacoltaBorsa;
		}




		public void setDescrFacoltaBorsa(String descrFacoltaBorsa) {
			this.descrFacoltaBorsa = descrFacoltaBorsa;
		}




		public String getDescrUniversitaBorsa() {
			return descrUniversitaBorsa;
		}




		public void setDescrUniversitaBorsa(String descrUniversitaBorsa) {
			this.descrUniversitaBorsa = descrUniversitaBorsa;
		}




		public String getLuogoBorsa() {
			return luogoBorsa;
		}




		public void setLuogoBorsa(String luogoBorsa) {
			this.luogoBorsa = luogoBorsa;
		}




		public String getNazioneBorsa() {
			return nazioneBorsa;
		}




		public void setNazioneBorsa(String nazioneBorsa) {
			this.nazioneBorsa = nazioneBorsa;
		}




		public Date getDataInizioBorsa() {
			return dataInizioBorsa;
		}




		public void setDataInizioBorsa(Date dataInizioBorsa) {
			this.dataInizioBorsa = dataInizioBorsa;
		}




		public Date getDataFineBorsa() {
			return dataFineBorsa;
		}




		public void setDataFineBorsa(Date dataFineBorsa) {
			this.dataFineBorsa = dataFineBorsa;
		}




		public String getDenominazioneSpec() {
			return denominazioneSpec;
		}




		public void setDenominazioneSpec(String denominazioneSpec) {
			this.denominazioneSpec = denominazioneSpec;
		}




		public String getLuogoSpec() {
			return luogoSpec;
		}




		public void setLuogoSpec(String luogoSpec) {
			this.luogoSpec = luogoSpec;
		}




		public String getNazioneSpec() {
			return nazioneSpec;
		}




		public void setNazioneSpec(String nazioneSpec) {
			this.nazioneSpec = nazioneSpec;
		}

		public String getDurataSpec() {
			return durataSpec;
		}


		public void setDurataSpec(String durataSpec) {
			this.durataSpec = durataSpec;
		}


		public void setIdSecondaLaurea(String idSecondaLaurea) {
			this.idSecondaLaurea = idSecondaLaurea;
		}




		public String getDescUniSecondaLaurea() {
			return descUniSecondaLaurea;
		}




		public void setDescUniSecondaLaurea(String descUniSecondaLaurea) {
			this.descUniSecondaLaurea = descUniSecondaLaurea;
		}




		public String getLuogoSecondaLaurea() {
			return luogoSecondaLaurea;
		}




		public void setLuogoSecondaLaurea(String luogoSecondaLaurea) {
			this.luogoSecondaLaurea = luogoSecondaLaurea;
		}




		public Date getDataSecondaLaurea() {
			return dataSecondaLaurea;
		}




		public void setDataSecondaLaurea(Date dataSecondaLaurea) {
			this.dataSecondaLaurea = dataSecondaLaurea;
		}

		
		public String getNazioneSecondaLaurea() {
			return nazioneSecondaLaurea;
		}




		public void setNazioneSecondaLaurea(String nazioneSecondaLaurea) {
			this.nazioneSecondaLaurea = nazioneSecondaLaurea;
		}
		

		public String getDescPrimaLaurea() {
			return descPrimaLaurea;
		}
		

		public void setDescPrimaLaurea(String descPrimaLaurea) {
			this.descPrimaLaurea = descPrimaLaurea;
		}

		
		public String getNazioneSecondaLaureaBis() {
			return nazioneSecondaLaureaBis;
		}




		public void setNazioneSecondaLaureaBis(String nazioneSecondaLaureaBis) {
			this.nazioneSecondaLaureaBis = nazioneSecondaLaureaBis;
		}



		public String getDescUniSecondaLaureaBis() {
			return descUniSecondaLaureaBis;
		}




		public String getIdAltraLaureaBis() {
			return idAltraLaureaBis;
		}


		public void setIdAltraLaureaBis(String idAltraLaureaBis) {
			this.idAltraLaureaBis = idAltraLaureaBis;
		}


		public void setDescUniSecondaLaureaBis(String descUniSecondaLaureaBis) {
			this.descUniSecondaLaureaBis = descUniSecondaLaureaBis;
		}




		public String getLuogoSecondaLaureaBis() {
			return luogoSecondaLaureaBis;
		}




		public void setLuogoSecondaLaureaBis(String luogoSecondaLaureaBis) {
			this.luogoSecondaLaureaBis = luogoSecondaLaureaBis;
		}




		public Date getDataSecondaLaureaBis() {
			return dataSecondaLaureaBis;
		}




		public void setDataSecondaLaureaBis(Date dataSecondaLaureaBis) {
			this.dataSecondaLaureaBis = dataSecondaLaureaBis;
		}

	
	
		public Date getDataIdoneita() {
			return dataIdoneita;
		}
	
	
	
	
		public void setDataIdoneita(Date dataIdoneita) {
			this.dataIdoneita = dataIdoneita;
		}
	
	
		public String getDescrUniversitaSpec() {
			return descrUniversitaSpec;
		}
	
	
	
		public void setDescrUniversitaSpec(String descrUniversitaSpec) {
			this.descrUniversitaSpec = descrUniversitaSpec;
		}
	
	
	
	
		public String getDescrFacoltaSpec() {
			return descrFacoltaSpec;
		}
	
	
	
	
		public void setDescrFacoltaSpec(String descrFacoltaSpec) {
			this.descrFacoltaSpec = descrFacoltaSpec;
		}
	
	
	
	
		public String getCodIsbn() {
			return codIsbn;
		}
	    
		
		
		public void setCodIsbn(String codIsbn) {
			this.codIsbn = codIsbn;
		}



		public String getFlagEsteroSecondaLaurea() {
			return flagEsteroSecondaLaurea;
		}


		public void setFlagEsteroSecondaLaurea(String flagEsteroSecondaLaurea) {
			this.flagEsteroSecondaLaurea = flagEsteroSecondaLaurea;
		}


		public String getDataInizioCorsoReg() {
			return dataInizioCorsoReg;
		}


		public void setDataInizioCorsoReg(String dataInizioCorsoReg) {
			this.dataInizioCorsoReg = dataInizioCorsoReg;
		}


		public String getDataInizioPubblicazioneReg() {
			return dataInizioPubblicazioneReg;
		}


		public void setDataInizioPubblicazioneReg(String dataInizioPubblicazioneReg) {
			this.dataInizioPubblicazioneReg = dataInizioPubblicazioneReg;
		}


		public String getFlagEsteroSecondaLaureaBis() {
			return flagEsteroSecondaLaureaBis;
		}


		public void setFlagEsteroSecondaLaureaBis(String flagEsteroSecondaLaureaBis) {
			this.flagEsteroSecondaLaureaBis = flagEsteroSecondaLaureaBis;
		}


		public String getFlagEsteroSpec() {
			return flagEsteroSpec;
		}


		public void setFlagEsteroSpec(String flagEsteroSpec) {
			this.flagEsteroSpec = flagEsteroSpec;
		}


		public String getFlagEsteroBorsa() {
			return flagEsteroBorsa;
		}


		public void setFlagEsteroBorsa(String flagEsteroBorsa) {
			this.flagEsteroBorsa = flagEsteroBorsa;
		}


		public String getFlagEsteroDottorato() {
			return flagEsteroDottorato;
		}


		public void setFlagEsteroDottorato(String flagEsteroDottorato) {
			this.flagEsteroDottorato = flagEsteroDottorato;
		}


		public String getFlagEsteroAltroTitolo() {
			return flagEsteroAltroTitolo;
		}


		public void setFlagEsteroAltroTitolo(String flagEsteroAltroTitolo) {
			this.flagEsteroAltroTitolo = flagEsteroAltroTitolo;
		}


		public String getFlagEsteroCorsoAgg() {
			return flagEsteroCorsoAgg;
		}


		public void setFlagEsteroCorsoAgg(String flagEsteroCorsoAgg) {
			this.flagEsteroCorsoAgg = flagEsteroCorsoAgg;
		}


//		public boolean isSecLaureaValidRequired() {
//			return secLaureaValidRequired;
//		}
//
//
//		public void setSecLaureaValidRequired(boolean secLaureaValidRequired) {
//			this.secLaureaValidRequired = secLaureaValidRequired;
//		}


		public AltraLaureaBis getAltraLaureaBis() {
			return altraLaureaBis;
		}


		public void setAltraLaureaBis(AltraLaureaBis altraLaureaBis) {
			this.altraLaureaBis = altraLaureaBis;
		}


		public AltraLaureaBis getAltraLaureaBisSelezionata() {
			return altraLaureaBisSelezionata;
		}


		public void setAltraLaureaBisSelezionata(
				AltraLaureaBis altraLaureaBisSelezionata) {
			this.altraLaureaBisSelezionata = altraLaureaBisSelezionata;
		}


		public Specializzazione getSpecializzazione() {
			return specializzazione;
		}


		public void setSpecializzazione(Specializzazione specializzazione) {
			this.specializzazione = specializzazione;
		}


		public Specializzazione getSpecializzazioneSelezionata() {
			return specializzazioneSelezionata;
		}


		public void setSpecializzazioneSelezionata(
				Specializzazione specializzazioneSelezionata) {
			this.specializzazioneSelezionata = specializzazioneSelezionata;
		}


		public BorsaStudio getBorsaStudio() {
			return borsaStudio;
		}


		public void setBorsaStudio(BorsaStudio borsaStudio) {
			this.borsaStudio = borsaStudio;
		}


		public BorsaStudio getBorsaStudioSelezionata() {
			return borsaStudioSelezionata;
		}


		public void setBorsaStudioSelezionata(BorsaStudio borsaStudioSelezionata) {
			this.borsaStudioSelezionata = borsaStudioSelezionata;
		}


		public Dottorato getDottorato() {
			return dottorato;
		}


		public void setDottorato(Dottorato dottorato) {
			this.dottorato = dottorato;
		}


		public Dottorato getDottoratoSelezionato() {
			return dottoratoSelezionato;
		}


		public void setDottoratoSelezionato(Dottorato dottoratoSelezionato) {
			this.dottoratoSelezionato = dottoratoSelezionato;
		}


		public AltroTitolo getAltroTitolo() {
			return altroTitolo;
		}


		public void setAltroTitolo(AltroTitolo altroTitolo) {
			this.altroTitolo = altroTitolo;
		}


		public AltroTitolo getAltroTitoloSelezionato() {
			return altroTitoloSelezionato;
		}


		public void setAltroTitoloSelezionato(AltroTitolo altroTitoloSelezionato) {
			this.altroTitoloSelezionato = altroTitoloSelezionato;
		}


		public CorsoAgg getCorsoAgg() {
			return corsoAgg;
		}


		public void setCorsoAgg(CorsoAgg corsoAgg) {
			this.corsoAgg = corsoAgg;
		}


		public CorsoAgg getCorsoAggSelezionato() {
			return corsoAggSelezionato;
		}


		public void setCorsoAggSelezionato(CorsoAgg corsoAggSelezionato) {
			this.corsoAggSelezionato = corsoAggSelezionato;
		}


		public Pubblicazione getPubblicazione() {
			return pubblicazione;
		}


		public void setPubblicazione(Pubblicazione pubblicazione) {
			this.pubblicazione = pubblicazione;
		}


		public Pubblicazione getPubblicazioneSelezionata() {
			return pubblicazioneSelezionata;
		}


		public void setPubblicazioneSelezionata(Pubblicazione pubblicazioneSelezionata) {
			this.pubblicazioneSelezionata = pubblicazioneSelezionata;
		}


		public List<AltraLaureaBis> getListaAltreLaureeBis() {
			return listaAltreLaureeBis;
		}


		public void setListaAltreLaureeBis(ArrayList<AltraLaureaBis> listaAltreLaureeBis) {
			this.listaAltreLaureeBis = listaAltreLaureeBis;
		}



		public List<Specializzazione> getListaSpecializzazioni() {
			return listaSpecializzazioni;
		}


		public void setListaSpecializzazioni(
				ArrayList<Specializzazione> listaSpecializzazioni) {
			this.listaSpecializzazioni = listaSpecializzazioni;
		}


		public List<BorsaStudio> getListaBorseStudio() {
			return listaBorseStudio;
		}


		public void setListaBorseStudio(ArrayList<BorsaStudio> listaBorseStudio) {
			this.listaBorseStudio = listaBorseStudio;
		}


		public List<Dottorato> getListaDottorati() {
			return listaDottorati;
		}


		public void setListaDottorati(ArrayList<Dottorato> listaDottorati) {
			this.listaDottorati = listaDottorati;
		}


		public List<AltroTitolo> getListaAltriTitoli() {
			return listaAltriTitoli;
		}

		public void setListaAltriTitoli(ArrayList<AltroTitolo> listaAltriTitoli) {
			this.listaAltriTitoli = listaAltriTitoli;
		}

		public List<CorsoAgg> getListaCorsiAgg() {
			return listaCorsiAgg;
		}

		public void setListaCorsiAgg(ArrayList<CorsoAgg> listaCorsiAgg) {
			this.listaCorsiAgg = listaCorsiAgg;
		}

		public List<Pubblicazione> getListaPubblicazioni() {
			return listaPubblicazioni;
		}

		public void setListaPubblicazioni(ArrayList<Pubblicazione> listaPubblicazioni) {
			this.listaPubblicazioni = listaPubblicazioni;
		}
		
		public boolean isVisualizzaPanelBancario() {
			return visualizzaPanelBancario;
		}

		public void setVisualizzaPanelBancario(boolean visualizzaPanelBancario) {
			this.visualizzaPanelBancario = visualizzaPanelBancario;
		}

		public boolean isVisualizzaPanelPostale() {
			return visualizzaPanelPostale;
		}

		public void setVisualizzaPanelPostale(boolean visualizzaPanelPostale) {
			this.visualizzaPanelPostale = visualizzaPanelPostale;
		}

		public DatiBando getDatiBando() {
			return datiBando;
		}

		public void setDatiBando(DatiBando datiBando) {
			this.datiBando = datiBando;
		}

		public String getTipologiaVersamento() {
			return tipologiaVersamento;
		}

		public void setTipologiaVersamento(String tipologiaVersamento) {
			this.tipologiaVersamento = tipologiaVersamento;
		}

		public String getContributoPartecipazione() {
			return contributoPartecipazione;
		}

		public void setContributoPartecipazione(String contributoPartecipazione) {
			this.contributoPartecipazione = contributoPartecipazione;
		}

		public boolean isMostraPanelBancario() {
			return mostraPanelBancario;
		}

		public void setMostraPanelBancario(boolean mostraPanelBancario) {
			this.mostraPanelBancario = mostraPanelBancario;
		}

		public boolean isMostraPanelPostale() {
			return mostraPanelPostale;
		}

		public void setMostraPanelPostale(boolean mostraPanelPostale) {
			this.mostraPanelPostale = mostraPanelPostale;
		}

		public boolean isMostraListaPagamenti() {
			return mostraListaPagamenti;
		}

		public void setMostraListaPagamenti(boolean mostraListaPagamenti) {
			this.mostraListaPagamenti = mostraListaPagamenti;
		}

		public Date getDataNascitaUtente() {
			return dataNascitaUtente;
		}

		public void setDataNascitaUtente(Date dataNascitaUtente) {
			this.dataNascitaUtente = dataNascitaUtente;
		}

		public int getElencoDocSize() {
			return elencoDocSize;
		}

		public Date getDataPrimaLaurea() {
			return dataPrimaLaurea;
		}

		public void setDataPrimaLaurea(Date dataPrimaLaurea) {
			this.dataPrimaLaurea = dataPrimaLaurea;
		}

		public void setElencoDocSize(int elencoDocSize) {
			this.elencoDocSize = elencoDocSize;
		}

		public boolean isVisualizzaDichiarazione() {
			return visualizzaDichiarazione;
		}

		public void setVisualizzaDichiarazione(boolean visualizzaDichiarazione) {
			this.visualizzaDichiarazione = visualizzaDichiarazione;
		}
		
		
}
