package com.accenture.CCFarm.PageBean;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpSession;

import org.primefaces.context.RequestContext;

import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.StringUtil;


@FacesValidator("com.accenture.CCFarm.PageBean.ConfermaEmailValidator")
public class ConfermaEmailValidator implements Validator
{
	
	public void validate(FacesContext context,UIComponent component,Object value) throws ValidatorException
	{
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		//id della componente di testo che ha invocato il validatore
		String sourceID=component.getId();
		
		//determina la componente di testo con la quale eseguire il confronto
		String targetID=sourceID.replaceFirst("conferma","");
		targetID=targetID.replaceFirst("Pec","pec");
		JSFUtility.update("pec");
		UIInput textComponent=(UIInput)JSFUtility.findComponent(JSFUtility.getUIViewRoot(),targetID);
		
		//procedi al confronto solo se la ricerca ha avuto esito positivo e il campo di conferma � stato valorizzato
		if(textComponent!=null && value!=null)
		{
			//ricava il testo oggetto del confronto
			String originalEmail=(String)textComponent.getValue();
			
			//ricava la stringa da confrontare col testo in oggetto
			String replicatedEmail=value.toString();
			
			//se i 2 indirizzi email non coincidono, genera un errore di validazione
			if(originalEmail==null || !replicatedEmail.trim().equalsIgnoreCase(originalEmail.trim()))
			{
				String msg=StringUtil.getPropertyMessage("requisiti.errore.conferma.pec",lingua);
				
				FacesMessage facesMessage = new FacesMessage("",msg);
				facesMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
		
				throw new ValidatorException(facesMessage);
			}
		}
	}
}

	