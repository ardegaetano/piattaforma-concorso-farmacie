package com.accenture.CCFarm.PageBean;

import java.io.Serializable;

public class UtenteTest {

	
	private String codiceFiscale;
	private String nome;
	private String cognome;
	private String pecMail;
	private String codTipoDomanda;
	private String tipoUtenza;
	private String flagAccettaTermini;
	private String createdBy;
	private Serializable creationDate;
	private Serializable lastUpdateDate;
	private String lastUpdatedBy;
	private String pwd;
	private String idUtente;
	public String getCodiceFiscale() {
		return codiceFiscale;
	}
	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getPecMail() {
		return pecMail;
	}
	public void setPecMail(String pecMail) {
		this.pecMail = pecMail;
	}
	public String getCodTipoDomanda() {
		return codTipoDomanda;
	}
	public void setCodTipoDomanda(String codTipoDomanda) {
		this.codTipoDomanda = codTipoDomanda;
	}
	public String getTipoUtenza() {
		return tipoUtenza;
	}
	public void setTipoUtenza(String tipoUtenza) {
		this.tipoUtenza = tipoUtenza;
	}
	public String getFlagAccettaTermini() {
		return flagAccettaTermini;
	}
	public void setFlagAccettaTermini(String flagAccettaTermini) {
		this.flagAccettaTermini = flagAccettaTermini;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Serializable getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Serializable creationDate) {
		this.creationDate = creationDate;
	}
	public Serializable getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(Serializable lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getIdUtente() {
		return idUtente;
	}
	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}
	
	
	
	
}

