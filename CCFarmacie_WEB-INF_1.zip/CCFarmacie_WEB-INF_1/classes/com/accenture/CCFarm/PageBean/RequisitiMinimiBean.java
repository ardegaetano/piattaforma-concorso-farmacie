package com.accenture.CCFarm.PageBean;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.Bean.ComuneSelect;
import com.accenture.CCFarm.Bean.NazioneSelect;
import com.accenture.CCFarm.Bean.ProvinciaSelect;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.RequisitiMinimiAction;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;

@ManagedBean
@RequestScoped
public class RequisitiMinimiBean
{
	//dati relativi alle localit�
	private HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect;
	private HashMap<String, ArrayList<ComuneSelect>> comuniSelect;
	private List<NazioneSelect> nazioniSEEList;
	private List nazioniSelect;
	private ArrayList<ProvinciaSelect> provinceList;
	private ArrayList<ComuneSelect> comuniResidenzaList,comuniElettoraliList;
	
	private String regioneSelezionata,provinciaSelezionata,comuneSelezionato, nazioneSelezionata;
	
	//Tabelle del db coinvolte: "Utente","RequisitiMinimi","Nazioni","Province","Comuni"
	//Dati Anagrafici
	private String cognomeUtente;
	private String nomeUtente;
	private Date dataNascitaUtente;
	private String dataNascitaString;
	private String sesso;
	
	private String nazioneNascitaUtente;
	private String denominazioneNazioneNascitaUtente;
	
	private String luogoNascitaUtente;
	private String denominazioneLuogoNascitaUtente;
	
	private String luogoNascitaEstera;
	
	private String prvNascitaUtente;
	private String denominazionePrvNascitaUtente;
	
	private String codiceFiscaleUtente;
	private String estremiDocumentoIdentitaUtente;
	
	//Dati Residenza
	private String indirizzoResidenza;
	private String prvResidenzaUtente;
	private String comuneResidenzaUtente;
	private String nazioneResidenzaUtente;
	private String localitaResidenzaEstera;
	private String capResidenzaUtente;
	private String nTelefonoUtente;
	private String nCellulareUtente;
	private String pecMail;
	
	//Fattispecie di appartenenza
	private String fattispecieAppartenenza;
	
	//Cittadinanza e Diritti Civili e Politici
	private String statoUe;
	private String provinciaListaElettorale;
	private String comuneListaElettorale;
	private String flagDirittiPoliticiCivili;
	
	//Iscrizione all'albo professionale dei Farmacisti
	private String flagIscrizioneAlbo;
	private String prvAlbo;
	private String prvAttualeAlbo;
	private Date dataAlbo;
	private String NAlbo;
	
	//Per la sola PA di Bolzano
	private boolean isBolzano;
	private String attestato;
	
	//Laurea Principale
	private String codTipoLaurea;
	private String descrUniversita;
	private String luogoLaurea;
	private Date dataLaurea;
	private String votoLaurea;
	private String baseVotoLaurea;
	private String flagLode;
	
	//Abilitazione
	private String descrUniAbilitazione;
	private String luogoUniAbilitazione;
	private String annoAbilitazione;
	private String votoAbilitazione;
	private String baseVotoAbilitazione;
	private String nazioneAbilitazione;
	private String estremiAbilitazioneEstera;
	
	//Condanne e procedimenti Penali
	private String flagNnCondannePenali;
	
	//Titolarit� di farmacia
	private String flagNnCessioneFarm;
	
	//Limite alla partecipazione
	private String flagNnPartecipazioneMultipla;
	
	private String[]listaHelp;
	private String[]listaHelpTitoli;
	private String[]listaHelpEsercizio;
	private String[]listaHelpVersamento;
	
	RequisitiMinimiAction requisitiMinimiAction;
	Logger logger = CommonLogger.getLogger("RequisitiMinimiBean");
	
	private String linguaScelta="it";
	
	public RequisitiMinimiBean()
	{
		requisitiMinimiAction=new RequisitiMinimiAction();
	}
	
	public boolean init(String idUtente)
	{
		//inizializza localit�
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		if(lingua!=null){
			linguaScelta=lingua;
		}
		
		//carica solo le nazioni dello SEE
		setNazioniSEEList(Localita.getNazioniEuropee());
		
		setNazioniSelect(Localita.getNazioni());
		
		//carica tutte le province
		setProvinceSelect(Localita.getProvince("0"));
		setProvinceList(provinceSelect.get("0"));
		
		try {
			return requisitiMinimiAction.init(idUtente,this);
		} catch (GestioneErroriException e) {
			logger.error("RequisitiMinimiBean - init: " + e.getMessage());	
			JSFUtility.redirect("errorPageGenerica.jsf");
			return false;
		}
	}
	
	public boolean updateDAO(String idUtente,java.sql.Timestamp now)
	{
		return requisitiMinimiAction.updateDAO(idUtente,now,this);
	}
	
	
	public void nazioneResidenzaCambiata(javax.faces.event.AjaxBehaviorEvent event)
	{
    	String sourceId=event.getComponent().getId();
    	
		if(sourceId.equals("statoResidenza"))
		{
			localitaResidenzaEstera = null;
			prvResidenzaUtente=null;
			comuneResidenzaUtente=null;
			
			JSFUtility.update("pannelloLocalitaResidenzaEstera");
			JSFUtility.update("pannelloResidenzaComuni");
		}
	}
	
	//metodi per il controllo dei vincoli sui dati ---------------------------------------------------------------
	
	//controlla che tutti flag siano stati valorizzati a true
	public boolean controllaFlag()
	{
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		if(flagDirittiPoliticiCivili==null || flagDirittiPoliticiCivili.equals("false"))
		{
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.casella.cittadinanza", lingua));
//			JSFUtility.addWarningMessage("Attenzione","E' necessario che la casella nella sezione 'Cittadinanza e Diritti Civili e Politici' sia spuntata");
			return false;
		}
		if(flagIscrizioneAlbo==null || flagIscrizioneAlbo.equals("false"))
		{
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.casella.albo", lingua));
//			JSFUtility.addWarningMessage("Attenzione","E' necessario che la casella nella sezione 'Iscrizione all'albo professionale' sia spuntata");
			return false;
		}
		if(flagNnCondannePenali==null || flagNnCondannePenali.equals("false"))
		{
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.casella.condanne", lingua));
//			JSFUtility.addWarningMessage("Attenzione","E' necessario che la casella nella sezione 'Condanne e procedimenti Penali' sia spuntata");
			return false;
		}
		if(flagNnCessioneFarm==null || flagNnCessioneFarm.equals("false"))
		{
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.casella.trasferimenti", lingua));
//			JSFUtility.addWarningMessage("Attenzione","E' necessario che la casella nella sezione 'Trasferimenti di Titolarit�' sia spuntata");
			return false;
		}
		if(flagNnPartecipazioneMultipla==null || flagNnPartecipazioneMultipla.equals("false"))
		{
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.casella.limite", lingua));
//			JSFUtility.addWarningMessage("Attenzione","E' necessario che la casella nella sezione 'Limite alla partecipazione' sia spuntata");
			return false;
		}
		return true;
	}
	
	//restituisce true se tutti i campi sono stati correttamente valorizzati
	public boolean isCompletato()
	{
		if(cognomeUtente==null || cognomeUtente.equals("")) return false;
		if(nomeUtente==null || nomeUtente.equals("")) return false;
		if(dataNascitaUtente==null) return false;
		if(sesso==null || sesso.equals("")) return false;
		
		if(nazioneNascitaUtente==null || nazioneNascitaUtente.equals("")) return false;
		
		if(nazioneNascitaUtente.equals("IT"))
		{
			if(luogoNascitaUtente==null || luogoNascitaUtente.equals("")) return false;
			if(prvNascitaUtente==null || prvNascitaUtente.equals("")) return false;
		}
		else
		{
			if(luogoNascitaEstera==null || luogoNascitaEstera.equals("")) return false;
		}
		
		if(codiceFiscaleUtente==null || codiceFiscaleUtente.equals("")) return false;
		if(estremiDocumentoIdentitaUtente==null || estremiDocumentoIdentitaUtente.equals("")) return false; 
		
		if(nazioneResidenzaUtente==null || nazioneResidenzaUtente.equals("") )
		{
			return false;
		}
		else if(nazioneResidenzaUtente.equals("IT"))
		{
		
			if(prvResidenzaUtente==null || prvResidenzaUtente.equals("")) return false;
			if(comuneResidenzaUtente==null || comuneResidenzaUtente.equals("")) return false;
		}
		else
		{
			if(localitaResidenzaEstera==null || localitaResidenzaEstera.equals("")) return false;
		}
		
		if(indirizzoResidenza==null || indirizzoResidenza.equals("")) return false;
		if(capResidenzaUtente==null || capResidenzaUtente.equals("")) return false;
		if(nTelefonoUtente==null || nTelefonoUtente.equals(""))
		{
			if(nCellulareUtente==null || nCellulareUtente.equals(""))
				return false;
		}
		if(pecMail==null || pecMail.equals("")) return false;
		
		if(fattispecieAppartenenza==null || fattispecieAppartenenza.equals("")) return false;
		
		if(statoUe==null || statoUe.equals("")) return false;
		
		if(statoUe.equals("IT"))
		{
			if(provinciaListaElettorale==null || provinciaListaElettorale.equals("")) return false;
			if(comuneListaElettorale==null || comuneListaElettorale.equals(""))	return false;
		}
		
		if(!flagDirittiPoliticiCivili.equals("true")) return false;
		
		if(!flagIscrizioneAlbo.equals("true")) return false;
		if(prvAlbo==null || prvAlbo.equals("")) return false;

		if(prvAttualeAlbo==null || prvAttualeAlbo.equals("")) return false;
		
		if(dataAlbo==null) return false;
		if(NAlbo==null || NAlbo.equals("")) return false;

		if(isBolzano && (attestato==null || attestato.equals(""))) return false;
		
		if(codTipoLaurea==null || codTipoLaurea.equals("")) return false;
		if(descrUniversita==null || descrUniversita.equals("")) return false;
		if(luogoLaurea==null || luogoLaurea.equals("")) return false;
		if(dataLaurea==null) return false;
		
		if(descrUniAbilitazione==null || descrUniAbilitazione.equals("")) return false;
		if(luogoUniAbilitazione==null || luogoUniAbilitazione.equals("")) return false;
		if(annoAbilitazione==null) return false;
		if(nazioneAbilitazione==null || nazioneAbilitazione.equals("")) return false;
		else if(nazioneAbilitazione.equals("Estera") && (estremiAbilitazioneEstera==null || estremiAbilitazioneEstera.equals("")))
			return false;
		
		if(!flagNnCondannePenali.equals("true")) return false;
		if(!flagNnCessioneFarm.equals("true")) return false;
		if(!flagNnPartecipazioneMultipla.equals("true")) return false;
		
		return true;
	}
	
	public boolean controllaCampi()
	{
		return controllaFlag() && controllaIscrizioneAlbo() && controlloVotoLaurea() && controlloVotoAbilitazione() &&
			   controllaDataConseguimentoLaurea() && controllaRecapitiTelefonici() && controllaAnnoAbilitazione();
	}
	
	private java.util.Date getDataPubblicazioneBando() throws Exception
	{
		DatiBando datiBando=(DatiBando)GetSessionUtility.getSessionAttribute(RepositorySession.DATI_BANDO);
		if(datiBando==null)
			throw new Exception("[Impossibile individuare la data di pubblicazione del bando]");
		
		java.util.Date dataPubblicazione=DateUtil.sqlDateToUtilDate(datiBando.getDataPubblicazioneBando());
	
		if(dataPubblicazione==null)
			throw new Exception("[Impossibile individuare la data di pubblicazione del bando]");
		return dataPubblicazione;
	}
	
	private java.util.Date getDataFineBando() throws Exception
	{
		DatiBando datiBando=(DatiBando)GetSessionUtility.getSessionAttribute(RepositorySession.DATI_BANDO);
		if(datiBando==null)
			throw new Exception("[Impossibile individuare la data di fine bando]");
		
		java.util.Date dataFineBando=datiBando.getDataFineBando();
	
		if(dataFineBando==null)
			throw new Exception("[Impossibile individuare la data di fine bando]");
		return dataFineBando;
	}
	
	private boolean controllaIscrizioneAlbo()
	{
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		//controllo: dataNascita < anno abilitazione < dataIscrizioneAlbo < dataScadenzaBando
		if(dataAlbo!=null)
		{
			int c=2;
			if(dataNascitaUtente!=null)
			{
				if(!dataNascitaUtente.before(dataAlbo))// dataNascita < dataAlbo ?
					c=0;
			}
			else
			{
				c=1;
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.data", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Errore durante la verifica della data inserita");
			}
			if(c==2)
			{
				try
				{
					Date dataPubblicazione=getDataFineBando();
					if(dataPubblicazione!=null)
					{
						if(!dataAlbo.before(dataPubblicazione))// dataAlbo < dataScadenza ?
							c=0;
					}
					else
					{
						c=1;
						JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.data", lingua));
//						JSFUtility.addWarningMessage("Attenzione","Errore durante la verifica della data inserita");
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
					dataAlbo=null;
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.data", lingua));
//					JSFUtility.addWarningMessage("Attenzione","Errore durante la verifica della data inserita");
					return false;
				}
			}
			//se qualcosa � andato storto
			if(c<2)
			{
				dataAlbo=null;
				if(c==0){
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.dataiscrizione.min.datanascita", lingua));
//					JSFUtility.addWarningMessage("Attenzione","La data di iscrizione all'Albo deve essere successiva a quella di nascita e precedente a quella di scadenza del Bando");
				}
				return false;
			}
			
           if(!this.annoAbilitazione.equalsIgnoreCase("")){ 
				
				if(new Integer(this.getAnnoAbilitazione()) > DateUtil.getYearFromDate(dataAlbo))
				
				{
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.annoAbilitazione.magg.dataiscrizione", lingua));
//					JSFUtility.addWarningMessage("Attenzione","L'anno di abilitazione non pu� essere successivo all'anno di prima iscrizione all'albo");
					//JSFUtility.scrollTo("form:msgs");
					return false;
				}
					
			}
			
			
			return true;
		}
		return false;	
	}
	
	private boolean controllaDataConseguimentoLaurea()
	{
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		//controllo: dataNascita < dataConseguimento < dataScadenzaBando
		if(dataLaurea!=null)
		{
			int c=2;
			if(dataNascitaUtente!=null)
			{
				if(!dataNascitaUtente.before(dataLaurea))// dataNascita < dataLaurea ?
					c=0;
			}
			else
			{
				c=1;
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.data", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Errore durante la verifica della data inserita");
			}
			if(c==2)
			{
				try
				{
					Date dataPubblicazione=getDataFineBando();
					if(dataPubblicazione!=null)
					{
						if(!dataLaurea.before(dataPubblicazione))// dataLaurea < dataScadenza ?
							c=0;
					}
					else
					{
						c=1;
						JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.data", lingua));
//						JSFUtility.addWarningMessage("Attenzione","Errore durante la verifica della data inserita");
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
					dataLaurea=null;
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.data", lingua));
//					JSFUtility.addWarningMessage("Attenzione","Errore durante la verifica della data inserita");
					return false;
				}
			}
			//se qualcosa � andato storto
			if(c<2)
			{
				dataLaurea=null;
				if(c==0){
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.datalaurea.minore.datanascita", lingua));
//					JSFUtility.addWarningMessage("Attenzione","La data di conseguimento della laurea deve essere successiva a quella di nascita e precedente a quella di scadenza del Bando");
				}
				return false;
			}
			return true;
		}
		return false;
	}
	
	//...
	
	//------------------------------------------------------------------------------------------------------------
	
	//dichiarazione listeners ------------------------------------------------------------------------------------
	
	public void nazioneCambiata(javax.faces.event.AjaxBehaviorEvent event)
	{
		String sourceId=event.getComponent().getId();
		
		if(sourceId.equals("cittadinanza"))
		{
			if(!statoUe.equals("IT"))
			{
				provinciaListaElettorale=null;
				comuneListaElettorale=null;
				
			}
			JSFUtility.update("comuniListaElettoralePanel");
		}
		
		if(sourceId.equals("nazioneAbilitazione"))
		{	
			JSFUtility.update("estremiAbilitazionePanel");
		}
	}
	
	public void provinciaCambiata(javax.faces.event.AjaxBehaviorEvent event)
	{
		String sourceId=event.getComponent().getId();
		
		//carica tutti i comuni appartenenti alla provincia selezionata
		
		if(sourceId.equals("prvResidenza"))
		{
			setComuniSelect(Localita.getComuni(prvResidenzaUtente));
			comuniResidenzaList=comuniSelect.get(prvResidenzaUtente);
			JSFUtility.update("comuneResidenza");
		}
		if(sourceId.equals("provinciaListaElettorale"))
		{
			setComuniSelect(Localita.getComuni(provinciaListaElettorale));
			comuniElettoraliList=comuniSelect.get(provinciaListaElettorale);
			JSFUtility.update("comuneListaElettorale");
		}
	}
	
	private boolean controllaRecapitiTelefonici()
	{
		
		if((nTelefonoUtente==null || nTelefonoUtente.equals("")) && (nCellulareUtente==null || nCellulareUtente.equals("")))
		{
			HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
			String lingua= (String)session.getAttribute("linguaScelta");
			
			JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.almeno.telefono", lingua));
//			JSFUtility.addWarningMessage("Attenzione","E' necessario inserire almeno uno dei due recapiti telefonici");
			return false;
		}
		return true;
	}
	
	public void aggiornaRadioButton(javax.faces.event.AjaxBehaviorEvent event)
	{	
		String sourceId=event.getComponent().getId();
		
		if(sourceId.equals("fattispecie"))
			JSFUtility.update("panelFattispecie");
		
		if(sourceId.equals("iscrizioneBolzano"))
			JSFUtility.update("panelIscrizioneBolzano");
	}
	
//	public void votoLaureaCambiato(javax.faces.event.AjaxBehaviorEvent event)
//	{
//		String sourceId=event.getComponent().getId();
//		
//		if(sourceId.equals("votoLaurea") && !controlloVotoLaurea())
//		{
//			votoLaurea=null;
//			JSFUtility.update("votoLaurea");
//			JSFUtility.addWarningMessage("Attenzione","Il voto di Laurea deve essere minore del massimo conseguibile");
//		}
//		
//		//se il voto non � massimo, togli la spunta al flag
//		if(votoLaurea!=null && !votoLaurea.equals(baseVotoLaurea))
//			flagLode=null;
//		
//		JSFUtility.update("flagLode");
//	}
	
	
	private boolean controlloVotoLaurea()
	{
		int valoreVotoLaurea;
		int valoreBaseVotoLaurea;
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		votoLaurea=votoLaurea.trim();
		baseVotoLaurea=baseVotoLaurea.trim();
		
		//controllo se i campi sono entrambi vuoti
		if(votoLaurea.equals("") && baseVotoLaurea.equals(""))
		{
			return true;
		}
		else
		{
			//se uno dei 2 � valorizzato ma l'altro no
			if((votoLaurea.equals("") && !baseVotoLaurea.equals("")) || 
			   (!votoLaurea.equals("") && baseVotoLaurea.equals("")))
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.voto.laurea.incompleto", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Il voto di Laurea � incompleto");
				return false;
			}
			
			//Se entrambi non sono vuoti verifico che siano due numerici
			try
			{
				 valoreVotoLaurea = Integer.parseInt(votoLaurea) ;
				 valoreBaseVotoLaurea = Integer.parseInt(baseVotoLaurea) ;
				
			} catch (Exception e) {
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.voto.laurea.numerico", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Il voto di Laurea e la base devono essere valori numerici");
				return false;
			}
			
			if (valoreVotoLaurea > valoreBaseVotoLaurea)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.voto.laurea.oltre.soglia", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Il voto di Laurea deve essere minore del massimo conseguibile");
				return false;
			}
			
			if (valoreBaseVotoLaurea!=110)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.base.laurea.110", lingua));
//				JSFUtility.addWarningMessage("Attenzione","La base voto di Laurea deve essere 110");
				return false;
			}
			
			if (valoreVotoLaurea != valoreBaseVotoLaurea && flagLode.equalsIgnoreCase("true"))
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.base.laurea.110", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Il flag Lode Laurea non pu� essere selezionato");
				this.setFlagLode("false");
				JSFUtility.update("flagLode");
				return false;
			}
			
			return true;
	   }
	}
	private boolean controlloVotoAbilitazione()
	{
		int valoreAbilitazione;
		int valoreBaseVotoAbilitazione;		
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		votoAbilitazione=votoAbilitazione.trim();
		baseVotoAbilitazione=baseVotoAbilitazione.trim();
		
		//controllo se i campi sono entrambi vuoti
		if(votoAbilitazione.equals("") && baseVotoAbilitazione.equals(""))
		{
			return true;
		}
		else
		{
			//se uno dei 2 � valorizzato ma l'altro no
			if((votoAbilitazione.equals("") && !baseVotoAbilitazione.equals("")) || 
			   (!votoAbilitazione.equals("") && baseVotoAbilitazione.equals("")))
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.voto.abilitazione.incompleto", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Il voto di abilitazione � incompleto");
				return false;
			}
			
			//Se entrambi non sono vuoti verifico che siano due numerici
			try
			{
				valoreAbilitazione = Integer.parseInt(votoAbilitazione) ;
				valoreBaseVotoAbilitazione = Integer.parseInt(baseVotoAbilitazione) ;
				
			} catch (Exception e) {
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.voto.abilitazione.numerico", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Il voto di abilitazione e la base devono essere valori numerici");
				return false;
			}
			
			if (valoreAbilitazione > valoreBaseVotoAbilitazione)
			{
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.voto.abilitazione.oltre.soglia", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Il voto di abilitazione deve essere minore del massimo conseguibile");
				return false;
			}
			
			return true;
		}
	}
	
	
	private boolean controllaAnnoAbilitazione()
	{
		
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		//controllo: anno dataNascita < annoPrimaLaurea <= annoAbilitazione <= annoPubblicazioneBando
		if(annoAbilitazione!=null)
		{
			int c=3;
			if(dataNascitaUtente!=null)
			{
				if(new Integer(annoAbilitazione) <= DateUtil.getYearFromDate(dataNascitaUtente))
					c=1;
			}
			if(dataLaurea!=null)
			{
				if(new Integer(annoAbilitazione) < DateUtil.getYearFromDate(dataLaurea))
					c=2;
			}
			if(dataNascitaUtente==null || dataLaurea==null)
			{
				c=0;
				JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.anno.abilitazione", lingua));
//				JSFUtility.addWarningMessage("Attenzione","Errore durante la verifica dell'anno di abilitazione");
			}
			if(c==3)
			{
				try
				{
					Date dataPubblicazione=getDataFineBando();
					if(dataPubblicazione!=null)
					{
						if(new Integer(annoAbilitazione) > DateUtil.getYearFromDate(dataPubblicazione))
							c=1;
					}
					else
					{
						c=0;
						JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.anno.abilitazione", lingua));
//						JSFUtility.addWarningMessage("Attenzione","Errore durante la verifica dell'anno di abilitazione");
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
					annoAbilitazione=null;
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.errore.anno.abilitazione", lingua));
//					JSFUtility.addWarningMessage("Attenzione","Errore durante la verifica dell'anno di abilitazione");
					return false;
				}
			}
			//se qualcosa � andato storto
			if(c<3)
			{
				annoAbilitazione=null;
				if(c==1){
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.anno.abilitazione.min.datanascita", lingua));
//					JSFUtility.addWarningMessage("Attenzione","L'anno di abilitazione deve essere successivo a quello di nascita e precedente a quello di scadenza del bando");
				}
				if(c==2){
					JSFUtility.addWarningMessage(JSFUtility.getPropertyMessage("bean.attenzione", lingua),JSFUtility.getPropertyMessage("requisitiMinimiBean.attenzione.anno.abilitazione.min.datalaurea", lingua));
//					JSFUtility.addWarningMessage("Attenzione","L'anno di abilitazione non pu� essere precedente a quello di conseguimento della laurea");
				}
				return false;
			}
			return true;
		}
		return false;
	}
	
	//------------------------------------------------------------------------------------------------------------
	
	public HashMap<String, ArrayList<ComuneSelect>> getComuniSelect() {
		return comuniSelect;
	}
	
	public HashMap<String, ArrayList<ProvinciaSelect>> getProvinceSelect() {
		return provinceSelect;
	}

	public void setProvinceSelect(
			HashMap<String, ArrayList<ProvinciaSelect>> provinceSelect) {
		this.provinceSelect = provinceSelect;
	}

	public void setComuniSelect(
			HashMap<String, ArrayList<ComuneSelect>> comuniSelect) {
		this.comuniSelect = comuniSelect;
	}
	
	public List<NazioneSelect> getNazioniSEEList() {
		return nazioniSEEList;
	}
	
	public void setNazioniSEEList(List<NazioneSelect> nazioniSEEList) {
		this.nazioniSEEList = nazioniSEEList;
	}

	public ArrayList<ProvinciaSelect> getProvinceList() {
		return provinceList;
	}
	
	public void setProvinceList(ArrayList<ProvinciaSelect> provinceList) {
		this.provinceList = provinceList;
	}
	
	public ArrayList<ComuneSelect> getComuniResidenzaList() {
		return comuniResidenzaList;
	}

	public void setComuniResidenzaList(ArrayList<ComuneSelect> comuniResidenzaList) {
		this.comuniResidenzaList = comuniResidenzaList;
	}

	public ArrayList<ComuneSelect> getComuniElettoraliList() {
		return comuniElettoraliList;
	}

	public void setComuniElettoraliList(ArrayList<ComuneSelect> comuniElettoraliList) {
		this.comuniElettoraliList = comuniElettoraliList;
	}
	
	//-----------------
	
	public String getRegioneSelezionata() {
		return regioneSelezionata;
	}

	public void setRegioneSelezionata(String regioneSelezionata) {
		this.regioneSelezionata = regioneSelezionata;
	}

	public String getProvinciaSelezionata() {
		return provinciaSelezionata;
	}

	public void setProvinciaSelezionata(String provinciaSelezionata) {
		this.provinciaSelezionata = provinciaSelezionata;
	}

	public String getComuneSelezionato() {
		return comuneSelezionato;
	}

	public void setComuneSelezionato(String comuneSelezionato) {
		this.comuneSelezionato = comuneSelezionato;
	}
	
	public String getCognomeUtente() {
		return cognomeUtente;
	}

	public void setCognomeUtente(String cognomeUtente) {
		this.cognomeUtente = cognomeUtente;
	}

	public String getNomeUtente() {
		return nomeUtente;
	}

	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}

	public Date getDataNascitaUtente() {
		return dataNascitaUtente;
	}

	public void setDataNascitaUtente(Date dataNascitaUtente) {
		dataNascitaString=StringUtil.dateToStringDDMMYYYY(dataNascitaUtente);
		this.dataNascitaUtente = dataNascitaUtente;
	}
	
	public String getDataNascitaString() {
		return dataNascitaString;
	}

	public void setDataNascitaString(String dataNascitaString) {
		this.dataNascitaString = dataNascitaString;
	}
	
	public String getSesso() {
		return sesso;
	}

	public void setSesso(String sesso) {
		this.sesso = sesso;
	}

	public String getNazioneNascitaUtente() {
		return nazioneNascitaUtente;
	}
	
	public void setNazioneNascitaUtente(String nazioneNascitaUtente) {
		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
		
		if(nazioneNascitaUtente!=null)
			denominazioneNazioneNascitaUtente=Localita.getDenominazioneNazione(nazioneNascitaUtente,lingua);
		this.nazioneNascitaUtente = nazioneNascitaUtente;
	}
	
	public String getDenominazioneNazioneNascitaUtente() {
		return denominazioneNazioneNascitaUtente;
	}
	
	public void setDenominazioneNazioneNascitaUtente(
			String denominazioneNazioneNascitaUtente) {
		this.denominazioneNazioneNascitaUtente = denominazioneNazioneNascitaUtente;
	}
	
	public String getLuogoNascitaUtente() {
		return luogoNascitaUtente;
	}
	
	public void setLuogoNascitaUtente(String luogoNascitaUtente) {
		if(luogoNascitaUtente!=null)
			denominazioneLuogoNascitaUtente=Localita.getDenominazioneComune(luogoNascitaUtente);
		this.luogoNascitaUtente = luogoNascitaUtente;
	}
	
	public String getDenominazioneLuogoNascitaUtente() {
		return denominazioneLuogoNascitaUtente;
	}

	public void setDenominazioneLuogoNascitaUtente(
			String denominazioneLuogoNascitaUtente) {
		this.denominazioneLuogoNascitaUtente = denominazioneLuogoNascitaUtente;
	}

	public String getLuogoNascitaEstera() {
		return luogoNascitaEstera;
	}

	public String getVotoLaurea() {
		return votoLaurea;
	}

	public void setVotoLaurea(String votoLaurea) {
		this.votoLaurea = votoLaurea;
	}

	public String getBaseVotoLaurea() {
		return baseVotoLaurea;
	}

	public void setBaseVotoLaurea(String baseVotoLaurea) {
		this.baseVotoLaurea = baseVotoLaurea;
	}

	public String getAnnoAbilitazione() {
		return annoAbilitazione;
	}

	public void setAnnoAbilitazione(String annoAbilitazione) {
		this.annoAbilitazione = annoAbilitazione;
	}

	public String getVotoAbilitazione() {
		return votoAbilitazione;
	}

	public void setVotoAbilitazione(String votoAbilitazione) {
		this.votoAbilitazione = votoAbilitazione;
	}

	public String getBaseVotoAbilitazione() {
		return baseVotoAbilitazione;
	}

	public void setBaseVotoAbilitazione(String baseVotoAbilitazione) {
		this.baseVotoAbilitazione = baseVotoAbilitazione;
	}

	public void setLuogoNascitaEstera(String luogoNascitaEstera) {
		this.luogoNascitaEstera = luogoNascitaEstera;
	}

	
	public String getPrvNascitaUtente() {
		return prvNascitaUtente;
	}

	public void setPrvNascitaUtente(String prvNascitaUtente) {
		if(prvNascitaUtente!=null)
			denominazionePrvNascitaUtente=Localita.getDenominazioneProvincia(prvNascitaUtente);
		this.prvNascitaUtente = prvNascitaUtente;
	}
	
	public String getDenominazionePrvNascitaUtente() {
		return denominazionePrvNascitaUtente;
	}

	public void setDenominazionePrvNascitaUtente(
			String denominazionePrvNascitaUtente) {
		this.denominazionePrvNascitaUtente = denominazionePrvNascitaUtente;
	}

	public String getCodiceFiscaleUtente() {
		return codiceFiscaleUtente;
	}

	public void setCodiceFiscaleUtente(String codiceFiscaleUtente) {
		this.codiceFiscaleUtente = codiceFiscaleUtente;
	}
	
	public String getEstremiDocumentoIdentitaUtente() {
		return estremiDocumentoIdentitaUtente;
	}

	public void setEstremiDocumentoIdentitaUtente(
			String estremiDocumentoIdentitaUtente) {
		this.estremiDocumentoIdentitaUtente = estremiDocumentoIdentitaUtente;
	}

	public String getIndirizzoResidenza() {
		return indirizzoResidenza;
	}

	public void setIndirizzoResidenza(String indirizzoResidenza) {
		this.indirizzoResidenza = indirizzoResidenza;
	}
	
	public String getPrvResidenzaUtente() {
		return prvResidenzaUtente;
	}

	public void setPrvResidenzaUtente(String prvResidenzaUtente) {
		this.prvResidenzaUtente = prvResidenzaUtente;
	}

	public String getComuneResidenzaUtente() {
		return comuneResidenzaUtente;
	}

	public void setComuneResidenzaUtente(String comuneResidenzaUtente) {
		this.comuneResidenzaUtente = comuneResidenzaUtente;
	}

	public String getCapResidenzaUtente() {
		return capResidenzaUtente;
	}

	public void setCapResidenzaUtente(String capResidenzaUtente) {
		this.capResidenzaUtente = capResidenzaUtente;
	}

	public String getnTelefonoUtente() {
		return nTelefonoUtente;
	}

	public void setnTelefonoUtente(String nTelefonoUtente) {
		this.nTelefonoUtente = nTelefonoUtente;
	}

	public String getnCellulareUtente() {
		return nCellulareUtente;
	}

	public void setnCellulareUtente(String nCellulareUtente) {
		this.nCellulareUtente = nCellulareUtente;
	}

	public String getPecMail() {
		return pecMail;
	}

	public void setPecMail(String pecMail) {
		this.pecMail = pecMail;
	}

	public String getFattispecieAppartenenza() {
		return fattispecieAppartenenza;
	}

	public void setFattispecieAppartenenza(String fattispecieAppartenenza) {
		this.fattispecieAppartenenza = fattispecieAppartenenza;
	}

	public String getStatoUe() {
		return statoUe;
	}

	public void setStatoUe(String statoUe) {
		this.statoUe = statoUe;
	}
	
	public String getProvinciaListaElettorale() {
		return provinciaListaElettorale;
	}

	public void setProvinciaListaElettorale(String provinciaListaElettorale) {
		this.provinciaListaElettorale = provinciaListaElettorale;
	}

	public String getComuneListaElettorale() {
		return comuneListaElettorale;
	}

	public void setComuneListaElettorale(String comuneListaElettorale) {
		this.comuneListaElettorale = comuneListaElettorale;
	}

	public String getFlagDirittiPoliticiCivili() {
		return flagDirittiPoliticiCivili;
	}

	public void setFlagDirittiPoliticiCivili(String flagDirittiPoliticiCivili) {
		this.flagDirittiPoliticiCivili = flagDirittiPoliticiCivili;
	}

	public String getFlagIscrizioneAlbo() {
		return flagIscrizioneAlbo;
	}

	public void setFlagIscrizioneAlbo(String flagIscrizioneAlbo) {
		this.flagIscrizioneAlbo = flagIscrizioneAlbo;
	}
	
	public String getPrvAlbo() {
		return prvAlbo;
	}

	public void setPrvAlbo(String prvAlbo) {
		this.prvAlbo = prvAlbo;
	}

	public String getPrvAttualeAlbo() {
		return prvAttualeAlbo;
	}

	public void setPrvAttualeAlbo(String prvAttualeAlbo) {
		this.prvAttualeAlbo = prvAttualeAlbo;
	}
	
	public Date getDataAlbo() {
		return dataAlbo;
	}
	
	public void setDataAlbo(Date dataAlbo) {
		this.dataAlbo = dataAlbo;
	}

	public String getNAlbo() {
		return NAlbo;
	}

	public void setNAlbo(String nAlbo) {
		NAlbo = nAlbo;
	}
	
	public boolean getIsBolzano() {
		return isBolzano;
	}

	public void setIsBolzano(boolean isBolzano) {
		this.isBolzano = isBolzano;
	}

	public String getAttestato() {
		return attestato;
	}

	public void setAttestato(String attestato) {
		this.attestato = attestato;
	}

	public String getCodTipoLaurea() {
		return codTipoLaurea;
	}

	public void setCodTipoLaurea(String codTipoLaurea) {
		this.codTipoLaurea = codTipoLaurea;
	}

	public String getDescrUniversita() {
		return descrUniversita;
	}

	public void setDescrUniversita(String descrUniversita) {
		this.descrUniversita = descrUniversita;
	}

	public String getLuogoLaurea() {
		return luogoLaurea;
	}

	public void setLuogoLaurea(String luogoLaurea) {
		this.luogoLaurea = luogoLaurea;
	}

	public Date getDataLaurea() {
		return dataLaurea;
	}

	public void setDataLaurea(Date dataLaurea) {
		this.dataLaurea = dataLaurea;
	}

	

	public String getFlagLode() {
		return flagLode;
	}

	public void setFlagLode(String flagLode) {
		this.flagLode = flagLode;
	}

	public String getDescrUniAbilitazione() {
		return descrUniAbilitazione;
	}

	public void setDescrUniAbilitazione(String descrUniAbilitazione) {
		this.descrUniAbilitazione = descrUniAbilitazione;
	}

	public String getLuogoUniAbilitazione() {
		return luogoUniAbilitazione;
	}

	public void setLuogoUniAbilitazione(String luogoUniAbilitazione) {
		this.luogoUniAbilitazione = luogoUniAbilitazione;
	}

	public String getNazioneAbilitazione() {
		return nazioneAbilitazione;
	}

	public void setNazioneAbilitazione(String nazioneAbilitazione) {
		this.nazioneAbilitazione = nazioneAbilitazione;
	}
	
	public String getEstremiAbilitazioneEstera() {
		return estremiAbilitazioneEstera;
	}

	public void setEstremiAbilitazioneEstera(String estremiAbilitazioneEstera) {
		this.estremiAbilitazioneEstera = estremiAbilitazioneEstera;
	}

	public String getFlagNnCondannePenali() {
		return flagNnCondannePenali;
	}

	public void setFlagNnCondannePenali(String flagNnCondannePenali) {
		this.flagNnCondannePenali = flagNnCondannePenali;
	}

	public String getFlagNnCessioneFarm() {
		return flagNnCessioneFarm;
	}

	public void setFlagNnCessioneFarm(String flagNnCessioneFarm) {
		this.flagNnCessioneFarm = flagNnCessioneFarm;
	}

	public String getFlagNnPartecipazioneMultipla() {
		return flagNnPartecipazioneMultipla;
	}

	public void setFlagNnPartecipazioneMultipla(String flagNnPartecipazioneMultipla) {
		this.flagNnPartecipazioneMultipla = flagNnPartecipazioneMultipla;
	}

	public RequisitiMinimiAction getRequisitiMinimiAction() {
		return requisitiMinimiAction;
	}

	public void setRequisitiMinimiAction(RequisitiMinimiAction requisitiMinimiAction) {
		this.requisitiMinimiAction = requisitiMinimiAction;
	}

	public String[] getListaHelp() {
		return listaHelp;
	}

	public void setListaHelp(String[] listaHelp) {
		this.listaHelp = listaHelp;
	}

	public String[] getListaHelpTitoli() {
		return listaHelpTitoli;
	}

	public void setListaHelpTitoli(String[] listaHelpTitoli) {
		this.listaHelpTitoli = listaHelpTitoli;
	}

	public String[] getListaHelpEsercizio() {
		return listaHelpEsercizio;
	}

	public void setListaHelpEsercizio(String[] listaHelpEsercizio) {
		this.listaHelpEsercizio = listaHelpEsercizio;
	}

	public String[] getListaHelpVersamento() {
		return listaHelpVersamento;
	}

	public void setListaHelpVersamento(String[] listaHelpVersamento) {
		this.listaHelpVersamento = listaHelpVersamento;
	}

	public List getNazioniSelect() {
		return nazioniSelect;
	}

	public void setNazioniSelect(List nazioniSelect) {
		this.nazioniSelect = nazioniSelect;
	}

	public String getNazioneSelezionata() {
		return nazioneSelezionata;
	}

	public void setNazioneSelezionata(String nazioneSelezionata) {
		this.nazioneSelezionata = nazioneSelezionata;
	}

	public String getNazioneResidenzaUtente() {
		return nazioneResidenzaUtente;
	}

	public void setNazioneResidenzaUtente(String nazioneResidenzaUtente) {
		this.nazioneResidenzaUtente = nazioneResidenzaUtente;
	}

	public String getLocalitaResidenzaEstera() {
		return localitaResidenzaEstera;
	}

	public void setLocalitaResidenzaEstera(String localitaResidenzaEstera) {
		this.localitaResidenzaEstera = localitaResidenzaEstera;
	}

	public String getLinguaScelta() {
		return linguaScelta;
	}

	
	
}