package com.accenture.CCFarm.PageBean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.primefaces.event.FlowEvent;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutiva;
import com.accenture.CCFarm.DAO.RegioneDatiBando;
import com.accenture.CCFarm.action.DomandaAction;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.TabellaDecodifica;

@ManagedBean
@RequestScoped
public class DomandaVisualizzazione
{
	private String idUtente;
	private String idUtenteAssociato;
	private String tipologiaUtente;//pu� assumere i valori: singolo, referente, associato
	private boolean loggato;// true:  l'utente per cui si deve visualizzare la domanda � quello che ha effettuato l'accesso
							// false: l'utente � un associato per cui il referente ha richiesto la visualizzazione della domanda
	
	private String codiceRegione,denominazioneRegione;
	
	private String statoDomanda,codiceStatoDomanda;
	private Candidatura candidatura = null;
		
	
	TitoliStudioCarrieraBeanVisualizzazione titoliStudioCarrieraBeanVisualizzazione;
    EsercizioProfBeanVisualizzazione esercizioProfBeanVisualizzazione;
	DichiarazioneSostitutivaBeanVisualizzazione dichiarazioneSostitutivaBeanVisualizzazione;
	RequisitiMinimiBeanVisualizzazione requisitiMinimiBeanVisualizzazione;
	
	DomandaAction domandaAction;
	
	public DomandaVisualizzazione()
	{
		
		try
		{
			domandaAction=new DomandaAction();
			
			init();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			JSFUtility.redirect("errorPageGenerica.jsf");
		}
	}
	
	private void trovaIDUtente() throws Exception
	{
		idUtenteAssociato=(String)((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("idUtenteAssociato");
		if(idUtenteAssociato!=null && !idUtenteAssociato.equals(""))
		{
			idUtente=idUtenteAssociato;
			loggato=false;
		}
		else
		{	
			idUtente=(String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_UTENTE);
			
			if(idUtente==null)
				throw new Exception("[Impossibile individuare Utente loggato]");
			
			loggato=true;
		}
	}
	
//	private void determinaTipologiaUtente() throws Exception
//	{
//		tipologiaUtente=domandaAction.determinaTipologiaUtente(idUtente);
//	}
	
	// recupera dalla sessione il codice regione
	private void determinaStatoCandidatura() throws Exception
	{
		 HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		 String lingua= (String)session.getAttribute("linguaScelta");
		
		//se la domanda da visualizzare � propria di un utente associato specificato in sessione
		if(idUtenteAssociato!=null && !idUtenteAssociato.equals(""))
		{
			codiceStatoDomanda=(String)((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getAttribute("statoDomandaAssociato");
			if(codiceStatoDomanda!=null && !codiceStatoDomanda.equals(""))
			{
				statoDomanda=(String)TabellaDecodifica.decodificaStatoCandidatura(codiceStatoDomanda,lingua);
			}
		}
		else //se la domanda da visualizzare � propria dell'utente loggato (referente, associato o singolo)
		{
			candidatura=(Candidatura)GetSessionUtility.getSessionAttribute(RepositorySession.CANDIDATURA);
			if(candidatura!=null)
			{
				codiceStatoDomanda=candidatura.getStatoDomanda();
				if(codiceStatoDomanda!=null && !codiceStatoDomanda.equals(""))
				{
					statoDomanda=(String)TabellaDecodifica.decodificaStatoCandidatura(codiceStatoDomanda, lingua);
				}
			}
		}
		
		if(codiceStatoDomanda==null || codiceStatoDomanda.equals(""))
			throw new Exception("[ Impossibile determinare lo stato della domanda per l'associato (id:"+idUtente+") ]");
	}
	
	//recupera dalla sessione il codice regione 
	private void trovaDatiRegione() throws Exception
	{
		codiceRegione=(String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_REGIONE);
		if(codiceRegione==null)
			throw new Exception("[Impossibile individuare codice Regione]");
			
		RegioneDatiBando dati=(RegioneDatiBando)GetSessionUtility.getSessionAttribute(RepositorySession.REGIONI_DATI_BANDO);
		if(dati==null)
			throw new Exception("[Impossibile individuare regioniDatiBando]");
			
		denominazioneRegione=dati.getDenominazioneReg();
		if(denominazioneRegione==null)
			throw new Exception("[Impossibile individuare denominazione Regione]");
	}
	
	public void init()
	{
		try
		{
			//preleva dati dalla sessione -------------------------------------------------------------------------------------
			trovaIDUtente();
			//determinaTipologiaUtente();
			determinaStatoCandidatura();
			trovaDatiRegione();
			//------------------------------------------------------------------------------------------------------------------
			
			//inizializza i bean per la visualizzazione della domanda
			requisitiMinimiBeanVisualizzazione = new RequisitiMinimiBeanVisualizzazione();
			titoliStudioCarrieraBeanVisualizzazione = new TitoliStudioCarrieraBeanVisualizzazione();
			esercizioProfBeanVisualizzazione = new EsercizioProfBeanVisualizzazione();
			dichiarazioneSostitutivaBeanVisualizzazione = new DichiarazioneSostitutivaBeanVisualizzazione();
			
			boolean loadFromDB=true;
			
			//se la domanda appartiene all'utente loggato ed � ancora in bozza, prova a caricare i dati dai bean in sessione..
			//(� questo il caso in cui i dati vengono utilizzati per mostrare il riepilogo pre-conferma dell'invio)
			if(loggato && codiceStatoDomanda.equals("B"))
			{
				//cerca il bean relativo alla compilazione della domanda
				Domanda domanda=(Domanda)GetSessionUtility.getSessionAttribute("domanda");
				
				//se � presente in sessione..
				if(domanda!=null)
				{
					requisitiMinimiBeanVisualizzazione.init(domanda.getRequisitiMinimiBean());
					titoliStudioCarrieraBeanVisualizzazione.init(domanda.getTitoliStudioCarrieraBean());
					esercizioProfBeanVisualizzazione.init(domanda.getEsercizioProfBean());
					dichiarazioneSostitutivaBeanVisualizzazione.init(domanda.getDichiarazioneSostitutivaBean());
					DichiarazioneSostitutiva dichiarazioneSostitutiva = new DichiarazioneSostitutiva();
					
					dichiarazioneSostitutiva.setIban(dichiarazioneSostitutivaBeanVisualizzazione.getIban());
					dichiarazioneSostitutiva.setNumeroUffPostale(dichiarazioneSostitutivaBeanVisualizzazione.getNumeroUffPostale());
					titoliStudioCarrieraBeanVisualizzazione.setDichiarazioneSostitutiva(dichiarazioneSostitutiva);
					//in ultimo, disabilita il caricamento dai dati dal db
					
					titoliStudioCarrieraBeanVisualizzazione.controllaPubbl();
					loadFromDB=false;
				}
			}
			if(loadFromDB)//..altrimenti preleva i dati dal db
			{
				requisitiMinimiBeanVisualizzazione.init(idUtente);
				titoliStudioCarrieraBeanVisualizzazione.init(idUtente);
				esercizioProfBeanVisualizzazione.init(idUtente);
				dichiarazioneSostitutivaBeanVisualizzazione.init(idUtente);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			JSFUtility.redirect("errorPage.jsf");
		}
	}
	
	//gestisce il passaggio tra un tab e l'altro del wizard
	public String handleFlow(FlowEvent event)
	{
		//riporta il focus all'inizio della pagina
		JSFUtility.scrollTo("messaggioIniziale");
		return event.getNewStep();
	}

	public TitoliStudioCarrieraBeanVisualizzazione getTitoliStudioCarrieraBeanVisualizzazione() {
		return titoliStudioCarrieraBeanVisualizzazione;
	}


	public void setTitoliStudioCarrieraBeanVisualizzazione(
			TitoliStudioCarrieraBeanVisualizzazione titoliStudioCarrieraBeanVisualizzazione) {
		this.titoliStudioCarrieraBeanVisualizzazione = titoliStudioCarrieraBeanVisualizzazione;
	}

	public String getIdUtente()
	{
		return idUtente;
	}
	public void setIdUtente(String idUtente)
	{
		this.idUtente = idUtente;
	}

	public String getTipologiaUtente() {
		return tipologiaUtente;
	}

	public void setTipologiaUtente(String tipologiaUtente) {
		this.tipologiaUtente = tipologiaUtente;
	}

	public String getCodiceRegione() {
		return codiceRegione;
	}

	public void setCodiceRegione(String codiceRegione) {
		this.codiceRegione = codiceRegione;
	}
	
	public String getDenominazioneRegione() {
		return denominazioneRegione;
	}

	public void setDenominazioneRegione(String denominazioneRegione) {
		this.denominazioneRegione = denominazioneRegione;
	}

	public RequisitiMinimiBeanVisualizzazione getRequisitiMinimiBeanVisualizzazione() {
		return requisitiMinimiBeanVisualizzazione;
	}

	public void setRequisitiMinimiBeanVisualizzazione(
			RequisitiMinimiBeanVisualizzazione requisitiMinimiBeanVisualizzazione) {
		this.requisitiMinimiBeanVisualizzazione = requisitiMinimiBeanVisualizzazione;
	}

	public EsercizioProfBeanVisualizzazione getEsercizioProfBeanVisualizzazione() {
		return esercizioProfBeanVisualizzazione;
	}
	
	public void setEsercizioProfBeanVisualizzazione(
			EsercizioProfBeanVisualizzazione esercizioProfBeanVisualizzazione) {
		this.esercizioProfBeanVisualizzazione = esercizioProfBeanVisualizzazione;
	}

	public DichiarazioneSostitutivaBeanVisualizzazione getDichiarazioneSostitutivaBeanVisualizzazione() {
		return dichiarazioneSostitutivaBeanVisualizzazione;
	}

	public void setDichiarazioneSostitutivaBeanVisualizzazione(
			DichiarazioneSostitutivaBeanVisualizzazione dichiarazioneSostitutivaBeanVisualizzazione) {
		this.dichiarazioneSostitutivaBeanVisualizzazione = dichiarazioneSostitutivaBeanVisualizzazione;
	}

	public String getStatoDomanda() {
		return statoDomanda;
	}

	public void setStatoDomanda(String statoDomanda) {
		this.statoDomanda = statoDomanda;
	}

	public String getCodiceStatoDomanda() {
		return codiceStatoDomanda;
	}

	public void setCodiceStatoDomanda(String codiceStatoDomanda) {
		this.codiceStatoDomanda = codiceStatoDomanda;
	}
	
}