package com.accenture.CCFarm.PageBean;

import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Level;

import com.accenture.CCFarm.Bean.PartecipanteAssociazione;
import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.action.ListaPartecipantiAssAction;
import com.accenture.CCFarm.utility.CCFarmLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.MatricePropertiesDe;
import com.accenture.CCFarm.utility.RepositorySession;

@ManagedBean
@SessionScoped
public class ListaPartecipantiAssociazioneBean {

	private String idUtente;
	private String cognomeUtente;
	private String nomeUtente;

	private ArrayList<PartecipanteAssociazione> listaPartecipanti;
	
	private PartecipanteAssociazione partecipanteSelezionato;
	
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	private String lingua= (String)session.getAttribute("linguaScelta");
	MatricePropertiesDe matriceDe = MatricePropertiesDe.getMatricePropertiesDe(); 
	
	public ListaPartecipantiAssociazioneBean() {
		
		listaPartecipanti = new ArrayList<PartecipanteAssociazione>();
		partecipanteSelezionato = new PartecipanteAssociazione();
		try {
			init();
		} catch (Exception e) {
			
		}
		

	}

	
	public void init() throws GestioneErroriException {
		// recupero l'utente dalla sessione
		CCFarmLogger.log("ListaPartecipantiAssociazioneBean - init: " , Level.INFO_INT,
				CandidaturaHome.class);
		boolean isTedesco=false;
		idUtente = (String) getSessionScope().getAttribute(RepositorySession.ID_UTENTE);
		cognomeUtente = (String) getSessionScope()
				.getAttribute(RepositorySession.COGNOME_UTENTE);
		nomeUtente = (String) getSessionScope().getAttribute(RepositorySession.NOME_UTENTE );
		Candidatura candidatura = (Candidatura) getSessionScope().getAttribute(RepositorySession.CANDIDATURA);


		listaPartecipanti = new ArrayList<PartecipanteAssociazione>();
		ListaPartecipantiAssAction action = new ListaPartecipantiAssAction();
		try {
			if(lingua.equals("de")){
				isTedesco = true;
			}
			listaPartecipanti = action.loadPagina(idUtente, candidatura,isTedesco);
		} catch (Exception e) {
			LogUtil.printException(e);
			GestioneErroriException eccezione = new GestioneErroriException("ListaPartecipantiAssociazioneBean - init - 1 - ");
			LogUtil.printException(eccezione);
			throw eccezione;
		}

		

	}
	
	
	// @PostConstruct
	public void riattiva() throws IllegalAccessException {
		// modifico in bozza la candidatura di input

		ListaPartecipantiAssAction action = new ListaPartecipantiAssAction();
	
		idUtente = (String) getSessionScope().getAttribute(RepositorySession.ID_UTENTE);
	
		try {
			action.riattivaCandidatura(partecipanteSelezionato.getIdUtente(), idUtente);
			init();
			JSFUtility.update("listaPanel");
			JSFUtility.addInfoMessage("Conferma", "Operazione eseguita",false);
		} catch (Exception e) {
			JSFUtility.addWarningMessage("Conferma", "Operazione eseguita");
		}

	}

	
	public void visualizzaDomanda() throws IllegalAccessException {
		// recupero l'utente dalla sessione

		String idUtenteAssociato = partecipanteSelezionato.getIdUtente();
		String statoDomandaAssociato = partecipanteSelezionato.getCodStatoDomanda();
		 ((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("idUtenteAssociato", idUtenteAssociato);
		 ((HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(false)).setAttribute("statoDomandaAssociato", statoDomandaAssociato);
		 
		
		 JSFUtility.redirect("visualizzaDomanda.jsf");
		
	}
	
	
	
	public ArrayList<PartecipanteAssociazione> getListaPartecipanti() {
		return listaPartecipanti;
	}

	public void setListaPartecipanti(
			ArrayList<PartecipanteAssociazione> listaPartecipanti) {
		this.listaPartecipanti = listaPartecipanti;
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public String getCognomeUtente() {
		return cognomeUtente;
	}

	public void setCognomeUtente(String cognomeUtente) {
		this.cognomeUtente = cognomeUtente;
	}

	public String getNomeUtente() {
		return nomeUtente;
	}

	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}

	

	public PartecipanteAssociazione getPartecipanteSelezionato() {
		return partecipanteSelezionato;
	}


	public void setPartecipanteSelezionato(
			PartecipanteAssociazione partecipanteSelezionato) {
		this.partecipanteSelezionato = partecipanteSelezionato;
	}


	// ritorna l'istanza sessione http corrente
	private HttpSession getSessionScope() {
		return (HttpSession) FacesContext.getCurrentInstance()
				.getExternalContext().getSession(true);
	}


}
