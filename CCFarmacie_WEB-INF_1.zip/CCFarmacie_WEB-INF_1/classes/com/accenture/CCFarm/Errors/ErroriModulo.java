package com.accenture.CCFarm.Errors;

import java.util.ArrayList;
import java.util.HashMap;

import com.accenture.CCFarm.Exception.GestioneErroriException;


public class ErroriModulo
{
    private HashMap<String, String> errori = new HashMap<String, String>();
    ArrayList<Errore> erroriList = new ArrayList<Errore>();
    int counter = 0;
    
    public void addError(String etichetta, String erroreCampo)	    throws GestioneErroriException
    {
	
	if (errori.containsKey(etichetta))
	{
	    throw new GestioneErroriException(this.getClass().getName() + " :::: " + etichetta + " :::EISTE UN'ALTRA ETICHETTA UGUALE NELLA CLASSE");
	}
	else
	{
	    errori.put(etichetta, erroreCampo);
	    Errore errore = new Errore(etichetta,erroreCampo);
	    erroriList.add(errore);
	}
    }

    public String getErrore(String campo)
    {
	return this.errori.get(campo);
    }

    public boolean hasError()
    {	
	return erroriList.size() > counter ? true : false;
    }

    public Errore nextError()
    {
	return erroriList.get(counter++);
    }
}
