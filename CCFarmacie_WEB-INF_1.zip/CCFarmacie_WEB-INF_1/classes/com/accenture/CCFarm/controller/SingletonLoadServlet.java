package com.accenture.CCFarm.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CaricaRuoli;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.StaticDefinitions;

@SuppressWarnings("serial")
public class SingletonLoadServlet extends HttpServlet {

	@Override
	public void init() throws ServletException {
		try {
			StaticDefinitions.BASE_PATH = getServletContext().getRealPath("");
			Properties props = new Properties();
			props.load(new FileInputStream(StaticDefinitions.BASE_PATH+"/WEB-INF/conf/mailProperties.properties"));
			StaticDefinitions.MAIL_PROPERTIES = props;
			Localita.getDecodificaComuniMap();
			Localita.getDecodificaNazioniMap();
			Localita.getDecodificaProvinceMap();
			Localita.getDecodificaRegioniMap();
			try {
				CaricaRuoli.getRuoli();
			} catch (GestioneErroriException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {			
			throw new ServletException("FILE DI PROPERTIES NON TROVATO ",e);
		} catch (IOException e) {
			throw new ServletException("IMPOSSIBILE ACCEDERE IN LETTURA AL DISCO ",e);
		}
	}
	
	
}
