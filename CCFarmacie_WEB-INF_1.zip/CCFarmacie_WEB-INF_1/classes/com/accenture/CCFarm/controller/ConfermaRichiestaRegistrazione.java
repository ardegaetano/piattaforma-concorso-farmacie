package com.accenture.CCFarm.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.DAO.UtenteCandidaturaHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CriptDecriptUtil;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.StaticDefinitions;
import com.accenture.mailer.concorsofarma.GestoreMail;
import com.accenture.mailer.concorsofarma.data.MailBean;

public class ConfermaRichiestaRegistrazione extends HttpServlet  {
	private String aesKey  = AppProperties.getAppProperty("aesKey");
	 
	
	protected void service(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException {
		MailBean mailBean = new MailBean();
		String token = req.getParameter("token");
		String idUtente = "";
		String linguaScelta = "";
		boolean isTedesco = false;
		String nextJSP ="";
		// String user = req.getParameter("user");
		// String codRegione = req.getParameter("codRegione");
		String action = req.getParameter("action").trim();
	
		
      String tokenDecodificato = CriptDecriptUtil.decriptToken(token, aesKey);
		
      //verifica se � stata inserita la scelta della lingua
		if(tokenDecodificato.contains("$")){
				
			idUtente = tokenDecodificato.substring(0, tokenDecodificato.indexOf("$"));
			linguaScelta = tokenDecodificato.substring(tokenDecodificato.indexOf("$")+1);
				
				if(linguaScelta!=null&&!linguaScelta.equals("")){
					
					isTedesco=true;
					req.getSession().setAttribute("linguaScelta", linguaScelta);
					}
			}
        else {
			
				idUtente= tokenDecodificato;
			}
        
						
		//String idUtente = AESCryptoUtil.decriptaCookie(token, aesKey);
		if(isTedesco){
			
			     nextJSP = "/jsp/errorPageRichiestaRegistrazione_de.jsf";
			
		}else
			{
				 nextJSP = "/jsp/errorPageRichiestaRegistrazione.jsf";

			}
				
		
		
		LogIn logIn = null;
		LogInHome loginHome = new LogInHome();
		try {
			logIn = loginHome.findById(idUtente);
		
		} catch (GestioneErroriException e) {	e.printStackTrace();
			// se la fase di completamento della registrazione non da problemi
			// dare messaggio di ok altimenti mandare messaggio di ko
		if(isTedesco){
			nextJSP = "/jsp/errorPageRichiestaRegistrazione_de.jsf";	
		}
		else{
			nextJSP = "/jsp/errorPageRichiestaRegistrazione.jsf";	
		}
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
			dispatcher.forward(req, resp);
		}

		UtenteCandidaturaHome utenteCandidaturaHome = new UtenteCandidaturaHome();
		UtenteCandidatura utenteCandidatura = utenteCandidaturaHome.findById(logIn.getIdUtente());
		utenteCandidatura.setLogIn(logIn);

		req.getSession().setAttribute(AppProperties.getAppProperty("idRegioneRegistrata"),
		Localita.getDenominazioneRegione(logIn.getIdRegione()));
	
		if (action.equals("attiva") || action.equals("annulla")) {

			if ((utenteCandidatura != null)
					&& (utenteCandidatura.getCandidatura()
							.getStatoRegistrazione() != null && (!utenteCandidatura
							.getCandidatura().getStatoRegistrazione()
							.equalsIgnoreCase("C") && !utenteCandidatura
							.getCandidatura().getStatoRegistrazione()
							.equalsIgnoreCase("A")))) {
				// aggiorno utente

				if (action.equals("attiva")) {
					utenteCandidatura.getCandidatura().setStatoRegistrazione("C");
					utenteCandidatura.getCandidatura().setFlgPrimoAccesso("Y");

					mailBean.getToAddresses().add(utenteCandidatura.getPecMail());

					if(isTedesco){
					mailBean.setOggettoMail("Autonome Provinz Bozen - Au�erordentliche Ausschreibung f�r Apotheken. .Zusendung des Passwortes  - "
							+ utenteCandidatura.getNomeUtente() + " "
							+ utenteCandidatura.getCognomeUtente());
					setCorpoMailAccettazioneTedesco(utenteCandidatura, mailBean);			
					nextJSP = "/jsp/confermaMail_de.jsf";
					}
					else{
						mailBean.setOggettoMail("Regione "+ Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente())
								+ " � Concorso straordinario farmacie. Invio Password. - "
								+ utenteCandidatura.getNomeUtente() + " "
								+ utenteCandidatura.getCognomeUtente());
						setCorpoMailAccettazione(utenteCandidatura, mailBean);			
						nextJSP = "/jsp/confermaMail.jsf";
						}
					try {

						utenteCandidaturaHome.confermaCandidatura(utenteCandidatura, mailBean);

					} catch (GestioneErroriException e) {
						e.printStackTrace();
						// se la fase di completamento della registrazione non da problemi dare messaggio di ok altimenti mandare messaggio di ko
						if(isTedesco){
							nextJSP = "/jsp/errorPageRichiestaRegistrazione_de.jsf";
						}else{
							nextJSP = "/jsp/errorPageRichiestaRegistrazione.jsf";
						}
					}

				} else {

					// Cerco tutti gli utenti che fanno parte della candidatura e mando una mail ad ognuno di loro avvisandoli dell'annullamneto
					String query = "select u from UtenteCandidatura u where u.candidatura.idCandidatura = '"
							+ utenteCandidatura.getCandidatura().getIdCandidatura() + "'";
					try {
						List<UtenteCandidatura> listaCandidature = utenteCandidaturaHome.findByQuery(query);
						inviaMailDiAnnullamntoCandidatura(listaCandidature,	utenteCandidatura.getIdUtente(), isTedesco);
						if(isTedesco){
							inviaMailDiAnnullamntoCandidatura(listaCandidature,	utenteCandidatura.getIdUtente(), isTedesco);
							nextJSP = "/jsp/confermaAnnullamento_de.jsf";
						}else{
							inviaMailDiAnnullamntoCandidatura(listaCandidature,	utenteCandidatura.getIdUtente(), isTedesco);
							nextJSP = "/jsp/confermaAnnullamento.jsf";
						}
					} catch (GestioneErroriException e) {
						e.printStackTrace();
						// se la fase di completamento della registrazione non da problemi dare messaggio di ok altimenti mandare messaggio di ko
						if(isTedesco){
							
							nextJSP = "/jsp/errorPageRichiestaRegistrazione_de.jsf";
						}else{
						
							nextJSP = "/jsp/errorPageRichiestaRegistrazione.jsf";
						}
					}

				}

				
			} else {
				// mandare messaggio di ko utente per cui si chiede la registrazione non trovato se la fase di completamento della registrazione non da
				// problemi dare messaggio di ok altimenti mandare messaggio di ko
				if (action.equals("annulla")) {
					if ((utenteCandidatura != null)
							&& (utenteCandidatura.getCandidatura().getStatoRegistrazione() != null && utenteCandidatura
									.getCandidatura().getStatoRegistrazione()
									.equalsIgnoreCase("C"))) {
						if(isTedesco){
							
							nextJSP = "/jsp/utenteGiaRegistrato_de.jsf";
					
						}else{
						
							nextJSP = "/jsp/utenteGiaRegistrato.jsf";
						}
					} else {
						if(isTedesco){
							
							nextJSP = "/jsp/utenteGiaAnnullato_de.jsf";
						}else {
						
							nextJSP = "/jsp/utenteGiaAnnullato.jsf";
						}
					}

				} else {
					if ((utenteCandidatura != null)
							&& (utenteCandidatura.getCandidatura().getStatoRegistrazione() != null && utenteCandidatura.getCandidatura().getStatoRegistrazione()
									.equalsIgnoreCase("A"))) {
						if(isTedesco){
							nextJSP = "/jsp/utenteGiaAnnullato_de.jsf";
						}else{
						nextJSP = "/jsp/utenteGiaAnnullato.jsf";
						}
					} else {
						if(isTedesco){
						nextJSP = "/jsp/utenteGiaRegistrato_de.jsf";
						}else{
							nextJSP = "/jsp/utenteGiaRegistrato.jsf";
						}
					}

				}
			}

		}

		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
		dispatcher.forward(req, resp);
	}
	
	public void setCorpoMailAccettazione(UtenteCandidatura utenteCandidatura, MailBean mailBean){ 
		
		
		String pwdDecriptata = CriptDecriptUtil.decriptToken(utenteCandidatura.getLogIn().getPassword(), aesKey);
		
		String gentileCliente = "Gentile�Dott./Dott.ssa "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+"\r\n<br/>\r\n<br/> la Sua registrazione alla piattaforma del Concorso Farmacie � stata confermata.";
		String laSuaPassword ="La password per accedere al portale per la compilazione della candidatura � la seguente  ";
		String attivazione = "\r\n<br/>\r\n<br/>Al primo accesso sar� necessario modificare la password fornita. ";
		String navigazione = "\r\n<br/>\r\n<br/>Le ricordiamo che, come dalle condizioni d'uso da Lei sottoscritte, le credenziali di<br/>\r<br/>\rautenticazione, ed in particolare la password, Le sono state attribuite in modo esclusivo e\r\n<br/>\r\n<br/>non possono essere messe a disposizione di terzi, neppure in tempi diversi.\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>Cordiali saluti.";
		String attenzione = "\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>ATTENZIONE: Questa email � stata generata in automatico ed eventuali risposte alla stessa non verranno gestite.";

		mailBean.setCorpoMail("<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+laSuaPassword+"\r\n<br/>\r\n<br/>"+"Password: "+ pwdDecriptata +"\r\n<br/>\r\n<br/>"+attivazione+"\r\n<br/>\r\n<br/>"+navigazione+" \r\n<br/>\r\n<br/> "+attenzione+"</htlml>");
		
	}
	public void setCorpoMailAccettazioneTedesco(UtenteCandidatura utenteCandidatura, MailBean mailBean){ 
		
		
		String pwdDecriptata = CriptDecriptUtil.decriptToken(utenteCandidatura.getLogIn().getPassword(), aesKey);
		
		String gentileCliente = "Sehr geehrter Herr Dr./ Sehr geehrte Frau Dr.in "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+"\r\n<br/>\r\n<br/> Ihre Anmeldung f�r die Plattform f�r die au�erordentliche Ausschreibung f�r Apotheken wurde best�tigt.";
		String laSuaPassword ="Das Passwort f�r den Zugang zum Portal f�r die Ausf�llung der Bewerbung ist  ";
		String attivazione = "\r\n<br/>\r\n<br/>Beim ersten Zugang muss das Passwort ge�ndert werden. ";
		String navigazione = "\r\n<br/>\r\n<br/>Es wird daran erinnert, dass laut den von Ihnen unterschriebenen Nutzungsbedingungen die <br/>\r<br/>\rZugangsdaten , und insbesondere das Passwort pers�nlich sind und zu keiner Zeit \r\n<br/>\r\n<br/>Dritten zur Verf�gung gestellt werden k�nnen.\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/> Mit freundlichen Gr��en. ";
		String attenzione = "\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>ACHTUNG: Automatisch generierte E-Mail. Etwaige Antworten auf diese E-Mail werden nicht bearbeitet.";
		mailBean.setCorpoMail("<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+laSuaPassword+"\r\n<br/>\r\n<br/>"+"Passwort: "+ pwdDecriptata +"\r\n<br/>\r\n<br/>"+attivazione+"\r\n<br/>\r\n<br/>"+navigazione+" \r\n<br/>\r\n<br/> "+attenzione+"</htlml>");
		
	}
	
	public void setCorpoMailRifiuto(UtenteCandidatura utenteCandidatura, MailBean mailBean){ 
		
		String gentileCliente = "Gentile�Dott./Dott.ssa "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" \r\n<br/>\r\n<br/>la Sua registrazione alla piattaforma del Concorso Farmacie � stata annullata.";
		String saluti = "Cordiali saluti.";
		String attenzione = "\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>ATTENZIONE: Questa email � stata generata in automatico ed eventuali risposte alla stessa non verranno gestite.";
		
		mailBean.setCorpoMail("<html>"+gentileCliente +"\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>"+saluti+"\r\n<br/>\r\n<br/>" +"\r\n<br/>\r\n<br/>"+attenzione+"\r\n<br/>\r\n<br/>" +"</htlml>");
		
	}
	public void setCorpoMailRifiutoTedesco(UtenteCandidatura utenteCandidatura, MailBean mailBean){ 
		
		String gentileCliente = "Sehr geehrter Herr Dr. / Sehr geehrte Frau Dr.in  "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" \r\n<br/>\r\n<br/>Ihre Anmeldung bei der Plattform der Ausschreibung f�r Apotheken wurde annulliert.";
		String saluti = "Mit freundlichen Gr��en.";
		String attenzione = "\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>ACHTUNG: Automatisch generierte E-Mail.  Etwaige Antworten auf diese E-Mail werden nicht bearbeitet.";
		
		mailBean.setCorpoMail("<html>"+gentileCliente +"\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>"+saluti+"\r\n<br/>\r\n<br/>" +"\r\n<br/>\r\n<br/>"+attenzione+"\r\n<br/>\r\n<br/>" +"</htlml>");
		
	}
	
		public void setCorpoMailRifiutoAssociati(UtenteCandidatura utenteCandidatura, MailBean mailBean){ 
		
		String gentileCliente = "Gentile�Dott./Dott.ssa "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" \r\n<br/>\r\n<br/>";
		String annullamento ="la Sua registrazione alla piattaforma del Concorso Farmacie � stata annullata poich� uno o pi� associati hanno annullato la propria registrazione.\r\n<br/>\r\n<br/> ";
		String nuovoInserimento="L'inserimento di una nuova candidatura per la stessa Regione o la stessa Provincia Autonoma pu� essere effettuato esclusivamente a seguito di una nuova registrazione alla piattaforma.";
		String saluti = "Cordiali saluti.";
		String attenzione = "\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>ATTENZIONE: Questa email � stata generata in automatico ed eventuali risposte alla stessa non verranno gestite.";
		
		mailBean.setCorpoMail("<html>"+gentileCliente +annullamento+nuovoInserimento+"\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>"+saluti+"\r\n<br/>\r\n<br/>" +"\r\n<br/>\r\n<br/>"+attenzione+"\r\n<br/>\r\n<br/>" +"</htlml>");
		
	}
		public void setCorpoMailRifiutoAssociatiTedesco(UtenteCandidatura utenteCandidatura, MailBean mailBean){ 
			
			String gentileCliente = "Sehr geehrter Herr Dr. / Sehr geehrte Frau Dr.in   "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" \r\n<br/>\r\n<br/>";
			String annullamento ="Seine Aufnahme der Plattform Apotheken Wettbewerb wurde abgebrochen, weil ein oder mehrere Mitglieder haben ihre Registrierung gel�scht.\r\n<br/>\r\n<br/> ";
			String nuovoInserimento="Die Eingabe einer neuen Bewerbung f�r die gleiche Region oder gleiche autonome Provinz kann nur nach einer neuen Anmeldung bei der Plattform erfolgen.";
			String saluti = "Mit freundlichen Gr��en.";
			String attenzione = "\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>ACHTUNG: Automatisch generierte E-Mail.  Etwaige Antworten auf diese E-Mail werden nicht bearbeitet.";
			
			mailBean.setCorpoMail("<html>"+gentileCliente +annullamento+nuovoInserimento+"\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>"+saluti+"\r\n<br/>\r\n<br/>" +"\r\n<br/>\r\n<br/>"+attenzione+"\r\n<br/>\r\n<br/>" +"</htlml>");
			
		}

	public void inviaMailDiAnnullamntoCandidatura(List<UtenteCandidatura> instance , String idUtenteAnnullante, boolean isTedesco)	throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		
		try {
			UtenteCandidatura utenteCandidatura = null;
			GestoreMail gestoreMail = new GestoreMail();
			MailBean mailBean = null;
			int[] indiciMail = new int[instance.size()];
			java.sql.Connection conn = session.connection();

			Query query = session.createQuery("Update Candidatura set STATO_REGISTRAZIONE = 'A' where ID_CANDIDATURA ='" + instance.get(0).getCandidatura().getIdCandidatura() +"'");
			query.executeUpdate();
			
			if(isTedesco){
				
				for (int i = 0; i < instance.size(); i++) {
					
					utenteCandidatura = instance.get(i);
					if(!utenteCandidatura.getIdUtente().equalsIgnoreCase(idUtenteAnnullante)){
						
						mailBean = new MailBean();
						mailBean.getToAddresses().add(utenteCandidatura.getPecMail());
						mailBean.setOggettoMail("Autonome Provinz Bozen  �  Abmeldung des Vereins -" + utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente());
						setCorpoMailRifiutoAssociatiTedesco(utenteCandidatura, mailBean);
						// SALVATAGGIO AUTOMATICO DELLEk INFORMAZIONI della mail
						indiciMail[i] = gestoreMail.saveMail(mailBean,	StaticDefinitions.MAIL_PROPERTIES, conn);
				   }else{
					    mailBean = new MailBean();
					    mailBean.getToAddresses().add(utenteCandidatura.getPecMail());
					    mailBean.setOggettoMail("Autonome Provinz Bozen   - Abmeldung des Vereins -" + utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente());
					    setCorpoMailRifiutoTedesco(utenteCandidatura, mailBean);
					    // SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
					    indiciMail[i] = gestoreMail.saveMail(mailBean,	StaticDefinitions.MAIL_PROPERTIES, conn);
				   }
					utenteCandidatura.getCandidatura().setStatoRegistrazione("A");
					utenteCandidatura.getCandidatura().setStatoDomanda("A");
					session.saveOrUpdate(utenteCandidatura);
				}
				
			}
			else{
			
				for (int i = 0; i < instance.size(); i++) {
					
					utenteCandidatura = instance.get(i);
					if(!utenteCandidatura.getIdUtente().equalsIgnoreCase(idUtenteAnnullante)){
						
						mailBean = new MailBean();
						mailBean.getToAddresses().add(utenteCandidatura.getPecMail());
						mailBean.setOggettoMail("Regione "+Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente()) + " - Annullamento registrazione dell'associazione -" + utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente());
						setCorpoMailRifiutoAssociati(utenteCandidatura, mailBean);
						// SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
						indiciMail[i] = gestoreMail.saveMail(mailBean,	StaticDefinitions.MAIL_PROPERTIES, conn);
				   }else{
					    mailBean = new MailBean();
					    mailBean.getToAddresses().add(utenteCandidatura.getPecMail());
					    mailBean.setOggettoMail("Regione "+Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente()) + " - Annullamento registrazione dell'associazione -" + utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente());
					    setCorpoMailRifiuto(utenteCandidatura, mailBean);
					    // SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
					    indiciMail[i] = gestoreMail.saveMail(mailBean,	StaticDefinitions.MAIL_PROPERTIES, conn);
				   }
					utenteCandidatura.getCandidatura().setStatoRegistrazione("A");
					utenteCandidatura.getCandidatura().setStatoDomanda("A");
					session.saveOrUpdate(utenteCandidatura);
				}
			}

			trx.commit();
			
			for (int i = 0; i < indiciMail.length; i++) {
				try {
					gestoreMail.sendMail(indiciMail[i],	StaticDefinitions.MAIL_PROPERTIES, conn);
				} catch (Throwable thr) {
					
				}
			}

		} catch (Exception e) {
			
			GestioneErroriException eccezione = new GestioneErroriException("UtenteCandidaturaHome - inserisciCandidatura: errore nell' inserimento della candidatuira",e);
			throw eccezione;
		} finally {
			session.close();
		}
	}
}
