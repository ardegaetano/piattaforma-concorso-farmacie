package com.accenture.CCFarm.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.DAO.UtenteCandidaturaHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AESCryptoLongUtil;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.RecuperaProtocollo;
import com.accenture.mailer.concorsofarma.data.MailBean;

public class ConfermaRegistrazioneNuovaPec extends HttpServlet  {
	
	
	protected void service(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException {
		
		MailBean mailBean = new MailBean();
		String token = req.getParameter("token");
		String action = req.getParameter("action").trim();
		String aesKey128 = AppProperties.getAppProperty("aesKey128");
		String lingua = (req.getParameter("lingua")!=null) ? req.getParameter("lingua").trim() : req.getParameter("lingua");

		String tokenDecriptato = AESCryptoLongUtil.decrypt(token, aesKey128,128);
		String idUtente = tokenDecriptato.substring(0,tokenDecriptato.indexOf("$"));
		String mailPec = tokenDecriptato.substring(tokenDecriptato.indexOf("$")+1).trim();
		
		String nextJSP = (lingua!=null && lingua.equals("de")) ? "/jsp/errorPageRichiestaAttivazioneNewPec_de.jsf" : "/jsp/errorPageRichiestaAttivazioneNewPec.jsf";

		LogIn logIn = new LogIn();
		LogInHome loginHome = new LogInHome();
		try {
			logIn = loginHome.findByIdHql(idUtente);
		} catch (GestioneErroriException e) {	e.printStackTrace();

			nextJSP = (lingua!=null && lingua.equals("de")) ? "/jsp/errorPageRichiestaAttivazioneNewPec_de.jsf" : "/jsp/errorPageRichiestaAttivazioneNewPec.jsf";			
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
			dispatcher.forward(req, resp);
		}

		UtenteCandidaturaHome utenteCandidaturaHome = new UtenteCandidaturaHome();
		UtenteCandidatura utenteCandidatura = utenteCandidaturaHome.findById(logIn.getIdUtente());
		
		//Imposto la lingua
		req.getSession().setAttribute("lingua", lingua);
		
		if  (utenteCandidatura.getNewPecMail()!= null && utenteCandidatura.getNewPecMail().trim().equals(mailPec)){
			utenteCandidatura.setLogIn(logIn);
		
			req.getSession().setAttribute(AppProperties.getAppProperty("idRegioneRegistrata"),
			Localita.getDenominazioneRegione(logIn.getIdRegione()));


				if (action.equals("attiva") &&
					"I".equalsIgnoreCase(utenteCandidatura.getRichiestaCambioPecMail())) 
				{
					
					mailBean.getToAddresses().add(utenteCandidatura.getNewPecMail());
					
					//recupero numero protocollo
					RecuperaProtocollo recuperaProtocollo = new RecuperaProtocollo();
					String protocollo = null;
					try {
						protocollo = recuperaProtocollo.getProtocolloRegionale(utenteCandidatura.getIdUtente());
					} catch (GestioneErroriException e1) {
						e1.printStackTrace();
						nextJSP = (lingua!=null && lingua.equals("de")) ? "/jsp/errorPageRichiestaAttivazioneNewPec_de.jsf" : "/jsp/errorPageRichiestaAttivazioneNewPec.jsf";
					}
					
					if (protocollo==null){
						protocollo = "N.D";
					}
					
					
					nextJSP = (lingua!=null && lingua.equals("de")) ? "/jsp/confermaPecMail_de.jsf" : "/jsp/confermaPecMail.jsf";
					
					try {
						utenteCandidaturaHome.confermaNuovaPec(utenteCandidatura.getIdUtente(), mailBean);
					} catch (GestioneErroriException e) {
						e.printStackTrace();
						nextJSP = (lingua!=null && lingua.equals("de")) ? "/jsp/errorPageRichiestaAttivazioneNewPec_de.jsf" : "/jsp/errorPageRichiestaAttivazioneNewPec.jsf";
					}

				} 
				
				// link rifiuto � stato tolto
				else if (action.equals("attiva") &&
					"F".equalsIgnoreCase(utenteCandidatura.getRichiestaCambioPecMail())) 
				{
					try {
						annullaRichiestaNuovaPec(utenteCandidatura);
						nextJSP = "/jsp/errorOutOfTimeRichiestaAttivazioneNewPec.jsf";
						
					} catch (GestioneErroriException e) {
						
						e.printStackTrace();
						nextJSP = (lingua!=null && lingua.equals("de")) ? "/jsp/errorPageRichiestaAttivazioneNewPec_de.jsf" : "/jsp/errorPageRichiestaAttivazioneNewPec.jsf";
					}

				}
				else 
				{
					nextJSP = (lingua!=null && lingua.equals("de")) ? "/jsp/errorLinkNewPecNonAttivo_de.jsf" : "/jsp/errorLinkNewPecNonAttivo.jsf";
				}

		} else 	{
			//Pec gi� attiva
			if(utenteCandidatura.getNewPecMail()== null && (utenteCandidatura.getPecCambiata()!=null && utenteCandidatura.getPecCambiata().equals("Y"))) {
				utenteCandidatura.setLogIn(logIn);
				req.getSession().setAttribute(AppProperties.getAppProperty("idRegioneRegistrata"),
				Localita.getDenominazioneRegione(logIn.getIdRegione()));
			
				nextJSP = (lingua!=null && lingua.equals("de")) ? "/jsp/confermaPecMail_de.jsf" : "/jsp/confermaPecMail.jsf";	
			}
			else
				nextJSP = (lingua!=null && lingua.equals("de")) ? "/jsp/errorPecNonUguale_de.jsf" : "/jsp/errorPecNonUguale.jsf";		
		}
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
		dispatcher.forward(req, resp);
	
	}
	
//	public void setCorpoMailAccettazione(UtenteCandidatura utenteCandidatura, MailBean mailBean){ 
//		
//		
//		String pwdDecriptata = AESCryptoUtil.decriptaCookie(utenteCandidatura.getLogIn().getPassword(), aesKey);
//		String gentileCliente= null;
//		if((utenteCandidatura.getSesso()).equalsIgnoreCase("M")){
//			
//			gentileCliente = "Gentile Dott. "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+"\r\n<br/>\r\n<br/>il Suo indirizzo email PEC per la piattaforma del Concorso Farmacie � stato modificato.";
//			
//		}else {
//			
//			gentileCliente = "Gentile Dott.ssa "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+"\r\n<br/>\r\n<br/>il Suo indirizzo email PEC per la piattaforma del Concorso Farmacie � stato modificato.";
//		 
//		}
//		
//		String saluti = "\r\n<br/>\r\n<br/>Cordiali saluti. ";
//		String attenzione = "\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>ATTENZIONE: Questa email � stata generata in automatico ed eventuali risposte alla stessa non verranno gestite.";
//
//		mailBean.setCorpoMail("<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+saluti+"\r\n<br/>\r\n<br/>"+attenzione+"</htlml>");
//		
//	}
	
	public void setCorpoMailRifiuto(UtenteCandidatura utenteCandidatura, MailBean mailBean){ 
		
		String gentileCliente= null;
		if((utenteCandidatura.getSesso()).equalsIgnoreCase("M")){
			
			gentileCliente = "Gentile Dott. "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" \r\n<br/>\r\n<br/> la Sua richiesta di modifica di email PEC per la piattaforma del Concorso Farmacie � stata annullata.";;
			
		}else {
			
			gentileCliente = "Gentile Dott.ssa "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" \r\n<br/>\r\n<br/> la Sua richiesta di modifica di email PEC per la piattaforma del Concorso Farmacie � stata annullata.";
		 
		}
		
		String saluti = "\r\n<br/>\r\n<br/>Cordiali saluti.";
		String attenzione = "\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>ATTENZIONE: Questa email � stata generata in automatico ed eventuali risposte alla stessa non verranno gestite.";
		
		mailBean.setCorpoMail("<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+saluti+"\r\n<br/>\r\n<br/>" +"\r\n<br/>\r\n<br/>"+attenzione+"\r\n<br/>\r\n<br/>" +"</htlml>");
		
	}
	
	public void annullaRichiestaNuovaPec(UtenteCandidatura utenteCandidatura)	throws GestioneErroriException {
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		
		try {

//			GestoreMail gestoreMail = new GestoreMail();
//			MailBean mailBean = null;
//
//			java.sql.Connection conn = session.connection();
//
//			
//			mailBean = new MailBean();
//		    mailBean.getToAddresses().add(utenteCandidatura.getPecMail());
//		    
//		    //recupero numero protocollo
//			RecuperaProtocollo recuperaProtocollo = new RecuperaProtocollo();
//			String protocollo = recuperaProtocollo.getProtocolloRegionale(utenteCandidatura.getIdUtente());
//			
//			if (protocollo==null){
//				
//				protocollo = "N.D";
//			}
//			
//		    mailBean.setOggettoMail("Regione "+Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente()) + " � Concorso straordinario farmacie. - Annullamento modifica indirizzo PEC. - " 
//		    + utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" - N. Protocollo "+protocollo);
//		    setCorpoMailRifiuto(utenteCandidatura, mailBean);
//				    // SALVATAGGIO AUTOMATICO DELLE INFORMAZIONI della mail
//			int indiciMail = gestoreMail.saveMail(mailBean,	StaticDefinitions.MAIL_PROPERTIES, conn);
//			
			// nel caso di annullamento 
			
			UtenteCandidaturaHome utCandhome = new UtenteCandidaturaHome ();
			utCandhome.annullaNuovaPec (utenteCandidatura.getIdUtente()/*, mailBean*/);
	
			// fine

			trx.commit();

		} catch (Exception e) {
			
			GestioneErroriException eccezione = new GestioneErroriException("ConfermaRegistrazioneNuovaPec - inviaMailDiAnnullamntoNuovaPec: errore nell' annullamento della nuova PEC",e);
			throw eccezione;
		} finally {
			session.close();
		}
	}
}
