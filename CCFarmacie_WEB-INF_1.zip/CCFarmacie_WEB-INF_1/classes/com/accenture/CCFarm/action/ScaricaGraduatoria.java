package com.accenture.CCFarm.action;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoriaHome;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.RepositorySession;


public class ScaricaGraduatoria extends HttpServlet {
	 
	Logger logger = CommonLogger.getLogger("ScaricaGraduatoria");
	
    public ScaricaGraduatoria() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	try {
			//recupero dalla Session	
			HttpSession session = request.getSession();
	    	String codiceRegione = (String) session.getAttribute(RepositorySession.ID_REGIONE);
	    	
	    	//codiceRegione = "200"; //TEST Sardegna
	    	
	        TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
	        TipoGraduatoria tipoGraduatoria = new TipoGraduatoria();
	        tipoGraduatoria = tipoGraduatoriaHome.findLastPubblicata(codiceRegione);
	        
	        byte[] graduatoria = tipoGraduatoria.getGraduatoriaPDF();
    		
	       
	       
	    
            response.reset(); 
            response.setContentType("application/pdf"); 
            response.setContentLength((int) graduatoria.length); 
            response.setHeader("Content-disposition", "attachment; filename=\"Graduatoria.pdf\"");
            ByteArrayInputStream in = null;             
            BufferedInputStream input = null; 
            BufferedOutputStream output = null; 
            final int buffersize = graduatoria.length; 
	            
        	in = new ByteArrayInputStream(graduatoria);
        	input = new BufferedInputStream(in); 
        	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
        	byte[] buffer = new byte[buffersize]; 
        	for (int length; (length = input.read(buffer)) > 0;) 
        	{	 
        		output.write(buffer, 0, length); 
        	}            	
	        
    	} catch (Exception e) {
    		logger.error("ScaricaGraduatoria: " + e);
    		response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/errorPageGenerica.jsf");
    	}
	    	
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	
}
