package com.accenture.CCFarm.action;



import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.accenture.CCFarm.DAO.RegioneDatiBando;
import com.accenture.CCFarm.PageBean.InfoRegCartina;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.RepositorySession;

/**
 * Servlet implementation class CaricoBandoRegione
 */

public class CaricoBandoRegione extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CaricoBandoRegione() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		
		String idRegine = (String) request.getParameter(RepositorySession.ID_REGIONE);
		
		HashMap map = (HashMap) request.getSession().getAttribute(RepositorySession.MAP_REGIONE);
		Map sessionMap = null;

		if (map!=null && map.containsKey(idRegine)){
			InfoRegCartina  infoRegCartina = new InfoRegCartina();
			infoRegCartina=  (InfoRegCartina) map.get(idRegine);
			RegioneDatiBando regioneDatiBando = infoRegCartina.getRegioneDatiBando();
			request.getSession().setAttribute(RepositorySession.ID_REGIONE, idRegine);
			request.getSession().setAttribute(RepositorySession.DATI_BANDO, regioneDatiBando.getDatiBando());
			request.getSession().setAttribute(RepositorySession.REGIONI_DATI_BANDO, regioneDatiBando);
			request.getSession().setAttribute(RepositorySession.STATO_BANDO_REGIONE, infoRegCartina.getColoreRegione());
//		    try {
//	            sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
//	        } catch (Exception e) {
//	            e.printStackTrace();
//	        }
//		    sessionMap.put("ID_REGIONE", idRegine);
//		    sessionMap.put("DATI_BANDO", regioneDatiBando.getDatiBando());
//		    sessionMap.put("REGIONI_DATI_BANDO", regioneDatiBando);
//		    sessionMap.put("STATO_BANDO_REGIONE", infoRegCartina.getColoreRegione());
			
//			FacesContext context = FacesContext.getCurrentInstance();
//			context.getExternalContext().getSessionMap().put("ID_REGIONE", idRegine);
//			context.getExternalContext().getSessionMap().put("DATI_BANDO", regioneDatiBando.getDatiBando());
//			context.getExternalContext().getSessionMap().put("REGIONI_DATI_BANDO", regioneDatiBando);
//			context.getExternalContext().getSessionMap().put("STATO_BANDO_REGIONE", infoRegCartina.getColoreRegione());

		}
		
		
		
//		if (GenericConstants.SERVER_ABSOLUTE_PATH.equals(""))
//   		{
//            String url = request.getHeader("Referer");
//            String hostName = null;
//            String appName = null;
//            int countToken = 1;
//            StringTokenizer st = new StringTokenizer(url,"/");
//            while(st.hasMoreTokens()){
//            	String token = st.nextToken();
//            	if(countToken == 2)
//            		hostName = token;
//            	if(token.startsWith(request.getSession().getServletContext().getServletContextName().toUpperCase())){
//            		appName = token;
//            		break;
//            	}
//            	countToken++;
//            }
//            
//            if(appName==null) appName = AppProperties.getAppProperty("app_Name");
//            url = url.substring(0, url.indexOf(hostName)+hostName.length());
//            url += "/"+appName;
//            
//            GenericConstants.SERVER_ABSOLUTE_PATH = url;
//    
//
//   		}
//				
//		response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/loginCandidato.jsp");
		response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/loginCandidato.jsp");
//	
//		LoginBean bean = new LoginBean();
//		bean.redirectLogin();
	}

}
