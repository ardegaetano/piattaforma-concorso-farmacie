package com.accenture.CCFarm.action;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.DAO.RegioneDatiBando;
import com.accenture.CCFarm.DAO.RegioneDatiBandoHome;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoriaHome;
import com.accenture.CCFarm.DAO.TipoGraduatoriaId;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PageBean.InfoRegCartina;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.StringUtil;

public class StatoBandoRegione {
	SimpleDateFormat fs = new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss");
	Logger logger = CommonLogger.getLogger("StatoBandoRegione");

	public StatoBandoRegione() {
		// TODO Auto-generated constructor stub
	}

	public HashMap getInfoRegione() {
		HashMap map = new HashMap();
		try {
			RegioneDatiBandoHome regioneDatiBandoHome = new RegioneDatiBandoHome();
			List<RegioneDatiBando> infoRegioni = new ArrayList<RegioneDatiBando>();
			infoRegioni = (List<RegioneDatiBando>) regioneDatiBandoHome.findByExample(new RegioneDatiBando());
			GraduatoriaPubblicaRegione graduatoriaPubblicaRegione = new GraduatoriaPubblicaRegione();

//			Collections.sort(infoRegioni, Collections.reverseOrder());

			Collections.sort(infoRegioni);

			// Regione reg = (Regione)infoRegioni.get(0);
			// DatiBando dat = reg.getDatiBando();
			// SimpleDateFormat fs=new SimpleDateFormat("dd/MM/yyyy");
			Date sysDate = new Date(System.currentTimeMillis());

			logger.info("sys data = " + sysDate);

			int sysDataInt = trasformaData(sysDate);
			int sysOraInt = recuperaOra(sysDate);
			//
						
			for (int i = 0; i < infoRegioni.size(); i++) {
				RegioneDatiBando regioneDatiBando = new RegioneDatiBando();
				regioneDatiBando = (RegioneDatiBando) infoRegioni.get(i);
				InfoRegCartina infoRegCartina = new InfoRegCartina();
				infoRegCartina.setColoreRegione("G");
				infoRegCartina.setRegioneDatiBando(regioneDatiBando);
				if (regioneDatiBando.getDatiBando() != null) {
					if (regioneDatiBando.getDatiBando().getDataInizioBando() != null) {
						infoRegCartina.setDataIni(fs.format(regioneDatiBando.getDatiBando().getDataInizioBando()));
					}
					if (regioneDatiBando.getDatiBando().getDataFineBando() != null) {
						infoRegCartina.setDataFin(fs.format(regioneDatiBando.getDatiBando().getDataFineBando()));
					}
					infoRegCartina.setStat(regioneDatiBando.getDatiBando().getStato());
					// infoRegCartina.setColoreRegione("G");
					// if (datiBando.getStato().equalsIgnoreCase("0")){
					// infoRegCartina.setColoreRegione("G");
					// } else {
					if (regioneDatiBando.getDatiBando().getStato().equalsIgnoreCase("1")) {
						int dataIni = trasformaData(regioneDatiBando.getDatiBando().getDataInizioBando());
						int dataFin = trasformaData(regioneDatiBando.getDatiBando().getDataFineBando());
						int oraFinInt = recuperaOra(regioneDatiBando.getDatiBando().getDataFineBando());
						int dataFinDue = calcolaData(regioneDatiBando.getDatiBando().getDataFineBando());

						if (sysDataInt >= dataIni && sysDataInt < dataFinDue) {
							infoRegCartina.setColoreRegione("V");
						}
						if (sysDataInt >= dataFinDue && sysDataInt <= dataFin) {
							infoRegCartina.setColoreRegione("Y");
						}
						if (sysDataInt == dataFin) {
							if (sysOraInt > oraFinInt) {
								infoRegCartina.setColoreRegione("R");
							} else {
								infoRegCartina.setColoreRegione("Y");
							}
						} else {
							if (sysDataInt > dataFin) {
								infoRegCartina.setColoreRegione("R");
							}
						}
					    
						//Controlla se la data di sistema ricade nella fase interpello attiva (range: data inizio interpello - data fine accettazione)
						//Se c'� un interpello attivo mettiamo la regione in marrone altrimenti si vede se deve essere blue 
						//if(interpelloHome.controllaPresenzaInterpelloPubblicato((regioneDatiBando.getCodReg()))) {
					    if(isFaseInterpelloAttiva(regioneDatiBando.getCodReg())) {
							infoRegCartina.setColoreRegione("M");
					    }else{	
							//sezione per colorare la cartina di blue						
							if (infoRegCartina.getColoreRegione().equalsIgnoreCase("R")){
								String trovato = "NO";
								trovato = graduatoriaPubblicaRegione.getGraduatoriaPubbColoreCartinaString(regioneDatiBando.getDatiBando().getCodReg());
								if (trovato.equalsIgnoreCase("SI")){
	//							if (graduatoriaPubblicaRegione.getGraduatoriaPubbColoreCartina(regioneDatiBando.getDatiBando().getCodReg())){
									infoRegCartina.setColoreRegione("B");	
								}	
							}
					    }
						
					}
				}
				
				map.put(regioneDatiBando.getCodReg(), infoRegCartina);
			}

		} catch (GestioneErroriException e) {
			logger.error("StatoBandoRegione - recupero informazioni cartina: "
					+ e);
			LogUtil.printException(e);
			// JSFUtility.redirect("errorPageGenerica.jsf");
		}

		return map;

	}

	private int trasformaData(Date data) {
		String dataString = fs.format(data);
		String dataConfert = dataString.substring(6, 10)
				+ dataString.substring(3, 5) + dataString.substring(0, 2);
		return Integer.parseInt(dataConfert);
	}

	private int recuperaOra(Date data) {
		String dataString = StringUtil.dateToString(data, sdf);
		String dataConfert = dataString.substring(13, 15)
				+ dataString.substring(16, 18) + dataString.substring(19, 21);
		return Integer.parseInt(dataConfert);
	}

	private int trasformaDataSting(String data) {
		// String dataString = fs.format(data);
		String dataConfert = data.substring(6, 10) + data.substring(3, 5)
				+ data.substring(0, 2);
		return Integer.parseInt(dataConfert);
	}

	private int calcolaData(Date data) {
		String dataGregorian = StringUtil.dateToString(data, sdf);

		Calendar cal = Calendar.getInstance();
		String result = "";
		try {
			cal.setTime(data);
			cal.add(Calendar.DATE, -9);
			result = StringUtil.dateToString(cal.getTime(), sdf);
		} catch (Exception e) {
		}

		return trasformaDataSting(result);
	}

	private static String dataTOString(Date w_date) {
		Calendar cal = Calendar.getInstance();
		String result = "";
		try {
			cal.setTime(w_date);
			cal.add(Calendar.DATE, -9);

			// Set time fields to zero
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			SimpleDateFormat formatterOut = new SimpleDateFormat("dd-MM-yyyy");
			result = formatterOut.format(cal.getTime());

		} catch (Exception e) {
		}
		return result;

	}
	
	private boolean getPubblicazione(RegioneDatiBando regioneDatiBando, int sysDataInt) throws GestioneErroriException{
		
		boolean gradPubblicata = false;
		TipoGraduatoria   tipoGraduatoria    = new TipoGraduatoria();
		TipoGraduatoriaId tipoGraduatoriaId  = new TipoGraduatoriaId();
		TipoGraduatoriaHome tipoGraduatoriaHome =  new TipoGraduatoriaHome();
		tipoGraduatoria.setCodRegione(regioneDatiBando.getCodReg());
		tipoGraduatoria.setProgressivo(regioneDatiBando.getDatiBando().getProgTipoGraduatoria());
		tipoGraduatoriaId.setCodRegione(regioneDatiBando.getCodReg());
		tipoGraduatoriaId.setProgressivo(regioneDatiBando.getDatiBando().getProgTipoGraduatoria());
		tipoGraduatoria.setIdKey(tipoGraduatoriaId);
		tipoGraduatoria = tipoGraduatoriaHome.findById(tipoGraduatoriaId);
	    if(tipoGraduatoria.getStatoGraduatoria()!=null &&tipoGraduatoria.getStatoGraduatoria().equals("P")  ){
//	       if (tipoGraduatoria.getStatoGraduatoria().equals("P")  && 
//	    	   trasformaData(tipoGraduatoria.getDataPublicazione())>= sysDataInt){
//	    	   
//	       }
	    	gradPubblicata = true;
	    } 
				
		
		return gradPubblicata;
		
	}
	
	private boolean isFaseInterpelloAttiva(String codReg) throws GestioneErroriException{

		boolean bRet = false;
	    InterpelloHome interpelloHome = new  InterpelloHome();
	    Interpello interpello = interpelloHome.determinaInterpelloCorrentePubblicatoChiuso(codReg);
	    if(interpello!=null) {
		    Date dataInizio = (Timestamp)interpello.getDataInizio();
		    Date dataFine = (Timestamp)interpello.getDataFineAccettazione();
		    
		    //se data sistema >= dataInizio e data fine non valorizzata oppure data sistema <= dataFine
		    if((!new Date().before(dataInizio)) && (dataFine==null || (!new Date().after(dataFine))))
		    	bRet = true;
	    }
		return bRet;
	}

}
