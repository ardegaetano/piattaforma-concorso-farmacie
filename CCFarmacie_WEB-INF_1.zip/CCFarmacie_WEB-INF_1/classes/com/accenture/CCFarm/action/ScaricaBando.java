package com.accenture.CCFarm.action;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.RepositorySession;


public class ScaricaBando extends HttpServlet {	
	 
	Logger logger = CommonLogger.getLogger("ScaricaBando");
	
    public ScaricaBando() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	try {
			//recupero dalla Session	
			HttpSession session = request.getSession();
	    	String codiceRegione = (String) session.getAttribute(RepositorySession.ID_REGIONE);
	    	
	    	//codiceRegione = "200"; //TEST Sardegna
	    	
	    	DatiBandoHome bandoHome = new DatiBandoHome();
	    	DatiBando datiBando = bandoHome.findById(codiceRegione);
	    	byte[] pdfData = datiBando.getFileBando();
	    	
            response.reset(); 
            response.setContentType("application/pdf"); 
            response.setContentLength((int) pdfData.length); 
            response.setHeader("Content-disposition", "attachment; filename=\"Bando.pdf\"");
            ByteArrayInputStream in = null;             
            BufferedInputStream input = null; 
            BufferedOutputStream output = null; 
            final int buffersize = pdfData.length; 
	            
        	in = new ByteArrayInputStream(pdfData);
        	input = new BufferedInputStream(in); 
        	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
        	byte[] buffer = new byte[buffersize]; 
        	for (int length; (length = input.read(buffer)) > 0;) 
        	{	 
        		output.write(buffer, 0, length); 
        	}            	
	        
    	} catch (Exception e) {
    		logger.error("ScaricaBando: " + e);
    		response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/errorPageGenerica.jsf");
    	}
	    	
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	
}
