package com.accenture.CCFarm.action;

import java.util.Date;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.DAO.AnagraficaFarm;
import com.accenture.CCFarm.DAO.AnagraficaFarmHome;
import com.accenture.CCFarm.DAO.Comune;
import com.accenture.CCFarm.DAO.ComuneHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.Provincia;
import com.accenture.CCFarm.DAO.ProvinciaHome;
import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PageBean.ConsultaSediBean;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.StringUtil;


public class ConsultaSediAction{
	

	public ConsultaSediAction(){
		
	}
	
    public void loadPaginaInserimento(ConsultaSediBean consultaSediBean) throws GestioneErroriException{
    	
    	//RECUPERO DALLA SESSIONE
    	
    	FacesContext context = FacesContext.getCurrentInstance();
    	//HttpSession session = (HttpSession)context.getExternalContext().getSession(true);
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	String idRegione = (String) session.getAttribute("ID_REGIONE");
    	
// Regione   	
    	Regione regione = new Regione();
    	RegioneHome regioneHome = new RegioneHome();
    	
    	DatiBando datiBando = new DatiBando();
    	DatiBandoHome datiBandoHome = new DatiBandoHome();
    	
    	regione =  regioneHome.findById(idRegione);
    	datiBando = datiBandoHome.findById(idRegione);
    	consultaSediBean.setRegioniDesc(regione.getDenominazioneReg());
//numero sedi disponibili
    	AnagraficaFarm anagraficaFarm = new AnagraficaFarm();
    	AnagraficaFarmHome anagraficaFarmHome =new AnagraficaFarmHome();
    	anagraficaFarm.setCodRegFarm(idRegione);
    	consultaSediBean.setListAnaFarm(anagraficaFarmHome.findByExample(anagraficaFarm));
    	Date dtPubblicazioneSedi = (Date)datiBando.getDataPubblicazioneSedi();
    	if(dtPubblicazioneSedi!=null)
    		consultaSediBean.setDataAggiornamentoSedi(StringUtil.dateToStringDDMMYYYY(dtPubblicazioneSedi));
    	
//    	int num = consultaSediBean.getListAnaFarm().size();
    	consultaSediBean.setNumeroSediDisponibili(""+consultaSediBean.getListAnaFarm().size());
    	
		consultaSediBean.setProvinceSelect(Localita.getProvince(idRegione));
		consultaSediBean.setProvinceList(consultaSediBean.getProvinceSelect().get(idRegione));

    	
    }
    
    public String getDesProvincia(String codProv) throws GestioneErroriException{
		Provincia provincia = new Provincia();
		ProvinciaHome provinciaHome =  new ProvinciaHome();
		provincia=provinciaHome.findById(codProv);
    	if (provincia!=null)
    		return provincia.getDenominazioneProvincia();
    	else
    		return "";
    }
    public String getDesComuini(String codCom) throws GestioneErroriException {
    	Comune comune = new Comune();
    	ComuneHome comuneHome =  new ComuneHome();
		comune=comuneHome.findById(codCom);
		if (comune!=null)
    	    return comune.getDenominazione();
		else
			return "";
    }
    
    
}