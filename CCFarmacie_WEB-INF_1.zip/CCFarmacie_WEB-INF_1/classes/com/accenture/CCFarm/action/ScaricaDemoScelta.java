package com.accenture.CCFarm.action;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;


public class ScaricaDemoScelta extends HttpServlet {
	 
	Logger logger = CommonLogger.getLogger("ScaricaDemoScelta");
	
    public ScaricaDemoScelta() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	doPost(	request, response);
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
    	try {
    		String path="";
    		String fileName="";
    		if(request.getSession().getAttribute("linguaScelta").equals("it")){
    			 path = "/DEMO_Candidato_interpello_sceltasedi.pdf";
    			 fileName="DEMO_Candidato_interpello_sceltasedi.pdf";
    		}else{
    			 //path = "/Demo_de.pdf";
    			 //fileName="Demo_de.pdf";
    			 path = "/DEMO_Candidato_interpello_sceltasedi_de.pdf";
   			 	 fileName="DEMO_Candidato_interpello_sceltasedi_de.pdf";
    		}
    		
    		
    		
    		InputStream streamB = getResource( path );
	    	byte[] pdfData = IOUtils.toByteArray(streamB);
	    	
            response.reset(); 
            response.setContentType("application/pdf"); 
            response.setContentLength((int) pdfData.length); 
            response.setHeader("Content-disposition", "attachment; filename=\""+fileName+"\"");
            ByteArrayInputStream in = null;             
            BufferedInputStream input = null; 
            BufferedOutputStream output = null; 
            final int buffersize = pdfData.length; 
            try {
	        	in = new ByteArrayInputStream(pdfData);
	        	input = new BufferedInputStream(in); 
	        	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
	        	byte[] buffer = new byte[buffersize]; 
	        	for (int length; (length = input.read(buffer)) > 0;) 
	        	{	 
	        		output.write(buffer, 0, length); 
	        	}            	
	        } finally {
	        	if(input!=null){
	        		try {
	        			input.close();
	        			output.close();
	        		}catch (IOException ioex) {
	        			logger.info("ScaricaDemo: Annulla operazione" + ioex);
	            	}	
	        	}
	        }        	
    	} catch (Exception e) {
    		logger.error("ScaricaDemo: " + e);
    		response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/errorPageGenerica.jsf");
    	}		
	}
	
	private InputStream getResource(String resourcePath) {
		ServletContext servletContext = getServletContext();
		InputStream openStream = servletContext.getResourceAsStream( resourcePath );
		return openStream;
	}
	
}
