package com.accenture.CCFarm.action;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;

import com.accenture.CCFarm.Bean.EsercizioProfessionale;
import com.accenture.CCFarm.Bean.ParafarmacieSearch;
import com.accenture.CCFarm.DAO.EsercizioProf;
import com.accenture.CCFarm.DAO.EsercizioProfHome;
import com.accenture.CCFarm.DAO.FarmacieHome;
import com.accenture.CCFarm.DAO.FarmacieSearch;
import com.accenture.CCFarm.DAO.ParafarmacieHome;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PageBean.EsercizioProfBean;
import com.accenture.CCFarm.PageBean.EsercizioProfBeanVisualizzazione;
import com.accenture.CCFarm.utility.CaricaRuoli;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.MatriceProperties;
import com.accenture.CCFarm.utility.MatricePropertiesDe;
import com.accenture.CCFarm.utility.StringUtil;


//@SuppressWarnings("serial")
public class EsercizioProfAction
{
	java.util.Date date;
    
    java.util.Date dataSys= new java.util.Date();
    private java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
    Logger logger =Logger.getLogger("Bando");
	Utente utente;
	UtenteHome utenteHome;
    
	EsercizioProf esercizioProf;
	EsercizioProfHome esercizioProfHome;
	EsercizioProfessionale esercizioProfessionale;
	ArrayList<EsercizioProf> eserciziProf;
	ArrayList<EsercizioProfessionale> listaEserciziProfessionali;
	private SimpleDateFormat sdf = new SimpleDateFormat();
	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	 String lingua= (String)session.getAttribute("linguaScelta");
	 
   MatriceProperties matriceIt = MatriceProperties.getMatricePropertiesIt();
   MatricePropertiesDe matriceDe = MatricePropertiesDe.getMatricePropertiesDe();
	public EsercizioProfAction()
	{
		utenteHome=new UtenteHome();
		esercizioProfHome=new EsercizioProfHome();
		esercizioProf = new EsercizioProf();
	}
	
    public boolean loadPaginaInserimento(String idDomanda,EsercizioProfBean esercizioProfBean) throws GestioneErroriException 
    {
    	try
    	{
    		
    		//Localita localita = new Localita();
    		eserciziProf = new ArrayList<EsercizioProf>();
    		esercizioProf = new EsercizioProf();
    		esercizioProf.setIdDomandaEs(idDomanda);
    		eserciziProf = (ArrayList<EsercizioProf>) esercizioProfHome.findByExample(esercizioProf);
    		
    		listaEserciziProfessionali = new ArrayList<EsercizioProfessionale>();
    		
    		if(eserciziProf!=null){
    			for (int i=0;i<eserciziProf.size();i++){
    				EsercizioProfessionale esercizio_appoggio = new EsercizioProfessionale();
    				BeanUtils.copyProperties(esercizio_appoggio,eserciziProf.get(i));
    				
    				sdf = new SimpleDateFormat("dd-MM-yyyy");
    		        esercizio_appoggio.setDataInizioStringa(StringUtil.dateToString(esercizio_appoggio.getDataInizioEs(),sdf));
    		        
    		        sdf = new SimpleDateFormat("dd-MM-yyyy");
    		        esercizio_appoggio.setDataFineStringa(StringUtil.dateToString(esercizio_appoggio.getDataFineEs(),sdf));
    				
//    				esercizio_appoggio.setComuneDescrizione(localita.getDenominazioneComune(esercizio_appoggio.getComuneEs()));
//    				esercizio_appoggio.setRegDescrizione(localita.getDenominazioneRegione(esercizio_appoggio.getRegEs()));
//    				esercizio_appoggio.setPrvDescrizione(localita.getDenominazioneProvincia(esercizio_appoggio.getPrvEs()));
    		       
    				if(lingua.equalsIgnoreCase("de")){
    					
    					if(esercizio_appoggio.getCodModalitaEs().equals("0")){
          					 esercizio_appoggio.setModalitaTempoDescr("Teilzeit");  
       					}
       					if(esercizio_appoggio.getCodModalitaEs().equals("1")){
          		        	esercizio_appoggio.setModalitaTempoDescr("Vollzeit");
       					}
    					
    				}else{
    					if(esercizio_appoggio.getCodModalitaEs().equals("0")){
       					 esercizio_appoggio.setModalitaTempoDescr("Tempo parziale");  
    					}
    					if(esercizio_appoggio.getCodModalitaEs().equals("1")){
       		        	esercizio_appoggio.setModalitaTempoDescr("Tempo pieno");
    					}
    				}
    				
    		       
    			
    		     
    		        if(lingua.equalsIgnoreCase("de")){
    		        	   esercizio_appoggio.setDescrizioneRuolo(CaricaRuoli.decodificaRuolo(esercizio_appoggio.getCodRuoloEs(),lingua)); 
    		        	if(esercizio_appoggio.getCodCategoriaEs().equals("0")){
        		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Apotheke");
        		          }
        		        if(esercizio_appoggio.getCodCategoriaEs().equals("1")){
        		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Andere");
        		         }
        		        if(esercizio_appoggio.getCodCategoriaEs().equals("3")){
        		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Kommerzieller_Betrieb_L.248/2006");
        		         }
    		        	
    		        }else{
    		        	   esercizio_appoggio.setDescrizioneRuolo(CaricaRuoli.decodificaRuolo(esercizio_appoggio.getCodRuoloEs(),lingua)); 
    		        	if(esercizio_appoggio.getCodCategoriaEs().equals("0")){
        		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Farmacia");
        		          }
        		        if(esercizio_appoggio.getCodCategoriaEs().equals("1")){
        		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Altro");
        		         }
        		        if(esercizio_appoggio.getCodCategoriaEs().equals("3")){
        		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Esercizio commerciale L.248/2006");
        		         }
    		        }
    		        
    				
    		        esercizio_appoggio.setIdDomandaEs(esercizio_appoggio.getIdDomandaEs());
    		        
    		        if(lingua.equalsIgnoreCase("de")){
    		        	
         				if(esercizio_appoggio.getFlagFarmRurale().equals("Si")){
         				esercizio_appoggio.setFlagFarmRurale("Ja");
		        		}
         				if(esercizio_appoggio.getFlagFarmRurale().equals("No")){
         				esercizio_appoggio.setFlagFarmRurale("Nein");
			        	}
		        	}else {
		        		if(esercizio_appoggio.getFlagFarmRurale().equals("Si")){
	         				esercizio_appoggio.setFlagFarmRurale("Si");
			        		}
	         			if(esercizio_appoggio.getFlagFarmRurale().equals("No")){
	         			esercizio_appoggio.setFlagFarmRurale("No");
		        	
		        	
				      	}
             	   }
    				
    				listaEserciziProfessionali.add(esercizio_appoggio);
    				
    			}
    		
    		}  
    		esercizioProfBean.setListaEserciziProfessionali(listaEserciziProfessionali);
    		
    		if(!listaEserciziProfessionali.isEmpty())
    		{
//	    		System.out.println("*********************************************************");
//	    		System.out.println("valore asl: "+listaEserciziProfessionali.get(0).getAslDenom());
//	    		System.out.println("valore asl: "+listaEserciziProfessionali.get(0).getAslEs());
    		}
    		
    	}	
	    	
    	catch(RuntimeException re)
    	{
    		re.printStackTrace();
    		return false;
    	}
	    
   		catch(IllegalAccessException e)
   		{
			e.printStackTrace();
			return false;
		}
   		catch(InvocationTargetException e)
   		{
			e.printStackTrace();
			return false;
		}
   		
   		return true;
    }
    
    public boolean loadPaginaInserimentoVisualizzazione (String idDomanda,EsercizioProfBeanVisualizzazione esercizioProfBeanVisualizzazione) throws GestioneErroriException 
    {
    	try
    	{
    		
    		eserciziProf = new ArrayList<EsercizioProf>();
    		esercizioProf = new EsercizioProf();
    		esercizioProf.setIdDomandaEs(idDomanda);
    		eserciziProf = (ArrayList<EsercizioProf>) esercizioProfHome.findByExample(esercizioProf);
    		
    		listaEserciziProfessionali = new ArrayList<EsercizioProfessionale>();
    		
    		if(eserciziProf!=null){
    			for (int i=0;i<eserciziProf.size();i++){
    				EsercizioProfessionale esercizio_appoggio = new EsercizioProfessionale();
    				BeanUtils.copyProperties(esercizio_appoggio,eserciziProf.get(i));
    				
    				sdf = new SimpleDateFormat("dd-MM-yyyy");
    		        esercizio_appoggio.setDataInizioStringa(StringUtil.dateToString(esercizio_appoggio.getDataInizioEs(),sdf));
    		        
    		        sdf = new SimpleDateFormat("dd-MM-yyyy");
    		        esercizio_appoggio.setDataFineStringa(StringUtil.dateToString(esercizio_appoggio.getDataFineEs(),sdf));
    				
    		        
    		        if(Localita.getDenominazioneComune(esercizio_appoggio.getComuneEs())!=null&&!Localita.getDenominazioneComune(esercizio_appoggio.getComuneEs()).equals("")){
    		        	esercizio_appoggio.setComuneDescrizione(Localita.getDenominazioneComune(esercizio_appoggio.getComuneEs()));
    		        	}else{
    		        		esercizio_appoggio.setComuneDescrizione(esercizio_appoggio.getComuneEs());
    		        	}
    				
    		        if(Localita.getDenominazioneRegione(esercizio_appoggio.getRegEs())!=null&&!Localita.getDenominazioneRegione(esercizio_appoggio.getRegEs()).equals("")){
    				esercizio_appoggio.setRegDescrizione(Localita.getDenominazioneRegione(esercizio_appoggio.getRegEs()));
    					}else{
    						esercizio_appoggio.setPrvDescrizione(esercizio_appoggio.getPrvEs());
    					}
    				
    				if(Localita.getDenominazioneProvincia(esercizio_appoggio.getPrvEs())!=null&&!Localita.getDenominazioneProvincia(esercizio_appoggio.getPrvEs()).equals("")){
    				esercizio_appoggio.setPrvDescrizione(Localita.getDenominazioneProvincia(esercizio_appoggio.getPrvEs()));
    					}else{
    						esercizio_appoggio.setRegDescrizione(esercizio_appoggio.getRegEs());
    					}
    				

    				if(lingua.equalsIgnoreCase("de")){
    					
    					if(esercizio_appoggio.getCodModalitaEs().equals("0")){
          					 esercizio_appoggio.setModalitaTempoDescr("Teilzeit");  
       					}
       					if(esercizio_appoggio.getCodModalitaEs().equals("1")){
          		        	esercizio_appoggio.setModalitaTempoDescr("Vollzeit");
       					}
    					
    				}else{
    					if(esercizio_appoggio.getCodModalitaEs().equals("0")){
       					 esercizio_appoggio.setModalitaTempoDescr("Tempo parziale");  
    					}
    					if(esercizio_appoggio.getCodModalitaEs().equals("1")){
       		        	esercizio_appoggio.setModalitaTempoDescr("Tempo pieno");
    					}
    				}
    				
    		       
    		      
    		        esercizio_appoggio.setDescrizioneRuolo(CaricaRuoli.decodificaruolo(esercizio_appoggio.getCodRuoloEs())); 
    		        
    		        if(lingua.equalsIgnoreCase("de")){
 		        	   esercizio_appoggio.setDescrizioneRuolo(CaricaRuoli.decodificaRuolo(esercizio_appoggio.getCodRuoloEs(),lingua)); 
 		        	if(esercizio_appoggio.getCodCategoriaEs().equals("0")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Apotheke");
     		          }
     		        if(esercizio_appoggio.getCodCategoriaEs().equals("1")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Andere");
     		         }
     		        if(esercizio_appoggio.getCodCategoriaEs().equals("3")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Kommerzieller_Betrieb_L.248/2006");
     		         }
 		        	
 		        }else{
 		        	   esercizio_appoggio.setDescrizioneRuolo(CaricaRuoli.decodificaRuolo(esercizio_appoggio.getCodRuoloEs(),lingua)); 
 		        	if(esercizio_appoggio.getCodCategoriaEs().equals("0")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Farmacia");
     		          }
     		        if(esercizio_appoggio.getCodCategoriaEs().equals("1")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Altro");
     		         }
     		        if(esercizio_appoggio.getCodCategoriaEs().equals("3")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Esercizio commerciale L.248/2006");
     		         }
 		        }
 		        
    				
    		        esercizio_appoggio.setIdDomandaEs(esercizio_appoggio.getIdDomandaEs());
    		        
                    if(lingua.equalsIgnoreCase("de")){
    		        	
         				if(esercizio_appoggio.getFlagFarmRurale().equals("Si")){
         				esercizio_appoggio.setFlagFarmRurale("Ja");
		        		}
         				if(esercizio_appoggio.getFlagFarmRurale().equals("No")){
         				esercizio_appoggio.setFlagFarmRurale("Nein");
			        	}
		        	}else {
		        		if(esercizio_appoggio.getFlagFarmRurale().equals("Si")){
	         				esercizio_appoggio.setFlagFarmRurale("Si");
			        		}
	         			if(esercizio_appoggio.getFlagFarmRurale().equals("No")){
	         			esercizio_appoggio.setFlagFarmRurale("No");
		        	
		        	
				      	}
             	   }
    				
    				listaEserciziProfessionali.add(esercizio_appoggio);
    					
    			}
    		
    		}  
    		esercizioProfBeanVisualizzazione.setListaEserciziProfessionali(listaEserciziProfessionali);
    		//System.out.println("*********************************************************");
    		if(!listaEserciziProfessionali.isEmpty()){
//    		System.out.println("valore asl: "+listaEserciziProfessionali.get(0).getAslDenom());
//    		System.out.println("valore asl: "+listaEserciziProfessionali.get(0).getAslEs());
    		}
    		
    	}	
	    	
    	catch(RuntimeException re)
    	{
    		re.printStackTrace();
    		return false;
    	}
	    
   		catch(IllegalAccessException e)
   		{
			e.printStackTrace();
			return false;
		}
   		catch(InvocationTargetException e)
   		{
			e.printStackTrace();
			return false;
		}
   		
   		return true;
    }
    
    public boolean loadPaginaInserimentoVisualizzazione(EsercizioProfBean esercizioProfBean,EsercizioProfBeanVisualizzazione esercizioProfBeanVisualizzazione) throws Exception
    {
    	
    	
    	try
    	{
    		
    		if(esercizioProfBean==null || esercizioProfBeanVisualizzazione==null)
        		throw new Exception("[Visualizzazione Domanda: Impossibile inizializzare Esercizi Professionali]");
    		
  		
    		listaEserciziProfessionali = new ArrayList<EsercizioProfessionale>();
    		
    		if(esercizioProfBean!=null){
    			for (int i=0;i<esercizioProfBean.getListaEserciziProfessionali().size();i++){
    				EsercizioProfessionale esercizio_appoggio = new EsercizioProfessionale();
    				BeanUtils.copyProperties(esercizio_appoggio,esercizioProfBean.getListaEserciziProfessionali().get(i));
    				
    				sdf = new SimpleDateFormat("dd-MM-yyyy");
    		        esercizio_appoggio.setDataInizioStringa(StringUtil.dateToString(esercizio_appoggio.getDataInizioEs(),sdf));
    		        
    		        sdf = new SimpleDateFormat("dd-MM-yyyy");
    		        esercizio_appoggio.setDataFineStringa(StringUtil.dateToString(esercizio_appoggio.getDataFineEs(),sdf));
    				
    		        
    		        if(Localita.getDenominazioneComune(esercizio_appoggio.getComuneEs())!=null&&!Localita.getDenominazioneComune(esercizio_appoggio.getComuneEs()).equals("")){
    		        	esercizio_appoggio.setComuneDescrizione(Localita.getDenominazioneComune(esercizio_appoggio.getComuneEs()));
    		        	}else{
    		        		esercizio_appoggio.setComuneDescrizione(esercizio_appoggio.getComuneEs());
    		        	}
    				
    		        if(Localita.getDenominazioneRegione(esercizio_appoggio.getRegEs())!=null&&!Localita.getDenominazioneRegione(esercizio_appoggio.getRegEs()).equals("")){
    				esercizio_appoggio.setRegDescrizione(Localita.getDenominazioneRegione(esercizio_appoggio.getRegEs()));
    					}else{
    						esercizio_appoggio.setPrvDescrizione(esercizio_appoggio.getPrvEs());
    					}
    				
    				if(Localita.getDenominazioneProvincia(esercizio_appoggio.getPrvEs())!=null&&!Localita.getDenominazioneProvincia(esercizio_appoggio.getPrvEs()).equals("")){
    				esercizio_appoggio.setPrvDescrizione(Localita.getDenominazioneProvincia(esercizio_appoggio.getPrvEs()));
    					}else{
    						esercizio_appoggio.setRegDescrizione(esercizio_appoggio.getRegEs());
    					}
    				
    					if(lingua.equalsIgnoreCase("de")){
    					
    					if(esercizio_appoggio.getCodModalitaEs().equals("0")){
          					 esercizio_appoggio.setModalitaTempoDescr("Teilzeit");  
       					}
       					if(esercizio_appoggio.getCodModalitaEs().equals("1")){
          		        	esercizio_appoggio.setModalitaTempoDescr("Vollzeit");
       					}
    					
    				}else{
    					if(esercizio_appoggio.getCodModalitaEs().equals("0")){
       					 esercizio_appoggio.setModalitaTempoDescr("Tempo parziale");  
    					}
    					if(esercizio_appoggio.getCodModalitaEs().equals("1")){
       		        	esercizio_appoggio.setModalitaTempoDescr("Tempo pieno");
    					}
    				}
    		       
    		      
    		        esercizio_appoggio.setDescrizioneRuolo(CaricaRuoli.decodificaruolo(esercizio_appoggio.getCodRuoloEs())); 
    		        
    		        if(lingua.equalsIgnoreCase("de")){
 		        	   esercizio_appoggio.setDescrizioneRuolo(CaricaRuoli.decodificaRuolo(esercizio_appoggio.getCodRuoloEs(),lingua)); 
 		        	if(esercizio_appoggio.getCodCategoriaEs().equals("0")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Apotheke");
     		          }
     		        if(esercizio_appoggio.getCodCategoriaEs().equals("1")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Andere");
     		         }
     		        if(esercizio_appoggio.getCodCategoriaEs().equals("3")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Kommerzieller_Betrieb_L.248/2006");
     		         }
 		        	
 		        }else{
 		        	   esercizio_appoggio.setDescrizioneRuolo(CaricaRuoli.decodificaRuolo(esercizio_appoggio.getCodRuoloEs(),lingua)); 
 		        	if(esercizio_appoggio.getCodCategoriaEs().equals("0")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Farmacia");
     		          }
     		        if(esercizio_appoggio.getCodCategoriaEs().equals("1")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Altro");
     		         }
     		        if(esercizio_appoggio.getCodCategoriaEs().equals("3")){
     		        	esercizio_appoggio.setTipologiaEsercizioDescrizione("Esercizio commerciale L.248/2006");
     		         }
 		        }
 		        
    				
    		        esercizio_appoggio.setIdDomandaEs(esercizio_appoggio.getIdDomandaEs());
    		       
    		        if(esercizio_appoggio.getFlagFarmRurale()==null || esercizio_appoggio.getFlagFarmRurale().equals(""))
    		        {
    		        	esercizio_appoggio.setFlagFarmRurale("-");
    		        }
    		        else
    		        { 
    		        	 if(lingua.equals("de")){   
    		        		if(esercizio_appoggio.getFlagFarmRurale().equals("Si")){
    		        			esercizio_appoggio.setFlagFarmRurale("Ja");
    		        		}
    		        		 if(esercizio_appoggio.getFlagFarmRurale().equals("No")){
    		        			 esercizio_appoggio.setFlagFarmRurale("Nein");
    			        	}
    		        	}else {
    		        		if(esercizio_appoggio.getFlagFarmRurale().equals("Si")){
    		        			esercizio_appoggio.setFlagFarmRurale("Si");
    				  		}
    		        		if(esercizio_appoggio.getFlagFarmRurale().equals("No")){
    		        			esercizio_appoggio.setFlagFarmRurale("No");
    		        	
    		        	
    				      	}
                 	   }
    	           }	
    				listaEserciziProfessionali.add(esercizio_appoggio);
    					
    			}
    		
    		}  
    		esercizioProfBeanVisualizzazione.setListaEserciziProfessionali(listaEserciziProfessionali);
    		System.out.println("*********************************************************");
    		if(!listaEserciziProfessionali.isEmpty()){
    		System.out.println("valore asl: "+listaEserciziProfessionali.get(0).getAslDenom());
    		System.out.println("valore asl: "+listaEserciziProfessionali.get(0).getAslEs());
    		}
    		
    	}	
	    	
    	catch(RuntimeException re)
    	{
    		re.printStackTrace();
    		return false;
    	}
	    
   		catch(IllegalAccessException e)
   		{
			e.printStackTrace();
			return false;
		}
   		catch(InvocationTargetException e)
   		{
			e.printStackTrace();
			return false;
		}
   		
   		return true;
    }
    
    public boolean updateDAO(String idDomanda,EsercizioProfBean esercizioProfBean) throws GestioneErroriException 
	{
	
			//preleva i dati dal bean di pagina e li copia nei bean di hibernate
			try
					{
						EsercizioProfessionale eseProf_appoggio = new EsercizioProfessionale();
				        ArrayList<EsercizioProfessionale> listaEserciziProfessionali;
				        listaEserciziProfessionali = (ArrayList<EsercizioProfessionale>)esercizioProfBean.getListaEserciziProfessionali();
				        
				        eserciziProf = new ArrayList<EsercizioProf>();
				        esercizioProf = new EsercizioProf();
						
						if(listaEserciziProfessionali!=null){
							for (int i=0;i<listaEserciziProfessionali.size();i++){
								
							
								eseProf_appoggio = listaEserciziProfessionali.get(i);
								
								esercizioProf = new EsercizioProf();
								
								BeanUtils.copyProperties(esercizioProf,eseProf_appoggio);
								
								esercizioProf.setIdDomandaEs(idDomanda);
								
								esercizioProf.setIdEsercizio(esercizioProfHome.getSequenceIdEsercizioProfessionale());
	
								eserciziProf.add(esercizioProf);
								 
							}
						
						}
						
					}
			
			catch(IllegalAccessException  e)
				{
					e.printStackTrace();
					return false;
				}
			
			catch(InvocationTargetException e)
				{
					e.printStackTrace();
					return false;
				}	
		
			catch(RuntimeException re)
				{
					re.printStackTrace();
					return false;
				}
	
			
			return true;

}
    
	
//	private String controlliCampi(EsercizioProfBean esercizioProfBean) {
//		
//	    String msg = "";
//	
//	    if(utente==null)
//	    	utente=utenteHome.findById((String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_UTENTE));
//	    
//	    Date dataNascitaUtente = utente.getDataNascitaUtente();
//	    // da ricavare da DB (DATI_BANDO.DATA_PUBBLICAZIONE_BANDO, DATI_BANDO.DATA_INIZIO_PUBBLICAZIONI) specifico per regione (DATI_BANDO.COD_REG)
//	    Date dataPubblicazioneBando;
//	    Date datInizioPubblicazione;
//	    
//	    
//	    Date dataInizio = esercizioProfBean.getDataInizioEs();
//	    Date dataFine = esercizioProfBean.getDataFineEs();
//	    
//	    
//	    if (dataInizio!= null && dataInizio.before(dataNascitaUtente)){
//	    	msg = msg + "Data Inizio Esercizio Professionale errata - la data Inizio Esercizio Professionale deve essere successiva alla data di nascita";
//	    }
////	    if (dataInizio!= null && dataInizio.after(dataPubblicazioneBando)|| dataInizio.equals(dataPubblicazioneBando)){
////	    	msg = msg + "Data Inizio Esercizio Professionale errata - la data Pubblicazione deve essere antecedente o uguale alla data Pubblicazione Bando";
////        }
//	    if (dataInizio!= null && dataFine!=null && dataInizio.before(dataFine)){
//	    	msg = msg + "Date incongruenti - la data inizio Inizio Esercizio Professionale deve essere inferiore alla data Fine Esercizio Professionale";
//	    }
//	    
//	
//	return msg;
//}  
	
	
		
	  public List<FarmacieSearch> ricerca(EsercizioProfBean esercizioProfBean) throws GestioneErroriException{
	    	FarmacieHome farmacieHome=new FarmacieHome();
	    	FarmacieSearch farmacieSearch = new FarmacieSearch();
	    	farmacieSearch.setCodRg(esercizioProfBean.getRegioneSelezionata());
	    	farmacieSearch.setCodIstatProv(esercizioProfBean.getProvinciaSelezionata());
	    	farmacieSearch.setCodIstatComu(esercizioProfBean.getComuneSelezionato());
	    	farmacieSearch.setpIva(esercizioProfBean.getPartitaIVA());
	    	farmacieSearch.setCodCap(esercizioProfBean.getCodCap());
	    	farmacieSearch.setIndirizzo(esercizioProfBean.getIndirizzo());
	    	farmacieSearch.setIdMinisetro(esercizioProfBean.getIdEsercizio());
	    	List<FarmacieSearch> farmList = farmacieHome.findByFilter(farmacieSearch);
	    
  	return farmList ;
  }
  
	  public List<ParafarmacieSearch> ricercaParafarmacie (EsercizioProfBean esercizioProfBean) throws GestioneErroriException {
		   ParafarmacieHome parafarmacieHome = new ParafarmacieHome();
		   ParafarmacieSearch parafarmacieSearch = new ParafarmacieSearch();
		   List<ParafarmacieSearch> parafarmList = new ArrayList<ParafarmacieSearch>();
		   parafarmacieSearch.setCodCap(esercizioProfBean.getCodCapParafarmacie());
		   parafarmacieSearch.setCodCmn(esercizioProfBean.getComuneSelezionatoParafarmacia());
		   parafarmacieSearch.setCodProvincia(esercizioProfBean.getProvinciaSelezionataParafarmacia());
		   parafarmacieSearch.setCodPva(esercizioProfBean.getPartitaIVAParafarmacie());
		   parafarmacieSearch.setCodRegione(esercizioProfBean.getRegioneSelezionataParafarmacia());
		     
		   parafarmList = parafarmacieHome.findByFilter(parafarmacieSearch);
		  
		   return parafarmList;
	   }

	public EsercizioProf getEsercizioProf() {
		return esercizioProf;
	}

	public void setEsercizioProf(EsercizioProf esercizioProf) {
		this.esercizioProf = esercizioProf;
	}

	public ArrayList<EsercizioProf> getEserciziProf() {
		return eserciziProf;
	}

	public void setEserciziProf(ArrayList<EsercizioProf> eserciziProf) {
		this.eserciziProf = eserciziProf;
	}
	
}