package com.accenture.CCFarm.action;



import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.LogAccessi;
import com.accenture.CCFarm.DAO.LogAccessiHome;
import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.utility.CriptDecriptUtil;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.ControlloBandoScaduto;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RepositorySession;

/**
 * Servlet implementation class CaricoBandoRegione
 */

public class LogInCandidatoServlet extends HttpServlet {
//	private static final long serialVersionUID = 1L;
	Logger logger = CommonLogger.getLogger("LogInCandidatoServlet");
	private String aesKey = AppProperties.getAppProperty("aesKey");
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogInCandidatoServlet() {
        super();
        // 
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// 
		super.init();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	
//	REcupero dalla request 
		String userCandidato = (String) request.getParameter("userid").trim();
		String passwordCandidato = (String) request.getParameter("password").trim();
//  recupero dalla Session	
		HttpSession session = request.getSession();
    	String codiceRegione = (String) session.getAttribute(RepositorySession.ID_REGIONE);
    	if (codiceRegione==null) codiceRegione="";
    	String nextPage="";
    	try {
	    	boolean pageok = false;
	    	if (userCandidato!=null && passwordCandidato!=null){
				LogIn logIn= new LogIn();
				LogInHome logInHome =new LogInHome();
				logIn = logInHome.findById(userCandidato);
				String pwdDecriptata ="";
				/*
				if(logIn!=null){
				    pwdDecriptata = AESCryptoUtil.decriptaCookie(logIn.getPassword(), aesKey);
				}
				*/
				if(logIn!=null && CriptDecriptUtil.decriptToken(logIn.getPassword(), aesKey).equals(passwordCandidato)){
				//if (logIn!=null && logIn.getPassword().equals(passwordCandidato)){
					if(logIn.getIdRegione().equalsIgnoreCase(codiceRegione)){
						Candidatura candidatura = new Candidatura();
						CandidaturaHome candidaturaHome = new CandidaturaHome();
						candidatura= candidaturaHome.findById(logIn.getIdUtente());
						if (candidatura!=null){
		//			candidatura singola = S   associata = A
							session.setAttribute(RepositorySession.CANDIDATURA, candidatura);
							if (candidatura.getModalitaCandidatura().equalsIgnoreCase("S")){
		//	    	candidatura singola 	    	
						    	if (candidatura.getStatoRegistrazione()!=null&& candidatura.getStatoRegistrazione().equalsIgnoreCase("C")){
						    		if (candidatura.getFlgPrimoAccesso().equals("Y")){
						    			if (controlloBandoScaduto(codiceRegione) || (candidatura.getStatoDomanda()!=null && candidatura.getStatoDomanda().equalsIgnoreCase("I")) ){
						    				utenteInSessione(logIn.getIdUtente(), userCandidato, passwordCandidato,  request, response);
						    				session.setAttribute(RepositorySession.PRIMO_ACCESSO, "SI");
											nextPage="/jsp/loginPrimoAccesso.jsf";
						    			} else{
		//			se si effettua il primo accesso a bando scaduto
						    				session.setAttribute(RepositorySession.IDMSG_ERROR_LOGIN, "04");
											session.setAttribute(RepositorySession.RETURN_ERROR_LOGIN, "/loginCandidato");
											nextPage="/jsp/errorLoginCandidato.jsf";
						    			}
						    		} else {
						    			pageok=true;
						    			logAccessiValidazione(logIn.getIdUtente());
						    			utenteInSessione(logIn.getIdUtente(),userCandidato, passwordCandidato, request, response);
						    			session.setAttribute(RepositorySession.PRIMO_ACCESSO, "NO");
						    			nextPage="/jsp/homeCandidato.jsf";
						    		}
						    	} else{
		//			candidatura singola inconpleta non si dovrebbe verificare
						    		session.setAttribute(RepositorySession.IDMSG_ERROR_LOGIN, "05"+candidatura.getStatoRegistrazione().toUpperCase());
									session.setAttribute(RepositorySession.RETURN_ERROR_LOGIN, "/loginCandidato");
									nextPage="/jsp/errorLoginCandidato.jsf";
						    	}
						    } else {
			//			candidatura in associata 
						    	ArrayList lCandidati = new ArrayList();
							    Candidatura associata = new Candidatura();
							    associata.setIdCandidatura(candidatura.getIdCandidatura());
							    List cAssociata = new ArrayList();
								cAssociata= candidaturaHome.findByExample(associata);
							    boolean okCandidatura = true;
							    for (int i = 0; i < cAssociata.size(); i++) {
								     Candidatura cd = new Candidatura();
									 cd = (Candidatura) cAssociata.get(i);
									 if (!cd.getStatoRegistrazione().equals("C")){
										 okCandidatura = false;
										 String idUtente = cd.getIdUtente();
										 UtenteHome utenteHome = new UtenteHome();
										 Utente utente = utenteHome.findById(idUtente);
										 String sDescrUtente = utente.getNomeUtente()+" "+utente.getCognomeUtente();
										 lCandidati.add(sDescrUtente);
										 //break;
									 }
							    }
							    if (okCandidatura){
							    	if (candidatura.getFlgPrimoAccesso().equals("Y")){
								    	if (controlloBandoScaduto(codiceRegione) || (candidatura.getStatoDomanda()!=null && (candidatura.getStatoDomanda().equalsIgnoreCase("I")|| candidatura.getStatoDomanda().equalsIgnoreCase("T")))){
								   			utenteInSessione(logIn.getIdUtente(),userCandidato, passwordCandidato, request, response);
								   			session.setAttribute(RepositorySession.PRIMO_ACCESSO, "SI");
											nextPage="/jsp/loginPrimoAccesso.jsf";
								   		} else{
			//	se si effettua il primo accesso a bando scaduto	
								   			session.setAttribute(RepositorySession.IDMSG_ERROR_LOGIN, "04");
											session.setAttribute(RepositorySession.RETURN_ERROR_LOGIN, "/loginCandidato");
											nextPage="/jsp/errorLoginCandidato.jsf";
								   		}
									} else {
							    		pageok=true;
							    		logAccessiValidazione(logIn.getIdUtente());
							    		utenteInSessione(logIn.getIdUtente(),userCandidato, passwordCandidato, request, response);
							    		session.setAttribute(RepositorySession.PRIMO_ACCESSO, "NO");
							    		nextPage="/jsp/homeCandidato.jsf";
							    	} 
							    } else {
			//		 pagina di errore candidatura associata per stato incompleto
							    	if (candidatura.getStatoDomanda().equals("A") && candidatura.getStatoRegistrazione().equals("A")){
							    		session.setAttribute(RepositorySession.IDMSG_ERROR_LOGIN, "05A");
							    	} else{
								    	
							    		session.setAttribute(RepositorySession.IDMSG_ERROR_LOGIN, "03");
							    		session.setAttribute(RepositorySession.DESCR_MSG_ERROR_CANDIDATI_NON_REGISTRATI, lCandidati);
							    	}	
									session.setAttribute(RepositorySession.RETURN_ERROR_LOGIN, "/loginCandidato");
									nextPage="/jsp/errorLoginCandidato.jsf";
							    }
						    }
						} 
				    } else{
	//	errore per user e password non corrispondenti alla regione di registrazione		    	
				    	session.setAttribute(RepositorySession.IDMSG_ERROR_LOGIN, "02");
						session.setAttribute(RepositorySession.RETURN_ERROR_LOGIN, "/loginCandidato");
						nextPage="/jsp/errorLoginCandidato.jsf";
				    }
				} else{
	//	Errore per passoword non valida		
					session.setAttribute(RepositorySession.IDMSG_ERROR_LOGIN, "01");
					session.setAttribute(RepositorySession.RETURN_ERROR_LOGIN, "/loginCandidato");
					nextPage="/jsp/errorLoginCandidato.jsf";
				}
			} else{
				session.setAttribute(RepositorySession.IDMSG_ERROR_LOGIN, "00");
				session.setAttribute(RepositorySession.RETURN_ERROR_LOGIN, "/loginCandidato");
				nextPage="/jsp/errorLoginCandidato.jsf";
			}
			
			
			if (nextPage!=null&&!nextPage.equals("")){
				response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+nextPage);
			} else{
				response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/loginCandidatoErrore.jsf");
			}
				
    	} catch (Exception e) {
    		logger.error("LogInCandidatoServlet - doPost: " + e.getMessage());	
//			JSFUtility.redirect("errorPageGenerica.jsf");
			response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/errorPageGenerica.jsf");
		}		

	}

	private void logAccessiValidazione(String  idUtente) throws Exception{
		LogAccessi     logAccessi     = new LogAccessi();
		LogAccessiHome logAccessiHome = new LogAccessiHome();
		logAccessi.setIdLog(logAccessiHome.getSequenceIdLog());
		logAccessi.setIdUtente(idUtente);
		java.util.Date dataSys= new java.util.Date();
//	    java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());   
		logAccessi.setLogAccesso(new java.sql.Timestamp(dataSys.getTime()));	
		
		logAccessiHome.saveOrUpdate(logAccessi);	
				
	}

	private void utenteInSessione(String  idUtente, String user, String password, HttpServletRequest request, HttpServletResponse response) throws Exception{
		Utente utente = new Utente();
	    UtenteHome utenteHome = new UtenteHome();
	    utente= utenteHome.findById(idUtente);
	    request.getSession().setAttribute(RepositorySession.USER_SESSION, user);
	    request.getSession().setAttribute(RepositorySession.PASSWORD_SESSION, password);
	   
	    if(utente!=null){
	    	request.getSession().setAttribute(RepositorySession.ID_UTENTE, utente.getIdUtente());
	    	request.getSession().setAttribute(RepositorySession.NOME_UTENTE, utente.getNomeUtente());
	    	request.getSession().setAttribute(RepositorySession.COGNOME_UTENTE, utente.getCognomeUtente());
	    }
		
	}
    
	private boolean controlloBandoScaduto(String codiceRegione) throws Exception{
//		controllo se la registrazione avviene dopo la data chiusura bando
		ControlloBandoScaduto ctl = new ControlloBandoScaduto();
		
		return ctl.controllaScadenza(codiceRegione);
	}

	
	
	
}
