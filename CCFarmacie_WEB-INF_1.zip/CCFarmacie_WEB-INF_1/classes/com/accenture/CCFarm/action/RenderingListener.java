package com.accenture.CCFarm.action;

import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

@SuppressWarnings("serial")
public class RenderingListener implements PhaseListener
{   
	// Init ---------------------------------------------------------------------------------------

    private static final String ALL_FACES_MESSAGES_ID="allFacesMessages";

    // Actions ------------------------------------------------------------------------------------

    /**
     * @see javax.faces.event.PhaseListener#getPhaseId()
     */
    public PhaseId getPhaseId()
    {
        // Only listen during the render response phase.
        return PhaseId.RENDER_RESPONSE;
    }

    /**
     * @see javax.faces.event.PhaseListener#beforePhase(javax.faces.event.PhaseEvent)
     */
    public void beforePhase(PhaseEvent event)
    {
        FacesContext currentFacesContext=event.getFacesContext();
        
        retrieveFacesMessages(currentFacesContext);
    }

    /**
     * @see javax.faces.event.PhaseListener#afterPhase(javax.faces.event.PhaseEvent)
     */
    public void afterPhase(PhaseEvent event){ /*Do nothing.*/ }

    // Methods ------------------------------------------------------------------------------------

    /**
     * Restore any facesmessages from session in the given FacesContext.
     * @param facesContext The involved FacesContext.
     */
    @SuppressWarnings("unchecked")
    private static void retrieveFacesMessages(FacesContext facesContext)
    {
    	Map<String, Object> sessionMap=facesContext.getExternalContext().getSessionMap();
        List<FacesMessage> messages=(List<FacesMessage>)sessionMap.remove(ALL_FACES_MESSAGES_ID);
        
        if(messages!=null)
        {
	        for (Object element : messages)
	        {
	            facesContext.addMessage(null,(FacesMessage)element);
	        }
        }
    }

}