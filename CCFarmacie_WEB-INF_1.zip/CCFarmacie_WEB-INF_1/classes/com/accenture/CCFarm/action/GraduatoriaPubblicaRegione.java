package com.accenture.CCFarm.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoriaHome;
import com.accenture.CCFarm.DAO.TipoGraduatoriaId;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.StringUtil;

public class GraduatoriaPubblicaRegione {
	SimpleDateFormat fs = new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss");
	Logger logger = CommonLogger.getLogger("StatoBandoRegione");
	private HashMap<String, String> hmGradPubOK = new HashMap<String, String>();
	//private HashMap hmUltGradPub = new HashMap();

	public GraduatoriaPubblicaRegione() {
		// TODO Auto-generated constructor stub
	}

	public HashMap getGraduatoriaList() {
		HashMap mapGrad = new HashMap();
		try {
			List<Regione> listRegioni = new ArrayList<Regione>();
			RegioneHome regioneHome = new RegioneHome();
			listRegioni = regioneHome.findByExample(new Regione());
			TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
			for (Regione regione : listRegioni) {
			    List<TipoGraduatoria> listTipGrad = new ArrayList<TipoGraduatoria>();
			     
				TipoGraduatoria tipoGraduatoria = new TipoGraduatoria();
			    TipoGraduatoriaId tipoGraduatoriaId = new TipoGraduatoriaId();
			    tipoGraduatoria.setCodRegione(regione.getCodReg());
			    tipoGraduatoriaId.setCodRegione(regione.getCodReg());
			    tipoGraduatoria.setIdKey(tipoGraduatoriaId);
			    listTipGrad = tipoGraduatoriaHome.findByExample(tipoGraduatoria);
			    
			    List<TipoGraduatoria> listTipGradFormat = new ArrayList<TipoGraduatoria>();
			    boolean pubblicazioneAvvenuta = false;
			    for (TipoGraduatoria tipoGrad : listTipGrad) {
					tipoGrad.setDataValutazioneFormat(fs.format(tipoGrad.getDataValutazione()));
					tipoGrad.setDataPublicazioneFormat(fs.format(tipoGrad.getDataPublicazione()));
					if (tipoGrad.getStatoGraduatoria()!=null && tipoGrad.getStatoGraduatoria().equalsIgnoreCase("P")){
						hmGradPubOK.put(regione.getCodReg(), "SI");
						pubblicazioneAvvenuta=true;
					}
					listTipGradFormat.add(tipoGrad);
				}
//			    if (listTipGradFormat!=null && listTipGradFormat.size()>0 && pubblicazioneAvvenuta){
			    if (pubblicazioneAvvenuta){
			    	mapGrad.put(regione, listTipGradFormat);
			    }
			}
 
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaPubblicaRegione - recupero informazioni della Graduatoria: "
					+ e);
			LogUtil.printException(e);
			// JSFUtility.redirect("errorPageGenerica.jsf");
		}

		return mapGrad;

	}
	
		
	public HashMap<String, String> getHmGradPubOK() {
		return hmGradPubOK;
	}

	public void setHmGradPubOK(HashMap<String, String> hmGradPubOK) {
		this.hmGradPubOK = hmGradPubOK;
	}

	
//	public HashMap getUltimaGraduatoriaPubb() {
//		try {
//			java.util.Date dataSys= new java.util.Date();
//			int dataSysInt = trasformaData(dataSys);
//			
//			List<Regione> listRegioni = new ArrayList<Regione>();
//			RegioneHome regioneHome = new RegioneHome();
//			listRegioni = regioneHome.findByExample(new Regione());
//			TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
//			for (Regione regione : listRegioni) {
//			    List<TipoGraduatoria> listTipGrad = new ArrayList<TipoGraduatoria>();
//			     
//				TipoGraduatoria tipoGraduatoria = new TipoGraduatoria();
//			    TipoGraduatoriaId tipoGraduatoriaId = new TipoGraduatoriaId();
//			    tipoGraduatoria.setCodRegione(regione.getCodReg());
//			    tipoGraduatoriaId.setCodRegione(regione.getCodReg());
//			    tipoGraduatoria.setIdKey(tipoGraduatoriaId);
//			    listTipGrad = tipoGraduatoriaHome.findByExample(tipoGraduatoria);
//			    
//			    for (TipoGraduatoria tipoGrad : listTipGrad) {
//			    	if (tipoGrad.getStatoGraduatoria()!=null && tipoGrad.getStatoGraduatoria().equalsIgnoreCase("P")){
//			    		int dataPubInt = trasformaData(tipoGrad.getDataPublicazione());	
//			    		if (dataSysInt== dataPubInt){
//			    			tipoGrad.setDataValutazioneFormat(fs.format(tipoGrad.getDataValutazione()));
//							tipoGrad.setDataPublicazioneFormat(fs.format(tipoGrad.getDataPublicazione()));
//							tipoGrad.setDataBollettinoUffRegFormat(fs.format(tipoGrad.getDataBollettinoUffReg()));
//							hmUltGradPub.put(regione.getCodReg(), tipoGrad);
//			    		} if(dataSysInt>dataPubInt){
//			    			tipoGrad.setDataValutazioneFormat(fs.format(tipoGrad.getDataValutazione()));
//							tipoGrad.setDataPublicazioneFormat(fs.format(tipoGrad.getDataPublicazione()));
//							tipoGrad.setDataBollettinoUffRegFormat(fs.format(tipoGrad.getDataBollettinoUffReg()));
//							hmUltGradPub.put(regione.getCodReg(), tipoGrad);
//						}
//						    
//			    		
////			    		if (dataSysInt<= dataPubInt){
////					    	if (hmUltGradPub.containsKey(tipoGrad.getCodRegione())){
////					    		if (dataSysInt==dataPubInt){
////					    			tipoGrad.setDataValutazioneFormat(fs.format(tipoGrad.getDataValutazione()));
////									tipoGrad.setDataPublicazioneFormat(fs.format(tipoGrad.getDataPublicazione()));
////									hmUltGradPub.put(regione.getCodReg(), tipoGrad);
////					    		}
////					    	} else{
////					    		tipoGrad.setDataValutazioneFormat(fs.format(tipoGrad.getDataValutazione()));
////								tipoGrad.setDataPublicazioneFormat(fs.format(tipoGrad.getDataPublicazione()));
////								hmUltGradPub.put(regione.getCodReg(), tipoGrad);	
////					    	}
////							
////						}
//			    	}
//				}
//			}
// 
//		} catch (GestioneErroriException e) {
//			logger.error("GraduatoriaPubblicaRegione - recupero informazioni della Graduatoria: "
//					+ e);
//			LogUtil.printException(e);
//			// JSFUtility.redirect("errorPageGenerica.jsf");
//		}
//
//		return hmUltGradPub;
//		
//	}

	public boolean getGraduatoriaPubbColoreCartina(String idRegione) {
		try {
			
			java.util.Date dataSys= new java.util.Date();
			int dataSysInt = trasformaData(dataSys);
			
//			List<Regione> listRegioni = new ArrayList<Regione>();
//			RegioneHome regioneHome = new RegioneHome();
//			listRegioni = regioneHome.findByExample(new Regione());
			TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
			List<TipoGraduatoria> listTipGrad = new ArrayList<TipoGraduatoria>();
		     
			TipoGraduatoria tipoGraduatoria = new TipoGraduatoria();
		    TipoGraduatoriaId tipoGraduatoriaId = new TipoGraduatoriaId();
		    tipoGraduatoria.setCodRegione(idRegione);
		    tipoGraduatoriaId.setCodRegione(idRegione);
		    tipoGraduatoria.setIdKey(tipoGraduatoriaId);
		    listTipGrad = tipoGraduatoriaHome.findByExample(tipoGraduatoria);
		    
		    for (TipoGraduatoria tipoGrad : listTipGrad) {
		    	if (tipoGrad.getStatoGraduatoria()!=null && tipoGrad.getStatoGraduatoria().equalsIgnoreCase("P")){
		    		int dataPubInt = trasformaData(tipoGrad.getDataPublicazione());	
		    		if (dataSysInt== dataPubInt){
		    			return true;
		    		} if(dataSysInt>dataPubInt){
		    			return  true;
		    		}
		    	}
			}
			
 
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaPubblicaRegione - recupero informazioni della Graduatoria: "
					+ e);
			LogUtil.printException(e);
			// JSFUtility.redirect("errorPageGenerica.jsf");
		}
		
		return false;

		
		
	}
	

	public String getGraduatoriaPubbColoreCartinaString(String idRegione) {
		try {
			
			java.util.Date dataSys= new java.util.Date();
			int dataSysInt = trasformaData(dataSys);
			
//			List<Regione> listRegioni = new ArrayList<Regione>();
//			RegioneHome regioneHome = new RegioneHome();
//			listRegioni = regioneHome.findByExample(new Regione());
			TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
			List<TipoGraduatoria> listTipGrad = new ArrayList<TipoGraduatoria>();
		     
			TipoGraduatoria tipoGraduatoria = new TipoGraduatoria();
		    TipoGraduatoriaId tipoGraduatoriaId = new TipoGraduatoriaId();
		    tipoGraduatoria.setCodRegione(idRegione);
		    tipoGraduatoriaId.setCodRegione(idRegione);
		    tipoGraduatoria.setIdKey(tipoGraduatoriaId);
		    listTipGrad = tipoGraduatoriaHome.findByExample(tipoGraduatoria);
//		    listTipGrad = tipoGraduatoriaHome.getTipograduatoriaQRY(idRegione);
		    
		    for (TipoGraduatoria tipoGrad : listTipGrad) {
			    
		    	if (tipoGrad.getStatoGraduatoria()!=null && tipoGrad.getStatoGraduatoria().equalsIgnoreCase("P")){
		    		int dataPubInt = trasformaData(tipoGrad.getDataPublicazione());	
		    		if (dataSysInt== dataPubInt){
		    			return "SI";
		    		} if(dataSysInt>dataPubInt){
		    			return  "SI";
		    		}
		    	}
			}
			
 
		} catch (GestioneErroriException e) {
			logger.error("GraduatoriaPubblicaRegione - recupero informazioni della Graduatoria: "
					+ e);
			LogUtil.printException(e);
			// JSFUtility.redirect("errorPageGenerica.jsf");
		}
		
		return "NO";

		
		
	}

	
//	public HashMap getHmUltGradPub() {
//		return hmUltGradPub;
//	}
//
//	public void setHmUltGradPub(HashMap hmUltGradPub) {
//		this.hmUltGradPub = hmUltGradPub;
//	}

	private int trasformaData(Date data) {
		String dataString = fs.format(data);
		String dataConfert = dataString.substring(6, 10)
				+ dataString.substring(3, 5) + dataString.substring(0, 2);
		return Integer.parseInt(dataConfert);
	}

	private int recuperaOra(Date data) {
		String dataString = StringUtil.dateToString(data, sdf);
		String dataConfert = dataString.substring(13, 15)
				+ dataString.substring(16, 18) + dataString.substring(19, 21);
		return Integer.parseInt(dataConfert);
	}

	private int trasformaDataSting(String data) {
		// String dataString = fs.format(data);
		String dataConfert = data.substring(6, 10) + data.substring(3, 5)
				+ data.substring(0, 2);
		return Integer.parseInt(dataConfert);
	}

	private int calcolaData(Date data) {
		String dataGregorian = StringUtil.dateToString(data, sdf);

		Calendar cal = Calendar.getInstance();
		String result = "";
		try {
			cal.setTime(data);
			cal.add(Calendar.DATE, -9);
			result = StringUtil.dateToString(cal.getTime(), sdf);
		} catch (Exception e) {
		}

		return trasformaDataSting(result);
	}

	private static String dataTOString(Date w_date) {
		Calendar cal = Calendar.getInstance();
		String result = "";
		try {
			cal.setTime(w_date);
			cal.add(Calendar.DATE, -9);

			// Set time fields to zero
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			SimpleDateFormat formatterOut = new SimpleDateFormat("dd-MM-yyyy");
			result = formatterOut.format(cal.getTime());

		} catch (Exception e) {
		}
		return result;

	}

	
	
//	jsp 
//	HashMap hmGradPubb = new HashMap();
//
//	hmGradPubb = (HashMap) request.getSession().getAttribute(RepositorySession.TIPO_GRAD_PUBB);
//
//	List<TipoGraduatoria> listTipGrad = new ArrayList<TipoGraduatoria>();
//	if (hmGradPubb!=null && hmGradPubb.containsKey(regioneDatiBando.getCodReg())){
//		listTipGrad = List<TipoGraduatoria> hmGradPubb.get(regioneDatiBando.getCodReg()); 	
//	}

}
