package com.accenture.CCFarm.action;

import java.io.ByteArrayInputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.AccettazioneRinunciaSedeHome;
import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.CandidaturaSediHome;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.RicevuteId;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PDFModulo.AccettazioneRinunciaSedeEntityPdf;
import com.accenture.CCFarm.PDFModulo.AccettazioneRinunciaSedePdf;
import com.accenture.CCFarm.PageBean.AccettazioneRinunciaSede;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.mailer.concorsofarma.data.MailBean;

public class AccettazioneRinunciaSedeAction {
	
	private Logger logger = CommonLogger.getLogger("AccettazioneRinunciaSedeAction");
	
	private static final String tipoRicevutaAccettazioneRinunciaSede = AppProperties.getAppProperty("tipo.ricevuta.accettazione.rinuncia.sede");
	private static String nomeFileRicevutaRinunciaSede;
	private static String nomeFileRicevutaAccettazioneSede;
	
	private AccettazioneRinunciaSedeHome accettazioneRinunciaSedeHome;
	private CandidaturaSediHome candidaturaSediHome;
	private GraduatoriaHome graduatoriaHome;
	private InterpelloHome interpelloHome;
	private RicevuteHome ricevuteHome;
	private UtenteHome utenteHome;
	
	public AccettazioneRinunciaSedeAction() {
		
		//inizializza classi gestione DAO
		accettazioneRinunciaSedeHome = new AccettazioneRinunciaSedeHome();
		candidaturaSediHome = new CandidaturaSediHome();
		graduatoriaHome = new GraduatoriaHome();
		interpelloHome = new InterpelloHome();
		ricevuteHome = new RicevuteHome();
		utenteHome = new UtenteHome();
	}
	
	public void init(AccettazioneRinunciaSede accettazioneRinunciaSede) throws GestioneErroriException {
		
		try {
			
			nomeFileRicevutaRinunciaSede = StringUtil.getPropertyMessage("nome.file.ricevuta.rinuncia.sede", accettazioneRinunciaSede.getLinguaScelta());
			nomeFileRicevutaAccettazioneSede = StringUtil.getPropertyMessage("nome.file.ricevuta.accettazione.sede", accettazioneRinunciaSede.getLinguaScelta());
			
			//determina codice regione
			accettazioneRinunciaSede.setIdRegione( (String) JSFUtility.getFacesContext().getExternalContext().getSessionMap().get(RepositorySession.ID_REGIONE));
			
			//determina dati utente
			String idUtente = (String) JSFUtility.getFacesContext().getExternalContext().getSessionMap().get(RepositorySession.ID_UTENTE);
			accettazioneRinunciaSede.setUtente(utenteHome.findById(idUtente));
			
			//determina dati candidatura
			accettazioneRinunciaSede.setCandidatura( (Candidatura) JSFUtility.getFacesContext().getExternalContext().getSessionMap().get(RepositorySession.CANDIDATURA));
			
			accettazioneRinunciaSede.setNumeroProtocolloDomanda(graduatoriaHome.findById(accettazioneRinunciaSede.getCandidatura().getIdCandidatura()).getNumeroProtocollo());
			
			//dati interpello corrente
			accettazioneRinunciaSede.setInterpello(interpelloHome.determinaInterpelloCorrente(accettazioneRinunciaSede.getIdRegione()));
			
			//data fine accettazione dell'interpello
			Date dataFineAccettazione = DateUtil.sqlTimestampToUtilDate((Timestamp) accettazioneRinunciaSede.getInterpello().getDataFineAccettazione());
			accettazioneRinunciaSede.setDataFineAccettazioneString(StringUtil.dateToStringDDMMYYYY(dataFineAccettazione));
			
			//determina sede abbinata dal sistema
			accettazioneRinunciaSede.setSedeAssegnata(accettazioneRinunciaSedeHome.determinaSedeAbbinata(accettazioneRinunciaSede.getCandidatura().getIdCandidatura()));
			
			//determina flag sede confermata (se il flag risulta valorizzato significa che l'utente ha gi� espresso una decisione riguardo la sede assegnata)
			String flagSedeConfermata = candidaturaSediHome.determinaSceltaConfermata(accettazioneRinunciaSede.getCandidatura().getIdCandidatura());
			
			//recupera data e orario correnti
			Timestamp istanteCorrente = DateUtil.getCurrentTimestamp();
			accettazioneRinunciaSede.setDataOdierna(StringUtil.timestampToString(istanteCorrente, "dd/MM/yyyy HH:mm:ss"));
			
			//considera confermata la scelta se ne risulta una gi� espressa o se non si rientra nella finestra temporale stabilita
			accettazioneRinunciaSede.setSceltaEffettuata((flagSedeConfermata != null && !flagSedeConfermata.trim().equals(""))
														 ||
														 (istanteCorrente.before((Timestamp) accettazioneRinunciaSede.getInterpello().getDataInizioAccettazione()))
														 ||
														 (istanteCorrente.after((Timestamp) accettazioneRinunciaSede.getInterpello().getDataFineAccettazione())));
			
			// calcola differenza tra data odierna e fine acettazione
			accettazioneRinunciaSede.setFraseDifferenzaDate(DateUtil.calcolaDiffDateInGiorniOreMinuti(StringUtil.timestampToString(istanteCorrente, "yyyy/MM/dd HH:mm:ss"), StringUtil.dateToString(dataFineAccettazione, "yyyy/MM/dd HH:mm:ss"), accettazioneRinunciaSede.getLinguaScelta()));
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSedeAction - inizializzazione fallita", e);
			throw new GestioneErroriException("AccettazioneRinunciaSedeAction - inizializzazione fallita");
		}
	}
	
	//salva la decisione di accettazione/rinuncia della sede abbinata
	public void salvaScelta(AccettazioneRinunciaSede accettazioneRinunciaSede) throws GestioneErroriException {
		
		try {
			
			candidaturaSediHome.salvaSceltaSede(accettazioneRinunciaSede.getCandidatura().getIdCandidatura(),
									  			accettazioneRinunciaSede.isSedeAccettata());
			
			accettazioneRinunciaSede.setSceltaEffettuata(true);
			
			//NOTA: il salvataggio della decisione e l'invio email avvengono in 2 transazioni distinte
			inviaMail(accettazioneRinunciaSede);
		}
		catch(Exception e) {
			
			logger.error("AccettazioneRinunciaSedeAction - salvataggio decisione fallito", e);
			throw new GestioneErroriException("AccettazioneRinunciaSedeAction - salvataggio decisione fallito");
		}
	}
	
	private MailBean preparaMailRicevutaAccettazioneRinunciaSede(String linguaScelta,
																 String pecMailUtente,
																 AccettazioneRinunciaSedeEntityPdf accettazioneRinunciaSedeEntityPdf,
																 byte[] ricevutaByteArray) {
		
		if(nomeFileRicevutaRinunciaSede == null || nomeFileRicevutaRinunciaSede.isEmpty())
			nomeFileRicevutaRinunciaSede = StringUtil.getPropertyMessage("nome.file.ricevuta.rinuncia.sede", linguaScelta);
		
		if(nomeFileRicevutaAccettazioneSede == null || nomeFileRicevutaAccettazioneSede.isEmpty())
			nomeFileRicevutaAccettazioneSede = StringUtil.getPropertyMessage("nome.file.ricevuta.accettazione.sede", linguaScelta);
		
		MailBean mailBean = new MailBean();
		
		//destinatario
		ArrayList<String> listaDest = new ArrayList<String>();
		listaDest.add(pecMailUtente);
		mailBean.setToAddresses(listaDest);
		
		String descrizioneRegione = "";
		if(accettazioneRinunciaSedeEntityPdf.getCodiceRegione().equals("041") || accettazioneRinunciaSedeEntityPdf.getCodiceRegione().equals("042")) {
			
			descrizioneRegione = accettazioneRinunciaSedeEntityPdf.getDescRegione();
		}
		else {
			
			descrizioneRegione = StringUtil.getPropertyMessage("accettazioneRinunciaSede.testo.regione", linguaScelta)
								 .replace("<nome_regione>", accettazioneRinunciaSedeEntityPdf.getDescRegione());
		}
		
		String decisione = (!accettazioneRinunciaSedeEntityPdf.isSedeAccettata()) ? StringUtil.getPropertyMessage("accettazioneRinunciaSede.rinuncia", linguaScelta) 
																			      :
																				    StringUtil.getPropertyMessage("accettazioneRinunciaSede.accettazione", linguaScelta);
		
		//oggetto
		String oggettoMail = StringUtil.getPropertyMessage("accettazioneRinunciaSede.oggetto.mail.ricevuta", linguaScelta)
							 .replace("<decisione>", decisione)
							 .replace("<regione>", descrizioneRegione)
							 .replace("<numero_protocollo>", accettazioneRinunciaSedeEntityPdf.getNumeroProtocolloDomanda());
		
		mailBean.setOggettoMail(oggettoMail);
		
		//corpo messaggio
		String corpoMail ="";
		//Per piemonte se ci sta l'accettazione il testo della mail sar� il seguente
		if((accettazioneRinunciaSedeEntityPdf.getCodiceRegione().equals("010")) && (accettazioneRinunciaSedeEntityPdf.isSedeAccettata())){
			 corpoMail = StringUtil.getPropertyMessage("accettazioneRinunciaSede.corpo.mail.ricevutaPiemonte", linguaScelta)
			 		   .replace("<nome>", accettazioneRinunciaSedeEntityPdf.getNome())
			 		   .replace("<cognome>", accettazioneRinunciaSedeEntityPdf.getCognome())
			 		   .replace("<decisione>", decisione)
			 		   .replace("<regione>", descrizioneRegione);
			
		}else{
			//Per i rifiuti e le accettazionui di tutte le altre regioni il testo � il sguente
			 corpoMail = StringUtil.getPropertyMessage("accettazioneRinunciaSede.corpo.mail.ricevuta", linguaScelta)
			 		   .replace("<nome>", accettazioneRinunciaSedeEntityPdf.getNome())
			 		   .replace("<cognome>", accettazioneRinunciaSedeEntityPdf.getCognome())
			 		   .replace("<decisione>", decisione)
			 		   .replace("<regione>", descrizioneRegione);
		}
		mailBean.setCorpoMail(corpoMail);
		
		//allegato
		mailBean.addAllegato((!accettazioneRinunciaSedeEntityPdf.isSedeAccettata()) ? nomeFileRicevutaRinunciaSede
																				    :
																					  nomeFileRicevutaAccettazioneSede, new ByteArrayInputStream(ricevutaByteArray), "application/pdf");
		
		return mailBean;
	}
	
	public void inviaMail(AccettazioneRinunciaSede accettazioneRinunciaSede) throws GestioneErroriException {
		
		//NOTA: la sequence viene staccata in ogni caso, anche se il metodo s'interrompe prima di aver composto l'email
		String idRicevuta = accettazioneRinunciaSedeHome.getIdRicevuta(accettazioneRinunciaSede.getIdRegione());
		
		//recupera data e orario correnti
		Date dataOdierna = DateUtil.getDataOdierna();
		Timestamp istanteCorrente = DateUtil.getCurrentTimestamp();
		
		//genera numero protocollo
		String numeroProtocollo = idRicevuta + " - " + StringUtil.dateToString(dataOdierna, "dd-MM-yyyy") + " - " + accettazioneRinunciaSede.getIdRegione();
		
		//popola bean contenente i dati da inserire nella ricevuta
		AccettazioneRinunciaSedeEntityPdf accettazioneRinunciaSedeEntityPdf = accettazioneRinunciaSedeHome.getDatiPerRicevuta(accettazioneRinunciaSede.getUtente().getIdUtente());
		accettazioneRinunciaSedeEntityPdf.setSedeAccettata(accettazioneRinunciaSede.isSedeAccettata());
		accettazioneRinunciaSedeEntityPdf.setDataInvio( StringUtil.timestampToString(istanteCorrente, "dd/MM/yyyy HH:mm:ss") );
		accettazioneRinunciaSedeEntityPdf.setNumeroProtocollo(numeroProtocollo);
		//dati sede assegnata
		accettazioneRinunciaSedeEntityPdf.setProvinciaSedeAssegnata(accettazioneRinunciaSede.getSedeAssegnata().getDescrPrvFarm());
		accettazioneRinunciaSedeEntityPdf.setFrazioneSedeAssegnata(accettazioneRinunciaSede.getSedeAssegnata().getFrazioneFarm());
		accettazioneRinunciaSedeEntityPdf.setProgressivoSedeAssegnata(accettazioneRinunciaSede.getSedeAssegnata().getNProgressivo());
		
		try {
			//crea documento PDF
			AccettazioneRinunciaSedePdf accettazioneRinunciaSedePdf = new AccettazioneRinunciaSedePdf();
			byte[] ricevutaByteArray = accettazioneRinunciaSedePdf.creaRicevutaPDF(accettazioneRinunciaSedeEntityPdf);
			
			if(ricevutaByteArray != null) {
				
				Ricevute ricevuta = new Ricevute();
					RicevuteId id = new RicevuteId();
					id.setIdRicevuta(idRicevuta);
					id.setIdCandidatura(accettazioneRinunciaSede.getCandidatura().getIdCandidatura());
					id.setIdRegione(accettazioneRinunciaSede.getIdRegione());
					id.setTipoRicevuta(tipoRicevutaAccettazioneRinunciaSede);
				ricevuta.setId(id);
				ricevuta.setContenutoFile(ricevutaByteArray);
				ricevuta.setDataInvio(dataOdierna);
				
				if(ricevuteHome.insertRicevute(ricevuta)) {
					
					//invia email con la ricevuta
					accettazioneRinunciaSedeHome.sendMail( preparaMailRicevutaAccettazioneRinunciaSede(accettazioneRinunciaSede.getLinguaScelta(),
																							   	       accettazioneRinunciaSede.getUtente().getPecMail(),
																							   	       accettazioneRinunciaSedeEntityPdf,
																								       ricevutaByteArray) );
				}
				else {
					
					throw new GestioneErroriException("AccettazioneRinunciaSedeAction - Errore durante il salvataggio della ricevuta");
				}
			}
			else {
				
				throw new GestioneErroriException("AccettazioneRinunciaSedeAction - Errore durante la creazione della ricevuta");
			}
		}
		catch(Exception e) {
			logger.error("AccettazioneRinunciaSedeAction - Errore durante la creazione della ricevuta", e);
			throw new GestioneErroriException("AccettazioneRinunciaSedeAction - Errore durante la creazione della ricevuta");
		}
	}
	
	// METODO PER INVIO MANUALE DELLA E-MAIL
	public void invioManuale(String codiceRegione, String idUtente,String idCandidatura, String scelta, String linguaScelta) {
		
		try {
			
			//preparazione dati utente
			AccettazioneRinunciaSede accettazioneRinunciaSede = new AccettazioneRinunciaSede(true);
			//dati utente
			accettazioneRinunciaSede.setIdRegione(codiceRegione);
			accettazioneRinunciaSede.setUtente(new UtenteHome().findById(idUtente));
			accettazioneRinunciaSede.setCandidatura(new CandidaturaHome().findById(idCandidatura));
			//scelta
			accettazioneRinunciaSede.setOpzioneSelezionata(scelta);
			//dati sede
			accettazioneRinunciaSede.setSedeAssegnata(new AccettazioneRinunciaSedeHome().determinaSedeAbbinata(accettazioneRinunciaSede.getCandidatura().getIdCandidatura()));
			accettazioneRinunciaSede.setLinguaScelta(linguaScelta);
			
			inviaMail(accettazioneRinunciaSede);
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
}
