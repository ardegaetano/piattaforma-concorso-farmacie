package com.accenture.CCFarm.action;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Random;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;

import com.accenture.CCFarm.Bean.UtenteAssociato;
import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.DAO.UtenteCandidaturaHome;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PageBean.ErroreBean;
import com.accenture.CCFarm.PageBean.RichiestaCredenziali;
import com.accenture.CCFarm.utility.CriptDecriptUtil;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.BigDecimalToIntConverter;
import com.accenture.CCFarm.utility.DataPubblicazioneBando;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.IntToBigDecimalConverter;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.SQLDateToUtilDateConverter;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.UtilDateToSQLDateConverter;
import com.accenture.CCFarm.utility.ValidateCF;
import com.accenture.mailer.concorsofarma.data.MailBean;


public class RichiestaCredenzialiAction {
	
	java.util.Date date;
    private Timestamp oggi;
    
    private Utente utente;
    private UtenteHome utenteHome;
    private UtenteCandidatura utenteCandidatura;
    private LogIn logIn;
    private UtenteCandidaturaHome utenteCandidaturaHome;
    private ArrayList<UtenteCandidatura> listaCandidature;
    private Candidatura candidatura;
    private ArrayList<String> listaCodiciFiscali;
    private String aesKey = AppProperties.getAppProperty("aesKey");
    private ErroreBean erroreBean ;
  	
  	
  
  	public RichiestaCredenzialiAction(){
  		
  		utenteHome=new UtenteHome();
  		  		
		//inizializza convertitori di tipo
  		BigDecimalToIntConverter bigDecimalToIntConverter=new BigDecimalToIntConverter();
		IntToBigDecimalConverter intToBigDecimalConverter=new IntToBigDecimalConverter();

		SQLDateToUtilDateConverter sqlDateToUtilDateConverter=new SQLDateToUtilDateConverter();
		UtilDateToSQLDateConverter utilDateToSqlDateConverter=new UtilDateToSQLDateConverter();
  	
  		//registra i convertitori per BeanUtils
		ConvertUtils.register(bigDecimalToIntConverter,Integer.class);
		ConvertUtils.register(intToBigDecimalConverter,BigDecimal.class);
		
		ConvertUtils.register(sqlDateToUtilDateConverter,java.util.Date.class);
		ConvertUtils.register(utilDateToSqlDateConverter,java.sql.Date.class);
  	}
  	
  	 	
  	  
    public java.sql.Timestamp getCurrentTimestamp()
	{
		return new java.sql.Timestamp(new java.util.Date().getTime());
	}
    
    public boolean checkRichiestaCredenziali(RichiestaCredenziali richiestaCredenziali) throws GestioneErroriException{
    	
    	boolean result = true;
    	utente=new Utente();
    	utenteCandidatura = new UtenteCandidatura();
    	listaCandidature = new ArrayList<UtenteCandidatura>();
       	String idUtente = "";
       	String tipoDomanda;
       	UtenteAssociato utenteAssociato;
       	UtenteCandidatura utenteCandidatura;
       	listaCodiciFiscali = new ArrayList<String>();
		utenteCandidaturaHome = new UtenteCandidaturaHome();
		boolean dataApprovata=false;
		String messaggioErrore = null;
       	String idUtenteAssociato="";
       	
       	HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
		String lingua= (String)session.getAttribute("linguaScelta");
    	
		oggi = getCurrentTimestamp();
		if(richiestaCredenziali.getListaAssociati().size()>0)
			tipoDomanda = "A";
		else 
			tipoDomanda="S";
			
		String codiceFiscale = richiestaCredenziali.getCodiceFiscaleUtente();
		String idRegioneRichiestaCredenziali =  richiestaCredenziali.getRegioneRichiesta();
		
		
		//controllo idRegione
		
		
		//controllo data nascita < 65
		dataApprovata = chekData(richiestaCredenziali.getDataNascitaUtente(),DataPubblicazioneBando.getDataPubblicazioneBando().get("ChiusuraBandoReg_" + idRegioneRichiestaCredenziali));
		if(dataApprovata){
		
			for(int k=0;k<richiestaCredenziali.getListaAssociati().size();k++){
			dataApprovata = chekData(richiestaCredenziali.getListaAssociati().get(k).getDataNascitaAssociato(),DataPubblicazioneBando.getDataPubblicazioneBando().get(idRegioneRichiestaCredenziali));

				if(!dataApprovata){
					richiestaCredenziali.setMessaggioErrore(JSFUtility.getPropertyMessage("utente.et�.18.65", lingua));
					result = false;
					break;
				}
			}
		}else{
			richiestaCredenziali.setMessaggioErrore(JSFUtility.getPropertyMessage("utente.et�.18.65", lingua));
			return dataApprovata;
		}
		
		//fine controllo data nascita
		
		//controllo utente gi� candidato per la regione
		if(dataApprovata){
		Hashtable< String, String> controlloDoppiCf = new Hashtable<String, String>();
		controlloDoppiCf.put(codiceFiscale.toUpperCase(), "OK");
		listaCodiciFiscali.add(codiceFiscale);
			if(tipoDomanda.equals("A")){
				
				for (int i=0;i<richiestaCredenziali.getListaAssociati().size();i++){
				
					String codiceFiscale2 = ((UtenteAssociato) richiestaCredenziali.getListaAssociati().get(i)).getCodiceFiscaleUtenteAssociato();
					listaCodiciFiscali.add(codiceFiscale2);
					//
					if (controlloDoppiCf.containsKey(codiceFiscale2.toUpperCase())){
						richiestaCredenziali.setMessaggioErrore(JSFUtility.getPropertyMessage("utente.due.volte.stessa.associazione",lingua));
						result=false;
						return result;
					}else{
						controlloDoppiCf.put(codiceFiscale2.toUpperCase(), "OK");
					}
					
				}
			}
			
			boolean validaOk=true;
			for (int i=0;i<listaCodiciFiscali.size();i++){
				validaOk=true;
				/*Prima di fare la query bisogna fare il controllo di validit� del codice fiscale e controllare che la data di nascita estratta dal cf 
				sia coerente con la data di nascita dell' utente */ 
				if (listaCodiciFiscali.get(i)!=null && !listaCodiciFiscali.get(i).equals("") && listaCodiciFiscali.get(i).length()<= 16){
					validaOk =ValidateCF.validaCF(listaCodiciFiscali.get(i).toUpperCase());
					}
					
				if (validaOk){
					    String query = "select u from UtenteCandidatura u where UPPER(u.codiceFiscaleUtente) = '"+listaCodiciFiscali.get(i).toUpperCase()+"' and (u.candidatura.statoRegistrazione ='I' or u.candidatura.statoRegistrazione ='C') and u.codRegUtente='"+idRegioneRichiestaCredenziali+"'";
						
						try {
							listaCandidature = (ArrayList<UtenteCandidatura>) utenteCandidaturaHome.findByQuery(query);
							if(listaCandidature.size()>1){	
								
								if(tipoDomanda.equals("A")){
									messaggioErrore = JSFUtility.getPropertyMessage("utenti.inviate.domande", lingua);
								}else{
									messaggioErrore = JSFUtility.getPropertyMessage("utente.due.domande", lingua);
								
								}
								richiestaCredenziali.setMessaggioErrore(messaggioErrore);
								result = false;
								break;
							}else{
								if(listaCandidature.size()>0){
									utenteCandidatura = listaCandidature.get(0);
									if(utenteCandidatura.getCodRegUtente().equals(idRegioneRichiestaCredenziali)){
										if(tipoDomanda.equals("A")){
											messaggioErrore = JSFUtility.getPropertyMessage("utente.iviato.domanda.partecipazione", lingua);
										}else{
											messaggioErrore = JSFUtility.getPropertyMessage("utente.gia.registrato", lingua);
										}
										richiestaCredenziali.setMessaggioErrore(messaggioErrore);
										result = false;
										break;
									}
								}
								
							}
						} catch (GestioneErroriException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					} else{
						if(tipoDomanda.equals("A")){
							messaggioErrore =  JSFUtility.getPropertyMessage("utenti.codice.fiscale.non.corretti", lingua);
						}else{
							messaggioErrore =  JSFUtility.getPropertyMessage("utente.codice.fiscale.non.corretto", lingua);
						}
						richiestaCredenziali.setMessaggioErrore(messaggioErrore);
						result = false;
						break;
					}
					
				
			
			}
		}
		 	
		return result;
    	
    }
    
    public boolean insertRichiestaCredenziali(RichiestaCredenziali richiestaCredenziali) throws GestioneErroriException {
    	
    	boolean result = false;
    	utente=new Utente();
    	utenteCandidatura = new UtenteCandidatura();
    	listaCandidature = new ArrayList<UtenteCandidatura>();
       	String idUtente = "";
       	String tipoDomanda;
       	UtenteAssociato utenteAssociato;
       	MailBean mailBean = null;
       	String referente=" "+richiestaCredenziali.getNomeUtente()+" "+richiestaCredenziali.getCognomeUtente()+"";
        String linguaScelta= (String) GetSessionUtility.getSessionAttribute("linguaScelta");;
        boolean isTedesco = false;
       	String idUtenteAssociato="";
    	
    	try
		{
    		//scelta lingua tedesca
    		if(linguaScelta.equals("de")){
    			isTedesco=true;
    		}
    		oggi = getCurrentTimestamp();
    		if(richiestaCredenziali.getListaAssociati().size()>0)
    			tipoDomanda = "A";
    		else 
    			tipoDomanda="S";
    			
    		idUtente = utenteHome.getSequenceIdUtente();
			utenteCandidatura.setIdUtente(idUtente);
			utenteCandidatura.setCodRegUtente(richiestaCredenziali.getRegioneRichiesta());
			utenteCandidatura.setIdDomandaUtente(idUtente);
			
			
			BeanUtils.copyProperties(utenteCandidatura, richiestaCredenziali);
			
			candidatura = new Candidatura();
			candidatura.setIdCandidatura(idUtente);
			candidatura.setIdUtente(idUtente);
			candidatura.setModalitaCandidatura(tipoDomanda);
			if(tipoDomanda.equals("A")){
			candidatura.setReferenteDomanda("Y");
			}
			candidatura.setStatoDomanda("B");
			candidatura.setStatoRegistrazione("I");
			candidatura.setCreatedByCand(idUtente);
			candidatura.setCreationDateCand(oggi);
			candidatura.setLastUpdateDateCand(oggi);
			candidatura.setLastUpdatedByCand(idUtente);
			candidatura.setFlgPrimoAccesso("Y");
			candidatura.setFlagRicevutaStampata("N");
			
			logIn = generateLogin(utenteCandidatura);
			
			utenteCandidatura.setLogIn(logIn);
			
			
			utenteCandidatura.setCandidatura(candidatura);
			utenteCandidatura.setCreatedByUtente(idUtente);
			utenteCandidatura.setLastUpdatedByUtente(idUtente);
			utenteCandidatura.setCreationDateUtente(oggi);
			utenteCandidatura.setLastUpdateDateUtente(oggi);
			
			listaCandidature.add(utenteCandidatura);
    		
			if(tipoDomanda.equals("A")){
				
				referente=""+richiestaCredenziali.getNomeUtente()+" "+richiestaCredenziali.getCognomeUtente();
				
				for (int i=0;i<richiestaCredenziali.getListaAssociati().size();i++){
					
				 utenteAssociato = new UtenteAssociato();
				 utenteAssociato = (UtenteAssociato) richiestaCredenziali.getListaAssociati().get(i);
				 
				 idUtenteAssociato = utenteHome.getSequenceIdUtente();
				
				 utenteCandidatura = new UtenteCandidatura();
				
				 utenteCandidatura.setCodRegUtente(richiestaCredenziali.getRegioneRichiesta());
				 utenteCandidatura.setIdDomandaUtente(idUtenteAssociato);
				 
				 utenteCandidatura.setIdUtente(idUtenteAssociato);
				 utenteCandidatura.setNomeUtente(utenteAssociato.getNomeUtenteAssociato());
				 utenteCandidatura.setCognomeUtente(utenteAssociato.getCognomeUtenteAssociato());
				 utenteCandidatura.setCodiceFiscaleUtente(utenteAssociato.getCodiceFiscaleUtenteAssociato());
				 
				 java.util.Date data = (java.util.Date)  utenteAssociato.getDataNascitaAssociato();
			     java.sql.Date dataNascitasql = new  java.sql.Date(data.getTime());
			     utenteCandidatura.setDataNascitaUtente(dataNascitasql);
			     utenteCandidatura.setLuogoNascitaUtente(utenteAssociato.getLuogoNascitaUtenteAssociato());
			     utenteCandidatura.setLuogoNascitaEstera(utenteAssociato.getLuogoNascitaEsteraUtenteAssociato());
				 utenteCandidatura.setPrvNascitaUtente(utenteAssociato.getPrvNascitaUtenteAssociato());
				 utenteCandidatura.setNazioneNascitaUtente(utenteAssociato.getNazioneNascitaUtenteAssociato());
				 utenteCandidatura.setSesso(utenteAssociato.getSessoAssociato());
				 utenteCandidatura.setPecMail(utenteAssociato.getPecMailAssociato());
				 utenteCandidatura.setTipoDocumento(utenteAssociato.getTipoDocumentoAssociato());
				 utenteCandidatura.setNumeroDoc(utenteAssociato.getNumeroDocAssociato());
				 utenteCandidatura.setEnteRilascioDoc(utenteAssociato.getEnteRilascioDocAssociato());
				 
				 java.util.Date datau = (java.util.Date)  utenteAssociato.getDataRilascioDocAssociato();
			     java.sql.Date dataRilasciosql = new  java.sql.Date(datau.getTime());
				 utenteCandidatura.setDataRilascioDoc(dataRilasciosql);
				
			     candidatura = new Candidatura();
			     candidatura.setIdCandidatura(idUtente);
			     candidatura.setIdUtente(idUtenteAssociato);
			     candidatura.setModalitaCandidatura(tipoDomanda);
				 candidatura.setReferenteDomanda("N");
				 candidatura.setStatoDomanda("B");
				 candidatura.setStatoRegistrazione("I");
				 candidatura.setFlgPrimoAccesso("Y");
				 candidatura.setFlagRicevutaStampata("N");
				 
				 candidatura.setCreatedByCand(idUtente);
				 candidatura.setCreationDateCand(oggi);
				 candidatura.setLastUpdateDateCand(oggi);
				 candidatura.setLastUpdatedByCand(idUtente);
	
				 
				 logIn = generateLogin(utenteCandidatura);
				 
					
				 utenteCandidatura.setLogIn(logIn);
				 
				 utenteCandidatura.setCandidatura(candidatura);
				 utenteCandidatura.setCreatedByUtente(idUtente);
				 utenteCandidatura.setLastUpdatedByUtente(idUtente);
				 utenteCandidatura.setCreationDateUtente(oggi);
				 utenteCandidatura.setLastUpdateDateUtente(oggi);
					 
				 
				listaCandidature.add(utenteCandidatura);
				 
				 
				}
			}
				
				UtenteCandidaturaHome utenteCandidaturaHome = new UtenteCandidaturaHome();
				UtenteCandidatura utenteCandidatura = null;
				
				//invio una mail al referente e a tutti gli associati
				
				for(int j=0;j<listaCandidature.size();j++){
					
					utenteCandidatura = listaCandidature.get(j);
					mailBean = new MailBean();
					String codiceCandidatura = listaCandidature.get(j).getCandidatura().getIdCandidatura();
					
					
					//mailBean.getCcnAddresses().add("andrea.la.terra@accenture.com");
					mailBean.getToAddresses().add(listaCandidature.get(j).getPecMail());
					String oggettoMail = "" ;
					
					if(listaCandidature.get(j).getCandidatura().getReferenteDomanda()== null || listaCandidature.get(j).getCandidatura().getReferenteDomanda().equals("Y")){
						if(isTedesco){
							setCorpoMail(listaCandidature.get(j), mailBean, "", isTedesco);
						    oggettoMail=" Autonome Provinz Bozen  - Au�erordentliche Ausschreibung f�r Apotheken. Aktivierung des Benutzerkontos - " + listaCandidature.get(j).getNomeUtente() + " " + listaCandidature.get(j).getCognomeUtente() + ".";
						}else {
							 oggettoMail="Regione "+Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente())+" � Concorso straordinario farmacie. Attivazione Utenza- " + listaCandidature.get(j).getNomeUtente() + " " + listaCandidature.get(j).getCognomeUtente() + ".";
							setCorpoMail(listaCandidature.get(j), mailBean, "", isTedesco);
						}
					}else{
						if(isTedesco){
							setCorpoMail(listaCandidature.get(j), mailBean, referente, isTedesco);
						    oggettoMail=" Autonome Provinz Bozen  - Au�erordentliche Ausschreibung f�r Apotheken. Aktivierung des Benutzerkontos  - " + listaCandidature.get(j).getNomeUtente() + " " + listaCandidature.get(j).getCognomeUtente() + ".";
						}else {
							 oggettoMail="Regione "+Localita.getDenominazioneRegione(utenteCandidatura.getCodRegUtente())+" � Concorso straordinario farmacie. Attivazione Utenza- " + listaCandidature.get(j).getNomeUtente() + " " + listaCandidature.get(j).getCognomeUtente() + ".";
							setCorpoMail(listaCandidature.get(j), mailBean, referente, isTedesco);
						}
					}
					mailBean.setOggettoMail(oggettoMail);
					
					utenteCandidatura.setMailBean(mailBean);
					
									
				}
							
				utenteCandidaturaHome.inserisciCandidatura(listaCandidature);
		}
    	
		catch(Exception e)
		{
			GestioneErroriException eccezione = new GestioneErroriException("RichiestaCredenzialiAction - insertRichiestaCredenziali: errore nell' inserimento delle credenziali");
			throw eccezione;
		}
    	
    	
		return result;
    	
    }
    
   
	
	public void setCorpoMail(UtenteCandidatura utenteCandidatura, MailBean mailBean, String referente, boolean tedesco){ 
		
		
		String tokenDaCriptare = ""+utenteCandidatura.getLogIn().getUtenza();
		//modifica per tedesco:::
		if(tedesco){
			
			tokenDaCriptare = tokenDaCriptare + "$DE";
			String token = CriptDecriptUtil.criptToken(tokenDaCriptare, aesKey);
			String gentileCliente ="";
			
			if(referente==null||referente.equals("")){
				gentileCliente = "Sehr geehrter Herr Dr. / Sehr geehrte Frau Dr.in  "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" ";	
			}else {
			 gentileCliente = "Sehr geehrter Herr Dr. / Sehr geehrte Frau Dr.in  "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" Ihr Name wurde angemeldet von:  "+referente+".";
			}
			String laSuaUser ="der Benutzername f�r den Zugang zum Portal f�r die Ausf�llung der Bewerbung ist:" ;
			String attivazione = "F�r die Aktivierung des Benutzernamens klicken Sie auf den untenstehenden Link: ";
			String linkAtt =" <a href= \"" +AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") + "/ConfermaRichiestaRegistrazione?token="  + token +"&action=attiva\"/>" + AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") +"/ConfermaRichiestaRegistrazione?token=" + token +"&action=attiva</a>";
			String click = "Sollte der Link nicht funktionieren, k�nnen Sie ihn in ein neues Fenster Ihres Browsers kopieren.";
			
			String avvertenza="ACHTUNG: Bewahren Sie Ihre Zugangsdaten sicher auf, da sie w�hrend der weiteren Ausschreibungsphasen erforderlich sein k�nnten.";
			
			String rifiuto = "\r\n<br/>\r\n<br/>\r\n<br/>Falls nicht Sie die Zugangsdaten beantragt haben, klicken Sie auf folgenden Link  \r\n<br/>\r\n<br/> oder kopieren ihn in ein neues Fenster Ihres Browsers: ";
			String linkRifiuto =" <a href= \"" +AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") + "/ConfermaRichiestaRegistrazione?token="  + token +"&action=annulla\"/>" + AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") +"/ConfermaRichiestaRegistrazione?token=" + token +"&action=annulla</a>";
			String dichiarazione="In K�rze erhalten Sie eine weitere E-Mail mit dem Passwort f�r den Zugang zum Portal.\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>Es wird daran erinnert, dass laut den von Ihnen unterschriebenen Nutzungsbedingungen die \r\n<br/>\r\n<br/>\r\n<br/>  Zugangsdaten , und insbesondere das Passwort ,pers�nlich sind und zu keiner Zeit  \r\n<br/>\r\n<br/>\r\n<br/>Dritten zur Verf�gung gestellt werden k�nnen.\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>Mit freundlichen Gr��en";
			String attenzione = "\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>ACHTUNG: Automatisch generierte E-Mail. Etwaige Antworten auf diese E-Mail werden nicht bearbeitet.";

			mailBean.setCorpoMail("<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+laSuaUser+"\r\n<br/>\r\n<br/>"+"Benutzername: "+utenteCandidatura.getLogIn().getUtenza()+"\r\n<br/>\r\n<br/>"+attivazione+"\r\n<br/>\r\n<br/>"+linkAtt+"\r\n<br/>\r\n<br/>"+click+"\r\n<br/>\r\n<br/>"+avvertenza+"\r\n<br/>\r\n<br/>"+rifiuto+"\r\n<br/>\r\n<br/>"+linkRifiuto+"\r\n<br/>\r\n<br/>"+dichiarazione+"\r\n<br/>\r\n<br/>"+attenzione+"</htlml>");
			
			
		}else{
		
		String token = CriptDecriptUtil.criptToken(tokenDaCriptare, aesKey);
		String gentileCliente ="";
		if(referente==null||referente.equals("")){
			gentileCliente = "Gentile Dott./Dott.ssa "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" ";	
		}else {
		 gentileCliente = "Gentile Dott./Dott.ssa "+utenteCandidatura.getNomeUtente()+" "+utenteCandidatura.getCognomeUtente()+" il suo nominativo � stato registrato dal sig : "+referente+".";
		}
		String laSuaUser ="il Codice Utente per accedere al portale per la compilazione della candidatura � il seguente: " ;
		String attivazione = "Pu� attivare il Codice Utente premendo sul link sottostante: ";
		String linkAtt =" <a href= \"" +AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") + "/ConfermaRichiestaRegistrazione?token="  + token +"&action=attiva\"/>" + AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") +"/ConfermaRichiestaRegistrazione?token=" + token +"&action=attiva</a>";
		String click = "Nel caso in cui  il link risulti non funzionante, pu� copiarlo in una nuova finestra del Suo browser.";
		
		String avvertenza="ATTENZIONE: si consiglia di conservare la presente utenza perch� dovr� essere utilizzata per le fasi successive del concorso.";
		
		String rifiuto = "\r\n<br/>\r\n<br/>\r\n<br/>Nel caso non fosse stato/a Lei ad inserire la richiesta di credenziali pu� premere sul seguente link \r\n<br/>\r\n<br/> o pu� copiarlo in nuova finestra del Suo browser :";
		String linkRifiuto =" <a href= \"" +AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") + "/ConfermaRichiestaRegistrazione?token="  + token +"&action=annulla\"/>" + AppProperties.getAppProperty("BaseUrlConfermaRegistrazione") +"/ConfermaRichiestaRegistrazione?token=" + token +"&action=annulla</a>";
		String dichiarazione="A breve le verr� inviata una ulteriore email con la password per accedere al portale.\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>Le ricordiamo che, come dalle condizioni d'uso da Lei sottoscritte, le credenziali di\r\n<br/>\r\n<br/>\r\n<br/>  autenticazione, ed in particolare la password, Le sono state attribuite in modo esclusivo e\r\n<br/>\r\n<br/>\r\n<br/>non possono essere messe a disposizione di terzi, neppure in tempi diversi.\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>Cordiali saluti.";
		String attenzione = "\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>ATTENZIONE: Questa email � stata generata in automatico ed eventuali risposte alla stessa non verranno gestite.";

		mailBean.setCorpoMail("<html>"+gentileCliente +"\r\n<br/>\r\n<br/>"+laSuaUser+"\r\n<br/>\r\n<br/>"+"Codice utente: "+utenteCandidatura.getLogIn().getUtenza()+"\r\n<br/>\r\n<br/>"+attivazione+"\r\n<br/>\r\n<br/>"+linkAtt+"\r\n<br/>\r\n<br/>"+click+"\r\n<br/>\r\n<br/>"+avvertenza+"\r\n<br/>\r\n<br/>"+rifiuto+"\r\n<br/>\r\n<br/>"+linkRifiuto+"\r\n<br/>\r\n<br/>"+dichiarazione+"\r\n<br/>\r\n<br/>"+attenzione+"</htlml>");
		
	   }
	
	}
	
  
	 
		
	public LogIn generateLogin(UtenteCandidatura utenteCandidatura){
		
		logIn = new LogIn();
		logIn.setIdUtente(utenteCandidatura.getIdUtente());
		String password = StringUtil.generateString(new Random(), utenteCandidatura.getCodiceFiscaleUtente(), 10);
		logIn.setPassword(password);
		String utenza= utenteCandidatura.getCodiceFiscaleUtente().substring(1,4)+utenteCandidatura.getIdUtente();
 		logIn.setUtenza(utenza);
 		logIn.setIdRegione(utenteCandidatura.getCodRegUtente());
 		
 		return logIn;
	}
	
	
	
	public Calendar modifyYear (Date data){
		
		Calendar dataCalendar = Calendar.getInstance();
		dataCalendar.setTime(data);
		dataCalendar.add(Calendar.YEAR,65);
			
		
		return dataCalendar;
		
	}
	public Calendar modifyYear18 (Date data){
		
		Calendar dataCalendar = Calendar.getInstance();
		dataCalendar.setTime(data);
		dataCalendar.add(Calendar.YEAR,18);
			
		
		return dataCalendar;
		
	}
	
	public boolean chekData(Date dataNascita, Date dataBando){
		Calendar dataModificata = modifyYear(dataNascita);
		Calendar data18 = modifyYear18(dataNascita);
		Calendar dataBandoRef = Calendar.getInstance();
						
		dataBandoRef.setTime(dataBando);
		if(dataModificata.after(dataBandoRef) && data18.before(dataBandoRef)){
			return true;
		}
		else
			return false;
	}
	
	
	public LogIn getLogIn() {
		return logIn;
	}

	public void setLogIn(LogIn logIn) {
		this.logIn = logIn;
	}
    
    
    
    
}
