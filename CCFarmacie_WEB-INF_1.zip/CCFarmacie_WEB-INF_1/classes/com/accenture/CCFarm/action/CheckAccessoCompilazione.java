package com.accenture.CCFarm.action;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.PrintException;
import com.accenture.CCFarm.utility.RepositorySession;


public class CheckAccessoCompilazione implements Filter 
{ 
	Logger logger = CommonLogger.getLogger("CheckAccessoCompilazione");
	
	private final static String errorPage = "errorPageGenerica.jsf";
	private final static String homeCandidatoPage = "homeCandidato.jsf";
	private final static String compilazioneDomandaPage = "compilaDomanda.jsf";
	
	public void destroy() {}
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		HttpServletRequest req=(HttpServletRequest)request;
		HttpServletResponse resp=(HttpServletResponse)response;
		
		try
		{
			HttpSession session = req.getSession(true);
			String pageRequested = req.getRequestURL().toString();
			boolean continua=true;
			
			//se la pagina chiamata � quella di compilazione della domanda
			if(pageRequested.contains(compilazioneDomandaPage))
			{
				//controlla lo stato della domanda per l'utente in sessione
				Candidatura candidatura=(Candidatura)session.getAttribute(RepositorySession.CANDIDATURA);
				
				//se in sessione sono effettivamente presenti i dettagli di una candidatura (c'� un utente loggato)..
				if(candidatura!=null)
				{
					//..recupera lo stato della domanda
					String statoDomanda=candidatura.getStatoDomanda();
					
					//se la domanda non risulta in bozza..
					if(!(statoDomanda!=null && statoDomanda.equalsIgnoreCase("B")))
					{
						//..redirigi verso la pagina home del candidato
						resp.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/"+homeCandidatoPage);
						continua=false;
					}
				}
			}
			
			//continua con l'indirizzamento verso la pagina di compilazione
			if(continua)
			{
				chain.doFilter(request,response);
			}
		}
		catch(Exception e)
		{
			logger.error("CheckAccessoCompilazione error: " + PrintException.stack2string(e));
			
			resp.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/"+errorPage);
		}
	}

	public void init(FilterConfig arg0) throws ServletException {}

}
