package com.accenture.CCFarm.action;

import java.util.logging.Logger;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.PageBean.HomeRegioneBean;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.UtenteRegioni;


public class HomeRegioneAction{
	
	java.util.Date dataSys= new java.util.Date();
    private java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
    Logger logger =Logger.getLogger("HomeRegione");
    
	String codRegione="200"; //PER TEST
	String utente="UtenteTest";

	public HomeRegioneAction(){
	}
	
    public void loadPaginaInserimento(HomeRegioneBean regBean) {
    	
    	//RECUPERO DALLA SESSIONE
    	FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	
    	try {
	    	//ACCESSO DA CARTINA ***********************************************************************************
	    	DatiBando datiBando = (DatiBando)session.getAttribute(RepositorySession.DATI_BANDO);
	    	if(datiBando!=null) {
	    		
	    		regBean.setRegione(GenericConstants.getDescrRegioneByCod(datiBando.getCodReg()));
	    	}
	    	else { //ACCESSO DA REGIONI *****************************************************************************
	    	
		    	UtenteRegioni utenteReg = (UtenteRegioni)session.getAttribute(RepositorySession.UTENTE_NSIS);
		    	
		    	if(utenteReg!=null)
		    	{
		    		codRegione = utenteReg.getCodRegione();
		    		utente = utenteReg.getNome();
		    	}
		    	//----------------------
		    	
		    	logger.info("****************************");
		    	System.out.println("CodRegione:"+codRegione);
		    	logger.info("****************************");
				
		    	regBean.setCodRegione(codRegione);
		    	regBean.setRegione(GenericConstants.getDescrRegioneByCod(codRegione));
		    	regBean.setUsername(utente);
		    	
	    	}	
    	} catch (Exception e) {
			e.printStackTrace();
		} 
    
    }
    
}