package com.accenture.CCFarm.action;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;

public class DomandaAction
{
	private CandidaturaHome candidaturaHome;
	private Candidatura candidatura;
	
	public DomandaAction()
	{
		candidaturaHome=new CandidaturaHome();
		
	}
	
	public String determinaTipologiaUtente(String idUtente) throws Exception
	{
		try
		{
			candidatura=candidaturaHome.findById(idUtente);
			String modalita=candidatura.getModalitaCandidatura();
			//se l'utenza � relativa ad una candidatura associata
			if(modalita.equals("A"))
			{
				if(candidatura.getReferenteDomanda().equals("Y"))
					return "referente";
				return "associato";
			}
			else if(modalita.equals("S"))//se l'utenza � relativa ad una candidatura singola
				return "singolo";
			
			return "<indefinita>";
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new Exception("[Impossibile determinare tipologia utente]");
		}
	}
}
