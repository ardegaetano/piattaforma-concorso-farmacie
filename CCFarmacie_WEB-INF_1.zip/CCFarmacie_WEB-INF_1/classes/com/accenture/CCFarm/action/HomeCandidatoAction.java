package com.accenture.CCFarm.action;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.math.BigDecimal;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.primefaces.model.DefaultStreamedContent;

import com.accenture.CCFarm.DAO.AccettazioneRinunciaSedeHome;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.Graduatoria;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.Interpello;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PageBean.HomeCandidatoBean;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.Convertitore;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.HibernateUtil;
import com.accenture.CCFarm.utility.RepositorySession;


public class HomeCandidatoAction {
	
    Logger logger = CommonLogger.getLogger("HomeCandidatoAction");
    
    private AccettazioneRinunciaSedeHome accettazioneRinunciaSedeHome;
    private CandidaturaRegHome candidaturaRegHome;
    private InterpelloHome interpelloHome;
    private GraduatoriaHome graduatoriaHome;
	//private UploadedFile fileBando;

	public HomeCandidatoAction() {
		
		//inizializza convertitori di tipo
		Convertitore.registraConvertitori();
		
		accettazioneRinunciaSedeHome = new AccettazioneRinunciaSedeHome();
		candidaturaRegHome = new CandidaturaRegHome();
		interpelloHome = new InterpelloHome();
		graduatoriaHome =new GraduatoriaHome();
	}
	
	//Setta il file per il download caricando il BLOB da DB
//	public void caricaFileDownload(BandoRegionale bandoReg) throws GestioneErroriException {
	public void caricaFileDownload(HomeCandidatoBean candidatoBean ) throws GestioneErroriException {
		
		//RECUPERO DALLA SESSIONE
    	FacesContext context = FacesContext.getCurrentInstance();
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	String idUtente = (String) session.getAttribute(RepositorySession.ID_UTENTE);
    	try {
    		
//	    	DatiBandoHome hDatiBando = new DatiBandoHome();
//			DatiBando datiBando = hDatiBando.findById("010");
			Ricevute ricevute = new Ricevute();
			RicevuteHome ricevuteHome = new RicevuteHome();
			ricevute =ricevuteHome.findById(idUtente);
			
	    	if(ricevute!=null){
//	    		Blob bFileBando = ricevute.getContenutoFile();
	    		byte[] bFileBando = ricevute.getContenutoFile();
	    		InputStream is = new ByteArrayInputStream(bFileBando);

	    	
	    		if(is!=null){
  		    		candidatoBean.setFileDownLoad(new DefaultStreamedContent(is, "application/pdf", "RicevutaInvioDomanda.pdf")); 
       			}
//	    		if(bFileBando!=null){
//       				InputStream streamB = bFileBando.getBinaryStream();
//       		    	if(streamB!=null){
//       		    		candidatoBean.setFileDownLoad(new DefaultStreamedContent(streamB, "application/pdf", "BANDO.pdf")); 
////       		    		bandoReg.setbCaricaBando(true);
//       		    	}	
//       			}
	    	}
//	    	else {
//	    		InputStream streamB = fileBando.getInputstream();
//	    		candidatoBean.setFileDownLoad(new DefaultStreamedContent(streamB, fileBando.getContentType(), fileBando.getFileName()));
////   				bandoReg.setbCaricaBando(true);
//	    	}
    	} catch (Exception e) {
			logger.error("HomeCandidatoAction - caricaFileDownload: errore nel caricamento del file: " + e.getMessage());
			throw new GestioneErroriException("HomeCandidatoAction - caricaFileDownload: "+e);
		} 
	}

	public String getStatoRichMailPec (HomeCandidatoBean candidatoBean, String idUtente ) throws GestioneErroriException {

    	String statoRichModPecMail ="";	    	
    	
    	try {
    		           	
			UtenteHome utenteHome = new UtenteHome();
			statoRichModPecMail = utenteHome.findById(idUtente).getRichiestaCambioPecMail();			

    	} catch (Exception e) {
			logger.error("HomeCandidatoAction - getStatoRichMailPec: errore nel recupero dello stato richiesta cambio PEC: " + e.getMessage());
			throw new GestioneErroriException("HomeCandidatoAction - caricaFileDownload: "+e);
		} 
    	
    	return statoRichModPecMail;	
	}
	
	//restituisce true se l'utente risulta abilitato alla scelta delle sedi per la regione di candidatura
	public boolean controllaAbilitazioneSceltaSedi(String codiceRegione, String idUtente) throws GestioneErroriException {
		
		if(interpelloHome.controllaValiditaInterpello(codiceRegione, DateUtil.getCurrentTimestamp())) {
			
			Interpello interpello=interpelloHome.determinaInterpelloCorrente(codiceRegione);
			BigDecimal indiceInterpelloGrad=graduatoriaHome.getIdInterpello(codiceRegione, idUtente);
			if(interpello!=null&&indiceInterpelloGrad!=null&&interpello.getId().getIdInterpello().intValue()!=indiceInterpelloGrad.intValue())
	    		 return false;
		
			  return candidaturaRegHome.controllaAbilitazioneSceltaSedi(idUtente);
			
		}
		
		return false;
	}
	
	//restituisce true se l'utente risulta abilitato all'accettazione/rinuncia della sede assegnata
	public boolean controllaAbilitazioneAccettazioneRinunciaSede(String codiceRegione, String idUtente) throws GestioneErroriException {
		
		if(interpelloHome.controllaValiditaFaseAccettazioneRinunciaInterpello(codiceRegione, DateUtil.getCurrentTimestamp())) {
			BigDecimal indiceInterpelloGrad=graduatoriaHome.getIdInterpello(codiceRegione, idUtente);
			Interpello interpello=interpelloHome.determinaInterpelloCorrente(codiceRegione);
			if(interpello!=null&&indiceInterpelloGrad!=null&&interpello.getId().getIdInterpello().intValue()!=indiceInterpelloGrad.intValue())
	    		 return false;
			return accettazioneRinunciaSedeHome.controllaAbilitazioneAccettazioneRinunciaSede(idUtente);
		}
		
		return false;
	}
	
//	public UploadedFile getFileBando() {
//		return fileBando;
//	}
//
//	public void setFileBando(UploadedFile fileBando) {
//		this.fileBando = fileBando;
//	}
	
}