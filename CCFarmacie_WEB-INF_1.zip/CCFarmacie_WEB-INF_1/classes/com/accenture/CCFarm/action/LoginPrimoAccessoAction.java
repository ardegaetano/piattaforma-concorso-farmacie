package com.accenture.CCFarm.action;

import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.LogAccessi;
import com.accenture.CCFarm.DAO.LogAccessiHome;
import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PageBean.LoginPrimoAccessoBean;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CriptDecriptUtil;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RepositorySession;


public class LoginPrimoAccessoAction{
	
	Logger logger = CommonLogger.getLogger("LogInCandidatoServlet");

	public LoginPrimoAccessoAction(){
		
	}
	
    public void loadPagina(LoginPrimoAccessoBean loginPrimoAccessoBean) {
    	
    	//RECUPERO DALLA SESSIONE
    	
		FacesContext context = FacesContext.getCurrentInstance();
    	//HttpSession session = (HttpSession)context.getExternalContext().getSession(true);
    	HttpServletRequest req = (HttpServletRequest) context.getExternalContext().getRequest();
    	HttpSession session = req.getSession();
    	String userSession = (String) session.getAttribute(RepositorySession.USER_SESSION);
    	String passwordSession = (String) session.getAttribute(RepositorySession.PASSWORD_SESSION);

    	loginPrimoAccessoBean.setUser(userSession);
    	loginPrimoAccessoBean.setOldPassword(passwordSession);
    	loginPrimoAccessoBean.setIdUtenteSession((String) session.getAttribute(RepositorySession.ID_UTENTE));
    	loginPrimoAccessoBean.setIdRegione((String) session.getAttribute(RepositorySession.ID_REGIONE));
    	String primoAccesso = (String) session.getAttribute(RepositorySession.PRIMO_ACCESSO);
    	if (primoAccesso==null) primoAccesso="";
    	loginPrimoAccessoBean.setPrimoAccesso(primoAccesso);
    	
    	
    }
    
    public LoginPrimoAccessoBean verificaUtenza(LoginPrimoAccessoBean loginBean) throws GestioneErroriException{
    	
    	List<LogIn> loginList = new ArrayList<LogIn>();
    	LoginPrimoAccessoBean loginNew = new LoginPrimoAccessoBean();
    	LogInHome logInHome = new LogInHome();
    	LogIn logIn = new LogIn();
    	logIn.setUtenza(loginBean.getUser());
    	    		
    	try {
			logIn = logInHome.findById(loginBean.getUser());
		} catch (GestioneErroriException e) {
		
			GestioneErroriException eccezione = new GestioneErroriException(
					"LogInPrimoAccessoAction - verificaUtenza: errore nella verificaUtenza di LogInPrimoAccessoAction");
			LogUtil.printException(eccezione);
			throw eccezione;
		}
	    
    	
        if(logIn!=null&&!logIn.getIdUtente().equals("")){
    
			loginNew.setNewPassword(logIn.getPassword());
			loginNew.setUser(logIn.getUtenza());
			loginNew.setIdUtenteSession(logIn.getIdUtente());
			loginNew.setIdRegione(logIn.getIdRegione());
        }			
	    return loginNew;
	    
        }
   
    
        
    
    public void autenticaPrimoAccesso(LoginPrimoAccessoBean loginPrimoAccessoBean) throws GestioneErroriException{
    	String aesKey = AppProperties.getAppProperty("aesKey");
    	LogIn logIn =new LogIn();
		logIn.setIdUtente(loginPrimoAccessoBean.getIdUtenteSession());
		String pwdCriptata =  CriptDecriptUtil.criptToken(loginPrimoAccessoBean.getNewPasswordConfirm().trim(), aesKey) ;
		logIn.setPassword(pwdCriptata);
		logIn.setUtenza(loginPrimoAccessoBean.getUser());
		logIn.setIdRegione(loginPrimoAccessoBean.getIdRegione());
		LogInHome logInHome = new LogInHome();
	
		logInHome.saveOrUpdate(logIn);
		
		logAccessiValidazione(logIn.getIdUtente());
		
		
		Candidatura candidatura = new Candidatura();
		CandidaturaHome candidaturaHome = new CandidaturaHome();
		try
		{
			candidatura = candidaturaHome.findById(loginPrimoAccessoBean.getIdUtenteSession());
		}
		catch (GestioneErroriException e1)
		{
			LogUtil.printException(e1);
		}
		candidatura.setFlgPrimoAccesso("N");
		candidatura.setLastUpdateDateCand(getCurrentTimestamp());
		candidatura.setLastUpdatedByCand(loginPrimoAccessoBean.getIdUtenteSession());
		candidaturaHome.saveOrUpdate(candidatura);
    }
    	  
    public java.sql.Timestamp getCurrentTimestamp()
	{
		return new java.sql.Timestamp(new java.util.Date().getTime());
	}

    private void logAccessiValidazione(String  idUtente) throws GestioneErroriException{
		LogAccessi     logAccessi     = new LogAccessi();
		LogAccessiHome logAccessiHome = new LogAccessiHome();
		logAccessi.setIdLog(logAccessiHome.getSequenceIdLog());
		logAccessi.setIdUtente(idUtente);
		java.util.Date dataSys= new java.util.Date();
//	    java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());   
		logAccessi.setLogAccesso(new java.sql.Timestamp(dataSys.getTime()));	
		
		logAccessiHome.saveOrUpdate(logAccessi);
				
	}
	
}