package com.accenture.CCFarm.action;

import java.util.Date;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.DAO.UtenteCandidaturaHome;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;

import com.accenture.CCFarm.utility.CriptDecriptUtil;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RecuperaProtocollo;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.mailer.concorsofarma.data.MailBean;


public class CambioPECAction{
	
	private FacesContext context =null;
	private HttpSession session= null; 
	private HttpServletRequest request=null;
	
	

	public CambioPECAction(){
		
	}
	
	
	public boolean inviaNewPec() throws GestioneErroriException
	{
		boolean result=false;
		
		try
		{
			sendMailReqNewPec();
			result = true;
		}
		catch(Exception e)
		{
			LogUtil.printException(e);
			GestioneErroriException eccezione = new GestioneErroriException("CambioPECAction - inviaNewPec: errore nell' inserimento delle nuova PEC");
			LogUtil.printException(eccezione);
			
			//throw eccezione;
		}
		
		return result;
	}
	
	
	
	
	
	public void sendMailReqNewPec()throws GestioneErroriException {
		
			try
			{
		
				context = FacesContext.getCurrentInstance();
				request = (HttpServletRequest) context.getExternalContext().getRequest();
				session = request.getSession();
			
				String aesKey128 = AppProperties.getAppProperty("aesKey128");

			    java.util.Date dataOggi = new Date(System.currentTimeMillis());
		        java.sql.Date dataOggisql = new  java.sql.Date(dataOggi.getTime());
				
				String idUtente= (String) session.getAttribute(RepositorySession.ID_UTENTE);
				MailBean mailBean = null;			
				String newMail= (String) session.getAttribute(RepositorySession.NEW_PEC_EMAIL);			
				UtenteHome utenteHome = new UtenteHome();
				Utente utente = utenteHome.findById(idUtente);			
				utente.setNewPecMail(newMail);
				utente.setRichiestaCambioPecMail("I");
				utente.setRichiestaCambioPecMailDate(dataOggisql);
				
				session.removeAttribute(RepositorySession.NEW_PEC_EMAIL);
				session.removeAttribute("cambioPECBean");
				
				utenteHome.invioMailRichModificaPec(utente,aesKey128);				
				utenteHome.saveOrUpdate(utente);

			
		}
		catch(Exception e)
		{
			GestioneErroriException eccezione = new GestioneErroriException("CambioPECAction - sendNewPec: errore nell' inserimento della nuova PEC");
			throw eccezione;
		}
		
	}

	
	

	public FacesContext getContext() {
		return context;
	}


	public void setContext(FacesContext context) {
		this.context = context;
	}


	public HttpSession getSession() {
		return session;
	}


	public void setSession(HttpSession session) {
		this.session = session;
	}


	public HttpServletRequest getRequest() {
		return request;
	}


	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	

}