package com.accenture.CCFarm.action;



import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.LogAccessi;
import com.accenture.CCFarm.DAO.LogAccessiHome;
import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.ControlloBandoScaduto;
import com.accenture.CCFarm.utility.GenericConstants;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.RepositorySession;

/**
 * Servlet implementation class CaricoBandoRegione
 */

public class LogOutServlet extends HttpServlet {
//	private static final long serialVersionUID = 1L;
	 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogOutServlet() {
        super();
        // 
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// 
		super.init();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
//		HttpSession session = request.getSession();

    	String nextPage="";
    	nextPage="/jsp/cartinaItalia.jsp";

    	request.getSession().invalidate();
		
		response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+nextPage);
		
//		JSFUtility.redirect("/jsp/cartinaItalia.jsp");	
	

	}


	
	
	
}
