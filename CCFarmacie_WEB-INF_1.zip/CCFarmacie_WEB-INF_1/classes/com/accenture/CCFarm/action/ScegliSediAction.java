package com.accenture.CCFarm.action;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.primefaces.model.DualListModel;

import com.accenture.CCFarm.DAO.AnagraficaFarm;
import com.accenture.CCFarm.DAO.AnagraficaFarmHome;
import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaRegHome;
import com.accenture.CCFarm.DAO.CandidaturaSedi;
import com.accenture.CCFarm.DAO.CandidaturaSediHome;
import com.accenture.CCFarm.DAO.CandidaturaSediId;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.GraduatoriaHome;
import com.accenture.CCFarm.DAO.InterpelloHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.RicevuteId;
import com.accenture.CCFarm.DAO.ScegliSediHome;
import com.accenture.CCFarm.DAO.UtenteHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PDFModulo.SceltaSediEntityPdf;
import com.accenture.CCFarm.PDFModulo.SceltaSediPdf;
import com.accenture.CCFarm.PageBean.ScegliSedi;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.DateUtil;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.mailer.concorsofarma.data.MailBean;

public class ScegliSediAction {
	
	private Logger logger = CommonLogger.getLogger("ScegliSediAction");
	
	private static final String flagValoreFalso = AppProperties.getAppProperty("flag.valore.falso");
	private static final String flagValoreVero = AppProperties.getAppProperty("flag.valore.vero");
	
	private static final String tipoRicevutaSceltaSedi = AppProperties.getAppProperty("tipo.ricevuta.scelta.sedi");
	private static String nomeFileRicevutaSceltaSedi;
	
	private AnagraficaFarmHome anagraficaFarmHome;
	private CandidaturaRegHome candidaturaRegHome;
	private CandidaturaSediHome candidaturaSediHome;
	private DatiBandoHome datiBandoHome;
	private GraduatoriaHome graduatoriaHome;
	private InterpelloHome interpelloHome;
	private RicevuteHome ricevuteHome;
	private ScegliSediHome scegliSediHome;
	private UtenteHome utenteHome;
	
	public ScegliSediAction() {
		
		//inizializza classi gestione DAO
		anagraficaFarmHome = new AnagraficaFarmHome();
		candidaturaRegHome = new CandidaturaRegHome();
		candidaturaSediHome = new CandidaturaSediHome();
		datiBandoHome = new DatiBandoHome();
		graduatoriaHome = new GraduatoriaHome();
		interpelloHome = new InterpelloHome();
		ricevuteHome = new RicevuteHome();
		scegliSediHome = new ScegliSediHome();
		utenteHome = new UtenteHome();
	}
	
	public void init(ScegliSedi scegliSedi) throws GestioneErroriException {
		
		try {
			
			nomeFileRicevutaSceltaSedi = StringUtil.getPropertyMessage("nome.file.ricevuta.scelta.sedi", scegliSedi.getLinguaScelta());
			
			//determina codice regione
			scegliSedi.setIdRegione( (String) JSFUtility.getFacesContext().getExternalContext().getSessionMap().get(RepositorySession.ID_REGIONE));
			
			//determina dati utente
			String idUtente = (String) JSFUtility.getFacesContext().getExternalContext().getSessionMap().get(RepositorySession.ID_UTENTE);
			scegliSedi.setUtente(utenteHome.findById(idUtente));
			
			//determina dati candidatura
			scegliSedi.setCandidatura( (Candidatura) JSFUtility.getFacesContext().getExternalContext().getSessionMap().get(RepositorySession.CANDIDATURA));
			
			//determina flag scelta delle sedi gi� effettuata
			String flagSedi = candidaturaRegHome.findById(scegliSedi.getCandidatura().getIdCandidatura()).getFlagSceltaSedi();
			scegliSedi.setFlagSedi((flagSedi != null)? flagSedi : flagValoreFalso);
			
			//determina numero di sedi messe a concorso
			scegliSedi.setNumSediConcorso(datiBandoHome.findById(scegliSedi.getIdRegione()).getSediCaricate().toString());
			
			//posizione del candidato in graduatoria
			scegliSedi.setPosizioneGraduatoria(graduatoriaHome.getIndiceTotaleGraduatoria(scegliSedi.getIdRegione(),
											   scegliSedi.getCandidatura().getIdCandidatura()).toString());
			
			//numero sedi selezionabili pari alla posizione del candidato nell'interpello
			scegliSedi.setNumSediSelezionabili(graduatoriaHome.getIndiceInterpello(scegliSedi.getIdRegione(),
																				   scegliSedi.getCandidatura().getIdCandidatura()).toString());
			
			//dati interpello corrente
			scegliSedi.setInterpello(interpelloHome.determinaInterpelloCorrente(scegliSedi.getIdRegione()));
			
			//numero interpello
			scegliSedi.setNumeroInterpello(scegliSedi.getInterpello().getId().getIdInterpello().toString());
			
			//data inizio interpello
			Date dataInizioInterpello = DateUtil.sqlTimestampToUtilDate((Timestamp) scegliSedi.getInterpello().getDataInizio());
			scegliSedi.setDataInizioInterpello(StringUtil.dateToStringDDMMYYYY(dataInizioInterpello));
			
			//data fine interpello
			Date dataFineInterpello = DateUtil.sqlTimestampToUtilDate((Timestamp) scegliSedi.getInterpello().getDataFine());
			scegliSedi.setDataFineInterpello(StringUtil.dateToStringDDMMYYYY(dataFineInterpello));
			
			// calcola differenza tra data odierna e fine interpello
			Timestamp istanteCorrente = DateUtil.getCurrentTimestamp();			
			scegliSedi.setFraseDifferenzaDate(DateUtil.calcolaDiffDateInGiorniOreMinuti(StringUtil.timestampToString(istanteCorrente, "yyyy/MM/dd HH:mm:ss"), StringUtil.dateToString(dataFineInterpello, "yyyy/MM/dd HH:mm:ss"), scegliSedi.getLinguaScelta()));
			
			// determina rinunce se primo interpello
			if(scegliSedi.getInterpello().getId().getIdInterpello().equals(new BigDecimal(1))){
				scegliSedi.setFlagInterpelloRinunce(interpelloHome.controllaPresenzaInterpelloConRinunce(scegliSedi.getIdRegione()));
			}
			else{
				scegliSedi.setFlagInterpelloRinunce(false);
			}
		}
		catch(Exception e) {
			
			logger.error("ScegliSediAction - inizializzazione fallita", e);
			throw new GestioneErroriException("ScegliSediAction - inizializzazione fallita");
		}
	}
	
	//carica le sedi disponibili e quelle gi� selezionate per l'interpello
	@SuppressWarnings("unchecked")
	public void caricaSedi(ScegliSedi scegliSedi) throws GestioneErroriException {
		
		try {
			
			//ricerca sedi associate alla regione di candidatura
			AnagraficaFarm anagraficaFarm = new AnagraficaFarm();
			anagraficaFarm.setCodRegFarm(scegliSedi.getIdRegione());
			
			List<AnagraficaFarm> sediDisponibili = (List<AnagraficaFarm>) anagraficaFarmHome.findByExampleOrdered(anagraficaFarm);
			List<AnagraficaFarm> sediSelezionate = scegliSediHome.caricaSediSelezionate(scegliSedi.getCandidatura().getIdCandidatura());
			
			//popola la mappa di lookup contenente i dati di tutte le sedi disponibili per la regione
			scegliSedi.setAnagraficaFarmMap(new HashMap<String, AnagraficaFarm>());
			for(AnagraficaFarm sede : sediDisponibili) {
				
				if(sede != null) {
					
					scegliSedi.getAnagraficaFarmMap().put(sede.getIdFarm(), sede);
				}
			}
			
			HashMap < String , AnagraficaFarm> sediDisponibiliMap = new HashMap < String , AnagraficaFarm>();
			for(int i = 0; i < sediDisponibili.size(); i++) {
				sediDisponibiliMap.put(sediDisponibili.get(i).getIdFarm(), sediDisponibili.get(i));
									
			}
			List<AnagraficaFarm> sediDisponibiliFinale = new ArrayList<AnagraficaFarm>() ;
					
			//rimozione sedi gi� selezionate
			//if(!sediSelezionate.isEmpty()) {
				for(int j = 0; j < sediSelezionate.size(); j++) {
					sediDisponibiliMap.remove(sediSelezionate.get(j).getIdFarm());
					}	
				
				for(int i = 0; i < sediDisponibili.size(); i++) {
					if(sediDisponibiliMap.containsKey(sediDisponibili.get(i).getIdFarm())){
						sediDisponibiliFinale.add(sediDisponibiliMap.get(sediDisponibili.get(i).getIdFarm()));
					}
						
				}
			//}
			
			sediDisponibili = sediDisponibiliFinale;
	
			/*
			//rimozione sedi gi� selezionate
			if(!sediSelezionate.isEmpty()) {
				
				for(int i = 0; i < sediDisponibili.size(); i++) {
					
					for(int j = 0; j < sediSelezionate.size(); j++) {
						
						//se gli ID delle sedi coincidono..
						if(sediDisponibili.get(i).getIdFarm().equals(sediSelezionate.get(j).getIdFarm())) {
							
							//sediDisponibili.remove(i);
						}else{
							sediDisponibiliFinale.add(sediDisponibili.get(i));
						}
						
					}
				}
			}
			*/
			
			scegliSedi.setSedi(new DualListModel<AnagraficaFarm>(sediDisponibili,
																 sediSelezionate));
			scegliSedi.setSediSelezionate(sediSelezionate);
			scegliSedi.setNumSediSelezionate(( (Integer) sediSelezionate.size()).toString());
		}
		catch(Exception e) {
			
			logger.error("ScegliSediAction - caricamento delle sedi disponibili e selezionabili fallito", e);
			throw new GestioneErroriException("ScegliSediAction - caricamento delle sedi disponibili e selezionabili fallito");
		}
	}
	
	//restituisce una lista ordinata contenente i riferimenti alle sedi selezionate
	private List<CandidaturaSedi> determinaPreferenzeSedi(ScegliSedi scegliSedi) {
		
		List<CandidaturaSedi> candidaturaSediList = new ArrayList<CandidaturaSedi>();
		
		int i = 0;
		CandidaturaSedi candidaturaSedi = null;
		CandidaturaSediId candidaturaSediId = null;
		for(AnagraficaFarm anagraficaFarm : scegliSedi.getSedi().getTarget()) {
			
			i++;
			candidaturaSedi = new CandidaturaSedi();
				candidaturaSediId = new CandidaturaSediId(scegliSedi.getCandidatura().getIdCandidatura(),
														  anagraficaFarm.getIdFarm());
			candidaturaSedi.setId(candidaturaSediId);
			candidaturaSedi.setOrdineScelta(new BigDecimal(i));
			candidaturaSediList.add(candidaturaSedi);
		}
		
		return candidaturaSediList;
	}
	
	//salva una preferenza per ogni sede selezionata dall'utente
	public void salva(ScegliSedi scegliSedi) throws GestioneErroriException {
		
		try {
			
			candidaturaSediHome.salva(scegliSedi.getCandidatura().getIdCandidatura(),
									  determinaPreferenzeSedi(scegliSedi));
		}
		catch(Exception e) {
			
			logger.error("ScegliSediAction - salvataggio sedi selezionate fallito", e);
			throw new GestioneErroriException("ScegliSediAction - salvataggio sedi selezionate fallito");
		}
	}
	
	public void invia(ScegliSedi scegliSedi) throws GestioneErroriException {
		
		try {
			
			scegliSediHome.invia(scegliSedi.getCandidatura().getIdCandidatura(),
								 determinaPreferenzeSedi(scegliSedi),
								 scegliSedi.getUtente().getIdUtente());
			
			scegliSedi.setFlagSedi(flagValoreVero);
			
			//NOTA: il salvataggio delle preferenze e l'invio email avvengono in 2 transazioni distinte
			inviaMail(scegliSedi);
		}
		catch(Exception e) {
			
			logger.error("ScegliSediAction - invio preferenze sedi fallito", e);
			throw new GestioneErroriException("ScegliSediAction - invio preferenze sedi fallito");
		}
	}
	
	private MailBean preparaMailRicevutaSceltaSedi(String linguaScelta, String pecMailUtente, SceltaSediEntityPdf sceltaSediEntity, byte[] ricevutaByteArray) {
		
		MailBean mailBean = new MailBean();
		
		//destinatario
		ArrayList<String> listaDest = new ArrayList<String>();
		listaDest.add(pecMailUtente);
		mailBean.setToAddresses(listaDest);
		
		String descrizioneRegione = "";
		if(sceltaSediEntity.getCodiceRegione().equals("041") || sceltaSediEntity.getCodiceRegione().equals("042")) {
			
			descrizioneRegione = sceltaSediEntity.getDescRegione();
		}
		else {
			
			descrizioneRegione = StringUtil.getPropertyMessage("sceltasedi.testo.regione", linguaScelta)
								 .replace("<nome_regione>", sceltaSediEntity.getDescRegione());
		}
		
		//oggetto
		String oggettoMail = StringUtil.getPropertyMessage("scegliSedi.oggetto.mail.ricevuta", linguaScelta)
							 .replace("<data_inizio_interpello>", sceltaSediEntity.getDataInizioInterpello())
							 .replace("<regione>", descrizioneRegione)
							 .replace("<numero_protocollo>", sceltaSediEntity.getNumeroProtocolloDomanda());
		
		mailBean.setOggettoMail(oggettoMail);
		
		//corpo messaggio
		String corpoMail = StringUtil.getPropertyMessage("scegliSedi.corpo.mail.ricevuta", linguaScelta)
						   .replace("<nome>", sceltaSediEntity.getNome())
						   .replace("<cognome>", sceltaSediEntity.getCognome())
						   .replace("<data_inizio_interpello>", sceltaSediEntity.getDataInizioInterpello())
						   .replace("<regione>", descrizioneRegione);
		
		mailBean.setCorpoMail(corpoMail);
		
		//allegato
		mailBean.addAllegato(nomeFileRicevutaSceltaSedi, new ByteArrayInputStream(ricevutaByteArray), "application/pdf");
		
		return mailBean;
	}
	
	public void inviaMail(ScegliSedi scegliSedi) throws GestioneErroriException {
		
		//NOTA: la sequence viene staccata in ogni caso, anche se il metodo s'interrompe prima di aver composto l'email
		String idRicevuta = scegliSediHome.getIdRicevuta(scegliSedi.getIdRegione());
		
		//recupera data e orario correnti
		Date dataOdierna = DateUtil.getDataOdierna();
		Timestamp istanteCorrente = DateUtil.getCurrentTimestamp();
		
		//genera numero protocollo
		String numeroProtocollo = idRicevuta + " - " + StringUtil.dateToString(dataOdierna, "dd-MM-yyyy") + " - " + scegliSedi.getIdRegione();
		
		//popola bean contenente i dati da inserire nella ricevuta
		SceltaSediEntityPdf sceltaSediEntityPdf = scegliSediHome.getDatiPerRicevuta(scegliSedi.getUtente().getIdUtente());
		sceltaSediEntityPdf.setDataInvio( StringUtil.timestampToString(istanteCorrente, "dd/MM/yyyy HH:mm:ss") );
		sceltaSediEntityPdf.setNumeroProtocollo(numeroProtocollo);
		sceltaSediEntityPdf.setSediSelezionate(scegliSedi.getNumSediSelezionate());
		sceltaSediEntityPdf.setSedi(scegliSedi.getSediSelezionate());
		
		try {
			//crea documento PDF
			SceltaSediPdf sceltaSediPdf = new SceltaSediPdf();
			byte[] ricevutaByteArray = sceltaSediPdf.creaRicevutaPDF(sceltaSediEntityPdf);
			
			if(ricevutaByteArray != null) {
				
				Ricevute ricevuta = new Ricevute();
					RicevuteId id = new RicevuteId();
					id.setIdRicevuta(idRicevuta);
					id.setIdCandidatura(scegliSedi.getCandidatura().getIdCandidatura());
					id.setIdRegione(scegliSedi.getIdRegione());
					id.setTipoRicevuta(tipoRicevutaSceltaSedi);
				ricevuta.setId(id);
				ricevuta.setContenutoFile(ricevutaByteArray);
				ricevuta.setDataInvio(dataOdierna);
				
				if(ricevuteHome.insertRicevute(ricevuta)) {
					
					//invia email con la ricevuta
					scegliSediHome.sendMail( preparaMailRicevutaSceltaSedi(scegliSedi.getLinguaScelta(),
																		   scegliSedi.getUtente().getPecMail(),
																		   sceltaSediEntityPdf,
																		   ricevutaByteArray) );
				}
				else {
					
					throw new GestioneErroriException("ScegliSediAction - Errore durante il salvataggio della ricevuta");
				}
			}
			else {
				
				throw new GestioneErroriException("ScegliSediAction - Errore durante la creazione della ricevuta");
			}
		}
		catch(Exception e) {
			logger.error("ScegliSediAction - Errore durante la creazione della ricevuta", e);
			throw new GestioneErroriException("ScegliSediAction - Errore durante la creazione della ricevuta");
		}
	}
	
}
