package com.accenture.CCFarm.action;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.accenture.pm.autenticazione.Utente;

abstract public class GenericAction implements Serializable{
	protected HttpServletRequest request = null;
	protected HttpServletResponse response = null;

	public GenericAction(HttpServletRequest request,HttpServletResponse response) {
		this.request = request;
		this.response = response;
	}

	public Object validateRequest() throws Exception{
		return null;
	}
	
	public Object executeRequest() throws Exception{
		return "Generic Action";
	}

	public String formatter(Object bean) throws Exception{
		return "Generic JSON";
	}
	
//	public boolean userIsLogged() throws Exception{
//		
//		HttpSession session = request.getSession();
//		Utente utenteBean = (Utente) session.getAttribute("USER");
//		if(utenteBean!=null){
//			return true;
//		}else{
//			return false;
//		}
//		
//	}
	
}
