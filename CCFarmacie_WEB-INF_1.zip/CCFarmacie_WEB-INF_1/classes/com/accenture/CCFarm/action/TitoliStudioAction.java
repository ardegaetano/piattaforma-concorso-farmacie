package com.accenture.CCFarm.action;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;

import com.accenture.CCFarm.Bean.CorsoAgg;
import com.accenture.CCFarm.DAO.AltraLaurea;
import com.accenture.CCFarm.DAO.AltraLaureaBis;
import com.accenture.CCFarm.DAO.AltraLaureaBisHome;
import com.accenture.CCFarm.DAO.AltraLaureaHome;
import com.accenture.CCFarm.DAO.AltroTitolo;
import com.accenture.CCFarm.DAO.AltroTitoloHome;
import com.accenture.CCFarm.DAO.BorsaStudio;
import com.accenture.CCFarm.DAO.BorsaStudioHome;
import com.accenture.CCFarm.DAO.CorsoAggiornamento;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutiva;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutivaHome;
import com.accenture.CCFarm.DAO.Dottorato;
import com.accenture.CCFarm.DAO.DottoratoHome;
import com.accenture.CCFarm.DAO.Idoneita;
import com.accenture.CCFarm.DAO.IdoneitaHome;
import com.accenture.CCFarm.DAO.ProvinciaHome;
import com.accenture.CCFarm.DAO.Pubblicazione;
import com.accenture.CCFarm.DAO.PubblicazioneHome;
import com.accenture.CCFarm.DAO.Specializzazione;
import com.accenture.CCFarm.DAO.SpecializzazioneHome;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PageBean.TitoliStudioCarrieraBean;
import com.accenture.CCFarm.PageBean.TitoliStudioCarrieraBeanVisualizzazione;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.MatriceProperties;
import com.accenture.CCFarm.utility.MatricePropertiesDe;
import com.accenture.CCFarm.utility.StringUtil;

public class TitoliStudioAction {
	
	
	java.util.Date dataSys= new java.util.Date();
    private java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());
    Logger logger =Logger.getLogger("Bando");
	java.util.Date date;
  
	UtenteCandidatura utenteCandidatura;
	
	List province;
	ProvinciaHome provinciaHome;
	
	AltraLaurea altraLaurea;
	AltraLaureaHome altraLaureaHome;
	AltraLaureaBis altraLaureaBis;
	AltraLaureaBisHome altraLaureaBisHome;
	Specializzazione specializzazione;
	SpecializzazioneHome specializzazioneHome;
	BorsaStudio borsaStudio;
	BorsaStudioHome borsaStudioHome;
	Dottorato dottorato;
	DottoratoHome dottoratoHome;
	AltroTitolo altroTitolo;
	AltroTitoloHome altroTitoloHome;
	CorsoAggiornamento corsoAggiornamento;
	CorsoAggiornamentoHome corsoAggiornamentoHome;
	Pubblicazione pubblicazione;
	PubblicazioneHome pubblicazioneHome;
	Idoneita idoneita;
	IdoneitaHome idoneitaHome;
	DichiarazioneSostitutiva dichiarazioneSostitutiva;
	DichiarazioneSostitutivaHome dichiarazioneSostitutivaHome;
	
	ArrayList<AltraLaurea> altreLauree;
	ArrayList<AltraLaureaBis> altreLaureeBis;
	ArrayList<Specializzazione> specializzazioni;
	ArrayList<BorsaStudio> borseStudio;
	ArrayList<Dottorato> dottorati;
	ArrayList<AltroTitolo> altriTitoli;
	ArrayList<CorsoAggiornamento> corsiAggiornamento;
	ArrayList<Pubblicazione> pubblicazioni;
	ArrayList<Idoneita> listaIdoneita;
	
	ArrayList<com.accenture.CCFarm.Bean.Pubblicazione> listaPubb;
	ArrayList<com.accenture.CCFarm.Bean.Specializzazione> listaSpec;
	ArrayList<CorsoAgg> listaCorsi;
	ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis> listaLaureeBis;
	ArrayList<com.accenture.CCFarm.Bean.Dottorato> listaDott;
	ArrayList<com.accenture.CCFarm.Bean.AltroTitolo> listaTitoli;
	ArrayList<com.accenture.CCFarm.Bean.BorsaStudio> listaBorse;
	
	private SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	 HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	 String lingua= (String)session.getAttribute("linguaScelta");
	 
    MatriceProperties matriceIt = MatriceProperties.getMatricePropertiesIt();
    MatricePropertiesDe matriceDe = MatricePropertiesDe.getMatricePropertiesDe();
	public TitoliStudioAction(){
		
		altraLaureaHome = new AltraLaureaHome();
		altraLaureaBisHome = new AltraLaureaBisHome();
		specializzazioneHome = new SpecializzazioneHome();
		borsaStudioHome = new BorsaStudioHome();
		dottoratoHome = new DottoratoHome();
		altroTitoloHome = new AltroTitoloHome();
		corsoAggiornamentoHome = new CorsoAggiornamentoHome();
		pubblicazioneHome = new PubblicazioneHome();
	    idoneitaHome = new IdoneitaHome();
	    dichiarazioneSostitutivaHome = new DichiarazioneSostitutivaHome();
	} 
	
	public boolean loadPaginaInserimento(String idDomanda,TitoliStudioCarrieraBean titoliStudioCarriera) throws GestioneErroriException
	{
	    	try
	    	{
	    		Date data_corso_appoggio = ((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataInizioCorsi();
	    	    Date data_pubb_appoggio = ((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataInizioPubblicazioni();
	    	    
	    	    titoliStudioCarriera.setDataInizioCorsoReg(StringUtil.dateToString(data_corso_appoggio,sdf));
	    	    titoliStudioCarriera.setDataInizioPubblicazioneReg(StringUtil.dateToString(data_pubb_appoggio,sdf));
	    		
	    	    HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	    		String lingua= (String)session.getAttribute("linguaScelta");
	    		//popolo altra laurea 
	    		altraLaurea = new AltraLaurea();
	    		altraLaurea = altraLaureaHome.findById(idDomanda);
	    		
	    		//popolo altra laurea bis
	    		altreLaureeBis = new ArrayList<AltraLaureaBis>();
	    		altraLaureaBis = new AltraLaureaBis();
	    		altraLaureaBis.setIdDomandaLaureaBis(idDomanda);
	    		altreLaureeBis = (ArrayList<AltraLaureaBis>) altraLaureaBisHome.findByExample(altraLaureaBis);	    		
	    		//popolo specializzazione
	    		specializzazioni = new ArrayList<Specializzazione>();
	    		specializzazione = new Specializzazione();
	    		specializzazione.setIdDomandaSpec(idDomanda);
	    		specializzazioni = (ArrayList<Specializzazione>) specializzazioneHome.findByExample(specializzazione);
	    		
	    		//popolo borse di studio 
	    		borseStudio = new ArrayList<BorsaStudio>();
	    		borsaStudio = new BorsaStudio();
	    		borsaStudio.setIdDomandaBorsaStudio(idDomanda);
	    		borseStudio = (ArrayList<BorsaStudio>)borsaStudioHome.findByExample(borsaStudio);
	    	
	    		//popolo dottorati
	    		dottorati = new ArrayList<Dottorato>();
	    		dottorato = new Dottorato();
	    		dottorato.setIdDomandaDottorato(idDomanda);
	    		dottorati = (ArrayList<Dottorato>)dottoratoHome.findByExample(dottorato);
	
	    		//popolo altri titoli
	    		altriTitoli = new ArrayList<AltroTitolo>();
	       		altroTitolo = new AltroTitolo();
	    		altroTitolo.setIdDomandaTitolo(idDomanda);
	    		altriTitoli = (ArrayList<AltroTitolo>) altroTitoloHome.findByExample(altroTitolo);
	    		
	    		//popolo corsi di aggiornamento
	    		corsiAggiornamento = new ArrayList<CorsoAggiornamento>();
	    		corsoAggiornamento = new CorsoAggiornamento();
	    		corsoAggiornamento.setIdDomandaAgg(idDomanda);
	    		corsiAggiornamento = (ArrayList<CorsoAggiornamento>) corsoAggiornamentoHome.findByExample(corsoAggiornamento);
	    		
	    		//popolo pubblicazioni
	    		pubblicazioni = new ArrayList<Pubblicazione>();
	    		pubblicazione = new Pubblicazione();
	    		pubblicazione.setIdDomandaPubbl(idDomanda);
	    		pubblicazioni = (ArrayList<Pubblicazione>) pubblicazioneHome.findByExample(pubblicazione);
	    		
	    		//popolo idoneita
	    		idoneita = new Idoneita();
	    		idoneita = idoneitaHome.findById(idDomanda);
	    		
	    		
	    		if(altraLaurea!=null){	    			
	    				PropertyUtils.copyProperties(titoliStudioCarriera, altraLaurea);	    				
	    		} 
	    		
	    		
	    		listaCorsi = new ArrayList<CorsoAgg>();
	    		CorsoAgg corso;
	    		if(corsiAggiornamento!=null){
	    			for (int i=0;i<corsiAggiornamento.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				corso = new CorsoAgg();
	    				corso.setDataInizioCorsoAggStringa(StringUtil.dateToString(corsiAggiornamento.get(i).getDataInizioCorsoAgg(),sdf));
	    				corso.setDataFineCorsoAggStringa(StringUtil.dateToString(corsiAggiornamento.get(i).getDataFineCorsoAgg(),sdf));
	    				corso.setIdCorsoAgg(corsiAggiornamento.get(i).getIdCorsoAgg());
	    				corso.setDichiarazioneCorsoAgg(corsiAggiornamento.get(i).getDichiarazioneCorsoAgg());
	    				corso.setFlagEsteroCorsoAgg(corsiAggiornamento.get(i).getFlagEsteroCorsoAgg());
	    				corso.setDataInizioCorsoAgg(corsiAggiornamento.get(i).getDataInizioCorsoAgg());
	    				corso.setDataFineCorsoAgg(corsiAggiornamento.get(i).getDataFineCorsoAgg());
	    				corso.setOrganizzatoCorsoAgg(corsiAggiornamento.get(i).getOrganizzatoCorsoAgg());
	    				corso.setTitoloCorsoAgg(corsiAggiornamento.get(i).getTitoloCorsoAgg());
	    				corso.setTotOreCorsoAgg(corsiAggiornamento.get(i).getTotOreCorsoAgg());
	    				if(lingua.equalsIgnoreCase("de")){
	    					//corso.setDichiarazioneCorsoAgg(matriceDe.getMatricePropertiesDe(corsiAggiornamento.get(i).getDichiarazioneCorsoAgg().replace(" ", "_")));
	    					corso.setFlagEsteroCorsoAgg(matriceDe.getMatricePropertiesDe(corsiAggiornamento.get(i).getFlagEsteroCorsoAgg().replace(" ", "_")));
	    					String a = matriceDe.getMatricePropertiesDe(corsiAggiornamento.get(i).getDichiarazioneCorsoAgg().replace(" ", "_"));
	    					corso.setDichiarazioneCorsoAgg(a);	    				
	    				}
	    				listaCorsi.add(corso);
	    			}
	    		
	    		}    
	    		titoliStudioCarriera.setListaCorsiAgg(listaCorsi);
	    		
	    		
	    		listaTitoli = new ArrayList<com.accenture.CCFarm.Bean.AltroTitolo>();
	    		com.accenture.CCFarm.Bean.AltroTitolo titolo;
	    		if(altriTitoli!=null){
	    			for (int i=0;i<altriTitoli.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				titolo = new com.accenture.CCFarm.Bean.AltroTitolo();
	    				titolo.setDataRilascioAltroTitoloStringa(StringUtil.dateToString(altriTitoli.get(i).getDataRilascioAltroTitolo(),sdf));
	    				titolo.setIdAltroTitolo(altriTitoli.get(i).getIdAltroTitolo());
	    				titolo.setDataRilascioAltroTitolo(altriTitoli.get(i).getDataRilascioAltroTitolo());
	    				titolo.setDescAltroTitolo(altriTitoli.get(i).getDescAltroTitolo());
	    				titolo.setDurataAltroTitolo(altriTitoli.get(i).getDurataAltroTitolo());
	    				titolo.setEsameFinaleAltroTitolo(altriTitoli.get(i).getEsameFinaleAltroTitolo());
	    				titolo.setFlagEsteroAltroTitolo(altriTitoli.get(i).getFlagEsteroAltroTitolo());
	    				titolo.setNoteAltroTitolo(altriTitoli.get(i).getNoteAltroTitolo());
	    				titolo.setRilascioAltroTitolo(altriTitoli.get(i).getRilascioAltroTitolo());
	    				if(lingua.equalsIgnoreCase("de")){
	    					titolo.setEsameFinaleAltroTitolo(matriceDe.getMatricePropertiesDe(altriTitoli.get(i).getEsameFinaleAltroTitolo().replace(" ", "_")));
	    					titolo.setFlagEsteroAltroTitolo(matriceDe.getMatricePropertiesDe(altriTitoli.get(i).getFlagEsteroAltroTitolo().replace(" ", "_")));
	    					}
	    				listaTitoli.add(titolo);
	    			}
	    		
	    		}  
	    		titoliStudioCarriera.setListaAltriTitoli(listaTitoli);
	    		
	    		
	    		listaLaureeBis = new ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis>();
	    		com.accenture.CCFarm.Bean.AltraLaureaBis laureaBis;
	    		if(altreLaureeBis!=null){
	    			for (int i=0;i<altreLaureeBis.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    				
	    				laureaBis = new com.accenture.CCFarm.Bean.AltraLaureaBis();
	    				laureaBis.setDataSecondaLaureaBisStringa(StringUtil.dateToString(altreLaureeBis.get(i).getDataSecondaLaureaBis(),sdf));
	    				laureaBis.setIdAltraLaureaBis(altreLaureeBis.get(i).getIdAltraLaureaBis());
	    				laureaBis.setIdSecondaLaureaBis(altreLaureeBis.get(i).getIdSecondaLaureaBis());	    				
	    				laureaBis.setDataSecondaLaureaBis(altreLaureeBis.get(i).getDataSecondaLaureaBis());
	    				laureaBis.setDescUniSecondaLaureaBis(altreLaureeBis.get(i).getDescUniSecondaLaureaBis());
	    				laureaBis.setFlagEsteroSecondaLaureaBis(altreLaureeBis.get(i).getFlagEsteroSecondaLaureaBis());
	    				laureaBis.setLuogoSecondaLaureaBis(altreLaureeBis.get(i).getLuogoSecondaLaureaBis());
	    				laureaBis.setNazioneSecondaLaureaBis(altreLaureeBis.get(i).getNazioneSecondaLaureaBis());
	    				if(lingua.equalsIgnoreCase("de")){
	    					laureaBis.setFlagEsteroSecondaLaureaBis(matriceDe.getMatricePropertiesDe(altreLaureeBis.get(i).getFlagEsteroSecondaLaureaBis().replace(" ", "_")));
	    					laureaBis.setIdAltraLaureaBis(matriceDe.getMatricePropertiesDe(altreLaureeBis.get(i).getIdAltraLaureaBis().replace(" ", "_")));
	    					laureaBis.setNazioneSecondaLaureaBis(matriceDe.getMatricePropertiesDe(altreLaureeBis.get(i).getNazioneSecondaLaureaBis().replace(" ", "_")));
	    				}
	    				listaLaureeBis.add(laureaBis);
	    				
	    			}
	    		
	    		}  
	    		titoliStudioCarriera.setListaAltreLaureeBis(listaLaureeBis);
	    		
	    		
	    		listaSpec = new ArrayList<com.accenture.CCFarm.Bean.Specializzazione>();
	    		com.accenture.CCFarm.Bean.Specializzazione spec;
	    		if(specializzazioni!=null){	    			
	    			for (int i=0;i<specializzazioni.size();i++){
	    				spec = new com.accenture.CCFarm.Bean.Specializzazione();
	    				spec.setIdSpecializzazione(specializzazioni.get(i).getIdSpecializzazione());
	    				spec.setDenominazioneSpec(specializzazioni.get(i).getDenominazioneSpec());
	    				spec.setDescrFacoltaSpec(specializzazioni.get(i).getDescrFacoltaSpec());
	    				spec.setDescrUniversitaSpec(specializzazioni.get(i).getDescrUniversitaSpec());
	    				spec.setDurataSpec(specializzazioni.get(i).getDurataSpec());
	    				spec.setFlagEsteroSpec(specializzazioni.get(i).getFlagEsteroSpec());
	    				spec.setLuogoSpec(specializzazioni.get(i).getLuogoSpec());
	    				spec.setNazioneSpec(specializzazioni.get(i).getNazioneSpec());
	    				if(lingua.equalsIgnoreCase("de")){
	    					spec.setNazioneSpec(matriceDe.getMatricePropertiesDe(specializzazioni.get(i).getNazioneSpec().replace(" ", "_")));
	    					spec.setFlagEsteroSpec(matriceDe.getMatricePropertiesDe(specializzazioni.get(i).getFlagEsteroSpec().replace(" ", "_")));
	    					}
	    				listaSpec.add(spec);
	    			}
	    		
	    		}  
	    		titoliStudioCarriera.setListaSpecializzazioni(listaSpec);
	    		
	    		
	    		listaPubb = new ArrayList<com.accenture.CCFarm.Bean.Pubblicazione>();
	    		com.accenture.CCFarm.Bean.Pubblicazione pubb;
	    		if(pubblicazioni!=null){
	    			for (int i=0;i<pubblicazioni.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				pubb = new com.accenture.CCFarm.Bean.Pubblicazione();
	    				pubb.setDataPubblicazioneStringa(StringUtil.dateToString(pubblicazioni.get(i).getDataPubblicazione(),sdf));
	    				pubb.setIdPubblicazione(pubblicazioni.get(i).getIdPubblicazione());
	    				pubb.setAutorePubblicazione(pubblicazioni.get(i).getAutorePubblicazione());
	    				pubb.setCodIsbn(pubblicazioni.get(i).getCodIsbn());
	    				pubb.setDataPubblicazione(pubblicazioni.get(i).getDataPubblicazione());
	    				pubb.setEditorePubblicazione(pubblicazioni.get(i).getEditorePubblicazione());
	    				pubb.setTipoPubblicazione(pubblicazioni.get(i).getTipoPubblicazione());
	    				pubb.setTitoloPubblicazione(pubblicazioni.get(i).getTitoloPubblicazione());
	    				if(lingua.equalsIgnoreCase("de")){
	    					pubb.setTipoPubblicazione(matriceDe.getMatricePropertiesDe(pubblicazioni.get(i).getTipoPubblicazione().replace(" ", "_")));	
	    				}
	    				listaPubb.add(pubb);
	    			}
	    		
	    		}  
	    		titoliStudioCarriera.setListaPubblicazioni(listaPubb);
	    		
	    		
	    		listaBorse = new ArrayList<com.accenture.CCFarm.Bean.BorsaStudio>();
	    		com.accenture.CCFarm.Bean.BorsaStudio borsa;
	    		if(borseStudio!=null){
	    			for (int i=0;i<borseStudio.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				borsa = new com.accenture.CCFarm.Bean.BorsaStudio();
	    				borsa.setDataInizioBorsaStringa(StringUtil.dateToString(borseStudio.get(i).getDataInizioBorsa(),sdf));
	    				borsa.setDataFineBorsaStringa(StringUtil.dateToString(borseStudio.get(i).getDataFineBorsa(),sdf));
	    				borsa.setIdBorsaStudio(borseStudio.get(i).getIdBorsaStudio());
	    				borsa.setDataFineBorsa(borseStudio.get(i).getDataFineBorsa());
	    				borsa.setDataInizioBorsa(borseStudio.get(i).getDataInizioBorsa());
	    				borsa.setDenominazioneBorsa(borseStudio.get(i).getDenominazioneBorsa());
	    				borsa.setDescrFacoltaBorsa(borseStudio.get(i).getDescrFacoltaBorsa());
	    				borsa.setDescrUniversitaBorsa(borseStudio.get(i).getDescrUniversitaBorsa());
	    				borsa.setFlagEsteroBorsa(borseStudio.get(i).getFlagEsteroBorsa());
	    				borsa.setLuogoBorsa(borseStudio.get(i).getLuogoBorsa());
	    				borsa.setNazioneBorsa(borseStudio.get(i).getNazioneBorsa());
	    				if(lingua.equalsIgnoreCase("de")){
	    					borsa.setNazioneBorsa(matriceDe.getMatricePropertiesDe(borseStudio.get(i).getNazioneBorsa().replace(" ", "_")));
	    					borsa.setFlagEsteroBorsa(matriceDe.getMatricePropertiesDe(borseStudio.get(i).getFlagEsteroBorsa().replace(" ", "_")));
	    					}
	    				listaBorse.add(borsa);
	    			}
	    		
	    		}
	    		titoliStudioCarriera.setListaBorseStudio(listaBorse);
	    		
	    		
	    		listaDott = new ArrayList<com.accenture.CCFarm.Bean.Dottorato>();
	    		com.accenture.CCFarm.Bean.Dottorato dott;
	    		if(dottorati!=null){
	    			for (int i=0;i<dottorati.size();i++){ 
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				dott = new com.accenture.CCFarm.Bean.Dottorato();
	    				dott.setDataInizioDottoratoStringa(StringUtil.dateToString(dottorati.get(i).getDataInizioDottorato(),sdf));
	    				dott.setDataFineDottoratoStringa(StringUtil.dateToString(dottorati.get(i).getDataFineDottorato(),sdf));
	    				dott.setIdDottorato(dottorati.get(i).getIdDottorato());
	    				dott.setDataFineDottorato(dottorati.get(i).getDataFineDottorato());
	    				dott.setDataInizioDottorato(dottorati.get(i).getDataInizioDottorato());
	    				dott.setDenominazioneDottorato(dottorati.get(i).getDenominazioneDottorato());
	    				dott.setDescrFacoltaDottorato(dottorati.get(i).getDescrFacoltaDottorato());
	    				dott.setDescrUniversitaDottorato(dottorati.get(i).getDescrUniversitaDottorato());
	    				dott.setFlagEsteroDottorato(dottorati.get(i).getFlagEsteroDottorato());
	    				dott.setLuogoDottorato(dottorati.get(i).getLuogoDottorato());
	    				dott.setNazioneDottorato(dottorati.get(i).getNazioneDottorato());
	    				if(lingua.equalsIgnoreCase("de")){
	    					dott.setNazioneDottorato(matriceDe.getMatricePropertiesDe(dottorati.get(i).getNazioneDottorato().replace(" ", "_")));
	    					dott.setFlagEsteroDottorato(matriceDe.getMatricePropertiesDe(dottorati.get(i).getFlagEsteroDottorato().replace(" ", "_")));
	    					}
	    				listaDott.add(dott);
	    			}
	    		
	    		}
	    		titoliStudioCarriera.setListaDottorati(listaDott);
	    		
	    		
//	    		if (listaIdoneita!=null){
//	    			for (int i=0;i<listaIdoneita.size();i++){
//	    				PropertyUtils.copyProperties(titoliStudioCarriera, listaIdoneita.get(i));
//	    			}
//	    			
//	    		}
	    		
	    		if (idoneita!=null){	    			
	    				PropertyUtils.copyProperties(titoliStudioCarriera, idoneita);	    			
	    		}
	    		
	    		
	    	}
	    	catch(RuntimeException re)
	    	{
	    		re.printStackTrace();
	    		return false;
	    	} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
	   		
	   		return true;
	    }

	 
	 
	 
	 public boolean loadPaginaInserimentoVisualizzazione(String idDomanda,TitoliStudioCarrieraBeanVisualizzazione titoliStudioCarrieraVisualizzazione) throws GestioneErroriException
	    {
	    	try
	    	{
	    		Date data_corso_appoggio = ((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataInizioCorsi();
	    	    Date data_pubb_appoggio = ((DatiBando)GetSessionUtility.getSessionAttribute("DATI_BANDO")).getDataInizioPubblicazioni();
	    		
	    	    titoliStudioCarrieraVisualizzazione.setDataInizioPubblicazioneReg(StringUtil.dateToString(data_pubb_appoggio,sdf));
	    		titoliStudioCarrieraVisualizzazione.setDataInizioCorsoReg(StringUtil.dateToString(data_corso_appoggio,sdf));
	    	    
	    		HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	    		String lingua= (String)session.getAttribute("linguaScelta");
	    		//popolo altra laurea 
			 	sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		altraLaurea = new AltraLaurea();
	    		altraLaurea = altraLaureaHome.findById(idDomanda);
	    		
	    		//popolo altra laurea bis
	    		altreLaureeBis = new ArrayList<AltraLaureaBis>();
	    		altraLaureaBis = new AltraLaureaBis();
	    		altraLaureaBis.setIdDomandaLaureaBis(idDomanda);
	    		altreLaureeBis = (ArrayList<AltraLaureaBis>) altraLaureaBisHome.findByExample(altraLaureaBis);	    		
	    		//popolo specializzazione
	    		specializzazioni = new ArrayList<Specializzazione>();
	    		specializzazione = new Specializzazione();
	    		specializzazione.setIdDomandaSpec(idDomanda);
	    		specializzazioni = (ArrayList<Specializzazione>) specializzazioneHome.findByExample(specializzazione);
	    		
	    		//popolo borse di studio 
	    		borseStudio = new ArrayList<BorsaStudio>();
	    		borsaStudio = new BorsaStudio();
	    		borsaStudio.setIdDomandaBorsaStudio(idDomanda);
	    		borseStudio = (ArrayList<BorsaStudio>)borsaStudioHome.findByExample(borsaStudio);
	    	
	    		//popolo dottorati
	    		dottorati = new ArrayList<Dottorato>();
	    		dottorato = new Dottorato();
	    		dottorato.setIdDomandaDottorato(idDomanda);
	    		dottorati = (ArrayList<Dottorato>)dottoratoHome.findByExample(dottorato);
	
	    		//popolo altri titoli
	    		altriTitoli = new ArrayList<AltroTitolo>();
	       		altroTitolo = new AltroTitolo();
	    		altroTitolo.setIdDomandaTitolo(idDomanda);
	    		altriTitoli = (ArrayList<AltroTitolo>) altroTitoloHome.findByExample(altroTitolo);
	    		
	    		//popolo corsi di aggiornamento
	    		corsiAggiornamento = new ArrayList<CorsoAggiornamento>();
	    		corsoAggiornamento = new CorsoAggiornamento();
	    		corsoAggiornamento.setIdDomandaAgg(idDomanda);
	    		corsiAggiornamento = (ArrayList<CorsoAggiornamento>) corsoAggiornamentoHome.findByExample(corsoAggiornamento);
	    		
	    		//popolo pubblicazioni
	    		pubblicazioni = new ArrayList<Pubblicazione>();
	    		pubblicazione = new Pubblicazione();
	    		pubblicazione.setIdDomandaPubbl(idDomanda);
	    		pubblicazioni = (ArrayList<Pubblicazione>) pubblicazioneHome.findByExample(pubblicazione);
	    		
	    		//popolo idoneita
	    		idoneita = new Idoneita();
	    		idoneita = idoneitaHome.findById(idDomanda);
	    		
	    		
	    		//popolo dichiarazione sostitutiva
	    		dichiarazioneSostitutiva = new DichiarazioneSostitutiva();
	    		dichiarazioneSostitutiva = dichiarazioneSostitutivaHome.findById(idDomanda);
	    		
	    		if(altraLaurea!=null){	  
	    			if(lingua.equalsIgnoreCase("de")){
	    				altraLaurea.setIdSecondaLaurea(matriceDe.getMatricePropertiesDe(altraLaurea.getIdSecondaLaurea().replace(" ", "_")));
						altraLaurea.setNazioneSecondaLaurea(matriceDe.getMatricePropertiesDe(altraLaurea.getNazioneSecondaLaurea().replace(" ", "_")));
					    altraLaurea.setFlagEsteroSecondaLaurea(matriceDe.getMatricePropertiesDe(altraLaurea.getFlagEsteroSecondaLaurea().replace(" ", "_")));	
	    			}
	    		PropertyUtils.copyProperties(titoliStudioCarrieraVisualizzazione, altraLaurea);	    				
	    		
	    		
	    		if(altraLaurea.getDataSecondaLaurea()!=null)
	    		titoliStudioCarrieraVisualizzazione.setDataSecondaLaureaString(StringUtil.dateToString(altraLaurea.getDataSecondaLaurea(),sdf));
	    		
	    		} 
	    		listaCorsi = new ArrayList<CorsoAgg>();
	    		CorsoAgg corso;
	    		if(corsiAggiornamento!=null){
	    			for (int i=0;i<corsiAggiornamento.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				corso = new CorsoAgg();
	    				corso.setDataInizioCorsoAggStringa(StringUtil.dateToString(corsiAggiornamento.get(i).getDataInizioCorsoAgg(),sdf));
	    				corso.setDataFineCorsoAggStringa(StringUtil.dateToString(corsiAggiornamento.get(i).getDataFineCorsoAgg(),sdf));
	    				corso.setIdCorsoAgg(corsiAggiornamento.get(i).getIdCorsoAgg());
	    				corso.setDichiarazioneCorsoAgg(corsiAggiornamento.get(i).getDichiarazioneCorsoAgg());
	    				corso.setFlagEsteroCorsoAgg(corsiAggiornamento.get(i).getFlagEsteroCorsoAgg());
//	    				corso.setGiornoPeriodoCorsoAgg(corsiAggiornamento.get(i).getGiornoPeriodoCorsoAgg());
	    				corso.setDataInizioCorsoAgg(corsiAggiornamento.get(i).getDataInizioCorsoAgg());
	    				corso.setDataFineCorsoAgg(corsiAggiornamento.get(i).getDataFineCorsoAgg());
	    				corso.setOrganizzatoCorsoAgg(corsiAggiornamento.get(i).getOrganizzatoCorsoAgg());
	    				corso.setTitoloCorsoAgg(corsiAggiornamento.get(i).getTitoloCorsoAgg());
	    				corso.setTotOreCorsoAgg(corsiAggiornamento.get(i).getTotOreCorsoAgg());
	    				if(lingua.equalsIgnoreCase("de")){
	    					//corso.setDichiarazioneCorsoAgg(matriceDe.getMatricePropertiesDe(corsiAggiornamento.get(i).getDichiarazioneCorsoAgg().replace(" ", "_")));
	    					corso.setFlagEsteroCorsoAgg(matriceDe.getMatricePropertiesDe(corsiAggiornamento.get(i).getFlagEsteroCorsoAgg().replace(" ", "_")));
	    					String a = matriceDe.getMatricePropertiesDe(corsiAggiornamento.get(i).getDichiarazioneCorsoAgg().replace(" ", "_"));
	    					corso.setDichiarazioneCorsoAgg(a);	    				
	    				}
	    				listaCorsi.add(corso);
	    			}
	    		
	    		    
	    		titoliStudioCarrieraVisualizzazione.setListaCorsiAgg(listaCorsi);
	    		}
	    		
	    		listaTitoli = new ArrayList<com.accenture.CCFarm.Bean.AltroTitolo>();
	    		com.accenture.CCFarm.Bean.AltroTitolo titolo;
	    		if(altriTitoli!=null){
	    			for (int i=0;i<altriTitoli.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				titolo = new com.accenture.CCFarm.Bean.AltroTitolo();
	    				titolo.setDataRilascioAltroTitoloStringa(StringUtil.dateToString(altriTitoli.get(i).getDataRilascioAltroTitolo(),sdf));
	    				titolo.setIdAltroTitolo(altriTitoli.get(i).getIdAltroTitolo());
	    				titolo.setDataRilascioAltroTitolo(altriTitoli.get(i).getDataRilascioAltroTitolo());
	    				titolo.setDescAltroTitolo(altriTitoli.get(i).getDescAltroTitolo());
	    				titolo.setDurataAltroTitolo(altriTitoli.get(i).getDurataAltroTitolo());
	    				titolo.setEsameFinaleAltroTitolo(altriTitoli.get(i).getEsameFinaleAltroTitolo());
	    				titolo.setFlagEsteroAltroTitolo(altriTitoli.get(i).getFlagEsteroAltroTitolo());
	    				titolo.setNoteAltroTitolo(altriTitoli.get(i).getNoteAltroTitolo());
	    				titolo.setRilascioAltroTitolo(altriTitoli.get(i).getRilascioAltroTitolo());
	    				if(lingua.equalsIgnoreCase("de")){
	    					titolo.setEsameFinaleAltroTitolo(matriceDe.getMatricePropertiesDe(altriTitoli.get(i).getEsameFinaleAltroTitolo().replace(" ", "_")));
	    					titolo.setFlagEsteroAltroTitolo(matriceDe.getMatricePropertiesDe(altriTitoli.get(i).getFlagEsteroAltroTitolo().replace(" ", "_")));
	    					}
	    				listaTitoli.add(titolo);
	    			}
	    		
	    		  
	    		titoliStudioCarrieraVisualizzazione.setListaAltriTitoli(listaTitoli);
	    	}
	    		
	    		listaLaureeBis = new ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis>();
	    		com.accenture.CCFarm.Bean.AltraLaureaBis laureaBis;
	    		if(altreLaureeBis!=null){
	    			for (int i=0;i<altreLaureeBis.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				laureaBis = new com.accenture.CCFarm.Bean.AltraLaureaBis();
	    				laureaBis.setDataSecondaLaureaBisStringa(StringUtil.dateToString(altreLaureeBis.get(i).getDataSecondaLaureaBis(),sdf));
	    				laureaBis.setIdAltraLaureaBis(altreLaureeBis.get(i).getIdAltraLaureaBis());
	    				laureaBis.setIdSecondaLaureaBis(altreLaureeBis.get(i).getIdSecondaLaureaBis());	    				
	    				laureaBis.setDataSecondaLaureaBis(altreLaureeBis.get(i).getDataSecondaLaureaBis());
	    				laureaBis.setDescUniSecondaLaureaBis(altreLaureeBis.get(i).getDescUniSecondaLaureaBis());
	    				laureaBis.setFlagEsteroSecondaLaureaBis(altreLaureeBis.get(i).getFlagEsteroSecondaLaureaBis());
	    				laureaBis.setLuogoSecondaLaureaBis(altreLaureeBis.get(i).getLuogoSecondaLaureaBis());
	    				laureaBis.setNazioneSecondaLaureaBis(altreLaureeBis.get(i).getNazioneSecondaLaureaBis());
	    				if(lingua.equalsIgnoreCase("de")){
	    					laureaBis.setFlagEsteroSecondaLaureaBis(matriceDe.getMatricePropertiesDe(altreLaureeBis.get(i).getFlagEsteroSecondaLaureaBis().replace(" ", "_")));
	    					laureaBis.setIdAltraLaureaBis(matriceDe.getMatricePropertiesDe(altreLaureeBis.get(i).getIdAltraLaureaBis().replace(" ", "_")));
	    					laureaBis.setNazioneSecondaLaureaBis(matriceDe.getMatricePropertiesDe(altreLaureeBis.get(i).getNazioneSecondaLaureaBis().replace(" ", "_")));
	    				}
	    				listaLaureeBis.add(laureaBis);
	    				
	    			}
	    		
	    		}  
	    		titoliStudioCarrieraVisualizzazione.setListaAltreLaureeBis(listaLaureeBis);
	    		
	    		
	    		listaSpec = new ArrayList<com.accenture.CCFarm.Bean.Specializzazione>();
	    		com.accenture.CCFarm.Bean.Specializzazione spec;
	    		if(specializzazioni!=null){	    			
	    			for (int i=0;i<specializzazioni.size();i++){
	    				spec = new com.accenture.CCFarm.Bean.Specializzazione();
	    				spec.setIdSpecializzazione(specializzazioni.get(i).getIdSpecializzazione());
	    				spec.setDenominazioneSpec(specializzazioni.get(i).getDenominazioneSpec());
	    				spec.setDescrFacoltaSpec(specializzazioni.get(i).getDescrFacoltaSpec());
	    				spec.setDescrUniversitaSpec(specializzazioni.get(i).getDescrUniversitaSpec());
	    				spec.setDurataSpec(specializzazioni.get(i).getDurataSpec());
	    				spec.setFlagEsteroSpec(specializzazioni.get(i).getFlagEsteroSpec());
	    				spec.setLuogoSpec(specializzazioni.get(i).getLuogoSpec());
	    				spec.setNazioneSpec(specializzazioni.get(i).getNazioneSpec());
	    				if(lingua.equalsIgnoreCase("de")){
	    					spec.setNazioneSpec(matriceDe.getMatricePropertiesDe(specializzazioni.get(i).getNazioneSpec().replace(" ", "_")));
	    					spec.setFlagEsteroSpec(matriceDe.getMatricePropertiesDe(specializzazioni.get(i).getFlagEsteroSpec().replace(" ", "_")));
	    					}
	    				listaSpec.add(spec);
	    			}
	    		
	    		 
	    		titoliStudioCarrieraVisualizzazione.setListaSpecializzazioni(listaSpec);
	    		} 
	    		
	    		listaPubb = new ArrayList<com.accenture.CCFarm.Bean.Pubblicazione>();
	    		com.accenture.CCFarm.Bean.Pubblicazione pubb;
	    		if(pubblicazioni!=null){
	    			for (int i=0;i<pubblicazioni.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				pubb = new com.accenture.CCFarm.Bean.Pubblicazione();
	    				pubb.setDataPubblicazioneStringa(StringUtil.dateToString(pubblicazioni.get(i).getDataPubblicazione(),sdf));
	    				pubb.setIdPubblicazione(pubblicazioni.get(i).getIdPubblicazione());
	    				pubb.setAutorePubblicazione(pubblicazioni.get(i).getAutorePubblicazione());
	    				pubb.setCodIsbn(pubblicazioni.get(i).getCodIsbn());
	    				pubb.setDataPubblicazione(pubblicazioni.get(i).getDataPubblicazione());
	    				pubb.setEditorePubblicazione(pubblicazioni.get(i).getEditorePubblicazione());
	    				pubb.setTipoPubblicazione(pubblicazioni.get(i).getTipoPubblicazione());
	    				pubb.setTitoloPubblicazione(pubblicazioni.get(i).getTitoloPubblicazione());
	    				if(lingua.equalsIgnoreCase("de")){
	    					pubb.setTipoPubblicazione(matriceDe.getMatricePropertiesDe(pubblicazioni.get(i).getTipoPubblicazione().replace(" ", "_")));	
	    				}
	    				listaPubb.add(pubb);
	    			}
	    		
	    		 
	    		titoliStudioCarrieraVisualizzazione.setListaPubblicazioni(listaPubb);
	    		} 
	    		
	    		listaBorse = new ArrayList<com.accenture.CCFarm.Bean.BorsaStudio>();
	    		com.accenture.CCFarm.Bean.BorsaStudio borsa;
	    		if(borseStudio!=null){
	    			for (int i=0;i<borseStudio.size();i++){
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				borsa = new com.accenture.CCFarm.Bean.BorsaStudio();
	    				borsa.setDataInizioBorsaStringa(StringUtil.dateToString((borseStudio.get(i).getDataInizioBorsa()),sdf));
	    				borsa.setDataFineBorsaStringa(StringUtil.dateToString(borseStudio.get(i).getDataFineBorsa(),sdf));
	    				borsa.setIdBorsaStudio(borseStudio.get(i).getIdBorsaStudio());
	    				borsa.setDataFineBorsa(borseStudio.get(i).getDataFineBorsa());
	    				borsa.setDataInizioBorsa(borseStudio.get(i).getDataInizioBorsa());
	    				borsa.setDenominazioneBorsa(borseStudio.get(i).getDenominazioneBorsa());
	    				borsa.setDescrFacoltaBorsa(borseStudio.get(i).getDescrFacoltaBorsa());
	    				borsa.setDescrUniversitaBorsa(borseStudio.get(i).getDescrUniversitaBorsa());
	    				borsa.setFlagEsteroBorsa(borseStudio.get(i).getFlagEsteroBorsa());
	    				borsa.setLuogoBorsa(borseStudio.get(i).getLuogoBorsa());
	    				borsa.setNazioneBorsa(borseStudio.get(i).getNazioneBorsa());
	    				if(lingua.equalsIgnoreCase("de")){
	    					borsa.setNazioneBorsa(matriceDe.getMatricePropertiesDe(borseStudio.get(i).getNazioneBorsa().replace(" ", "_")));
	    					borsa.setFlagEsteroBorsa(matriceDe.getMatricePropertiesDe(borseStudio.get(i).getFlagEsteroBorsa().replace(" ", "_")));
	    					}
	    				listaBorse.add(borsa);
	    			}
	    		
	    		
	    		titoliStudioCarrieraVisualizzazione.setListaBorseStudio(listaBorse);
	    		}
	    		
	    		listaDott = new ArrayList<com.accenture.CCFarm.Bean.Dottorato>();
	    		com.accenture.CCFarm.Bean.Dottorato dott;
	    		if(dottorati!=null){
	    			for (int i=0;i<dottorati.size();i++){ 
	    				sdf = new SimpleDateFormat("dd-MM-yyyy");
	    		        
	    				dott = new com.accenture.CCFarm.Bean.Dottorato();
	    				dott.setDataInizioDottoratoStringa(StringUtil.dateToString(dottorati.get(i).getDataInizioDottorato(),sdf));
	    				dott.setDataFineDottoratoStringa(StringUtil.dateToString(dottorati.get(i).getDataFineDottorato(),sdf));
	    				dott.setIdDottorato(dottorati.get(i).getIdDottorato());
	    				dott.setDataFineDottorato(dottorati.get(i).getDataFineDottorato());
	    				dott.setDataInizioDottorato(dottorati.get(i).getDataInizioDottorato());
	    				dott.setDenominazioneDottorato(dottorati.get(i).getDenominazioneDottorato());
	    				dott.setDescrFacoltaDottorato(dottorati.get(i).getDescrFacoltaDottorato());
	    				dott.setDescrUniversitaDottorato(dottorati.get(i).getDescrUniversitaDottorato());
	    				dott.setFlagEsteroDottorato(dottorati.get(i).getFlagEsteroDottorato());
	    				dott.setLuogoDottorato(dottorati.get(i).getLuogoDottorato());
	    				dott.setNazioneDottorato(dottorati.get(i).getNazioneDottorato());
	    				if(lingua.equalsIgnoreCase("de")){
	    					dott.setNazioneDottorato(matriceDe.getMatricePropertiesDe(dottorati.get(i).getNazioneDottorato().replace(" ", "_")));
	    					dott.setFlagEsteroDottorato(matriceDe.getMatricePropertiesDe(dottorati.get(i).getFlagEsteroDottorato().replace(" ", "_")));
	    					}
	    				listaDott.add(dott);
	    			}
	    		
	    		
	    		titoliStudioCarrieraVisualizzazione.setListaDottorati(listaDott);
	    		}
	    		
//	    		if (listaIdoneita!=null){
//	    			for (int i=0;i<listaIdoneita.size();i++){
//	    				PropertyUtils.copyProperties(titoliStudioCarriera, listaIdoneita.get(i));
//	    			}
//	    			
//	    		}
	    		
	    		if (idoneita!=null){	    			
	    				PropertyUtils.copyProperties(titoliStudioCarrieraVisualizzazione, idoneita);	    			
	    		}
	    		
	    		if(dichiarazioneSostitutiva!=null){
	    			titoliStudioCarrieraVisualizzazione.setDichiarazioneSostitutiva(dichiarazioneSostitutiva);
	    		}
	    		
	    		
	    		
	    	}
	    	catch(RuntimeException re)
	    	{
	    		re.printStackTrace();
	    		return false;
	    	} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
	   		
	   		return true;
	    }
	
	public void loadPaginaInserimentoVisualizzazione(TitoliStudioCarrieraBean titoliStudioCarrieraBean,TitoliStudioCarrieraBeanVisualizzazione titoliStudioCarrieraVisualizzazione) throws Exception
	{
		if(titoliStudioCarrieraBean==null || titoliStudioCarrieraVisualizzazione==null)
			throw new Exception("[Visualizzazione Domanda: Impossibile inizializzare Titoli]");
		
		PropertyUtils.copyProperties(titoliStudioCarrieraVisualizzazione,titoliStudioCarrieraBean);	    				
	    
		if(titoliStudioCarrieraVisualizzazione.getDataSecondaLaurea()!=null)
			titoliStudioCarrieraVisualizzazione.setDataSecondaLaureaString(StringUtil.dateToString(titoliStudioCarrieraVisualizzazione.getDataSecondaLaurea(),sdf));
	
		//copia le liste di titoli nel bean in visualizzazione
		if(lingua.equalsIgnoreCase("de")){
			titoliStudioCarrieraVisualizzazione.setIdSecondaLaurea(matriceDe.getMatricePropertiesDe(titoliStudioCarrieraBean.getIdSecondaLaurea().replace(" ", "_")));
			titoliStudioCarrieraVisualizzazione.setFlagEsteroSecondaLaurea(matriceDe.getMatricePropertiesDe(titoliStudioCarrieraBean.getFlagEsteroSecondaLaurea().replace(" ", "_")));
			titoliStudioCarrieraVisualizzazione.setNazioneSecondaLaurea(matriceDe.getMatricePropertiesDe(titoliStudioCarrieraBean.getNazioneSecondaLaurea().replace(" ", "_")));
			}
		titoliStudioCarrieraVisualizzazione.getListaAltreLaureeBis().addAll(titoliStudioCarrieraBean.getListaAltreLaureeBis());
		titoliStudioCarrieraVisualizzazione.getListaAltriTitoli().addAll(titoliStudioCarrieraBean.getListaAltriTitoli());
		titoliStudioCarrieraVisualizzazione.getListaBorseStudio().addAll(titoliStudioCarrieraBean.getListaBorseStudio());
		titoliStudioCarrieraVisualizzazione.getListaCorsiAgg().addAll(titoliStudioCarrieraBean.getListaCorsiAgg());
		titoliStudioCarrieraVisualizzazione.getListaDottorati().addAll(titoliStudioCarrieraBean.getListaDottorati());
		titoliStudioCarrieraVisualizzazione.getListaPubblicazioni().addAll(titoliStudioCarrieraBean.getListaPubblicazioni());
		titoliStudioCarrieraVisualizzazione.getListaSpecializzazioni().addAll(titoliStudioCarrieraBean.getListaSpecializzazioni());
		
	}
	
	public boolean updateDAO(String idDomanda,TitoliStudioCarrieraBean titoliStudioCarrieraBean) throws GestioneErroriException
	{
	
			//preleva i dati dal bean di pagina e li copia nei bean di hibernate
			try
					{
				        ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis> listaLaureeBis;
				        listaLaureeBis = (ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis>)titoliStudioCarrieraBean.getListaAltreLaureeBis();
				        ArrayList<com.accenture.CCFarm.Bean.AltroTitolo> listaTitoli;
				        listaTitoli = (ArrayList<com.accenture.CCFarm.Bean.AltroTitolo>)titoliStudioCarrieraBean.getListaAltriTitoli();
				        ArrayList<com.accenture.CCFarm.Bean.CorsoAgg> listaCorsi;
				        listaCorsi = (ArrayList<com.accenture.CCFarm.Bean.CorsoAgg>)titoliStudioCarrieraBean.getListaCorsiAgg();
				        ArrayList<com.accenture.CCFarm.Bean.Dottorato> listaDott;
				        listaDott = (ArrayList<com.accenture.CCFarm.Bean.Dottorato>)titoliStudioCarrieraBean.getListaDottorati();
				        ArrayList<com.accenture.CCFarm.Bean.Pubblicazione> listaPubb;
				        listaPubb = (ArrayList<com.accenture.CCFarm.Bean.Pubblicazione>)titoliStudioCarrieraBean.getListaPubblicazioni();
				        ArrayList<com.accenture.CCFarm.Bean.Specializzazione> listaSpec;
				        listaSpec = (ArrayList<com.accenture.CCFarm.Bean.Specializzazione>)titoliStudioCarrieraBean.getListaSpecializzazioni();
				        ArrayList<com.accenture.CCFarm.Bean.BorsaStudio> listaBorse;
				        listaBorse = (ArrayList<com.accenture.CCFarm.Bean.BorsaStudio>)titoliStudioCarrieraBean.getListaBorseStudio();
				        
				        altraLaurea = new AltraLaurea();
				        
				        altreLaureeBis = new ArrayList<AltraLaureaBis>();
						altraLaureaBis = null;
						
						specializzazioni = new ArrayList<Specializzazione>();
						specializzazione = null;
						
						borseStudio = new ArrayList<BorsaStudio>();
						borsaStudio = null;
						
						dottorati = new ArrayList<Dottorato>();
						dottorato = null;
						
						altriTitoli = new ArrayList<AltroTitolo>();
				   		altroTitolo = new AltroTitolo();
				   		
				   		idoneita = new Idoneita();
						
						corsiAggiornamento = new ArrayList<CorsoAggiornamento>();
						corsoAggiornamento = null;
						
						pubblicazioni = new ArrayList<Pubblicazione>();
						pubblicazione = null;
						
						
						BeanUtils.copyProperties(altraLaurea,titoliStudioCarrieraBean);
						
						altraLaurea.setIdDomandaLaurea(idDomanda);
						
						com.accenture.CCFarm.Bean.AltraLaureaBis laurea_appoggio = null;
						if(listaLaureeBis!=null)
						{
							for (int i=0;i<listaLaureeBis.size();i++)
							{
								altraLaureaBis = new AltraLaureaBis();
								laurea_appoggio = listaLaureeBis.get(i);
								
								altraLaureaBis.setIdAltraLaureaBis(laurea_appoggio.getIdAltraLaureaBis());
								altraLaureaBis.setDataSecondaLaureaBis(laurea_appoggio.getDataSecondaLaureaBis()); 
								altraLaureaBis.setDescUniSecondaLaureaBis(laurea_appoggio.getDescUniSecondaLaureaBis());
								altraLaureaBis.setFlagEsteroSecondaLaureaBis(laurea_appoggio.getFlagEsteroSecondaLaureaBis());
								altraLaureaBis.setIdDomandaLaureaBis(idDomanda);
								altraLaureaBis.setLuogoSecondaLaureaBis(laurea_appoggio.getLuogoSecondaLaureaBis());
								altraLaureaBis.setNazioneSecondaLaureaBis(laurea_appoggio.getNazioneSecondaLaureaBis());
								
								altraLaureaBis.setIdSecondaLaureaBis(altraLaureaBisHome.getSequenceIdAltraLaureaBis());								

								altreLaureeBis.add(altraLaureaBis);
							}
						
						}
						
						if(listaPubb!=null)
						{
							for (int i=0;i<listaPubb.size();i++)
							{
								pubblicazione = new Pubblicazione();
								
								com.accenture.CCFarm.Bean.Pubblicazione pubb_appoggio = new com.accenture.CCFarm.Bean.Pubblicazione();
								pubb_appoggio = listaPubb.get(i);
								
								pubblicazione.setAutorePubblicazione(pubb_appoggio.getAutorePubblicazione());
								pubblicazione.setCodIsbn(pubb_appoggio.getCodIsbn());
								pubblicazione.setDataPubblicazione(pubb_appoggio.getDataPubblicazione());
								pubblicazione.setEditorePubblicazione(pubb_appoggio.getEditorePubblicazione());
								pubblicazione.setIdDomandaPubbl(idDomanda);
								pubblicazione.setTipoPubblicazione(pubb_appoggio.getTipoPubblicazione());
								pubblicazione.setTitoloPubblicazione(pubb_appoggio.getTitoloPubblicazione());
								pubblicazione.setIdPubblicazione(pubblicazioneHome.getSequenceIdPubblicazione());								

								pubblicazioni.add(pubblicazione);
							}
						
						} 
						
						if(listaTitoli!=null)
						{
							for (int i=0;i<listaTitoli.size();i++)
							{
								altroTitolo = new AltroTitolo();
								
								com.accenture.CCFarm.Bean.AltroTitolo titolo_appoggio = new com.accenture.CCFarm.Bean.AltroTitolo();
								titolo_appoggio = listaTitoli.get(i);

								altroTitolo.setDataRilascioAltroTitolo(titolo_appoggio.getDataRilascioAltroTitolo());
								altroTitolo.setDescAltroTitolo(titolo_appoggio.getDescAltroTitolo());
								altroTitolo.setDurataAltroTitolo(titolo_appoggio.getDurataAltroTitolo());
								altroTitolo.setEsameFinaleAltroTitolo(titolo_appoggio.getEsameFinaleAltroTitolo());
								altroTitolo.setFlagEsteroAltroTitolo(titolo_appoggio.getFlagEsteroAltroTitolo());
								altroTitolo.setIdAltroTitolo(altroTitoloHome.getSequenceIdAltroTitolo());
								
								altroTitolo.setIdDomandaTitolo(idDomanda);
								
								altroTitolo.setNoteAltroTitolo(titolo_appoggio.getNoteAltroTitolo());
								altroTitolo.setRilascioAltroTitolo(titolo_appoggio.getRilascioAltroTitolo());								

								altriTitoli.add(altroTitolo);
							}
						
						} 
						
						if(listaSpec!=null)
						{
							for (int i=0;i<listaSpec.size();i++)
							{
								specializzazione = new Specializzazione();
								com.accenture.CCFarm.Bean.Specializzazione spec_appoggio = new com.accenture.CCFarm.Bean.Specializzazione();
								spec_appoggio = listaSpec.get(i);
							
								specializzazione.setDenominazioneSpec(spec_appoggio.getDenominazioneSpec());
								specializzazione.setDescrFacoltaSpec(spec_appoggio.getDescrFacoltaSpec());
								specializzazione.setDurataSpec(spec_appoggio.getDurataSpec());
								specializzazione.setFlagEsteroSpec(spec_appoggio.getFlagEsteroSpec());
								specializzazione.setIdDomandaSpec(idDomanda);
								specializzazione.setIdSpecializzazione(specializzazioneHome.getSequenceIdSpecializzazione());
								specializzazione.setLuogoSpec(spec_appoggio.getLuogoSpec());
								specializzazione.setNazioneSpec(spec_appoggio.getNazioneSpec());
								specializzazione.setDescrUniversitaSpec(spec_appoggio.getDescrUniversitaSpec());
								
								specializzazioni.add(specializzazione);
							}
						
						} 
						
						if(listaCorsi!=null)
						{
							for (int i=0;i<listaCorsi.size();i++)
							{
								corsoAggiornamento = new CorsoAggiornamento();
								com.accenture.CCFarm.Bean.CorsoAgg corso_appoggio = new com.accenture.CCFarm.Bean.CorsoAgg();
								corso_appoggio = listaCorsi.get(i);
							
								corsoAggiornamento.setDichiarazioneCorsoAgg(corso_appoggio.getDichiarazioneCorsoAgg());
								corsoAggiornamento.setFlagEsteroCorsoAgg(corso_appoggio.getFlagEsteroCorsoAgg());
								corsoAggiornamento.setDataInizioCorsoAgg(corso_appoggio.getDataInizioCorsoAgg());
								corsoAggiornamento.setDataFineCorsoAgg(corso_appoggio.getDataFineCorsoAgg());
								corsoAggiornamento.setIdCorsoAgg(corsoAggiornamentoHome.getSequenceIdCorsoAggiornamento());
								corsoAggiornamento.setIdDomandaAgg(idDomanda);
								corsoAggiornamento.setOrganizzatoCorsoAgg(corso_appoggio.getOrganizzatoCorsoAgg());
								corsoAggiornamento.setTitoloCorsoAgg(corso_appoggio.getTitoloCorsoAgg());
								corsoAggiornamento.setTotOreCorsoAgg(corso_appoggio.getTotOreCorsoAgg());								

								corsiAggiornamento.add(corsoAggiornamento);
							}
						
						} 
						
						if(listaBorse!=null)
						{
							for (int i=0;i<listaBorse.size();i++)
							{
								borsaStudio = new BorsaStudio();
								com.accenture.CCFarm.Bean.BorsaStudio borsa_appoggio = new com.accenture.CCFarm.Bean.BorsaStudio();
								borsa_appoggio = listaBorse.get(i);
								
								borsaStudio.setDenominazioneBorsa(borsa_appoggio.getDenominazioneBorsa());
								borsaStudio.setDescrFacoltaBorsa(borsa_appoggio.getDescrFacoltaBorsa());
								borsaStudio.setDescrUniversitaBorsa(borsa_appoggio.getDescrUniversitaBorsa());
								borsaStudio.setFlagEsteroBorsa(borsa_appoggio.getFlagEsteroBorsa());
								borsaStudio.setDataInizioBorsa(borsa_appoggio.getDataInizioBorsa());
								borsaStudio.setDataFineBorsa(borsa_appoggio.getDataFineBorsa());
								borsaStudio.setIdBorsaStudio(borsaStudioHome.getSequenceIdBorsaStudio());
								borsaStudio.setIdDomandaBorsaStudio(idDomanda);
								borsaStudio.setLuogoBorsa(borsa_appoggio.getLuogoBorsa());
								borsaStudio.setNazioneBorsa(borsa_appoggio.getNazioneBorsa());								

								borseStudio.add(borsaStudio);
							}
						
						} 
						
						if(listaDott!=null)
						{
							for (int i=0;i<listaDott.size();i++)
							{
								dottorato = new Dottorato();
								com.accenture.CCFarm.Bean.Dottorato dott_appoggio = new com.accenture.CCFarm.Bean.Dottorato();
								dott_appoggio = listaDott.get(i);

								dottorato.setDataFineDottorato(dott_appoggio.getDataFineDottorato());
								dottorato.setDataInizioDottorato(dott_appoggio.getDataInizioDottorato());
								dottorato.setDenominazioneDottorato(dott_appoggio.getDenominazioneDottorato());
								dottorato.setDescrFacoltaDottorato(dott_appoggio.getDescrFacoltaDottorato());
								dottorato.setDescrUniversitaDottorato(dott_appoggio.getDescrUniversitaDottorato());
								dottorato.setFlagEsteroDottorato(dott_appoggio.getFlagEsteroDottorato());
								dottorato.setIdDomandaDottorato(idDomanda);
								dottorato.setIdDottorato(dottoratoHome.getSequenceIdDottorato());
								dottorato.setLuogoDottorato(dott_appoggio.getLuogoDottorato());
								dottorato.setNazioneDottorato(dott_appoggio.getNazioneDottorato());								

								dottorati.add(dottorato);
							}
						
						} 
						
						BeanUtils.copyProperties(idoneita,titoliStudioCarrieraBean);
						
						if(idoneita!=null)
							idoneita.setIdDomandaIdon(idDomanda);
			}
			
			catch(IllegalAccessException  e)
				{
					e.printStackTrace();
					return false;
				}
			
			catch(InvocationTargetException e)
				{
					e.printStackTrace();
					return false;
				}	
		
			catch(RuntimeException re)
				{
					re.printStackTrace();
					return false;
				}
			
			return true;

}	


		public AltraLaurea getAltraLaurea() {
			return altraLaurea;
		}
		
		public void setAltraLaurea(AltraLaurea altraLaurea) {
			this.altraLaurea = altraLaurea;
		}
		
		public AltraLaureaHome getAltraLaureaHome() {
			return altraLaureaHome;
		}
		
		public void setAltraLaureaHome(AltraLaureaHome altraLaureaHome) {
			this.altraLaureaHome = altraLaureaHome;
		}
		
		public AltraLaureaBis getAltraLaureaBis() {
			return altraLaureaBis;
		}
		
		public void setAltraLaureaBis(AltraLaureaBis altraLaureaBis) {
			this.altraLaureaBis = altraLaureaBis;
		}
		
		public AltraLaureaBisHome getAltraLaureaBisHome() {
			return altraLaureaBisHome;
		}
		
		public void setAltraLaureaBisHome(AltraLaureaBisHome altraLaureaBisHome) {
			this.altraLaureaBisHome = altraLaureaBisHome;
		}
		
		public Specializzazione getSpecializzazione() {
			return specializzazione;
		}
		
		public void setSpecializzazione(Specializzazione specializzazione) {
			this.specializzazione = specializzazione;
		}
		
		public SpecializzazioneHome getSpecializzazioneHome() {
			return specializzazioneHome;
		}
		
		public void setSpecializzazioneHome(SpecializzazioneHome specializzazioneHome) {
			this.specializzazioneHome = specializzazioneHome;
		}
		
		public BorsaStudio getBorsaStudio() {
			return borsaStudio;
		}
		
		public void setBorsaStudio(BorsaStudio borsaStudio) {
			this.borsaStudio = borsaStudio;
		}
		
		public BorsaStudioHome getBorsaStudioHome() {
			return borsaStudioHome;
		}
		
		public void setBorsaStudioHome(BorsaStudioHome borsaStudioHome) {
			this.borsaStudioHome = borsaStudioHome;
		}
		
		public Dottorato getDottorato() {
			return dottorato;
		}
		
		public void setDottorato(Dottorato dottorato) {
			this.dottorato = dottorato;
		}
		
		public DottoratoHome getDottoratoHome() {
			return dottoratoHome;
		}
		
		public void setDottoratoHome(DottoratoHome dottoratoHome) {
			this.dottoratoHome = dottoratoHome;
		}
		
		public AltroTitolo getAltroTitolo() {
			return altroTitolo;
		}
		
		public void setAltroTitolo(AltroTitolo altroTitolo) {
			this.altroTitolo = altroTitolo;
		}
		
		public AltroTitoloHome getAltroTitoloHome() {
			return altroTitoloHome;
		}
		
		public void setAltroTitoloHome(AltroTitoloHome altroTitoloHome) {
			this.altroTitoloHome = altroTitoloHome;
		}
		
		public CorsoAggiornamento getCorsoAggiornamento() {
			return corsoAggiornamento;
		}
		
		public void setCorsoAggiornamento(CorsoAggiornamento corsoAggiornamento) {
			this.corsoAggiornamento = corsoAggiornamento;
		}
		
		public CorsoAggiornamentoHome getCorsoAggiornamentoHome() {
			return corsoAggiornamentoHome;
		}
		
		public void setCorsoAggiornamentoHome(
				CorsoAggiornamentoHome corsoAggiornamentoHome) {
			this.corsoAggiornamentoHome = corsoAggiornamentoHome;
		}
		
		public Pubblicazione getPubblicazione() {
			return pubblicazione;
		}
		
		public void setPubblicazione(Pubblicazione pubblicazione) {
			this.pubblicazione = pubblicazione;
		}
		
		public PubblicazioneHome getPubblicazioneHome() {
			return pubblicazioneHome;
		}
		
		public void setPubblicazioneHome(PubblicazioneHome pubblicazioneHome) {
			this.pubblicazioneHome = pubblicazioneHome;
		}
		
		public Idoneita getIdoneita() {
			return idoneita;
		}
		
		public void setIdoneita(Idoneita idoneita) {
			this.idoneita = idoneita;
		}
		
		public IdoneitaHome getIdoneitaHome() {
			return idoneitaHome;
		}
		
		public void setIdoneitaHome(IdoneitaHome idoneitaHome) {
			this.idoneitaHome = idoneitaHome;
		}
		
		public ArrayList<AltraLaurea> getAltreLauree() {
			return altreLauree;
		}
		
		public void setAltreLauree(ArrayList<AltraLaurea> altreLauree) {
			this.altreLauree = altreLauree;
		}
		
		public ArrayList<AltraLaureaBis> getAltreLaureeBis() {
			return altreLaureeBis;
		}
		
		public void setAltreLaureeBis(ArrayList<AltraLaureaBis> altreLaureeBis) {
			this.altreLaureeBis = altreLaureeBis;
		}
		
		public ArrayList<Specializzazione> getSpecializzazioni() {
			return specializzazioni;
		}
		
		public void setSpecializzazioni(ArrayList<Specializzazione> specializzazioni) {
			this.specializzazioni = specializzazioni;
		}
		
		public ArrayList<BorsaStudio> getBorseStudio() {
			return borseStudio;
		}
		
		public void setBorseStudio(ArrayList<BorsaStudio> borseStudio) {
			this.borseStudio = borseStudio;
		}
		
		public ArrayList<Dottorato> getDottorati() {
			return dottorati;
		}
		
		public void setDottorati(ArrayList<Dottorato> dottorati) {
			this.dottorati = dottorati;
		}
		
		public ArrayList<AltroTitolo> getAltriTitoli() {
			return altriTitoli;
		}
		
		public void setAltriTitoli(ArrayList<AltroTitolo> altriTitoli) {
			this.altriTitoli = altriTitoli;
		}
		
		public ArrayList<CorsoAggiornamento> getCorsiAggiornamento() {
			return corsiAggiornamento;
		}
		
		public void setCorsiAggiornamento(
				ArrayList<CorsoAggiornamento> corsiAggiornamento) {
			this.corsiAggiornamento = corsiAggiornamento;
		}
		
		public ArrayList<Pubblicazione> getPubblicazioni() {
			return pubblicazioni;
		}
		
		public void setPubblicazioni(ArrayList<Pubblicazione> pubblicazioni) {
			this.pubblicazioni = pubblicazioni;
		}
		
		public ArrayList<Idoneita> getListaIdoneita() {
			return listaIdoneita;
		}
		
		public void setListaIdoneita(ArrayList<Idoneita> listaIdoneita) {
			this.listaIdoneita = listaIdoneita;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.Pubblicazione> getListaPubb() {
			return listaPubb;
		}
		
		public void setListaPubb(
				ArrayList<com.accenture.CCFarm.Bean.Pubblicazione> listaPubb) {
			this.listaPubb = listaPubb;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.Specializzazione> getListaSpec() {
			return listaSpec;
		}
		
		public void setListaSpec(
				ArrayList<com.accenture.CCFarm.Bean.Specializzazione> listaSpec) {
			this.listaSpec = listaSpec;
		}
		
		public ArrayList<CorsoAgg> getListaCorsi() {
			return listaCorsi;
		}
		
		public void setListaCorsi(ArrayList<CorsoAgg> listaCorsi) {
			this.listaCorsi = listaCorsi;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis> getListaLaureeBis() {
			return listaLaureeBis;
		}
		
		public void setListaLaureeBis(
				ArrayList<com.accenture.CCFarm.Bean.AltraLaureaBis> listaLaureeBis) {
			this.listaLaureeBis = listaLaureeBis;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.Dottorato> getListaDott() {
			return listaDott;
		}
		
		public void setListaDott(
				ArrayList<com.accenture.CCFarm.Bean.Dottorato> listaDott) {
			this.listaDott = listaDott;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.AltroTitolo> getListaTitoli() {
			return listaTitoli;
		}
		
		public void setListaTitoli(
				ArrayList<com.accenture.CCFarm.Bean.AltroTitolo> listaTitoli) {
			this.listaTitoli = listaTitoli;
		}
		
		public ArrayList<com.accenture.CCFarm.Bean.BorsaStudio> getListaBorse() {
			return listaBorse;
		}
		
		public void setListaBorse(
				ArrayList<com.accenture.CCFarm.Bean.BorsaStudio> listaBorse) {
			this.listaBorse = listaBorse;
		}

		public UtenteCandidatura getUtenteCandidatura() {
			return utenteCandidatura;
		}

		public void setUtenteCandidatura(UtenteCandidatura utenteCandidatura) {
			this.utenteCandidatura = utenteCandidatura;
		}  

}
