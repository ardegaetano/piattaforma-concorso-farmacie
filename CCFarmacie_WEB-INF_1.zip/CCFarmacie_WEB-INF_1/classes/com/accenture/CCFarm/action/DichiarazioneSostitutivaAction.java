package com.accenture.CCFarm.action;

import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.commons.beanutils.BeanUtils;

import com.accenture.CCFarm.DAO.DichiarazioneSostitutiva;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutivaHome;
import com.accenture.CCFarm.DAO.Documento;
import com.accenture.CCFarm.DAO.DocumentoHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PageBean.DichiarazioneSostitutivaBean;
import com.accenture.CCFarm.PageBean.DichiarazioneSostitutivaBeanVisualizzazione;
import com.accenture.CCFarm.utility.StringUtil;

public class DichiarazioneSostitutivaAction {
	
	java.util.Date date;
    private Timestamp oggi;
    
	DichiarazioneSostitutiva dichiarazioneSostitutiva;
	DichiarazioneSostitutivaHome dichiarazioneSostitutivaHome;
	DocumentoHome documentoHome;
	ArrayList<Documento> listaDocumenti;
	ArrayList<DichiarazioneSostitutiva> dichiarazioni = new ArrayList<DichiarazioneSostitutiva>();

	public DichiarazioneSostitutivaAction() {
		dichiarazioneSostitutivaHome=new DichiarazioneSostitutivaHome();
		documentoHome=new DocumentoHome();
	}
	
	public boolean loadPaginaInserimento(String idDomandaDic,DichiarazioneSostitutivaBean dichiarazioneSostitutivaBean) throws GestioneErroriException{
    	try
    	{
    		//popola lista delle province
    		dichiarazioneSostitutiva=new DichiarazioneSostitutiva();
    		dichiarazioneSostitutiva =  dichiarazioneSostitutivaHome.findById(idDomandaDic);
    		
	    	}
    	catch(RuntimeException re)
    	{
    		re.printStackTrace();
    		return false;
    	}
	    
    	//copia i dati dai bean di hibernate nel bean di pagina
   		try
   		{
 
   			if(dichiarazioneSostitutiva!=null)
   				BeanUtils.copyProperties(dichiarazioneSostitutivaBean,dichiarazioneSostitutiva);
   			
   			
		}
   		catch(IllegalAccessException e)
   		{
			e.printStackTrace();
			return false;
		}
   		catch(InvocationTargetException e)
   		{
			e.printStackTrace();
			return false;
		}
   		
   		return true;
    }
	
	public boolean loadPaginaInserimentoVisualizzazione(String idDomandaDic,DichiarazioneSostitutivaBeanVisualizzazione dichiarazioneSostitutivaBeanVisualizzazione)throws GestioneErroriException{
    	try
    	{
    		//popola lista delle province
    		dichiarazioneSostitutiva=new DichiarazioneSostitutiva();
    		dichiarazioneSostitutiva=dichiarazioneSostitutivaHome.findById(idDomandaDic);
    	   		
    		
	    	}
    	catch(RuntimeException re)
    	{
    		re.printStackTrace();
    		return false;
    	}
	    
    	//copia i dati dai bean di hibernate nel bean di pagina
   		try
   		{
 
   			if(dichiarazioneSostitutiva!=null)
   				BeanUtils.copyProperties(dichiarazioneSostitutivaBeanVisualizzazione,dichiarazioneSostitutiva);
   			if(dichiarazioneSostitutivaBeanVisualizzazione.getDataVersamento()!=null)
   			dichiarazioneSostitutivaBeanVisualizzazione.setDataVersamentoString(StringUtil.dateToStringDDMMYYYY(dichiarazioneSostitutivaBeanVisualizzazione.getDataVersamento()));
   			
		}
   		catch(IllegalAccessException e)
   		{
			e.printStackTrace();
			return false;
		}
   		catch(InvocationTargetException e)
   		{
			e.printStackTrace();
			return false;
		}
   		
   		return true;
    }
	
	public void loadPaginaInserimentoVisualizzazione(DichiarazioneSostitutivaBean dichiarazioneSostitutivaBean,DichiarazioneSostitutivaBeanVisualizzazione dichiarazioneSostitutivaBeanVisualizzazione) throws Exception
	{
		if(dichiarazioneSostitutivaBean==null || dichiarazioneSostitutivaBeanVisualizzazione==null)
			throw new Exception("[Visualizzazione Domanda: Impossibile inizializzare Documenti e Versamenti]");
		
		BeanUtils.copyProperties(dichiarazioneSostitutivaBeanVisualizzazione,dichiarazioneSostitutivaBean);
		
		if(dichiarazioneSostitutivaBeanVisualizzazione.getDataVersamento()!=null)
			dichiarazioneSostitutivaBeanVisualizzazione.setDataVersamentoString(StringUtil.dateToStringDDMMYYYY(dichiarazioneSostitutivaBeanVisualizzazione.getDataVersamento()));
    }
	
	public boolean updateDAO(String idDomanda,DichiarazioneSostitutivaBean dichiarazioneSostitutivaBean) throws GestioneErroriException {
			
		
		dichiarazioneSostitutiva=new DichiarazioneSostitutiva();
		
		
		//preleva i dati dal bean di pagina e li copia nei bean di hibernate
		try
		{
			BeanUtils.copyProperties(dichiarazioneSostitutiva,dichiarazioneSostitutivaBean);
			
			dichiarazioneSostitutiva.setIdDomandaDic(idDomanda);
			if (dichiarazioneSostitutivaBean.getDataOperazione()!=null || dichiarazioneSostitutivaBean.getDataVersamento()!=null){
				dichiarazioneSostitutiva.setFlagDichiarazione("false");				
			}
			
			if(dichiarazioneSostitutiva.getElencoDocumenti()!=null && !dichiarazioneSostitutiva.getElencoDocumenti().equals("")){
				StringTokenizer stringToken = new StringTokenizer(dichiarazioneSostitutiva.getElencoDocumenti(),"|");
				Vector vettoreDiDoc = new Vector();
				while (stringToken.hasMoreTokens()){
					vettoreDiDoc.add(stringToken.nextElement());
				}
				//String[] listaDoc = dichiarazioneSostitutiva.getElencoDocumenti().split("|");
				String appoggio = "";
				listaDocumenti = new ArrayList<Documento>();
				Documento doc_appoggio;
	    		
				for (int i=0;i<vettoreDiDoc.size(); i++)
				{
	    			appoggio =(String) vettoreDiDoc.get(i);
	    			doc_appoggio = new Documento();
					doc_appoggio.setTipoDocumento(appoggio);
					doc_appoggio.setIdDomandaDocumento(idDomanda);
					doc_appoggio.setIdDocumento(documentoHome.getSequenceIdDocumento());
					
					listaDocumenti.add(doc_appoggio);
				}
			}
			else {
				listaDocumenti = null;
			}
			dichiarazioneSostitutivaBean.setListaDocumenti(listaDocumenti);
			
		}
		catch(IllegalAccessException e)
		{
			e.printStackTrace();
			return false;
		}
		catch(InvocationTargetException e)
		{
			e.printStackTrace();
			return false;
		}
				
		return true;
		}
					

	public String[] validatorFields() {
		
		return null;
	}

	public boolean sendMailDom() {
		
		return true;
	}

	public boolean printDom() {
		
		return true;
	}

	public DichiarazioneSostitutiva getDichiarazioneSostitutiva() {
		return dichiarazioneSostitutiva;
	}

	public void setDichiarazioneSostitutiva(
			DichiarazioneSostitutiva dichiarazioneSostitutiva) {
		this.dichiarazioneSostitutiva = dichiarazioneSostitutiva;
	}

	public ArrayList<Documento> getListaDocumenti() {
		return listaDocumenti;
	}

	public void setListaDocumenti(ArrayList<Documento> listaDocumenti) {
		this.listaDocumenti = listaDocumenti;
	}
	
}
