package com.accenture.CCFarm.action;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;

import com.accenture.CCFarm.DAO.NazioneHome;
import com.accenture.CCFarm.DAO.RequisitiMinimi;
import com.accenture.CCFarm.DAO.RequisitiMinimiHome;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.DAO.UtenteCandidaturaHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PageBean.RequisitiMinimiBean;
import com.accenture.CCFarm.PageBean.RequisitiMinimiBeanVisualizzazione;
import com.accenture.CCFarm.utility.BigDecimalToIntConverter;
import com.accenture.CCFarm.utility.GetSessionUtility;
import com.accenture.CCFarm.utility.IntToBigDecimalConverter;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.MatriceProperties;
import com.accenture.CCFarm.utility.MatricePropertiesDe;
import com.accenture.CCFarm.utility.RepositorySession;
import com.accenture.CCFarm.utility.SQLDateToUtilDateConverter;
import com.accenture.CCFarm.utility.StringUtil;
import com.accenture.CCFarm.utility.TabellaDecodifica;
import com.accenture.CCFarm.utility.UtilDateToSQLDateConverter;

public class RequisitiMinimiAction
{
	private UtenteCandidatura utenteCandidatura;
	private UtenteCandidaturaHome utenteCandidaturaHome;
	
	private RequisitiMinimi requisitiMinimi;
	private RequisitiMinimiHome requisitiMinimiHome;
	private NazioneHome nazioneHome;
	
	HttpSession session = (HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	String lingua = (String)session.getAttribute("linguaScelta");
	
	 MatriceProperties matriceIt = MatriceProperties.getMatricePropertiesIt();
	 MatricePropertiesDe matriceDe = MatricePropertiesDe.getMatricePropertiesDe();
	public RequisitiMinimiAction()
	{
		//inizializza i controller di Hibernate
		utenteCandidaturaHome=new UtenteCandidaturaHome();
		requisitiMinimiHome=new RequisitiMinimiHome();
		nazioneHome= new NazioneHome();
		//registra convertitori aggiuntivi per BeanUtils
		//BigDecimal <--> Int
		ConvertUtils.register(new BigDecimalToIntConverter(),Integer.class);
		ConvertUtils.register(new IntToBigDecimalConverter(),BigDecimal.class);
		//SQL Date <--> Util Date
		ConvertUtils.register(new SQLDateToUtilDateConverter(),java.util.Date.class);
		ConvertUtils.register(new UtilDateToSQLDateConverter(),java.sql.Date.class);
	}
	
	//carica dati da db nel bean di pagina
	public boolean init(String idUtente,RequisitiMinimiBean requisitiMinimiBean) throws GestioneErroriException 
	{	
		if(requisitiMinimiBean==null)
			return false;
		try
		{
			//popola i campi relativi al bean "utente"
			utenteCandidatura=utenteCandidaturaHome.findById(idUtente);
			if(utenteCandidatura.getNazioneResidenzaUtente()==null || utenteCandidatura.getNazioneResidenzaUtente().equals("")){
				utenteCandidatura.setNazioneResidenzaUtente("IT");
			}
			if(utenteCandidatura.getCodiceFiscaleUtente()!=null && utenteCandidatura.getCodiceFiscaleUtente().startsWith("*"))
			{
				utenteCandidatura.setCodiceFiscaleUtente("N.D.");
			}
			//recupera idDomanda dall'istanza di "utente"
			String idDomanda=utenteCandidatura.getIdDomandaUtente();
			
			//popola i campi relativi al bean "RequisitiMinimi"
			requisitiMinimi=requisitiMinimiHome.findById(idDomanda);
		}
		catch(RuntimeException e)
		{
			e.printStackTrace();
			return false;
		}
		//copia i dati dai bean di hibernate al bean di pagina
		try
		{
			//copia campi dai bean del db al bean di pagina
			
			//se il bean "utente" � stato popolato
			if(utenteCandidatura!=null)
			{
				BeanUtils.copyProperties(requisitiMinimiBean,utenteCandidatura);
				
				//decodifica codice del documento
				TabellaDecodifica.getDocumentoIdentita();
				String tipoDocumento=TabellaDecodifica.decodificaDocumentoIdentita(utenteCandidatura.getTipoDocumento(), requisitiMinimiBean.getLinguaScelta());
				
				//compone il campo "estremi documento d'identit�" della pagina a partire dai dati nel database
				requisitiMinimiBean.setEstremiDocumentoIdentitaUtente(tipoDocumento+": "+
																	  utenteCandidatura.getNumeroDoc()+","+
																	  utenteCandidatura.getEnteRilascioDoc()+" ("+
																	  StringUtil.dateToStringDDMMYYYY(utenteCandidatura.getDataRilascioDoc())+")");
			}
			//se il bean "requisitiMinimi" � stato popolato
			if(requisitiMinimi!=null)
				BeanUtils.copyProperties(requisitiMinimiBean,requisitiMinimi);
			
			if(utenteCandidatura.getPrvResidenzaUtente()!=null)
			{
				requisitiMinimiBean.setComuniSelect(Localita.getComuni(utenteCandidatura.getPrvResidenzaUtente()));
				requisitiMinimiBean.setComuniResidenzaList(requisitiMinimiBean.getComuniSelect().get(utenteCandidatura.getPrvResidenzaUtente()));
			}
			if(utenteCandidatura.getProvinciaListaElettorale()!=null)
			{
				requisitiMinimiBean.setComuniSelect(Localita.getComuni(utenteCandidatura.getProvinciaListaElettorale()));
				requisitiMinimiBean.setComuniElettoraliList(requisitiMinimiBean.getComuniSelect().get(utenteCandidatura.getProvinciaListaElettorale()));
			}
			
			//controlla regione selezionata: se corrisponde a Bolzano attiva il pannello opzionale della pagina
			String codiceRegione=(String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_REGIONE);
			if(codiceRegione!=null && codiceRegione.equals("041"))
				requisitiMinimiBean.setIsBolzano(true);
		}
		catch(IllegalAccessException  e)
		{
			e.printStackTrace();
			return false;
		}
		catch( InvocationTargetException e)
		{
			e.printStackTrace();
			return false;
		}
		
		return (utenteCandidatura!=null);// && (requisitiMinimi!=null);
	}
	
	public boolean initVisualizzazione(String idUtente,RequisitiMinimiBeanVisualizzazione requisitiMinimiBeanVisualizzazione) throws GestioneErroriException 
	{	
		if(requisitiMinimiBeanVisualizzazione==null)
			return false;
		try
		{
			//popola i campi relativi al bean "utente"
			utenteCandidatura=utenteCandidaturaHome.findById(idUtente);
			//se codice fiscale � calcolato non appare
			if(utenteCandidatura.getCodiceFiscaleUtente()!=null && utenteCandidatura.getCodiceFiscaleUtente().startsWith("*"))
			{
				utenteCandidatura.setCodiceFiscaleUtente("N.D.");
			}
			//recupera idDomanda dall'istanza di "utente"
			String idDomanda=utenteCandidatura.getIdDomandaUtente();
			
			//popola i campi relativi al bean "RequisitiMinimi"
			requisitiMinimi=requisitiMinimiHome.findById(idDomanda);
		}
		catch(RuntimeException e)
		{
			e.printStackTrace();
			return false;
		}
		//copia i dati dai bean di hibernate al bean di pagina
		try
		{
			//copia campi da bean a bean
			
			//se il caricamento del bean "utente" dal db � andato a buon fine
			if(utenteCandidatura!=null)
			{
				BeanUtils.copyProperties(requisitiMinimiBeanVisualizzazione,utenteCandidatura);
				
				//compone il campo "estremi documento d'identit�" della pagina a partire dai dati nel database
				
				//decodifica codice del documento
				TabellaDecodifica.getDocumentoIdentita();
				String tipoDocumento=TabellaDecodifica.decodificaDocumentoIdentita(utenteCandidatura.getTipoDocumento(), requisitiMinimiBeanVisualizzazione.getLinguaScelta());
				
				requisitiMinimiBeanVisualizzazione.setEstremiDocumentoIdentitaUtente(tipoDocumento+": "+
																	  utenteCandidatura.getNumeroDoc()+","+
																	  utenteCandidatura.getEnteRilascioDoc()+" ("+
																	  StringUtil.dateToStringDDMMYYYY(utenteCandidatura.getDataRilascioDoc())+")");
			}
			//se il caricamento del bean "requisitiMinimi" dal db � andato a buon fine
			
			requisitiMinimiBeanVisualizzazione.setDataNascitaString(StringUtil.dateToStringDDMMYYYY(requisitiMinimiBeanVisualizzazione.getDataNascitaUtente()));
			
			if(requisitiMinimiBeanVisualizzazione.getNazioneNascitaUtente()!=null &&  requisitiMinimiBeanVisualizzazione.getNazioneNascitaUtente().equals("IT")){
				
				requisitiMinimiBeanVisualizzazione.setLuogoNascitaUtente(Localita.getDenominazioneComune(requisitiMinimiBeanVisualizzazione.getLuogoNascitaUtente()));
				requisitiMinimiBeanVisualizzazione.setPrvNascitaUtente(Localita.getDenominazioneProvincia(requisitiMinimiBeanVisualizzazione.getPrvNascitaUtente()));
				}
				
				//requisitiMinimiBeanVisualizzazione.setNazioneNascitaUtente(Localita.getDenominazioneNazione(requisitiMinimiBeanVisualizzazione.getNazioneNascitaUtente()));
			
			if(requisitiMinimiBeanVisualizzazione.getNazioneResidenzaUtente()!=null &&  requisitiMinimiBeanVisualizzazione.getNazioneResidenzaUtente().equals("IT")){
				
				requisitiMinimiBeanVisualizzazione.setComuneResidenzaUtente(Localita.getDenominazioneComune(requisitiMinimiBeanVisualizzazione.getComuneResidenzaUtente()));
				requisitiMinimiBeanVisualizzazione.setPrvResidenzaUtente(Localita.getDenominazioneProvincia(requisitiMinimiBeanVisualizzazione.getPrvResidenzaUtente()));
				}
								
				//requisitiMinimiBeanVisualizzazione.setNazioneResidenzaUtente(Localita.getDenominazioneNazione(requisitiMinimiBeanVisualizzazione.getNazioneResidenzaUtente()));
				
				
			//controlla regione selezionata: se corrisponde a Bolzano attiva il pannello opzionale della pagina
			String codiceRegione=(String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_REGIONE);
			if(codiceRegione!=null && codiceRegione.equals("041"))
				requisitiMinimiBeanVisualizzazione.setIsBolzano(true);
			
			
			if(requisitiMinimi!=null){
				BeanUtils.copyProperties(requisitiMinimiBeanVisualizzazione,requisitiMinimi);
				String fattispecieAppartenenza = requisitiMinimiBeanVisualizzazione.getFattispecieAppartenenza();
				if(lingua.equalsIgnoreCase("de")){
					requisitiMinimiBeanVisualizzazione.setCodTipoLaurea(matriceDe.getMatricePropertiesDe(requisitiMinimi.getCodTipoLaurea().replace(" ", "_")));
					if(fattispecieAppartenenza.equals("1")){
						requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("Kein Apothekeninhaber, unabh�ngig von der beruflichen Situation");
					}else if(fattispecieAppartenenza.equals("2")){
						requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("Inhaber einer �Landapotheke mit Standortzulage� (farmacia rurale sussidiata)");
					}else if(fattispecieAppartenenza.equals("3")){
						requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("Inhaber einer ��berz�hligen Apotheke� (farmacia soprannumeraria)");
					}else if(fattispecieAppartenenza.equals("4")){
						requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("Inhaber von Betrieben gem�� Art. 5, Absatz 1 des Gesetzesdekrets Nr. 223 vom 4. Juli 2006, mit �nderungen umgewandelt in Gesetz Nr. 248 vom 4. August 2006");
					}else if(fattispecieAppartenenza.equals("5")){
						requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("Teilhaber einer Gesellschaft, die Inhaberin einer �Landapotheke mit Standortzulage� (farmacia rurale sussidiata) oder einer ��berz�hligen Apotheke� (farmacia soprannumeraria) ist, sofern die Gesellschaft nicht auch Inhaberin von Apotheken ist, die nicht den vorgenannten Merkmalen entsprechen");
					}
				}else{
					
					if(fattispecieAppartenenza.equals("1")){
						requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("non titolari di farmacia in qualunque condizione professionale si trovino");
					}else if(fattispecieAppartenenza.equals("2")){
						requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("titolari di farmacia rurale sussidiata");
					}else if(fattispecieAppartenenza.equals("3")){
						requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("titolari di farmacia soprannumeraria");
					}else if(fattispecieAppartenenza.equals("4")){
						requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("titolari di esercizio di cui all art. 5 comma 1 del decreto legge 4 luglio 2006 n. 223, convertito con modificazioni nella legge 4 agosto 2006 n. 248");
					}else if(fattispecieAppartenenza.equals("5")){
						requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("soci di societa titolare di farmacia rurale sussidiata o di farmacia  soprannumeraria,a condizione che la societa non sia titolare anche di farmacie prive delle predette caratteristiche");
					}
				}
			
		
			
			//requisitiMinimiBeanVisualizzazione.setNazioneNascitaUtente(nazioneNascitaUtente);
			
			requisitiMinimiBeanVisualizzazione.setComuneListaElettorale(Localita.getDenominazioneComune(requisitiMinimiBeanVisualizzazione.getComuneListaElettorale()));
			requisitiMinimiBeanVisualizzazione.setNazioneNascitaUtente(Localita.getDenominazioneNazione(requisitiMinimiBeanVisualizzazione.getNazioneNascitaUtente(),lingua));
			requisitiMinimiBeanVisualizzazione.setNazioneResidenzaUtente(Localita.getDenominazioneNazione(requisitiMinimiBeanVisualizzazione.getNazioneResidenzaUtente(),lingua));
			requisitiMinimiBeanVisualizzazione.setStatoUe(Localita.getDenominazioneNazione(requisitiMinimiBeanVisualizzazione.getStatoUe(),lingua));
			requisitiMinimiBeanVisualizzazione.setPrvAlbo(Localita.getDenominazioneProvincia(requisitiMinimiBeanVisualizzazione.getPrvAlbo()));
			requisitiMinimiBeanVisualizzazione.setPrvAttualeAlbo(Localita.getDenominazioneProvincia(requisitiMinimiBeanVisualizzazione.getPrvAttualeAlbo()));
			requisitiMinimiBeanVisualizzazione.setProvinciaListaElettorale(Localita.getDenominazioneProvincia(requisitiMinimiBeanVisualizzazione.getProvinciaListaElettorale()));
			}
			
		}
		catch(IllegalAccessException  e)
		{
			e.printStackTrace();
			return false;
		}
		catch( InvocationTargetException e)
		{
			e.printStackTrace();
			return false;
		}
		
		return (utenteCandidatura!=null) && (requisitiMinimi!=null);
	}
	
	public void initVisualizzazione(RequisitiMinimiBean requisitiMinimiBean,RequisitiMinimiBeanVisualizzazione requisitiMinimiBeanVisualizzazione) throws Exception 
	{	
		if(requisitiMinimiBean==null || requisitiMinimiBeanVisualizzazione==null)
			throw new Exception("[Visualizzazione Domanda: Impossibile inizializzare Requisiti]");
		
		BeanUtils.copyProperties(requisitiMinimiBeanVisualizzazione,requisitiMinimiBean);
		
		requisitiMinimiBeanVisualizzazione.setDataNascitaString(StringUtil.dateToStringDDMMYYYY(requisitiMinimiBeanVisualizzazione.getDataNascitaUtente()));
		
		if(requisitiMinimiBeanVisualizzazione.getNazioneNascitaUtente()!=null && requisitiMinimiBeanVisualizzazione.getNazioneNascitaUtente().equals("IT"))
		{
			requisitiMinimiBeanVisualizzazione.setLuogoNascitaUtente(Localita.getDenominazioneComune(requisitiMinimiBeanVisualizzazione.getLuogoNascitaUtente()));
			requisitiMinimiBeanVisualizzazione.setPrvNascitaUtente(Localita.getDenominazioneProvincia(requisitiMinimiBeanVisualizzazione.getPrvNascitaUtente()));
		}
		else //localita' estera
			requisitiMinimiBeanVisualizzazione.setLuogoNascitaUtente(Localita.getDenominazioneComune(requisitiMinimiBeanVisualizzazione.getLuogoNascitaUtente()));
		
		requisitiMinimiBeanVisualizzazione.setComuneListaElettorale(Localita.getDenominazioneComune(requisitiMinimiBeanVisualizzazione.getComuneListaElettorale()));
		if(requisitiMinimiBeanVisualizzazione.getNazioneResidenzaUtente()!=null &&  requisitiMinimiBeanVisualizzazione.getNazioneResidenzaUtente().equals("IT")){
			
			requisitiMinimiBeanVisualizzazione.setComuneResidenzaUtente(Localita.getDenominazioneComune(requisitiMinimiBeanVisualizzazione.getComuneResidenzaUtente()));
			requisitiMinimiBeanVisualizzazione.setPrvResidenzaUtente(Localita.getDenominazioneProvincia(requisitiMinimiBeanVisualizzazione.getPrvResidenzaUtente()));
			}
							
			
		
		
		
		//controlla regione selezionata: se corrisponde a Bolzano attiva il pannello opzionale della pagina
		String codiceRegione=(String)GetSessionUtility.getSessionAttribute(RepositorySession.ID_REGIONE);
		if(codiceRegione!=null && codiceRegione.equals("041"))
			requisitiMinimiBeanVisualizzazione.setIsBolzano(true);
		
		String fattispecieAppartenenza = requisitiMinimiBeanVisualizzazione.getFattispecieAppartenenza();
		if(lingua.equalsIgnoreCase("de")){
			requisitiMinimiBeanVisualizzazione.setCodTipoLaurea(matriceDe.getMatricePropertiesDe(requisitiMinimiBean.getCodTipoLaurea().replace(" ", "_")));
			if(fattispecieAppartenenza.equals("1")){
				requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("Kein Apothekeninhaber, unabh�ngig von der beruflichen Situation");
			}else if(fattispecieAppartenenza.equals("2")){
				requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("Inhaber einer �Landapotheke mit Standortzulage� (farmacia rurale sussidiata)");
			}else if(fattispecieAppartenenza.equals("3")){
				requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("Inhaber einer ��berz�hligen Apotheke� (farmacia soprannumeraria)");
			}else if(fattispecieAppartenenza.equals("4")){
				requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("Inhaber von Betrieben gem�� Art. 5, Absatz 1 des Gesetzesdekrets Nr. 223 vom 4. Juli 2006, mit �nderungen umgewandelt in Gesetz Nr. 248 vom 4. August 2006");
			}else if(fattispecieAppartenenza.equals("5")){
				requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("Teilhaber einer Gesellschaft, die Inhaberin einer �Landapotheke mit Standortzulage� (farmacia rurale sussidiata) oder einer ��berz�hligen Apotheke� (farmacia soprannumeraria) ist, sofern die Gesellschaft nicht auch Inhaberin von Apotheken ist, die nicht den vorgenannten Merkmalen entsprechen");
			}
		}else{
			if(fattispecieAppartenenza.equals("1")){
				requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("non titolari di farmacia in qualunque condizione professionale si trovino");
			}else if(fattispecieAppartenenza.equals("2")){
				requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("titolari di farmacia rurale sussidiata");
			}else if(fattispecieAppartenenza.equals("3")){
				requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("titolari di farmacia soprannumeraria");
			}else if(fattispecieAppartenenza.equals("4")){
				requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("titolari di esercizio di cui all art. 5 comma 1 del decreto legge 4 luglio 2006 n. 223, convertito con modificazioni nella legge 4 agosto 2006 n. 248");
			}else if(fattispecieAppartenenza.equals("5")){
				requisitiMinimiBeanVisualizzazione.setFattispecieAppartenenza("soci di societa titolare di farmacia rurale sussidiata o di farmacia  soprannumeraria,a condizione che la societa non sia titolare anche di farmacie prive delle predette caratteristiche");
			}
		}
		
		
		
		if(lingua.equalsIgnoreCase("de")){
			requisitiMinimiBeanVisualizzazione.setNazioneAbilitazione(matriceDe.getMatricePropertiesDe(requisitiMinimiBean.getNazioneAbilitazione().replace(" ", "_")));
		}
		
		
		requisitiMinimiBeanVisualizzazione.setPrvAlbo(Localita.getDenominazioneProvincia(requisitiMinimiBeanVisualizzazione.getPrvAlbo()));
		requisitiMinimiBeanVisualizzazione.setPrvAttualeAlbo(Localita.getDenominazioneProvincia(requisitiMinimiBeanVisualizzazione.getPrvAttualeAlbo()));
		requisitiMinimiBeanVisualizzazione.setNazioneNascitaUtente(Localita.getDenominazioneNazione(requisitiMinimiBeanVisualizzazione.getNazioneNascitaUtente(),lingua));
		requisitiMinimiBeanVisualizzazione.setNazioneResidenzaUtente(Localita.getDenominazioneNazione(requisitiMinimiBeanVisualizzazione.getNazioneResidenzaUtente(),lingua));
		requisitiMinimiBeanVisualizzazione.setStatoUe(Localita.getDenominazioneNazione(requisitiMinimiBeanVisualizzazione.getStatoUe(),lingua));
		requisitiMinimiBeanVisualizzazione.setProvinciaListaElettorale(Localita.getDenominazioneProvincia(requisitiMinimiBeanVisualizzazione.getProvinciaListaElettorale()));
	}
	
	//inserisce dati del bean di pagina nel db
	public boolean updateDAO(String idUtente,java.sql.Timestamp now,RequisitiMinimiBean requisitiMinimiBean)
	{
		//aggiorna
		utenteCandidatura.setLastUpdateDateUtente(now);
		utenteCandidatura.setLastUpdatedByUtente(idUtente);
		
		//se � la prima volta che si esegue un'aggiornamento, crea un record sulla tabella Requisiti Minimi
		//(qualora non ne esista gi� uno associato all'id utente corrente) 
		if(requisitiMinimi==null)
		{
			requisitiMinimi=new RequisitiMinimi(idUtente,
											    idUtente,
											    now,
											    idUtente,
											    now);
		}
		else
		{
			requisitiMinimi.setLastUpdatedByReq(idUtente);
			requisitiMinimi.setLastUpdateDateReq(now);
		}
		
		//preleva i dati dal bean di pagina e li copia nei bean del db
		try
		{	
			if(utenteCandidatura!=null)
				BeanUtils.copyProperties(utenteCandidatura,requisitiMinimiBean);

			if(requisitiMinimi!=null)
				BeanUtils.copyProperties(requisitiMinimi,requisitiMinimiBean);
		}
		catch(IllegalAccessException  e)
		{
			e.printStackTrace();
			return false;
		}
		catch(InvocationTargetException e)
		{
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	public UtenteCandidatura getUtenteCandidatura() {
		return utenteCandidatura;
	}

	public void setUtenteCandidatura(UtenteCandidatura utenteCandidatura) {
		this.utenteCandidatura = utenteCandidatura;
	}

	public RequisitiMinimi getRequisitiMinimi() {
		return requisitiMinimi;
	}

	public void setRequisitiMinimi(RequisitiMinimi requisitiMinimi) {
		this.requisitiMinimi = requisitiMinimi;
	}
}