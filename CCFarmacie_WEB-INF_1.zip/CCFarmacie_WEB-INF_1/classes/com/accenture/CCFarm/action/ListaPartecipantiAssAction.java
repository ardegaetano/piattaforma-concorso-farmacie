
package com.accenture.CCFarm.action;

import java.util.ArrayList;

import com.accenture.CCFarm.Bean.PartecipanteAssociazione;
import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.DAO.UtenteCandidaturaHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.LogUtil;
import com.accenture.CCFarm.utility.MatricePropertiesDe;
import com.accenture.CCFarm.utility.TabellaDecodifica;

public class ListaPartecipantiAssAction {

	public ListaPartecipantiAssAction() {

	}
	MatricePropertiesDe matriceDe = MatricePropertiesDe.getMatricePropertiesDe(); 
	
	public ArrayList<PartecipanteAssociazione> loadPagina(String idUtente, Candidatura candidatura, boolean isTedesco)
			throws GestioneErroriException {

		// RECUPERO DALLA SESSIONE

		CandidaturaHome candHome = new CandidaturaHome();
		UtenteCandidaturaHome utCandHome = new UtenteCandidaturaHome();
		ArrayList<PartecipanteAssociazione> listaPartecipanti = new ArrayList<PartecipanteAssociazione>();

		// recupero l'id della candidatura dell'utente che ricerca
		Candidatura cand = new Candidatura();
		try {
			cand = candHome.findById(idUtente);
		} catch (Exception e) {
			LogUtil.printException(e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"ListaPartecipantiAssAction - loadPagina - 1 - ");
			LogUtil.printException(eccezione);

			throw eccezione;
		}

		String idCand = cand.getIdCandidatura();

		// recupero l'elenco di candidati in associata, escluso l'utente che
		// cerca
		Candidatura candRic = new Candidatura();
		candRic.setIdCandidatura(idCand);
		// ArrayList<Candidatura> listAss = (ArrayList<Candidatura>) candHome
		// .findByExample(candRic);

		UtenteCandidatura utCandRic = new UtenteCandidatura();
		utCandRic.setCandidatura(new Candidatura());
		utCandRic.getCandidatura().setIdCandidatura(idCand);

		ArrayList<UtenteCandidatura> listAss = new ArrayList<UtenteCandidatura>();
		try {

			// imposto la query da eseguire a db

			String query = "select u from UtenteCandidatura u where u.candidatura.idCandidatura = '"
					+ idCand + "' and u.idUtente != '" + idUtente+"'";

			listAss = (ArrayList<UtenteCandidatura>) utCandHome
					.findByQuery(query);
		} catch (Exception e) {
			LogUtil.printException(e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"ListaPartecipantiAssAction - loadPagina - 2 -");
			LogUtil.printException(eccezione);
			throw eccezione;
		}

		for (int i = 0; i < listAss.size(); i++) {
			UtenteCandidatura utCand = listAss.get(i);
			PartecipanteAssociazione part = new PartecipanteAssociazione();
			part.setIdUtente(utCand.getIdUtente());
			part.setNominativo(utCand.getCognomeUtente() + " "
					+ utCand.getNomeUtente());
			part.setCodiceFiscale(utCand.getCodiceFiscaleUtente());
			part.setCodStatoDomanda(utCand.getCandidatura().getStatoDomanda());
			part.setIdCandidatura(utCand.getCandidatura().getIdCandidatura());

			if (part.getCodStatoDomanda() != null) {
				
				if(isTedesco){
					
					part.setDescrStatoDomanda((String) TabellaDecodifica.decodificaStatoCandidatura(part.getCodStatoDomanda(), "de"));
				}else{
				part.setDescrStatoDomanda((String) TabellaDecodifica
						.getTabellaDecodifica().get(
								part.getCodStatoDomanda()
										+ "_STATO_CANDIDATURA"));
				}
				if (part.getCodStatoDomanda().equals("C") && candidatura.getReferenteDomanda()!=null && candidatura.getReferenteDomanda().equals("Y") ) {
					part.setRiattivaVisibile(false);
				} else {
					part.setRiattivaVisibile(true);
				}
			}

			part.setCodTipoPartecipante(utCand.getCandidatura()
					.getReferenteDomanda());
			if (part.getCodTipoPartecipante() != null) {
				if(isTedesco){
					if (part.getCodTipoPartecipante().equals("N")) {
						part.setDescrTipoPartecipante(matriceDe.getMatricePropertiesDe("Associato"));
					} else {
						part.setDescrTipoPartecipante(matriceDe.getMatricePropertiesDe("Referente"));
					}
				}else{
					if (part.getCodTipoPartecipante().equals("N")) {
						part.setDescrTipoPartecipante("Associato");
					} else {
						part.setDescrTipoPartecipante("Referente");
					}
				}

			}

			listaPartecipanti.add(part);

		}

		return listaPartecipanti;

	}

	public void riattivaCandidatura(String idUtenteAss, String idUtente)
			throws GestioneErroriException {

		// recupero la candidatura dell'utente
		CandidaturaHome candHome = new CandidaturaHome();
		Candidatura cand = candHome.findById(idUtenteAss);
		java.util.Date dataSys = new java.util.Date();
		java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());

		cand.setStatoDomanda("B");
		cand.setLastUpdatedByCand(idUtente);
		cand.setLastUpdateDateCand(oggi);

		try {
			candHome.saveOrUpdate(cand);

		} catch (Exception e) {
			LogUtil.printException(e);
			GestioneErroriException eccezione = new GestioneErroriException(
					"ListaPartecipantiAssAction - riattivaCandidatura - 1 -");
			LogUtil.printException(eccezione);

			throw eccezione;
		}

	}

}