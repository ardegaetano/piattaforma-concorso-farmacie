package com.accenture.CCFarm.action;

import java.util.List;

import com.accenture.CCFarm.DAO.ComuneHome;
import com.accenture.CCFarm.DAO.FarmacieHome;
import com.accenture.CCFarm.DAO.FarmacieSearch;
import com.accenture.CCFarm.DAO.ProvinciaHome;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.PageBean.RicercaFarmacieBean;



public class RicercaFarmacieAction{

	//membri per le localit� --------------------------------------------------------------------------------------------------------------
	List regioni;
	RegioneHome regioneHome;
    List province;
	ProvinciaHome provinciaHome;
	List comuni;
	ComuneHome comuneHome;
	//--------------------------------------------------------------------------------------------------------------

	public RicercaFarmacieAction(){
		regioneHome=new RegioneHome();
		provinciaHome= new ProvinciaHome();
		comuneHome= new ComuneHome();
				
	}
	
	
   
    public boolean init(RicercaFarmacieBean ricercaFarmacieBean) {
    	
    	System.out.println("init ricerca action");
    	
    	if(ricercaFarmacieBean==null) return false;
		try
		{
			
			
		}
		catch(RuntimeException e)
		{
			e.printStackTrace();
			return false;
		}
		
		return true;
    }
    
    public List<FarmacieSearch> ricerca(RicercaFarmacieBean ricercaFarmacieBean) throws GestioneErroriException{
    	FarmacieHome farmacieHome=new FarmacieHome();
    	FarmacieSearch farmacieSearch = new FarmacieSearch();
    	farmacieSearch.setCodRg(ricercaFarmacieBean.getRegioneSelezionata());
    	farmacieSearch.setCodIstatProv(ricercaFarmacieBean.getProvinciaSelezionata());
    	farmacieSearch.setCodIstatComu(ricercaFarmacieBean.getComuneSelezionato());
    	farmacieSearch.setpIva(ricercaFarmacieBean.getPartitaIVA());
    	farmacieSearch.setCodCap(ricercaFarmacieBean.getCodCap());
    	farmacieSearch.setIndirizzo(ricercaFarmacieBean.getIndirizzo());
    	farmacieSearch.setIdMinisetro("18216");
    	List<FarmacieSearch> farmList = farmacieHome.findByFilter(farmacieSearch);
    	//		for (int i = 0; i < farmList.size(); i++) {
//			Farmacie farmacie = new Farmacie();
//			farmacie= farmList.get(i);
//			farmacieSearch.setIdMinisetro(farmacie.getId().getCodPf());
//			farmacieSearch.setDesSede(farmacie.getId().getDesFmc());
//			farmacieSearch.setIndirizzo(farmacie.getId().getDesInd());
//			farmacieSearch.setCodCap(farmacie.getId().getDesCap());
//			fS.add(farmacieSearch);
//		}
    	
    	
    	return farmList ;
    }
    
}