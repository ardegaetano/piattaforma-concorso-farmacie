package com.accenture.CCFarm.action;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.PageBean.Domanda;
import com.accenture.CCFarm.utility.AppProperties;
import com.accenture.CCFarm.utility.CommonLogger;

/**
 * Servlet implementation class DemoServlet
 */

@SuppressWarnings("serial")
public class DemoServlet extends HttpServlet
{
	Logger logger = CommonLogger.getLogger("DemoServlet.java");
	
	/**
     * @see HttpServlet#HttpServlet()
     */
    public DemoServlet() 
    {
        super(); 
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException
	{
		super.init();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		//avvia la modalit� di navigazione demo
		//imposta in sessione un attributo per abilitare la navigazione della domanda in modalit� demo
		
		HttpSession session = request.getSession();
    	session.setAttribute("navigazioneDemo","navigazioneDemo");
    	Domanda domanda=(Domanda)session.getAttribute("domanda");
		if(domanda!=null)
		{
			// se gi� presente, rimuovi il riferimento all'istanza per farne creare una pulita
			// (necessario per evitare che vengano mostrati eventuali dati inseriti in precedenza)
			session.removeAttribute("domanda");
		}
		
		//redirigi verso la pagina di compilazione
		response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/compilaDomanda.jsf");
	}
}