package com.accenture.CCFarm.converter;

import javax.faces.bean.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import com.accenture.CCFarm.DAO.AnagraficaFarm;
import com.accenture.CCFarm.PageBean.ScegliSedi;
import com.accenture.CCFarm.utility.JSFUtility;

@FacesConverter(forClass=AnagraficaFarm.class, value="sediConverter")
@RequestScoped
public class SediConverter implements Converter {

	private ScegliSedi scegliSediBean;
	
	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String value) {
		
		if (value != null && !value.equals("")) {
			
			return getScegliSediBean().getAnagraficaFarmMap().get(value);
		}
		else {
			
			return null;
		}
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object value) {
		
		if (value != null && !value.equals("")) {
			
			AnagraficaFarm anagraficaFarm = (AnagraficaFarm) value;
			return anagraficaFarm.getIdFarm();
		}
		else {
			
			return "";
		}
	}

	public ScegliSedi getScegliSediBean() {
		
		if(scegliSediBean == null) {
			
			scegliSediBean = (ScegliSedi) JSFUtility.getUIViewRoot().getViewMap().get("scegliSedi");
		}
		
		return scegliSediBean;
	}

}
