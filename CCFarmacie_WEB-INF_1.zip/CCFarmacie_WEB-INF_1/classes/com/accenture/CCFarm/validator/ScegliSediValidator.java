package com.accenture.CCFarm.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import org.apache.log4j.Logger;
import org.primefaces.model.DualListModel;

import com.accenture.CCFarm.DAO.AnagraficaFarm;
import com.accenture.CCFarm.PageBean.ScegliSedi;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.StringUtil;

@FacesValidator(value = "com.accenture.CCFarm.validator.ScegliSediValidator")
public class ScegliSediValidator implements Validator {
	
	private Logger logger = CommonLogger.getLogger("ScegliSedi");
	
	@SuppressWarnings("unchecked")
	@Override
	public void validate(FacesContext ctx, UIComponent component, Object value) throws ValidatorException {
		
		try {
		
			if(value instanceof DualListModel<?>) {
				
				int numeroSediSelezionate = ((DualListModel<AnagraficaFarm>) value).getTarget().size();
				
				ScegliSedi scegliSedi = (ScegliSedi) JSFUtility.getUIViewRoot().getViewMap().get("scegliSedi");
				
				int numeroSediSelezionabili = Integer.parseInt(scegliSedi.getNumSediSelezionabili());
				
				if(numeroSediSelezionate != numeroSediSelezionabili) {
					
					String corpoMessaggio = StringUtil.getPropertyMessage("scegliSedi.validator.pickList", "it");
					
					JSFUtility.addWarningMessage("", corpoMessaggio);
					
					FacesMessage facesMessage = new FacesMessage("", corpoMessaggio);
					facesMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
					throw new ValidatorException(facesMessage);
				}
			}
		}
		catch(Exception e) {
			
			//se l'eccezione catturata non � di validazione
			if(e instanceof ValidatorException) {
				
				throw (ValidatorException) e;
			}
			else {
				
				logger.error("Errore durante la validazione della scelta sedi", e);
			}
		}
	}

}
