package com.accenture.CCFarm.Annotation;


import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;

@Retention(RUNTIME)
public @interface CustomBeanAnnotation 
{    
    public String ETICHETTA();
    public boolean REQUIRED() default true;
    public Class<?> TYPE() default String.class;
    public boolean READONLY() default false;
}