package com.accenture.CCFarm.Bean;

import java.util.Date;

public class BorsaStudio {
	
	private String idBorsaStudio;
	private String denominazioneBorsa;
	private String descrFacoltaBorsa;
	private String descrUniversitaBorsa;
	private String luogoBorsa;
	private String nazioneBorsa;
	private Date   dataInizioBorsa;
	private Date   dataFineBorsa;
	private String   dataInizioBorsaStringa;
	private String   dataFineBorsaStringa;
	private String flagEsteroBorsa;
	
	public String getDenominazioneBorsa() {
		return denominazioneBorsa;
	}
	public String getIdBorsaStudio() {
		return idBorsaStudio;
	}
	public void setIdBorsaStudio(String idBorsaStudio) {
		this.idBorsaStudio = idBorsaStudio;
	}
	public void setDenominazioneBorsa(String denominazioneBorsa) {
		this.denominazioneBorsa = denominazioneBorsa;
	}
	public String getDescrFacoltaBorsa() {
		return descrFacoltaBorsa;
	}
	public void setDescrFacoltaBorsa(String descrFacoltaBorsa) {
		this.descrFacoltaBorsa = descrFacoltaBorsa;
	}
	public String getDescrUniversitaBorsa() {
		return descrUniversitaBorsa;
	}
	public void setDescrUniversitaBorsa(String descrUniversitaBorsa) {
		this.descrUniversitaBorsa = descrUniversitaBorsa;
	}
	public String getLuogoBorsa() {
		return luogoBorsa;
	}
	public void setLuogoBorsa(String luogoBorsa) {
		this.luogoBorsa = luogoBorsa;
	}
	public String getNazioneBorsa() {
		return nazioneBorsa;
	}
	public void setNazioneBorsa(String nazioneBorsa) {
		this.nazioneBorsa = nazioneBorsa;
	}
	public Date getDataInizioBorsa() {
		return dataInizioBorsa;
	}
	public void setDataInizioBorsa(Date dataInizioBorsa) {
		this.dataInizioBorsa = dataInizioBorsa;
	}
	public Date getDataFineBorsa() {
		return dataFineBorsa;
	}
	public void setDataFineBorsa(Date dataFineBorsa) {
		this.dataFineBorsa = dataFineBorsa;
	}
	public String getFlagEsteroBorsa() {
		return flagEsteroBorsa;
	}
	public void setFlagEsteroBorsa(String flagEsteroBorsa) {
		this.flagEsteroBorsa = flagEsteroBorsa;
	}
	public String getDataInizioBorsaStringa() {
		return dataInizioBorsaStringa;
	}
	public void setDataInizioBorsaStringa(String dataInizioBorsaStringa) {
		this.dataInizioBorsaStringa = dataInizioBorsaStringa;
	}
	public String getDataFineBorsaStringa() {
		return dataFineBorsaStringa;
	}
	public void setDataFineBorsaStringa(String dataFineBorsaStringa) {
		this.dataFineBorsaStringa = dataFineBorsaStringa;
	}
		

}
