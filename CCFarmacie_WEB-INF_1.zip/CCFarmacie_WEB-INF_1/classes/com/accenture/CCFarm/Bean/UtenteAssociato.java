package com.accenture.CCFarm.Bean;

import com.accenture.CCFarm.action.RichiestaCredenzialiAction;
import com.accenture.CCFarm.utility.StringUtil;

public class UtenteAssociato{

//anagrafica utente associato
private String nomeUtenteAssociato;
private String cognomeUtenteAssociato;
private String sessoAssociato;
private String codiceFiscaleUtenteAssociato;
private String pecMailAssociato;

private String replicaPecMailAssociato;

private java.util.Date dataNascitaAssociato;
private String luogoNascitaUtenteAssociato;
private String luogoNascitaEsteraUtenteAssociato;
private String nazioneNascitaUtenteAssociato;
private String prvNascitaUtenteAssociato;
private String dataNascitaAssociatoString;
private String flagCodiceFiscaleItalianoAssociato = "true";

//estremi documento
private String tipoDocumentoAssociato;
private String numeroDocAssociato;
private String enteRilascioDocAssociato;
private java.util.Date dataRilascioDocAssociato;

private String regioneRichiesta;
RichiestaCredenzialiAction richiestaCredenzialiAction = new RichiestaCredenzialiAction();


public String getTipoDocumentoAssociato() {
	return tipoDocumentoAssociato;
}
public void setTipoDocumentoAssociato(String tipoDocumentoAssociato) {
	this.tipoDocumentoAssociato = tipoDocumentoAssociato;
}
public String getEnteRilascioDocAssociato() {
	return enteRilascioDocAssociato;
}
public void setEnteRilascioDocAssociato(String enteRilascioDocAssociato) {
	this.enteRilascioDocAssociato = enteRilascioDocAssociato;
}
public java.util.Date getDataRilascioDocAssociato() {
	return dataRilascioDocAssociato;
}
public void setDataRilascioDocAssociato(java.util.Date dataRilascioDocAssociato) {
	this.dataRilascioDocAssociato = dataRilascioDocAssociato;
}
public String getNumeroDocAssociato() {
	return numeroDocAssociato;
}
public void setNumeroDocAssociato(String numeroDocAssociato) {
	this.numeroDocAssociato = numeroDocAssociato;
}
public String getNomeUtenteAssociato() {
	return nomeUtenteAssociato;
}
public void setNomeUtenteAssociato(String nomeUtenteAssociato) {
	this.nomeUtenteAssociato = nomeUtenteAssociato;
}
public String getCognomeUtenteAssociato() {
	return cognomeUtenteAssociato;
}
public void setCognomeUtenteAssociato(String cognomeUtenteAssociato) {
	this.cognomeUtenteAssociato = cognomeUtenteAssociato;
}
public String getSessoAssociato() {
	return sessoAssociato;
}
public void setSessoAssociato(String sessoAssociato) {
	this.sessoAssociato = sessoAssociato;
}
public String getCodiceFiscaleUtenteAssociato() {
	return codiceFiscaleUtenteAssociato;
}
public void setCodiceFiscaleUtenteAssociato(String codiceFiscaleUtenteAssociato) {
	this.codiceFiscaleUtenteAssociato = codiceFiscaleUtenteAssociato;
}
public String getPecMailAssociato() {
	return pecMailAssociato;
}
public void setPecMailAssociato(String pecMailAssociato) {
	//imposta il nuovo valore (eliminando gli spazi)
	if(pecMailAssociato!=null)
	{
		this.pecMailAssociato = pecMailAssociato.trim();
	}
	else
	{
		this.pecMailAssociato = null;
	}
}

public String getReplicaPecMailAssociato() {
	return replicaPecMailAssociato;
}
public void setReplicaPecMailAssociato(String replicaPecMailAssociato) {
	//imposta il nuovo valore (eliminando gli spazi)
	if(replicaPecMailAssociato!=null)
	{
		this.replicaPecMailAssociato = replicaPecMailAssociato.trim();
	}
	else
	{
		this.replicaPecMailAssociato = null;
	}
}

public java.util.Date getDataNascitaAssociato() {
		return dataNascitaAssociato;
}
public void setDataNascitaAssociato(java.util.Date dataNascitaAssociato) {
	
	if(dataNascitaAssociato!=null && !dataNascitaAssociato.equals("")){
	dataNascitaAssociatoString = StringUtil.dateToStringDDMMYYYY(dataNascitaAssociato);
	}
	this.dataNascitaAssociato = dataNascitaAssociato;
}
public String getLuogoNascitaUtenteAssociato() {
	return luogoNascitaUtenteAssociato;
}
public void setLuogoNascitaUtenteAssociato(String luogoNascitaUtenteAssociato) {
	this.luogoNascitaUtenteAssociato = luogoNascitaUtenteAssociato;
}

public String getDataNascitaAssociatoString() {
	return dataNascitaAssociatoString;
}
public void setDataNascitaAssociatoString(String dataNascitaAssociatoString) {
	this.dataNascitaAssociatoString = dataNascitaAssociatoString;
}
public String getNazioneNascitaUtenteAssociato() {
	return nazioneNascitaUtenteAssociato;
}
public void setNazioneNascitaUtenteAssociato(
		String nazioneNascitaUtenteAssociato) {
	this.nazioneNascitaUtenteAssociato = nazioneNascitaUtenteAssociato;
}

public String getPrvNascitaUtenteAssociato() {
	return prvNascitaUtenteAssociato;
}
public void setPrvNascitaUtenteAssociato(String prvNascitaUtenteAssociato) {
	this.prvNascitaUtenteAssociato = prvNascitaUtenteAssociato;
}
public String getRegioneRichiesta() {
	return regioneRichiesta;
}
public void setRegioneRichiesta(String regioneRichiesta) {
	this.regioneRichiesta = regioneRichiesta;
}
public String getLuogoNascitaEsteraUtenteAssociato() {
	return luogoNascitaEsteraUtenteAssociato;
}
public void setLuogoNascitaEsteraUtenteAssociato(
		String luogoNascitaEsteraUtenteAssociato) {
	this.luogoNascitaEsteraUtenteAssociato = luogoNascitaEsteraUtenteAssociato;
}
public String getFlagCodiceFiscaleItalianoAssociato() {
	return flagCodiceFiscaleItalianoAssociato;
}
public void setFlagCodiceFiscaleItalianoAssociato(
		String flagCodiceFiscaleItalianoAssociato) {
	this.flagCodiceFiscaleItalianoAssociato = flagCodiceFiscaleItalianoAssociato;
}

}

