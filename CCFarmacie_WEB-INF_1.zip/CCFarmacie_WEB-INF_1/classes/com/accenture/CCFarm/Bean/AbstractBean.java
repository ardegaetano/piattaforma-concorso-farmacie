package com.accenture.CCFarm.Bean;


import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Properties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.accenture.CCFarm.Annotation.CustomBeanAnnotation;
import com.accenture.CCFarm.Customclasstype.TypeClassVerifier;
import com.accenture.CCFarm.Exception.BeanException;
import com.accenture.CCFarm.Exception.GestioneErroriException;


//import com.accenture.farmavigvetmodule.annotation.CustomBeanAnnotation;
//import com.accenture.farmavigvetmodule.customclasstype.TypeClassVerifier;
//import com.accenture.farmavigvetmodule.exception.BeanException;
//import com.accenture.farmavigvetmodule.exception.GestioneErroriException;
//import com.accenture.farmavigvetmodule.utility.ConnectionProperties;

@XmlAccessorType(XmlAccessType.NONE)
public abstract class AbstractBean extends AbstractBeanUtil
{
    
	private static final Properties ConnectionProperties = null;
	private static Properties p = null;   
	static
	{		
		if (p==null)
		{
			try
			{
				p = new Properties();
				p.load(AbstractBean.class.getResourceAsStream("/messaggi.properties"));
			}
			catch (IOException e)
			{
				// TODO: handle exception
			}
		}
	}
    
    
	public void populate(HashMap<String, String[]> parametri, int arrayIndex) throws BeanException
	{
		Field campi[] = this.getClass().getDeclaredFields();
		for (int c = 0; c < campi.length; c++)
		{	   
			try
			{
				if(campi[c].getType().equals(String.class) &&!(campi[c].getModifiers()==Modifier.PRIVATE))
					campi[c].set(this, "");
				if (parametri.get(campi[c].getName()) != null && !(campi[c].getModifiers()==Modifier.PRIVATE))
					campi[c].set(this, parametri.get(campi[c].getName())[arrayIndex].trim());
			}
			catch (IllegalArgumentException e)
			{ 
				throw new BeanException("ERRORE NEL POPOLAMENTO DEL BEAN "+this.getClass(),e);
			}
			catch (IllegalAccessException e)
			{ 
				throw new BeanException("ERRORE NEL POPOLAMENTO DEL BEAN "+this.getClass(),e);
			}
			catch (NullPointerException n)
			{		
				throw new BeanException("ARRAY INDEX FUORI RANGE NEL POPOLAMENTO DEL BEAN"+this.getClass(),n);
			}
		}
	}

	public boolean validate() throws BeanException
	{
		boolean retVal = true;
		try
		{
			Field campi[] = this.getClass().getDeclaredFields();
			String valoreCampo = "";
			Annotation annotation = null;
			for (int i = 0; i < campi.length && !Boolean.parseBoolean(ConnectionProperties.getProperty("DEVELOPE_MODE")); i++)
			{
				annotation = campi[i].getAnnotation(CustomBeanAnnotation.class);
				if (annotation != null && annotation instanceof CustomBeanAnnotation)
				{
					valoreCampo = (String) campi[i].get(this);
					CustomBeanAnnotation constraint = (CustomBeanAnnotation) annotation;

					//INIZIO CONTROLLI		   

					if ((valoreCampo == null || valoreCampo.trim().equals("")) && constraint.REQUIRED())
					{
						retVal = false;
						String codMsg = this.getClass().getSimpleName()+"."+campi[i].getName()+".REQUIRED";
						String msg = p.getProperty(codMsg);
						if (msg == null) msg = p.getProperty("*.REQUIRED");
						if (msg == null) msg = " messaggio errore non configurato per :" +codMsg;
						//errori.addError(campi[i].getAnnotation(CustomBeanAnnotation.class).ETICHETTA(), msg);
						errori.addError(campi[i].getName(), msg);
						continue;
						//il continue interrompe il controllo se campo � obbligatorio
						//saltano quindi eventuali controlli successivi 
					}

					if (!TypeClassVerifier.verify(constraint.TYPE(), valoreCampo))
					{	
						retVal = false;
						String codMsg = this.getClass().getSimpleName()+"."+campi[i].getName()+".TYPE";
						String msg = p.getProperty(codMsg);
						if (msg == null) msg = p.getProperty("*."+constraint.TYPE().getSimpleName());
						if (msg == null) msg = " messaggio errore non configurato per :" +codMsg;
						errori.addError(campi[i].getName(), msg);
						continue;
					}

				}
			}
		}
		catch (IllegalAccessException e)
		{
			retVal=false;
			throw new BeanException("ERRORE NELLA VALIDAZIONE DEL BEAN "+this.getClass(),e);
		}
		catch (GestioneErroriException e)
		{
			retVal=false;
			throw new BeanException("ERRORE: ",e);
		}
		return retVal;
	}

	public void fillFake(HashMap<String, String[]> parametri, int arrayIndex) throws BeanException
	{
		Field campi[] = this.getClass().getDeclaredFields();
		for (int c = 0; c < campi.length; c++)
		{	   
			try
			{
				if(campi[c].getType().equals(String.class) &&!(campi[c].getModifiers()==Modifier.PRIVATE))
					campi[c].set(this, "");
				if (!(campi[c].getModifiers()==Modifier.PRIVATE))
					campi[c].set(this, "XXXXX");
			}
			catch (IllegalArgumentException e)
			{ 
				throw new BeanException("ERRORE NEL POPOLAMENTO DEL BEAN "+this.getClass(),e);
			}
			catch (IllegalAccessException e)
			{ 
				throw new BeanException("ERRORE NEL POPOLAMENTO DEL BEAN "+this.getClass(),e);
			}
			catch (NullPointerException n)
			{		
				throw new BeanException("arrayIndexm fuori range "+this.getClass(),n);
			}
		}
	}

	public CustomBeanAnnotation getCustomBeanAnnotation(String campoBean) throws BeanException
	{	
		CustomBeanAnnotation constraint =null;
		try
		{
			Field campo = this.getClass().getDeclaredField(campoBean);
			Annotation annotation = null;

			annotation = campo.getAnnotation(CustomBeanAnnotation.class);
			if (annotation != null && annotation instanceof CustomBeanAnnotation)
			{
				constraint = (CustomBeanAnnotation) annotation;		    
			}


		}
		catch (NullPointerException e)
		{	 
			throw new BeanException("ERRORE NELL'ACCESSO ALLA PROPRIETA DELL'ANNOTATION DEL BEAN "+this.getClass(),e);
		}
		catch (SecurityException e)
		{
			throw new BeanException("ERRORE NELL'ACCESSO ALLA PROPRIETA DELL'ANNOTATION DEL BEAN "+this.getClass(),e);	
		}
		catch (NoSuchFieldException e)
		{
			throw new BeanException("ERRORE NELL'ACCESSO ALLA PROPRIETA DELL'ANNOTATION DEL BEAN "+this.getClass(),e);
		}
		return constraint;
	}
  
}
