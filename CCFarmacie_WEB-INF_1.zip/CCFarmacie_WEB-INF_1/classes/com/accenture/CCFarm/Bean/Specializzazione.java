package com.accenture.CCFarm.Bean;

public class Specializzazione {
	
	private String idSpecializzazione;
	private String denominazioneSpec;
	private String descrFacoltaSpec;
	private String descrUniversitaSpec;
	private String luogoSpec;
	private String nazioneSpec;
	private String durataSpec;
	private String flagEsteroSpec;
	
	public String getDenominazioneSpec() {
		return denominazioneSpec;
	}
	public String getIdSpecializzazione() {
		return idSpecializzazione;
	}
	public void setIdSpecializzazione(String idSpecializzazione) {
		this.idSpecializzazione = idSpecializzazione;
	}
	public void setDenominazioneSpec(String denominazioneSpec) {
		this.denominazioneSpec = denominazioneSpec;
	}
	public String getDescrFacoltaSpec() {
		return descrFacoltaSpec;
	}
	public void setDescrFacoltaSpec(String descrFacoltaSpec) {
		this.descrFacoltaSpec = descrFacoltaSpec;
	}
	public String getDescrUniversitaSpec() {
		return descrUniversitaSpec;
	}
	public void setDescrUniversitaSpec(String descrUniversitaSpec) {
		this.descrUniversitaSpec = descrUniversitaSpec;
	}
	public String getLuogoSpec() {
		return luogoSpec;
	}
	public void setLuogoSpec(String luogoSpec) {
		this.luogoSpec = luogoSpec;
	}
	public String getNazioneSpec() {
		return nazioneSpec;
	}
	public void setNazioneSpec(String nazioneSpec) {
		this.nazioneSpec = nazioneSpec;
	}
	
	public String getDurataSpec() {
		return durataSpec;
	}
	public void setDurataSpec(String durataSpec) {
		this.durataSpec = durataSpec;
	}
	public String getFlagEsteroSpec() {
		return flagEsteroSpec;
	}
	public void setFlagEsteroSpec(String flagEsteroSpec) {
		this.flagEsteroSpec = flagEsteroSpec;
	}
	

}
