package com.accenture.CCFarm.Bean;

import java.util.Date;

public class CorsoAgg {

	private String idCorsoAgg;
	private String titoloCorsoAgg;
	private String organizzatoCorsoAgg;
	private Date   dataInizioCorsoAgg;
	private Date   dataFineCorsoAgg;
	private String   dataInizioCorsoAggStringa;
	private String   dataFineCorsoAggStringa;
	private String totOreCorsoAgg;
	private String dichiarazioneCorsoAgg;
	private String flagEsteroCorsoAgg;

	public String getTitoloCorsoAgg() {
		return titoloCorsoAgg;
	}
	public String getIdCorsoAgg() {
		return idCorsoAgg;
	}
	public void setIdCorsoAgg(String idCorsoAgg) {
		this.idCorsoAgg = idCorsoAgg;
	}
	public void setTitoloCorsoAgg(String titoloCorsoAgg) {
		this.titoloCorsoAgg = titoloCorsoAgg;
	}
	public String getOrganizzatoCorsoAgg() {
		return organizzatoCorsoAgg;
	}
	public void setOrganizzatoCorsoAgg(String organizzatoCorsoAgg) {
		this.organizzatoCorsoAgg = organizzatoCorsoAgg;
	}
	public Date getDataInizioCorsoAgg() {
		return dataInizioCorsoAgg;
	}
	public void setDataInizioCorsoAgg(Date dataInizioCorsoAgg) {
		this.dataInizioCorsoAgg = dataInizioCorsoAgg;
	}
	public Date getDataFineCorsoAgg() {
		return dataFineCorsoAgg;
	}
	public void setDataFineCorsoAgg(Date dataFineCorsoAgg) {
		this.dataFineCorsoAgg = dataFineCorsoAgg;
	}
	public String getDichiarazioneCorsoAgg() {
		return dichiarazioneCorsoAgg;
	}
	public void setDichiarazioneCorsoAgg(String dichiarazioneCorsoAgg) {
		this.dichiarazioneCorsoAgg = dichiarazioneCorsoAgg;
	}
	public String getFlagEsteroCorsoAgg() {
		return flagEsteroCorsoAgg;
	}
	public void setFlagEsteroCorsoAgg(String flagEsteroCorsoAgg) {
		this.flagEsteroCorsoAgg = flagEsteroCorsoAgg;
	}
	public String getDataInizioCorsoAggStringa() {
		return dataInizioCorsoAggStringa;
	}
	public void setDataInizioCorsoAggStringa(String dataInizioCorsoAggStringa) {
		this.dataInizioCorsoAggStringa = dataInizioCorsoAggStringa;
	}
	public String getDataFineCorsoAggStringa() {
		return dataFineCorsoAggStringa;
	}
	public void setDataFineCorsoAggStringa(String dataFineCorsoAggStringa) {
		this.dataFineCorsoAggStringa = dataFineCorsoAggStringa;
	}
	public String getTotOreCorsoAgg() {
		return totOreCorsoAgg;
	}
	public void setTotOreCorsoAgg(String totOreCorsoAgg) {
		this.totOreCorsoAgg = totOreCorsoAgg;
	}
	
	
}
