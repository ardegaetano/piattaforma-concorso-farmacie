package com.accenture.CCFarm.Bean;




public class RegioneSelect implements Comparable<RegioneSelect>{
	

private String descrizione;
private String codice;


public int compareTo(RegioneSelect otherObject)
{
    return descrizione.compareTo(otherObject.getDescrizione());
}



public String getDescrizione() {
	return descrizione;
}
public void setDescrizione(String descrizione) {
	this.descrizione = descrizione;
}
public String getCodice() {
	return codice;
}
public void setCodice(String codice) {
	this.codice = codice;
}




}

