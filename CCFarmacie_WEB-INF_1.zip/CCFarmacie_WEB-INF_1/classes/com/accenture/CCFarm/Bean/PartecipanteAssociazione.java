package com.accenture.CCFarm.Bean;

public class PartecipanteAssociazione {

	private String nome;
	private String cognome;
	private String nominativo;
	private String codiceFiscale;
	private String codTipoPartecipante;
	private String descrTipoPartecipante;
	private String codStatoDomanda;
	private String descrStatoDomanda;
	private String idUtente;
	private String idCandidatura;
	private Boolean riattivaVisibile;

	public Boolean getRiattivaVisibile() {
		return riattivaVisibile;
	}

	public void setRiattivaVisibile(Boolean riattivaVisibile) {
		this.riattivaVisibile = riattivaVisibile;
	}

	public String getIdCandidatura() {
		return idCandidatura;
	}

	public void setIdCandidatura(String idCandidatura) {
		this.idCandidatura = idCandidatura;
	}

	public String getIdUtente() {
		return idUtente;
	}

	public void setIdUtente(String idUtente) {
		this.idUtente = idUtente;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getCodiceFiscale() {
		return codiceFiscale;
	}

	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}

	public String getCodTipoPartecipante() {
		return codTipoPartecipante;
	}

	public void setCodTipoPartecipante(String codTipoPartecipante) {
		this.codTipoPartecipante = codTipoPartecipante;
	}

	public String getDescrTipoPartecipante() {
		return descrTipoPartecipante;
	}

	public void setDescrTipoPartecipante(String descrTipoPartecipante) {
		this.descrTipoPartecipante = descrTipoPartecipante;
	}

	public String getCodStatoDomanda() {
		return codStatoDomanda;
	}

	public void setCodStatoDomanda(String codStatoDomanda) {
		this.codStatoDomanda = codStatoDomanda;
	}

	public String getDescrStatoDomanda() {
		return descrStatoDomanda;
	}

	public void setDescrStatoDomanda(String descrStatoDomanda) {
		this.descrStatoDomanda = descrStatoDomanda;
	}

	public String getNominativo() {
		return nominativo;
	}

	public void setNominativo(String nominativo) {
		this.nominativo = nominativo;
	}

}
