package com.accenture.CCFarm.Bean;

import java.util.Date;

public class Pubblicazione {


	private String idPubblicazione;
	private String tipoPubblicazione;
	private String autorePubblicazione;
	private String titoloPubblicazione;
	private String editorePubblicazione;
	private String codIsbn;
	private Date dataPubblicazione;
	private String dataPubblicazioneStringa;
	
	public String getTipoPubblicazione() {
		return tipoPubblicazione;
	}
	public String getIdPubblicazione() {
		return idPubblicazione;
	}
	public void setIdPubblicazione(String idPubblicazione) {
		this.idPubblicazione = idPubblicazione;
	}
	public void setTipoPubblicazione(String tipoPubblicazione) {
		this.tipoPubblicazione = tipoPubblicazione;
	}
	public String getAutorePubblicazione() {
		return autorePubblicazione;
	}
	public void setAutorePubblicazione(String autorePubblicazione) {
		this.autorePubblicazione = autorePubblicazione;
	}
	public String getTitoloPubblicazione() {
		return titoloPubblicazione;
	}
	public void setTitoloPubblicazione(String titoloPubblicazione) {
		this.titoloPubblicazione = titoloPubblicazione;
	}
	public String getEditorePubblicazione() {
		return editorePubblicazione;
	}
	public void setEditorePubblicazione(String editorePubblicazione) {
		this.editorePubblicazione = editorePubblicazione;
	}
	public String getCodIsbn() {
		return codIsbn;
	}
	public void setCodIsbn(String codIsbn) {
		this.codIsbn = codIsbn;
	}
	public Date getDataPubblicazione() {
		return dataPubblicazione;
	}
	public void setDataPubblicazione(Date dataPubblicazione) {
		this.dataPubblicazione = dataPubblicazione;
	}
	public String getDataPubblicazioneStringa() {
		return dataPubblicazioneStringa;
	}
	public void setDataPubblicazioneStringa(String dataPubblicazioneStringa) {
		this.dataPubblicazioneStringa = dataPubblicazioneStringa;
	}
	
	
}
