package com.accenture.CCFarm.Bean;

import java.util.Date;

public class AltroTitolo {

	private String idAltroTitolo;
	private String descAltroTitolo;
	private String   durataAltroTitolo;
	private String rilascioAltroTitolo;
	private Date dataRilascioAltroTitolo;
	private String dataRilascioAltroTitoloStringa;
	private String esameFinaleAltroTitolo;
	private String noteAltroTitolo;
	private String flagEsteroAltroTitolo;
	
	public String getDescAltroTitolo() {
		return descAltroTitolo;
	}
	public String getIdAltroTitolo() {
		return idAltroTitolo;
	}
	public void setIdAltroTitolo(String idAltroTitolo) {
		this.idAltroTitolo = idAltroTitolo;
	}
	public void setDescAltroTitolo(String descAltroTitolo) {
		this.descAltroTitolo = descAltroTitolo;
	}
	public String getRilascioAltroTitolo() {
		return rilascioAltroTitolo;
	}
	public String getDurataAltroTitolo() {
		return durataAltroTitolo;
	}
	public void setDurataAltroTitolo(String durataAltroTitolo) {
		this.durataAltroTitolo = durataAltroTitolo;
	}
	public void setRilascioAltroTitolo(String rilascioAltroTitolo) {
		this.rilascioAltroTitolo = rilascioAltroTitolo;
	}
	public Date getDataRilascioAltroTitolo() {
		return dataRilascioAltroTitolo;
	}
	public void setDataRilascioAltroTitolo(Date dataRilascioAltroTitolo) {
		this.dataRilascioAltroTitolo = dataRilascioAltroTitolo;
	}
	public String getEsameFinaleAltroTitolo() {
		return esameFinaleAltroTitolo;
	}
	public void setEsameFinaleAltroTitolo(String esameFinaleAltroTitolo) {
		this.esameFinaleAltroTitolo = esameFinaleAltroTitolo;
	}
	public String getNoteAltroTitolo() {
		return noteAltroTitolo;
	}
	public void setNoteAltroTitolo(String noteAltroTitolo) {
		this.noteAltroTitolo = noteAltroTitolo;
	}
	public String getFlagEsteroAltroTitolo() {
		return flagEsteroAltroTitolo;
	}
	public void setFlagEsteroAltroTitolo(String flagEsteroAltroTitolo) {
		this.flagEsteroAltroTitolo = flagEsteroAltroTitolo;
	}
	public String getDataRilascioAltroTitoloStringa() {
		return dataRilascioAltroTitoloStringa;
	}
	public void setDataRilascioAltroTitoloStringa(
			String dataRilascioAltroTitoloStringa) {
		this.dataRilascioAltroTitoloStringa = dataRilascioAltroTitoloStringa;
	}
	
	
}
