package com.accenture.CCFarm.Bean;


import java.lang.reflect.Field;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.accenture.CCFarm.Annotation.CustomBeanAnnotation;
import com.accenture.CCFarm.Errors.Errore;
import com.accenture.CCFarm.Errors.ErroriModulo;
import com.accenture.CCFarm.Exception.BeanException;

@XmlAccessorType(XmlAccessType.NONE)
public abstract class AbstractBeanUtil
{
    protected ErroriModulo errori = new ErroriModulo();
    protected boolean readOnly = false; 
    
    public boolean isReadOnly()
    {
        return readOnly;
    }

    public void setReadOnly(boolean readOnly)
    {
        this.readOnly = readOnly;
    }

    public boolean hasErrors() throws BeanException
    {	
	if(errori!=null)
	{
	    return errori.hasError();
	}
	else return false;
    }
    
    public Errore nextError()
    {
	return errori.nextError();
    }
    
    public boolean getError(String campo)
    {
	if (errori!=null)
	    return errori.getErrore(campo)!=null;
	else return false;
    }

    
    public String getValoreCampo(String campo) throws BeanException
    {
	String retVal = "";
	try
	{
	    Field field = this.getClass().getDeclaredField(campo);
	    retVal = (String)field.get(this);
	}
	catch (SecurityException e)
	{
	    throw new BeanException("ERRORE NELL'ACCESSO AL CAMPO: "+campo+" "+this.getClass(),e);
	}
	catch (NoSuchFieldException e)
	{
	    throw new BeanException("CAMPO NON PRESENTE: "+campo+" "+this.getClass(),e);
	}
	catch (IllegalArgumentException e)
	{
	    throw new BeanException("CAMPO NON ACCESSIBILE CON ANRGOMETO STRINGA: "+campo+" "+this.getClass(),e);
	}
	catch (IllegalAccessException e)
	{
	    throw new BeanException("CAMPO NON ACCESSIBILE (E' PRIVATE?): "+campo+" "+this.getClass(),e);
	}
	return retVal;	
	
    }
    
 
    public String getEtichetta(String nomeCampo)
    {
	String retVal = null;
	try
	{
	    Field campo = this.getClass().getDeclaredField(nomeCampo);
	    if (campo!=null)
	    {
		CustomBeanAnnotation annotation = campo.getAnnotation(CustomBeanAnnotation.class);
		if (annotation!=null)
			retVal=annotation.ETICHETTA();
	        if (retVal==null) retVal = campo.getName()+"(impostare etichetta su annotation)";
	    }
	}
	catch (SecurityException e)
	{
	    // TODO Auto-generated catch block
	    retVal = "-- campo privato non accessibile nella classe --";
	}
	catch (NoSuchFieldException e)
	{
	    // TODO Auto-generated catch block
	    retVal = "-- campo non disponibile nella classe --";
	}
	return retVal;	   
    }
    
    public String printErrors() throws BeanException  
    {
	StringBuffer sbErrori = new StringBuffer("");
	if (errori!= null && errori.hasError())
	{
	    String etichetta = "";
	    Errore errore = null;
	    
	    sbErrori.append("<a name=\"ERRORI\" id=\"ERRORI\"></a>");
	    sbErrori.append("<div class=\"box_titolo\">Errori riscontrati nella compilazione</div>");
	    sbErrori.append("<div class=\"box_privato_border_errori box_privato_padding_sottomodulo\"  ><ul>");
	    while (errori.hasError())
	    {
		errore = errori.nextError();		
		Field campo=null;
		try
		{
		    campo = this.getClass().getDeclaredField(errore.getNomeCampo());
		}
		catch (SecurityException e)
		{
		    throw new BeanException("ERRORE NELL'ACCESSO AL CAMPO: "+errore.getNomeCampo()+" "+this.getClass(),e);
		}
		catch (NoSuchFieldException e)
		{
		    etichetta ="NO_CORR";
		}
		if (!etichetta.equals("NO_CORR"))
		{
		    etichetta = campo.getAnnotation(CustomBeanAnnotation.class).ETICHETTA();
		    if (etichetta.endsWith("*"))
			etichetta = etichetta.substring(0,etichetta.length()-1);
		}
		else
		{
		    etichetta = errore.getNomeCampo();
		}
		sbErrori.append("<li><b>" + etichetta + ":</b> " + errore.getMessaggio() + "<br/></li>");
	    }
	    sbErrori.append("</ul></div>");
	    sbErrori.append("<div style=\"height: 20px;\"></div>");
	}	
	
	return sbErrori.toString();
    }
    
    public boolean isRequired(String campo) throws BeanException
    {
	boolean retVal = false;
	try
	{
	    Field field = this.getClass().getDeclaredField(campo);
	    CustomBeanAnnotation annotation = field.getAnnotation(CustomBeanAnnotation.class);
	    if (annotation.REQUIRED())
		retVal = true;
	}
	catch (NoSuchFieldException e)
	{
	    throw new BeanException("CAMPO NON PRESENTE: "+campo+" "+this.getClass(),e);
	}
	return retVal;
    }

    public ErroriModulo getErrori()
    {
        return errori;
    }

    public void setErrori(ErroriModulo errori)
    {
        this.errori = errori;
    }
  
}
