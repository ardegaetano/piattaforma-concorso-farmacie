package com.accenture.CCFarm.utility;

public class HelpDe {

	//**************************************************************************************************************************
	//HELP REGISTRAZIONE *******************************************************************************************************
	//**************************************************************************************************************************
	
	public static String[] caricaHelpDatiRegistrazione() {
		
		//Help pagina Dati Registrazione
		String[] helpReg = new String[33];

		//Modalit� di partecipazione
		helpReg[0] = "Typ der Bewerbung (individuell oder gemeinschaftlich)";
		//Cognome
		helpReg[1] = "Nachname des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung den Nachnamen des Referenten angeben.";
		//Nome
		helpReg[2] = "Name des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung den Namen des Referenten angeben.";
		//Data di nascita
		helpReg[3] = "Geburtsdatum des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung das Geburtsdatum des Referenten angeben (tt/mm/jjjj) .";
		//Nazionalit� di nascita
		helpReg[4] = "Geburtsstaat des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung das Geburtsstaat des Referenten angeben.";
		//Localita' estera di nascita
		helpReg[5] = "Ausl�ndischer Geburtsort des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung den ausl�ndischen Geburtsort des Referenten angeben.";
		//Provincia di nascita
		helpReg[6] = "Ausl�ndischer Provinz  des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung den ausl�ndischen Geburtsort des Referenten angeben.";
		//Comune di nascita
		helpReg[7] = "Geburtsgemeinde des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung die Geburtsgemeinde des Referenten angeben.";
		//Sesso
		helpReg[8] = "Geschlecht des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung das Geschlecht des Referenten angeben.";
		//Codice fiscale
		helpReg[9] = "Steuernummer des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung die Steuernummer des Referenten angeben.";
		//Indirizzo PEC
		helpReg[10] = "PEC-Adresse des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung die PEC-Adresse des Referenten angeben. Die angegebene Adresse wird f�r alle Meldungen betreffend die Ausschreibung verwendet.";
		
		//Conferma Indirizzo PEC
		helpReg[32] = "PEC-Adresse zur Best�tigung erneut eingeben.";
		
		//Tipo documento
		helpReg[11] = "Typ des Ausweisdokuments des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung den Typ des Ausweisdokuments des Referenten angeben. ACHTUNG: Der Ausweis muss zum Zeitpunkt der Einsendung der Bewerbung g�ltig sein.";
		//Numero
		helpReg[12] = "Nummer des Ausweisdokuments des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung die Nummer des Ausweisdokuments des Referenten angeben";
		//Ente di rilascio
		helpReg[13] = "K�rperschaft, die das Ausweisdokument des Bewerbers ausgestellt hat. Im Falle einer gemeinschaftlichen Bewerbung jene K�rperschaft angeben, die das Ausweisdokument des Referenten ausgestellt hat.";
		//Data di rilascio
		helpReg[14] = "Ausstellungsdatum des Ausweisdokuments des Bewerbers. Im Falle einer gemeinschaftlichen Bewerbung das Ausstellungsdatum des Ausweisdokuments des Referenten angeben (tt/mm/jjjj).";
		//Accettazione condizioni
		helpReg[15] = "Zustimmung des Benutzers betreffend die Bereitstellung der Account-Informationen f�r die Online-Registrierung";
		//DATI ASSOCIATO
		//Cognome
		helpReg[16] = "Nachname des Bewerbers";
		//Nome
		helpReg[17] = "Name des Bewerbers";
		//Data di nascita
		helpReg[18] = "Geburtsdatum des Bewerbers (tt/mm/jjjj)";
		//Nazionalit� di nascita
		helpReg[19] = "Geburtsstaat des Bewerbers";
		//Localita' estera di nascita
		helpReg[20] = "Ausl�ndischer Geburtsort des Bewerbers";
		//Provincia di nascita
		helpReg[21] = "Geburtsprovinz des Bewerbers";
		//Comune di nascita
		helpReg[22] = "Geburtsgemeinde des Bewerbers";
		//Sesso
		helpReg[23] = "Geschlecht des Bewerbers";
		//Codice fiscale
		helpReg[24] = "Steuernummer des Bewerbers";
		//Indirizzo PEC
		helpReg[25] = "PEC-Adresse des Bewerbers.  Die angegebene Adresse wird f�r alle Meldungen betreffend die Ausschreibung verwendet.";
		
		//Tipo documento
		helpReg[26] = "Typ des Ausweisdokuments des Bewerbers (Personalausweis oder Reisepass)";
		//Numero
		helpReg[27] = "Nummer des Ausweisdokuments des Bewerbers";
		//Ente di rilascio
		helpReg[28] = "K�rperschaft, die das Ausweisdokument des Bewerbers ausgestellt hat";
		//Data di rilascio
		helpReg[29] = "Ausstellungsdatum des Ausweisdokuments des Bewerbers (tt/mm/jjjj)";
		//Flag Codice Fiscale Italiano
		helpReg[30] = "Verf�gt der Bewerber �ber eine italienische Steuernummer? Im Falle einer gemeinschaftlichen Bewerbung angeben, ob der Referent im Besitz einer italienischen Steuernummer ist.";
		//Flag Codice Fiscale Italiano Associato
		helpReg[31] = "Verf�gt der gemeinschaftliche Bewerber �ber eine italienische Steuernummer?";
						
		return helpReg;
	}
	
	//**************************************************************************************************************************
	//HELP DOMANDA *************************************************************************************************************
	//**************************************************************************************************************************
	public static String[] caricaHelpDatiCandidato() {
		
		//Help requisiti minimi
		//DATI ANAGRAFICI
		String[] helpCand = new String[47];
		//Cognome Candidato
		helpCand[0] = "Bei der Anmeldung angegebener Nachname des Bewerbers";
		//Nome Candidato
		helpCand[1] = "Bei der Anmeldung angegebener Name des Bewerbers";
		//Data di nascita Candidato
		helpCand[2] = "Bei der Anmeldung angegebenes Geburtsdatum des Bewerbers (tt/mm/jjjj)";
		//Nazionalit� di nascita Candidato
		helpCand[3] = "Bei der Anmeldung angegebener Geburtsstaat des Bewerbers";
		//Localita' estera di nascita Candidato
		helpCand[4] = "Bei der Anmeldung angegebener ausl�ndischer Geburtsort des Bewerbers";
		//Provincia Nascita Candidato
		helpCand[5] = "Bei der Anmeldung angegebene Geburtsprovinz des Bewerbers";
		//Comune Nascita Candidato
		helpCand[6] = "Bei der Anmeldung angegebene Geburtsgemeinde des Bewerbers";
		//Codice fiscale Candidato
		helpCand[7] = "Bei der Anmeldung angegebene Steuernummer des Bewerbers";
		//Estremi documento d'identita' Candidato
		helpCand[8] = "Bei der Anmeldung angegebene Daten des Ausweisdokuments des Bewerbers";
		//DATI RESIDENZA
		helpCand[9] = "Wohnsitzadresse des Bewerbers. Ist keine Hausnummer vorhanden, das Akronym �SNC� eingeben.";
		
		helpCand[10] = "Wohnsitzprovinz des Ausweisdokuments des Bewerbers";
		helpCand[11] = "Wohnsitzgemeinde des Ausweisdokuments des Bewerbers";
		helpCand[12] = "PLZ oder ZIP-CODE des Wohnortes des Bewerbers";
		helpCand[13] = "Haupttelefonnummer des Bewerbers";
		helpCand[14] = "Zweite Telefonnummer des Bewerbers";
		helpCand[15] = "Bei der Anmeldung angegebene PEC-Adresse des Bewerbers. Es darf ausschlie�lich eine Zertifizierte E-Mail-Adresse (PEC) angegeben werden. Laut Art. 5 der Wettbewerbsausschreibung ist die Bewerbung bei Angabe einer nicht-zertifizierten E-Mail-Adresse im Sinne des DPR 445/2000 unzul�ssig.";
		//FATTISPECIE DI APPARTENENZA
		helpCand[16] = "Daten zur Inhaberkategorie des Bewerbers laut Art. 2 der Ausschreibung";
		//CITTADINANZA E DIRITTI CIVILI E POLITICI
		helpCand[17] = "Staatsb�rgerschaft des Bewerbers";
		helpCand[18] = "Provinz der W�hlerliste des Bewerbers";
		helpCand[19] = "Gemeinde der W�hlerliste des Bewerbers";
		helpCand[20] = "B�rgerliche/politische Rechte des Bewerbers";
		//ISCRIZIONE ALL'ALBO PROFESSIONALE
		helpCand[21] = "Ist der Bewerber in das Berufsverzeichnis der Apotheker eingetragen?"; 
		helpCand[22] = "Provinz der Ersteintragung in das Berufsverzeichnis der Apotheker. Bei Mehrfacheintragungen im Laufe der Jahre die chronologisch erste Eintragung angeben.";
		
		//** voce provvisoria **
		helpCand[46] = "Provinz, in welcher der Bewerber derzeit in das Berufsverzeichnis der Apotheker eingetragen ist.";
		
		helpCand[23] = "Datum der Ersteintragung in das Berufsverzeichnis der Apotheker. Bei Mehrfacheintragungen im Laufe der Jahre die chronologisch erste Eintragung angeben(tt/mm/jjjj) .";  
		helpCand[24] = "Nummer der Ersteintragung in das Berufsverzeichnis der Apotheker. Bei Mehrfacheintragungen im Laufe der Jahre die chronologisch erste Eintragung angeben.";
		//BOLZANO
		helpCand[25] = "Erkl�rung �ber die Beherrschung der f�r die Teilnahme an  der Ausschreibung anerkannten Sprachen";
		helpCand[26] = "";
		//LAUREA PRINCIPALE
		helpCand[27] = "IF�r die Bewerbung als Hauptdiplom gew�hlter Universit�tsabschluss";
		helpCand[28] = "Universit�t, an welcher der f�r die Bewerbung als Hauptdiplom gew�hlte Universit�tsabschluss erlangt wurde";
		helpCand[29] = "Ort, an welchem der f�r die Bewerbung als Hauptdiplom gew�hlte Universit�tsabschluss erlangt wurde";
		helpCand[30] = "Datum, an welchem der f�r die Bewerbung als Hauptdiplom gew�hlte Universit�tsabschluss erlangt wurde (tt/mm/jjjj)";
		helpCand[31] = "Abschlussnote des f�r die Bewerbung als Hauptdiplom gew�hlten Universit�tsabschlusses. Falls im Ausland erlangt, gleichwertige Abschlussnote angeben. Als Grundlage gilt die Punktezahl 110";
		helpCand[32] = "M�gliche Punktezahl f�r die Abschlussnote des f�r die Bewerbung als Hauptdiplom gew�hlten Universit�tsabschlusses";
		helpCand[33] = "Auszeichnung des f�r die Bewerbung als Hauptdiplom gew�hlten Universit�tsabschlusses";
		//ABILITAZIONE
		helpCand[34] = "Universit�t, an welcher die Bef�higung zum Apothekerberuf erlangt wurde";
		helpCand[35] = "Ort, an dem die Bef�higung zum Apothekerberuf erlangt wurde";
		helpCand[36] = "Jahr, in dem die Bef�higung zum Apothekerberuf erlangt wurde";
		helpCand[37] = "Abschlussnote der Bef�higung f�r den Apothekerberuf";
		helpCand[38] = "M�gliche Punktezahl f�r die Bef�higung f�r den Apothekerberuf";
		helpCand[39] = "Staat, in dem die Bef�higung zum Apothekerberuf erlangt wurde";
		helpCand[40] = "Daten der Anerkennung f�r im Ausland erlangte Bef�higungen";
		helpCand[41] = "Der Bewerber erkl�rt in �bereinstimmung mit Art. 2 der Ausschreibung, nie strafrechtlich verurteilt worden zu sein, und dass daher im Sinne der geltenden Bestimmungen keine Hinderungs- oder Ausschlussgr�nde f�r die Aus�bung des Apothekerberufs vorliegen";
		helpCand[42] = "Der Bewerber erkl�rt in �bereinstimmung mit Art. 2 der Ausschreibung, die Apotheke in den letzten zehn Jahren nicht abgetreten zu haben (auch ausf�llen, falls der Bewerber nie Inhaber einer Apotheke war)";
		helpCand[43] = "Der Bewerber erkl�rt in �bereinstimmung mit Art. 2 der Ausschreibung, an nicht mehr als zwei au�erordentlichen Wettbewerben teilzunehmen";
		helpCand[44] = "Wohnsitzstaat des Bewerbers";
		helpCand[45] = "Ausl�ndischer Wohnort des Bewerbers";
		
		return helpCand;
	}
	
	public static String[] caricaHelpTitoliDiStudio() {
		String[] helpTit = new String[66];
		//Seconda Laurea Farmacia
		helpTit[0]="Zweites Universit�tsdiplom in Pharmazie oder CPT";
		helpTit[1]="Universit�t, an der das zweite Universit�tsdiplom in Pharmazie oder CPT erlangt wurde";
		helpTit[2]="Ort, an dem das zweite Universit�tsdiplom in Pharmazie oder CPT erlangt wurde";
		helpTit[3]="Datum, an dem das zweite Universit�tsdiplom in Pharmazie oder CPT erlangt wurde";
		helpTit[4]="Land, in dem das zweite Universit�tsdiplom in Pharmazie oder CPT erlangt wurde";
		helpTit[5]="Wurde das zweite Universit�tsdiplom in Pharmazie oder CPT an einer �ffentlichen oder an einer privaten Einrichtung erlangt?";
		//Seconda Laurea 
		helpTit[6]="Typ des zweiten Diploms (aus dem Dropdown-Men� w�hlen)";
		helpTit[7]="Universit�t, an der das zweite Universit�tsdiplom erlangt wurde";
		helpTit[8]="Ort, an dem das zweite Universit�tsdiplom erlangt wurde";
		helpTit[9]="Datum, an dem das zweite Universit�tsdiplom erlangt wurde";
		helpTit[10]="Staat, in dem das zweite Universit�tsdiplom erlangt wurde";
		helpTit[11]="Wurde das zweite Universit�tsdiplom an einer �ffentlichen oder an einer privaten Einrichtung erlangt?";
		//Altra laurea
		helpTit[12]="Typ des zus�tzlichen Diploms";
		helpTit[13]="Universit�t, an der das zus�tzliche Universit�tsdiplom erlangt wurde";
		helpTit[14]="Ort, an dem das zus�tzliche Universit�tsdiplom erlangt wurde";
		helpTit[15]="Datum, an dem das zus�tzliche Universit�tsdiplom erlangt wurde";
		helpTit[16]="Staat, in dem das zus�tzliche Universit�tsdiplom erlangt wurde";
		helpTit[17]="Wurde das zus�tzliche Universit�tsdiplom an einer �ffentlichen oder an einer privaten Einrichtung erlangt?";
		//Specializzazioni
		helpTit[18]="Bezeichnung der Fachausbildung";
		helpTit[19]="Fakult�t, an der die Fachausbildung abgeschlossen wurde";
		helpTit[20]="Universit�t, an der die Fachausbildung abgeschlossen wurde";
		helpTit[21]="Ort, an dem die Fachausbildung abgeschlossen wurde";
		helpTit[22]="Staat, in dem die Fachausbildung abgeschlossen wurde";
		helpTit[23]="Dauer der Fachausbildung in Jahren";
		helpTit[24]="Wurde die Fachausbildung an einer �ffentlichen oder an einer privaten Einrichtung abgeschlossen?";
		//Borse di Studio
		helpTit[25]="Bezeichnung des Stipendiums";
		helpTit[26]="Fakult�t, an der das Stipendium erlangt wurde";
		helpTit[27]="Universit�t, an der das Stipendium erlangt wurde";
		helpTit[28]="Ort, an dem das Stipendium erlangt wurde";
		helpTit[29]="Staat, in dem das Stipendium erlangt wurde";
		helpTit[30]="Anlaufdatum des Stipendiums";
		helpTit[31]="Abschlussdatum des Stipendiums";
		helpTit[32]="Wurde das Stipendium an einer �ffentlichen oder an einer privaten Einrichtung erlangt?";
		//Dottorato
		helpTit[33]="Bezeichnung des Doktoratsstudiums in Pharmazie oder CPT";
		helpTit[34]="Fakult�t, an der das Doktorat in Pharmazie oder CPT erlangt wurde";
		helpTit[35]="Universit�t, an der das Doktorat in Pharmazie oder CPT erlangt wurde";
		helpTit[36]="Ort, an dem das Doktorat in Pharmazie oder CPT erlangt wurde";
		helpTit[37]="Staat, in dem das Doktorat in Pharmazie oder CPT erlangt wurde";
		helpTit[38]="Anlaufdatum des Doktoratsstudiums in Pharmazie oder CPT";
		helpTit[39]="Abschlussdatum des Doktoratsstudiums in Pharmazie oder CPT";
		helpTit[40]="Wurde das Doktorat an einer �ffentlichen oder an einer privaten Einrichtung erlangt?";
		//Altri Titoli di Studio
		helpTit[41]="Erlangter Studientitel (Master oder Lehrgang zur Weiterbildung)";
		helpTit[42]="Zeitraum zur Erlangung des Studientitels (z.B.: 1 Jahr)";
		helpTit[43]="Einrichtung, die den Studientitel ausgestellt hat";
		helpTit[44]="Ausstellungsdatum des Studientitels";
		helpTit[45]="Sieht der Studientitel eine Abschlusspr�fung vor?";
		helpTit[46]="Allf�llige Anmerkungen";
		helpTit[47]="Wurde der Studientitel an einer �ffentlichen oder an einer privaten Einrichtung erlangt?";
		//Idoneita'
		helpTit[48]="Wurde die Bef�higung f�r Apothekensitze erlangt?";
		helpTit[49]="Daten der Urkunde f�r die Genehmigung der Rangordnung. K�RPERSCHAFT, GEBIET und NUMMER angeben.";
		helpTit[50]="Datum der Urkunde f�r die Genehmigung der Rangordnung";
		//Idoneita' Nazionale
		helpTit[51]="Daten der staatlichen Bef�higung f�r leitende Apotheker";
		helpTit[52]="Jahr der Erlangung der staatlichen Bef�higung f�r leitende Apotheker";
		//Corsi di Aggiornamento
		helpTit[53]="Bezeichnung des Weiterbildungskurses";
		helpTit[54]="Veranstalter des Weiterbildungskurses";
		helpTit[55]="Beginn des Weiterbildungskurses";
		helpTit[56]="Ende des Weiterbildungskurses";
		helpTit[57]="Gesamtstundenzahl der Weiterbildung";
		helpTit[58]="Wurde die Abschlusspr�fung des Weiterbildungskurses (falls vorgesehen) bestanden?";
		helpTit[59]="Wurde der Weiterbildungskurs an einer �ffentlichen oder an einer privaten Einrichtung besucht?";
		//Pubblicazioni Scientifiche
		helpTit[60]="Art der Publikation";
		helpTit[61]="Autor oder Autoren der Publikation";
		helpTit[62]="Titel der Publikation";
		helpTit[63]="Herausgeber der Publikation";
		helpTit[64]="ISBN oder ISSN der Publikation";
		helpTit[65]="Ver�ffentlichungsdatum der Publikation";
		
		return helpTit;
	}
	
	public static String[] caricaHelpEsercizioProfessionale() {
		String[] helpEs = new String[14];
		helpEs[0] = "Beginn der Berufst�tigkeit. Es d�rfen ausschlie�lich T�tigkeiten eingetragen werden, die vor der Ver�ffentlichung der Ausschreibung abgeschlossen wurden.";
		helpEs[1] = "Ende der Berufst�tigkeit. Bei eint�giger T�tigkeit sind Beginn und Ende gleichlautend. Es d�rfen ausschlie�lich T�tigkeiten eingetragen werden, die vor der Ver�ffentlichung der Ausschreibung abgeschlossen wurden.";
		helpEs[2] = "Art der Berufst�tigkeit: Bis zu 20 Stunden gelten als Teilzeit, mehr als 20 Stunden als Vollzeit.";
		helpEs[3] = "Rolle des Bewerbers im Rahmen der angegebenen Berufst�tigkeit";
		helpEs[4] = "Art der Einrichtung, f�r welche die angegebene Berufst�tigkeit ausge�bt wurde";
		helpEs[5] = "Bezeichnung der Einrichtung, f�r welche die angegebene Berufst�tigkeit ausge�bt wurde";
		helpEs[6] = "Adresse der Einrichtung, f�r welche die angegebene Berufst�tigkeit ausge�bt wurde";
		helpEs[7] = "Sitz (Region bzw. Staat, falls im Ausland) der Einrichtung, f�r welche die Berufst�tigkeit ausge�bt wurde";
		helpEs[8] = "Provinz, in der die Einrichtung, f�r welche die angegebene Berufst�tigkeit ausge�bt wurde, ihren Sitz hat";
		helpEs[9] = "Ort, in dem die Einrichtung, f�r welche die angegebene Berufst�tigkeit ausge�bt wurde, ihren Sitz hat";
		helpEs[10] = "Bezugssanit�tseinheit der Einrichtung, f�r welche die angegebene Berufst�tigkeit ausge�bt wurde";
		helpEs[11] = "Wurde die Berufst�tigkeit bei einer Landapotheke/einem l�ndlichen Handelsbetrieb laut G. 248/2006 ausge�bt? ACHTUNG: Eine Apotheke/ein Handelsbetrieb laut G. 248/2006 sind als l�ndlich anzugeben, falls diese Bezeichnung im betreffenden Zeitraum zutraf.";
		helpEs[12] = "Wurde die Berufst�tigkeit in einer italienischen Gemeinde oder im Ausland ausge�bt?";
		helpEs[13] = "PLZ der Einrichtung, f�r welche die angegebene Berufst�tigkeit ausge�bt wurde";
		return helpEs;
	}
	
	public static String[] caricaHelpDatiVersamento() {
		String[] helpVers = new String[9];
		helpVers[0] = "Datum der Einzahlung der Teilnahmegeb�hr";
		helpVers[1] = "IBAN-Code des f�r die Einzahlung der Teilnahmegeb�hr genutzten Kontokorrents";
		helpVers[2] = "CRO oder sonstige Kennung der Transaktion f�r die Einzahlung der Teilnahmegeb�hr";
		helpVers[3] = "Rolle des Bewerbers im Rahmen der angegebenen Berufst�tigkeit";
		helpVers[4] = "Nummer des Postamtes, in dem die Einzahlung der Teilnahmegeb�hr vorgenommen wurde";
		helpVers[5] = "Fortlaufende Nummer der Transaktion f�r die Einzahlung der Teilnahmegeb�hr";
		helpVers[6] = "Sie verpflichten sich zur Einzahlung der Teilnahmegeb�hr und zur Einsendung der Unterlagen laut Art. 5 der Ausschreibung";
		helpVers[7] = "Liste der einzureichenden Unterlagen laut Art. 5 der Ausschreibung";
		helpVers[8] = "Art der Einzahlung der Teilnahmegeb�hr";
		return helpVers;
	}
	
	//**************************************************************************************************************************
	//HELP RICERCA FARMACIE ****************************************************************************************************
	//**************************************************************************************************************************
	
	public static String[] caricaHelpRicercaFarmacie() {
		String[] helpFarm = new String[6];
		helpFarm[0] = "Region, in der die Suche durchgef�hrt werden soll";
		helpFarm[1] = "Provinz, in der die Suche durchgef�hrt werden soll";
		helpFarm[2] = "Gemeinde, in der die Suche durchgef�hrt werden soll";
		helpFarm[3] = "PLZ, f�r welche die Suche durchgef�hrt werden soll";
		helpFarm[4] = "Adresse, f�r welche die Suche durchgef�hrt werden soll";
		helpFarm[5] = "MwSt.-Nr., f�r welche die Suche durchgef�hrt werden soll";
		
		return helpFarm;
	}
	
}
