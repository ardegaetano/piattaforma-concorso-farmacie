package com.accenture.CCFarm.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.accenture.CCFarm.Bean.Ruolo;
import com.accenture.CCFarm.DAO.ValoriCodice;
import com.accenture.CCFarm.DAO.ValoriCodiceHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;

public class CaricaRuoli {

	private static List<Ruolo> ruoli = new ArrayList<Ruolo>(); 
	private static HashMap<String,String> decodificaRuoli = new HashMap<String,String>(); 
	private static HashMap<String,String> decodificaRuoliDe = new HashMap<String,String>(); 
	
	public static List<Ruolo> getRuoli() throws GestioneErroriException
	{
		Ruolo ruolo = null;
		if(ruoli==null || ruoli.isEmpty())
		{
			ValoriCodiceHome valoriCodiceHome = new ValoriCodiceHome();
		    ValoriCodice valoriCodice = new ValoriCodice();
		    valoriCodice.setTipoCodice("TIPO_RUOLO");
		    List<ValoriCodice> valoriCodiceList = valoriCodiceHome.findByExample(valoriCodice);
			for (int i =0; i<valoriCodiceList.size(); i++){
				valoriCodice = valoriCodiceList.get(i);
				ruolo = new Ruolo();
				ruolo.setCodice(valoriCodice.getIdKey().getCodice());
				ruolo.setDescrizione(valoriCodice.getDescrizione());
				ruolo.setDescrizioneDe(valoriCodice.getDescrizioneDe());
				ruoli.add(ruolo);
				decodificaRuoli.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizione());
				decodificaRuoliDe.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizioneDe());
			}
		}
     return ruoli;
	}
	
	
	
	
	public static String decodificaruolo(String codice)
	{
		String decodifica = null;
		if(ruoli==null || ruoli.isEmpty()){
			try {
				getRuoli();
			} catch (GestioneErroriException e) {
				
				e.printStackTrace();
				return null;
			}
		}
		decodifica = decodificaRuoli.get(codice);
		return decodifica;
	}
	
	public static String decodificaRuolo(String codice, String lingua) throws GestioneErroriException {

		String decodifica = null;
		if (lingua.equals("it")) {
			decodifica = decodificaRuoli.get(codice);
		} else {
			decodifica = decodificaRuoliDe.get(codice);
		}

		return decodifica;
	}
}
