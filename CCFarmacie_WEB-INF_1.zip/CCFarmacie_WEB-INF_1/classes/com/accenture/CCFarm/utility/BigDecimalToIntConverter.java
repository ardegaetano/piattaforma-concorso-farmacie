package com.accenture.CCFarm.utility;

import java.math.BigDecimal;

import org.apache.commons.beanutils.Converter;

public class BigDecimalToIntConverter implements Converter
{
	public Object convert(Class type,Object value)
	{
		if(value!=null && (value instanceof BigDecimal) && (type == Integer.class))
		{
			BigDecimal bigDec = (BigDecimal) value;
	    	Integer  integ =  new Integer(bigDec.intValue());
	    	return (integ);
		}
		return value;
	}
}