package com.accenture.CCFarm.utility;


public class UtenteRegioni {

	private String userId="";
	private String nome="";
	private String cognome="";
	//private String UO="";
	private String UOName="";
	private String codRegione = "";
	private String nomeRegione = "";
	private String profilo = "";
	private boolean isAmm = false;
	//private boolean isMdS = false;
	//private boolean isRegione = false;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getCodRegione() {
		return codRegione;
	}
	public void setCodRegione(String codRegione) {
		this.codRegione = codRegione;
	}
	public String getNomeRegione() {
		return nomeRegione;
	}
	public void setNomeRegione(String nomeRegione) {
		this.nomeRegione = nomeRegione;
	}
	public String getProfilo() {
		return profilo;
	}
	public void setProfilo(String profilo) {
		this.profilo = profilo;
	}
	public String getUOName() {
		return UOName;
	}
	public void setUOName(String uOName) {
		UOName = uOName;
	}
	public boolean isAmm() {
		return isAmm;
	}
	public void setAmm(boolean isAmm) {
		this.isAmm = isAmm;
	}

}
