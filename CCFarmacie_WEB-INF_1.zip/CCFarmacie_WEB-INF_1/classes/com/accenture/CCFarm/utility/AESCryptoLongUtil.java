package com.accenture.CCFarm.utility;

import java.nio.charset.Charset;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class AESCryptoLongUtil {
	
	private static final String algorithm = "AES";
	private static final Charset charset = Charset.forName("UTF-8");
	private static final char[] HEX_CHARS = "0123456789ABCDEF".toCharArray();
	
	public static String encrypt(String textToEncrypt, String key, int keyBits) {
		
		try {
			
			if(key == null || key.trim().isEmpty() || (keyBits % 32 > 0))
				throw new RuntimeException("Chiave di criptazione non valida");
			
			//recupera la rappresentazione in byte della chiave (oppurtunamente tagliata)
			int expectedKeyLength = keyBits / 8;
			byte[] keyBytes = key.getBytes(charset);
			byte[] paddedKeyBytes = new byte[expectedKeyLength];
			System.arraycopy(keyBytes, 0, paddedKeyBytes, 0, Math.min(keyBytes.length, paddedKeyBytes.length));
			
			//genera l'oggetto che rappresenta la chiave necessario all'algoritmo di cifratura
			SecretKey secretKey = new SecretKeySpec(paddedKeyBytes, algorithm);
			
			//converte il testo in esadecimale per garantire la lunghezza a multipli di 16 bytes necessaria per l'algoritmo AES
			String paddedTextToEncrypt = stringToHex(textToEncrypt.getBytes(charset));
			byte[] textToEncryptPaddedBytes = paddedTextToEncrypt.getBytes();
			
		    Cipher cipher = Cipher.getInstance(algorithm);
		    cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			
		    byte[] encryptedTextBytes = cipher.doFinal(textToEncryptPaddedBytes);
			
		    //restituisce una rappresentazione in esadecimale del testo cifrato
		    return stringToHex(encryptedTextBytes);
		}
		catch(Exception e) {
			
			e.printStackTrace();
			return null;
		}
	}
	
	public static String decrypt(String textToDecrypt, String key, int keyBits) {
		
		try {
			
			if(key == null || key.trim().isEmpty() || (keyBits % 32 > 0))
				throw new RuntimeException("Chiave di criptazione non valida");
			
			//recupera la rappresentazione in byte della chiave (oppurtunamente tagliata)
			int expectedKeyLength = keyBits / 8;
			byte[] keyBytes = key.getBytes(charset);
			byte[] paddedKeyBytes = new byte[expectedKeyLength];
			System.arraycopy(keyBytes, 0, paddedKeyBytes, 0, Math.min(keyBytes.length, paddedKeyBytes.length));
			
			//genera l'oggetto che rappresenta la chiave necessario all'algoritmo di cifratura
			SecretKey secretKey = new SecretKeySpec(paddedKeyBytes, algorithm);
			
			//recupera la rappresentazione in byte della stringa esadecimale cifrata
			byte[] textToDecryptBytes = hexToBytes(textToDecrypt.toCharArray());
			
			Cipher cipherDec = Cipher.getInstance(algorithm);
			cipherDec.init(Cipher.DECRYPT_MODE, secretKey);
			
			byte[] decryptedTextBytes = cipherDec.doFinal(textToDecryptBytes);
			
			//restituisce la stringa decifrata (nella codifica originaria) a partire dalla sua rappresentazione esadecimale
			return new String(hexToBytes(new String(decryptedTextBytes).toCharArray()), charset);
		}
		catch(Exception e) {
			
			e.printStackTrace();
			return null;
		}
	}
	
	private static String stringToHex(byte[] stringBytes) {
		
		char[] chars = new char[2 * stringBytes.length];
	    for(int i = 0; i < stringBytes.length; ++i) {
	    	
	        chars[2 * i] 	 = HEX_CHARS[(stringBytes[i] & 0xF0) >>> 4];
	        chars[2 * i + 1] = HEX_CHARS[ stringBytes[i] & 0x0F];
	    }
	    return new String(chars);
	}
	
	public static byte[] hexToBytes(char[] hexChars) {
		
		int length = hexChars.length / 2;
		byte[] raw = new byte[length];
		
		for(int i = 0; i < length; i++) {
			
			int high = Character.digit(hexChars[i * 2], 16);
			int low  = Character.digit(hexChars[i * 2 + 1], 16);
			int value = (high << 4) | low;
			
			if(value > 127)
				value -= 256;
			
			raw[i] = (byte) value;
		}
		return raw;
	}
	
}


