package com.accenture.CCFarm.utility;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class ValidateCF {
	
	
	public static boolean validaCF(String cf) {
		int start = 0 ;
		boolean check = false;
		cf = cf.trim();
		if(cf.length() >= 16){
			while(!check && cf.length() >= start+16){
				check = checkCF(cf.substring(start,start+16));
				start++;
			}
		}
		
		return check;
	}
		
	private static boolean checkCF(String cf){
		// Regular Expression per controllare la correttezza sintattica del CF */
		String regex = "[a-zA-Z]{6}[0-9]{2}[a-zA-Z][0-9]{2}[a-zA-Z][0-9]{3}[a-zA-Z]";
		int somma = 0;
		// Creazione HashMap per associazione chiave-valore per i caratteri dispari
		Map<String, String> chrDispari = new HashMap<String, String>();
		chrDispari.put("0", "1");
		chrDispari.put("1", "0");
		chrDispari.put("2", "5");
		chrDispari.put("3", "7");
		chrDispari.put("4", "9");
		chrDispari.put("5", "13");
		chrDispari.put("6", "15");
		chrDispari.put("7", "17");
		chrDispari.put("8", "19");
		chrDispari.put("9", "21");
		chrDispari.put("A", "1");
		chrDispari.put("B", "0");
		chrDispari.put("C", "5");
		chrDispari.put("D", "7");
		chrDispari.put("E", "9");
		chrDispari.put("F", "13");
		chrDispari.put("G", "15");
		chrDispari.put("H", "17");
		chrDispari.put("I", "19");
		chrDispari.put("J", "21");
		chrDispari.put("K", "2");
		chrDispari.put("L", "4");
		chrDispari.put("M", "18");
		chrDispari.put("N", "20");
		chrDispari.put("O", "11");
		chrDispari.put("P", "3");
		chrDispari.put("Q", "6");
		chrDispari.put("R", "8");
		chrDispari.put("S", "12");
		chrDispari.put("T", "14");
		chrDispari.put("U", "16");
		chrDispari.put("V", "10");
		chrDispari.put("W", "22");
		chrDispari.put("X", "25");
		chrDispari.put("Y", "24");
		chrDispari.put("Z", "23");
	
		// Creazione HashMap per associazione chiave-valore per i caratteri pari		
		Map<String, String> chrPari = new HashMap<String, String>();
		chrPari.put("0", "0");
		chrPari.put("1", "1");
		chrPari.put("2", "2");
		chrPari.put("3", "3");
		chrPari.put("4", "4");
		chrPari.put("5", "5");
		chrPari.put("6", "6");
		chrPari.put("7", "7");
		chrPari.put("8", "8");
		chrPari.put("9", "9");
		chrPari.put("A", "0");
		chrPari.put("B", "1");
		chrPari.put("C", "2");
		chrPari.put("D", "3");
		chrPari.put("E", "4");
		chrPari.put("F", "5");
		chrPari.put("G", "6");
		chrPari.put("H", "7");
		chrPari.put("I", "8");
		chrPari.put("J", "9");
		chrPari.put("K", "10");
		chrPari.put("L", "11");
		chrPari.put("M", "12");
		chrPari.put("N", "13");
		chrPari.put("O", "14");
		chrPari.put("P", "15");
		chrPari.put("Q", "16");
		chrPari.put("R", "17");
		chrPari.put("S", "18");
		chrPari.put("T", "19");
		chrPari.put("U", "20");
		chrPari.put("V", "21");
		chrPari.put("W", "22");
		chrPari.put("X", "23");
		chrPari.put("Y", "24");
		chrPari.put("Z", "25");
	
		// Creazione HashMap per associazione chiave-valore per il CARATTERE DI CONTROLLO
		Map<String, String> chrControllo = new HashMap<String, String>();
		chrControllo.put("0", "A");
		chrControllo.put("1", "B");
		chrControllo.put("2", "C");
		chrControllo.put("3", "D");
		chrControllo.put("4", "E");
		chrControllo.put("5", "F");
		chrControllo.put("6", "G");
		chrControllo.put("7", "H");
		chrControllo.put("8", "I");
		chrControllo.put("9", "J");
		chrControllo.put("10", "K");
		chrControllo.put("11", "L");
		chrControllo.put("12", "M");
		chrControllo.put("13", "N");
		chrControllo.put("14", "O");
		chrControllo.put("15", "P");
		chrControllo.put("16", "Q");
		chrControllo.put("17", "R");
		chrControllo.put("18", "S");
		chrControllo.put("19", "T");
		chrControllo.put("20", "U");
		chrControllo.put("21", "V");
		chrControllo.put("22", "W");
		chrControllo.put("23", "X");
		chrControllo.put("24", "Y");
		chrControllo.put("25", "Z");
		try{
			cf = cf.toUpperCase();
			// Effettua la somma di tutti i valori ricavati da ogni singolo carattere del CF.
			for(int i=0; i<15; i++) {
				if (i % 2 == 1)
				{
					somma += Integer.parseInt((String)
	                chrPari.get(Character.toString(cf.charAt(i))));
				}
				else
				{
					somma += Integer.parseInt((String)
	                chrDispari.get(Character.toString(cf.charAt(i))));
				}
			}
			// Calcolo l'esatto carattere di controllo in base al codice fiscale fornito dall'utente
			String strControlloCalcolato = (String)chrControllo.get(""+somma%26);
			Character chrControlloCalcolato = strControlloCalcolato.charAt(0);
		
			// Ricavo il carattere di controllo fornito dall'utente 
			Character chrControlloInserito = cf.charAt(15);
		
		
			if (!Pattern.matches(regex, cf) || !chrControlloInserito.equals(chrControlloCalcolato) )
			     return false;
			else
				return true;
		}
		catch (Exception e) {
			return false;
		}
	}

}
