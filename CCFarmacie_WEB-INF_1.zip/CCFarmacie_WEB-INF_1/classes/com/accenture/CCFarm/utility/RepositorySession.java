package com.accenture.CCFarm.utility;


public class RepositorySession {

	public final static String ID_REGIONE = "ID_REGIONE"; 
	public final static String DATI_BANDO  = "DATI_BANDO"; 
	public final static String REGIONI_DATI_BANDO = "REGIONI_DATI_BANDO"; 
	
	// STATO_BANDO_REGIONE  = G = grigio
//							  V = verde
//						      Y = giallo
//						      R = rosso
	public final static String STATO_BANDO_REGIONE = "STATO_BANDO_REGIONE"; 
	public final static String ID_UTENTE = "ID_UTENTE"; 
	public final static String NOME_UTENTE = "NOME_UTENTE"; 
	public final static String COGNOME_UTENTE = "COGNOME_UTENTE"; 
	public final static String MAP_REGIONE = "MAP_REGIONE"; 
	public final static String USER_SESSION = "USER_SESSION"; 
	public final static String PASSWORD_SESSION = "PASSWORD_SESSION"; 
	public final static String UTENTE_NSIS = "USER"; 
	public final static String IDMSG_ERROR_LOGIN = "IDMSG_ERROR_LOGIN"; 
	public final static String RETURN_ERROR_LOGIN = "RETURN_ERROR_LOGIN"; 
	public final static String CANDIDATURA = "CANDIDATURA"; 
	public final static String PRIMO_ACCESSO = "PRIMO_ACCESSO"; 
	public final static String IDMSG_ERROR_GEN = "IDMSG_ERROR_GEN"; 
	public final static String RETURN_ERROR_GEN = "RETURN_ERROR_GEN"; 
	public final static String DESCR_MSG_ERROR_CANDIDATI_NON_REGISTRATI = "MSG_CANDIDATI_NON_REGISTRATI";
	
	public final static String registrazione = "registrazione"; 
	public final static String TIPO_GRAD_PUBB = "TIPO_GRAD_PUBB"; 
	public final static String ULTIMA_GRAD_PUBB_OK = "ULTIMA_GRAD_PUBB_OK"; 
	public final static String TIPO_GRAD_PUBB_OK = "TIPO_GRAD_PUBB_OK"; 
//	public final static String  = ""; 
//	public final static String  = ""; 
//	public final static String  = ""; 
//	public final static String  = ""; 
	public static final String NEW_PEC_EMAIL = "NEW_PEC_EMAIL";
	public static final String LISTA_SEDI = "LISTA_SEDI";
	
	
	
	
	
}
