package com.accenture.CCFarm.utility;



import java.io.IOException;
import java.util.StringTokenizer;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.accenture.CCFarm.DAO.Candidatura;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.LogAccessi;
import com.accenture.CCFarm.DAO.LogAccessiHome;
import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteHome;

/**
 * Servlet implementation class CaricoBandoRegione
 */

public class LogServlet extends HttpServlet {
//	private static final long serialVersionUID = 1L;
	Logger logger = CommonLogger.getLogger("LogServlet");
	   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogServlet() {
        super();
        // 
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// 

		super.init();
		
		String appo = config.getServletContext().getRealPath("");
		 PropertyConfigurator.configure(appo+"\\WEB-INF\\conf\\log4j.properties");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	
		
		String userCandidato = (String) request.getParameter("userid");
		String passwordCandidato = (String) request.getParameter("password");
		
		try {
			boolean pageok = false;
			if (userCandidato!=null && passwordCandidato!=null){
				LogIn logIn= new LogIn();
				LogInHome logInHome =new LogInHome();
				try {
					logIn = logInHome.findById(userCandidato.toUpperCase());
				} catch (Exception e) {
					LogUtil.printException(e);
	//				response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/loginErrore.jsf");
					response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/loginErrore.jsf");
				}
				
				if (logIn!=null){
					Candidatura candidatura = new Candidatura();
					CandidaturaHome candidaturaHome = new CandidaturaHome();
					try {
						candidatura= candidaturaHome.findById(logIn.getIdUtente());
					} catch (Exception e) {
						LogUtil.printException(e);
	//					response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/loginErrore.jsf");
						response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/loginErrore.jsf");
					}
					
					if (candidatura!=null){
					    if (candidatura.getStatoDomanda()!=null&& candidatura.getStatoDomanda().equalsIgnoreCase("A")){
						    pageok=true;
						    logAccessiValidazione(logIn.getIdUtente());
						    Utente utente = new Utente();
						    UtenteHome utenteHome = new UtenteHome();
						    utente= utenteHome.findById(logIn.getIdUtente());
						    if(utente!=null){
						    	request.getSession().setAttribute(RepositorySession.ID_UTENTE, utente.getIdUtente());
						    	request.getSession().setAttribute(RepositorySession.NOME_UTENTE, utente.getNomeUtente());
						    	request.getSession().setAttribute(RepositorySession.COGNOME_UTENTE, utente.getCognomeUtente());
						    }
					    }
					} 
				}
			}
			
			if (pageok){
	//			response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/homeCandidato.jsf");
				response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/homeCandidato.jsf");
			} else{
	//			response.sendRedirect(GenericConstants.SERVER_ABSOLUTE_PATH+"/jsp/loginErrore.jsf");
				response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/loginErrore.jsf");
			}
		}catch (Exception e) {
    		logger.error("LogServlet - doGet: " + e.getMessage());	
 //			JSFUtility.redirect("errorPageGenerica.jsf");
			response.sendRedirect(AppProperties.getAppProperty("BaseUrlCartina")+"/jsp/errorPageGenerica.jsf");
		}
	}

	private void logAccessiValidazione(String  idUtente)throws Exception{
		LogAccessi     logAccessi     = new LogAccessi();
		LogAccessiHome logAccessiHome = new LogAccessiHome();
		logAccessi.setIdLog(logAccessiHome.getSequenceIdLog());
		logAccessi.setIdUtente(idUtente);
		java.util.Date dataSys= new java.util.Date();
//	    java.sql.Timestamp oggi = new java.sql.Timestamp(dataSys.getTime());   
		logAccessi.setLogAccesso(new java.sql.Timestamp(dataSys.getTime()));	
		
		logAccessiHome.saveOrUpdate(logAccessi);
		
	}
}
