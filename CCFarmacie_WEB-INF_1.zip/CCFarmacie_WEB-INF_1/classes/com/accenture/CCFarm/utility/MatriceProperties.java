package com.accenture.CCFarm.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import com.accenture.CCFarm.captcha.CaptchaGenerator;

public class MatriceProperties extends Properties {
	
	private static MatriceProperties matricePropertiesIt = null;
	
	
	private MatriceProperties(){
	
		
		
       URL urlIt = CaptchaGenerator.class.getResource("/resources/matrice_it.properties");
	    
		String basePathIt =urlIt.getPath();
		try{
			
			InputStream isIt = new FileInputStream(urlIt.getPath());
			load(isIt);
		}catch (Exception ex){
				
		}			
		
		
        
	}
	
	public static MatriceProperties getMatricePropertiesIt(){ 
		
		if(matricePropertiesIt != null){
		 return matricePropertiesIt;
		}else{	
			matricePropertiesIt = new MatriceProperties();
			return matricePropertiesIt;
		}	
	}
	
public static String getMatricePropertiesIt(String nomeProp){ 
		
		if(matricePropertiesIt != null){
		 return matricePropertiesIt.getProperty(nomeProp);
		}else{	
			matricePropertiesIt = new MatriceProperties();
			return matricePropertiesIt.getMatricePropertiesIt(nomeProp);
		}	
	}




}
