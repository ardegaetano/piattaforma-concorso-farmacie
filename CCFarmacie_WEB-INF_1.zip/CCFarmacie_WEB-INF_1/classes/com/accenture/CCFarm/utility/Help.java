package com.accenture.CCFarm.utility;

public class Help {

	//**************************************************************************************************************************
	//HELP REGISTRAZIONE *******************************************************************************************************
	//**************************************************************************************************************************
	
	public static String[] caricaHelpDatiRegistrazione() {
		
		//Help pagina Dati Registrazione
		String[] helpReg = new String[33];

		//Modalit� di partecipazione
		helpReg[0] = "Indica la tipologia di partecipazione (singola o associata)";
		//Cognome
		helpReg[1] = "Indica il cognome del candidato. In caso di partecipazione associata, specificare il cognome del referente.";
		//Nome
		helpReg[2] = "Indica il nome del candidato. In caso di partecipazione associata, specificare il nome del referente.";
		//Data di nascita
		helpReg[3] = "Indica la data di nascita del candidato. In caso di partecipazione associata, specificare la data di nascita del referente.";
		//Nazionalit� di nascita
		helpReg[4] = "Indica la nazione di nascita del candidato. In caso di partecipazione associata, specificare la nazione di nascita del referente.";
		//Localita' estera di nascita
		helpReg[5] = "Indica la localita' estera di nascita del candidato. In caso di partecipazione associata, specificare la localita' estera di nascita del referente.";
		//Provincia di nascita
		helpReg[6] = "Indica la provincia di nascita del candidato. In caso di partecipazione associata, specificare la provincia di nascita del referente.";
		//Comune di nascita
		helpReg[7] = "Indica il comune di nascita del candidato. In caso di partecipazione associata, specificare il comune di nascita del referente.";
		//Sesso
		helpReg[8] = "Indica il sesso del candidato. In caso di partecipazione associata, specificare il sesso del referente.";
		//Codice fiscale
		helpReg[9] = "Indica il codice fiscale del candidato. In caso di partecipazione associata, specificare il codice fiscale del referente.";
		//Indirizzo PEC
		helpReg[10] = "Indica l'indirizzo email PEC del candidato. In caso di partecipazione associata, specificare l'indirizzo email del referente. L'indirizzo specificato sar� considerato come riferimento per tutte le comunicazioni relative al concorso.";
		
		//Conferma Indirizzo PEC
		helpReg[32] = "Inserisci nuovamente l'indirizzo PEC, a conferma della sua correttezza.";
		
		//Tipo documento
		helpReg[11] = "Indica il tipo di documento di riconoscimento del candidato. In caso di partecipazione associata, specificare il tipo di documento del referente. ATTENZIONE: Il documento deve essere valido al momento dell'invio della domanda.";
		//Numero
		helpReg[12] = "Indica il numero del documento di riconoscimento del candidato. In caso di partecipazione associata, specificare il numero del documento di riconoscimento del referente.";
		//Ente di rilascio
		helpReg[13] = "Indica l'ente di rilascio del documento di riconoscimento del candidato. In caso di partecipazione associata, specificare l'ente di rilascio del documento di riconoscimento del referente.";
		//Data di rilascio
		helpReg[14] = "Indica la data di rilascio del documento di riconoscimento del candidato. In caso di partecipazione associata, specificare la data di rilascio del documento di riconoscimento del referente.";
		//Accettazione condizioni
		helpReg[15] = "Indica l'accettazione dell'autorizzazione da parte dell'utente del rilascio delle informazioni relative all'account per la registrazione on-line al concorso";
		//DATI ASSOCIATO
		//Cognome
		helpReg[16] = "Indica il cognome dell'associato";
		//Nome
		helpReg[17] = "Indica il nome dell'associato";
		//Data di nascita
		helpReg[18] = "Indica la data di nascita dell'associato";
		//Nazionalit� di nascita
		helpReg[19] = "Indica la nazione' di nascita dell'associato";
		//Localita' estera di nascita
		helpReg[20] = "Indica la localita' estera di nascita dell'associato";
		//Provincia di nascita
		helpReg[21] = "Indica la provincia di nascita dell'associato";
		//Comune di nascita
		helpReg[22] = "Indica il comune di nascita dell'associato";
		//Sesso
		helpReg[23] = "Indica il sesso dell'associato";
		//Codice fiscale
		helpReg[24] = "Indica il codice fiscale dell'associato";
		//Indirizzo PEC
		helpReg[25] = "Indica l'indirizzo email PEC dell'associato. L'indirizzo specificato sar� considerato come riferimento per tutte le comunicazioni relative al concorso.";
		
		//Tipo documento
		helpReg[26] = "Indica il tipo di documento di riconoscimento (carta d'identita' o passaporto) dell'associato";
		//Numero
		helpReg[27] = "Indica il numero del documento di riconoscimento dell'associato";
		//Ente di rilascio
		helpReg[28] = "Indica l'ente di rilascio del documento di riconoscimento dell'associato";
		//Data di rilascio
		helpReg[29] = "Indica la data di rilascio del documento di riconoscimento dell'associato";
		//Flag Codice Fiscale Italiano
		helpReg[30] = "Indica se il candidato e' in possesso di un codice fiscale italiano. In caso di partecipazione associata, specificare se il referente e' in possesso di un codice fiscale italiano.";
		//Flag Codice Fiscale Italiano Associato
		helpReg[31] = "Indica se l'associato e' in possesso di un codice fiscale italiano";
						
		return helpReg;
	}
	
	//**************************************************************************************************************************
	//HELP DOMANDA *************************************************************************************************************
	//**************************************************************************************************************************
	public static String[] caricaHelpDatiCandidato() {
		
		//Help requisiti minimi
		//DATI ANAGRAFICI
		String[] helpCand = new String[47];
		//Cognome Candidato
		helpCand[0] = "Indica il cognome del candidato, specificato in fase di registrazione";
		//Nome Candidato
		helpCand[1] = "Indica il nome del candidato, specificato in fase di registrazione";
		//Data di nascita Candidato
		helpCand[2] = "Indica la data di nascita del candidato, specificato in fase di registrazione";
		//Nazionalit� di nascita Candidato
		helpCand[3] = "Indica la nazionalita' di nascita del candidato, specificato in fase di registrazione";
		//Localita' estera di nascita Candidato
		helpCand[4] = "Indica la localita' estera di nascita del candidato, specificato in fase di registrazione";
		//Provincia Nascita Candidato
		helpCand[5] = "Indica la provincia di nascita del candidato, specificato in fase di registrazione";
		//Comune Nascita Candidato
		helpCand[6] = "Indica il comune di nascita del candidato, specificato in fase di registrazione";
		//Codice fiscale Candidato
		helpCand[7] = "Indica il codice fiscale del candidato, specificato in fase di registrazione";
		//Estremi documento d'identita' Candidato
		helpCand[8] = "Indica gli estremi del documento d'identita' del candidato, specificato in fase di registrazione";
		//DATI RESIDENZA
		helpCand[9] = "Indica l'indirizzo di residenza del candidato, se non � presente numero civico inserire 'snc'";
		
		helpCand[10] = "Indica la provincia di residenza del candidato";
		helpCand[11] = "Indica il comune di residenza del candidato";
		helpCand[12] = "Indica il CAP o lo ZIP/CODE di residenza del candidato";
		helpCand[13] = "Indica il numero di telefono per la reperibilita' del candidato";
		helpCand[14] = "Indica il numero di telefono secondario per la reperibilita' del candidato";
		helpCand[15] = "Indica l'indirizzo email PEC del candidato, specificato in fase di registrazione. Indicare esclusivamente un indirizzo di Posta Elettronica Certificata (PEC). Ai sensi dell�art. 5 del bando di concorso, l�indicazione di un indirizzo di posta elettronica non certificata costituisce elemento di inammissibilit� della domanda ai sensi del DPR 445/2000.";
		//FATTISPECIE DI APPARTENENZA
		helpCand[16] = "Indica la fattispecie di appartenenza del candidato, come da art.2 del bando di concorso";
		//CITTADINANZA E DIRITTI CIVILI E POLITICI
		helpCand[17] = "Indica la cittadinanza del candidato";
		helpCand[18] = "Indica la provincia della lista elettorale del candidato";
		helpCand[19] = "Indica il comune della lista elettorale del candidato";
		helpCand[20] = "Indica il goderimento dei diritti civili/politici del candidato";
		//ISCRIZIONE ALL'ALBO PROFESSIONALE
		helpCand[21] = "Indica se il candidato e' iscritto all'albo dei farmacisti"; 
		helpCand[22] = "Indica la provincia di prima iscrizione all'albo dei farmacisti. In caso di pi� iscrizioni nel corso degli anni, specificare la prima in ordine temporale.";
		
		//** voce provvisoria **
		helpCand[46] = "Indica la provincia presso la quale si � attualmente iscritti all'albo dei farmacisti.";
		
		helpCand[23] = "Indica la data della prima iscrizione all'albo dei farmacisti. In caso di pi� iscrizioni nel corso degli anni, specificare la prima in ordine temporale.";  
		helpCand[24] = "Indica il numero di prima iscrizione all'albo dei farmacisti. In caso di pi� iscrizioni nel corso degli anni, specificare la prima in ordine temporale.";
		//BOLZANO
		helpCand[25] = "Indica la dichiarazione di conoscenza delle lingue riconosciute per la partecipazione al concorso";
		helpCand[26] = "";
		//LAUREA PRINCIPALE
		helpCand[27] = "Indica la tipologia della laurea scelta come principale per la partecipazione al concorso";
		helpCand[28] = "Indica l'universita' di conseguimento della laurea scelta come principale per la partecipazione al concorso";
		helpCand[29] = "Indica il luogo di conseguimento della laurea scelta come principale per la partecipazione al concorso";
		helpCand[30] = "Indica la data di conseguimento della laurea scelta come principale per la partecipazione al concorso";
		helpCand[31] = "Indica il voto di conseguimento della laurea scelta come principale per la partecipazione al concorso.In caso di titolo conseguito all'estero,indicare il voto equivalente in base 110";
		helpCand[32] = "Indica la base di voto di conseguimento della laurea scelta come principale per la partecipazione al concorso";
		helpCand[33] = "Indica la lode della laurea scelta come principale per la partecipazione al concorso";
		//ABILITAZIONE
		helpCand[34] = "Indica l'universita' presso cui � stata conseguita l'abilitazione alla professione di farmacista";
		helpCand[35] = "Indica il luogo di cui � stata conseguita l'abilitazione alla professione di farmacista";
		helpCand[36] = "Indica l'anno in cui � stata conseguita l'abilitazione alla professione di farmacista";
		helpCand[37] = "Indica la votazione di abilitazione alla professione di farmacista";
		helpCand[38] = "Indica la base di votazione di abilitazione alla professione di farmacista";
		helpCand[39] = "Indica la nazione di abilitazione presso cui � stata conseguita l'abilitazione alla professione di farmacista";
		helpCand[40] = "Indica gli estremi del provvedimento di riconoscimento per le abilitazioni coinseguite all'estero";
		helpCand[41] = "Indica che il candidato dichiara di non aver riportato condanne penali definitive che precludano o escludano, ai sensi delle vigenti disposizioni, l'esercizio della professione di farmacista, come da art. 2 del bando di concorso";
		helpCand[42] = "Indica che il candidato dichiara di non aver ceduto la farmacia negli ultimi dieci anni, come da art. 2 del bando di concorso (da valorizzare anche nel caso in cui non si � mai stati titolari di farmacie)";
		helpCand[43] = "Indica che il candidato dichiara di partecipare a non piu' di due concorsi straordinari, come da art. 2 del bando di concorso";
		helpCand[44] = "Indica la nazione di residenza del candidato";
		helpCand[45] = "Indica la localita' estera di residenza del candidato";
		
		return helpCand;
	}
	
	public static String[] caricaHelpTitoliDiStudio() {
		String[] helpTit = new String[66];
		//Seconda Laurea Farmacia
		helpTit[0]="Indica la tipologia della seconda laurea in farmacia o CTF conseguita";
		helpTit[1]="Indica l'universita' in cui � stata conseguita la seconda laurea in farmacia o CTF";
		helpTit[2]="Indica il luogo in cui � stata conseguita la seconda laurea in farmacia o CTF";
		helpTit[3]="Indica la data di conseguimento della seconda laurea in farmacia o CTF";
		helpTit[4]="Indica la nazione in cui � stata conseguita la seconda laurea in farmacia o CTF";
		helpTit[5]="Indica se la seconda laurea in farmacia o CTF e' stata conseguita presso una struttura pubblica o privata";
		//Seconda Laurea 
		helpTit[6]="Indica la tipologia di seconda laurea conseguita (tra quelle indicate nel menu' a tendina)";
		helpTit[7]="Indica l'universita' in cui � stata conseguita la seconda laurea";
		helpTit[8]="Indica il luogo in cui � stata conseguita la seconda laurea";
		helpTit[9]="Indica la data di conseguimento della seconda laurea";
		helpTit[10]="Indica la nazione in cui � stata conseguita la seconda laurea";
		helpTit[11]="Indica se la seconda laurea e' stata conseguita presso una struttura pubblica o privata";
		//Altra laurea
		helpTit[12]="Indica la tipologia di altra laurea conseguita";
		helpTit[13]="Indica l'universita' in cui � stata conseguita l'altra laurea";
		helpTit[14]="Indica il luogo in cui � stata conseguita l'altra laurea";
		helpTit[15]="Indica la data in cui � stata conseguita l'altra laurea";
		helpTit[16]="Indica la nazione in cui � stata conseguita l'altra laurea";
		helpTit[17]="Indica se l'altra laurea e' stata conseguita presso una struttura pubblica o privata";
		//Specializzazioni
		helpTit[18]="Indica la denominazione di specializzazione";
		helpTit[19]="Indica la facolta' in cui � stata conseguita la specializzazione";
		helpTit[20]="Indica l'universita' in cui � stata conseguita la specializzazione";
		helpTit[21]="Indica il luogo in cui � stata conseguita la specializzazione";
		helpTit[22]="Indica la nazione in cui � stata conseguita la specializzazione";
		helpTit[23]="Indica la durata in anni della specializzazione";
		helpTit[24]="Indica se la specializzazione e' stata conseguita presso una struttura pubblica o privata";
		//Borse di Studio
		helpTit[25]="Indica la denominazione della borsa di studio";
		helpTit[26]="Indica la facolta' in cui � stata conseguita la borsa di studio";
		helpTit[27]="Indica l'universita' in cui � stata conseguita la borsa di studio";
		helpTit[28]="Indica il luogo in cui � stata conseguita la borsa di studio";
		helpTit[29]="Indica la nazione in cui � stata conseguita la borsa di studio";
		helpTit[30]="Indica la data di inizio della borsa di studio";
		helpTit[31]="Indica la data di fine della borsa di studio";
		helpTit[32]="Indica se la borsa di studio e' stata conseguita presso una struttura pubblica o privata";
		//Dottorato
		helpTit[33]="Indica la denominazione del dottorato in farmacia o CTF";
		helpTit[34]="Indica la facolta' in cui � stato conseguito il dottorato in farmacia o CTF";
		helpTit[35]="Indica l'universita' in cui � stato conseguito il dottorato in farmacia o CTF";
		helpTit[36]="Indica il luogo in cui � stato conseguito il dottorato in farmacia o CTF";
		helpTit[37]="Indica la nazione in cui � stato conseguito il dottorato in farmacia o CTF";
		helpTit[38]="Indica la data di inizio del dottorato in farmacia o CTF";
		helpTit[39]="Indica la data di fine del dottorato in farmacia o CTF";
		helpTit[40]="Indica se il dottorato in farmacia o CTF e' stato conseguito presso una struttura pubblica o privata";
		//Altri Titoli di Studio
		helpTit[41]="Indica la denominazione del titolo di studio (master o corso di perfezionamento) conseguito";
		helpTit[42]="Indica la durata del titolo di studio (ad esempio: 1 anno)";
		helpTit[43]="Indica l'ente che ha rilasciato il titolo di studio";
		helpTit[44]="Indica la data di rilascio del titolo di studio";
		helpTit[45]="Indica se il titolo di studio prevede un esame finale";
		helpTit[46]="Indica eventuali note";
		helpTit[47]="Indica se il titolo di studio e' stato conseguito presso una struttura pubblica o privata";
		//Idoneita'
		helpTit[48]="Indica se l'idoneita' per sedi farmaceutiche e' stata conseguita";
		helpTit[49]="Indica gli estremi dell'atto del provvedimento di approvazione della graduatoria. Specificare ENTE, AMBITO TERRITORIALE e NUMERO.";
		helpTit[50]="Indica la data dell'atto di provvedimento di approvazione della graduatoria";
		//Idoneita' Nazionale
		helpTit[51]="Indica i riferimenti del provvedimento di idoneita' nazionale per il farmacista dirigente";
		helpTit[52]="Indica l'anno di raggiungimento dell'idoneita' nazionale per il farmacista dirigente";
		//Corsi di Aggiornamento
		helpTit[53]="Indica la denominazione del corso di aggiornamento";
		helpTit[54]="Indica l'organizzatore che ha istituito il corso di aggiornamento";
		helpTit[55]="Indica la data di inizio del corso di aggiornamento";
		helpTit[56]="Indica la data di fine del corso di aggiornamento";
		helpTit[57]="Indica il numero di ore totali del corso di aggiornamento";
		helpTit[58]="Indica il superamento o il non superamento dell'esame del corso di aggiornamento, se previsto";
		helpTit[59]="Indica se il corsi di aggiornamento e' stato conseguito presso una struttura pubblica o privata";
		//Pubblicazioni Scientifiche
		helpTit[60]="Indica la tipologia di pubblicazione";
		helpTit[61]="Indica l'autore o gli autori della pubblicazione";
		helpTit[62]="Indica il titolo della pubblicazione";
		helpTit[63]="Indica l'editore della pubblicazione";
		helpTit[64]="Indica il codice ISBN o ISSN della pubblicazione";
		helpTit[65]="Indica la data di pubblicazione dell'opera";
		
		return helpTit;
	}
	
	public static String[] caricaHelpEsercizioProfessionale() {
		String[] helpEs = new String[14];
		helpEs[0] = "Indica la data inizio dell'esercizio professionale. E' permesso inserire solo esperienze antecedenti la data di pubblicazione del bando.";
		helpEs[1] = "Indica la data fine dell'esercizio professionale. Nel caso di esperienze di un giorno, la data di fine � uguale alla data inizio. E' permesso inserire solo esperienze antecedenti la data di pubblicazione del bando.";
		helpEs[2] = "Indica la modalita' dell'esperienza: fino a 20 ore � da considerarsi tempo parziale, oltre � da considerarsi tempo pieno.";
		helpEs[3] = "Indica il ruolo svolto dal candidato per l'esercizio professionale indicato";
		helpEs[4] = "Indica la tipologia della struttura presso la quale � stata esercitata l'esperienza indicata";
		helpEs[5] = "Indica la denominazione della struttura presso la quale � stata esercitata l'esperienza indicata";
		helpEs[6] = "Indica l'indirizzo della struttura presso la quale � stata esercitata l'esperienza indicata";
		helpEs[7] = "Indica la Regione (o Nazione estera) della struttura presso la quale � stata esercitata l'esperienza indicata";
		helpEs[8] = "Indica la provincia della struttura presso la quale � stata esercitata l'esperienza indicata";
		helpEs[9] = "Indica la localit� della struttura presso la quale � stata esercitata l'esperienza indicata";
		helpEs[10] = "Indica l'asl di appartenenza della struttura presso la quale � stata esercitata l'esperienza indicata";
		helpEs[11] = "Indica se l'esercizio professionale e' stato esercitato presso una farmacia/esercizio commerciale L.248/2006 rurale. ATTENZIONE: la farmacia/esercizio commerciale L.248/2006 � da segnalare come rurale se lo era nel periodo in cui � stata esercitata l'esperienza.";
		helpEs[12] = "Indica se l'esperienza � stata svolta in un comune italiano oppure all'estero";
		helpEs[13] = "Indica il CAP della struttura presso la quale � stata esercitata l'esperienza indicata";
		return helpEs;
	}
	
	public static String[] caricaHelpDatiVersamento() {
		String[] helpVers = new String[9];
		helpVers[0] = "Indica la data in cui e' stato effettuato il versamento per il contributo di partecipazione";
		helpVers[1] = "Indica il codice IBAN dal quale � stato effettuato il versamento per il contributo di partecipazione";
		helpVers[2] = "Indica il CRO o altro identificativo dell'operazione per il versamento per il contributo di partecipazione";
		helpVers[3] = "Indica la data in cui e' stato effettuato il versamento per il contributo di partecipazione";
		helpVers[4] = "Indica il numero dell'ufficio postale in cui e' stato effettuato il versamento per il contributo di partecipazione";
		helpVers[5] = "Indica il progressivo dell'operazione del versamento per il contributo di partecipazione";
		helpVers[6] = "Indica l'impegno ad effettuare il versamento del contributo di partecipazione e ad inviare la documentazione, come da art. 5 del bando di concorso";
		helpVers[7] = "Indica l'elenco dei documenti da inviare, come da art. 5 del bando di concorso";
		helpVers[8] = "Indica la tipologia di versamento del contributo di partecipazione";
		return helpVers;
	}
	
	//**************************************************************************************************************************
	//HELP RICERCA FARMACIE ****************************************************************************************************
	//**************************************************************************************************************************
	
	public static String[] caricaHelpRicercaFarmacie() {
		String[] helpFarm = new String[6];
		helpFarm[0] = "Indica la regione per la quale si vuole effettuare la ricerca";
		helpFarm[1] = "Indica la provincia per la quale si vuole effettuare la ricerca";
		helpFarm[2] = "Indica il comune per il quale si vuole effettuare la ricerca";
		helpFarm[3] = "Indica il CAP per il quale si vuole effettuare la ricerca";
		helpFarm[4] = "Indica l'indirizzo per il quale si vuole effettuare la ricerca";
		helpFarm[5] = "Indica la partita IVA per il quale si vuole effettuare la ricerca";
		
		return helpFarm;
	}
	
}
