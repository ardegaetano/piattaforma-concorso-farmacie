package com.accenture.CCFarm.utility;

import java.io.BufferedReader;
import java.io.Reader;
import java.sql.Clob;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.ResourceBundle;

import com.accenture.CCFarm.Exception.GestioneErroriException;


public class StringUtil 
{
	private static SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
	
	
	//cerca il nome che pi� si "avvicina" a quello inserito
	public static String trovaSuggerimento(String name,List<String> existingNames)
	{
		if(name==null || existingNames==null)
			return name;
		
		try
		{
			name=name.toUpperCase();
			String closerMatch=null;
			int distance=0;
			int minDistance=Integer.MAX_VALUE;
			for(String currentName : existingNames)
			{
				distance=StringUtil.levenshtein_distance(name,currentName);
				
				if(distance<minDistance)
				{
					minDistance=distance;
					closerMatch=currentName;
				}
			}
			
			return closerMatch;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	//restituisce una "misura" della similitudine tra 2 stringhe
	public static int levenshtein_distance(String x,String y)
	{
	    int m=x.length();
	    int n=y.length();
	 
	    int i,j;
	    
	    int distance;
	    
	    int d[][]=new int[m+1][n+1];
	    
	    for(i=0;i<=m;i++)
	        d[i][0]=i;
	 
	    for(j=1;j<=n;j++)
	        d[0][j]=j;
	 
	    for(i=1;i<=m;i++)
	    {
	        for(j=1;j<=n;j++)
	        {
	            if(x.charAt(i-1)!=y.charAt(j-1))
	            {
	                int k=minimum(d[i][j-1],d[i-1][j],d[i-1][j-1]);
	                d[i][j]=k+1;
	            }
	            else
	            {
	                d[i][j]=d[i-1][j-1];
	            }
	        }
	    }
	    
	    distance=d[m][n];
	    
	    return distance;
	}
	
	//restituisce il minimo tra 3 interi
	private static int minimum(int a,int b,int c)
	{
		int min=a;
 
        if(b<min)
        	min=b;
 
        if(c<min)
        	min=c;
        
        return min;
	}
	
	public static String dateToStringDDMMYYYY(Date date)
	{
		try
		{
			if(date==null)
				return null;
			return df.format(date);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static String convertClob(Clob cl) throws GestioneErroriException{

		try{
		Reader stream = cl.getCharacterStream();
		BufferedReader reader = new BufferedReader(stream);
		StringBuffer sb = new StringBuffer();
		String line = null;
		while ((line=reader.readLine())!=null){
			   sb.append(line+"\r\n");
			  }
		stream.close();
		
		if (sb.length()>0){
			   return sb.toString();
			  }
		
		}catch(Exception e){
			e.printStackTrace();
		}
		  
		   
		  return "";
		 }
	
	
	public static String dateToString(Date date, SimpleDateFormat dateFormat)
	{
		try
		{
			if(date==null || dateFormat==null)
				return null;
			return dateFormat.format(date);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static String dateToString(Date date, String format) {
		
		try {
			
			if(date == null || format == null)
				return null;
			
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			return dateFormat.format(date);
		}
		catch(Exception e) {
			
			e.printStackTrace();
			return null;
		}
	}
	
	public static String timestampToString(Timestamp time, String format) {
		
		try {
			
			if(time == null || format == null)
				return null;
			
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			return dateFormat.format(time);
		}
		catch(Exception e) {
			
			e.printStackTrace();
			return null;
		}
	}
	
	public static Date stringToDate(String date,String format)
	{
		try
		{
			if(date==null || format==null)
				return null;
			
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			
			return (Date)sdf.parse(date);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static Date StringDDMMYYYYToDate(String s)
	{
		try
		{
			if(s==null)
				return null;
			return (Date)df.parse(s);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static String generateString(Random rng, String characters, int length)
	{
		String aesKey  = AppProperties.getAppProperty("aesKey");
	    char[] text = new char[length];
	    for (int i = 0; i < length; i++)
	    {
	        text[i] = characters.charAt(rng.nextInt(characters.length()));
	    }
	    String daCriptare = new String(text);
	    String pedCriptata = CriptDecriptUtil.criptToken(daCriptare, aesKey);
	    return pedCriptata;
	}
	
	//trova la stringa corrispondente alla chiave specificata, all'interno del message bundle dell'applicazione (linguaggio selezionabile)
	public static String getPropertyMessage(String propertyKey,String language)
	{
		try
		{
			String messageBundleName=JSFUtility.getFacesContext().getApplication().getMessageBundle();
			
			ResourceBundle messageBundle=ResourceBundle.getBundle(messageBundleName,new Locale(language));
		
			return messageBundle.getString(propertyKey);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	//************************************************************************************************************************
	// METODI CALCOLO CODICE FISCALE
		
	private static final String mesi = "ABCDEHLMPRST"; 
	private static final String vocali = "AEIOU"; 
	private static final String consonanti = "BCDFGHJKLMNPQRSTVWXYZ"; 
	private static final String alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 

	private static int[][] matricecod; 

	static 
	{ 
	matricecod= new int[91][2]; 
	matricecod [0][1] = 1 ; 
	matricecod [0][0] = 0 ; 
	matricecod [1][1] = 0 ; 
	matricecod [1][0] = 1 ; 
	matricecod [2][1] = 5 ; 
	matricecod [2][0] = 2 ; 
	matricecod [3][1] = 7 ; 
	matricecod [3][0] = 3 ; 
	matricecod [4][1] = 9 ; 
	matricecod [4][0] = 4 ; 
	matricecod [5][1] = 13 ; 
	matricecod [5][0] = 5 ; 
	matricecod [6][1] = 15 ; 
	matricecod [6][0] = 6 ; 
	matricecod [7][1] = 17 ; 
	matricecod [7][0] = 7 ; 
	matricecod [8][1] = 19 ; 
	matricecod [8][0] = 8 ; 
	matricecod [9][1] = 21 ; 
	matricecod [9][0] = 9 ; 
	matricecod [10][1] = 1 ; 
	matricecod [10][0] = 0 ; 
	matricecod [11][1] = 0 ; 
	matricecod [11][0] = 1 ; 
	matricecod [12][1] = 5 ; 
	matricecod [12][0] = 2 ; 
	matricecod [13][1] = 7 ; 
	matricecod [13][0] = 3 ; 
	matricecod [14][1] = 9 ; 
	matricecod [14][0] = 4 ; 
	matricecod [15][1] = 13 ; 
	matricecod [15][0] = 5 ; 
	matricecod [16][1] = 15 ; 
	matricecod [16][0] = 6 ; 
	matricecod [17][1] = 17 ; 
	matricecod [17][0] = 7 ; 
	matricecod [18][1] = 19 ; 
	matricecod [18][0] = 8 ; 
	matricecod [19][1] = 21 ; 
	matricecod [19][0] = 9 ; 
	matricecod [20][1] = 2 ; 
	matricecod [20][0] = 10 ; 
	matricecod [21][1] = 4 ; 
	matricecod [21][0] = 11 ; 
	matricecod [22][1] = 18 ; 
	matricecod [22][0] = 12 ; 
	matricecod [23][1] = 20 ; 
	matricecod [23][0] = 13 ; 
	matricecod [24][1] = 11 ; 
	matricecod [24][0] = 14 ; 
	matricecod [25][1] = 3 ; 
	matricecod [25][0] = 15 ; 
	matricecod [26][1] = 6 ; 
	matricecod [26][0] = 16 ; 
	matricecod [27][1] = 8 ; 
	matricecod [27][0] = 17 ; 
	matricecod [28][1] = 12 ; 
	matricecod [28][0] = 18 ; 
	matricecod [29][1] = 14 ; 
	matricecod [29][0] = 19 ; 
	matricecod [30][1] = 16 ; 
	matricecod [30][0] = 20 ; 
	matricecod [31][1] = 10 ; 
	matricecod [31][0] = 21 ; 
	matricecod [32][1] = 22 ; 
	matricecod [32][0] = 22 ; 
	matricecod [33][1] = 25 ; 
	matricecod [33][0] = 23 ; 
	matricecod [34][1] = 24 ; 
	matricecod [34][0] = 24 ; 
	matricecod [35][1] = 23 ; 
	matricecod [35][0] = 25 ; 
	} 
		
	public static String generaCodiceFiscaleStraniero(String cognomeIn, String nomeIn, Date dNascita, String nazione, String localitaIn, String sesso)  
	{
		String retval = null; 
		String nome=nomeIn.toUpperCase(); 
		String cognome=cognomeIn.toUpperCase(); 
		String localita=localitaIn.toUpperCase(); 
		int anno=0,mese=0,giorno=0,codcontrollo=0; 
		Date data=dNascita; 

		GregorianCalendar cal =new GregorianCalendar(); 
		cal.setTime(data); 
		String a =Integer.toString(cal.get(cal.YEAR)); 
		a=a.substring(a.length()-2,a.length()); 
		anno= Integer.parseInt(a); 
		mese= cal.get(cal.MONTH); 
		giorno= cal.get(cal.DATE); 

		retval="*"+getCodeCognomeCF(noAccentate(cognome.trim()))+getCodeNomeCF(noAccentate(nome.trim())); 
		if ("F".equals(sesso)) { giorno=giorno+40; } 
		retval += ((anno<10)?"0":"")+Integer.toString(anno) + mesi.charAt(mese)+((giorno<10)?"0":"")+Integer.toString(giorno); 
		retval += nazione; //Codice Nazione
		retval += getCodeCognomeCF(noAccentate(localita.trim())); //Localita
		/*for (int i=0;i<15;i++) { 
		codcontrollo += matricecod[Character.getNumericValue(retval.charAt(i))][(i+1)%2]; 
		} 
		retval += alfabeto.charAt(codcontrollo % 26); */
		retval += "*";
		return retval; 
		
	}
	
	private static String getCodeCognomeCF(String cogn) 
	{ 
		int i=0; 
		String stringa=""; 
		//trova consonanti 
		while ((stringa.length() < 3) && (i+1 <= cogn.length())) { 
			if (consonanti.indexOf(cogn.charAt(i)) > -1) { 
				stringa += cogn.charAt(i); 
			} 
			i++; 
		} 
		i = 0; 
		//se non bastano prende vocali 
		while ((stringa.length() < 3) && (i+1 <= cogn.length())) { 
			if (vocali.indexOf(cogn.charAt(i)) > -1) { 
				stringa += cogn.charAt(i); 
			} 
			i++; 
		} 
		//se non bastano aggiungo le x 
		if (stringa.length() < 3) { 
			for (i = stringa.length();i<3;i++) { 
				stringa += "X"; 
			} 
		} 
		return stringa; 
	} 

	private static String getCodeNomeCF(String nom) 
	{ 
		int i=0; 
		String stringa="", cons=""; 
		//trova consonanti 
		while ((cons.length() < 4) && (i+1 <= nom.length())) { 
			if (consonanti.indexOf(nom.charAt(i)) > -1) { 
				cons += nom.charAt(i); 
			} 
			i++; 
		} 
		//se sono + di 3 prende 1� 3� 4� 
		if (cons.length()>3){ 
			stringa=cons.substring(0,1)+cons.substring(2,4); 
			return stringa; 
		} 
		else{ 
			stringa=cons; 
		} 
		i = 0; 
		//se non bastano prende vocali 
		while ((stringa.length() < 3) && (i+1 <= nom.length())) { 
			if (vocali.indexOf(nom.charAt(i)) > -1) { 
				stringa += nom.charAt(i); 
			} 
			i++; 
		} 
		//se non bastano aggiungo le x 
		if (stringa.length() < 3) { 
			for (i = stringa.length();i<3;i++) { 
				stringa += "X"; 
			} 
		} 
		return stringa; 
	} 
		
	private static String noAccentate(String s){ 
		//------------------------------------------------------------------------------// 
		// noAccentate // 
		// restituisce la stringa s trasformando le lettere accentate in non accentate // 
		// ad esempio "and�" viene trasformata "ando" // 
		//------------------------------------------------------------------------------// 
		final String ACCENTATE="������������"; 
		final String NOACCENTO="AEEIOUAEEIOU"; 
		int i=0; 
		//scorre la stringa originale 
		while (i<s.length()){ 
			int p= ACCENTATE.indexOf(s.charAt(i)); 
			//se ha trovato una lettera accentata 
			if (p>-1){ 
				//sostituisce con la relativa non accentata 
				s=s.substring(0,i)+NOACCENTO.charAt(p)+s.substring(i+1); 
			} 
			i++; 
		} 
		return s; 
	} 
	
	public static String replaceApice(String inString){
		
		int posApice = inString.indexOf("'");
		int start = 0;
		
		while(posApice>-1){
			inString = inString.substring(0,posApice)+"''"+inString.substring(posApice+1);
			start = posApice+2;
			posApice = inString.indexOf("'", start);
		}
		return inString;
	}
	

	
}
 