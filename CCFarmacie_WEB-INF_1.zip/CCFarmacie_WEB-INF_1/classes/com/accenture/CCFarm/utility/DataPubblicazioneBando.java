package com.accenture.CCFarm.utility;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;

public class DataPubblicazioneBando {
	
	
	private static HashMap<String,Date> datePubblicazioneBandi;

	public static HashMap<String,Date> getDataPubblicazioneBando()throws GestioneErroriException	{
		
		//se non ho ancora mai caricato la lista dei bandi 
		if(datePubblicazioneBandi==null)	{
			List<DatiBando> datiBandoList = null;
			//recupero tramite l'apposita home tutte le nazioni dal db
			DatiBandoHome datiBandoHome = new DatiBandoHome();
			DatiBando datiBando = new DatiBando();
			datiBandoList = datiBandoHome.findByExample(datiBando);
						
			//popola lista delle nazioni
			datePubblicazioneBandi = new HashMap< String, Date>();
			String denominazione=null;
			DatiBando datibando = null;
			for(int i=0;i<datiBandoList.size(); i++){
				datibando = datiBandoList.get(i);
				datePubblicazioneBandi.put(datibando.getCodReg(), (Date) datibando.getCreationDateBando());
				datePubblicazioneBandi.put("ChiusuraBandoReg_" + datibando.getCodReg() , (Date) datibando.getDataFineBando());
			}		
		}
			
		return datePubblicazioneBandi;
	
	}
}
