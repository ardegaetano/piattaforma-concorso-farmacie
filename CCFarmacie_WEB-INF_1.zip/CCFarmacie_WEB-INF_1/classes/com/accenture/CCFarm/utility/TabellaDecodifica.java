package com.accenture.CCFarm.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import com.accenture.CCFarm.Bean.DocumentoIdentita;
import com.accenture.CCFarm.Bean.Ruolo;
import com.accenture.CCFarm.Bean.StatoDomanda;
import com.accenture.CCFarm.DAO.ValoriCodice;
import com.accenture.CCFarm.DAO.ValoriCodiceHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;

public class TabellaDecodifica extends Hashtable {

	private static TabellaDecodifica tabella = null;
	private static List<Ruolo> ruoli = new ArrayList<Ruolo>();
	private static HashMap<String, String> decodificaRuoli = new HashMap<String, String>();
	private static List<StatoDomanda> statoCanList = new ArrayList<StatoDomanda>();
	private static HashMap<String, String> decodificaStatoCandidatura = new HashMap<String, String>();
	private static List<DocumentoIdentita> documentiIdentita = new ArrayList<DocumentoIdentita>();
	private static HashMap<String, String> decodificaDocumentiIdentita = new HashMap<String, String>();

	private static HashMap<String, String> decodificaRuoliDe = new HashMap<String, String>();
	private static HashMap<String, String> decodificaStatoCandidaturaDe = new HashMap<String, String>();
	private static HashMap<String, String> decodificaDocumentiIdentitaDe = new HashMap<String, String>();

	private TabellaDecodifica() {

	}

	public static TabellaDecodifica getTabellaDecodifica() throws GestioneErroriException {

		if (tabella == null) {
			ValoriCodiceHome valoriCodiceHome = new ValoriCodiceHome();
			ValoriCodice valoriCodice = new ValoriCodice();
			List lista = valoriCodiceHome.findByExample(valoriCodice);
			tabella = new TabellaDecodifica();
			for (int i = 0; i < lista.size(); i++) {
				valoriCodice = (ValoriCodice) lista.get(i);
				tabella.put(valoriCodice.getIdKey().getCodice() + "_" + valoriCodice.getIdKey().getTipoCodice(), valoriCodice.getDescrizione());
			}
			return tabella;
		} else {
			return tabella;
		}

	}

	public static List<Ruolo> getRuoli() throws GestioneErroriException {
		Ruolo ruolo = null;
		if (ruoli == null || ruoli.isEmpty()) {
			ValoriCodiceHome valoriCodiceHome = new ValoriCodiceHome();
			ValoriCodice valoriCodice = new ValoriCodice();
			valoriCodice.setTipoCodice("TIPO_RUOLO");
			List<ValoriCodice> valoriCodiceList = valoriCodiceHome.findByExample(valoriCodice);
			for (int i = 0; i < valoriCodiceList.size(); i++) {
				valoriCodice = valoriCodiceList.get(i);
				ruolo = new Ruolo();
				ruolo.setCodice(valoriCodice.getIdKey().getCodice());
				ruolo.setDescrizione(valoriCodice.getDescrizione());
				ruolo.setDescrizioneDe(valoriCodice.getDescrizioneDe());
				ruoli.add(ruolo);
				decodificaRuoli.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizione());
				decodificaRuoliDe.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizioneDe());
			}
		}
		return ruoli;
	}

	public static String decodificaRuolo(String codice, String lingua) throws GestioneErroriException {

		String decodifica = null;
		if (lingua.equals("it")) {
			decodifica = decodificaRuoli.get(codice);
		} else {
			decodifica = decodificaRuoliDe.get(codice);
		}

		return decodifica;
	}

	public static String decodificaruolo(String codice) {
		String decodifica = null;
		decodifica = decodificaRuoli.get(codice);
		return decodifica;
	}

	public static List<Ruolo> getStatoCandidatura() throws GestioneErroriException {
		StatoDomanda statoDomanda = null;
		if (statoCanList == null || statoCanList.isEmpty()) {
			ValoriCodiceHome valoriCodiceHome = new ValoriCodiceHome();
			ValoriCodice valoriCodice = new ValoriCodice();
			valoriCodice.setTipoCodice("STATO_CANDIDATURA");
			List<ValoriCodice> valoriCodiceList = valoriCodiceHome.findByExample(valoriCodice);
			for (int i = 0; i < valoriCodiceList.size(); i++) {
				valoriCodice = valoriCodiceList.get(i);
				statoDomanda = new StatoDomanda();
				statoDomanda.setCodice(valoriCodice.getIdKey().getCodice());
				statoDomanda.setDescrizione(valoriCodice.getDescrizione());
				statoDomanda.setDescrizioneDe(valoriCodice.getDescrizioneDe());

				statoCanList.add(statoDomanda);
				decodificaStatoCandidatura.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizione());
				decodificaStatoCandidaturaDe.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizioneDe());
			}
		}
		return ruoli;
	}

	public static String decodificaStatoCandidatura(String codice, String lingua) throws GestioneErroriException {
		getStatoCandidatura();
		String decodifica = null;
		if (lingua.equals("it")) {
			decodifica = decodificaStatoCandidatura.get(codice);
		} else {
			decodifica = decodificaStatoCandidaturaDe.get(codice);
		}

		return decodifica;
	}

	public static String decodificaStatoCandidatura(String codice) throws GestioneErroriException {
		getStatoCandidatura();
		String decodifica = null;
		decodifica = decodificaStatoCandidatura.get(codice);
		return decodifica;
	}

	public static List<DocumentoIdentita> getDocumentoIdentita() throws GestioneErroriException {
		DocumentoIdentita documentoIdentita = null;
		if (documentiIdentita == null || documentiIdentita.isEmpty()) {
			ValoriCodiceHome valoriCodiceHome = new ValoriCodiceHome();
			ValoriCodice valoriCodice = new ValoriCodice();
			valoriCodice.setTipoCodice("TIPO_DOC_RICONOSCIMENTO");
			List<ValoriCodice> valoriCodiceList = valoriCodiceHome.findByExample(valoriCodice);
			for (int i = 0; i < valoriCodiceList.size(); i++) {
				valoriCodice = valoriCodiceList.get(i);
				documentoIdentita = new DocumentoIdentita();
				documentoIdentita.setCodice(valoriCodice.getIdKey().getCodice());
				documentoIdentita.setDescrizione(valoriCodice.getDescrizione());
				documentoIdentita.setDescrizioneDe(valoriCodice.getDescrizioneDe());
				documentiIdentita.add(documentoIdentita);
				decodificaDocumentiIdentita.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizione());
				decodificaDocumentiIdentitaDe.put(valoriCodice.getIdKey().getCodice(), valoriCodice.getDescrizioneDe());
			}
		}
		return documentiIdentita;
	}

	public static String decodificaDocumentoIdentita(String codice, String lingua) throws GestioneErroriException {

		String decodifica = null;
		if (decodificaDocumentiIdentita != null && !decodificaDocumentiIdentita.isEmpty()) {

			if (lingua.equals("it")) {
				decodifica = decodificaDocumentiIdentita.get(codice);
			} else {
				decodifica = decodificaDocumentiIdentitaDe.get(codice);
			}
		}
		return decodifica;
	}

	public static String decodificaDocumentoIdentita(String codice) {
		if (decodificaDocumentiIdentita != null && !decodificaDocumentiIdentita.isEmpty()) {
			return decodificaDocumentiIdentita.get(codice);
		}
		return null;
	}

}
