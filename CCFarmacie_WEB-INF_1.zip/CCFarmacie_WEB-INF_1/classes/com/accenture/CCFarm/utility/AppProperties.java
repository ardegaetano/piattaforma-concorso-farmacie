package com.accenture.CCFarm.utility;

import java.util.HashMap;
import java.util.Map;

public class AppProperties {
	
	private static Map<String, String> appProperties = null;
	
	private static Map<String, String> getAppProperties() {
		
		if(appProperties == null) {
			
			appProperties = new HashMap<String, String>();
			
			/* SVILUPPO
			appProperties.put("app_Name", "CCFarmacie");
			appProperties.put("bck_immage_path", "/CaptchaGenerator");
			appProperties.put("BaseUrlCartina", "/CCFarmacie");
			appProperties.put("BaseUrlConfermaRegistrazione", "http://192.168.20.185:8080/CCFarmacie");
			appProperties.put("oraChiusuraBando", "18");
			appProperties.put("idRegioneRegistrata", "idRegioneRegistrata");
			appProperties.put("aesKey128", "263F7998FE159C223ECCD6EA46662CCC");
			appProperties.put("aesKey", "C09385B0E84A2B072D64AC3B35433D5C"); */
			
			/* PRODUZIONE */
			appProperties.put("app_Name", "CCFarm");
			appProperties.put("bck_immage_path", "/CaptchaGenerator");
			appProperties.put("BaseUrlCartina", "/CCFarm");
			appProperties.put("BaseUrlConfermaRegistrazione", "https://www.concorsofarmacie.sanita.it/CCFarm");
			appProperties.put("oraChiusuraBando", "18");
			appProperties.put("idRegioneRegistrata", "idRegioneRegistrata");
			appProperties.put("aesKey128", "263F7998FE159C223ECCD6EA46662CCC");
			appProperties.put("aesKey", "C09385B0E84A2B072D64AC3B35433D5C");
			
			/* PRODUZIONE TEST
			appProperties.put("app_Name", "CCFarmTEST");
			appProperties.put("bck_immage_path", "/CaptchaGenerator");
			appProperties.put("BaseUrlCartina", "/CCFarmTEST");
			appProperties.put("BaseUrlConfermaRegistrazione", "https://nsis.sanita.it/csfarm/CCFarmTEST");
			appProperties.put("oraChiusuraBando", "18");
			appProperties.put("idRegioneRegistrata", "idRegioneRegistrata");
			appProperties.put("aesKey128", "263F7998FE159C223ECCD6EA46662CCC");
			appProperties.put("aesKey", "C09385B0E84A2B072D64AC3B35433D5C"); */
			
			appProperties.put("tipo.ricevuta.scelta.sedi", "SS");
			appProperties.put("tipo.ricevuta.accettazione.rinuncia.sede", "ARS");
			appProperties.put("numero.giorni.preavviso.interpello", "2");
			appProperties.put("numero.giorni.validita.interpello", "5");
			appProperties.put("orario.inizio.validita.interpello", "18");
			appProperties.put("orario.termine.validita.interpello", "18");
			appProperties.put("progressivo.iniziale.interpelli", "1");
			appProperties.put("codice.interpello.predisposto", "D");
			appProperties.put("codice.interpello.pubblicato", "P");
			appProperties.put("codice.interpello.chiuso", "C");
			appProperties.put("flag.valore.falso", "false");
			appProperties.put("flag.valore.vero", "true");
			appProperties.put("modalita.candidatura.singola", "S");
			appProperties.put("modalita.candidatura.associata", "A");
			appProperties.put("flag.referente.candidatura", "Y");
			
			//msg home LIGURIA
			appProperties.put("home.liguria.msg", "<b>27/05/2015</b> - in ottemperanza all'ordine impartito dal giudice amministrativo ligure, "+
				"il <u>ricorso presentato al Tar Liguria il 12 novembre 2014</u> dalla dott.ssa Fulvia Scotti per ottenere l'annullamento della graduatoria di merito "+
				"definitiva dei vincitori del concorso straordinario e <u>l'ordinanza n.114 del 21 maggio 2015</u> con la quale il Tar Liguria ha ordinato alla ricorrente "+ 
				"l'integrazione del contraddittorio nei confronti di tutti i concorrenti e alla regione la pubblicazione dei due atti.<BR>"+
				"<b>Per accedere ai documenti far riferimento al sito regionale</b>.");
			appProperties.put("home.liguria.link", "");
			appProperties.put("home.liguria.msg2", "");
			appProperties.put("home.liguria.link2", "");
			appProperties.put("home.liguria.msg3", "");
			appProperties.put("home.liguria.msg4", "<b>02/09/2015</b> - il decreto del Direttore generale del Dipartimento Salute e Servizi sociali n.260 del 02/09/2015 avente ad oggetto: "+ 
				"'Convalida provvedimenti di indizione concorso e approvazione bando di concorso pubblico regionale straordinario per titoli per assegnazione "+
				"sedi farmaceutiche regione Liguria, di nomina  commissione e approvazione graduatoria concorsuale'. Rinvenibile in formato integrale sul Burl "+ 
				"n. 37 del 16.09.2015, parte II.<BR> "+
				"<b>Per accedere al provvedimento far riferimento al sito regionale</b>.");

			
		}
		return appProperties;
	}
	
	public static String getAppProperty(String nomeProp) {
		
		return getAppProperties().get(nomeProp);	
	}

}
