package com.accenture.CCFarm.utility;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

public class GetSessionUtility {

	//ritorna l'istanza della sessione http corrente (nel caso non esiste ne crea una e ne ritorna il riferimento)
	private static HttpSession getSessionScope()
	{
		return (HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	}
	
	//ritorna l'oggetto in sessione individuato da "attribute"
	public static Object getSessionAttribute(String attribute)
	{
		try
		{
			return getSessionScope().getAttribute(attribute);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	//carica in sessione l'attributo specificato
	public static boolean setSessionAttribute(String attributeName,Object attribute)
	{
		try
		{
			getSessionScope().setAttribute(attributeName,attribute);
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
	
	//carica in sessione l'attributo specificato
	public static boolean removeSessionAttribute(String attributeName)
	{
		try
		{
			getSessionScope().removeAttribute(attributeName);
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
}
