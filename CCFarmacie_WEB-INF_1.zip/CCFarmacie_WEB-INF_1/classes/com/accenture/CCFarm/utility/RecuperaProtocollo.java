package com.accenture.CCFarm.utility;

import java.text.SimpleDateFormat;

import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.Exception.GestioneErroriException;

public class RecuperaProtocollo {
	SimpleDateFormat fst  = new SimpleDateFormat("dd-MM-yyyy");
		
	
	public RecuperaProtocollo() {
	
	}
	
	public String getProtocollo(String id_utente) throws GestioneErroriException{
//		controllo se la registrazione avviene dopo la data chiusura bando
//		Date sysDate = new Date (System.currentTimeMillis());
//	    
		CandidaturaHome candidaturaDAO = new CandidaturaHome();
		UtenteCandidatura utenteCandidatura = null;
		utenteCandidatura = candidaturaDAO.findByUserId(id_utente);
		RicevuteHome ricevuteDAO = new RicevuteHome();
		Ricevute ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
		String protocollo= null;
		
		if (ricevuta!=null)
		{
			protocollo = ricevuta.getId().getIdRicevuta()
					     +" - "
					     + fst.format(ricevuta.getDataInvio())
					     +" - "
					     + ricevuta.getId().getIdRegione();
		}

		return protocollo;
		
	}
	
	
	public String getProtocolloRegionale(String id_utente)throws GestioneErroriException {
//		controllo se la registrazione avviene dopo la data chiusura bando
//		Date sysDate = new Date (System.currentTimeMillis());
//	    
		CandidaturaHome candidaturaRegHome= new CandidaturaHome();
		UtenteCandidatura utenteCandidatura = null;
		String protocollo= null;
		Ricevute ricevuta = new Ricevute();
		
		try {
			utenteCandidatura = candidaturaRegHome.findByUserId(id_utente);
			
			RicevuteHome ricevuteDAO = new RicevuteHome();
			ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
			if (ricevuta.getId() != null && ricevuta.getId().getIdRicevuta() != null && 
					ricevuta.getDataInvio() != null  && ricevuta.getId().getIdRegione() != null)
				{
					protocollo = ricevuta.getId().getIdRicevuta()
							     +" - "
							     + fst.format(ricevuta.getDataInvio())
							     +" - "
							     + ricevuta.getId().getIdRegione();
				}
		} catch (Exception e) {
			
			throw new GestioneErroriException("Errore recupera protocollo - errore recupera protocollo");
			
		}
		return protocollo;
		
	}
	
	public String getProtocolloRegionaleObbligatorio(String id_utente)throws GestioneErroriException {
//		controllo se la registrazione avviene dopo la data chiusura bando
//		Date sysDate = new Date (System.currentTimeMillis());
//	    
		CandidaturaHome candidaturaRegHome= new CandidaturaHome();
		UtenteCandidatura utenteCandidatura = null;
		String protocollo= null;
		Ricevute ricevuta = new Ricevute();
		
		try {
			utenteCandidatura = candidaturaRegHome.findByUserId(id_utente);
			
			RicevuteHome ricevuteDAO = new RicevuteHome();
			ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
			
			protocollo = ricevuta.getId().getIdRicevuta()
					     +" - "
					     + fst.format(ricevuta.getDataInvio())
					     +" - "
					     + ricevuta.getId().getIdRegione();
				
		} catch (Exception e) {
			
			throw new GestioneErroriException("Errore recupera protocollo - errore recupera protocollo");
			
		}
		return protocollo;
		
	}

	
}
