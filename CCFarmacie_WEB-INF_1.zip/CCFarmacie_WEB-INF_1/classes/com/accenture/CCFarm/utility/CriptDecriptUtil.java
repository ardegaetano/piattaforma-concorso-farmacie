package com.accenture.CCFarm.utility;


import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class CriptDecriptUtil {
	
	//Cripta il corpo del Cookie..
	public static String criptToken(String tokenDaCriptare,String chiaveCript ){
		try{
			//String keyAes=AESUtil.AES_KEY;
			byte [] keyBytes = new byte[16];
			java.math.BigInteger b = new java.math.BigInteger(chiaveCript, 16);
			byte [] bigBytes = b.toByteArray();
			System.arraycopy(bigBytes, 0, keyBytes, 0, Math.min(keyBytes.length, bigBytes.length));
			SecretKey skey = new SecretKeySpec(keyBytes , "AES");
		    byte[] raw = skey.getEncoded();
		    SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		    Cipher cipher = Cipher.getInstance("AES");
		    cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
			byte[] encrypted = cipher.doFinal(tokenDaCriptare.getBytes());
			String testo=asHex(encrypted);
			return(testo);
		}catch(Exception e){
			e.printStackTrace();
			return(null);
		}//Fine try..catch...
	}//Fine metodo..
	
	//Decripta il corpo del cookie...
	public static String decriptToken(String tokenDaDecriptare,String chiaveDecript){
		try{
			//String keyAesDecrypt = AESUtil.AES_KEY;
			byte[] byteDaDecrypt = hexToBytes(tokenDaDecriptare.toCharArray());
			java.math.BigInteger bDec = new java.math.BigInteger(chiaveDecript, 16);
			byte[] keyBytesDec = new byte[16];
			byte[] bigBytesDec = bDec.toByteArray();
			System.arraycopy(bigBytesDec, 0, keyBytesDec, 0, Math.min(keyBytesDec.length, bigBytesDec.length));
			SecretKey skeyDec = new SecretKeySpec(keyBytesDec, "AES");
			byte[] rawDec = skeyDec.getEncoded();
			SecretKeySpec skeySpecDec = new SecretKeySpec(rawDec, "AES");
			Cipher cipherDec = Cipher.getInstance("AES");
			cipherDec.init(Cipher.DECRYPT_MODE, skeySpecDec);
			byte[] original = cipherDec.doFinal(byteDaDecrypt);
			String originalString = new String(original);
			return (originalString);
		}catch(Exception e){
			e.printStackTrace();
			return(null);
		}//Fine try..catch...
	}//Fine metodo..
	

	
	
	public static String asHex(byte buf[]) {
		StringBuffer strbuf = new StringBuffer(buf.length * 2);
		int i;

		for (i = 0; i < buf.length; i++) {
			if (((int) buf[i] & 0xff) < 0x10)
				strbuf.append("0");

			strbuf.append(Long.toString((int) buf[i] & 0xff, 16));
		}

		return strbuf.toString();
	}//Fine metodo..
	
	public static byte[] hexToBytes(char[] hex) {
		int length = hex.length / 2;
		byte[] raw = new byte[length];
		for (int i = 0; i < length; i++) {
			int high = Character.digit(hex[i * 2], 16);
			int low = Character.digit(hex[i * 2 + 1], 16);
			int value = (high << 4) | low;
			if (value > 127)
				value -= 256;
			raw[i] = (byte) value;
		}//Fine for..
		return raw;
	}//Fine metodo..

}//Fine classe...
