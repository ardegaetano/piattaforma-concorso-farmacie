package com.accenture.CCFarm.utility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.accenture.CCFarm.Bean.ComuneSelect;
import com.accenture.CCFarm.Bean.NazioneSelect;
import com.accenture.CCFarm.Bean.ProvinciaSelect;
import com.accenture.CCFarm.Bean.RegioneSelect;
import com.accenture.CCFarm.DAO.Comune;
import com.accenture.CCFarm.DAO.ComuneHome;
import com.accenture.CCFarm.DAO.Nazione;
import com.accenture.CCFarm.DAO.NazioneHome;
import com.accenture.CCFarm.DAO.Provincia;
import com.accenture.CCFarm.DAO.ProvinciaHome;
import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.Exception.GestioneErroriException;

public class Localita {

	private static List regioni = null;
	private static List province = null;
	private static List comuni = null;
	private static List<NazioneSelect> nazioniSelect = null;
	private static List<NazioneSelect> nazioniSEESelect = null;
	private static List<RegioneSelect> regioniSelect = null;
	private static List<ProvinciaSelect> provinceSelect = null;
	private static List<ComuneSelect> comuniSelect = null;
	private static HashMap<String, ArrayList<ProvinciaSelect>> provinceMap = new HashMap<String, ArrayList<ProvinciaSelect>>();
	private static HashMap<String, ArrayList<ComuneSelect>> comuniMap = new HashMap<String, ArrayList<ComuneSelect>>();
	private static HashMap<String, String> decodificaNazioniMap = null;
	private static HashMap<String, String> decodificaNazioniDeMap = null;
	private static HashMap<String, String> decodificaRegioniMap = null;
	private static HashMap<String, String> decodificaProvinceMap = null;
	private static HashMap<String, String> decodificaComuniMap = null;
	
	public static List<NazioneSelect> getNazioni()
	{
		if(nazioniSelect==null)	{
			 List<Nazione> nazioni = null;
			//recupero tramite l'apposita home tutte le nazioni dal db
			NazioneSelect nazioneSelect;
			NazioneHome nazionehome = new NazioneHome();
			Nazione nazione = new Nazione();
			try {
				nazioni = nazionehome.findByExample(nazione);
			} catch (GestioneErroriException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//popola lista delle nazioni
			nazioniSelect=new ArrayList<NazioneSelect>();
			
			Iterator it=nazioni.iterator();
			while(it.hasNext())
			{
				nazione=(Nazione)(it.next());
				
					nazioneSelect = new NazioneSelect();
					nazioneSelect.setCodice(nazione.getCodIsoNazione());
					nazioneSelect.setDescrizione(nazione.getDscIsoNazione());
					nazioneSelect.setDescrizioneDe(nazione.getDscNazioneEstesaDe());
					nazioniSelect.add(nazioneSelect);
			}
			Collections.sort(nazioniSelect);
			
		}
		return nazioniSelect;
	}
	
	public static List<NazioneSelect> getNazioniEuropee()
	{
		if(nazioniSEESelect==null)	{
			 List<Nazione> nazioni = null;
			//recupero tramite l'apposita home tutte le nazioni dal db
			NazioneSelect nazioneSelect;
			NazioneHome nazionehome = new NazioneHome();
			Nazione nazione = new Nazione();
			try {
				nazioni = nazionehome.findByExample(nazione);
			} catch (GestioneErroriException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//popola lista delle nazioni
			nazioniSEESelect=new ArrayList<NazioneSelect>();
			
			Iterator it=nazioni.iterator();
			while(it.hasNext())
			{
				nazione=(Nazione)(it.next());
				int flagUe=Integer.parseInt(nazione.getFlagStatoUe());
				if(flagUe>0)
				{
					nazioneSelect = new NazioneSelect();
					nazioneSelect.setCodice(nazione.getCodIsoNazione());
					nazioneSelect.setDescrizione(nazione.getDscIsoNazione());
					nazioneSelect.setDescrizioneDe(nazione.getDscNazioneEstesaDe());
					nazioniSEESelect.add(nazioneSelect);
				}
			}
			
			Collections.sort(nazioniSEESelect);
			
		}
		return nazioniSEESelect;
	}

	
	public static List<RegioneSelect> getRegioni()
	{
		
		if(regioniSelect==null)
		{
			RegioneHome regioneHome = new RegioneHome();
			Regione regione = new Regione();
			try {
				regioni = regioneHome.findByExample(regione);
			} catch (GestioneErroriException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//popola lista delle nazioni
			RegioneSelect regioneSelect = null;
			regioniSelect= new ArrayList<RegioneSelect>();
						
			Iterator it=regioni.iterator();
			while(it.hasNext())
			{
				regione=(Regione)(it.next());
				regioneSelect = new RegioneSelect();
				regioneSelect.setDescrizione(regione.getDenominazioneReg());
				regioneSelect.setCodice(regione.getCodReg());
				regioniSelect.add(regioneSelect);
			}
			
			Collections.sort(regioniSelect);	
		}
		return regioniSelect;
	}
	
	public static HashMap<String, ArrayList<ProvinciaSelect>> getProvince(String codiceRegione){
		List<ProvinciaSelect> provinceSelect=new ArrayList<ProvinciaSelect>();
		ArrayList<ProvinciaSelect> listaProvince = new ArrayList<ProvinciaSelect>();
		
			listaProvince = provinceMap.get(codiceRegione);
			
				if(listaProvince==null)	{
					ProvinciaHome provinciaHome = new ProvinciaHome();
					Provincia provincia = new Provincia();
					if(province==null){
						try {
							province = provinciaHome.findByExample(provincia);
						} catch (GestioneErroriException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					
				   //popola lista delle province
				   ProvinciaSelect provinciaSelect=null;
				
					Iterator it=province.iterator();
					while(it.hasNext())
					{
						provincia=(Provincia)(it.next());
						if(!codiceRegione.equals("0")){
							//lista province dipendente dalla regione
								if(provincia.getCodiceRegione().equals(codiceRegione)){
										provinciaSelect=new ProvinciaSelect();
										provinciaSelect.setCodice(provincia.getCodiceProvincia());
										provinciaSelect.setDescrizione(provincia.getDenominazioneProvincia());
										provinceSelect.add(provinciaSelect);
								}
							
								Collections.sort(provinceSelect);	
								provinceMap.put(codiceRegione, (ArrayList<ProvinciaSelect>) provinceSelect);
								
							}
							//lista provincie indioendente dalla regione
							else{
								provinciaSelect=new ProvinciaSelect();
								provinciaSelect.setCodice(provincia.getCodiceProvincia());
								provinciaSelect.setDescrizione(provincia.getDenominazioneProvincia());
								provinceSelect.add(provinciaSelect);
									
								Collections.sort(provinceSelect);
								provinceMap.put("0", (ArrayList<ProvinciaSelect>) provinceSelect);
							}
						
						}
				}
		return provinceMap;
	}
	
	public static HashMap<String, ArrayList<ComuneSelect>> getComuni(String codiceProvincia){
		List<ComuneSelect> comuniSelect=new ArrayList<ComuneSelect>();
		ArrayList<ComuneSelect> lista = new ArrayList<ComuneSelect>();
		
			
		lista = comuniMap.get(codiceProvincia);
		
		if(lista==null)	{
			ComuneHome comuneHome = new ComuneHome();
			Comune comune = new Comune();
			comune.setCodiceProvincia(codiceProvincia);
			try {
				comuni = comuneHome.findByExample(comune);
			} catch (GestioneErroriException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		//popola lista dei comuni
		ComuneSelect comuneSelect=null;
		
		Iterator it=comuni.iterator();
		while(it.hasNext())
		{
			comune=(Comune)(it.next());
						
			if(comune.getCodiceProvincia().equals(codiceProvincia)){
				comuneSelect = new ComuneSelect();
				comuneSelect.setCodice(comune.getCodiceComune());
				comuneSelect.setDescrizione(comune.getDenominazioneEstesa());
				comuniSelect.add(comuneSelect);
				}
			
			Collections.sort(comuniSelect);
			
						
			}
		comuniMap.put(codiceProvincia, (ArrayList<ComuneSelect>) comuniSelect);
		
		
		}
		
		return comuniMap;
	}
	
	//--------------------------------------------------------------------
	
	public static HashMap<String, String> getDecodificaNazioniMap(){
		
		if(decodificaNazioniMap==null||decodificaNazioniMap.isEmpty())
		{
			if(nazioniSelect==null||nazioniSelect.isEmpty()){
				nazioniSelect=getNazioni();
			}
				decodificaNazioniMap = new HashMap<String, String>();
				for(int i=0;i<nazioniSelect.size();i++){
					decodificaNazioniMap.put(nazioniSelect.get(i).getCodice(), nazioniSelect.get(i).getDescrizione());
				}
		}
		return decodificaNazioniMap;
	}
	
	
 public static HashMap<String, String> getDecodificaNazioniDeMap(){
		
		if(decodificaNazioniDeMap==null||decodificaNazioniDeMap.isEmpty())
		{
			if(nazioniSelect==null||nazioniSelect.isEmpty()){
				nazioniSelect=getNazioni();
			}
				decodificaNazioniDeMap = new HashMap<String, String>();
				for(int i=0;i<nazioniSelect.size();i++){
					decodificaNazioniDeMap.put(nazioniSelect.get(i).getCodice(), nazioniSelect.get(i).getDescrizioneDe());
				}
		}
		return decodificaNazioniDeMap;
	}
	
	
	
	
	
	
	public static HashMap<String, String> getDecodificaRegioniMap(){
			
		if(decodificaRegioniMap==null||decodificaRegioniMap.isEmpty())
		{
			if(regioniSelect==null||regioniSelect.isEmpty()){
				regioniSelect=getRegioni();
			}
			decodificaRegioniMap = new HashMap<String, String>();
				for(int i=0;i<regioniSelect.size();i++){
					String reg =regioniSelect.get(i).getCodice();
					String reg2 = regioniSelect.get(i).getDescrizione();
					decodificaRegioniMap.put(reg, reg2);
				}
		}
		return decodificaRegioniMap;
	}
	
	public static HashMap<String, String> getDecodificaProvinceMap(){
		
		if(decodificaProvinceMap==null||decodificaProvinceMap.isEmpty()){
			
			decodificaProvinceMap = new HashMap<String, String>();
			provinceSelect = new ArrayList<ProvinciaSelect>();
			ProvinciaSelect provinciaSelect = new ProvinciaSelect();
			
			ProvinciaHome provinciaHome = new ProvinciaHome();
			Provincia provincia = new Provincia();
			try {
				province = provinciaHome.findByExample(provincia);
			} catch (GestioneErroriException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Iterator it=province.iterator();
			while(it.hasNext())
			{
				provincia=(Provincia)(it.next());
				provinciaSelect = new ProvinciaSelect();
				provinciaSelect.setDescrizione(provincia.getDenominazioneProvincia());
				provinciaSelect.setCodice(provincia.getCodiceProvincia());
				provinceSelect.add(provinciaSelect);
			}
			
			Collections.sort(provinceSelect);	
				for(int i=0;i<provinceSelect.size();i++){
					decodificaProvinceMap.put(provinceSelect.get(i).getCodice(), provinceSelect.get(i).getDescrizione());
					}
		}
					
			return decodificaProvinceMap;
	}
	
	public static HashMap<String, String> getDecodificaComuniMap(){
			
		if(decodificaComuniMap==null||decodificaComuniMap.isEmpty()){
			
			decodificaComuniMap = new HashMap<String, String>();
			comuniSelect = new ArrayList<ComuneSelect>();
			ComuneSelect comuneSelect = new ComuneSelect();
			
			ComuneHome comuneHome = new ComuneHome();
			Comune comune = new Comune();
			try {
				comuni = comuneHome.findByExample(comune);
			} catch (GestioneErroriException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Iterator it=comuni.iterator();
			while(it.hasNext())
			{
				comune=(Comune)(it.next());
				comuneSelect = new ComuneSelect();
				comuneSelect.setDescrizione(comune.getDenominazione());
				comuneSelect.setCodice(comune.getCodiceComune());
				comuniSelect.add(comuneSelect);
			}
			
			Collections.sort(comuniSelect);	
				for(int i=0;i<comuniSelect.size();i++){
					decodificaComuniMap.put(comuniSelect.get(i).getCodice(), comuniSelect.get(i).getDescrizione());
					}
			}
					
			return decodificaComuniMap;
	}
	
	//--------------------------------------------------------------------
	
	public static String getDenominazioneNazione(String codice){
		
		String denominazioneNazioneString ="";
		
		if(decodificaNazioniMap==null||decodificaNazioniMap.isEmpty()){
			getDecodificaNazioniMap();
		}
		
		denominazioneNazioneString = decodificaNazioniMap.get(codice);
		
		return denominazioneNazioneString;
	}
	
	
public static String getDenominazioneNazione(String codice, String lingua){
		
		String denominazioneNazioneString ="";
		if (lingua.equals("it")){
			
		
		if(decodificaNazioniMap==null||decodificaNazioniMap.isEmpty()){
			getDecodificaNazioniMap();
		}
		
		
		denominazioneNazioneString = decodificaNazioniMap.get(codice);
		}else{
			if(decodificaNazioniDeMap==null||decodificaNazioniDeMap.isEmpty()){
				getDecodificaNazioniDeMap();
			}
			
			
			denominazioneNazioneString = decodificaNazioniDeMap.get(codice);
		}
			
		return denominazioneNazioneString;
	}
	
	
	
	public static String getDenominazioneRegione(String codice){
		
		String denominazioneRegioneString ="";
		
		if(decodificaRegioniMap==null||decodificaRegioniMap.isEmpty()){
			getDecodificaRegioniMap();
		}
		
		denominazioneRegioneString = decodificaRegioniMap.get(codice);
		
		return denominazioneRegioneString;
	}
	
	public static String getDenominazioneProvincia(String codice){
		
		String denominazioneProvinciaString ="";
		
		if(decodificaProvinceMap==null||decodificaProvinceMap.isEmpty()){
			getDecodificaProvinceMap();
		}
	
		denominazioneProvinciaString = decodificaProvinceMap.get(codice);
		
		return denominazioneProvinciaString;
	}
	
	public static String getDenominazioneComune(String codice){
		
		String denominazioneComuneString ="";
		
		if(decodificaComuniMap==null||decodificaComuniMap.isEmpty()){
			getDecodificaComuniMap();
		}
		
		denominazioneComuneString = decodificaComuniMap.get(codice);
		
		return denominazioneComuneString;
	}

	
		
}
