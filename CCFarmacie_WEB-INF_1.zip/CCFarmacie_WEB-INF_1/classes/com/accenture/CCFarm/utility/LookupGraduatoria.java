package com.accenture.CCFarm.utility;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.DAO.TipoGraduatoria;
import com.accenture.CCFarm.DAO.TipoGraduatoriaHome;
import com.accenture.CCFarm.DAO.TipoGraduatoriaId;
import com.accenture.CCFarm.Exception.GestioneErroriException;

public class LookupGraduatoria {
	
	private static Logger logger = CommonLogger.getLogger("LookupGraduatoria");
	
	private static SimpleDateFormat dateFormat;
	
	private static Date dataUltimoCaricamento;
	private static HashMap<String, TipoGraduatoria> graduatorieMap;
	private static HashMap<String, TipoGraduatoria> graduatoriePrecMap;
	
	static {
		
		dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		dataUltimoCaricamento = DateUtil.getDataOdierna();
		loadGraduatorieMap(dataUltimoCaricamento);
	}
	
	public static HashMap<String, TipoGraduatoria> getGraduatorie() {
		
		Date dataOdierna = DateUtil.getDataOdierna();
		//se � passato un giorno o pi� dall'ultimo caricamento, o se la mappa risulta vuota, aggiorna le graduatorie nella mappa
		if(DateUtil.calcolaDifferenzaDate(dataUltimoCaricamento, dataOdierna) > 0 ||
		   graduatorieMap == null || graduatorieMap.isEmpty()) {
			
			//carica da DB le graduatorie aggiornate per tutte le regioni
			loadGraduatorieMap(dataOdierna);
			
			//aggiorna la data di caricamento
			dataUltimoCaricamento = dataOdierna;
		}
		
		return graduatorieMap;
	}
	
	public static HashMap<String, TipoGraduatoria> getGraduatoriePrec() {
		
		return graduatoriePrecMap;
	}
	
	@SuppressWarnings("unchecked")
	private static void loadGraduatorieMap(Date dataOdierna) {
		
		try {
			
			graduatorieMap = new HashMap<String, TipoGraduatoria>();
			graduatoriePrecMap = new HashMap<String, TipoGraduatoria>();
			
			RegioneHome regioneHome = new RegioneHome();
			TipoGraduatoriaHome tipoGraduatoriaHome = new TipoGraduatoriaHome();
			
			List<Regione> listRegioni = (List<Regione>) regioneHome.findByExample(new Regione());
			
			TipoGraduatoria tipoGraduatoria = null;
			TipoGraduatoriaId tipoGraduatoriaId = null;
			
			//loop per ogni regione
			for (Regione regione : listRegioni) {
				
				List<TipoGraduatoria> listTipGrad = new ArrayList<TipoGraduatoria>();
			     
				tipoGraduatoria = new TipoGraduatoria();
				    tipoGraduatoriaId = new TipoGraduatoriaId();
				    tipoGraduatoria.setCodRegione(regione.getCodReg());
				    tipoGraduatoriaId.setCodRegione(regione.getCodReg());
			    tipoGraduatoria.setIdKey(tipoGraduatoriaId);
			    
			    listTipGrad = tipoGraduatoriaHome.findByExample(tipoGraduatoria);
			    
			    //loop per ogni record tipo graduatoria
			    for (TipoGraduatoria tipoGrad : listTipGrad) {
			    	
			    	if (tipoGrad.getStatoGraduatoria() != null && tipoGrad.getStatoGraduatoria().equalsIgnoreCase("P")) {
			    		
			    		//se data pubblicazione coincide con data corrente o superiore
			    		if (DateUtil.calcolaDifferenzaDate(tipoGrad.getDataPublicazione(), dataOdierna) >= 0) {
			    			
			    			tipoGrad.setDataValutazioneFormat(dateFormat.format(tipoGrad.getDataValutazione()));
							tipoGrad.setDataPublicazioneFormat(dateFormat.format(tipoGrad.getDataPublicazione()));
							tipoGrad.setDataBollettinoUffRegFormat(dateFormat.format(tipoGrad.getDataBollettinoUffReg()));
							
							if(graduatorieMap.get(regione.getCodReg())!=null) {
								TipoGraduatoria grad = graduatorieMap.get(regione.getCodReg());
								graduatoriePrecMap.put(regione.getCodReg(), grad);
							}
							graduatorieMap.put(regione.getCodReg(), tipoGrad);
			    		}
						
			    	}
				}
			}
		}
		catch (GestioneErroriException e) {
			
			logger.error("LookupGraduatoria - recupero informazioni Graduatorie fallito", e);
		}
	}
		
}
