package com.accenture.CCFarm.utility;

public class RepositoryProperties {

	
	public final static String APP_NAME = "app_Name"; 
	public final static String BASE_URL_CATINA  = "BaseUrlCartina"; 
	public final static String BASE_URL_CONFERMA_REGISTRAZIONE  = "BaseUrlConfermaRegistrazione"; 
	public final static String ORA_CHIUSURA_BANDO = "oraChiusuraBando"; 
	
	
	
}
