package com.accenture.CCFarm.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil
{
	//converte una data util in un timestamp sql
	public static java.sql.Timestamp utilDateToSqlTimestamp(java.util.Date utilDate)
	{
		if(utilDate != null)
			return new java.sql.Timestamp(utilDate.getTime());
		else
			return null;
	}
	
	//converte un timestamp sql in una data util
	public static java.util.Date sqlTimestampToUtilDate(java.sql.Timestamp sqlTimestamp)
	{
		if(sqlTimestamp != null)
			return new java.util.Date(sqlTimestamp.getTime());
		else
			return null;
	}
	
	//converte una data util in una sql
	public static java.sql.Date utilDateToSQLDate(java.util.Date utilDate)
	{
		if(utilDate!=null)
			return new java.sql.Date(utilDate.getTime());
		else 
			return null;
	}
	
	//converte una data sql in una util
	public static java.util.Date sqlDateToUtilDate(java.sql.Date sqlDate)
	{	
    	if(sqlDate!=null)
    		return new java.util.Date(sqlDate.getTime());
    	else 
    		return null;
	}
	
	public static int getYearFromDate(java.util.Date date)
	{
		if(date!=null)
		{
			Calendar calendar=Calendar.getInstance();
	        calendar.setTime(date);
	        return calendar.get(Calendar.YEAR);
		}
		return 0;
	}
	
	//ricava timestamp (sql) dell'istante corrente
	public static java.sql.Timestamp getCurrentTimestamp()
	{
		return new java.sql.Timestamp(new java.util.Date().getTime());
	}
	
	public static Date getDataOdierna()
	{
		Calendar calendar=Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
        
	}
	
	public static Date getDataOdiernaConOre()
	{
		Calendar calendar=Calendar.getInstance();
        
        return calendar.getTime();
        
	}
	
	public static int calcolaDifferenzaDate(Date dataInizio, Date dataFine) {
    	
    	if(dataInizio == null || dataFine == null)
    		return 0;
    	
    	return (int) ((dataFine.getTime() - dataInizio.getTime()) / (24 * 60 * 60 * 1000.0));
    }
	
	public static String calcolaDiffDateInGiorniOreMinuti(String dataInizio, String dataFine, String linguaScelta) throws Exception {
        
        String result = "";
        SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
//        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date d1 = null;
        Date d2 = null;
        try {
            d1 = format.parse(dataInizio);
            d2 = format.parse(dataFine);
        } catch (ParseException e) {
            throw new Exception(e);
        }    
        long diff = d2.getTime() - d1.getTime();
        long diffMinutes = diff / (60 * 1000) % 60;
        long diffHours = diff / (60 * 60 * 1000) % 24;
        long diffDays = diff / (24 * 60 * 60 * 1000);
        
        if(diffDays > 0)
        	result += diffDays+" "+StringUtil.getPropertyMessage("sedi.giorni", linguaScelta);
        else if(diffDays == 1)
        	result += diffDays+" "+StringUtil.getPropertyMessage("sedi.giorno", linguaScelta);
        
        if(result.length() > 0) result += " ";
        
        if(diffHours > 0)
        	result += diffHours+" "+StringUtil.getPropertyMessage("sedi.ore", linguaScelta);
        else if(diffHours == 1)
        	result += diffHours+" "+StringUtil.getPropertyMessage("sedi.ora", linguaScelta);
        
        if(result.length() > 0) result += " ";
        
        if(diffMinutes > 0)
        	result += diffMinutes+" "+StringUtil.getPropertyMessage("sedi.minuti", linguaScelta);
        else if(diffMinutes == 1)
        	result += diffMinutes+" "+StringUtil.getPropertyMessage("sedi.minuto", linguaScelta);

        return result;
  }

}
