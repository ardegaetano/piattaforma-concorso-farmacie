package com.accenture.CCFarm.utility;

import org.apache.commons.beanutils.Converter;

public class StringToBooleanCheckConverter implements Converter
{
	public Object convert(Class type,Object value)
	{
		if (value != null && (value instanceof String) && (type == Boolean.class)) 
		{
			String val = (String)value;
	    	Boolean valCheck = val.equals("1") ?  new Boolean(true) : new Boolean(false);
	    	return (valCheck);
	    }
		return value;
	}	
}
