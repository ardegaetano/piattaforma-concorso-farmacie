package com.accenture.CCFarm.utility;

//import org.apache.log4j.Logger;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.Logger;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class HibernateUtil 
{
    
	private static final SessionFactory sessionFactory;

	static 
	{
		try 
		{ 
			
			sessionFactory = new Configuration().configure().buildSessionFactory();
			//Logger.getLogger("HibernateUtil").info("SessionFactory - Creazione del session factory");
		} catch (Throwable ex) {
//			Logger.getLogger("HibernateUtil").error("SessionFactory - Initial SessionFactory creation failed." + ex);
			Logger logger =Logger.getLogger("HibernateUtil");
			StringWriter strWriter = new StringWriter() ;
			PrintWriter printWriter = new PrintWriter(strWriter);
			ex.printStackTrace(printWriter);
			String eccezione = strWriter.toString();
			logger.info("rpxxx :eccezione : " + eccezione);
			throw new ExceptionInInitializerError(ex);
		}
	}

	private static SessionFactory getCurrentSession() {
		Logger logger =Logger.getLogger("HibernateUtil");
		try{
			return (sessionFactory == null ? new Configuration().configure().buildSessionFactory() : sessionFactory);
		}catch (Exception e) {
			StringWriter strWriter = new StringWriter() ;
			PrintWriter printWriter = new PrintWriter(strWriter);
			e.printStackTrace(printWriter);
			String eccezione = strWriter.toString();
			logger.info("rpxxx :eccezione sull'apertura della connessione: " + eccezione);
			throw new ExceptionInInitializerError(e);
			
		}
		
	}
	
	public static Session openSession() {
		Logger logger =Logger.getLogger("HibernateUtil");
		//logger.info("sto aprendo la sessione");
		Session sessioneHb =null; 
		try {
			 sessioneHb = getCurrentSession().openSession();
			
			 //logger.info("ho apERTO la sessione");
				
		} catch (Exception e) {
			StringWriter strWriter = new StringWriter() ;
			PrintWriter printWriter = new PrintWriter(strWriter);
			e.printStackTrace(printWriter);
			String eccezione = strWriter.toString();
			logger.info("rpxxx :eccezione sull'apertura della connessione: " + eccezione);
			throw new ExceptionInInitializerError(e);
			
		}
		return sessioneHb;
	}
	
	/*public static java.sql.Connection getSqlConnection() {
		
		Logger logger =Logger.getLogger("HibernateUtil");
		logger.info("sto aprendo la sessione");
		java.sql.Connection conn = null;
		try {
			 
			 conn = getCurrentSession().openSession().connection();
			
			 logger.info("ho aperto la connessione");
				
		} catch (Exception e) {
			StringWriter strWriter = new StringWriter() ;
			PrintWriter printWriter = new PrintWriter(strWriter);
			e.printStackTrace(printWriter);
			String eccezione = strWriter.toString();
			logger.info("rpxxx :eccezione sull'apertura della connessione: " + eccezione);
			throw new ExceptionInInitializerError(e);
			
		}
		return conn;
		
		return null;
	}*/
}
