package com.accenture.CCFarm.utility;

import org.apache.commons.beanutils.Converter;

public class BooleanToStringCheckConverter implements Converter
{
	public Object convert(Class type,Object value)
	{
		if (value != null && (value instanceof Boolean) && (type == String.class)) 
		{
    		Boolean valCheck = (Boolean)value;
    		String val = (valCheck)? "1" : "0";
    		return (val);
	    }
		return value;
	}
}
