package com.accenture.CCFarm.utility;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class CCFarmLogger {
	
	public static final int TRACE = Level.TRACE_INT;
	public static final int DEBUG = Level.DEBUG_INT;
	public static final int INFO = Level.INFO_INT;
	public static final int WARN = Level.WARN_INT;
	public static final int ERROR = Level.ERROR_INT;
	public static final int FATAL = Level.FATAL_INT;
	
	public static void log(String message, int priority, Class className) {
		Logger logger = Logger.getLogger(className);
		logger.log(Level.toLevel(priority), message);
	}
	
	
}
