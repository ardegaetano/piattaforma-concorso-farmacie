package com.accenture.CCFarm.utility;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

public class JSFUtility
{
	private static final String ALL_FACES_MESSAGES_ID = "allFacesMessages";
	private static Logger logger = CommonLogger.getLogger("JSFUtilityLogger");
	
	public static FacesContext getFacesContext()
	{
		return FacesContext.getCurrentInstance();
	}
	
	private static RequestContext getRequestContext()
	{
		return RequestContext.getCurrentInstance();
	}
	
	public static UIViewRoot getUIViewRoot()
	{
		return getFacesContext().getViewRoot();
	} 
	
	public static String getClientId(String componentId)
	{
	    UIComponent c=findComponent(getUIViewRoot(),componentId);
	    if(c!=null)
	    	return c.getClientId(getFacesContext());
	    else
	    	return null;
	}
	
	public static UIComponent findComponent(UIComponent c,String id)
	{
		if(id.equals(c.getId()))
			return c;
	    
	    Iterator<UIComponent> kids=c.getFacetsAndChildren();
	    while(kids.hasNext())
	    {
	    	UIComponent found=findComponent(kids.next(),id);
	    	if (found!=null)
	    		return found;
	    }
	    return null;
	}
	
	//invoca il refresh della componente specificata
	public static void update(String componentName)
	{
		try
		{
			String clientID=getClientId(componentName);
			if(clientID!=null)
				getRequestContext().update(clientID);
			else
			{
				logger.info("[JSFUtility Update - componente '"+componentName+"' non trovata]");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("[JSFUtility Update - componente '"+componentName+"' non trovata]");
		}
	}
	
	//esegue uno script dal request context corrente
	public static void executeScript(String script)
	{
		try
		{
			getRequestContext().execute(script);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("[JSFUtility executeScript - errore durante l'esecuzione dello script -> '"+script+"']");
		}	
	}
	
	@SuppressWarnings("unchecked")
	//aggiunge un messaggio di notifica nel contesto della pagina (e opzionalmente in sessione)
	public static void addInfoMessage(String intestazione,String corpo,boolean persistente)
	{
		try
		{
			FacesMessage message=new FacesMessage(FacesMessage.SEVERITY_INFO,intestazione,corpo);
			getFacesContext().addMessage(null,message);
			
			//se il flag � impostato a true, salva il messaggio in sessione
			if(persistente)
			{
				Map<String,Object> sessionMap=getFacesContext().getExternalContext().getSessionMap();
		        List<FacesMessage> existingMessages=(List<FacesMessage>)sessionMap.get(ALL_FACES_MESSAGES_ID);
		        
		        //se la lista di messaggi salvati non � stata creata
		        if(existingMessages==null)
		        {
		        	existingMessages=new ArrayList<FacesMessage>();
		        	sessionMap.put(ALL_FACES_MESSAGES_ID,existingMessages);
		        }
		        
		        //aggiunge il messaggio corrente alla lista
		        existingMessages.add(message);
		        
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("[JSFUtility addInfoMessage - errore nell'aggiunta del messaggio '"+intestazione+" - "+corpo+"']");
		}
	}

	//aggiunge un messaggio di warning nel contesto della pagina
	public static void addWarningMessage(String intestazione,String corpo)
	{
		try
		{
			FacesMessage message=new FacesMessage(FacesMessage.SEVERITY_WARN,intestazione,corpo);
			getFacesContext().addMessage(null,message);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("[JSFUtility addWarningMessage - errore nell'aggiunta del messaggio '"+intestazione+" - "+corpo+"']");
		}
	}
	
	//aggiunge un messaggio di warning nel contesto della pagina e scrolla verso la componente che visualizza i messaggi
	public static void addWarningMessage(String intestazione,String corpo,String messagesComponent)
	{
		try
		{
			FacesMessage message=new FacesMessage(FacesMessage.SEVERITY_WARN,intestazione,corpo);
			getFacesContext().addMessage(null,message);
			scrollTo(messagesComponent);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("[JSFUtility addWarningMessage - errore nell'aggiunta del messaggio '"+intestazione+" - "+corpo+"']");
		}
	}
	
	//re-indirizza verso l'URL specificato
	public static void redirect(String url)
	{
		try
		{
			getFacesContext().getExternalContext().redirect(url);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("[JSFUtility redirect - [redirect to "+url+" fallito]");
		}
	}
	
	//smooth scroll to the specified component in the current page
	public static void scrollTo(String componentName)
	{
		try
		{
			getRequestContext().scrollTo(componentName);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error("[JSFUtility scrollTo - [scrollTo "+componentName+" fallito]");
		}
	}
	
	//trova la stringa corrispondente alla chiave specificata, all'interno del message bundle dell'applicazione (linguaggio selezionabile)
    public static String getPropertyMessage(String propertyKey,String language)

    {

            try

            {

                    String messageBundleName=JSFUtility.getFacesContext().getApplication().getMessageBundle();

                    

                    ResourceBundle messageBundle=ResourceBundle.getBundle(messageBundleName,new Locale(language));

            

                    return messageBundle.getString(propertyKey);

            }

            catch(Exception e)

            {

                    logger.error("[JSFUtility getPropertyMessage error]"+" [stack: "+e.getStackTrace()+"]");

                    return null;

            }

    }


	
}
