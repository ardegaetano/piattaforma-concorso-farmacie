package com.accenture.CCFarm.utility;

import org.apache.log4j.Logger;

public class CommonLogger
{

    public static Logger getLogger(String loggerName)
    {	
	return Logger.getLogger(loggerName);
    }

}
