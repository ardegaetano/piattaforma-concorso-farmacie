package com.accenture.CCFarm.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import com.accenture.CCFarm.captcha.CaptchaGenerator;

public class MatricePropertiesDe extends Properties {
	
	
	private static MatricePropertiesDe matricePropertiesDe = null;
	
	private MatricePropertiesDe(){
	
		URL url = CaptchaGenerator.class.getResource("/resources/matrice_de.properties");
	    
		String basePath =url.getPath();
		
       
		try{
			InputStream is = new FileInputStream(url.getPath());
			load(is);
			
		}catch (Exception ex){
				
		}			
		
		
        
	}
	
	
public static MatricePropertiesDe getMatricePropertiesDe(){ 
	
	if(matricePropertiesDe != null){
	 return matricePropertiesDe;
	}else{	
		matricePropertiesDe = new MatricePropertiesDe();
		return matricePropertiesDe;
	}	
}

public static String getMatricePropertiesDe(String nomeProp){ 
	
	if(matricePropertiesDe != null){
	 return matricePropertiesDe.getProperty(nomeProp);
	}else{	
		matricePropertiesDe = new MatricePropertiesDe();
		return matricePropertiesDe.getMatricePropertiesDe(nomeProp);
	}	
}

}
