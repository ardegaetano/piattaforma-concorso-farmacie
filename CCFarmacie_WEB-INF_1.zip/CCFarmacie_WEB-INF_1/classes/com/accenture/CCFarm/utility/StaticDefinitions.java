package com.accenture.CCFarm.utility;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.captcha.CaptchaGenerator;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.LogUtil;


public class StaticDefinitions {
	
	public static String BASE_PATH = null;
	public static Properties MAIL_PROPERTIES = null;
	private static final Logger log = CommonLogger.getLogger("AnnullaDomandeScaduteBatch");
	
	
	public static Properties getAppProperties(){ 
		
		if(MAIL_PROPERTIES != null){
		 return MAIL_PROPERTIES;
		}else{	
			MAIL_PROPERTIES = new Properties();
			
			URL url = CaptchaGenerator.class.getResource("/resources/mailProperties.properties");
		    
			String basePath =url.getPath();
			try{
				InputStream is = new FileInputStream(url.getPath());
				MAIL_PROPERTIES.load(is);
			}catch (Exception ex){
					
			}			
			return MAIL_PROPERTIES;
		}	
	}
	
public static Properties getMailProperties(){ 
		
		if(MAIL_PROPERTIES != null){
		  return MAIL_PROPERTIES;
		}else{	
			MAIL_PROPERTIES = new Properties();
			
			//String basePath="CONF/mailProperties.properties";
		
			try{
				
				InputStream is  = AppProperties.class.getClassLoader().getResourceAsStream("resources/mailProperties.properties");
				//InputStream is = new FileInputStream(basePath);
				MAIL_PROPERTIES.load(is);
			}catch (Exception ex){
				 log.error("Errore Lettura del file di prop per la mail" + LogUtil.printException(ex));	
			}			
			return MAIL_PROPERTIES;
		}	
	}

}

