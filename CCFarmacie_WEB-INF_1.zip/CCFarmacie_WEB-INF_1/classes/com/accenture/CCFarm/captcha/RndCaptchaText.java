package com.accenture.CCFarm.captcha;

import java.security.SecureRandom;
import java.util.Random;

//import org.apache.log4j.Logger;


public class RndCaptchaText {
	//private static Logger log = null;
	public String getText() {
		//log = Logger.getLogger(RndCaptchaText.class);
		try{
		//log.info("RndCaptchaText | getText | START");
		int car = LETTERS.length - 1;
		//log.info("RndCaptchaText | getText | END RETURN : "+LETTERS[GENERATOR.nextInt(car)]+LETTERS[GENERATOR.nextInt(car)]+LETTERS[GENERATOR.nextInt(car)]+LETTERS[GENERATOR.nextInt(car)]+LETTERS[GENERATOR.nextInt(car)]);
		return LETTERS[GENERATOR.nextInt(car)]+LETTERS[GENERATOR.nextInt(car)]+LETTERS[GENERATOR.nextInt(car)]+LETTERS[GENERATOR.nextInt(car)]+LETTERS[GENERATOR.nextInt(car)];
	
	}catch (Exception e) {
		//log.warn("RndCaptchaText | getText | ERROR RETURN NULL");
		return null;
	}
		
	}
	private static final Random GENERATOR = new SecureRandom();
	private static final String LETTERS[] = { "q","w","e","r","t","y","u","i","o","p","l","k","j","h","g","f","d","s","a","z","x","c","v","b","n","m","1","2","3","4","5","6","7","8","9","0" };

}

