package com.accenture.CCFarm.captcha;

import java.awt.Color;
import java.security.SecureRandom;
import java.util.Random;


public class RndColorText {
	//private static Logger log = null;
	public Color[] getColor() {
		//log = Logger.getLogger(RndColorText.class);
		try{
		//log.info("RndCaptchaText | getColor | START");
		int indiceToStart = GENERATOR.nextInt(5);
		Color[] arrayColorToReturn = new Color[COLORS.length];
		int cont = 0;
		for(int i = indiceToStart; i < COLORS.length; i++) {
			arrayColorToReturn[cont] = COLORS[i];
			cont++;
		}
		for(int i = indiceToStart-1; i >= 0; i--){
			arrayColorToReturn[cont] = COLORS[i];
			cont++;
		}
		//log.info("RndColorText | getColor | END RETURN : "+ arrayColorToReturn[0].toString() + arrayColorToReturn[1].toString() + arrayColorToReturn[2].toString() + arrayColorToReturn[3].toString() + arrayColorToReturn[4].toString());
		return arrayColorToReturn;
		}catch (Exception e) {
			//log.warn("RndCaptchaText | getColor | ERROR RETURN NULL");
			return null;
		}
	}

	private static final Random GENERATOR = new SecureRandom();
	private static final Color[] COLORS = {new Color(Integer.parseInt("860a0a",16)), new Color(Integer.parseInt("15842A",16)), new Color(Integer.parseInt("f9093c",16)), new Color(Integer.parseInt("1026b0",16)), new Color(Integer.parseInt("000000",16))};

}