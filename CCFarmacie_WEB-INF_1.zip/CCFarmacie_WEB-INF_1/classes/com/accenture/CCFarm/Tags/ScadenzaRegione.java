package com.accenture.CCFarm.Tags;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import com.accenture.CCFarm.Bean.AbstractBean;
import com.accenture.CCFarm.DAO.DatiBando;

import com.accenture.CCFarm.PageBean.InfoRegCartina;
import com.accenture.CCFarm.action.StatoBandoRegione;
import com.accenture.CCFarm.utility.StringUtil;


public class ScadenzaRegione extends TagSupport
{
	public SimpleDateFormat fs  = new SimpleDateFormat("dd/MM/yyyy");
	public SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss");
	public int sysDataInt = 0;
    public int sysOraInt	=0;
	 
	 public String divContenitore = "";
	 public String divClose = "";
	 public String aCapo= "";
	 public String divWrapMap = "";
	 public String divMap= "";
	 public String divCountDownInfo  = "";
	 public String divCountDownA  = "";
	 public String divCountDownB  = "";
	 public String divInfo= "";
	 public String divLegend= "";
	 public String divHead= "";
	 public String formItalia= "";
	 public String scriptSend= "";
	 
	 public String scriptJQ = "";
	 public String scriptJQCoutDown="";
	 
	 public HashMap mapRegioni =null;
		
	 
	 	String beanColor= "G";
		String beanColorVerde= "V";
		String beanColorBle= "B";
		String beanColorRed= "R";
		String beanColorYellow= "Y";
		
		
	
    @Override
    public int doStartTag() throws JspException
    {

	AbstractBean bean = null;
	bean = (AbstractBean) pageContext.getAttribute("pageBean");
//	pageContext.getRequest().setAttribute("campo", campo);
//	pageContext.getRequest().setAttribute("pageBean", bean);
	String outString = "";
	String lenStr = "";
	
	StatoBandoRegione statoBandoRegione = new StatoBandoRegione();
	HashMap mapRegioni1 = new HashMap();
//	mapRegioni = statoBandoRegione.getInfoRegione();
	mapRegioni = (HashMap) pageContext.getSession().getAttribute("MAP_REGIONE");
//	mapRegioni1 = (HashMap) pageContext.getSession().getAttribute("MAP_REGIONE");
//	pageContext.getSession().setAttribute("MAP_REGIONE", mapRegioni);
	
//	Costrisco Cartina
	
	Date sysDate = new Date (System.currentTimeMillis());
     sysDataInt = trasformaData(sysDate);
     sysOraInt = recuperaOra(sysDate);
	
	Iterator iterator = mapRegioni.keySet().iterator();
	String currentKey;
	String bloccoScadenza="";			
	while (iterator.hasNext()) {
		currentKey = (String) iterator.next();
		InfoRegCartina  infoRegCartina = new InfoRegCartina();
		infoRegCartina=  (InfoRegCartina) mapRegioni.get(currentKey);
		boolean messaggioInScadenza = controllaMSGScadenza(infoRegCartina.getRegioneDatiBando().getDatiBando());
		if (messaggioInScadenza){
			String intestazione="";
			if (infoRegCartina.getRegioneDatiBando().getCodReg().equals("041") || infoRegCartina.getRegioneDatiBando().getCodReg().equals("042")){
				intestazione= "La "+ infoRegCartina.getRegioneDatiBando().getDenominazioneReg();
			} else {
				intestazione= "La Regione  " + infoRegCartina.getRegioneDatiBando().getDenominazioneReg();
			}
			String dataFine= null;
			if(infoRegCartina.getRegioneDatiBando().getDatiBando().getDataFineBando()!=null){
				dataFine =fs.format(infoRegCartina.getRegioneDatiBando().getDatiBando().getDataFineBando());
			}
			
			bloccoScadenza +=  "<div>" +
			                  	"<p>" +
			                  		"<b>- ATTENZIONE</b>: Il giorno <b>" +
			                  	    dataFine +
			                  	    "</b> alle ore <b>18:00</b> la piattaforma chiude l'acquisizione delle domande per <b>"+
			                  	    intestazione +
			                  	    "</b>." +
			                  	"</p>"+
			                  	"</div> ";
		}	
		
	}
	
		
	try
	{
//		outString += formItalia+"\n";
		outString += bloccoScadenza;
//		JspWriter out = pageContext.getOut();
//		out.print(outString);
	    pageContext.getOut().print(outString);
	} catch (IOException e)	{
	    throw new JspException("/WEB-INF/jspTag/inputTextFieldTag.jsp",e);
	}

	return SKIP_BODY;
    }

        

    private boolean controllaMSGScadenza(DatiBando datiBando) {
//		controllo se la registrazione avviene dopo la data chiusura bando
		
	    if (datiBando!=null){
	    	if (datiBando.getStato().equals("1")){
	    		int dataFin = trasformaData(datiBando.getDataFineBando());
	    		int dataFinPiuUno = calcolaData(datiBando.getDataFineBando(), "+");
		    	int oraFinInt = recuperaOra(datiBando.getDataFineBando());
		    	int dataFinMenoUno = calcolaData(datiBando.getDataFineBando(), "-");
//		    	if (sysDataInt>dataFin){
		    	if (sysDataInt>dataFinPiuUno){
//	        	bando scaduto
		        	return false;
		        } else {
//		        	if (sysDataInt==dataFin){
//		        		if (sysOraInt>oraFinInt){
//	//	    	        	bando scaduto
//		    	        	return false;
//		        		} else{
//	//			        	bando in essere
//				        	return true;	
//		        		}
//		        	} else {
//		        		        data fine - 4              data fine + 1       
		        		if (sysDataInt>=dataFinMenoUno && sysDataInt<dataFinPiuUno){
	//	        			bando in essere scadnza �-1 giorno
		        			return true;	
				        } else{
	//		        	bando in essere  controllare se rance -1 
				        	return false;
			        	}	
//		        	}
		        }
	    	} else{
	    		return false;
	    	}
	    } else  {
	    	return false;
	    }
	}

	private int trasformaData(java.util.Date data){
		String dataString = fs.format(data);
		String dataConfert = dataString.substring(6, dataString.length())  +
							 dataString.substring(3, 5)  +
				             dataString.substring(0, 2)  ;
		return Integer.parseInt(dataConfert);
	}
	
	private int recuperaOra(Date data){
		String dataString = StringUtil.dateToString(data,sdf);
		String dataConfert = dataString.substring(13, 15)  +
							 dataString.substring(16, 18)  +
				             dataString.substring(19, 21)  ;
		return Integer.parseInt(dataConfert);
	}
	private int trasformaDataSting(String data){
//		String dataString = fs.format(data);
		String dataConfert = data.substring(6, 10)  +
							 data.substring(3, 5)  +
				             data.substring(0, 2)  ;
		return Integer.parseInt(dataConfert);
	}

	
	private int calcolaData(Date data, String segno){
		
		String dataGregorian = StringUtil.dateToStringDDMMYYYY(data);

		Calendar cal = Calendar.getInstance();
		String result = "";
		try { 
			cal.setTime(data);
			if (segno.equals("-"))
				cal.add(Calendar.DATE, -4);
			if (segno.equals("+"))
				cal.add(Calendar.DATE, +1);
			result = StringUtil.dateToStringDDMMYYYY(cal.getTime()); 
		}
		catch (Exception e)
		{}			
	
		return trasformaDataSting(result);
	}
    
    
    
    
    
    
    
    
}