package com.accenture.CCFarm.Tags;


import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import com.accenture.CCFarm.Bean.AbstractBean;
import com.accenture.CCFarm.PageBean.InfoRegCartina;
import com.accenture.CCFarm.action.StatoBandoRegione;
import com.accenture.CCFarm.utility.LookupGraduatoria;


public class MapItaly extends TagSupport
{
	 public String aosta=""; 
	 public String trentinoTrento="";
	 public String trentinoBolzano="";
	 public String friuli="";
	 public String sardegna="";
	 public String sicilia="";
	 public String calabria="";
	 public String veneto="";
	 public String lombardia="";
	 public String basilicata="";
	 public String campania="";
	 public String puglia="";
	 public String lazio="";
	 public String molise="";
	 public String abruzzo="";
	 public String marche="";
	 public String umbria="";
	 public String toscana="";
	 public String romagna="";
	 public String piemonte="";
	 public String liguria="";
	 
	 public String divContenitore = "";
	 public String divClose = "";
	 public String aCapo= "";
	 public String divWrapMap = "";
	 public String divMap= "";
	 public String divCountDownInfo  = "";
	 public String divCountDownA  = "";
	 public String divCountDownB  = "";
	 public String divInfo= "";
	 public String divLegend= "";
	 public String divHead= "";
	 public String formItalia= "";
	 public String scriptSend= "";
	 
	 public String scriptJQ = "";
	 public String scriptJQCoutDown="";
	 
	 public HashMap mapRegioni =null;
	 public HashMap mapGraduatoriaPubblicata;	
	 public HashMap mapGradPubb;
	 public HashMap mapUltimaGradPubb;
	 
	 
	 	String beanColor= "G";
		String beanColorVerde= "V";
		String beanColorBle= "B";
		String beanColorRed= "R";
		String beanColorYellow= "Y";
		
		
	
    @Override
    public int doStartTag() throws JspException
    {

	AbstractBean bean = null;
	bean = (AbstractBean) pageContext.getAttribute("pageBean");
//	pageContext.getRequest().setAttribute("campo", campo);
//	pageContext.getRequest().setAttribute("pageBean", bean);
	String outString = "";
	String lenStr = "";
	
	StatoBandoRegione statoBandoRegione = new StatoBandoRegione();
//	HashMap mapRegioni = new HashMap();
	mapRegioni = statoBandoRegione.getInfoRegione();
	pageContext.getSession().setAttribute("MAP_REGIONE", mapRegioni);

	//Sezione Graduatoria Pubblicata
	mapUltimaGradPubb = LookupGraduatoria.getGraduatorie();
	//pageContext.getSession().setAttribute(RepositorySession.ULTIMA_GRAD_PUBB_OK, mapUltimaGradPubb);

//	mapGraduatoriaPubblicata = graduatoriaPubblicaRegione.getGraduatoriaList();
//	mapGradPubb  = graduatoriaPubblicaRegione.getHmGradPubOK();
//	pageContext.getSession().setAttribute(RepositorySession.TIPO_GRAD_PUBB, mapGraduatoriaPubblicata);
//	pageContext.getSession().setAttribute(RepositorySession.TIPO_GRAD_PUBB_OK, mapGradPubb);
	
	
	
//	Costrisco Cartina
	preparaDivContenitore();
	//preparaSend();
	//preparaDivRegioni();
	//preparaJQuery();
	
	
	
	Iterator iterator = mapRegioni.keySet().iterator();
	String currentKey;
	String bloccoRegioni="";			
	while (iterator.hasNext()) {
		currentKey = (String) iterator.next();
		InfoRegCartina  infoRegCartina = new InfoRegCartina();
		infoRegCartina=  (InfoRegCartina) mapRegioni.get(currentKey);
		String idRegioneCSSJQuery =  infoRegCartina.getRegioneDatiBando().getNomeRegFile().substring(1, infoRegCartina.getRegioneDatiBando().getNomeRegFile().length()-4);
		String coloreRegine = infoRegCartina.getColoreRegione().toUpperCase()+infoRegCartina.getRegioneDatiBando().getNomeRegFile();
		String href = "";
//		if (infoRegCartina.getColoreRegione().toUpperCase().equals("V") || infoRegCartina.getColoreRegione().toUpperCase().equals("Y")){
		if (!infoRegCartina.getColoreRegione().toUpperCase().equals("G") ){
			href ="href=\"javascript:sendRegion('" + infoRegCartina.getRegioneDatiBando().getCodReg()+"','"+infoRegCartina.getColoreRegione().toUpperCase()+"')\"";
		}
		
		//		bloccoRegioni +="<a href=\"javascript:sendRegion('" + infoRegCartina.getRegioneDatiBando().getCodReg()+"','"+infoRegCartina.getColoreRegione().toUpperCase()+"')\">"+
		bloccoRegioni +="<a "+href+" >"+
				
				"<img src=\"../images/imgCartina/regioni/"+coloreRegine+"\""+ " id=\""+idRegioneCSSJQuery+"\""+
					" class=\"regione\" alt=\""+infoRegCartina.getRegioneDatiBando().getDenominazioneReg()+"\" title=\""+infoRegCartina.getRegioneDatiBando().getDenominazioneReg()+"\" />"+
//				 "<span>"+
//			 		"<img src=\"../images/imgCartina/regioni/"+coloreRegine+"\""+ " alt=\"\" />"+
//			 		"<b>"+infoRegCartina.getRegioneDatiBando().getDenominazioneReg()+"</b>"+
////			 		"<em>Count Down ......"+divCountDownA+"cd_"+idRegioneCSSJQuery+divCountDownB+"</em>"+
//			 		"<em></em>"+
//				"</span>"+
			"</a>"+"\n";
	}
	
		
	try
	{
		outString += formItalia+"\n";
//		outString += scriptSend+"\n";
		outString += divContenitore+"\n";
//		outString += aCapo+aCapo;
//		outString += divHead+"\n";
		outString += divWrapMap+"\n";
		outString += divMap+"\n";
//		outString += divInfo+"\n";
		outString += bloccoRegioni;
		outString += divClose+"\n";
		outString += divClose+"\n";
//		outString += divLegend+"\n";
//		outString += aCapo+aCapo+"\n";
//		outString += scriptJQ+"\n";
//		outString += scriptJQCoutDown+"\n";
		outString += divClose+"\n";
		
//		JspWriter out = pageContext.getOut();
//		out.print(outString);
	    pageContext.getOut().print(outString);
	}
//	catch (BeanException e)
//	{
//	    throw new JspException("/WEB-INF/jspTag/inputTextFieldTag.jsp",e);
//	}
	catch (IOException e)
	{
	    throw new JspException("/WEB-INF/jspTag/inputTextFieldTag.jsp",e);
	}

	return SKIP_BODY;
    }

//    public void preparaSend(){
//    	scriptSend= "<script language=\"javascript\" type=\"text/javascript\">"+"\n"+
//				    	"function sendRegion(idRegione, nomeRegione, coloreRegione){"+"\n"+
//						    	
//				    			"if (coloreRegione == 'G' ){"+"\n"+
//				    				"alert('Bando Regionale non ancora disponibile ');"+"\n"+
//				    			"}"+"\n"+
//				    			"if (coloreRegione == 'R' ){"+"\n"+
//			    				"alert('Bando Regionale Scaduto ');"+"\n"+
//			    				"}"+"\n"+
//			    				
//								"if (coloreRegione == 'V' || coloreRegione == 'Y' ){"+"\n"+
//									"alert('Bando Regionale ');"+"\n"+
//									"document.form_action.ACTION_METHOD.value = \"CaricoBandoRegione\";"+"\n"+
//							    	"alert('rpxxx 1.4 ' + document.form_action.ACTION_METHOD.value );"+"\n"+
//									"document.form_action.ID_REGIONE.value=idRegione;"+"\n"+
////							    	"document.form_action.submit();"+"\n"+
//						    	"}"+"\n"+
//						    	
//                              "alert('REgione '+ idRegione + ' - ' +  nomeRegione  +' - '+ coloreRegione );"+"\n"+
//				    	  "}"+"\n"+
//			    	"</script>"+"\n";
//    	
//    }  
    public void preparaDivContenitore(){
    	 formItalia="<form name=\"form_action\" id=\"form_action\" method=\"post\" action=\"../CaricoBandoRegione\">"+"\n"+
						"<input type=\"hidden\" name=\"ACTION_NAME\" value=\"\">"+"\n"+
	   	 				"<input type=\"hidden\" name=\"ACTION_METHOD\" value=\"\">"+"\n"+ 
						"<input type=\"hidden\" name=\"ACTION_FORM\" value=\"\">"+"\n"+ 
						"<input type=\"hidden\" name=\"ID_REGIONE\" value=\"\">"+"\n"+
						"<input type=\"hidden\" name=\"MAP_REGIONE\" value=\""+mapRegioni+"\">"+"\n"+
					"</form>"+"\n"; 
		
	   	 
    	
    	 divContenitore = "<div id=\"contenitore\">";
	   	 divClose = "</div>";
	   	 aCapo= "<br>";
	   	 divWrapMap = "<div id=\"wrap_mappa\">";
	   	 divMap= "<div id=\"mappa\">";
	   	
	   	 divCountDownInfo  = "<div id=\"countdown_dashboard\">"+
	   						            "<div class=\"dash weeks_dash\">"+
	   						                 "<span class=\"dash_title_info\">sett</span>"+
	   						                  "<div class=\"digit\">0</div>"+
	   						                  "<div class=\"digit\">0</div>"+
	   						             "</div>"+
	   						             "<div class=\"dash days_dash\">"+
	   						                     "<span class=\"dash_title_info\">giorni</span>"+
	   						                     "<div class=\"digit\">0</div>"+
	   						                     "<div class=\"digit\">0</div>"+
	   						             "</div>"+
	   						             "<div class=\"dash hours_dash\">"+
	   						                     "<span class=\"dash_title_info\">ore</span>"+
	   						                     "<div class=\"digit\">0</div>"+
	   						                     "<div class=\"digit\">0</div>"+
	   						             "</div>"+
	   						             "<div class=\"dash minutes_dash\">"+
	   						                     "<span class=\"dash_title_info\">minuti</span>"+
	   						                     "<div class=\"digit\">0</div>"+
	   						                     "<div class=\"digit\">0</div>"+
	   						             "</div>"+
	   						             "<div class=\"dash seconds_dash\">"+
	   						                     "<span class=\"dash_title_info\">secondi</span>"+
	   						                     "<div class=\"digit\">0</div>"+
	   						                     "<div class=\"digit\">0</div>"+
	   						             "</div>"+
	   						   "</div>";
	   	 divCountDownA  = "<div id=\"";
	   	 divCountDownB  = "\">"+
	   					            "<div class=\"dash weeks_dash\">"+
	   					                  "<p class=\"dash_title\">sett</p>"+
	   					                  "<div class=\"digit\">0</div>"+
	   					                  "<div class=\"digit\">0</div>"+
	   					             "</div>"+
	   					             "<div class=\"dash days_dash\">"+
	   					                  "<p class=\"dash_title\">giorni</p>"+
	   					                  "<div class=\"digit\">0</div>"+
	   					                  "<div class=\"digit\">0</div>"+
	   					             "</div>"+
	   					             "<div class=\"dash hours_dash\">"+
	   					                  "<p class=\"dash_title\">ore</p>"+
	   					                  "<div class=\"digit\">0</div>"+
	   					                  "<div class=\"digit\">0</div>"+
	   					             "</div>"+
	   					             "<div class=\"dash minutes_dash\">"+
	   					                  "<p class=\"dash_title\">minuti</p>"+
	   					                  "<div class=\"digit\">0</div>"+
	   					                  "<div class=\"digit\">0</div>"+
	   					             "</div>"+
	   					             "<div class=\"dash seconds_dash\">"+
	   					                  "<p class=\"dash_title\">secondi</p>"+
	   					                  "<div class=\"digit\">0</div>"+
	   					                  "<div class=\"digit\">0</div>"+
	   					             "</div>"+
	   							"</div>";
	
	   	
	   	
	   	
	   	 divInfo= "<div id=\"info\">"+
	   						"<span>"+
//	   							"<img src=\"../images/imgCartina/regioni/italia.gif\" alt=\"\" />"+
////	   							"<b>CSS MAPPA ITALIA</b>"+
////	   							"<em>Coutn Dowon."+divCountDownInfo+"</em>"+
//	   							"<em>Italia.</em>"+
	   						"</span>"+
	   					"</div>";
	   	 divLegend = "<div id=\"wrap_mappa_legend\">"+
						"<div id=\"mappa_legend\">"+
							"<p style=\"color:black;\">*Verde: il bando � attivo</p>"+
							"<p style=\"color:black;\">*Grigio: il bando non � attivo</p>"+
							"<p style=\"color:black;\">*Giallo: la presentazione delle domande � in scadenza</p>"+
							"<p style=\"color:black;\">*Rosso: la presentazione delle domande � scaduta</p>"+
						"</div>"+
					 "</div>";
	   	 divHead= "<div id=\"wrap_mappa_head\">"+
					"<div id=\"mappa_head\">"+
						"BANDO DI CONCORSO PUBBLICO REGIONALE STRAORDINARIO PER TITOLI PER L'ASSEGNAZIONE DELLE SEDI FARMACEUTICHE DISPONIBILI PER IL PRIVATO ESERCIZIO"+
					"</div>"+
				 "</div>";
	 		

    }
    
    public void preparaDivRegioni(){

    	 aosta		  ="<a href=\"#nogo\">"+ 
				 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_aosta.gif\" id=\"aosta\" class=\"regione\" alt=\"Valle d'Aosta\" />"+
				 "<span>"+
					"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_aosta.gif\" alt=\"\" />"+
					"<b>VALLE D'AOSTA</b>"+
					"<em>Count Down Aosta......"+divCountDownA+"cd_aosta"+divCountDownB+"</em>"+
				 "</span>"+
			   "</a>";
		 trentinoTrento ="<a href=\"#nogo\">"+ 
						   "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_trentinoTrento.gif\" id=\"trentinoTrento\" class=\"regione\" alt=\"Trentino Alto Aldige\" />"+
						   "<span>"+
					 		   "<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_trentino.gif\" alt=\"\" />"+
					 		   "<b>TRENTINO ALTO ALDIGE</b>"+
					 		   "<em>Count Down Trentino......"+divCountDownA+"cd_trentinoTrento"+divCountDownB+"</em>"+
						   "</span>"+
					    "</a>";
		
		 trentinoBolzano="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_trentinoBolzano.gif\" id=\"trentinoBolzano\" class=\"regione\" alt=\"Trentino Alto Aldige Provincia di Bolzano\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_trentino.gif\" alt=\"\" />"+
						 		"<b>TRENTINO - Provincia di Bolzano</b>"+
						 		"<em>Count Down Bolzano......"+divCountDownA+"cd_trentinoBolzano"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 friuli	 	   ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_friuli.gif\" id=\"friuli\" class=\"regione\" alt=\"Friuli Venezia Giulia\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_friuli.gif\" alt=\"\" />"+
						 		"<b>FRIULI VENEZIA GIULIA</b>"+
						 		"<em>Count Down Friuli......"+divCountDownA+"cd_friuli"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 sardegna	 	   ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColorRed.toUpperCase()+"_sardegna.gif\" id=\"sardegna\" class=\"regione\" alt=\"Sardegna\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_sardegna.gif\" alt=\"\" />"+
						 		"<b>SARDEGNA</b>"+
						 		"<em>Count Down Sardegna......"+divCountDownA+"cd_sardegna"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 sicilia	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColorRed.toUpperCase()+"_sicilia.gif\" id=\"sicilia\" class=\"regione\" alt=\"Sicilia\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_sicilia.gif\" alt=\"\" />"+
						 		"<b>SICILIA</b>"+
						 		"<em>Count Down Sicilia......"+divCountDownA+"cd_sicilia"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 calabria	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_calabria.gif\" id=\"calabria\" class=\"regione\" alt=\"calabria\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_calabria.gif\" alt=\"\" />"+
						 		"<b>CALABRIA</b>"+
						 		"<em>Count Down Calabria......"+divCountDownA+"cd_calabria"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 veneto	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_veneto.gif\" id=\"veneto\" class=\"regione\" alt=\"Veneto\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_veneto.gif\" alt=\"\" />"+
						 		"<b>VENETO</b>"+
						 		"<em>Count Down Veneto......"+divCountDownA+"cd_veneto"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 lombardia 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_lombardia.gif\" id=\"lombardia\" class=\"regione\" alt=\"Lombardia\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_lombardia.gif\" alt=\"\" />"+
						 		"<b>LOMBARDIA</b>"+
						 		"<em>Count Down Lombardia......"+divCountDownA+"cd_lombardia"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 basilicata 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_basilicata.gif\" id=\"basilicata\" class=\"regione\" alt=\"Basilicata\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_basilicata.gif\" alt=\"\" />"+
						 		"<b>BASILICATA</b>"+
						 		"<em>Count Down Basilicata......"+divCountDownA+"cd_basilicata"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 campania 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_campania.gif\" id=\"campania\" class=\"regione\" alt=\"Campania\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_campania.gif\" alt=\"\" />"+
						 		"<b>CAMPANIA</b>"+
						 		"<em>Count Down Campania......"+divCountDownA+"cd_campania"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 puglia	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_puglia.gif\" id=\"puglia\" class=\"regione\" alt=\"Puglia\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_puglia.gif\" alt=\"\" />"+
						 		"<b>PUGLIA</b>"+
						 		"<em>Count Down Puglia......"+divCountDownA+"cd_puglia"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 lazio	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_lazio.gif\" id=\"lazio\" class=\"regione\" alt=\"Lazio\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_lazio.gif\" alt=\"\" />"+
						 		"<b>LAZIO</b>"+
						 		"<em>Count Down Lazio......"+divCountDownA+"cd_lazio"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 molise	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_molise.gif\" id=\"molise\" class=\"regione\" alt=\"Molise\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_molise.gif\" alt=\"\" />"+
						 		"<b>MOLISE</b>"+
						 		"<em>Count Down Molise......"+divCountDownA+"cd_molise"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 abruzzo	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColorYellow.toUpperCase()+"_abruzzo.gif\" id=\"abruzzo\" class=\"regione\" alt=\"Abruzzo\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_abruzzo.gif\" alt=\"\" />"+
						 		"<b>ABRUZZO</b>"+
						 		"<em>Count Down Abruzzo......"+divCountDownA+"cd_abruzzo"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 marche	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_marche.gif\" id=\"marche\" class=\"regione\" alt=\"Marche\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_marche.gif\" alt=\"\" />"+
						 		"<b>MARCHE</b>"+
						 		"<em>Count Down Marche......"+divCountDownA+"cd_marche"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 umbria	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_umbria.gif\" id=\"umbria\" class=\"regione\" alt=\"Umbria\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_umbria.gif\" alt=\"\" />"+
						 		"<b>UMBRIA</b>"+
						 		"<em>Count Down Umbria......"+divCountDownA+"cd_umbria"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 toscana	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColorYellow.toUpperCase()+"_toscana.gif\" id=\"toscana\" class=\"regione\" alt=\"Toscana\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_toscana.gif\" alt=\"\" />"+
						 		"<b>TOSCANA</b>"+
						 		"<em>Count Down Toscana......"+divCountDownA+"cd_toscana"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 romagna	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_romagna.gif\" id=\"romagna\" class=\"regione\" alt=\"Romagna\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_romagna.gif\" alt=\"\" />"+
						 		"<b>ROMAGNA</b>"+
						 		"<em>Count Down Romagna......"+divCountDownA+"cd_romagna"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 piemonte	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_piemonte.gif\" id=\"piemonte\" class=\"regione\" alt=\"Piemonte\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_piemonte.gif\" alt=\"\" />"+
						 		"<b>PIEMONTE</b>"+
						 		"<em>Count Down Piemonte......"+divCountDownA+"cd_piemonte"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";
		 liguria	 	    ="<a href=\"#nogo\">"+ 
							 "<img src=\"../images/imgCartina/regioni/"+beanColor.toUpperCase()+"_liguria.gif\" id=\"liguria\" class=\"regione\" alt=\"Liguria\" />"+
							 "<span>"+
						 		"<img src=\"../images/imgCartina/regioni/"+beanColorVerde.toUpperCase()+"_liguria.gif\" alt=\"\" />"+
						 		"<b>LIGURIA</b>"+
						 		"<em>Count Down Piemonte......"+divCountDownA+"cd_liguria"+divCountDownB+"</em>"+
							"</span>"+
						"</a>";


    }
    
    public void preparaJQuery(){
    	//script dinamico
    	//
    	//<script language="javascript" type="text/javascript">
    	//jQuery(document).ready(function() {
    	//var data="20130225";
    	//var anno=parseInt(data.substring(0,4));
    	//var mese=parseInt(data.substring(4,6));
    	//var giorno=parseInt(data.substring(6,8));
    	////alert (anno+"/"+mese+"/"+giorno);
    	//$('#countdown_dashboard').countDown({
//    	       targetOffset: {
//    	               'day':          giorno,
//    	               'month':        mese,
//    	               'year':         anno,
//    	               'hour':         0,
//    	               'min':                 0,
//    	               'sec':                 0
//    	       },
//    			omitWeeks: true
    	//});
    	//
    	//
    	//});
    	//</script> 	

      	 scriptJQCoutDown = "<script language=\"javascript\" type=\"text/javascript\">"+
 			    "jQuery(document).ready(function() {"+
 			            "$('#countdown_dashboard').countDown({"+
 			                    "  targetDate: {"+
 			                            "'day':          30,"+
 			                            "'month':         8,"+
 			                            "'year':       2012,"+
 			                            "'hour':         19,"+
 			                            "'min':          30,"+
 			                            "'sec':           0"+
 			                    "}"+
 			            "});"+"\n"+
 	    			    "});"+"\n"+
 	       			"</script>"; 	

    	
    	 scriptJQ = "<script language=\"javascript\" type=\"text/javascript\">"+
    			    "jQuery(document).ready(function() {"+
    			            "$('#countdown_dashboard').countDown({"+
    			                    "  targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':         9,"+
    			                            "'year':       2012,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    			            "});"+"\n"+
    			            "$('#cd_lazio').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':         9,"+
    			                            "'year':       2013,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    	                           "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_puglia').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        11,"+
    			                            "'year':       2014,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    		                "$('#cd_aosta').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        12,"+
    			                            "'year':       2012,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+            
    	                   "$('#cd_trentinoTrento').countDown({"+
    			                    "  targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        1,"+
    			                            "'year':       2013,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_trentinoBolzano').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        3,"+
    			                            "'year':       2014,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_friuli').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        5,"+
    			                            "'year':       2014,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_sardegna').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        7,"+
    			                            "'year':       2014,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_sicilia').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        4,"+
    			                            "'year':       2014,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_calabria').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        12,"+
    			                            "'year':       2014,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_veneto').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        11,"+
    			                            "'year':       2014,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_lombardia').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        3,"+
    			                            "'year':       2013,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_basilicata').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        10,"+
    			                            "'year':       2012,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_campania').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        6,"+
    			                            "'year':       2013,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_molise').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        11,"+
    			                            "'year':       2015,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_abruzzo').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        8,"+
    			                            "'year':       2013,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_marche').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        6,"+
    			                            "'year':       2013,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_umbria').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        12,"+
    			                            "'year':       2013,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_toscana').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        6,"+
    			                            "'year':       2015,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_romagna').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        2,"+
    			                            "'year':       2013,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_piemonte').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        1,"+
    			                            "'year':       2015,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    	                   "$('#cd_liguria').countDown({"+
    			                    " targetDate: {"+
    			                            "'day':           4,"+
    			                            "'month':        8,"+
    			                            "'year':       2015,"+
    			                            "'hour':         11,"+
    			                            "'min':          30,"+
    			                            "'sec':           0"+
    			                    "}"+
    	                   "});"+"\n"+
    			    "});"+"\n"+
    			"</script>"; 	

    	    	
    }

}