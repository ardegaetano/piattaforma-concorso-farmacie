package com.accenture.CCFarm.PDFModulo;


public class AccettazioneRinunciaSedeEntityPdf {
	
	private String codiceRegione;
	
	private String descRegione;
	
	private boolean sedeAccettata;
	
	private String dataInvio;
	
	private String numeroProtocollo;
	
	private String provinciaSedeAssegnata;
	
	private String frazioneSedeAssegnata;
	
	private String progressivoSedeAssegnata;
	
	private String cognome;
	
	private String nome;
	
	private String codiceFiscale;
	
	private String dataNascita;
	
	private String comuneNascita;
	
	private String provinciaNascita;
	
	private String luogoNascitaEstero;
	
	private String codiceStatoNascita;
	
	private String statoNascita;
	
	private String numeroProtocolloDomanda;
	
	private String modalitaPartecipazione;
	
	public AccettazioneRinunciaSedeEntityPdf() {
		
	}

	public AccettazioneRinunciaSedeEntityPdf(String codiceRegione,
			String descRegione, boolean sedeAccettata, String dataInvio,
			String numeroProtocollo, String provinciaSedeAssegnata,
			String frazioneSedeAssegnata, String progressivoSedeAssegnata,
			String cognome, String nome, String codiceFiscale,
			String dataNascita, String comuneNascita, String provinciaNascita,
			String luogoNascitaEstero, String codiceStatoNascita,
			String statoNascita, String numeroProtocolloDomanda,
			String modalitaPartecipazione) {
		this.codiceRegione = codiceRegione;
		this.descRegione = descRegione;
		this.sedeAccettata = sedeAccettata;
		this.dataInvio = dataInvio;
		this.numeroProtocollo = numeroProtocollo;
		this.provinciaSedeAssegnata = provinciaSedeAssegnata;
		this.frazioneSedeAssegnata = frazioneSedeAssegnata;
		this.progressivoSedeAssegnata = progressivoSedeAssegnata;
		this.cognome = cognome;
		this.nome = nome;
		this.codiceFiscale = codiceFiscale;
		this.dataNascita = dataNascita;
		this.comuneNascita = comuneNascita;
		this.provinciaNascita = provinciaNascita;
		this.luogoNascitaEstero = luogoNascitaEstero;
		this.codiceStatoNascita = codiceStatoNascita;
		this.statoNascita = statoNascita;
		this.numeroProtocolloDomanda = numeroProtocolloDomanda;
		this.modalitaPartecipazione = modalitaPartecipazione;
	}

	public String getCodiceRegione() {
		return codiceRegione;
	}

	public void setCodiceRegione(String codiceRegione) {
		this.codiceRegione = codiceRegione;
	}

	public String getDescRegione() {
		return descRegione;
	}

	public void setDescRegione(String descRegione) {
		this.descRegione = descRegione;
	}

	public boolean isSedeAccettata() {
		return sedeAccettata;
	}

	public void setSedeAccettata(boolean sedeAccettata) {
		this.sedeAccettata = sedeAccettata;
	}

	public String getDataInvio() {
		return dataInvio;
	}

	public void setDataInvio(String dataInvio) {
		this.dataInvio = dataInvio;
	}

	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}

	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}

	public String getProvinciaSedeAssegnata() {
		return provinciaSedeAssegnata;
	}

	public void setProvinciaSedeAssegnata(String provinciaSedeAssegnata) {
		this.provinciaSedeAssegnata = provinciaSedeAssegnata;
	}

	public String getFrazioneSedeAssegnata() {
		return frazioneSedeAssegnata;
	}

	public void setFrazioneSedeAssegnata(String frazioneSedeAssegnata) {
		this.frazioneSedeAssegnata = frazioneSedeAssegnata;
	}

	public String getProgressivoSedeAssegnata() {
		return progressivoSedeAssegnata;
	}

	public void setProgressivoSedeAssegnata(String progressivoSedeAssegnata) {
		this.progressivoSedeAssegnata = progressivoSedeAssegnata;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCodiceFiscale() {
		return codiceFiscale;
	}

	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}

	public String getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}

	public String getComuneNascita() {
		return comuneNascita;
	}

	public void setComuneNascita(String comuneNascita) {
		this.comuneNascita = comuneNascita;
	}

	public String getProvinciaNascita() {
		return provinciaNascita;
	}

	public void setProvinciaNascita(String provinciaNascita) {
		this.provinciaNascita = provinciaNascita;
	}

	public String getLuogoNascitaEstero() {
		return luogoNascitaEstero;
	}

	public void setLuogoNascitaEstero(String luogoNascitaEstero) {
		this.luogoNascitaEstero = luogoNascitaEstero;
	}

	public String getCodiceStatoNascita() {
		return codiceStatoNascita;
	}

	public void setCodiceStatoNascita(String codiceStatoNascita) {
		this.codiceStatoNascita = codiceStatoNascita;
	}

	public String getStatoNascita() {
		return statoNascita;
	}

	public void setStatoNascita(String statoNascita) {
		this.statoNascita = statoNascita;
	}

	public String getNumeroProtocolloDomanda() {
		return numeroProtocolloDomanda;
	}

	public void setNumeroProtocolloDomanda(String numeroProtocolloDomanda) {
		this.numeroProtocolloDomanda = numeroProtocolloDomanda;
	}

	public String getModalitaPartecipazione() {
		return modalitaPartecipazione;
	}

	public void setModalitaPartecipazione(String modalitaPartecipazione) {
		this.modalitaPartecipazione = modalitaPartecipazione;
	}

}
