package com.accenture.CCFarm.PDFModulo;

public class DottoratoPDF {
	
	   private String denomDottorato;
	   private String facoltaDottorato;
	   private String univeDottorato;
	   private String luogoDottorato;
	   private String nazioneDottorato;
	   private String dataIniFineDottorato;	   
	   private String seEsteraPrivataDottorato;
	public String getDenomDottorato() {
		return denomDottorato;
	}
	public void setDenomDottorato(String denomDottorato) {
		this.denomDottorato = denomDottorato;
	}
	public String getFacoltaDottorato() {
		return facoltaDottorato;
	}
	public void setFacoltaDottorato(String facoltaDottorato) {
		this.facoltaDottorato = facoltaDottorato;
	}
	public String getUniveDottorato() {
		return univeDottorato;
	}
	public void setUniveDottorato(String univeDottorato) {
		this.univeDottorato = univeDottorato;
	}
	public String getLuogoDottorato() {
		return luogoDottorato;
	}
	public void setLuogoDottorato(String luogoDottorato) {
		this.luogoDottorato = luogoDottorato;
	}
	public String getNazioneDottorato() {
		return nazioneDottorato;
	}
	public void setNazioneDottorato(String nazioneDottorato) {
		this.nazioneDottorato = nazioneDottorato;
	}
	public String getDataIniFineDottorato() {
		return dataIniFineDottorato;
	}
	public void setDataIniFineDottorato(String dataIniFineDottorato) {
		this.dataIniFineDottorato = dataIniFineDottorato;
	}
	public String getSeEsteraPrivataDottorato() {
		return seEsteraPrivataDottorato;
	}
	public void setSeEsteraPrivataDottorato(String seEsteraPrivataDottorato) {
		this.seEsteraPrivataDottorato = seEsteraPrivataDottorato;
	}
	   
	   

}
