package com.accenture.CCFarm.PDFModulo;

public class BorseDiStudio {
	
	   private String denomBStudio;
	   private String facoltaBStudio;
	   private String univeBStudio;
	   private String luogoBStudio;
	   private String nazioneBStudio;
	   private String dataIniFineBStudio;	   
	   private String seEsteraPrivataBStudio;
	   
	public String getDenomBStudio() {
		return denomBStudio;
	}
	public void setDenomBStudio(String denomBStudio) {
		this.denomBStudio = denomBStudio;
	}
	public String getFacoltaBStudio() {
		return facoltaBStudio;
	}
	public void setFacoltaBStudio(String facoltaBStudio) {
		this.facoltaBStudio = facoltaBStudio;
	}
	public String getUniveBStudio() {
		return univeBStudio;
	}
	public void setUniveBStudio(String univeBStudio) {
		this.univeBStudio = univeBStudio;
	}
	public String getLuogoBStudio() {
		return luogoBStudio;
	}
	public void setLuogoBStudio(String luogoBStudio) {
		this.luogoBStudio = luogoBStudio;
	}
	public String getNazioneBStudio() {
		return nazioneBStudio;
	}
	public void setNazioneBStudio(String nazioneBStudio) {
		this.nazioneBStudio = nazioneBStudio;
	}
	public String getDataIniFineBStudio() {
		return dataIniFineBStudio;
	}
	public void setDataIniFineBStudio(String dataIniFineBStudio) {
		this.dataIniFineBStudio = dataIniFineBStudio;
	}
	public String getSeEsteraPrivataBStudio() {
		return seEsteraPrivataBStudio;
	}
	public void setSeEsteraPrivataBStudio(String seEsteraPrivataBStudio) {
		this.seEsteraPrivataBStudio = seEsteraPrivataBStudio;
	}
	   
	   

}
