package com.accenture.CCFarm.PDFModulo;

import java.util.ArrayList;
import java.util.List;

public class EntityPDFRicevuta {

 
	   private String dataInvio;
	   private String dataInvioRettificata;
	   private String descRegUtente;
	   private String modoPartecipa;
	   private String numeroProtocollo;
	   private String numeroProtocolloRettificata;
	   private String cognome;
	   private String nome;
	   private String sesso;
	   private String codifisc;
	   private String dataNascita;
	   private String comuneNascita;
	   private String provNascita;
	   private String localitaEsteraNascita;
	   private String statoNascita;
	   private String estremiDocumento;
	   private String indirizzoResidenza;
	   private String nazioneResidenzaUtente;
	   private String localitaResidenzaEstera;
	   private String provResidenza;
	   private String comuneResidenza;
	   private String capResidenza;
	   private String rifTelefonico;
	   private String emailCertificata;
	   private String appartenenza;
	   private String cittadinanza;
	   private String listaElettorale;
	   private String provIscrizioneFarmacisti;
	   private String provAttualeIscrizioneFarmacisti;
	   private String dataPrimaIscrizioneFarmacisti;
	   private String numeroIscrizioneFarmacisti;
	   private String paBolzano;
	   private String tipoLaurea;
	   private String universitaConseg;
	   private String luogoLaurea;
	   private String dataLaurea;
	   private String votoLaurea;
	   private String baseVotoLaurea;
	   private String lodeVotoLaurea;
	   private String nazioneAbilitazione;
	   private String universitaAbiltazione;
	   private String luogoAbilitazione;
	   private String annoAbilitazione;
	   private String votoAbilitazione;
	   private String baseVotoAbilitazione;
	   private String estremiAbilitazione;
	   private String altraLaurea;
	   private String univAltraLaurea;
	   private String luogoAltraLaurea;
	   private String dataAltraLaurea;
	   private String nazioneAltraLaurea;
	   private String seEsteraPrivataAltraLaurea;
	   private String altraLaureaF;
	   private String univAltraLaureaF;
	   private String luogoAltraLaureaF;
	   private String dataAltraLaureaF;
	   private String nazioneAltraLaureaF;
	   private String seEsteraPrivataAltraLaureaF;	   
	   private List<SpecializzazioniUniversitarie> listaSpeciaUnivers = new ArrayList<SpecializzazioniUniversitarie>();
	   private List<BorseDiStudio> listaBorseDiStudio = new ArrayList<BorseDiStudio>();
	   private List<DottoratoPDF> listaDottorato = new ArrayList<DottoratoPDF>();	   
	   private List<AltriTitoli> listaAltriTitoli = new ArrayList<AltriTitoli>();
	   private List<CorsoDiAggiornamento> listaCorsiAggiornamento = new ArrayList<CorsoDiAggiornamento>();
	   private List<PubblicazioneScentifica> listaPubblicaScentifica = new ArrayList<PubblicazioneScentifica>();
	   private String idoneitaConseguita;
	   private String estremiAtto;
	   private String dataAtto;
	   private String rifIdoneitaNaz;
	   private String annoIdoneitaNaz;
	   private String dataPartenzaCorso;
	   private String dataPubbScient;
	   
	   private List<EsercizioProfessionale> listaEsercizioProfessionale = new ArrayList<EsercizioProfessionale>();

	   
	   private String estremiVersamento;
	   
	   private String dataOperazioneVers;
	   private String ibanVersamento;
	   private String croVersamento;
	   
	   private String dataVersamento;
	   private String numeroUfficio;
	   private String progOperazioneVCY;
	   
	   private String contributoPartecipazione;
	   
	   private List<String> listaDocumentiVersamento = new ArrayList<String>();
	   
		   
	public String getDataPubbScient() {
		return dataPubbScient;
	}
	public void setDataPubbScient(String dataPubbScient) {
		this.dataPubbScient = dataPubbScient;
	}
	public List<PubblicazioneScentifica> getListaPubblicaScentifica() {
		return listaPubblicaScentifica;
	}
	public void setListaPubblicaScentifica(
			List<PubblicazioneScentifica> listaPubblicaScentifica) {
		this.listaPubblicaScentifica = listaPubblicaScentifica;
	}
	public List<CorsoDiAggiornamento> getListaCorsiAggiornamento() {
		return listaCorsiAggiornamento;
	}
	public void setListaCorsiAggiornamento(
			List<CorsoDiAggiornamento> listaCorsiAggiornamento) {
		this.listaCorsiAggiornamento = listaCorsiAggiornamento;
	}
	public List<AltriTitoli> getListaAltriTitoli() {
		return listaAltriTitoli;
	}
	public void setListaAltriTitoli(List<AltriTitoli> listaAltriTitoli) {
		this.listaAltriTitoli = listaAltriTitoli;
	}
	public List<DottoratoPDF> getListaDottorato() {
		return listaDottorato;
	}
	public void setListaDottorato(List<DottoratoPDF> listaDottorato) {
		this.listaDottorato = listaDottorato;
	}
	public List<BorseDiStudio> getListaBorseDiStudio() {
		return listaBorseDiStudio;
	}
	public void setListaBorseDiStudio(List<BorseDiStudio> listaBorseDiStudio) {
		this.listaBorseDiStudio = listaBorseDiStudio;
	}
	public List<SpecializzazioniUniversitarie> getListaSpeciaUnivers() {
		return listaSpeciaUnivers;
	}
	public void setListaSpeciaUnivers(
			List<SpecializzazioniUniversitarie> listaSpeciaUnivers) {
		this.listaSpeciaUnivers = listaSpeciaUnivers;
	}
	public List<String> getListaDocumentiVersamento() {
		return listaDocumentiVersamento;
	}
	public void setListaDocumentiVersamento(List<String> listaDocumentiVersamento) {
		this.listaDocumentiVersamento = listaDocumentiVersamento;
	}
	public String getEstremiVersamento() {
		return estremiVersamento;
	}
	public void setEstremiVersamento(String estremiVersamento) {
		this.estremiVersamento = estremiVersamento;
	}
	public String getDataOperazioneVers() {
		return dataOperazioneVers;
	}
	public void setDataOperazioneVers(String dataOperazioneVers) {
		this.dataOperazioneVers = dataOperazioneVers;
	}
	public String getIbanVersamento() {
		return ibanVersamento;
	}
	public void setIbanVersamento(String ibanVersamento) {
		this.ibanVersamento = ibanVersamento;
	}
	public String getCroVersamento() {
		return croVersamento;
	}
	public void setCroVersamento(String croVersamento) {
		this.croVersamento = croVersamento;
	}
	public String getDataVersamento() {
		return dataVersamento;
	}
	public void setDataVersamento(String dataVersamento) {
		this.dataVersamento = dataVersamento;
	}
	public String getNumeroUfficio() {
		return numeroUfficio;
	}
	public void setNumeroUfficio(String numeroUfficio) {
		this.numeroUfficio = numeroUfficio;
	}
	public String getProgOperazioneVCY() {
		return progOperazioneVCY;
	}
	public void setProgOperazioneVCY(String progOperazioneVCY) {
		this.progOperazioneVCY = progOperazioneVCY;
	}
	
	public String getContributoPartecipazione() {
		return contributoPartecipazione;
	}
	public void setContributoPartecipazione(String contributoPartecipazione) {
		this.contributoPartecipazione = contributoPartecipazione;
	}
	
	
	public List<EsercizioProfessionale> getListaEsercizioProfessionale() {
		return listaEsercizioProfessionale;
	}
	public void setListaEsercizioProfessionale(
			List<EsercizioProfessionale> listaEsercizioProfessionale) {
		this.listaEsercizioProfessionale = listaEsercizioProfessionale;
	}
	public String getDataPartenzaCorso() {
		return dataPartenzaCorso;
	}
	public void setDataPartenzaCorso(String dataPartenzaCorso) {
		this.dataPartenzaCorso = dataPartenzaCorso;
	}

	public String getRifIdoneitaNaz() {
		return rifIdoneitaNaz;
	}
	public void setRifIdoneitaNaz(String rifIdoneitaNaz) {
		this.rifIdoneitaNaz = rifIdoneitaNaz;
	}
	public String getAnnoIdoneitaNaz() {
		return annoIdoneitaNaz;
	}
	public void setAnnoIdoneitaNaz(String annoIdoneitaNaz) {
		this.annoIdoneitaNaz = annoIdoneitaNaz;
	}
	public String getIdoneitaConseguita() {
		return idoneitaConseguita;
	}
	public void setIdoneitaConseguita(String idoneitaConseguita) {
		this.idoneitaConseguita = idoneitaConseguita;
	}
	public String getEstremiAtto() {
		return estremiAtto;
	}
	public void setEstremiAtto(String estremiAtto) {
		this.estremiAtto = estremiAtto;
	}
	public String getDataAtto() {
		return dataAtto;
	}
	public void setDataAtto(String dataAtto) {
		this.dataAtto = dataAtto;
	}

	public String getAltraLaureaF() {
		return altraLaureaF;
	}
	public void setAltraLaureaF(String altraLaureaF) {
		this.altraLaureaF = altraLaureaF;
	}
	public String getUnivAltraLaureaF() {
		return univAltraLaureaF;
	}
	public void setUnivAltraLaureaF(String univAltraLaureaF) {
		this.univAltraLaureaF = univAltraLaureaF;
	}
	public String getLuogoAltraLaureaF() {
		return luogoAltraLaureaF;
	}
	public void setLuogoAltraLaureaF(String luogoAltraLaureaF) {
		this.luogoAltraLaureaF = luogoAltraLaureaF;
	}
	public String getDataAltraLaureaF() {
		return dataAltraLaureaF;
	}
	public void setDataAltraLaureaF(String dataAltraLaureaF) {
		this.dataAltraLaureaF = dataAltraLaureaF;
	}
	public String getNazioneAltraLaureaF() {
		return nazioneAltraLaureaF;
	}
	public void setNazioneAltraLaureaF(String nazioneAltraLaureaF) {
		this.nazioneAltraLaureaF = nazioneAltraLaureaF;
	}
	public String getSeEsteraPrivataAltraLaureaF() {
		return seEsteraPrivataAltraLaureaF;
	}
	public void setSeEsteraPrivataAltraLaureaF(String seEsteraPrivataAltraLaureaF) {
		this.seEsteraPrivataAltraLaureaF = seEsteraPrivataAltraLaureaF;
	}
	public String getAltraLaurea() {
		return altraLaurea;
	}
	public void setAltraLaurea(String altraLaurea) {
		this.altraLaurea = altraLaurea;
	}
	public String getUnivAltraLaurea() {
		return univAltraLaurea;
	}
	public void setUnivAltraLaurea(String univAltraLaurea) {
		this.univAltraLaurea = univAltraLaurea;
	}
	public String getLuogoAltraLaurea() {
		return luogoAltraLaurea;
	}
	public void setLuogoAltraLaurea(String luogoAltraLaurea) {
		this.luogoAltraLaurea = luogoAltraLaurea;
	}
	public String getDataAltraLaurea() {
		return dataAltraLaurea;
	}
	public void setDataAltraLaurea(String dataAltraLaurea) {
		this.dataAltraLaurea = dataAltraLaurea;
	}
	public String getNazioneAltraLaurea() {
		return nazioneAltraLaurea;
	}
	public void setNazioneAltraLaurea(String nazioneAltraLaurea) {
		this.nazioneAltraLaurea = nazioneAltraLaurea;
	}
	public String getSeEsteraPrivataAltraLaurea() {
		return seEsteraPrivataAltraLaurea;
	}
	public void setSeEsteraPrivataAltraLaurea(String seEsteraPrivataAltraLaurea) {
		this.seEsteraPrivataAltraLaurea = seEsteraPrivataAltraLaurea;
	}
	public String getNazioneAbilitazione() {
		return nazioneAbilitazione;
	}
	public void setNazioneAbilitazione(String nazioneAbilitazione) {
		this.nazioneAbilitazione = nazioneAbilitazione;
	}
	public String getUniversitaAbiltazione() {
		return universitaAbiltazione;
	}
	public void setUniversitaAbiltazione(String universitaAbiltazione) {
		this.universitaAbiltazione = universitaAbiltazione;
	}
	public String getLuogoAbilitazione() {
		return luogoAbilitazione;
	}
	public void setLuogoAbilitazione(String luogoAbilitazione) {
		this.luogoAbilitazione = luogoAbilitazione;
	}

	
	public String getAnnoAbilitazione() {
		return annoAbilitazione;
	}
	public void setAnnoAbilitazione(String annoAbilitazione) {
		this.annoAbilitazione = annoAbilitazione;
	}
	public String getVotoAbilitazione() {
		return votoAbilitazione;
	}
	public void setVotoAbilitazione(String votoAbilitazione) {
		this.votoAbilitazione = votoAbilitazione;
	}
	public String getEstremiAbilitazione() {
		return estremiAbilitazione;
	}
	public void setEstremiAbilitazione(String estremiAbilitazione) {
		this.estremiAbilitazione = estremiAbilitazione;
	}
	public String getTipoLaurea() {
		return tipoLaurea;
	}
	public void setTipoLaurea(String tipoLaurea) {
		this.tipoLaurea = tipoLaurea;
	}
	public String getUniversitaConseg() {
		return universitaConseg;
	}
	public void setUniversitaConseg(String universitaConseg) {
		this.universitaConseg = universitaConseg;
	}
	public String getLuogoLaurea() {
		return luogoLaurea;
	}
	public void setLuogoLaurea(String luogoLaurea) {
		this.luogoLaurea = luogoLaurea;
	}
	public String getDataLaurea() {
		return dataLaurea;
	}
	public void setDataLaurea(String dataLaurea) {
		this.dataLaurea = dataLaurea;
	}
	public String getVotoLaurea() {
		return votoLaurea;
	}
	public void setVotoLaurea(String votoLaurea) {
		this.votoLaurea = votoLaurea;
	}
	public String getPaBolzano() {
		return paBolzano;
	}
	public void setPaBolzano(String paBolzano) {
		this.paBolzano = paBolzano;
	}
	public String getProvIscrizioneFarmacisti() {
		return provIscrizioneFarmacisti;
	}
	public void setProvIscrizioneFarmacisti(String provIscrizioneFarmacisti) {
		this.provIscrizioneFarmacisti = provIscrizioneFarmacisti;
	}
	public String getDataPrimaIscrizioneFarmacisti() {
		return dataPrimaIscrizioneFarmacisti;
	}
	public void setDataPrimaIscrizioneFarmacisti(
			String dataPrimaIscrizioneFarmacisti) {
		this.dataPrimaIscrizioneFarmacisti = dataPrimaIscrizioneFarmacisti;
	}
	public String getNumeroIscrizioneFarmacisti() {
		return numeroIscrizioneFarmacisti;
	}
	public void setNumeroIscrizioneFarmacisti(String numeroIscrizioneFarmacisti) {
		this.numeroIscrizioneFarmacisti = numeroIscrizioneFarmacisti;
	}
	public String getCittadinanza() {
		return cittadinanza;
	}
	public void setCittadinanza(String cittadinanza) {
		this.cittadinanza = cittadinanza;
	}
	public String getListaElettorale() {
		return listaElettorale;
	}
	public void setListaElettorale(String listaElettorale) {
		this.listaElettorale = listaElettorale;
	}
	public String getAppartenenza() {
		return appartenenza;
	}
	public void setAppartenenza(String appartenenza) {
		this.appartenenza = appartenenza;
	}
	public String getIndirizzoResidenza() {
		return indirizzoResidenza;
	}
	public void setIndirizzoResidenza(String indirizzoResidenza) {
		this.indirizzoResidenza = indirizzoResidenza;
	}
	public String getProvResidenza() {
		return provResidenza;
	}
	public void setProvResidenza(String provResidenza) {
		this.provResidenza = provResidenza;
	}
	public String getComuneResidenza() {
		return comuneResidenza;
	}
	public void setComuneResidenza(String comuneResidenza) {
		this.comuneResidenza = comuneResidenza;
	}
	public String getCapResidenza() {
		return capResidenza;
	}
	public void setCapResidenza(String capResidenza) {
		this.capResidenza = capResidenza;
	}
	public String getRifTelefonico() {
		return rifTelefonico;
	}
	public void setRifTelefonico(String rifTelefonico) {
		this.rifTelefonico = rifTelefonico;
	}
	public String getEmailCertificata() {
		return emailCertificata;
	}
	public void setEmailCertificata(String emailCertificata) {
		this.emailCertificata = emailCertificata;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSesso() {
		return sesso;
	}
	public void setSesso(String sesso) {
		this.sesso = sesso;
	}
	public String getCodifisc() {
		return codifisc;
	}
	public void setCodifisc(String codifisc) {
		this.codifisc = codifisc;
	}
	public String getDataNascita() {
		return dataNascita;
	}
	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}
	public String getComuneNascita() {
		return comuneNascita;
	}
	public void setComuneNascita(String comuneNascita) {
		this.comuneNascita = comuneNascita;
	}
	public String getProvNascita() {
		return provNascita;
	}
	public void setProvNascita(String provNascita) {
		this.provNascita = provNascita;
	}

	public String getModoPartecipa() {
		return modoPartecipa;
	}
	public void setModoPartecipa(String modoPartecipa) {
		this.modoPartecipa = modoPartecipa;
	}
	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}
	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}
	public String getDataInvio() {
		return dataInvio;
	}
	public void setDataInvio(String dataInvio) {
		this.dataInvio = dataInvio;
	}
	public String getDescRegUtente() {
		return descRegUtente;
	}
	public void setDescRegUtente(String descRegUtente) {
		this.descRegUtente = descRegUtente;
	}
	public String getLocalitaEsteraNascita() {
		return localitaEsteraNascita;
	}
	public void setLocalitaEsteraNascita(String localitaEsteraNascita) {
		this.localitaEsteraNascita = localitaEsteraNascita;
	}
	public String getStatoNascita() {
		return statoNascita;
	}
	public void setStatoNascita(String statoNascita) {
		this.statoNascita = statoNascita;
	}
	public String getEstremiDocumento() {
		return estremiDocumento;
	}
	public void setEstremiDocumento(String estremiDocumento) {
		this.estremiDocumento = estremiDocumento;
	}
	public String getBaseVotoLaurea() {
		return baseVotoLaurea;
	}
	public void setBaseVotoLaurea(String baseVotoLaurea) {
		this.baseVotoLaurea = baseVotoLaurea;
	}
	public String getBaseVotoAbilitazione() {
		return baseVotoAbilitazione;
	}
	public void setBaseVotoAbilitazione(String baseVotoAbilitazione) {
		this.baseVotoAbilitazione = baseVotoAbilitazione;
	}
	public String getLodeVotoLaurea() {
		return lodeVotoLaurea;
	}
	public void setLodeVotoLaurea(String lodeVotoLaurea) {
		this.lodeVotoLaurea = lodeVotoLaurea;
	}
	public String getDataInvioRettificata() {
		return dataInvioRettificata;
	}
	public void setDataInvioRettificata(String dataInvioRettificata) {
		this.dataInvioRettificata = dataInvioRettificata;
	}
	public String getNumeroProtocolloRettificata() {
		return numeroProtocolloRettificata;
	}
	public void setNumeroProtocolloRettificata(String numeroProtocolloRettificata) {
		this.numeroProtocolloRettificata = numeroProtocolloRettificata;
	}
	public String getNazioneResidenzaUtente() {
		return nazioneResidenzaUtente;
	}
	public void setNazioneResidenzaUtente(String nazioneResidenzaUtente) {
		this.nazioneResidenzaUtente = nazioneResidenzaUtente;
	}
	public String getLocalitaResidenzaEstera() {
		return localitaResidenzaEstera;
	}
	public void setLocalitaResidenzaEstera(String localitaResidenzaEstera) {
		this.localitaResidenzaEstera = localitaResidenzaEstera;
	}
	public String getProvAttualeIscrizioneFarmacisti() {
		return provAttualeIscrizioneFarmacisti;
	}
	public void setProvAttualeIscrizioneFarmacisti(
			String provAttualeIscrizioneFarmacisti) {
		this.provAttualeIscrizioneFarmacisti = provAttualeIscrizioneFarmacisti;
	}
	
	
	
	
}
