package com.accenture.CCFarm.PDFModulo;

public class AltriTitoli {
	
	   private String titoloAltro;
	   private String durataAltro;
	   private String rilasciatoDaAltro;
	   private String dataRilascio;
	   private String esitoFinaleAltro;
	   private String noteAltro;	   
	   private String seEsteraPrivataAltro;
	public String getTitoloAltro() {
		return titoloAltro;
	}
	public void setTitoloAltro(String titoloAltro) {
		this.titoloAltro = titoloAltro;
	}
	public String getDurataAltro() {
		return durataAltro;
	}
	public void setDurataAltro(String durataAltro) {
		this.durataAltro = durataAltro;
	}
	public String getRilasciatoDaAltro() {
		return rilasciatoDaAltro;
	}
	public void setRilasciatoDaAltro(String rilasciatoDaAltro) {
		this.rilasciatoDaAltro = rilasciatoDaAltro;
	}
	public String getDataRilascio() {
		return dataRilascio;
	}
	public void setDataRilascio(String dataRilascio) {
		this.dataRilascio = dataRilascio;
	}
	public String getEsitoFinaleAltro() {
		return esitoFinaleAltro;
	}
	public void setEsitoFinaleAltro(String esitoFinaleAltro) {
		this.esitoFinaleAltro = esitoFinaleAltro;
	}
	public String getNoteAltro() {
		return noteAltro;
	}
	public void setNoteAltro(String noteAltro) {
		this.noteAltro = noteAltro;
	}
	public String getSeEsteraPrivataAltro() {
		return seEsteraPrivataAltro;
	}
	public void setSeEsteraPrivataAltro(String seEsteraPrivataAltro) {
		this.seEsteraPrivataAltro = seEsteraPrivataAltro;
	}
	   
	   

}
