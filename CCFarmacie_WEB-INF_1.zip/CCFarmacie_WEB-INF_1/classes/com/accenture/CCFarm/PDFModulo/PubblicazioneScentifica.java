package com.accenture.CCFarm.PDFModulo;

public class PubblicazioneScentifica {

	private String tipoPubblic;
	private String autorePubb;
	private String dataPubblicazione;
	private String titoloStudio;
	private String editoreStudio;
	private String isbn;
	
	
	public String getDataPubblicazione() {
		return dataPubblicazione;
	}
	public void setDataPubblicazione(String dataPubblicazione) {
		this.dataPubblicazione = dataPubblicazione;
	}
	public String getTipoPubblic() {
		return tipoPubblic;
	}
	public void setTipoPubblic(String tipoPubblic) {
		this.tipoPubblic = tipoPubblic;
	}
	public String getAutorePubb() {
		return autorePubb;
	}
	public void setAutorePubb(String autorePubb) {
		this.autorePubb = autorePubb;
	}

	public String getTitoloStudio() {
		return titoloStudio;
	}
	public void setTitoloStudio(String titoloStudio) {
		this.titoloStudio = titoloStudio;
	}
	public String getEditoreStudio() {
		return editoreStudio;
	}
	public void setEditoreStudio(String editoreStudio) {
		this.editoreStudio = editoreStudio;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	
}


