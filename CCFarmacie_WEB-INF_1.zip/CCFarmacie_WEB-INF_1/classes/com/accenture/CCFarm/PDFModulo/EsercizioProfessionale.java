package com.accenture.CCFarm.PDFModulo;

public class EsercizioProfessionale {
	
	   private String dalTitoloProf;
	   private String alTitoloProf;
	   private String modoTitoloProf;
	   private String ruoloTitoloProf;
	   private String tipoStruttura;
	   private String denomStruttura;
	   private String indiStruttura;
	   
	   private String capStruttura;
	   
	   private String regioneStruttura;
	   private String provStruttura;
	   private String comStruttura;
	   private String aslRiferimento;
	   private String farmRurale;
	
	public String getDalTitoloProf() {
		return dalTitoloProf;
	}
	public void setDalTitoloProf(String dalTitoloProf) {
		this.dalTitoloProf = dalTitoloProf;
	}
	public String getAlTitoloProf() {
		return alTitoloProf;
	}
	public void setAlTitoloProf(String alTitoloProf) {
		this.alTitoloProf = alTitoloProf;
	}
	public String getModoTitoloProf() {
		return modoTitoloProf;
	}
	public void setModoTitoloProf(String modoTitoloProf) {
		this.modoTitoloProf = modoTitoloProf;
	}
	public String getRuoloTitoloProf() {
		return ruoloTitoloProf;
	}
	public void setRuoloTitoloProf(String ruoloTitoloProf) {
		this.ruoloTitoloProf = ruoloTitoloProf;
	}
	public String getTipoStruttura() {
		return tipoStruttura;
	}
	public void setTipoStruttura(String tipoStruttura) {
		this.tipoStruttura = tipoStruttura;
	}
	public String getDenomStruttura() {
		return denomStruttura;
	}
	public void setDenomStruttura(String denomStruttura) {
		this.denomStruttura = denomStruttura;
	}
	public String getIndiStruttura() {
		return indiStruttura;
	}
	public void setIndiStruttura(String indiStruttura) {
		this.indiStruttura = indiStruttura;
	}
	public String getCapStruttura() {
		return capStruttura;
	}
	public void setCapStruttura(String capStruttura) {
		this.capStruttura = capStruttura;
	}
	public String getRegioneStruttura() {
		return regioneStruttura;
	}
	public void setRegioneStruttura(String regioneStruttura) {
		this.regioneStruttura = regioneStruttura;
	}
	public String getProvStruttura() {
		return provStruttura;
	}
	public void setProvStruttura(String provStruttura) {
		this.provStruttura = provStruttura;
	}
	public String getComStruttura() {
		return comStruttura;
	}
	public void setComStruttura(String comStruttura) {
		this.comStruttura = comStruttura;
	}
	public String getAslRiferimento() {
		return aslRiferimento;
	}
	public void setAslRiferimento(String aslRiferimento) {
		this.aslRiferimento = aslRiferimento;
	}
	public String getFarmRurale() {
		return farmRurale;
	}
	public void setFarmRurale(String farmRurale) {
		this.farmRurale = farmRurale;
	}
	   
	   
	   
	

	   

}
