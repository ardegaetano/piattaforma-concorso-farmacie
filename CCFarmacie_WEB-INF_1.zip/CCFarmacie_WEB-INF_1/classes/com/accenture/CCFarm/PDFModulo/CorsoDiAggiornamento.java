package com.accenture.CCFarm.PDFModulo;

public class CorsoDiAggiornamento {
	
	   private String titoloAggCorso;
	   private String organizzatoAggCorso;
	   private String giornoPeridoAggCorso;
	   private String totaleOreEsame;
	   private String esitoEsameSuperato;
	   private String seEsteroPrivatoEsame;
	public String getTitoloAggCorso() {
		return titoloAggCorso;
	}
	public void setTitoloAggCorso(String titoloAggCorso) {
		this.titoloAggCorso = titoloAggCorso;
	}
	public String getOrganizzatoAggCorso() {
		return organizzatoAggCorso;
	}
	public void setOrganizzatoAggCorso(String organizzatoAggCorso) {
		this.organizzatoAggCorso = organizzatoAggCorso;
	}
	public String getGiornoPeridoAggCorso() {
		return giornoPeridoAggCorso;
	}
	public void setGiornoPeridoAggCorso(String giornoPeridoAggCorso) {
		this.giornoPeridoAggCorso = giornoPeridoAggCorso;
	}
	public String getTotaleOreEsame() {
		return totaleOreEsame;
	}
	public void setTotaleOreEsame(String totaleOreEsame) {
		this.totaleOreEsame = totaleOreEsame;
	}
	public String getEsitoEsameSuperato() {
		return esitoEsameSuperato;
	}
	public void setEsitoEsameSuperato(String esitoEsameSuperato) {
		this.esitoEsameSuperato = esitoEsameSuperato;
	}
	public String getSeEsteroPrivatoEsame() {
		return seEsteroPrivatoEsame;
	}
	public void setSeEsteroPrivatoEsame(String seEsteroPrivatoEsame) {
		this.seEsteroPrivatoEsame = seEsteroPrivatoEsame;
	}
	   
	   

}
