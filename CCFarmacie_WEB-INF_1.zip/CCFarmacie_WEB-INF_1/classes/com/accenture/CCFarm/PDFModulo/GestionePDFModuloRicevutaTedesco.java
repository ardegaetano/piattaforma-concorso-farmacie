package com.accenture.CCFarm.PDFModulo;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Level;

import com.accenture.CCFarm.DAO.AltraLaurea;
import com.accenture.CCFarm.DAO.AltraLaureaBis;
import com.accenture.CCFarm.DAO.AltraLaureaBisHome;
import com.accenture.CCFarm.DAO.AltraLaureaHome;
import com.accenture.CCFarm.DAO.AltroTitolo;
import com.accenture.CCFarm.DAO.AltroTitoloHome;
import com.accenture.CCFarm.DAO.BorsaStudio;
import com.accenture.CCFarm.DAO.BorsaStudioHome;
import com.accenture.CCFarm.DAO.CandidaturaHome;
import com.accenture.CCFarm.DAO.CorsoAggiornamento;
import com.accenture.CCFarm.DAO.CorsoAggiornamentoHome;
import com.accenture.CCFarm.DAO.DatiBando;
import com.accenture.CCFarm.DAO.DatiBandoHome;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutiva;
import com.accenture.CCFarm.DAO.DichiarazioneSostitutivaHome;
import com.accenture.CCFarm.DAO.Documento;
import com.accenture.CCFarm.DAO.DocumentoHome;
import com.accenture.CCFarm.DAO.Dottorato;
import com.accenture.CCFarm.DAO.DottoratoHome;
import com.accenture.CCFarm.DAO.EsercizioProf;
import com.accenture.CCFarm.DAO.EsercizioProfHome;
import com.accenture.CCFarm.DAO.Idoneita;
import com.accenture.CCFarm.DAO.IdoneitaHome;
import com.accenture.CCFarm.DAO.LogIn;
import com.accenture.CCFarm.DAO.LogInHome;
import com.accenture.CCFarm.DAO.Pubblicazione;
import com.accenture.CCFarm.DAO.PubblicazioneHome;
import com.accenture.CCFarm.DAO.Regione;
import com.accenture.CCFarm.DAO.RegioneHome;
import com.accenture.CCFarm.DAO.RequisitiMinimi;
import com.accenture.CCFarm.DAO.RequisitiMinimiHome;
import com.accenture.CCFarm.DAO.Ricevute;
import com.accenture.CCFarm.DAO.RicevuteHome;
import com.accenture.CCFarm.DAO.RicevuteId;
import com.accenture.CCFarm.DAO.Specializzazione;
import com.accenture.CCFarm.DAO.SpecializzazioneHome;
import com.accenture.CCFarm.DAO.Utente;
import com.accenture.CCFarm.DAO.UtenteCandidatura;
import com.accenture.CCFarm.DAO.ValoriCodice;
import com.accenture.CCFarm.DAO.ValoriCodiceHome;
import com.accenture.CCFarm.DAO.ValoriCodiceId;
import com.accenture.CCFarm.PageBean.Domanda;
import com.accenture.CCFarm.captcha.CaptchaGenerator;
import com.accenture.CCFarm.utility.CCFarmLogger;
import com.accenture.CCFarm.utility.CaricaRuoli;
import com.accenture.CCFarm.utility.Localita;
import com.accenture.CCFarm.utility.MatricePropertiesDe;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class GestionePDFModuloRicevutaTedesco {

	

	final static Font fonts12_bold = new Font(FontFamily.HELVETICA, 12, Font.BOLD);
	final static Font fonts10_normal = new Font(FontFamily.HELVETICA, 10, Font.NORMAL);
	final static Font fonts10_bold = new Font(FontFamily.HELVETICA, 10, Font.BOLD);
	final static Font fonts6_italic = new Font(FontFamily.HELVETICA, 6, Font.BOLD + Font.ITALIC);
	final static Font fonts6_normal = new Font(FontFamily.HELVETICA, 6, Font.NORMAL);
	final static Font fonts8_normal = new Font(FontFamily.HELVETICA, 8, Font.NORMAL);
	final static Font fonts8_bold = new Font(FontFamily.HELVETICA, 8, Font.BOLD);
	
	private  String dateInvio = "";
	private byte[] imgRicevutaPDF;
	private static final int IMG_WIDTH = 100;
	private static final int IMG_HEIGHT = 100;
	private static final int LIMITE_SALTO_PAGINA = 120;
	private static final int POS_RIGA_SALTO_PAGINA = 25;
	public  int nriga_posizione = 840;
	private  Properties bodyRicevuta = new Properties();
	private  EntityPDFRicevuta entityPDFRicevuta = new EntityPDFRicevuta();
	public  List<EntityPDFRicevuta> listaEntityPDFRicevuta = new ArrayList<EntityPDFRicevuta>();
	public  int totale_pagine = 0;
	public  boolean contaLepagine = true;
	public  int totale_pagine_stampate = 0;
	public  boolean seOggetto = true;
	private  Document documentoPDF = new Document();
	private  Regione regione = new Regione();
	private  RegioneHome regioneDAO = new RegioneHome();
	private  UtenteCandidatura uteCandi = new UtenteCandidatura();
	private  CandidaturaHome candidaturaHome = new CandidaturaHome();
	private  RequisitiMinimi requiMinimi = new RequisitiMinimi();
	private  RequisitiMinimiHome requiMinimiDAO = new RequisitiMinimiHome();
	private  LogIn login = new LogIn();
	private  LogInHome logInDAO = new LogInHome();
	private  AltraLaurea altraLaurea = new AltraLaurea();
	private  AltraLaureaHome altraLaureaDAO = new AltraLaureaHome();
	private  AltraLaureaBis altraLaureaBis = new AltraLaureaBis();
	private  AltraLaureaBisHome altraLaureaBisDAO = new AltraLaureaBisHome();
	private  List<Specializzazione> listSpecializzazione = new ArrayList<Specializzazione>();
	private  SpecializzazioneHome specializzazioneDAO = new SpecializzazioneHome();
	private  List<BorsaStudio> listBorsaStudio = new ArrayList<BorsaStudio>();
	private  BorsaStudioHome borsaStudioDAO = new BorsaStudioHome();
	private  List<Dottorato> listDottorato = new ArrayList<Dottorato>();
	private  DottoratoHome dottoratoDAO = new DottoratoHome();
	private  List<AltroTitolo> listAltriTitolo = new ArrayList<AltroTitolo>();
	private  AltroTitoloHome altroTitoloDAO = new AltroTitoloHome();
	private  Idoneita idoneita = new Idoneita();
	private  IdoneitaHome ideoneitaDAO = new IdoneitaHome();
	private  List<CorsoAggiornamento> listCorsoAggiornamento = new ArrayList<CorsoAggiornamento>();
	private  CorsoAggiornamentoHome corsoAggiornamentoDAO = new CorsoAggiornamentoHome();
	private  List<Pubblicazione> listPubblicazione = new ArrayList<Pubblicazione>();
	private  PubblicazioneHome pubblicazioneDAO = new PubblicazioneHome();
	private  List<EsercizioProf> listEsercizioProf = new ArrayList<EsercizioProf>();
	private  EsercizioProf esercizioProf = new EsercizioProf();
	private  EsercizioProfHome esercizioProfDAO = new EsercizioProfHome();
	private  DichiarazioneSostitutiva dichiarazioneSostitutiva = new DichiarazioneSostitutiva();
	private  DichiarazioneSostitutivaHome dichiarazioneSostitutivaDAO = new DichiarazioneSostitutivaHome();
	private  DatiBando datiBando = new DatiBando();
	private  DatiBandoHome datiBandoDAO = new DatiBandoHome();
	private  String numero_protocollo_ricevuta = new String("");
	private  String id_ricevuta_inserito = "";
	private  Ricevute ricevute = new Ricevute();
	private  RicevuteId ricevuteId = new RicevuteId();
	private  ValoriCodice valoriCodice = new ValoriCodice();
	private  ValoriCodiceHome valoriCodiceDAO = new ValoriCodiceHome();
	private  Documento documento = new Documento();
	private  DocumentoHome documentoDAO = new DocumentoHome();
	private  List<Documento> listDocumenti = new ArrayList<Documento>();
	
	MatricePropertiesDe matriceDe = MatricePropertiesDe.getMatricePropertiesDe();
	String lingua = "";
	public byte[] getImgRicevutaPDF() {
		return imgRicevutaPDF;
	}

	public  void setImgRicevutaPDF(byte[] imgRicevutaPDF) {
		this.imgRicevutaPDF = imgRicevutaPDF;
	}

	public  List<EntityPDFRicevuta> getListaEntityPDFRicevuta() {
		return listaEntityPDFRicevuta;
	}

	public void setListaEntityPDFRicevuta(
			List<EntityPDFRicevuta> listaEntityPDFRicevuta) {
		this.listaEntityPDFRicevuta = listaEntityPDFRicevuta;
	}

	public  EntityPDFRicevuta getEntityPDFRicevuta() {
		return entityPDFRicevuta;
	}

	public String getDateInvio() {
		return dateInvio;
	}

	public void setDateInvio(String dateInvio) {
		this.dateInvio = dateInvio;
	}

	public int getNriga_posizione() {
		return nriga_posizione;
	}

	public void setNriga_posizione(int nriga_posizione) {
		this.nriga_posizione = nriga_posizione;
	}

	public int getTotale_pagine() {
		return totale_pagine;
	}

	public void setTotale_pagine(int totale_pagine) {
		this.totale_pagine = totale_pagine;
	}

	public boolean isContaLepagine() {
		return contaLepagine;
	}

	public void setContaLepagine(boolean contaLepagine) {
		this.contaLepagine = contaLepagine;
	}

	public int getTotale_pagine_stampate() {
		return totale_pagine_stampate;
	}

	public void setTotale_pagine_stampate(int totale_pagine_stampate) {
		this.totale_pagine_stampate = totale_pagine_stampate;
	}

	public boolean isSeOggetto() {
		return seOggetto;
	}

	public void setSeOggetto(boolean seOggetto) {
		this.seOggetto = seOggetto;
	}

	public Document getDocumentoPDF() {
		return documentoPDF;
	}

	public void setDocumentoPDF(Document documentoPDF) {
		this.documentoPDF = documentoPDF;
	}

	public Regione getRegione() {
		return regione;
	}

	public void setRegione(Regione regione) {
		this.regione = regione;
	}

	public RegioneHome getRegioneDAO() {
		return regioneDAO;
	}

	public void setRegioneDAO(RegioneHome regioneDAO) {
		this.regioneDAO = regioneDAO;
	}

	public UtenteCandidatura getUteCandi() {
		return uteCandi;
	}

	public void setUteCandi(UtenteCandidatura uteCandi) {
		this.uteCandi = uteCandi;
	}

	public CandidaturaHome getCandidaturaHome() {
		return candidaturaHome;
	}

	public void setCandidaturaHome(CandidaturaHome candidaturaHome) {
		this.candidaturaHome = candidaturaHome;
	}

	public RequisitiMinimi getRequiMinimi() {
		return requiMinimi;
	}

	public void setRequiMinimi(RequisitiMinimi requiMinimi) {
		this.requiMinimi = requiMinimi;
	}

	public RequisitiMinimiHome getRequiMinimiDAO() {
		return requiMinimiDAO;
	}

	public void setRequiMinimiDAO(RequisitiMinimiHome requiMinimiDAO) {
		this.requiMinimiDAO = requiMinimiDAO;
	}

	public LogIn getLogin() {
		return login;
	}

	public void setLogin(LogIn login) {
		this.login = login;
	}

	public LogInHome getLogInDAO() {
		return logInDAO;
	}

	public void setLogInDAO(LogInHome logInDAO) {
		this.logInDAO = logInDAO;
	}

	public AltraLaurea getAltraLaurea() {
		return altraLaurea;
	}

	public void setAltraLaurea(AltraLaurea altraLaurea) {
		this.altraLaurea = altraLaurea;
	}

	public AltraLaureaHome getAltraLaureaDAO() {
		return altraLaureaDAO;
	}

	public void setAltraLaureaDAO(AltraLaureaHome altraLaureaDAO) {
		this.altraLaureaDAO = altraLaureaDAO;
	}

	public AltraLaureaBis getAltraLaureaBis() {
		return altraLaureaBis;
	}

	public void setAltraLaureaBis(AltraLaureaBis altraLaureaBis) {
		this.altraLaureaBis = altraLaureaBis;
	}

	public AltraLaureaBisHome getAltraLaureaBisDAO() {
		return altraLaureaBisDAO;
	}

	public void setAltraLaureaBisDAO(AltraLaureaBisHome altraLaureaBisDAO) {
		this.altraLaureaBisDAO = altraLaureaBisDAO;
	}

	public List<Specializzazione> getListSpecializzazione() {
		return listSpecializzazione;
	}

	public void setListSpecializzazione(List<Specializzazione> listSpecializzazione) {
		this.listSpecializzazione = listSpecializzazione;
	}

	public SpecializzazioneHome getSpecializzazioneDAO() {
		return specializzazioneDAO;
	}

	public void setSpecializzazioneDAO(SpecializzazioneHome specializzazioneDAO) {
		this.specializzazioneDAO = specializzazioneDAO;
	}

	public List<BorsaStudio> getListBorsaStudio() {
		return listBorsaStudio;
	}

	public void setListBorsaStudio(List<BorsaStudio> listBorsaStudio) {
		this.listBorsaStudio = listBorsaStudio;
	}

	public BorsaStudioHome getBorsaStudioDAO() {
		return borsaStudioDAO;
	}

	public void setBorsaStudioDAO(BorsaStudioHome borsaStudioDAO) {
		this.borsaStudioDAO = borsaStudioDAO;
	}

	public List<Dottorato> getListDottorato() {
		return listDottorato;
	}

	public void setListDottorato(List<Dottorato> listDottorato) {
		this.listDottorato = listDottorato;
	}

	public DottoratoHome getDottoratoDAO() {
		return dottoratoDAO;
	}

	public void setDottoratoDAO(DottoratoHome dottoratoDAO) {
		this.dottoratoDAO = dottoratoDAO;
	}

	public List<AltroTitolo> getListAltriTitolo() {
		return listAltriTitolo;
	}

	public void setListAltriTitolo(List<AltroTitolo> listAltriTitolo) {
		this.listAltriTitolo = listAltriTitolo;
	}

	public AltroTitoloHome getAltroTitoloDAO() {
		return altroTitoloDAO;
	}

	public void setAltroTitoloDAO(AltroTitoloHome altroTitoloDAO) {
		this.altroTitoloDAO = altroTitoloDAO;
	}

	public Idoneita getIdoneita() {
		return idoneita;
	}

	public void setIdoneita(Idoneita idoneita) {
		this.idoneita = idoneita;
	}

	public IdoneitaHome getIdeoneitaDAO() {
		return ideoneitaDAO;
	}

	public void setIdeoneitaDAO(IdoneitaHome ideoneitaDAO) {
		this.ideoneitaDAO = ideoneitaDAO;
	}

	public List<CorsoAggiornamento> getListCorsoAggiornamento() {
		return listCorsoAggiornamento;
	}

	public void setListCorsoAggiornamento(
			List<CorsoAggiornamento> listCorsoAggiornamento) {
		this.listCorsoAggiornamento = listCorsoAggiornamento;
	}

	public CorsoAggiornamentoHome getCorsoAggiornamentoDAO() {
		return corsoAggiornamentoDAO;
	}

	public void setCorsoAggiornamentoDAO(
			CorsoAggiornamentoHome corsoAggiornamentoDAO) {
		this.corsoAggiornamentoDAO = corsoAggiornamentoDAO;
	}

	public List<Pubblicazione> getListPubblicazione() {
		return listPubblicazione;
	}

	public void setListPubblicazione(List<Pubblicazione> listPubblicazione) {
		this.listPubblicazione = listPubblicazione;
	}

	public PubblicazioneHome getPubblicazioneDAO() {
		return pubblicazioneDAO;
	}

	public void setPubblicazioneDAO(PubblicazioneHome pubblicazioneDAO) {
		this.pubblicazioneDAO = pubblicazioneDAO;
	}

	public EsercizioProf getEsercizioProf() {
		return esercizioProf;
	}

	public void setEsercizioProf(EsercizioProf esercizioProf) {
		this.esercizioProf = esercizioProf;
	}

	public EsercizioProfHome getEsercizioProfDAO() {
		return esercizioProfDAO;
	}

	public void setEsercizioProfDAO(EsercizioProfHome esercizioProfDAO) {
		this.esercizioProfDAO = esercizioProfDAO;
	}

	public DichiarazioneSostitutiva getDichiarazioneSostitutiva() {
		return dichiarazioneSostitutiva;
	}

	public void setDichiarazioneSostitutiva(
			DichiarazioneSostitutiva dichiarazioneSostitutiva) {
		this.dichiarazioneSostitutiva = dichiarazioneSostitutiva;
	}

	public DichiarazioneSostitutivaHome getDichiarazioneSostitutivaDAO() {
		return dichiarazioneSostitutivaDAO;
	}

	public void setDichiarazioneSostitutivaDAO(
			DichiarazioneSostitutivaHome dichiarazioneSostitutivaDAO) {
		this.dichiarazioneSostitutivaDAO = dichiarazioneSostitutivaDAO;
	}

	public DatiBando getDatiBando() {
		return datiBando;
	}

	public void setDatiBando(DatiBando datiBando) {
		this.datiBando = datiBando;
	}

	public DatiBandoHome getDatiBandoDAO() {
		return datiBandoDAO;
	}

	public void setDatiBandoDAO(DatiBandoHome datiBandoDAO) {
		this.datiBandoDAO = datiBandoDAO;
	}

	public String getNumero_protocollo_ricevuta() {
		return numero_protocollo_ricevuta;
	}

	public void setNumero_protocollo_ricevuta(String numero_protocollo_ricevuta) {
		this.numero_protocollo_ricevuta = numero_protocollo_ricevuta;
	}

	public String getId_ricevuta_inserito() {
		return id_ricevuta_inserito;
	}

	public void setId_ricevuta_inserito(String id_ricevuta_inserito) {
		this.id_ricevuta_inserito = id_ricevuta_inserito;
	}

	public Ricevute getRicevute() {
		return ricevute;
	}

	public void setRicevute(Ricevute ricevute) {
		this.ricevute = ricevute;
	}

	public RicevuteId getRicevuteId() {
		return ricevuteId;
	}

	public void setRicevuteId(RicevuteId ricevuteId) {
		this.ricevuteId = ricevuteId;
	}

	public ValoriCodice getValoriCodice() {
		return valoriCodice;
	}

	public void setValoriCodice(ValoriCodice valoriCodice) {
		this.valoriCodice = valoriCodice;
	}

	public ValoriCodiceHome getValoriCodiceDAO() {
		return valoriCodiceDAO;
	}

	public void setValoriCodiceDAO(ValoriCodiceHome valoriCodiceDAO) {
		this.valoriCodiceDAO = valoriCodiceDAO;
	}

	public Documento getDocumento() {
		return documento;
	}

	public void setDocumento(Documento documento) {
		this.documento = documento;
	}

	public DocumentoHome getDocumentoDAO() {
		return documentoDAO;
	}

	public void setDocumentoDAO(DocumentoHome documentoDAO) {
		this.documentoDAO = documentoDAO;
	}

	public List<Documento> getListDocumenti() {
		return listDocumenti;
	}

	public void setListDocumenti(List<Documento> listDocumenti) {
		this.listDocumenti = listDocumenti;
	}

	public static Font getFonts12Bold() {
		return fonts12_bold;
	}

	public static Font getFonts10Normal() {
		return fonts10_normal;
	}

	public static Font getFonts10Bold() {
		return fonts10_bold;
	}

	public static Font getFonts6Italic() {
		return fonts6_italic;
	}

	public static Font getFonts6Normal() {
		return fonts6_normal;
	}

	public static Font getFonts8Normal() {
		return fonts8_normal;
	}

	public static Font getFonts8Bold() {
		return fonts8_bold;
	}

	public static int getImgWidth() {
		return IMG_WIDTH;
	}

	public static int getImgHeight() {
		return IMG_HEIGHT;
	}

	public static int getLimiteSaltoPagina() {
		return LIMITE_SALTO_PAGINA;
	}

	public static int getPosRigaSaltoPagina() {
		return POS_RIGA_SALTO_PAGINA;
	}

	public void setEntityPDFRicevuta(EntityPDFRicevuta entityPDFRicevuta) {
		this.entityPDFRicevuta = entityPDFRicevuta;
	}

	public GestionePDFModuloRicevutaTedesco()  // Costruttore 
	{
		try {		
				URL url = CaptchaGenerator.class.getResource("/resources/ricevutapdf_de.properties");
				//String currentDir = "C://Documents and Settings//Administrator//workspace//CCFarmacie//src//resources//ricevutapdf.properties";
				//bodyRicevuta.load(new FileInputStream(currentDir));
				String nfile = url.getFile();
				nfile = nfile.replaceAll("%20", " ");
				bodyRicevuta.load(new FileInputStream(nfile));
				HttpSession session=(HttpSession)FacesContext.getCurrentInstance().getExternalContext().getSession(true);
				lingua= (String)session.getAttribute("linguaScelta");
			} catch (IOException e) {
				CCFarmLogger.log("File Properties 'ricevutapdf' non trovato..", Level.ERROR_INT,
						CandidaturaHome.class);
			}
	}
	
	/**
	 * @param args
	 */
	public static Domanda getSessionDomandaBean() {
		Domanda ilBean = null;
		ilBean = ((Domanda) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("domanda"));
		/*
		if (ilBean == null) 
		{
			//il bean non esiste a livello sessione
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("domanda", new Domanda());
		}
		*/
		return ilBean;
		
		//((Domanda) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("domanda"));
	}
	
	

    public static EntityPDFRicevuta initUteCandRicev()
    {
    	EntityPDFRicevuta result = new EntityPDFRicevuta();   
    	result.setDescRegUtente("REGIONE DI PROVA");
    	result.setDataInvio("20/10/2012 10:25");
    	result.setModoPartecipa("Singola");
    	result.setNumeroProtocollo("Nr.123456789");
    	result.setCognome("PROVA COGNOME");
    	result.setNome("PROVA COGNOME");
    	result.setCodifisc("PROVA CODICE");
    	result.setDataNascita("PROVA DATA DI NASCITA");
    	result.setComuneNascita("PROVA COMUNE NASCITA");
    	result.setProvNascita("PROVA PROVINCIA DI NASCITA");
    	result.setLocalitaEsteraNascita("PROVA LOCALIATA ESTERA NASCITA");
    	result.setStatoNascita("PROVA STATO DI NASCITA");
    	result.setEstremiDocumento("ESTREMI DOCUMENTO");
    	result.setIndirizzoResidenza("INDIRIZZO RESIDENZA");
    	result.setProvResidenza("PROVINCIA RESIDENZA");
    	result.setComuneResidenza("COMUNE RESIDENZA");
    	result.setNazioneResidenzaUtente("STATO DI RESIDENZA");
        result.setLocalitaResidenzaEstera("LOCALITA DI RESIDENZA");
    	result.setCapResidenza("CAP RESIDENZA");
    	result.setRifTelefonico("RIF TELEFONICO");
    	result.setEmailCertificata("EMAIL CERTIFICATA");
    	result.setAppartenenza("FATTISPECIE DI APPARTENENZA");
    	result.setCittadinanza("ITALIANA");
    	result.setListaElettorale("LISTA ELETTORALE");
    	result.setProvIscrizioneFarmacisti("PRPV ISCR FARMACIA");
    	result.setDataPrimaIscrizioneFarmacisti("DATA PRIMA ISCRI FARMACIA");
    	result.setNumeroIscrizioneFarmacisti("NUMERO ISCR FARMACISTI 123");
    	result.setPaBolzano("PROVA PER SOLO PA DI BOLZANO");
    	result.setTipoLaurea("TIPO LAUREA");
    	result.setUniversitaConseg("UNIVERSITA CONSEGUITA");
    	result.setLuogoLaurea("LUOGO LAUREA");
    	result.setDataLaurea("DATA LAUREA");
    	result.setVotoLaurea("VOTO LAUREA");
    	result.setNazioneAbilitazione("NZIONE ABILITAZIONE");
    	result.setUniversitaAbiltazione("UNIVER ABILIATZIONE");
    	result.setLuogoAbilitazione("LUOGO ABILITZ");
    	result.setAnnoAbilitazione("ANNO ABILITA");
    	result.setVotoAbilitazione("VOTO ABILITAZION");
    	result.setEstremiAbilitazione("ESTREMI ABILITAZIONE");
    	result.setAltraLaureaF("ALTRA LAUREA FARMA");
    	result.setUnivAltraLaureaF("UNIVERSITA ALTRA LAUREA FARMA");
    	result.setLuogoAltraLaureaF("LUOGO ALTRA LAUREA FARMA");
    	result.setDataAltraLaureaF("DATA ALTRA LUREA FARMA");
    	result.setNazioneAltraLaureaF("NAZIONE ALTRA LAUREA FARMA");
    	result.setSeEsteraPrivataAltraLaureaF("SI/NO FARMA");
    	result.setAltraLaurea("ALTRA LAUREA");
    	result.setUnivAltraLaurea("UNIVERSITA ALTRA LAUREA");
    	result.setLuogoAltraLaurea("LUOGO ALTRA LAUREA");
    	result.setDataAltraLaurea("DATA ALTRA LUREA");
    	result.setNazioneAltraLaurea("NAZIONE ALTRA LAUREA");
    	result.setSeEsteraPrivataAltraLaurea("SI/NO");
    	
    	SpecializzazioniUniversitarie result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_1");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC");
    	result_1.setUniveSpecializza("UNIVER SPECIAL");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA");
    	result_1.setNazioneSpecializza("NAZIONE SPEC");
    	result_1.setDurataSpecializza("DURATA SPEC");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO");
    	result.getListaSpeciaUnivers().add(result_1);
    	
    	result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_2");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC_2222");
    	result_1.setUniveSpecializza("UNIVER SPECIAL_2222");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA_2222");
    	result_1.setNazioneSpecializza("NAZIONE SPEC_2222");
    	result_1.setDurataSpecializza("DURATA SPEC_2222");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO_2222");
    	result.getListaSpeciaUnivers().add(result_1);
    	
    	result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_33");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC_3333");
    	result_1.setUniveSpecializza("UNIVER SPECIAL_3333");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA_3333");
    	result_1.setNazioneSpecializza("NAZIONE SPEC_3333");
    	result_1.setDurataSpecializza("DURATA SPEC_3333");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO_3333");
    	result.getListaSpeciaUnivers().add(result_1);
    	
    	
    	result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_4");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC_3333");
    	result_1.setUniveSpecializza("UNIVER SPECIAL_3333");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA_3333");
    	result_1.setNazioneSpecializza("NAZIONE SPEC_3333");
    	result_1.setDurataSpecializza("DURATA SPEC_3333");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO_3333");
    	result.getListaSpeciaUnivers().add(result_1);
    	
    	result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_5");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC_3333");
    	result_1.setUniveSpecializza("UNIVER SPECIAL_3333");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA_3333");
    	result_1.setNazioneSpecializza("NAZIONE SPEC_3333");
    	result_1.setDurataSpecializza("DURATA SPEC_3333");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO_366333");
    	result.getListaSpeciaUnivers().add(result_1);
    	
    	
    	result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_6");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC_3333");
    	result_1.setUniveSpecializza("UNIVER SPECIAL_3333");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA_3333");
    	result_1.setNazioneSpecializza("NAZIONE SPEC_3333");
    	result_1.setDurataSpecializza("DURATA SPEC_3333");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO_388333");
    	result.getListaSpeciaUnivers().add(result_1);
    	   	  
    	result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_7");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC_3333");
    	result_1.setUniveSpecializza("UNIVER SPECIAL_3333");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA_3333");
    	result_1.setNazioneSpecializza("NAZIONE SPEC_3333");
    	result_1.setDurataSpecializza("DURATA SPEC_3333");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO_3333");
    	result.getListaSpeciaUnivers().add(result_1);

    	result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_8");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC_3333");
    	result_1.setUniveSpecializza("UNIVER SPECIAL_3333");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA_3333");
    	result_1.setNazioneSpecializza("NAZIONE SPEC_3333");
    	result_1.setDurataSpecializza("DURATA SPEC_3333");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO_331133");
    	result.getListaSpeciaUnivers().add(result_1);
    	
    	result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_9");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC_3333");
    	result_1.setUniveSpecializza("UNIVER SPECIAL_3333");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA_3333");
    	result_1.setNazioneSpecializza("NAZIONE SPEC_3333");
    	result_1.setDurataSpecializza("DURATA SPEC_3333");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO_311333");
    	result.getListaSpeciaUnivers().add(result_1);
    	
    	result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_10");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC_3333");
    	result_1.setUniveSpecializza("UNIVER SPECIAL_3333");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA_3333");
    	result_1.setNazioneSpecializza("NAZIONE SPEC_3333");
    	result_1.setDurataSpecializza("DURATA SPEC_3333");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO_315333");
    	result.getListaSpeciaUnivers().add(result_1);
    	
    	result_1 = new SpecializzazioniUniversitarie();
    	result_1.setDenomSpecializza("DENOMI SPECIALIZZZIONE_11");
    	result_1.setFacoltaSpecializza("FACOLTA SPEC_3333");
    	result_1.setUniveSpecializza("UNIVER SPECIAL_3333");
    	result_1.setLuogoSpecializza("LUOGO SPECIALIZZA_3333");
    	result_1.setNazioneSpecializza("NAZIONE SPEC_3333");
    	result_1.setDurataSpecializza("DURATA SPEC_3333");
    	result_1.setSeEsteraPrivataSpecializza("SE SPECI SI/NO_3333");
    	result.getListaSpeciaUnivers().add(result_1);    	
    	   	  	
    	BorseDiStudio result_2 = new BorseDiStudio();    	
    	result_2.setDenomBStudio("DENOM BORSA STUDIO");
    	result_2.setFacoltaBStudio("FACOLTA BORSA STUDIO");
    	result_2.setUniveBStudio("UNIVERS BORSA STUDIO");
    	result_2.setLuogoBStudio("LUOGO BORSA STUDIO");
    	result_2.setNazioneBStudio("NAZIONE BORSA STUDIO");
    	result_2.setDataIniFineBStudio("INIZIO-FINE");
    	result_2.setSeEsteraPrivataBStudio("SE ESTERNA O PRIVATA B STUDIO");
    	result.getListaBorseDiStudio().add(result_2);
    	
    	result_2 = new BorseDiStudio();    	
    	result_2.setDenomBStudio("DENOM BORSA STUDIO");
    	result_2.setFacoltaBStudio("FACOLTA BORSA STUDIO");
    	result_2.setUniveBStudio("UNIVERS BORSA STUDIO");
    	result_2.setLuogoBStudio("LUOGO BORSA STUDIO");
    	result_2.setNazioneBStudio("NAZIONE BORSA STUDIO");
    	result_2.setDataIniFineBStudio("INIZIO-FINE");
    	result_2.setSeEsteraPrivataBStudio("SE ESTERNA O PRIVATA B STUDIO");
    	result.getListaBorseDiStudio().add(result_2);
    	
    	result_2 = new BorseDiStudio();    	
    	result_2.setDenomBStudio("DENOM BORSA STUDIO");
    	result_2.setFacoltaBStudio("FACOLTA BORSA STUDIO");
    	result_2.setUniveBStudio("UNIVERS BORSA STUDIO");
    	result_2.setLuogoBStudio("LUOGO BORSA STUDIO");
    	result_2.setNazioneBStudio("NAZIONE BORSA STUDIO");
    	result_2.setDataIniFineBStudio("INIZIO-FINE");
    	result_2.setSeEsteraPrivataBStudio("SE ESTERNA O PRIVATA B STUDIO");
    	result.getListaBorseDiStudio().add(result_2);
    	
    	result_2 = new BorseDiStudio();    	
    	result_2.setDenomBStudio("DENOM BORSA STUDIO");
    	result_2.setFacoltaBStudio("FACOLTA BORSA STUDIO");
    	result_2.setUniveBStudio("UNIVERS BORSA STUDIO");
    	result_2.setLuogoBStudio("LUOGO BORSA STUDIO");
    	result_2.setNazioneBStudio("NAZIONE BORSA STUDIO");
    	result_2.setDataIniFineBStudio("INIZIO-FINE");
    	result_2.setSeEsteraPrivataBStudio("SE ESTERNA O PRIVATA B STUDIO");
    	result.getListaBorseDiStudio().add(result_2);
    	
    	/*
    	result_2 = new BorseDiStudio();    	
    	result_2.setDenomBStudio("DENOM BORSA STUDIO");
    	result_2.setFacoltaBStudio("FACOLTA BORSA STUDIO");
    	result_2.setUniveBStudio("UNIVERS BORSA STUDIO");
    	result_2.setLuogoBStudio("LUOGO BORSA STUDIO");
    	result_2.setNazioneBStudio("NAZIONE BORSA STUDIO");
    	result_2.setDataIniFineBStudio("INIZIO-FINE");
    	result_2.setSeEsteraPrivataBStudio("SE ESTERNA O PRIVATA B STUDIO");
    	result.getListaBorseDiStudio().add(result_2);
    	
    	result_2 = new BorseDiStudio();    	
    	result_2.setDenomBStudio("DENOM BORSA STUDIO");
    	result_2.setFacoltaBStudio("FACOLTA BORSA STUDIO");
    	result_2.setUniveBStudio("UNIVERS BORSA STUDIO");
    	result_2.setLuogoBStudio("LUOGO BORSA STUDIO");
    	result_2.setNazioneBStudio("NAZIONE BORSA STUDIO");
    	result_2.setDataIniFineBStudio("INIZIO-FINE");
    	result_2.setSeEsteraPrivataBStudio("SE ESTERNA O PRIVATA B STUDIO");
    	result.getListaBorseDiStudio().add(result_2);
    	
    	result_2 = new BorseDiStudio();    	
    	result_2.setDenomBStudio("DENOM BORSA STUDIO");
    	result_2.setFacoltaBStudio("FACOLTA BORSA STUDIO");
    	result_2.setUniveBStudio("UNIVERS BORSA STUDIO");
    	result_2.setLuogoBStudio("LUOGO BORSA STUDIO");
    	result_2.setNazioneBStudio("NAZIONE BORSA STUDIO");
    	result_2.setDataIniFineBStudio("INIZIO-FINE");
    	result_2.setSeEsteraPrivataBStudio("SE ESTERNA O PRIVATA B STUDIO");
    	result.getListaBorseDiStudio().add(result_2);
    	*/
    	
    	DottoratoPDF result_3 = new DottoratoPDF();
    	result_3.setDenomDottorato("DENOM DOTTORATO");
    	result_3.setFacoltaDottorato("FACOLTA DOTTORATO");
    	result_3.setUniveDottorato("UNIVERS DOTTORATO");
    	result_3.setLuogoDottorato("LUOGO DOTTORATO");
    	result_3.setNazioneDottorato("NAZIONE DOTTORATO");
    	result_3.setDataIniFineDottorato("INIZIO-FINE");
    	result_3.setSeEsteraPrivataDottorato("SE ESTERNA O PRIVATA DOTTORATO");
    	result.getListaDottorato().add(result_3);
    	
    	
    	result_3 = new DottoratoPDF();
    	result_3.setDenomDottorato("DENOM DOTTORATO");
    	result_3.setFacoltaDottorato("FACOLTA DOTTORATO");
    	result_3.setUniveDottorato("UNIVERS DOTTORATO");
    	result_3.setLuogoDottorato("LUOGO DOTTORATO");
    	result_3.setNazioneDottorato("NAZIONE DOTTORATO");
    	result_3.setDataIniFineDottorato("INIZIO-FINE");
    	result_3.setSeEsteraPrivataDottorato("SE ESTERNA O PRIVATA DOTTORATO");
    	result.getListaDottorato().add(result_3);
    	
    	/*
    	result_3 = new Dottorato();
    	result_3.setDenomDottorato("DENOM DOTTORATO");
    	result_3.setFacoltaDottorato("FACOLTA DOTTORATO");
    	result_3.setUniveDottorato("UNIVERS DOTTORATO");
    	result_3.setLuogoDottorato("LUOGO DOTTORATO");
    	result_3.setNazioneDottorato("NAZIONE DOTTORATO");
    	result_3.setDataIniFineDottorato("INIZIO-FINE");
    	result_3.setSeEsteraPrivataDottorato("SE ESTERNA O PRIVATA DOTTORATO");
    	result.getListaDottorato().add(result_3);
    	
    	result_3 = new Dottorato();
    	result_3.setDenomDottorato("DENOM DOTTORATO");
    	result_3.setFacoltaDottorato("FACOLTA DOTTORATO");
    	result_3.setUniveDottorato("UNIVERS DOTTORATO");
    	result_3.setLuogoDottorato("LUOGO DOTTORATO");
    	result_3.setNazioneDottorato("NAZIONE DOTTORATO");
    	result_3.setDataIniFineDottorato("INIZIO-FINE");
    	result_3.setSeEsteraPrivataDottorato("SE ESTERNA O PRIVATA DOTTORATO");
    	result.getListaDottorato().add(result_3);
    	
    	result_3 = new Dottorato();
    	result_3.setDenomDottorato("DENOM DOTTORATO");
    	result_3.setFacoltaDottorato("FACOLTA DOTTORATO");
    	result_3.setUniveDottorato("UNIVERS DOTTORATO");
    	result_3.setLuogoDottorato("LUOGO DOTTORATO");
    	result_3.setNazioneDottorato("NAZIONE DOTTORATO");
    	result_3.setDataIniFineDottorato("INIZIO-FINE");
    	result_3.setSeEsteraPrivataDottorato("SE ESTERNA O PRIVATA DOTTORATO");
    	result.getListaDottorato().add(result_3);
    	
    	result_3 = new Dottorato();
    	result_3.setDenomDottorato("DENOM DOTTORATO");
    	result_3.setFacoltaDottorato("FACOLTA DOTTORATO");
    	result_3.setUniveDottorato("UNIVERS DOTTORATO");
    	result_3.setLuogoDottorato("LUOGO DOTTORATO");
    	result_3.setNazioneDottorato("NAZIONE DOTTORATO");
    	result_3.setDataIniFineDottorato("INIZIO-FINE");
    	result_3.setSeEsteraPrivataDottorato("SE ESTERNA O PRIVATA DOTTORATO");
    	result.getListaDottorato().add(result_3);
    	
    	result_3 = new Dottorato();
    	result_3.setDenomDottorato("DENOM DOTTORATO");
    	result_3.setFacoltaDottorato("FACOLTA DOTTORATO");
    	result_3.setUniveDottorato("UNIVERS DOTTORATO");
    	result_3.setLuogoDottorato("LUOGO DOTTORATO");
    	result_3.setNazioneDottorato("NAZIONE DOTTORATO");
    	result_3.setDataIniFineDottorato("INIZIO-FINE");
    	result_3.setSeEsteraPrivataDottorato("SE ESTERNA O PRIVATA DOTTORATO");
    	result.getListaDottorato().add(result_3);
    	*/
    	
    	AltriTitoli result_4 = new AltriTitoli();    	
    	result_4.setTitoloAltro("TITOLO ALTRO");
    	result_4.setDurataAltro("DURATO ALTRO");
    	result_4.setRilasciatoDaAltro("RILASCIATO DA ALTRO");
    	result_4.setDataRilascio("DATA RILASCIO");
    	result_4.setEsitoFinaleAltro("ESITO FINALE ALTRO");
    	result_4.setNoteAltro("NOTE ALTRO");
    	result_4.setSeEsteraPrivataAltro("SE ESTERNA O PRIVATA ALTRO");
    	result.getListaAltriTitoli().add(result_4);
    	
    	result_4 = new AltriTitoli();    	
    	result_4.setTitoloAltro("TITOLO ALTRO");
    	result_4.setDurataAltro("DURATO ALTRO");
    	result_4.setRilasciatoDaAltro("RILASCIATO DA ALTRO");
    	result_4.setDataRilascio("DATA RILASCIO");
    	result_4.setEsitoFinaleAltro("ESITO FINALE ALTRO");
    	result_4.setNoteAltro("NOTE ALTRO");
    	result_4.setSeEsteraPrivataAltro("SE ESTERNA O PRIVATA ALTRO");
    	result.getListaAltriTitoli().add(result_4);    	
    	
    	result_4 = new AltriTitoli();    	
    	result_4.setTitoloAltro("TITOLO ALTRO");
    	result_4.setDurataAltro("DURATO ALTRO");
    	result_4.setRilasciatoDaAltro("RILASCIATO DA ALTRO");
    	result_4.setDataRilascio("DATA RILASCIO");
    	result_4.setEsitoFinaleAltro("ESITO FINALE ALTRO");
    	result_4.setNoteAltro("NOTE ALTRO");
    	result_4.setSeEsteraPrivataAltro("SE ESTERNA O PRIVATA ALTRO");
    	result.getListaAltriTitoli().add(result_4);  
    	/*
    	result_4 = new AltriTitoli();    	
    	result_4.setTitoloAltro("TITOLO ALTRO");
    	result_4.setDurataAltro("DURATO ALTRO");
    	result_4.setRilasciatoDaAltro("RILASCIATO DA ALTRO");
    	result_4.setDataRilascio("DATA RILASCIO");
    	result_4.setEsitoFinaleAltro("ESITO FINALE ALTRO");
    	result_4.setNoteAltro("NOTE ALTRO");
    	result_4.setSeEsteraPrivataAltro("SE ESTERNA O PRIVATA ALTRO");
    	result.getListaAltriTitoli().add(result_4);  
    	
    	result_4 = new AltriTitoli();    	
    	result_4.setTitoloAltro("TITOLO ALTRO");
    	result_4.setDurataAltro("DURATO ALTRO");
    	result_4.setRilasciatoDaAltro("RILASCIATO DA ALTRO");
    	result_4.setDataRilascio("DATA RILASCIO");
    	result_4.setEsitoFinaleAltro("ESITO FINALE ALTRO");
    	result_4.setNoteAltro("NOTE ALTRO");
    	result_4.setSeEsteraPrivataAltro("SE ESTERNA O PRIVATA ALTRO");
    	result.getListaAltriTitoli().add(result_4);  
    	
    	result_4 = new AltriTitoli();    	
    	result_4.setTitoloAltro("TITOLO ALTRO");
    	result_4.setDurataAltro("DURATO ALTRO");
    	result_4.setRilasciatoDaAltro("RILASCIATO DA ALTRO");
    	result_4.setDataRilascio("DATA RILASCIO");
    	result_4.setEsitoFinaleAltro("ESITO FINALE ALTRO");
    	result_4.setNoteAltro("NOTE ALTRO");
    	result_4.setSeEsteraPrivataAltro("SE ESTERNA O PRIVATA ALTRO");
    	result.getListaAltriTitoli().add(result_4);  
    	
    	result_4 = new AltriTitoli();    	
    	result_4.setTitoloAltro("TITOLO ALTRO");
    	result_4.setDurataAltro("DURATO ALTRO");
    	result_4.setRilasciatoDaAltro("RILASCIATO DA ALTRO");
    	result_4.setDataRilascio("DATA RILASCIO");
    	result_4.setEsitoFinaleAltro("ESITO FINALE ALTRO");
    	result_4.setNoteAltro("NOTE ALTRO");
    	result_4.setSeEsteraPrivataAltro("SE ESTERNA O PRIVATA ALTRO");
    	result.getListaAltriTitoli().add(result_4);      	
    	*/
    	
    	result.setIdoneitaConseguita("VALORE IDONEITA CON");
    	result.setEstremiAtto("ESTREMI ATTO");
    	result.setDataAtto("VAL DATA ATTO");
    	result.setRifIdoneitaNaz("RIF IDONEITA' NAZIONALE");
    	result.setAnnoIdoneitaNaz("ANNO IDONEITA' NAZIONALE");
    	
    	CorsoDiAggiornamento result_5 = new CorsoDiAggiornamento();
    	result_5.setTitoloAggCorso("TITOLO CORSO AGG");
    	result_5.setOrganizzatoAggCorso("ORGANIZZATO DA");
    	result_5.setGiornoPeridoAggCorso("PRIODO GG/PER");
    	result_5.setTotaleOreEsame("TOT ORE ESAQME");
    	result_5.setEsitoEsameSuperato("SI/NO");
    	result_5.setSeEsteroPrivatoEsame("ESITO ESTERO PRIVATO ESAME");
    	result.getListaCorsiAggiornamento().add(result_5);
    	
    	result.setDataPartenzaCorso("DATA PARTENZA CORSO");
    	result_5 = new CorsoDiAggiornamento();
    	result_5.setTitoloAggCorso("TITOLO CORSO AGG");
    	result_5.setOrganizzatoAggCorso("ORGANIZZATO DA");
    	result_5.setGiornoPeridoAggCorso("PRIODO GG/PER");
    	result_5.setTotaleOreEsame("TOT ORE ESAQME");
    	result_5.setEsitoEsameSuperato("SI/NO");
    	result_5.setSeEsteroPrivatoEsame("ESITO ESTERO PRIVATO ESAME");
    	result.getListaCorsiAggiornamento().add(result_5);
    	
    	result_5 = new CorsoDiAggiornamento();
    	result_5.setTitoloAggCorso("TITOLO CORSO AGG");
    	result_5.setOrganizzatoAggCorso("ORGANIZZATO DA");
    	result_5.setGiornoPeridoAggCorso("PRIODO GG/PER");
    	result_5.setTotaleOreEsame("TOT ORE ESAQME");
    	result_5.setEsitoEsameSuperato("SI/NO");
    	result_5.setSeEsteroPrivatoEsame("ESITO ESTERO PRIVATO ESAME");
    	result.getListaCorsiAggiornamento().add(result_5);
    	
    	/*
    	result_5 = new CorsoDiAggiornamento();
    	result_5.setTitoloAggCorso("TITOLO CORSO AGG");
    	result_5.setOrganizzatoAggCorso("ORGANIZZATO DA");
    	result_5.setGiornoPeridoAggCorso("PRIODO GG/PER");
    	result_5.setTotaleOreEsame("TOT ORE ESAQME");
    	result_5.setEsitoEsameSuperato("SI/NO");
    	result_5.setSeEsteroPrivatoEsame("ESITO ESTERO PRIVATO ESAME");
    	result.getListaCorsiAggiornamento().add(result_5);
    	
    	result_5 = new CorsoDiAggiornamento();
    	result_5.setTitoloAggCorso("TITOLO CORSO AGG");
    	result_5.setOrganizzatoAggCorso("ORGANIZZATO DA");
    	result_5.setGiornoPeridoAggCorso("PRIODO GG/PER");
    	result_5.setTotaleOreEsame("TOT ORE ESAQME");
    	result_5.setEsitoEsameSuperato("SI/NO");
    	result_5.setSeEsteroPrivatoEsame("ESITO ESTERO PRIVATO ESAME");
    	result.getListaCorsiAggiornamento().add(result_5);
    	
    	result_5 = new CorsoDiAggiornamento();
    	result_5.setTitoloAggCorso("TITOLO CORSO AGG");
    	result_5.setOrganizzatoAggCorso("ORGANIZZATO DA");
    	result_5.setGiornoPeridoAggCorso("PRIODO GG/PER");
    	result_5.setTotaleOreEsame("TOT ORE ESAQME");
    	result_5.setEsitoEsameSuperato("SI/NO");
    	result_5.setSeEsteroPrivatoEsame("ESITO ESTERO PRIVATO ESAME");
    	result.getListaCorsiAggiornamento().add(result_5);
    	
    	result_5 = new CorsoDiAggiornamento();
    	result_5.setTitoloAggCorso("TITOLO CORSO AGG");
    	result_5.setOrganizzatoAggCorso("ORGANIZZATO DA");
    	result_5.setGiornoPeridoAggCorso("PRIODO GG/PER");
    	result_5.setTotaleOreEsame("TOT ORE ESAQME");
    	result_5.setEsitoEsameSuperato("SI/NO");
    	result_5.setSeEsteroPrivatoEsame("ESITO ESTERO PRIVATO ESAME");
    	result.getListaCorsiAggiornamento().add(result_5);    	
    	
    	*/
    	PubblicazioneScentifica result_6 = new PubblicazioneScentifica(); 	    
    	result_6.setTipoPubblic("TIP PUBBLICAZIONE");
    	result_6.setAutorePubb("AUTORE PUBBLICA");
    	result_6.setDataPubblicazione("DATA PUBB SCIENT");
    	result_6.setTitoloStudio("TITOLO STUDIO");
    	result_6.setEditoreStudio("EDITORE STUDIO");
    	result_6.setIsbn("ISSN PROVA");
    	result.getListaPubblicaScentifica().add(result_6);

    	result_6 = new PubblicazioneScentifica(); 	    
    	result_6.setTipoPubblic("TIP PUBBLICAZIONE");
    	result_6.setAutorePubb("AUTORE PUBBLICA");
    	result_6.setDataPubblicazione("DATA PUBB SCIENT");
    	result_6.setTitoloStudio("TITOLO STUDIO");
    	result_6.setEditoreStudio("EDITORE STUDIO");
    	result_6.setIsbn("ISSN PROVA");
    	result.getListaPubblicaScentifica().add(result_6);
    	
    	result_6 = new PubblicazioneScentifica(); 	    
    	result_6.setTipoPubblic("TIP PUBBLICAZIONE");
    	result_6.setAutorePubb("AUTORE PUBBLICA");
    	result_6.setDataPubblicazione("DATA PUBB SCIENT");
    	result_6.setTitoloStudio("TITOLO STUDIO");
    	result_6.setEditoreStudio("EDITORE STUDIO");
    	result_6.setIsbn("ISSN PROVA");
    	result.getListaPubblicaScentifica().add(result_6);
    	
    	/*
    	result_6 = new PubblicazioneScentifica(); 	    
    	result_6.setTipoPubblic("TIP PUBBLICAZIONE");
    	result_6.setAutorePubb("AUTORE PUBBLICA");
    	result_6.setDataPubblicazione("DATA PUBB SCIENT");
    	result_6.setTitoloStudio("TITOLO STUDIO");
    	result_6.setEditoreStudio("EDITORE STUDIO");
    	result_6.setIsbn("ISBN PROVA");
    	result.getListaPubblicaScentifica().add(result_6);
    	
    	result_6 = new PubblicazioneScentifica(); 	    
    	result_6.setTipoPubblic("TIP PUBBLICAZIONE");
    	result_6.setAutorePubb("AUTORE PUBBLICA");
    	result_6.setDataPubblicazione("DATA PUBB SCIENT");
    	result_6.setTitoloStudio("TITOLO STUDIO");
    	result_6.setEditoreStudio("EDITORE STUDIO");
    	result_6.setIsbn("ISBN PROVA");
    	result.getListaPubblicaScentifica().add(result_6);
    	
    	result_6 = new PubblicazioneScentifica(); 	    
    	result_6.setTipoPubblic("TIP PUBBLICAZIONE");
    	result_6.setAutorePubb("AUTORE PUBBLICA");
    	result_6.setDataPubblicazione("DATA PUBB SCIENT");
    	result_6.setTitoloStudio("TITOLO STUDIO");
    	result_6.setEditoreStudio("EDITORE STUDIO");
    	result_6.setIsbn("ISBN PROVA");
    	result.getListaPubblicaScentifica().add(result_6);
    	
    	result_6 = new PubblicazioneScentifica(); 	    
    	result_6.setTipoPubblic("TIP PUBBLICAZIONE");
    	result_6.setAutorePubb("AUTORE PUBBLICA");
    	result_6.setDataPubblicazione("DATA PUBBLICAZIONE");
    	result_6.setTitoloStudio("TITOLO STUDIO");
    	result_6.setEditoreStudio("EDITORE STUDIO");
    	result_6.setIsbn("ISBN PROVA");
    	result.getListaPubblicaScentifica().add(result_6);    	
    	*/
 	/*    result.setDataPubbScient("DATA PUBB SCIENT");
 	    result.setDalTitoloProf("DAL..:");
 	    result.setAlTitoloProf("AL...");
 	    result.setModoTitoloProf("MODO TIPO");
 	    result.setRuoloTitoloProf("RUOLO TITOLO");
 	    result.setTipoStruttura("TIPO STRUTTRUA");
 	    result.setDenomStruttura("DENOMINZIONE STRUTT");
 	    result.setIndiStruttura("INDIRIZZO STRUTTURA");
 	    result.setRegioneStruttura("REGIONE STRUTTURA");
 	    result.setProvStruttura("PROV STRUTTURA");
 	    result.setComStruttura("COMUN STRUTT");
 	    result.setAslRiferimento("ASL RIFERIMENTO");
 	    result.setFarmRurale("FARMACIA RURALE");  */
 	    result.setEstremiVersamento("ESTREMI VERSAMENTO");
 	    result.setDataOperazioneVers("DATA OPERAZIONE");
 	    result.setIbanVersamento("IBAN VERSAMENTO");   
 	    result.setCroVersamento("CRO VERSAMENTO");    
 	    result.setDataVersamento("DATA VERSAMENTO");   
 	    result.setNumeroUfficio("NUMERO UFFICIO");    
 	    result.setProgOperazioneVCY("PROG VCY");
 	    String documento = new String("DOCUMENTO 1");
 	    result.getListaDocumentiVersamento().add(documento);
 	    documento = new String("DOCUMENTO 1");
	    result.getListaDocumentiVersamento().add(documento);
	    documento = new String("DOCUMENTO 2");
 	    result.getListaDocumentiVersamento().add(documento);
 	    documento = new String("DOCUMENTO 3");
	    result.getListaDocumentiVersamento().add(documento);
	    documento = new String("DOCUMENTO 4");
 	    result.getListaDocumentiVersamento().add(documento);
 	    documento = new String("DOCUMENTO 5");
	    result.getListaDocumentiVersamento().add(documento);
	    documento = new String("DOCUMENTO 6");
 	    result.getListaDocumentiVersamento().add(documento);
 	    documento = new String("DOCUMENTO 7");
	    result.getListaDocumentiVersamento().add(documento);
	    documento = new String("DOCUMENTO 8");
 	    result.getListaDocumentiVersamento().add(documento);
 	    documento = new String("DOCUMENTO 9");
	    result.getListaDocumentiVersamento().add(documento);
	    documento = new String("DOCUMENTO 10");
 	    result.getListaDocumentiVersamento().add(documento);	
    	return result;
    }
    /**
     * @param page
     * @param contentStream
     * @param y the y-coordinate of the first row
     * @param margin the padding on left and right of table
     * @param content a 2d array containing the table data
     * @throws IOException
     */
     
    public  PdfPTable createBoxOggettoText(String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	
    try {
       PdfPCell cell = new PdfPCell();
       Paragraph w_testo = new Paragraph(testo,fonts12_bold);
       PdfContentByte canvas = pdfWrite.getDirectContent();
       w_testo.setAlignment(Element.ALIGN_CENTER);
       cell.addElement(w_testo); 
       table.addCell(cell);
       table.setTotalWidth(550);
       table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 20);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}      
    	
        return table;
    } 
    
//    public  PdfPTable createBoxDichiarazione(String testo,PdfWriter pdfWrite ) {
//    	
//    	PdfPTable table = new PdfPTable(1);
//    	
//    try {
//       PdfPCell cell = new PdfPCell();
//       
//       Paragraph w_testo = new Paragraph(testo,fonts12_bold);
//       PdfContentByte canvas = pdfWrite.getDirectContent();
//       w_testo.setAlignment(Element.ALIGN_LEFT);
//       
//       cell.addElement(w_testo); 
//       table.addCell(cell);
//       
//       table.setTotalWidth(550);
//       table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
//      
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	   	if (nriga_posizione != 0)
//	   	{	
//	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
//	   	}
//	   	else
//	   	{	
//	   		nriga_posizione = 790;
//	   	}      
//    	
//        return table;
//    }
    
 public  PdfPTable createBoxSecondaDichiarazione(String testo,PdfWriter pdfWrite ) {
    	
    	PdfPTable table = new PdfPTable(1);
    	
    try {
       PdfPCell cell = new PdfPCell();
       
       Paragraph w_testo = new Paragraph(testo,fonts12_bold);
       PdfContentByte canvas = pdfWrite.getDirectContent();
       w_testo.setAlignment(Element.ALIGN_LEFT);
       
       cell.addElement(w_testo); 
       table.addCell(cell);
       
       table.setTotalWidth(550);
       table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
       saltoPaginaUltimo(table,pdfWrite);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}      
    	
        return table;
    }
    
// public  PdfPTable createBoxSecondaDichiarazione(String testo,PdfWriter pdfWrite ) {
// 	// a table with three columns
// 	
// 	PdfPTable table = new PdfPTable(1);
// 	PdfPTable table2 = new PdfPTable(2);
// 	
// try {
//     PdfPCell cell = new PdfPCell();
//     Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
//     //w_etichetta.add(w_testo);
//     PdfContentByte canvas = pdfWrite.getDirectContent();
//     w_etichetta.setAlignment(Element.ALIGN_LEFT);
//     cell.addElement(w_etichetta); 
//     cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
//     table.addCell(cell);
//     
//     PdfPCell cell2 = new PdfPCell();
//     PdfPCell cell3 = new PdfPCell();
//     PdfPCell cell4 = new PdfPCell();
//     PdfPCell cell5 = new PdfPCell();
//     cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
//     String[] ww_testi = testo.split("#");
//     Paragraph w_testo = null;
//     for (int idx=0;idx<ww_testi.length;idx++)
//     {
//         w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
//         w_testo.setAlignment(Element.ALIGN_LEFT);
//         if (idx==0)
//         {
//             cell3.setPaddingLeft(-50);
//             cell3.setBorder(Rectangle.NO_BORDER);            	
//         	cell3.addElement(w_testo);
//         	
//         }
//         if (idx==1)
//         {
//         	cell4.setBorder(Rectangle.NO_BORDER);
//         	cell4.addElement(w_testo);
//             
//         }            
//         if (idx==2)
//         {
//         	cell5.setColspan(2);
//             cell5.setPaddingLeft(-50);
//             cell5.setBorder(Rectangle.NO_BORDER);            	
//         	cell5.addElement(w_testo);
//         }            
//     }
// 	table2.addCell(cell3);
//     table2.addCell(cell4);             	
// 	table2.addCell(cell5);        
//     cell2.addElement(table2); 
//     table.addCell(cell2);
//     table.setTotalWidth(550);
//     table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);       
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		if (nriga_posizione != 0)
//		{	
//			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
//		}
//		else
//		{	
//			nriga_posizione = 790;
//		}    		
// 
//      return table;
// }     
    
    public boolean ristampaRicevutaIdUtentePDF(String id_utente)
   	{	
   		boolean result = false;
		try
		{
			CandidaturaHome candidaturaDAO = new CandidaturaHome();
			UtenteCandidatura utenteCandidatura = null;
			utenteCandidatura = candidaturaDAO.findByUserId(id_utente);
			RicevuteHome ricevuteDAO = new RicevuteHome();
			Ricevute ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
			ricevute = ricevuta;
			if (ricevuta!=null)
			{
				setImgRicevutaPDF(ricevuta.getContenutoFile());
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 		
   		return result;
   		
   	}  
    

    public boolean ristampaRicevutaIdUtentePDFRecovery(String id_utente)
   	{	
   		boolean result = false;
		try
		{
			CandidaturaHome candidaturaDAO = new CandidaturaHome();
			UtenteCandidatura utenteCandidatura = null;
			utenteCandidatura = candidaturaDAO.findByUserId(id_utente);
			RicevuteHome ricevuteDAO = new RicevuteHome();
			Ricevute ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
			ricevute = ricevuta;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 		
   		return result;
   		
   	}  
    
    public boolean caricaDatiDaUtentePerEntityPDF(String id_utente)
   	{	
   		boolean result = false;
		try
		{
			CandidaturaHome candidaturaDAO = new CandidaturaHome();
			UtenteCandidatura utenteCandidatura = null;
			utenteCandidatura = candidaturaDAO.findByUserId(id_utente);
			if (utenteCandidatura!=null)
			{
				List<Utente> listaUtente = new ArrayList<Utente>();				
				listaUtente = candidaturaDAO.listaUtentiXIdCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
				for (Utente w_utente : listaUtente)
				{
					initEntityPDFromEntityUtente(w_utente);
					getListaEntityPDFRicevuta().add(getEntityPDFRicevuta());
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 		
   		return result;
   		
   	}     

	public static String formattaDataTOString(Date w_date, String formatOra)
	{
		Calendar cal = Calendar.getInstance();
		String result = "";
		if (w_date!=null)
		{
			try { 
				cal.setTime(w_date);
				// Set time fields to zero  
				cal.set(Calendar.HOUR_OF_DAY, 0);  
				cal.set(Calendar.MINUTE, 0);  
				cal.set(Calendar.SECOND, 0);  
				cal.set(Calendar.MILLISECOND, 0);	
				SimpleDateFormat formatterOut = null;
				if (formatOra!=null)
				{	
					formatterOut = new SimpleDateFormat("dd-MM-yyyy" + " " + formatOra);
				}
				else
				{	
					formatterOut = new SimpleDateFormat("dd-MM-yyyy");
				}
					
					  
				result = formatterOut.format(cal.getTime()); 
			}
			catch (Exception e)
			{}			

		}
		return result;

	}
    
    public  void initEntityPDFromEntityUtente(Utente utente)
    {
    	try
    	 {
    		/* inizializzazione strutture di prelievo dati */
	    	entityPDFRicevuta = new EntityPDFRicevuta(); 
	    	regione = regioneDAO.findById((utente.getCodRegUtente()==null)?"":utente.getCodRegUtente());
	    	if (regione==null) regione = new Regione();
	    	uteCandi = candidaturaHome.findByUserId((utente.getIdUtente()==null)?"":utente.getIdUtente());
	    	if (uteCandi == null) uteCandi = new UtenteCandidatura();
//	    	if(uteCandi.getCandidatura().getStatoDomanda()!=null && uteCandi.getCandidatura().getStatoDomanda().equals("I")){
//	    		//query per prendere il numero protocollo e la data invio precedenti alla rettifica attuale
//	    		
//	    		entityPDFRicevuta.setDataInvioRettificata(dataInvioRettificata)
//	    		entityPDFRicevuta.setNumeroProtocolloRettificata(numeroProtocolloRettificata)
//	    	}
	    	requiMinimi = requiMinimiDAO.findById((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());
	    	if (requiMinimi != null){
	    		requiMinimi.setCodTipoLaurea(matriceDe.getMatricePropertiesDe(requiMinimi.getCodTipoLaurea().replace(" ", "_")));
	    		requiMinimi.setNazioneAbilitazione(matriceDe.getMatricePropertiesDe(requiMinimi.getNazioneAbilitazione().replace(" ", "_")));
	    	}else{ 
	    		requiMinimi = new RequisitiMinimi();
	    		}
	    	login = logInDAO.findByIdHql((utente.getIdUtente()==null)?"":utente.getIdUtente());
	    	if (login == null) login = new LogIn();
	    	
	    	altraLaurea = altraLaureaDAO.findById((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());
	    	
	    	if (altraLaurea!=null && altraLaurea.getIdSecondaLaurea()!=null){
	    		altraLaurea.setIdSecondaLaurea( matriceDe.getMatricePropertiesDe(altraLaurea.getIdSecondaLaurea().replace(" ", "_")));
	    		altraLaurea.setFlagEsteroSecondaLaurea(matriceDe.getMatricePropertiesDe(altraLaurea.getFlagEsteroSecondaLaurea().replace(" ", "_")));
	    		altraLaurea.setNazioneSecondaLaurea(matriceDe.getMatricePropertiesDe(altraLaurea.getNazioneSecondaLaurea().replace(" ", "_")));
	    		
	    	}else{
	    		altraLaurea = new AltraLaurea();
	    	}
	    	
	    	
	    	altraLaureaBis = altraLaureaBisDAO.findByIdHql((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());
	    	if(altraLaureaBis!=null && altraLaureaBis.getIdAltraLaureaBis()!=null){
	    		String id = matriceDe.getMatricePropertiesDe(altraLaureaBis.getIdAltraLaureaBis().replace(" ", "_")).toString();
				altraLaureaBis.setIdAltraLaureaBis(id);
		    	altraLaureaBis.setFlagEsteroSecondaLaureaBis(matriceDe.getMatricePropertiesDe(altraLaureaBis.getFlagEsteroSecondaLaureaBis().replace(" ", "_")));
				altraLaureaBis.setNazioneSecondaLaureaBis(matriceDe.getMatricePropertiesDe(altraLaureaBis.getNazioneSecondaLaureaBis().replace(" ", "_")));
				
	    	}
	    	
	    	listSpecializzazione = specializzazioneDAO.findByExampleHql((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());
	        BorsaStudio borsaAppoggio = new BorsaStudio();
	        borsaAppoggio.setIdDomandaBorsaStudio((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());
	        listBorsaStudio =  borsaStudioDAO.findByExample(borsaAppoggio);
	        listDottorato = dottoratoDAO.findByExampleHql((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());
	        AltroTitolo titoloAppoggio = new AltroTitolo();
	        titoloAppoggio.setIdDomandaTitolo((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());
	        listAltriTitolo = altroTitoloDAO.findByExample(titoloAppoggio);
	        idoneita = ideoneitaDAO.findById((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());
	        if (idoneita == null) idoneita = new Idoneita();
	        CorsoAggiornamento corsoAppoggio = new CorsoAggiornamento();
	        corsoAppoggio.setIdDomandaAgg((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());
	        listCorsoAggiornamento = corsoAggiornamentoDAO.findByExample(corsoAppoggio);
	        Pubblicazione pubbAppoggio =new Pubblicazione();
	        pubbAppoggio.setIdDomandaPubbl((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());	        
	        listPubblicazione = pubblicazioneDAO.findByExample(pubbAppoggio);
	        
	        EsercizioProf esercizioProfAppoggio = new EsercizioProf();
	        esercizioProfAppoggio.setIdDomandaEs((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());
	        listEsercizioProf = esercizioProfDAO.findByExample(esercizioProfAppoggio);
	        if (esercizioProf==null) esercizioProf = new EsercizioProf();
	        dichiarazioneSostitutiva = dichiarazioneSostitutivaDAO.findById((uteCandi.getIdDomandaUtente()==null)?"":uteCandi.getIdDomandaUtente());	        
	        if (dichiarazioneSostitutiva==null) dichiarazioneSostitutiva = new DichiarazioneSostitutiva();
	        listDocumenti = documentoDAO.findListDocumentiById(dichiarazioneSostitutiva.getIdDomandaDic());	        
	        datiBando = datiBandoDAO.findById((uteCandi.getCodRegUtente()==null)?"":uteCandi.getCodRegUtente());
	        if (datiBando==null) datiBando=new DatiBando();
	        String wDocumenti = "";
	        for (Documento w_doc : listDocumenti)
	        {
	        	wDocumenti = wDocumenti + w_doc.getTipoDocumento() + "#";
	        }
	        dichiarazioneSostitutiva.setElencoDocumenti(wDocumenti);
	        Localita localita = new Localita();
	        CaricaRuoli caricaruoli = new CaricaRuoli();
	        String descrizione = "";
	        /*--------------------------------------------*/
	    	
	    	entityPDFRicevuta.setDescRegUtente(((regione.getDenominazioneReg() == null) ?"":regione.getDenominazioneReg()));
	    	if (dateInvio.equals(""))
	    	{
	    		entityPDFRicevuta.setDataInvio(((uteCandi.getCandidatura().getDataInvioDomanda()==null)?"":formattaDataTOString(uteCandi.getCandidatura().getDataInvioDomanda(),null)));	    		
	    	}
	    	else
	    	{
	    		entityPDFRicevuta.setDataInvio(dateInvio);	    		
	    	}
	    	
	    		    		
	    	ValoriCodiceId valId = new ValoriCodiceId();
	        valId.setCodice(((uteCandi.getCandidatura().getModalitaCandidatura()==null)?"":uteCandi.getCandidatura().getModalitaCandidatura()));
	        valId.setTipoCodice("COD_MOD_PARTECIPAZIONE");
	        valoriCodice.setIdKey(valId);
	        valoriCodice = valoriCodiceDAO.findById(valId);
	        if (valoriCodice==null) valoriCodice = new ValoriCodice();
	    	entityPDFRicevuta.setModoPartecipa(valoriCodice.getDescrizioneDe());
	    	entityPDFRicevuta.setNumeroProtocollo(numero_protocollo_ricevuta);
	    	entityPDFRicevuta.setCognome((uteCandi.getCognomeUtente()==null)?"":uteCandi.getCognomeUtente());
	    	entityPDFRicevuta.setNome((uteCandi.getNomeUtente()==null)?"":uteCandi.getNomeUtente());
	    	
	    	entityPDFRicevuta.setSesso((uteCandi.getSesso()==null)?"":uteCandi.getSesso());
	    	
	    	descrizione = (uteCandi.getCodiceFiscaleUtente()==null)?"":uteCandi.getCodiceFiscaleUtente();
	    	if(descrizione!=null && descrizione.startsWith("*"))descrizione="N.D.";
	    	entityPDFRicevuta.setCodifisc(descrizione);
	    	entityPDFRicevuta.setDataNascita((uteCandi.getDataNascitaUtente()==null)?"":formattaDataTOString(uteCandi.getDataNascitaUtente(),null));
	    	descrizione = localita.getDenominazioneComune((uteCandi.getLuogoNascitaUtente()==null)?"":uteCandi.getLuogoNascitaUtente());
	    	entityPDFRicevuta.setComuneNascita(((descrizione=="") || (descrizione==null))?"":descrizione);
	    	descrizione = localita.getDenominazioneProvincia((uteCandi.getPrvNascitaUtente()==null)?"":uteCandi.getPrvNascitaUtente());
	    	entityPDFRicevuta.setProvNascita(((descrizione=="") || (descrizione==null))?"":descrizione);
	    	entityPDFRicevuta.setLocalitaEsteraNascita((uteCandi.getLuogoNascitaEstera()==null)?"":uteCandi.getLuogoNascitaEstera());
	    	descrizione = localita.getDenominazioneNazione((uteCandi.getNazioneNascitaUtente()==null)?"":uteCandi.getNazioneNascitaUtente(),lingua);
	    	entityPDFRicevuta.setStatoNascita(descrizione);
	    	
	    	valId = new ValoriCodiceId();
	        valId.setCodice(((uteCandi.getTipoDocumento()==null)?"":uteCandi.getTipoDocumento()));
	        valId.setTipoCodice("TIPO_DOC_RICONOSCIMENTO");
	        valoriCodice.setIdKey(valId);
	        valoriCodice = valoriCodiceDAO.findById(valId);
	        entityPDFRicevuta.setEstremiDocumento(valoriCodice.getDescrizioneDe() + ": " + ((uteCandi.getNumeroDoc()==null)?"":uteCandi.getNumeroDoc()) + "," + ((uteCandi.getEnteRilascioDoc()==null)?"":uteCandi.getEnteRilascioDoc()) + ((uteCandi.getDataRilascioDoc()==null)?"":" ("+formattaDataTOString(uteCandi.getDataRilascioDoc(),null)+")"));
	    	
	        entityPDFRicevuta.setIndirizzoResidenza((uteCandi.getIndirizzoResidenza()==null)?"":uteCandi.getIndirizzoResidenza());
	    	//nazione residenza
	        descrizione = localita.getDenominazioneNazione((uteCandi.getNazioneResidenzaUtente()==null)?"":uteCandi.getNazioneResidenzaUtente(),lingua);
	        entityPDFRicevuta.setNazioneResidenzaUtente(descrizione);
	        entityPDFRicevuta.setLocalitaResidenzaEstera((uteCandi.getLocalitaResidenzaEstera()==null)?"":localita.getDenominazioneNazione((uteCandi.getLocalitaResidenzaEstera()==null)?"":uteCandi.getLocalitaResidenzaEstera(),lingua));
	        descrizione = localita.getDenominazioneProvincia((uteCandi.getPrvResidenzaUtente()==null)?"":uteCandi.getPrvResidenzaUtente());
	    	entityPDFRicevuta.setProvResidenza(((descrizione=="") || (descrizione==null))?"":descrizione);
	    	descrizione = localita.getDenominazioneComune((uteCandi.getComuneResidenzaUtente()==null)?"":uteCandi.getComuneResidenzaUtente());
	    	entityPDFRicevuta.setComuneResidenza(((descrizione=="") || (descrizione==null))?"":descrizione);
	    	entityPDFRicevuta.setCapResidenza((uteCandi.getCapResidenzaUtente()==null)?"":uteCandi.getCapResidenzaUtente());
	    	
	    	entityPDFRicevuta.setRifTelefonico(((uteCandi.getnTelefonoUtente()==null)? "" : uteCandi.getnTelefonoUtente()+" (Festnetz)") + ((uteCandi.getnCellulareUtente()==null)? "" : ((uteCandi.getnTelefonoUtente()==null)?"":" - ") + uteCandi.getnCellulareUtente()+" (Mobiltelefon)"));
	    	
	    	entityPDFRicevuta.setEmailCertificata((uteCandi.getPecMail()==null)?"":uteCandi.getPecMail());
	    	
	    	valId = new ValoriCodiceId();
	        valId.setCodice((requiMinimi.getFattispecieAppartenenza()==null)?"":requiMinimi.getFattispecieAppartenenza());
	        valId.setTipoCodice("COD_FATTISPECIE");
	        valoriCodice.setIdKey(valId);
	        valoriCodice = valoriCodiceDAO.findById(valId);
	        
	        if (valoriCodice==null)
	        {
	        	entityPDFRicevuta.setAppartenenza(" - ");
	        }
	        else
	        {
	        	entityPDFRicevuta.setAppartenenza(valoriCodice.getDescrizioneDe());
	        }
	    	
	    	descrizione = localita.getDenominazioneNazione((uteCandi.getStatoUe()==null)?"":uteCandi.getStatoUe(),lingua);
	    	entityPDFRicevuta.setCittadinanza(((descrizione=="") || (descrizione==null))?"":descrizione);
	    	
	    	descrizione = localita.getDenominazioneComune((uteCandi.getComuneListaElettorale()==null)?"":uteCandi.getComuneListaElettorale());
	    	entityPDFRicevuta.setListaElettorale(((descrizione=="") || (descrizione==null))?"":descrizione);
	    	
	    	descrizione = localita.getDenominazioneProvincia((requiMinimi.getPrvAlbo()==null)?"":requiMinimi.getPrvAlbo());
	    	entityPDFRicevuta.setProvIscrizioneFarmacisti(((descrizione=="") || (descrizione==null))?"":descrizione);
	    	descrizione = localita.getDenominazioneProvincia((requiMinimi.getPrvAttualeAlbo()==null)?"":requiMinimi.getPrvAttualeAlbo());
	    	entityPDFRicevuta.setProvAttualeIscrizioneFarmacisti(((descrizione=="") || (descrizione==null))?"":descrizione);
	    	entityPDFRicevuta.setDataPrimaIscrizioneFarmacisti((requiMinimi.getDataAlbo()==null)?"":formattaDataTOString(requiMinimi.getDataAlbo(),null));
	    	entityPDFRicevuta.setNumeroIscrizioneFarmacisti((requiMinimi.getNAlbo()==null)?"":requiMinimi.getNAlbo());
	    	
	    	String codice_regione = (uteCandi.getCodRegUtente()==null)?"":uteCandi.getCodRegUtente();
	    	
	    	entityPDFRicevuta.setPaBolzano("");
	    	if (codice_regione.equals("041")) /* Reg Autonoma di PA BOlzano */
	    	{
	    		String messaggioAttestato="";
    			if(requiMinimi.getAttestato()!=null)
    			{
    				if(requiMinimi.getAttestato().equals("1"))
    				{
    					messaggioAttestato=bodyRicevuta.getProperty("attestato.lingue.1");
    				}
    				else if(requiMinimi.getAttestato().equals("2"))
    				{
    					messaggioAttestato=bodyRicevuta.getProperty("attestato.lingue.2");
    				}
    			}
	    		entityPDFRicevuta.setPaBolzano(messaggioAttestato);
	    	}
	    	entityPDFRicevuta.setTipoLaurea((requiMinimi.getCodTipoLaurea()==null)?"":requiMinimi.getCodTipoLaurea());
	    	entityPDFRicevuta.setUniversitaConseg((requiMinimi.getDescrUniversita()==null)?"":requiMinimi.getDescrUniversita());
	    	entityPDFRicevuta.setLuogoLaurea((requiMinimi.getLuogoLaurea()==null)?"":requiMinimi.getLuogoLaurea());
	    	entityPDFRicevuta.setDataLaurea((requiMinimi.getDataLaurea()==null)?"":formattaDataTOString(requiMinimi.getDataLaurea(),null));
	    	entityPDFRicevuta.setVotoLaurea((requiMinimi.getVotoLaurea()==null)?"":requiMinimi.getVotoLaurea().toString());
	    	entityPDFRicevuta.setBaseVotoLaurea((requiMinimi.getBaseVotoLaurea()==null)?"":requiMinimi.getBaseVotoLaurea().toString());
	    	
	    	if(requiMinimi.getFlagLode()!=null && requiMinimi.getFlagLode().equals("true"))
	    	{
	    		entityPDFRicevuta.setLodeVotoLaurea("e Lode");
	    	}
	    	else
	    	{
	    		entityPDFRicevuta.setLodeVotoLaurea("");
	    	}
	    	
	    	entityPDFRicevuta.setNazioneAbilitazione((requiMinimi.getNazioneAbilitazione()==null)?"":requiMinimi.getNazioneAbilitazione());
	    	entityPDFRicevuta.setUniversitaAbiltazione((requiMinimi.getDescrUniAbilitazione()==null)?"":requiMinimi.getDescrUniAbilitazione());
	    	entityPDFRicevuta.setLuogoAbilitazione((requiMinimi.getLuogoUniAbilitazione()==null)?"":requiMinimi.getLuogoUniAbilitazione());
	    	entityPDFRicevuta.setAnnoAbilitazione((requiMinimi.getAnnoAbilitazione()==null)?"":requiMinimi.getAnnoAbilitazione().toString());
	    	entityPDFRicevuta.setVotoAbilitazione((requiMinimi.getVotoAbilitazione()==null)?"":requiMinimi.getVotoAbilitazione().toString());
	    	entityPDFRicevuta.setBaseVotoAbilitazione((requiMinimi.getBaseVotoAbilitazione()==null)?"":requiMinimi.getBaseVotoAbilitazione().toString());
	    	entityPDFRicevuta.setEstremiAbilitazione((requiMinimi.getEstremiAbilitazioneEstera()==null)?"":requiMinimi.getEstremiAbilitazioneEstera());
	    	entityPDFRicevuta.setAltraLaureaF((altraLaurea.getIdSecondaLaurea()==null)?"":altraLaurea.getIdSecondaLaurea());
	       	entityPDFRicevuta.setUnivAltraLaureaF((altraLaurea.getDescUniSecondaLaurea()==null)?"":altraLaurea.getDescUniSecondaLaurea());
	    	entityPDFRicevuta.setLuogoAltraLaureaF((altraLaurea.getLuogoSecondaLaurea()==null)?"":altraLaurea.getLuogoSecondaLaurea());
	    	entityPDFRicevuta.setDataAltraLaureaF((altraLaurea.getDataSecondaLaurea()==null)?"":formattaDataTOString(altraLaurea.getDataSecondaLaurea(),null));
	    	entityPDFRicevuta.setNazioneAltraLaureaF((altraLaurea.getNazioneSecondaLaurea()==null)?"":altraLaurea.getNazioneSecondaLaurea());
	    	entityPDFRicevuta.setSeEsteraPrivataAltraLaureaF((altraLaurea.getFlagEsteroSecondaLaurea()==null)?"":altraLaurea.getFlagEsteroSecondaLaurea());
	    	entityPDFRicevuta.setAltraLaurea((altraLaureaBis.getIdAltraLaureaBis()==null)?"":altraLaureaBis.getIdAltraLaureaBis());
	    	entityPDFRicevuta.setUnivAltraLaurea((altraLaureaBis.getDescUniSecondaLaureaBis()==null)?"":altraLaureaBis.getDescUniSecondaLaureaBis());
	    	entityPDFRicevuta.setLuogoAltraLaurea((altraLaureaBis.getLuogoSecondaLaureaBis()==null)?"":altraLaureaBis.getLuogoSecondaLaureaBis());
	    	entityPDFRicevuta.setDataAltraLaurea((altraLaureaBis.getDataSecondaLaureaBis()==null)?"":formattaDataTOString(altraLaureaBis.getDataSecondaLaureaBis(),null));
	    	entityPDFRicevuta.setNazioneAltraLaurea((altraLaureaBis.getNazioneSecondaLaureaBis()==null)?"":altraLaureaBis.getNazioneSecondaLaureaBis());
	    	entityPDFRicevuta.setSeEsteraPrivataAltraLaurea((altraLaureaBis.getFlagEsteroSecondaLaureaBis()==null)?"":altraLaureaBis.getFlagEsteroSecondaLaureaBis());
	    	
	    	for (Specializzazione specia : listSpecializzazione)
	    	{
	    		SpecializzazioniUniversitarie result_1 = new SpecializzazioniUniversitarie();
		    	result_1.setDenomSpecializza((specia.getDenominazioneSpec()==null)?"":specia.getDenominazioneSpec());
		    	result_1.setFacoltaSpecializza((specia.getDescrFacoltaSpec()==null)?"":specia.getDescrFacoltaSpec());
		    	result_1.setUniveSpecializza((specia.getDescrUniversitaSpec()==null)?"":specia.getDescrUniversitaSpec());
		    	result_1.setLuogoSpecializza((specia.getLuogoSpec()==null)?"":specia.getLuogoSpec());
		    	result_1.setNazioneSpecializza((specia.getNazioneSpec()==null)?"":matriceDe.getMatricePropertiesDe(specia.getNazioneSpec().replace(" ", "_")));
		    	result_1.setDurataSpecializza((specia.getDurataSpec()==null)?"":specia.getDurataSpec().toString());
		    	result_1.setSeEsteraPrivataSpecializza((specia.getFlagEsteroSpec()==null)?"":matriceDe.getMatricePropertiesDe(specia.getFlagEsteroSpec().replace(" ", "_")));
		    	entityPDFRicevuta.getListaSpeciaUnivers().add(result_1);	    		
	    	}
	    	
	    	for (BorsaStudio borsa : listBorsaStudio)
	    	{
		    	BorseDiStudio result_2 = new BorseDiStudio();    	
		    	result_2.setDenomBStudio((borsa.getDenominazioneBorsa()==null)?"":borsa.getDenominazioneBorsa());
		    	result_2.setFacoltaBStudio((borsa.getDescrFacoltaBorsa()==null)?"":borsa.getDescrFacoltaBorsa());
		    	result_2.setUniveBStudio((borsa.getDescrUniversitaBorsa()==null)?"":borsa.getDescrUniversitaBorsa());
		    	result_2.setLuogoBStudio((borsa.getLuogoBorsa()==null)?"":borsa.getLuogoBorsa());
		    	result_2.setNazioneBStudio((borsa.getNazioneBorsa()==null)?"":matriceDe.getMatricePropertiesDe(borsa.getNazioneBorsa().replace(" ", "_")));
		    	String dataInizio  = (borsa.getDataInizioBorsa()==null)?"":formattaDataTOString(borsa.getDataInizioBorsa(),null);
		    	String dataFine   = (borsa.getDataFineBorsa()==null)?"":formattaDataTOString(borsa.getDataFineBorsa(),null);
		    	result_2.setDataIniFineBStudio(dataInizio + " / " + dataFine);
		    	result_2.setSeEsteraPrivataBStudio((borsa.getFlagEsteroBorsa()==null)?"":matriceDe.getMatricePropertiesDe(borsa.getFlagEsteroBorsa().replace(" ", "_")));
		    	entityPDFRicevuta.getListaBorseDiStudio().add(result_2);
	    	}
	    	
	    	for (Dottorato dotto : listDottorato)
	    	{
	    		
		    	DottoratoPDF result_3 = new DottoratoPDF();
		    	result_3.setDenomDottorato((dotto.getDenominazioneDottorato()==null)?"":dotto.getDenominazioneDottorato());
		    	result_3.setFacoltaDottorato((dotto.getDescrFacoltaDottorato()==null)?"":dotto.getDescrFacoltaDottorato());
		    	result_3.setUniveDottorato((dotto.getDescrUniversitaDottorato()==null)?"":dotto.getDescrUniversitaDottorato());
		    	result_3.setLuogoDottorato((dotto.getLuogoDottorato()==null)?"":dotto.getLuogoDottorato());
		    	result_3.setNazioneDottorato((dotto.getNazioneDottorato()==null)?"":matriceDe.getMatricePropertiesDe(dotto.getNazioneDottorato().replace(" ", "_")));
		    	String dataInizio  = (dotto.getDataInizioDottorato()==null)?"":formattaDataTOString(dotto.getDataInizioDottorato(),null);
		    	String dataFine   = (dotto.getDataFineDottorato()==null)?"":formattaDataTOString(dotto.getDataFineDottorato(),null);		    	
		    	result_3.setDataIniFineDottorato(dataInizio + " / " + dataFine);
		    	result_3.setSeEsteraPrivataDottorato((dotto.getFlagEsteroDottorato()==null)?"":matriceDe.getMatricePropertiesDe(dotto.getFlagEsteroDottorato().replace(" ", "_")));
		    	entityPDFRicevuta.getListaDottorato().add(result_3);	    		
	    	}

	    	for (AltroTitolo titolo : listAltriTitolo)
	    	{
		    	AltriTitoli result_4 = new AltriTitoli();    	
		    	result_4.setTitoloAltro((titolo.getDescAltroTitolo()==null)?"":titolo.getDescAltroTitolo());
		    	result_4.setDurataAltro((titolo.getDurataAltroTitolo()==null)?"":titolo.getDurataAltroTitolo().toString());
		    	result_4.setRilasciatoDaAltro((titolo.getRilascioAltroTitolo()==null)?"":titolo.getRilascioAltroTitolo());
		    	result_4.setDataRilascio((titolo.getDataRilascioAltroTitolo()==null)?"":formattaDataTOString(titolo.getDataRilascioAltroTitolo(),null));
		    	result_4.setEsitoFinaleAltro((titolo.getEsameFinaleAltroTitolo()==null)?"":matriceDe.getMatricePropertiesDe(titolo.getEsameFinaleAltroTitolo().replace(" ", "_")));
		    	result_4.setNoteAltro((titolo.getNoteAltroTitolo()==null)?"":titolo.getNoteAltroTitolo());
		    	result_4.setSeEsteraPrivataAltro((titolo.getFlagEsteroAltroTitolo()==null)?"":matriceDe.getMatricePropertiesDe(titolo.getFlagEsteroAltroTitolo().replace(" ", "_")));
		    	entityPDFRicevuta.getListaAltriTitoli().add(result_4);	    		
	    	}
	    	String w_idoneita = "";
	    	
	    	if(idoneita.getFlagIdoneitaSediIdoneita()!=null && idoneita.getFlagIdoneitaSediIdoneita().equals("true"))
	    	{
	    		w_idoneita = "Ja";
	    	}
	    	
	    	entityPDFRicevuta.setIdoneitaConseguita(w_idoneita);
	    	entityPDFRicevuta.setEstremiAtto((idoneita.getEstremiIdoneita()==null)?"":idoneita.getEstremiIdoneita());
	    	entityPDFRicevuta.setDataAtto((idoneita.getDataIdoneita()==null)?"":formattaDataTOString(idoneita.getDataIdoneita(),null));
	    	entityPDFRicevuta.setRifIdoneitaNaz((idoneita.getRifIdoneitaNazionale()==null)?"":idoneita.getRifIdoneitaNazionale());
	    	entityPDFRicevuta.setAnnoIdoneitaNaz((idoneita.getAnnoIdoneitaNazionale()==null)?"":idoneita.getAnnoIdoneitaNazionale().toString());
	    	
	    	for (CorsoAggiornamento corso : listCorsoAggiornamento)
	    	{
		    	CorsoDiAggiornamento result_5 = new CorsoDiAggiornamento();
		    	result_5.setTitoloAggCorso((corso.getTitoloCorsoAgg()==null)?"":corso.getTitoloCorsoAgg());
		    	result_5.setOrganizzatoAggCorso((corso.getOrganizzatoCorsoAgg()==null)?"":corso.getOrganizzatoCorsoAgg());
		    	
		    	result_5.setGiornoPeridoAggCorso("Von "
		    									+((corso.getDataInizioCorsoAgg()==null)?"?":formattaDataTOString(corso.getDataInizioCorsoAgg(),null))
		    									+" bis "
		    									+((corso.getDataFineCorsoAgg()==null)?"?":formattaDataTOString(corso.getDataFineCorsoAgg(),null)));
		    	
		    	result_5.setTotaleOreEsame((corso.getTotOreCorsoAgg()==null)?"":corso.getTotOreCorsoAgg().toString());
		    	result_5.setEsitoEsameSuperato((corso.getDichiarazioneCorsoAgg()==null)?"":matriceDe.getMatricePropertiesDe(corso.getDichiarazioneCorsoAgg().replace(" ", "_")));
		    	result_5.setSeEsteroPrivatoEsame((corso.getFlagEsteroCorsoAgg()==null)?"":matriceDe.getMatricePropertiesDe(corso.getFlagEsteroCorsoAgg().replace(" ", "_")));
		    	entityPDFRicevuta.getListaCorsiAggiornamento().add(result_5);
	    	}
	    	
	    	entityPDFRicevuta.setDataPartenzaCorso((datiBando.getDataInizioCorsi()==null)?"":formattaDataTOString(datiBando.getDataInizioCorsi(),null));

	    	for (Pubblicazione pubblica : listPubblicazione)
	    	{
		    	PubblicazioneScentifica result_6 = new PubblicazioneScentifica(); 	    
		    	result_6.setTipoPubblic((pubblica.getTipoPubblicazione()==null)?"":matriceDe.getMatricePropertiesDe(pubblica.getTipoPubblicazione().replace(" ", "_")));
		    	result_6.setAutorePubb((pubblica.getAutorePubblicazione()==null)?"":pubblica.getAutorePubblicazione());
		    	result_6.setDataPubblicazione((pubblica.getDataPubblicazione()==null)?"":formattaDataTOString(pubblica.getDataPubblicazione(),null));
		    	result_6.setTitoloStudio((pubblica.getTitoloPubblicazione()==null)?"":pubblica.getTitoloPubblicazione());
		    	result_6.setEditoreStudio((pubblica.getEditorePubblicazione()==null)?"":pubblica.getEditorePubblicazione());
		    	result_6.setIsbn((pubblica.getCodIsbn()==null)?"":pubblica.getCodIsbn());
		    	entityPDFRicevuta.getListaPubblicaScentifica().add(result_6);	    		
	    	}	    	
	    	entityPDFRicevuta.setDataPubbScient((datiBando.getDataInizioPubblicazioni()==null)?"":formattaDataTOString(datiBando.getDataInizioPubblicazioni(),null));
	    	
	    	for (EsercizioProf esercizioProf : listEsercizioProf)
	    	{
		    	EsercizioProfessionale result_7 = new EsercizioProfessionale(); 
		    	
		    	result_7.setDalTitoloProf((esercizioProf.getDataInizioEs()==null)?"":formattaDataTOString(esercizioProf.getDataInizioEs(),null));
		    	result_7.setAlTitoloProf((esercizioProf.getDataFineEs()==null)?"":formattaDataTOString(esercizioProf.getDataFineEs(),null));
		    	valId = new ValoriCodiceId();
		        valId.setCodice((esercizioProf.getCodModalitaEs()==null)?"":esercizioProf.getCodModalitaEs());
		        valId.setTipoCodice("COD_MODO_ES");
		        valoriCodice.setIdKey(valId);
		        valoriCodice = valoriCodiceDAO.findById(valId);
		        if (valoriCodice==null) valoriCodice = new ValoriCodice();
		    	descrizione = valoriCodice.getDescrizioneDe();
		    	result_7.setModoTitoloProf(((descrizione=="") || (descrizione==null))?"":descrizione);
		    	descrizione = caricaruoli.decodificaRuolo((esercizioProf.getCodRuoloEs()==null)?"":esercizioProf.getCodRuoloEs(),lingua);
		    	result_7.setRuoloTitoloProf(((descrizione=="") || (descrizione==null))?"":descrizione);
		        valId = new ValoriCodiceId();
		        valId.setCodice((esercizioProf.getCodCategoriaEs()==null)?"":esercizioProf.getCodCategoriaEs());
		        valId.setTipoCodice("COD_CATEGORIA_ES");
		        valoriCodice.setIdKey(valId);
		        valoriCodice = valoriCodiceDAO.findById(valId);
		        if (valoriCodice==null) valoriCodice = new ValoriCodice();
		        result_7.setTipoStruttura((valoriCodice.getDescrizioneDe()==null)?"":valoriCodice.getDescrizioneDe());
		        result_7.setDenomStruttura((esercizioProf.getDenEsercizio()==null)?"":esercizioProf.getDenEsercizio());
		        result_7.setIndiStruttura((esercizioProf.getIndirizzoEs()==null)?"":esercizioProf.getIndirizzoEs());
		    	
		        result_7.setCapStruttura((esercizioProf.getCapEs()==null)?" - ":esercizioProf.getCapEs());
		        
		        descrizione = localita.getDenominazioneRegione((esercizioProf.getRegEs()==null)?"":esercizioProf.getRegEs());
		    	result_7.setRegioneStruttura(((descrizione=="") || (descrizione==null))?esercizioProf.getRegEs():descrizione);
		    	descrizione = localita.getDenominazioneProvincia((esercizioProf.getPrvEs()==null)?"":esercizioProf.getPrvEs());
		    	result_7.setProvStruttura(((descrizione=="") || (descrizione==null))?esercizioProf.getPrvEs():descrizione);
		    	descrizione = localita.getDenominazioneComune((esercizioProf.getComuneEs()==null)?"":esercizioProf.getComuneEs());
		    	result_7.setComStruttura(((descrizione=="") || (descrizione==null))?esercizioProf.getComuneEs():descrizione);
		    	result_7.setAslRiferimento((esercizioProf.getAslEs()==null)?"":esercizioProf.getAslEs());
		    	//result_7.setFarmRurale((esercizioProf.getFlagFarmRurale()==null)?"":esercizioProf.getFlagFarmRurale());
		    	
		    	if(esercizioProf.getFlagFarmRurale().equals("Si")){
	        		
	        		result_7.setFarmRurale("Ja");
	        		}
	        		 if(esercizioProf.getFlagFarmRurale().equals("No")){
		        		
				    	result_7.setFarmRurale("Nein");

		        	}
		    	entityPDFRicevuta.getListaEsercizioProfessionale().add(result_7);	    		
	    	}	    	
	    	

	    	
	    	entityPDFRicevuta.setContributoPartecipazione(datiBando.getContributoPartecipazione());
	    	
	    	if(entityPDFRicevuta.getContributoPartecipazione()!=null && entityPDFRicevuta.getContributoPartecipazione().equals("1")){
	    	
	    		entityPDFRicevuta.setEstremiVersamento((datiBando.getEstremiPagamento()==null)?"":datiBando.getEstremiPagamento());
	    		entityPDFRicevuta.setDataOperazioneVers((dichiarazioneSostitutiva.getDataOperazione()==null)?"":formattaDataTOString(dichiarazioneSostitutiva.getDataOperazione(),null));
	    		entityPDFRicevuta.setIbanVersamento((dichiarazioneSostitutiva.getIban()==null)?"":dichiarazioneSostitutiva.getIban());  
	    		entityPDFRicevuta.setCroVersamento((dichiarazioneSostitutiva.getCro()==null)?"":dichiarazioneSostitutiva.getCro());   
	    		entityPDFRicevuta.setDataVersamento((dichiarazioneSostitutiva.getDataVersamento()==null)?"":formattaDataTOString(dichiarazioneSostitutiva.getDataVersamento(),null)); 
	    		entityPDFRicevuta.setNumeroUfficio((dichiarazioneSostitutiva.getNumeroUffPostale()==null)?"":dichiarazioneSostitutiva.getNumeroUffPostale());    
	    		entityPDFRicevuta.setProgOperazioneVCY((dichiarazioneSostitutiva.getProgressivoOperazione()==null)?"":dichiarazioneSostitutiva.getProgressivoOperazione());
	    	}
	    	
	    	
	    	String w_documenti = ((dichiarazioneSostitutiva.getElencoDocumenti()==null)?"":dichiarazioneSostitutiva.getElencoDocumenti());
	 	    String[] documenti = w_documenti.split("#");
	 	   /*
	 	    String[] documenti = new String[100];
	 	    for (int idx=0;idx<100;idx++)
	 	    {
	 	    	documenti[idx] = "DOCUMENTO_DOCUMENTO_DOCUMENTO_" + idx;
	 	    }
	 	    */	 	    
	 	   entityPDFRicevuta.getListaDocumentiVersamento().clear();
	 	    for (String valore : documenti)
	 	    {
	 	    	if (!valore.equals(""))
	 	    	 {
	 	    		entityPDFRicevuta.getListaDocumentiVersamento().add(valore);
	 	    	 }	
	 	    }
    	 }
		catch (Exception e)
		{
			e.printStackTrace();
		} 		    	
	}
    
    public  PdfPTable createBoxSecondaLaureaTextF(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();        
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setPaddingLeft(-50);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            	
            }
            if (idx==3)
            {
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }
            if (idx==4)
            {
                cell7.setPaddingLeft(-50);
                cell7.setBorder(Rectangle.NO_BORDER);            	
            	cell7.addElement(w_testo);
            	
            }
            if (idx==5)
            {
                cell8.setBorder(Rectangle.NO_BORDER);            	
            	cell8.addElement(w_testo);
            	
            }          
        }
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);
        table2.addCell(cell6);
        table2.addCell(cell7);
        table2.addCell(cell8);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPagina(table, pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}  
         return table;
    }     
    
    
    
    public  PdfPTable createBoxSpecializzazioniText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	String testo_appoggio = testo;
    	PdfPTable table = new PdfPTable(1);    	
    	PdfPCell cell2 = new PdfPCell();
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);   
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        int nCount = 1;
    	for (SpecializzazioniUniversitarie specializzazioni : entityPDFRicevuta.getListaSpeciaUnivers())
    	{	
    		testo = testo_appoggio;
		    testo = setTextParamatriSpecializzazioni(testo,specializzazioni);
		    PdfPTable table2 = new PdfPTable(2);
		    if (nCount>1) 
		    {
			    	PdfPCell cell3_1 = new PdfPCell();
			    	String testo_vuoto = "";
			        String[] ww_testi = testo_vuoto.split("#");
			        Paragraph w_testo = null;
			        for (int idx=0;idx<ww_testi.length;idx++)
			        {
			            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
			            w_testo.setAlignment(Element.ALIGN_LEFT);  
			            if (idx==0)
			            {
			            	cell3_1.setPaddingLeft(-50);
			            	cell3_1.setColspan(2);
			            	cell3_1.setBorder(Rectangle.NO_BORDER);            	
			            	cell3_1.addElement(w_testo);			            	
			            } 	 			            
			        }
			        table2.addCell(cell3_1);
			        table2.addCell(cell3_1);
		    }
	        PdfPCell cell3 = new PdfPCell();
	        PdfPCell cell4 = new PdfPCell();
	        PdfPCell cell5 = new PdfPCell();
	        PdfPCell cell6 = new PdfPCell();
	        PdfPCell cell7 = new PdfPCell();
	        PdfPCell cell8 = new PdfPCell(); 
	        PdfPCell cell9 = new PdfPCell();		        
	        String[] ww_testi = testo.split("#");
	        Paragraph w_testo = null;
	        for (int idx=0;idx<ww_testi.length;idx++)
	        {
	            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
	            w_testo.setAlignment(Element.ALIGN_LEFT);  
	            if (idx==0)
	            {
	                cell3.setPaddingLeft(-50);
	                cell3.setBorder(Rectangle.NO_BORDER);            	
	            	cell3.addElement(w_testo);	            	
		        } 
		        if (idx==1)
		        {
		            cell4.setBorder(Rectangle.NO_BORDER);            	
		         	cell4.addElement(w_testo);
	            }
		        if (idx==2)
		        {
		            cell5.setPaddingLeft(-50);
		            cell5.setBorder(Rectangle.NO_BORDER);            	
		          	cell5.addElement(w_testo);
	            }
	            if (idx==3)
	            {
	                cell6.setBorder(Rectangle.NO_BORDER);            	
	            	cell6.addElement(w_testo);
	            }
	            if (idx==4)
	            {
	                cell7.setPaddingLeft(-50);
	                cell7.setBorder(Rectangle.NO_BORDER);            	
	            	cell7.addElement(w_testo);
	            }
	            if (idx==5)
	            {
	                cell8.setBorder(Rectangle.NO_BORDER);            	
	            	cell8.addElement(w_testo);
	            } 
	            if (idx==6)
	            {
	                cell9.setPaddingLeft(-50);
	                cell9.setColspan(2);
	                cell9.setBorder(Rectangle.NO_BORDER);            	
	            	cell9.addElement(w_testo);
	            }            
	        }
	        table2.addCell(cell3);
	        table2.addCell(cell4);
	        table2.addCell(cell5);
	        table2.addCell(cell6);
	        table2.addCell(cell7);
	        table2.addCell(cell8);
	        table2.addCell(cell9);	        
		    cell2.addElement(table2);
		    table.addCell(cell2);
		    table.setTotalWidth(550);
		    table = saltoPaginaForzata(table, pdfWrite, canvas,cell2);
		    cell2 = new PdfPCell();
		    if (table==null)
		    {
		    	table = new PdfPTable(1);
		    	cell2.setBorder(Rectangle.BOX);
		    	nriga_posizione = 790;
		    }
		    else
		    {
		    	cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
		    }		    	        	        
		    nCount = nCount + 1;
       } 
       table.setTotalWidth(550);
 	   table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);    	
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}    		

       return table;
    }
    
    
    public  PdfPTable createBoxFineRicevutaText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.NO_BORDER);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        cell2.setBorder(Rectangle.NO_BORDER);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            if (idx==0)
            {
            	w_testo.setAlignment(Element.ALIGN_LEFT);  
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
            	w_testo.setAlignment(Element.ALIGN_LEFT);  
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            }   
        }
        table2.addCell(cell3);
        table2.addCell(cell4);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
         return table;
    }    
    public  PdfPTable createBoxVuotoText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
        try {
            PdfPCell cell = new PdfPCell();
            Paragraph w_testo = new Paragraph(testo,fonts8_normal);
            PdfContentByte canvas = pdfWrite.getDirectContent();
            w_testo.setAlignment(Element.ALIGN_RIGHT);
            cell.addElement(w_testo);             
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);
            table.setTotalWidth(700);
            table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
     		} catch (Exception e) {
     			// TODO Auto-generated catch block
     			e.printStackTrace();
     		}
             return table;
    }    
    public  PdfPTable createBoxPaginazioneText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
        try {
            PdfPCell cell = new PdfPCell();
            Paragraph w_testo = new Paragraph(testo,fonts6_normal);
            PdfContentByte canvas = pdfWrite.getDirectContent();
            w_testo.setAlignment(Element.ALIGN_RIGHT);
            cell.addElement(w_testo);             
            cell.setBorder(Rectangle.NO_BORDER);
            table.addCell(cell);
            table.setTotalWidth(550);
            table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
     		} catch (Exception e) {
     			// TODO Auto-generated catch block
     			e.printStackTrace();
     		}
             return table;
    }
    
    public  PdfPTable createBoxEstremiDocVersamentoText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts6_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);                
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }   
            if (idx==2)
            {
            	cell5.setPaddingLeft(-240);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            }
    
        }        
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);       
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}    
         return table;
    }     
    
    public  PdfPTable createBoxEstremiDocVersamentoTextSecondo(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts6_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
           
    
        }        
        table2.addCell(cell3);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}    
         return table;
    }     
    
    public  PdfPTable createBoxEstremiVersamentoText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();
        PdfPCell cell9 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);     
                if ( (getEntityPDFRicevuta().getCroVersamento().equals("")) &&
                	 (getEntityPDFRicevuta().getIbanVersamento().equals("")))
                {
                    w_testo = new Paragraph("",fonts8_normal);
                    w_testo.setAlignment(Element.ALIGN_LEFT);
                }
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setColspan(2);            	
                cell4.setBorder(Rectangle.NO_BORDER);    
                if ( (getEntityPDFRicevuta().getCroVersamento().equals("")) &&
                   	 (getEntityPDFRicevuta().getIbanVersamento().equals("")))
                   {
                       w_testo = new Paragraph("",fonts8_normal);
                       w_testo.setAlignment(Element.ALIGN_LEFT);
                   }                
            	cell4.addElement(w_testo);
            	
            }   
            if (idx==2)
            {
                cell5.setPaddingLeft(-50);
                cell5.setColspan(2);            	
                cell5.setBorder(Rectangle.NO_BORDER);  
                if ( (getEntityPDFRicevuta().getCroVersamento().equals("")) &&
                   	 (getEntityPDFRicevuta().getIbanVersamento().equals("")))
                   {
                       w_testo = new Paragraph("",fonts8_normal);
                       w_testo.setAlignment(Element.ALIGN_LEFT);
                   }
            	cell5.addElement(w_testo);
            	
            }
            if (idx==3)
            {
                cell6.setPaddingLeft(-50);
                cell6.setColspan(2);            	
                cell6.setBorder(Rectangle.NO_BORDER);  
                if ( (getEntityPDFRicevuta().getCroVersamento().equals("")) &&
                   	 (getEntityPDFRicevuta().getIbanVersamento().equals("")))
                   {
	                       w_testo = new Paragraph("",fonts8_normal);
	                       w_testo.setAlignment(Element.ALIGN_LEFT);
	                      
                   }                
            	cell6.addElement(w_testo);
            	
            }
            if (idx==4)
            {
                cell7.setPaddingLeft(-50);
                cell7.setColspan(2);            	
                cell7.setBorder(Rectangle.NO_BORDER);    
                if ( (getEntityPDFRicevuta().getCroVersamento().equals("")) &&
                      	 (getEntityPDFRicevuta().getIbanVersamento().equals("")))
                {               
	                if ( (getEntityPDFRicevuta().getNumeroUfficio().equals("")) &&
	                      	 (getEntityPDFRicevuta().getProgOperazioneVCY().equals("")))
	                      {
	                          w_testo = new Paragraph("",fonts8_normal);
	                          w_testo.setAlignment(Element.ALIGN_LEFT);
	                      }     
                }   
                else
                {
                    w_testo = new Paragraph("",fonts8_normal);
                    w_testo.setAlignment(Element.ALIGN_LEFT);
                }                  
            	cell7.addElement(w_testo);
            	
            }
            if (idx==5)
            {
                cell8.setPaddingLeft(-50);
                cell8.setColspan(2);            	
                cell8.setBorder(Rectangle.NO_BORDER);    
                if ( (getEntityPDFRicevuta().getCroVersamento().equals("")) &&
                     	 (getEntityPDFRicevuta().getIbanVersamento().equals("")))
               {               
	                if ( (getEntityPDFRicevuta().getNumeroUfficio().equals("")) &&
	                      	 (getEntityPDFRicevuta().getProgOperazioneVCY().equals("")))
	                      {
	                          w_testo = new Paragraph("",fonts8_normal);
	                          w_testo.setAlignment(Element.ALIGN_LEFT);
	                      }     
               }   
               else
               {
                   w_testo = new Paragraph("",fonts8_normal);
                   w_testo.setAlignment(Element.ALIGN_LEFT);
               }                  
            	cell8.addElement(w_testo);
            }
            if (idx==6)
            {
                cell9.setPaddingLeft(-50);
                cell9.setColspan(2);            	
                cell9.setBorder(Rectangle.NO_BORDER);    
                if ((getEntityPDFRicevuta().getCroVersamento().equals("")) &&
                     	 (getEntityPDFRicevuta().getIbanVersamento().equals("")))
               {                 
	                if ( (getEntityPDFRicevuta().getNumeroUfficio().equals("")) &&
	                      	 (getEntityPDFRicevuta().getProgOperazioneVCY().equals("")))
	                      {
	                          w_testo = new Paragraph("",fonts8_normal);
	                          w_testo.setAlignment(Element.ALIGN_LEFT);
	                      }
               }   
                else
                {
                    w_testo = new Paragraph("",fonts8_normal);
                    w_testo.setAlignment(Element.ALIGN_LEFT);
                }               	
                	
            	cell9.addElement(w_testo);
            }     
        }
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);
        table2.addCell(cell6);
        table2.addCell(cell7);
        table2.addCell(cell8);
        table2.addCell(cell9);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPagina(table,pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
    	if (nriga_posizione != 0)
    	{	
    		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
    	}
    	else
    	{	
    		nriga_posizione = 790;
    	}  
         return table;
    }     
    

    
    
    public  PdfPTable createBoxTitoloProfessionaleText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	String testo_appoggio = testo;
    	PdfPTable table = new PdfPTable(1);    	
    	PdfPCell cell2 = new PdfPCell();
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);   
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        int nCount = 1;
    	for (EsercizioProfessionale esercizioProfessionale : entityPDFRicevuta.getListaEsercizioProfessionale())
    	{	
    		testo = testo_appoggio;
		    testo = setTextParamatriTitoloProfessionale(testo,esercizioProfessionale);
		    PdfPTable table2 = new PdfPTable(3);
		    if (nCount>1) 
		    {
			    	PdfPCell cell3_1 = new PdfPCell();
			    	String testo_vuoto = "";
			        String[] ww_testi = testo_vuoto.split("#");
			        Paragraph w_testo = null;
			        for (int idx=0;idx<ww_testi.length;idx++)
			        {
			            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
			            w_testo.setAlignment(Element.ALIGN_LEFT);  
			            if (idx==0)
			            {
			            	cell3_1.setPaddingLeft(-50);
			            	cell3_1.setColspan(3);
			            	cell3_1.setBorder(Rectangle.NO_BORDER);            	
			            	cell3_1.addElement(w_testo);			            	
			            } 	 			            
			        }
			        table2.addCell(cell3_1);
			        table2.addCell(cell3_1);
		    }
		    
		   
	        PdfPCell cell3 = new PdfPCell();
	        PdfPCell cell4 = new PdfPCell();
	        PdfPCell cell5 = new PdfPCell();
	        PdfPCell cell6 = new PdfPCell();
	        PdfPCell cell7 = new PdfPCell();
	        PdfPCell cell8 = new PdfPCell();
	        PdfPCell cell9 = new PdfPCell();
	        PdfPCell cell10 = new PdfPCell();
	        PdfPCell cell11 = new PdfPCell();
	        PdfPCell cell12 = new PdfPCell();
	        PdfPCell cell13 = new PdfPCell();
	        PdfPCell cell14 = new PdfPCell();
	        PdfPCell cell15 = new PdfPCell();
	        
	        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);

	        String[] ww_testi = testo.split("#");
	        Paragraph w_testo = null;
	        for (int idx=0;idx<ww_testi.length;idx++)
	        {
	            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
	            w_testo.setAlignment(Element.ALIGN_LEFT);  
	            if (idx==0)
	            {
	                cell3.setPaddingLeft(-50);
	                cell3.setBorder(Rectangle.NO_BORDER);            	
	            	cell3.addElement(w_testo);
	            	
	            } 
	            if (idx==1)
	            {
	                cell4.setBorder(Rectangle.NO_BORDER);            	
	            	cell4.addElement(w_testo);
	            	
	            }   
	            if (idx==2)
	            {
	                cell5.setBorder(Rectangle.NO_BORDER);            	
	            	cell5.addElement(w_testo);
	            	
	            }
	            if (idx==3)
	            {
	                cell6.setPaddingLeft(-50);
	                cell6.setColspan(3);            	
	                cell6.setBorder(Rectangle.NO_BORDER);            	
	            	cell6.addElement(w_testo);
	            	
	            }
	            if (idx==4)
	            {
	                cell7.setPaddingLeft(-50);
	                cell7.setColspan(3);            	
	                cell7.setBorder(Rectangle.NO_BORDER);            	
	            	cell7.addElement(w_testo);
	            	
	            }
	            if (idx==5)
	            {
	                cell8.setPaddingLeft(-50);
	                cell8.setColspan(3);            	
	                cell8.setBorder(Rectangle.NO_BORDER);            	
	            	cell8.addElement(w_testo);
	            }
	            if (idx==6)
	            {
	                cell9.setPaddingLeft(-50);
	                cell9.setColspan(3);            	
	                cell9.setBorder(Rectangle.NO_BORDER);            	
	            	cell9.addElement(w_testo);
	            }
	            
	            if (idx==7)
	            {
	                cell15.setPaddingLeft(-50);
	                cell15.setColspan(3);            	
	                cell15.setBorder(Rectangle.NO_BORDER);            	
	            	cell15.addElement(w_testo);
	            }
	            
	            if (idx==8)
	            {
	                cell10.setPaddingLeft(-50);
	                cell10.setBorder(Rectangle.NO_BORDER);            	
	            	cell10.addElement(w_testo);
	            } 
	            if (idx==9)
	            {
	                cell11.setBorder(Rectangle.NO_BORDER);            	
	            	cell11.addElement(w_testo);
	            } 
	            if (idx==10)
	            {
	                cell12.setBorder(Rectangle.NO_BORDER);            	
	            	cell12.addElement(w_testo);
	            } 
	            if (idx==11)
	            {
	                cell13.setPaddingLeft(-50);
	                cell13.setColspan(2);            	
	                cell13.setBorder(Rectangle.NO_BORDER);            	
	            	cell13.addElement(w_testo);
	            } 
	            if (idx==12)
	            {
	                cell14.setBorder(Rectangle.NO_BORDER);            	
	            	cell14.addElement(w_testo);
	            }                         
	        }
	        table2.addCell(cell3);
	        table2.addCell(cell4);
	        table2.addCell(cell5);
	        table2.addCell(cell6);
	        table2.addCell(cell7);
	        table2.addCell(cell8);
	        table2.addCell(cell9);
	        
	        table2.addCell(cell15);
	        
	        table2.addCell(cell10);
	        table2.addCell(cell11);
	        table2.addCell(cell12);
	        table2.addCell(cell13);
	        table2.addCell(cell14);
      
		    cell2.addElement(table2);
		    table.addCell(cell2);
		    table.setTotalWidth(550);
		    table = saltoPaginaForzata(table, pdfWrite, canvas,cell2);
		    cell2 = new PdfPCell();
		    if (table==null)
		    {
		    	table = new PdfPTable(1);
		    	cell2.setBorder(Rectangle.BOX);
		    	nriga_posizione = 790;
		    }
		    else
		    {
		    	cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
		    }		    	        	        
		    nCount = nCount + 1;
       } 
       table.setTotalWidth(550);
 	   table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);    	
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}    		

       return table;
    }
//    public  PdfPTable createBoxTitoloProfessionaleText(String etichetta,String testo,PdfWriter pdfWrite ) {
//    	// a table with three columns
//    	PdfPTable table = new PdfPTable(1);
//    	PdfPTable table2 = new PdfPTable(3);
//    try {
//        PdfPCell cell = new PdfPCell();
//        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
//        //w_etichetta.add(w_testo);
//        PdfContentByte canvas = pdfWrite.getDirectContent();
//        w_etichetta.setAlignment(Element.ALIGN_LEFT);
//        cell.addElement(w_etichetta); 
//        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
//        table.addCell(cell);
//        
//        PdfPCell cell2 = new PdfPCell();
//        PdfPCell cell3 = new PdfPCell();
//        PdfPCell cell4 = new PdfPCell();
//        PdfPCell cell5 = new PdfPCell();
//        PdfPCell cell6 = new PdfPCell();
//        PdfPCell cell7 = new PdfPCell();
//        PdfPCell cell8 = new PdfPCell();
//        PdfPCell cell9 = new PdfPCell();
//        PdfPCell cell10 = new PdfPCell();
//        PdfPCell cell11 = new PdfPCell();
//        PdfPCell cell12 = new PdfPCell();
//        PdfPCell cell13 = new PdfPCell();
//        PdfPCell cell14 = new PdfPCell();
//        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);

//        String[] ww_testi = testo.split("#");
//        Paragraph w_testo = null;
//        for (int idx=0;idx<ww_testi.length;idx++)
//        {
//            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
//            w_testo.setAlignment(Element.ALIGN_LEFT);  
//            if (idx==0)
//            {
//                cell3.setPaddingLeft(-50);
//                cell3.setBorder(Rectangle.NO_BORDER);            	
//            	cell3.addElement(w_testo);
//            	
//            } 
//            if (idx==1)
//            {
//                cell4.setBorder(Rectangle.NO_BORDER);            	
//            	cell4.addElement(w_testo);
//            	
//            }   
//            if (idx==2)
//            {
//                cell5.setBorder(Rectangle.NO_BORDER);            	
//            	cell5.addElement(w_testo);
//            	
//            }
//            if (idx==3)
//            {
//                cell6.setPaddingLeft(-50);
//                cell6.setColspan(3);            	
//                cell6.setBorder(Rectangle.NO_BORDER);            	
//            	cell6.addElement(w_testo);
//            	
//            }
//            if (idx==4)
//            {
//                cell7.setPaddingLeft(-50);
//                cell7.setColspan(3);            	
//                cell7.setBorder(Rectangle.NO_BORDER);            	
//            	cell7.addElement(w_testo);
//            	
//            }
//            if (idx==5)
//            {
//                cell8.setPaddingLeft(-50);
//                cell8.setColspan(3);            	
//                cell8.setBorder(Rectangle.NO_BORDER);            	
//            	cell8.addElement(w_testo);
//            }
//            if (idx==6)
//            {
//                cell9.setPaddingLeft(-50);
//                cell9.setColspan(3);            	
//                cell9.setBorder(Rectangle.NO_BORDER);            	
//            	cell9.addElement(w_testo);
//            }     
//            if (idx==7)
//            {
//                cell10.setPaddingLeft(-50);
//                cell10.setBorder(Rectangle.NO_BORDER);            	
//            	cell10.addElement(w_testo);
//            } 
//            if (idx==8)
//            {
//                cell11.setBorder(Rectangle.NO_BORDER);            	
//            	cell11.addElement(w_testo);
//            } 
//            if (idx==9)
//            {
//                cell12.setBorder(Rectangle.NO_BORDER);            	
//            	cell12.addElement(w_testo);
//            } 
//            if (idx==10)
//            {
//                cell13.setPaddingLeft(-50);
//                cell13.setColspan(2);            	
//                cell13.setBorder(Rectangle.NO_BORDER);            	
//            	cell13.addElement(w_testo);
//            } 
//            if (idx==11)
//            {
//                cell14.setBorder(Rectangle.NO_BORDER);            	
//            	cell14.addElement(w_testo);
//            }                         
//        }
//        table2.addCell(cell3);
//        table2.addCell(cell4);
//        table2.addCell(cell5);
//        table2.addCell(cell6);
//        table2.addCell(cell7);
//        table2.addCell(cell8);
//        table2.addCell(cell9);
//        table2.addCell(cell10);
//        table2.addCell(cell11);
//        table2.addCell(cell12);
//        table2.addCell(cell13);
//        table2.addCell(cell14);
    
//        cell2.addElement(table2); 
//        table.addCell(cell2);
//        table.setTotalWidth(550);
//        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
//        saltoPagina(table,pdfWrite);
// 		} catch (Exception e) {
// 			// TODO Auto-generated catch block
// 			e.printStackTrace();
// 		}
//    	if (nriga_posizione != 0)
//    	{	
//    		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
//    	}
//    	else
//    	{	
//    		nriga_posizione = 790;
//    	}    
//         return table;
//    } 
//    
    
    public  PdfPTable createBoxPubblScientText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	String testo_appoggio = testo;
    	PdfPTable table = new PdfPTable(1);    	
    	PdfPCell cell2 = new PdfPCell();
        PdfPCell cell = new PdfPCell();
        etichetta = etichetta.replace("<?-&1-?>", getEntityPDFRicevuta().getDataPubbScient());
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);   
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        int nCount = 1;
    	for (PubblicazioneScentifica publicscent : entityPDFRicevuta.getListaPubblicaScentifica())
    	{	
    		testo = testo_appoggio;
		    testo = setTextParamatriPubblScient(testo,publicscent);
		    PdfPTable table2 = new PdfPTable(2);
		    if (nCount>1) 
		    {
			    	PdfPCell cell3_1 = new PdfPCell();
			    	String testo_vuoto = "";
			        String[] ww_testi = testo_vuoto.split("#");
			        Paragraph w_testo = null;
			        for (int idx=0;idx<ww_testi.length;idx++)
			        {
			            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
			            w_testo.setAlignment(Element.ALIGN_LEFT);  
			            if (idx==0)
			            {
			            	cell3_1.setPaddingLeft(-50);
			            	cell3_1.setColspan(2);
			            	cell3_1.setBorder(Rectangle.NO_BORDER);            	
			            	cell3_1.addElement(w_testo);			            	
			            } 	 			            
			        }
			        table2.addCell(cell3_1);
			        table2.addCell(cell3_1);
		    }
	        PdfPCell cell3 = new PdfPCell();
	        PdfPCell cell4 = new PdfPCell();
	        PdfPCell cell5 = new PdfPCell();
	        PdfPCell cell6 = new PdfPCell();
	        PdfPCell cell7 = new PdfPCell();
	        PdfPCell cell8 = new PdfPCell(); 	        
	        String[] ww_testi = testo.split("#");
	        Paragraph w_testo = null;
	        for (int idx=0;idx<ww_testi.length;idx++)
	        {
	            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
	            w_testo.setAlignment(Element.ALIGN_LEFT);  
	            if (idx==0)
	            {
	                cell3.setPaddingLeft(-50);
	                cell3.setColspan(2);
	                cell3.setBorder(Rectangle.NO_BORDER);            	
	            	cell3.addElement(w_testo);
	            	
	            } 
	            if (idx==1)
	            {
	                cell4.setPaddingLeft(-50);
	                cell4.setColspan(2);            	
	                cell4.setBorder(Rectangle.NO_BORDER);            	
	            	cell4.addElement(w_testo);
	            	
	            }   
	            if (idx==2)
	            {
	                cell5.setPaddingLeft(-50);
	                cell5.setColspan(2);            	
	                cell5.setBorder(Rectangle.NO_BORDER);            	
	            	cell5.addElement(w_testo);
	            	
	            }
	            if (idx==3)
	            {
	                cell6.setPaddingLeft(-50);
	                cell6.setColspan(2);            	
	                cell6.setBorder(Rectangle.NO_BORDER);            	
	            	cell6.addElement(w_testo);
	            	
	            }
	            if (idx==4)
	            {
	                cell7.setPaddingLeft(-50);
	                cell7.setColspan(2);            	
	                cell7.setBorder(Rectangle.NO_BORDER);            	
	            	cell7.addElement(w_testo);
	            	
	            }
	            if (idx==5)
	            {
	                cell8.setPaddingLeft(-50);
	                cell8.setColspan(2);            	
	                cell8.setBorder(Rectangle.NO_BORDER);            	
	            	cell8.addElement(w_testo);
	            }            
	        }
	        table2.addCell(cell3);
	        table2.addCell(cell4);
	        table2.addCell(cell5);
	        table2.addCell(cell6);
	        table2.addCell(cell7);
	        table2.addCell(cell8);	        
		    cell2.addElement(table2);
		    table.addCell(cell2);
		    table.setTotalWidth(550);
		    table = saltoPaginaForzata(table, pdfWrite, canvas,cell2);
		    cell2 = new PdfPCell();
		    if (table==null)
		    {
		    	table = new PdfPTable(1);
		    	cell2.setBorder(Rectangle.BOX);
		    	nriga_posizione = 790;
		    }
		    else
		    {
		    	cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
		    }		    	        	        
		    nCount = nCount + 1;
       } 
       table.setTotalWidth(550);
 	   table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);    	
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}    		    		        
        return table;      	
    }    
    
    public  PdfPTable createBoxCorsiAggText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	String testo_appoggio = testo;
    	PdfPTable table = new PdfPTable(1);    	
    	PdfPCell cell2 = new PdfPCell();
        PdfPCell cell = new PdfPCell();
        etichetta = etichetta.replace("<?-&1-?>", getEntityPDFRicevuta().getDataPartenzaCorso());
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);   
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        int nCount = 1;
    	for (CorsoDiAggiornamento corsoaggio : entityPDFRicevuta.getListaCorsiAggiornamento())
    	{	
    		testo = testo_appoggio;
    		testo = setTextParamatriCorsiAgg(testo,corsoaggio);
		    PdfPTable table2 = new PdfPTable(2);
		    if (nCount>1) 
		    {
			    	PdfPCell cell3_1 = new PdfPCell();
			    	String testo_vuoto = "";
			        String[] ww_testi = testo_vuoto.split("#");
			        Paragraph w_testo = null;
			        for (int idx=0;idx<ww_testi.length;idx++)
			        {
			            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
			            w_testo.setAlignment(Element.ALIGN_LEFT);  
			            if (idx==0)
			            {
			            	cell3_1.setPaddingLeft(-50);
			            	cell3_1.setColspan(2);
			            	cell3_1.setBorder(Rectangle.NO_BORDER);            	
			            	cell3_1.addElement(w_testo);			            	
			            } 	 			            
			        }
			        table2.addCell(cell3_1);
			        table2.addCell(cell3_1);
		    }
	        PdfPCell cell3 = new PdfPCell();
	        PdfPCell cell4 = new PdfPCell();
	        PdfPCell cell5 = new PdfPCell();
	        PdfPCell cell6 = new PdfPCell();
	        PdfPCell cell7 = new PdfPCell();
	        PdfPCell cell8 = new PdfPCell(); 	        
	        String[] ww_testi = testo.split("#");
	        Paragraph w_testo = null;
	        for (int idx=0;idx<ww_testi.length;idx++)
	        {
	            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
	            w_testo.setAlignment(Element.ALIGN_LEFT);  
	            if (idx==0)
	            {
	                cell3.setPaddingLeft(-50);
	                cell3.setBorder(Rectangle.NO_BORDER);            	
	            	cell3.addElement(w_testo);
	            	
	            } 
	            if (idx==1)
	            {
	                cell4.setBorder(Rectangle.NO_BORDER);            	
	            	cell4.addElement(w_testo);
	            	
	            }
	            if (idx==2)
	            {
	                cell5.setPaddingLeft(-50);
	                cell5.setBorder(Rectangle.NO_BORDER);            	
	            	cell5.addElement(w_testo);
	            	
	            } 
	            if (idx==3)
	            {
	                cell6.setBorder(Rectangle.NO_BORDER);            	
	            	cell6.addElement(w_testo);
	            	
	            } 
	            if (idx==4)
	            {
	                cell7.setPaddingLeft(-50);
	                cell7.setBorder(Rectangle.NO_BORDER);            	
	            	cell7.addElement(w_testo);
	            	
	            } 
	            if (idx==5)
	            {
	                cell8.setBorder(Rectangle.NO_BORDER);            	
	            	cell8.addElement(w_testo);
	            	
	            }            
	                        
	        }
	        table2.addCell(cell3);
	        table2.addCell(cell4);
	        table2.addCell(cell5);
	        table2.addCell(cell6);
	        table2.addCell(cell7);
	        table2.addCell(cell8);	        
		    cell2.addElement(table2);
		    table.addCell(cell2);
		    table.setTotalWidth(550);
		    table = saltoPaginaForzata(table, pdfWrite, canvas,cell2);
		    cell2 = new PdfPCell();
		    if (table==null)
		    {
		    	table = new PdfPTable(1);
		    	cell2.setBorder(Rectangle.BOX);
		    	nriga_posizione = 790;
		    }
		    else
		    {
		    	cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
		    }		    	        	        
		    nCount = nCount + 1;
       } 
       table.setTotalWidth(550);
 	   table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);    	
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}    		
       return table;     	
    }      
    
    public  PdfPTable createBoxIdoneitaNazText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setColspan(2);            	
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
                        
        }
        table2.addCell(cell3);
        table2.addCell(cell4);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPagina(table,pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}     
         return table;
    }     
    
    public  PdfPTable createBoxIdoneitaText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setColspan(2);            	
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setPaddingLeft(-50);
                cell5.setColspan(2);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            	
            }
                        
        }
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPagina(table,pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}     
         return table;
    } 
    
    public  PdfPTable createBoxAltriTitoliText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	String testo_appoggio = testo;
    	PdfPTable table = new PdfPTable(1);    	
    	PdfPCell cell2 = new PdfPCell();
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);   
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        int nCount = 1;
        for (AltriTitoli altrititoli : entityPDFRicevuta.getListaAltriTitoli())
    	{	
    		testo = testo_appoggio;
		    testo = setTextParamatriAltriTitoli(testo,altrititoli);
		    PdfPTable table2 = new PdfPTable(2);
		    if (nCount>1) 
		    {
			    	PdfPCell cell3_1 = new PdfPCell();
			    	String testo_vuoto = "";
			        String[] ww_testi = testo_vuoto.split("#");
			        Paragraph w_testo = null;
			        for (int idx=0;idx<ww_testi.length;idx++)
			        {
			            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
			            w_testo.setAlignment(Element.ALIGN_LEFT);  
			            if (idx==0)
			            {
			            	cell3_1.setPaddingLeft(-50);
			            	cell3_1.setColspan(2);
			            	cell3_1.setBorder(Rectangle.NO_BORDER);            	
			            	cell3_1.addElement(w_testo);			            	
			            } 	 			            
			        }
			        table2.addCell(cell3_1);
			        table2.addCell(cell3_1);
		    }
	        PdfPCell cell3 = new PdfPCell();
	        PdfPCell cell4 = new PdfPCell();
	        PdfPCell cell5 = new PdfPCell();
	        PdfPCell cell6 = new PdfPCell();
	        PdfPCell cell7 = new PdfPCell();
	        PdfPCell cell8 = new PdfPCell(); 
	        PdfPCell cell9 = new PdfPCell();		        
	        String[] ww_testi = testo.split("#");
	        Paragraph w_testo = null;
	        for (int idx=0;idx<ww_testi.length;idx++)
	        {
	            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
	            w_testo.setAlignment(Element.ALIGN_LEFT);  
	            if (idx==0)
	            {
	                cell3.setPaddingLeft(-50);
	                cell3.setBorder(Rectangle.NO_BORDER);            	
	            	cell3.addElement(w_testo);
	            	
	            } 
	            if (idx==1)
	            {
	                cell4.setBorder(Rectangle.NO_BORDER);            	
	            	cell4.addElement(w_testo);
	            	
	            }
	            if (idx==2)
	            {
	                cell5.setPaddingLeft(-50);
	                cell5.setBorder(Rectangle.NO_BORDER);            	
	            	cell5.addElement(w_testo);
	            	
	            }
	            if (idx==3)
	            {
	                cell6.setBorder(Rectangle.NO_BORDER);            	
	            	cell6.addElement(w_testo);
	            	
	            }
	            if (idx==4)
	            {
	                cell7.setPaddingLeft(-50);
	                cell7.setBorder(Rectangle.NO_BORDER);            	
	            	cell7.addElement(w_testo);
	            	
	            }
	            if (idx==5)
	            {
	                cell8.setBorder(Rectangle.NO_BORDER);            	
	            	cell8.addElement(w_testo);
	            } 
	            if (idx==6)
	            {
	                cell9.setPaddingLeft(-50);
	                cell9.setColspan(2);
	                cell9.setBorder(Rectangle.NO_BORDER);            	
	            	cell9.addElement(w_testo);
	            	
	            }            
	        }
	        table2.addCell(cell3);
	        table2.addCell(cell4);
	        table2.addCell(cell5);
	        table2.addCell(cell6);
	        table2.addCell(cell7);
	        table2.addCell(cell8);
	        table2.addCell(cell9);        
		    cell2.addElement(table2);
		    table.addCell(cell2);
		    table.setTotalWidth(550);
		    table = saltoPaginaForzata(table, pdfWrite, canvas,cell2);
		    cell2 = new PdfPCell();
		    if (table==null)
		    {
		    	table = new PdfPTable(1);
		    	cell2.setBorder(Rectangle.BOX);
		    	nriga_posizione = 790;
		    }
		    else
		    {
		    	cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
		    }		    	        	        
		    nCount = nCount + 1;
       } 
       table.setTotalWidth(550);
 	   table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);    	
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}       
        return table;  
    }     
    
    public  PdfPTable createBoxDottoratoText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	String testo_appoggio = testo;
    	PdfPTable table = new PdfPTable(1);    	
    	PdfPCell cell2 = new PdfPCell();
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);   
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        int nCount = 1;
        for (DottoratoPDF dottorato : entityPDFRicevuta.getListaDottorato())
    	{	
    		testo = testo_appoggio;
		    testo = setTextParamatriDottorato(testo,dottorato);
		    PdfPTable table2 = new PdfPTable(2);
		    if (nCount>1) 
		    {
			    	PdfPCell cell3_1 = new PdfPCell();
			    	String testo_vuoto = "";
			        String[] ww_testi = testo_vuoto.split("#");
			        Paragraph w_testo = null;
			        for (int idx=0;idx<ww_testi.length;idx++)
			        {
			            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
			            w_testo.setAlignment(Element.ALIGN_LEFT);  
			            if (idx==0)
			            {
			            	cell3_1.setPaddingLeft(-50);
			            	cell3_1.setColspan(2);
			            	cell3_1.setBorder(Rectangle.NO_BORDER);            	
			            	cell3_1.addElement(w_testo);			            	
			            } 	 			            
			        }
			        table2.addCell(cell3_1);
			        table2.addCell(cell3_1);
		    }
	        PdfPCell cell3 = new PdfPCell();
	        PdfPCell cell4 = new PdfPCell();
	        PdfPCell cell5 = new PdfPCell();
	        PdfPCell cell6 = new PdfPCell();
	        PdfPCell cell7 = new PdfPCell();
	        PdfPCell cell8 = new PdfPCell(); 
	        PdfPCell cell9 = new PdfPCell();		        
	        String[] ww_testi = testo.split("#");
	        Paragraph w_testo = null;
	        for (int idx=0;idx<ww_testi.length;idx++)
	        {
	            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
	            w_testo.setAlignment(Element.ALIGN_LEFT);  
	            if (idx==0)
	            {
	                cell3.setPaddingLeft(-50);
	                cell3.setBorder(Rectangle.NO_BORDER);            	
	            	cell3.addElement(w_testo);
	            	
	            } 
	            if (idx==1)
	            {
	                cell4.setBorder(Rectangle.NO_BORDER);            	
	            	cell4.addElement(w_testo);
	            	
	            }
	            if (idx==2)
	            {
	                cell5.setPaddingLeft(-50);
	                cell5.setBorder(Rectangle.NO_BORDER);            	
	            	cell5.addElement(w_testo);
	            	
	            }
	            if (idx==3)
	            {
	                cell6.setBorder(Rectangle.NO_BORDER);            	
	            	cell6.addElement(w_testo);
	            	
	            }
	            if (idx==4)
	            {
	                cell7.setPaddingLeft(-50);
	                cell7.setBorder(Rectangle.NO_BORDER);            	
	            	cell7.addElement(w_testo);
	            	
	            }
	            if (idx==5)
	            {
	                cell8.setBorder(Rectangle.NO_BORDER);            	
	            	cell8.addElement(w_testo);
	            } 
	            if (idx==6)
	            {
	                cell9.setPaddingLeft(-50);
	                cell9.setColspan(2);
	                cell9.setBorder(Rectangle.NO_BORDER);            	
	            	cell9.addElement(w_testo);
	            	
	            }            
	        }
	        table2.addCell(cell3);
	        table2.addCell(cell4);
	        table2.addCell(cell5);
	        table2.addCell(cell6);
	        table2.addCell(cell7);
	        table2.addCell(cell8);
	        table2.addCell(cell9);        
		    cell2.addElement(table2);
		    table.addCell(cell2);
		    table.setTotalWidth(550);
		    table = saltoPaginaForzata(table, pdfWrite, canvas,cell2);
		    cell2 = new PdfPCell();
		    if (table==null)
		    {
		    	table = new PdfPTable(1);
		    	cell2.setBorder(Rectangle.BOX);
		    	nriga_posizione = 790;
		    }
		    else
		    {
		    	cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
		    }		    	        	        
		    nCount = nCount + 1;
       } 
       table.setTotalWidth(550);
 	   table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);    	
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}    		
       return table; 
    }    
    
    public  PdfPTable createBoxBorsaDiStudioText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	String testo_appoggio = testo;
    	PdfPTable table = new PdfPTable(1);    	
    	PdfPCell cell2 = new PdfPCell();
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);   
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        int nCount = 1;
    	for (BorseDiStudio borsadistudio : entityPDFRicevuta.getListaBorseDiStudio())
    	{	
    		testo = testo_appoggio;
		    testo = setTextParamatriBorsaDiStudio(testo,borsadistudio);
		    PdfPTable table2 = new PdfPTable(2);
		    if (nCount>1) 
		    {
			    	PdfPCell cell3_1 = new PdfPCell();
			    	String testo_vuoto = "";
			        String[] ww_testi = testo_vuoto.split("#");
			        Paragraph w_testo = null;
			        for (int idx=0;idx<ww_testi.length;idx++)
			        {
			            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
			            w_testo.setAlignment(Element.ALIGN_LEFT);  
			            if (idx==0)
			            {
			            	cell3_1.setPaddingLeft(-50);
			            	cell3_1.setColspan(2);
			            	cell3_1.setBorder(Rectangle.NO_BORDER);            	
			            	cell3_1.addElement(w_testo);			            	
			            } 	 			            
			        }
			        table2.addCell(cell3_1);
			        table2.addCell(cell3_1);
		    }
	        PdfPCell cell3 = new PdfPCell();
	        PdfPCell cell4 = new PdfPCell();
	        PdfPCell cell5 = new PdfPCell();
	        PdfPCell cell6 = new PdfPCell();
	        PdfPCell cell7 = new PdfPCell();
	        PdfPCell cell8 = new PdfPCell(); 
	        PdfPCell cell9 = new PdfPCell();		        
	        String[] ww_testi = testo.split("#");
	        Paragraph w_testo = null;
	        for (int idx=0;idx<ww_testi.length;idx++)
	        {
	            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
	            w_testo.setAlignment(Element.ALIGN_LEFT);  
	            if (idx==0)
	            {
	                cell3.setPaddingLeft(-50);
	                cell3.setBorder(Rectangle.NO_BORDER);            	
	            	cell3.addElement(w_testo);
	            	
	            } 
	            if (idx==1)
	            {
	                cell4.setBorder(Rectangle.NO_BORDER);            	
	            	cell4.addElement(w_testo);
	            	
	            }
	            if (idx==2)
	            {
	                cell5.setPaddingLeft(-50);
	                cell5.setBorder(Rectangle.NO_BORDER);            	
	            	cell5.addElement(w_testo);
	            	
	            }
	            if (idx==3)
	            {
	                cell6.setBorder(Rectangle.NO_BORDER);            	
	            	cell6.addElement(w_testo);
	            	
	            }
	            if (idx==4)
	            {
	                cell7.setPaddingLeft(-50);
	                cell7.setBorder(Rectangle.NO_BORDER);            	
	            	cell7.addElement(w_testo);
	            	
	            }
	            if (idx==5)
	            {
	                cell8.setBorder(Rectangle.NO_BORDER);            	
	            	cell8.addElement(w_testo);
	            } 
	            if (idx==6)
	            {
	                cell9.setPaddingLeft(-50);
	                cell9.setColspan(2);
	                cell9.setBorder(Rectangle.NO_BORDER);            	
	            	cell9.addElement(w_testo);
	            	
	            }            
	        }
	        table2.addCell(cell3);
	        table2.addCell(cell4);
	        table2.addCell(cell5);
	        table2.addCell(cell6);
	        table2.addCell(cell7);
	        table2.addCell(cell8);
	        table2.addCell(cell9);	        
		    cell2.addElement(table2);
		    table.addCell(cell2);
		    table.setTotalWidth(550);
		    table = saltoPaginaForzata(table, pdfWrite, canvas,cell2);
		    cell2 = new PdfPCell();
		    if (table==null)
		    {
		    	table = new PdfPTable(1);
		    	cell2.setBorder(Rectangle.BOX);
		    	nriga_posizione = 790;
		    }
		    else
		    {
		    	cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
		    }		    	        	        
		    nCount = nCount + 1;
       }  
    	table.setTotalWidth(550);
		table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}  		
        return table;    	
    }    
    
    public  PdfPTable createBoxSecondaLaureaText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();        
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            } 
            if (idx==1)
            {
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setPaddingLeft(-50);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            	
            }
            if (idx==3)
            {
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }
            if (idx==4)
            {
                cell7.setPaddingLeft(-50);
                cell7.setBorder(Rectangle.NO_BORDER);            	
            	cell7.addElement(w_testo);
            	
            }
            if (idx==5)
            {
                cell8.setBorder(Rectangle.NO_BORDER);            	
            	cell8.addElement(w_testo);
            	
            }          
        }
        table2.addCell(cell3);
        table2.addCell(cell4);
        table2.addCell(cell5);
        table2.addCell(cell6);
        table2.addCell(cell7);
        table2.addCell(cell8);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPagina(table, pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		
    	 
         return table;
    } 
    
    
    public  PdfPTable createBoxRequisitiMinimiText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);  
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }            
        }
        table2.addCell(cell3);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPagina(table, pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{
			nriga_posizione = 790;
		}

         return table;
    }     
    
    
    public  PdfPTable saltoPaginaForzata(PdfPTable table,PdfWriter pdfWrite,PdfContentByte canvas,PdfPCell cell2)
    {
    		if (
    				(LIMITE_SALTO_PAGINA >= (nriga_posizione - (int)table.getTotalHeight())) ||
    				((LIMITE_SALTO_PAGINA + 20) >= (nriga_posizione - (int)table.getTotalHeight()))
    			)	
    		{
    			table.setTotalWidth(550);
    			table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);
				documentoPDF.newPage();
				pdfWrite.setPageEmpty(false);
				nriga_posizione = 840;
				w_testo = getBodyRicevuta().getProperty("headerpagina");
			
				w_testo = setTextParamatriHeader(w_testo);
				nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
				table = null;	
    		}
    		return table;

    }
    
    
    
    public  void saltoPaginaUltimo(PdfPTable table,PdfWriter pdfWrite)
    {
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);

    }    
    
    
    public  void saltoPagina(PdfPTable table,PdfWriter pdfWrite)
    {
    		if (LIMITE_SALTO_PAGINA >= (nriga_posizione - (int)table.getTotalHeight()))
    		{
				nriga_posizione = POS_RIGA_SALTO_PAGINA; 
				String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
				createBoxPaginazioneText("",w_testo,pdfWrite);
				documentoPDF.newPage();
				pdfWrite.setPageEmpty(false);
				nriga_posizione = 840;
				w_testo = getBodyRicevuta().getProperty("headerpagina");
				w_testo = setTextParamatriHeader(w_testo);
				nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
				nriga_posizione = 0;
    		}

    }
    
    
    public  PdfPTable createBoxAbilitazioneText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (ww_testi[idx].contains("<?-elimina-?>"))
            {
            	w_testo = new Paragraph("",fonts8_normal);;
            }
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            } 
            if (idx==2)
            {
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            	
            }
            if (idx==3)
            {
                cell6.setPaddingLeft(-50);
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }
            if (idx==4)
            {
                cell7.setBorder(Rectangle.NO_BORDER);            	
            	cell7.addElement(w_testo);
            }  
            
            if (idx==5)
            {
                cell8.setPaddingLeft(-50);
                cell8.setColspan(2);
                cell8.setBorder(Rectangle.NO_BORDER);                   
            	cell8.addElement(w_testo);
            }            
        }
    	table2.addCell(cell3);
    	table2.addCell(cell4);
    	table2.addCell(cell5);
    	table2.addCell(cell6);
    	table2.addCell(cell7);
    	table2.addCell(cell8);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        saltoPagina(table,pdfWrite);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
    	if (nriga_posizione != 0)
    	{	
    		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
    	}
    	else
    	{	
    		nriga_posizione = 790;
    	}    		
    		
        return table;
    }     

    public  PdfPTable createBoxLaureaPrincText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            } 
            if (idx==2)
            {
                cell5.setPaddingLeft(-50);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            	
            }
            if (idx==3)
            {
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }
            if (idx==4)
            {
                cell7.setPaddingLeft(-50);
                cell7.setColspan(2);
                cell7.setBorder(Rectangle.NO_BORDER);            	
            	cell7.addElement(w_testo);
            }            
        }
    	table2.addCell(cell3);
    	table2.addCell(cell4);
    	table2.addCell(cell5);
    	table2.addCell(cell6);
    	table2.addCell(cell7);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        
        saltoPagina(table, pdfWrite);
 		
    	} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		

         return table;
    }     
    
    
    public  PdfPTable createBoxPaBolzanoText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setColspan(2);
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }            
        }
    	table2.addCell(cell3);
    	table2.addCell(cell4);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
        
        saltoPagina(table, pdfWrite);
        
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		

         return table;
    }     
    
    
    public  PdfPTable createBoxHeaderText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.NO_BORDER);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        cell2.setBorder(Rectangle.NO_BORDER);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts6_italic);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            }  
            if (idx==3)
            {
                cell6.setPaddingLeft(-50);
                cell6.setColspan(2);
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            	
            }            
        }
    	table2.addCell(cell3);
    	table2.addCell(cell4);
    	table2.addCell(cell5);
    	table2.addCell(cell6);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
         return table;
    }  
    
    public  PdfPTable createBoxDatiAlboFarmacistiText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setBorder(Rectangle.NO_BORDER);            	
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            	
            }       
            if (idx==3)
            {
            	cell6.setPaddingLeft(-50);
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            }  
            if (idx==4)
            {
                cell7.setBorder(Rectangle.NO_BORDER);            	
            	cell7.addElement(w_testo);
            	
            }     
           
        }
    	table2.addCell(cell3);
    	table2.addCell(cell4);
    	table2.addCell(cell5);
    	table2.addCell(cell6);
    	table2.addCell(cell7);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		

         return table;
    }     
    
    public  PdfPTable createBoxDatiCittadinanzaText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
                cell4.setPaddingLeft(-50);
                cell4.setColspan(2);
                cell4.setBorder(Rectangle.NO_BORDER);     
                if (!getEntityPDFRicevuta().getCittadinanza().equalsIgnoreCase("ITALIEN"))
                {
                    w_testo = new Paragraph("",fonts8_normal);
                    w_testo.setAlignment(Element.ALIGN_LEFT);                	
                	
                }
            	cell4.addElement(w_testo);
            	
            }
            if (idx==2)
            {
                cell5.setPaddingLeft(-50);
                cell5.setColspan(2);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            	
            }            
        }
    	table2.addCell(cell3);
    	table2.addCell(cell4);
    	table2.addCell(cell5);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		

         return table;
    }     
    
 
    public  PdfPTable createBoxDatiAppartenenzaText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setColspan(2);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
        }
    	table2.addCell(cell3);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		

         return table;
    }      
    
    public  PdfPTable createBoxDatiResidenzaText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();
        PdfPCell cell9 = new PdfPCell();
        PdfPCell cell10 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
            	
            	cell4.setBorder(Rectangle.NO_BORDER);
            	cell4.addElement(w_testo);
                
            }            
           
            if (idx==2)
            {
            	
            	cell5.setPaddingLeft(-50);
                cell5.setBorder(Rectangle.NO_BORDER);      
                if (!getEntityPDFRicevuta().getNazioneResidenzaUtente().equalsIgnoreCase("ITALIEN"))
                {
                    w_testo = new Paragraph("",fonts8_normal);
                    w_testo.setAlignment(Element.ALIGN_LEFT);
                }
            	cell5.addElement(w_testo);
            } 
            if (idx==3)
            {     
            	
                cell6.setBorder(Rectangle.NO_BORDER);     
                if (!getEntityPDFRicevuta().getNazioneResidenzaUtente().equalsIgnoreCase("ITALIEN"))
                {
                    w_testo = new Paragraph("",fonts8_normal);
                    w_testo.setAlignment(Element.ALIGN_LEFT);
                }
            	cell6.addElement(w_testo);
            } 
            
            if (idx==4)
            {
            	cell7.setPaddingLeft(-50);
                cell7.setBorder(Rectangle.NO_BORDER);   
                if (getEntityPDFRicevuta().getNazioneResidenzaUtente().equalsIgnoreCase("ITALIEN"))
                {
                    w_testo = new Paragraph("",fonts8_normal);
                    w_testo.setAlignment(Element.ALIGN_LEFT);
                }
            	cell7.addElement(w_testo);
            }    
            if (idx==5)
            {
            	cell8.setBorder(Rectangle.NO_BORDER);
            	cell8.addElement(w_testo);
                
            }            
            if (idx==6)
            {
                cell9.setPaddingLeft(-50);
                cell9.setBorder(Rectangle.NO_BORDER);            	
            	cell9.addElement(w_testo);
            }  
            
            if (idx==7)
            {
            	
            	cell10.setColspan(2);
                cell10.setBorder(Rectangle.NO_BORDER);            	
            	cell10.addElement(w_testo);
            }     

        }
    	table2.addCell(cell3);
        table2.addCell(cell4);             	
    	table2.addCell(cell5); 
    	table2.addCell(cell6);  
    	table2.addCell(cell7);
    	table2.addCell(cell8);
    	table2.addCell(cell9);
    	table2.addCell(cell10);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		

         return table;
    }    
    
    public  PdfPTable createBoxDatiAnagraficiText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        PdfPCell cell6 = new PdfPCell();
        PdfPCell cell7 = new PdfPCell();
        PdfPCell cell8 = new PdfPCell();
        PdfPCell cell9 = new PdfPCell();
        PdfPCell cell10 = new PdfPCell();
        PdfPCell cell11 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
            	cell4.setBorder(Rectangle.NO_BORDER);
            	cell4.addElement(w_testo);
                
            }            
            if (idx==2)
            {
                cell5.setPaddingLeft(-50);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            }  
            if (idx==3)
            {
                cell6.setBorder(Rectangle.NO_BORDER);            	
            	cell6.addElement(w_testo);
            }  
            
            if (idx==4)
            {
            	cell7.setPaddingLeft(-50);
                cell7.setBorder(Rectangle.NO_BORDER);      
                if (!getEntityPDFRicevuta().getStatoNascita().equalsIgnoreCase("ITALIEN"))
                {
                    w_testo = new Paragraph("",fonts8_normal);
                    w_testo.setAlignment(Element.ALIGN_LEFT);
                }
            	cell7.addElement(w_testo);
            } 
            if (idx==5)
            {            	
                cell8.setBorder(Rectangle.NO_BORDER);     
                if (!getEntityPDFRicevuta().getStatoNascita().equalsIgnoreCase("ITALIEN"))
                {
                    w_testo = new Paragraph("",fonts8_normal);
                    w_testo.setAlignment(Element.ALIGN_LEFT);
                }
            	cell8.addElement(w_testo);
            } 
            
            if (idx==6)
            {
            	cell9.setPaddingLeft(-50);
                cell9.setBorder(Rectangle.NO_BORDER);   
                if (getEntityPDFRicevuta().getStatoNascita().equalsIgnoreCase("ITALIEN"))
                {
                    w_testo = new Paragraph("",fonts8_normal);
                    w_testo.setAlignment(Element.ALIGN_LEFT);
                }
            	cell9.addElement(w_testo);
            }    
            if (idx==7)
            {
                cell10.setBorder(Rectangle.NO_BORDER);            	
            	cell10.addElement(w_testo);
            } 
            if (idx==8)
            {
            	cell11.setPaddingLeft(-50);
            	cell11.setColspan(2);
                cell11.setBorder(Rectangle.NO_BORDER);            	
            	cell11.addElement(w_testo);
            }             
        
        }
    	table2.addCell(cell3);
        table2.addCell(cell4);             	
    	table2.addCell(cell5); 
    	table2.addCell(cell6);  
    	table2.addCell(cell7);
    	table2.addCell(cell8);
    	table2.addCell(cell9);
    	table2.addCell(cell10);
    	table2.addCell(cell11);
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		

         return table;
    }     
    public  PdfPTable createBoxDatiInvioText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	
    	PdfPTable table = new PdfPTable(1);
    	PdfPTable table2 = new PdfPTable(2);
    	
    try {
        PdfPCell cell = new PdfPCell();
        Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
        //w_etichetta.add(w_testo);
        PdfContentByte canvas = pdfWrite.getDirectContent();
        w_etichetta.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(w_etichetta); 
        cell.setBorder(Rectangle.LEFT+Rectangle.TOP + Rectangle.RIGHT);
        table.addCell(cell);
        
        PdfPCell cell2 = new PdfPCell();
        PdfPCell cell3 = new PdfPCell();
        PdfPCell cell4 = new PdfPCell();
        PdfPCell cell5 = new PdfPCell();
        cell2.setBorder(Rectangle.LEFT+Rectangle.BOTTOM + Rectangle.RIGHT);
        String[] ww_testi = testo.split("#");
        Paragraph w_testo = null;
        for (int idx=0;idx<ww_testi.length;idx++)
        {
            w_testo = new Paragraph(ww_testi[idx],fonts8_normal);
            w_testo.setAlignment(Element.ALIGN_LEFT);
            if (idx==0)
            {
                cell3.setPaddingLeft(-50);
                cell3.setBorder(Rectangle.NO_BORDER);            	
            	cell3.addElement(w_testo);
            	
            }
            if (idx==1)
            {
            	cell4.setBorder(Rectangle.NO_BORDER);
            	cell4.addElement(w_testo);
                
            }            
            if (idx==2)
            {
            	cell5.setColspan(2);
                cell5.setPaddingLeft(-50);
                cell5.setBorder(Rectangle.NO_BORDER);            	
            	cell5.addElement(w_testo);
            }            
        }
    	table2.addCell(cell3);
        table2.addCell(cell4);             	
    	table2.addCell(cell5);        
        cell2.addElement(table2); 
        table.addCell(cell2);
        table.setTotalWidth(550);
        table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);       
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
		if (nriga_posizione != 0)
		{	
			nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
		}
		else
		{	
			nriga_posizione = 790;
		}    		
    
         return table;
    }     
    
    public  PdfPTable createBoxNotaText(String etichetta,String testo,PdfWriter pdfWrite ) {
    	// a table with three columns
    	PdfPTable table = new PdfPTable(1);
    	
    try {
       PdfPCell cell = new PdfPCell();
       //testo = "NOTA" +  "\n" + testo + "\n";fff
       Paragraph w_etichetta = new Paragraph(etichetta,fonts8_bold);
       Paragraph w_testo = new Paragraph(testo,fonts8_bold);
       w_etichetta.add(w_testo);
       PdfContentByte canvas = pdfWrite.getDirectContent();
       w_testo.setAlignment(Element.ALIGN_LEFT + Element.ALIGN_JUSTIFIED);
       cell.addElement(w_etichetta); 
       table.addCell(cell);
       table.setTotalWidth(550);
       table.writeSelectedRows(0, 2, 0, -1,25,nriga_posizione, canvas);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   	if (nriga_posizione != 0)
	   	{	
	   		nriga_posizione = nriga_posizione - (int)(table.getTotalHeight() + 5);
	   	}
	   	else
	   	{	
	   		nriga_posizione = 790;
	   	}      
        return table;
    } 
    
    private  BufferedImage resizeImageWithHint(BufferedImage originalImage, int type){
    	 
	BufferedImage resizedImage = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, type);
	Graphics2D g = resizedImage.createGraphics();
	g.drawImage(originalImage, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
	g.dispose();	
	g.setComposite(AlphaComposite.Src);
 
	g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
	RenderingHints.VALUE_INTERPOLATION_BILINEAR);
	g.setRenderingHint(RenderingHints.KEY_RENDERING,
	RenderingHints.VALUE_RENDER_QUALITY);
	g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
	RenderingHints.VALUE_ANTIALIAS_ON);
 
	return resizedImage;
    }	    
    
    
    public  String setTextParamatriOggetto(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getDescRegUtente());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    public String setTextParamatriDichiarazione(String testo)
    {
    	testo = testo.replace("<cognome>",getEntityPDFRicevuta().getCognome());
    	testo = testo.replace("<nome>",getEntityPDFRicevuta().getNome());
    	
    	if(getEntityPDFRicevuta().getSesso()!=null)
    	{
    		if(getEntityPDFRicevuta().getSesso().toUpperCase().equals("M"))
    		{
    			testo = testo.replace("Sottoscritto/a","Sottoscritto");
    		}
    		else if(getEntityPDFRicevuta().getSesso().toUpperCase().equals("F"))
    		{
    			testo = testo.replace("Sottoscritto/a","Sottoscritta");
    		}
    	}
    	
    	return testo;
    }
    
    public  String setTextParamatriDatiInvio(String testo)
    {
    	if  (dateInvio.equals(""))
    		if (!getEntityPDFRicevuta().getDataInvio().equals(""))
    			dateInvio = getEntityPDFRicevuta().getDataInvio(); 
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getDataInvio());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getModoPartecipa());
    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getNumeroProtocollo());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    public  String setTextParamatriDatiAnagraficaInvio(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getCognome());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getNome());
    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getCodifisc());
    	testo = testo.replace("<?-&4-?>", getEntityPDFRicevuta().getDataNascita());
    	testo = testo.replace("<?-&5-?>", getEntityPDFRicevuta().getComuneNascita());
    	testo = testo.replace("<?-&6-?>", getEntityPDFRicevuta().getProvNascita());
    	testo = testo.replace("<?-&7-?>", getEntityPDFRicevuta().getLocalitaEsteraNascita());
    	testo = testo.replace("<?-&8-?>", getEntityPDFRicevuta().getStatoNascita());
    	testo = testo.replace("<?-&9-?>", getEntityPDFRicevuta().getEstremiDocumento());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }   
    
    
    
    
    
    
    public  String setTextParamatriBorsaDiStudio(String testo,BorseDiStudio borsedistudio)
    {
    	testo = testo.replace("<?-&1-?>", borsedistudio.getDenomBStudio());
    	testo = testo.replace("<?-&2-?>", borsedistudio.getFacoltaBStudio());
    	testo = testo.replace("<?-&3-?>", borsedistudio.getUniveBStudio());
    	testo = testo.replace("<?-&4-?>", borsedistudio.getLuogoBStudio());
    	testo = testo.replace("<?-&5-?>", borsedistudio.getNazioneBStudio());
    	testo = testo.replace("<?-&6-?>", borsedistudio.getDataIniFineBStudio());
    	testo = testo.replace("<?-&7-?>", borsedistudio.getSeEsteraPrivataBStudio());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    public  String setTextParamatriSpecializzazioni(String testo,SpecializzazioniUniversitarie specializzazioni)
    {
    	testo = testo.replace("<?-&1-?>", specializzazioni.getDenomSpecializza());
    	testo = testo.replace("<?-&2-?>", specializzazioni.getFacoltaSpecializza());
    	testo = testo.replace("<?-&3-?>", specializzazioni.getUniveSpecializza());
    	testo = testo.replace("<?-&4-?>", specializzazioni.getLuogoSpecializza());
    	testo = testo.replace("<?-&5-?>", specializzazioni.getNazioneSpecializza());
    	testo = testo.replace("<?-&6-?>", specializzazioni.getDurataSpecializza());
    	testo = testo.replace("<?-&7-?>", specializzazioni.getSeEsteraPrivataSpecializza());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }

    
    public  String setTextParamatriSecondaLaurea(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getAltraLaurea());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getUnivAltraLaurea());
    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getLuogoAltraLaurea());
    	testo = testo.replace("<?-&4-?>", getEntityPDFRicevuta().getDataAltraLaurea());
    	testo = testo.replace("<?-&5-?>", getEntityPDFRicevuta().getNazioneAltraLaurea());
    	testo = testo.replace("<?-&6-?>", getEntityPDFRicevuta().getSeEsteraPrivataAltraLaurea());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    public  String setTextParamatriSecondaLaureaF(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getAltraLaureaF());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getUnivAltraLaureaF());
    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getLuogoAltraLaureaF());
    	testo = testo.replace("<?-&4-?>", getEntityPDFRicevuta().getDataAltraLaureaF());
    	testo = testo.replace("<?-&5-?>", getEntityPDFRicevuta().getNazioneAltraLaureaF());
    	testo = testo.replace("<?-&6-?>", getEntityPDFRicevuta().getSeEsteraPrivataAltraLaureaF());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }    
   
    public  String setTextParamatriRequisitiMinimi(String testo)
    {
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    public  String setTextParamatriAbilitazione(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getNazioneAbilitazione());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getUniversitaAbiltazione());
    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getLuogoAbilitazione());
    	testo = testo.replace("<?-&4-?>", getEntityPDFRicevuta().getAnnoAbilitazione());
    	
    	String votoAbilitazione=getEntityPDFRicevuta().getVotoAbilitazione();
    	String baseVotoAbilitazione=getEntityPDFRicevuta().getBaseVotoAbilitazione();
    	
    	if(votoAbilitazione!=null && baseVotoAbilitazione!=null && !votoAbilitazione.equals("") && !baseVotoAbilitazione.equals(""))
    	{
    		testo = testo.replace("<?-&5-?>", votoAbilitazione + " / " + baseVotoAbilitazione);
    	}
    	else
    	{
    		testo = testo.replace("<?-&5-?>"," - ");
    	}
    	
    	if (!getEntityPDFRicevuta().getEstremiAbilitazione().equals(""))
    	{	
    		testo = testo.replace("<?-&6-?>", getEntityPDFRicevuta().getEstremiAbilitazione());
    	}
    	else
    	{	
    		testo = testo.replace("<?-&6-?>", "<?-elimina-?>");
    	}    		
    	
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    
    public  String setTextParamatriLaureaPrinc(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getTipoLaurea());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getUniversitaConseg());
    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getLuogoLaurea());
    	testo = testo.replace("<?-&4-?>", getEntityPDFRicevuta().getDataLaurea());
    	
    	String votoLaurea=getEntityPDFRicevuta().getVotoLaurea();
    	String baseVotoLaurea=getEntityPDFRicevuta().getBaseVotoLaurea();
    	
    	if(votoLaurea!=null && baseVotoLaurea!=null && !votoLaurea.equals("") && !baseVotoLaurea.equals(""))
    	{
    		testo = testo.replace("<?-&5-?>", votoLaurea + " / " + baseVotoLaurea + " " + getEntityPDFRicevuta().getLodeVotoLaurea());
    	}
    	else
    	{
    		testo = testo.replace("<?-&5-?>"," - ");
    	}
    	
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    
    public  String setTextParamatriPaBolzano(String testo)
    {
    	if (!getEntityPDFRicevuta().getPaBolzano().equals(""))
    	{
    		testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getPaBolzano());
		}
		else
		{	
			testo = testo.replace("<?-&1-?>", "<?-elimina-?>");
		} 
    	
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }    

    
    public  String setTextParamatriHeader(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getDescRegUtente());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getDataInvio());
    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getModoPartecipa());
    	testo = testo.replace("<?-&4-?>", getEntityPDFRicevuta().getNumeroProtocollo());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }    
    
    public  String setTextParamatriDatiAlboFarmacisti(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getProvIscrizioneFarmacisti());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getProvAttualeIscrizioneFarmacisti());
    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getDataPrimaIscrizioneFarmacisti());
    	testo = testo.replace("<?-&4-?>", getEntityPDFRicevuta().getNumeroIscrizioneFarmacisti());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    public  String setTextParamatriDatiCittadinanza(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getCittadinanza());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getListaElettorale());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }     
    
    public  String setTextParamatriDatiAppartenenza(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getAppartenenza());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    } 
    
    
    
    
    
    
    
    public  String setTextParamatriFineRicevuta(String testo)
    {
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }    
    
    public  String setTextParamatriEstremiDocVersamento(String testo)
    {
    	String listaDocumenti = new String();
    	String appo_salto = "";
    	int idx = 1;
    	for (String w_documento : getEntityPDFRicevuta().getListaDocumentiVersamento())
    	{  
    		listaDocumenti = listaDocumenti + w_documento ;
    		if (idx > 0)
    			listaDocumenti = listaDocumenti + "  --  ";
    		idx++;
    	}
    	testo = testo.replace("<?-&1-?>", listaDocumenti.toUpperCase());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }    
   
    
    public  String setTextParamatriEstremiVersamento(String testo)
    {
    	if (!getEntityPDFRicevuta().getEstremiVersamento().equals(""))
    	{
    		testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getEstremiVersamento());
		}
		else
		{	
			testo = testo.replace("<?-&1-?>", "<?-elimina_vers-?>");
		} 
    	if (!getEntityPDFRicevuta().getDataOperazioneVers().equals(""))
    	{
    		testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getDataOperazioneVers());
		}
		else
		{	
			testo = testo.replace("<?-&2-?>", "<?-elimina-?>");
		} 
    	if (!getEntityPDFRicevuta().getIbanVersamento().equals(""))
    	{
    		testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getIbanVersamento());
		}
		else
		{	
			testo = testo.replace("<?-&3-?>", "<?-elimina-?>");
		}     	
    	if (!getEntityPDFRicevuta().getCroVersamento().equals(""))
    	{
    		testo = testo.replace("<?-&4-?>", getEntityPDFRicevuta().getCroVersamento());		
    	}
		else
		{	
			testo = testo.replace("<?-&4-?>", "<?-elimina-?>");
		}
    	if (!getEntityPDFRicevuta().getDataVersamento().equals(""))
    	{
    		testo = testo.replace("<?-&5-?>", getEntityPDFRicevuta().getDataVersamento());		
    	}
		else
		{	
			testo = testo.replace("<?-&5-?>", "<?-elimina-?>");
		}
    	if (!getEntityPDFRicevuta().getNumeroUfficio().equals(""))
    	{
    		testo = testo.replace("<?-&6-?>", getEntityPDFRicevuta().getNumeroUfficio());		
    	}
		else
		{	
			testo = testo.replace("<?-&6-?>", "<?-elimina-?>");
		}    	
    	if (!getEntityPDFRicevuta().getProgOperazioneVCY().equals(""))
    	{
    		testo = testo.replace("<?-&7-?>", getEntityPDFRicevuta().getProgOperazioneVCY());		
    	}
		else
		{	
			testo = testo.replace("<?-&7-?>", "<?-elimina-?>");
		}
    	
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }    
    
    
    public  String setTextParamatriTitoloProfessionale(String testo, EsercizioProfessionale esercizioProfessionale)
    {
    	testo = testo.replace("<?-&1-?>", esercizioProfessionale.getDalTitoloProf());
    	testo = testo.replace("<?-&2-?>", esercizioProfessionale.getAlTitoloProf());
    	testo = testo.replace("<?-&3-?>", esercizioProfessionale.getModoTitoloProf());
    	testo = testo.replace("<?-&4-?>", esercizioProfessionale.getRuoloTitoloProf());
    	testo = testo.replace("<?-&5-?>", esercizioProfessionale.getTipoStruttura());
    	testo = testo.replace("<?-&6-?>", esercizioProfessionale.getDenomStruttura());
    	testo = testo.replace("<?-&7-?>", esercizioProfessionale.getIndiStruttura());
    	testo = testo.replace("<?-&8-?>", esercizioProfessionale.getRegioneStruttura());
    	testo = testo.replace("<?-&9-?>", esercizioProfessionale.getProvStruttura());
    	testo = testo.replace("<?-&10-?>", esercizioProfessionale.getComStruttura());
    	testo = testo.replace("<?-&11-?>", esercizioProfessionale.getAslRiferimento());
    	testo = testo.replace("<?-&12-?>", esercizioProfessionale.getFarmRurale());
    	
    	testo = testo.replace("<?-&13-?>", esercizioProfessionale.getCapStruttura());
    	
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    
    public  String setTextParamatriPubblScient(String testo,PubblicazioneScentifica pubblicscient)
    {
    	testo = testo.replace("<?-&1-?>", pubblicscient.getTipoPubblic());
    	testo = testo.replace("<?-&2-?>", pubblicscient.getAutorePubb());
    	testo = testo.replace("<?-&3-?>", pubblicscient.getTitoloStudio());
    	testo = testo.replace("<?-&4-?>", pubblicscient.getEditoreStudio());
    	testo = testo.replace("<?-&5-?>", pubblicscient.getIsbn());
    	testo = testo.replace("<?-&6-?>", pubblicscient.getDataPubblicazione());    	
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    
    public  String setTextParamatriCorsiAgg(String testo,CorsoDiAggiornamento corsodiaggiornamento)
    {
    	testo = testo.replace("<?-&1-?>", corsodiaggiornamento.getTitoloAggCorso());
    	testo = testo.replace("<?-&2-?>", corsodiaggiornamento.getOrganizzatoAggCorso());
    	testo = testo.replace("<?-&3-?>", corsodiaggiornamento.getGiornoPeridoAggCorso());
    	testo = testo.replace("<?-&4-?>", corsodiaggiornamento.getTotaleOreEsame());
    	testo = testo.replace("<?-&5-?>", corsodiaggiornamento.getEsitoEsameSuperato()); 
    	testo = testo.replace("<?-&6-?>", corsodiaggiornamento.getSeEsteroPrivatoEsame()); 
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }    
    
    public  String setTextParamatriIdoneitaNaz(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getRifIdoneitaNaz());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getAnnoIdoneitaNaz());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    
    public  String setTextParamatriIdoneita(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getIdoneitaConseguita());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getEstremiAtto());
    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getDataAtto());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }

    
    public  String setTextParamatriAltriTitoli(String testo,AltriTitoli altrititoli)
    {
    	testo = testo.replace("<?-&1-?>", altrititoli.getTitoloAltro());
    	testo = testo.replace("<?-&2-?>", altrititoli.getDurataAltro());
    	testo = testo.replace("<?-&3-?>", altrititoli.getRilasciatoDaAltro());
    	testo = testo.replace("<?-&4-?>", altrititoli.getDataRilascio());
    	testo = testo.replace("<?-&5-?>", altrititoli.getEsitoFinaleAltro());
    	testo = testo.replace("<?-&6-?>", altrititoli.getNoteAltro());
    	testo = testo.replace("<?-&7-?>", altrititoli.getSeEsteraPrivataAltro());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    
    public  String setTextParamatriDottorato(String testo,DottoratoPDF dottorato)
    {
    	testo = testo.replace("<?-&1-?>", dottorato.getDenomDottorato());
    	testo = testo.replace("<?-&2-?>", dottorato.getFacoltaDottorato());
    	testo = testo.replace("<?-&3-?>", dottorato.getUniveDottorato());
    	testo = testo.replace("<?-&4-?>", dottorato.getLuogoDottorato());
    	testo = testo.replace("<?-&5-?>", dottorato.getNazioneDottorato());
    	testo = testo.replace("<?-&6-?>", dottorato.getDataIniFineDottorato());
    	testo = testo.replace("<?-&7-?>", dottorato.getSeEsteraPrivataDottorato());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }
    
    public  String setTextParamatriDatiResidenza(String testo)
    {
    	testo = testo.replace("<?-&1-?>", getEntityPDFRicevuta().getIndirizzoResidenza());
    	testo = testo.replace("<?-&2-?>", getEntityPDFRicevuta().getNazioneResidenzaUtente());
    	testo = testo.replace("<?-&3-?>", getEntityPDFRicevuta().getComuneResidenza());
    	testo = testo.replace("<?-&4-?>", getEntityPDFRicevuta().getProvResidenza());
    	testo = testo.replace("<?-&5-?>", getEntityPDFRicevuta().getLocalitaResidenzaEstera());
    	testo = testo.replace("<?-&6-?>", getEntityPDFRicevuta().getCapResidenza());
    	testo = testo.replace("<?-&7-?>", getEntityPDFRicevuta().getRifTelefonico());
    	testo = testo.replace("<?-&8-?>", getEntityPDFRicevuta().getEmailCertificata());
    	while (testo.indexOf("<?-n-?>") > 0)
    	{
    		testo = testo.replace("<?-n-?>", "\r\n");
    	}
    	return testo;
    }   
    
    public  Document creaRicevuta(PdfWriter pdfWrite)
    {
            // Carica Logo Ministero
			//BufferedImage img = ImageIO.read(new FileInputStream(currentDir.getAbsolutePath() + "//WebContent//images//layout//logo_ministero.png"));
			try {
				java.io.File currentDir = new java.io.File("");
				/*
				Image img = null;
				img = Image.getInstance(currentDir.getAbsolutePath() + "//WebContent//images//layout//logo_ministero.png");
				img.setAlignment(Image.LEFT | Image.TEXTWRAP);
				img.setBorder(Image.BOX);
				img.setBorderWidth(0);      
				documento.add(img);
				*/	
				String testo = "";
				
				if(seOggetto)
				{
					nriga_posizione = 800;
					testo = getBodyRicevuta().getProperty("oggetto").toUpperCase();
//					if(uteCandi.getCandidatura().getStatoDomanda().equals("I")){
//						testo = testo+"\r \n"+  getBodyRicevuta().getProperty("oggettoRettifica").toUpperCase();
//						}
					testo = setTextParamatriOggetto(testo);				
					createBoxOggettoText(testo,pdfWrite);
					
				}
				else
				{
					nriga_posizione = POS_RIGA_SALTO_PAGINA; 
					String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
					createBoxPaginazioneText("",w_testo,pdfWrite);
					nriga_posizione = 840;
					w_testo = getBodyRicevuta().getProperty("headerpagina");
					w_testo = setTextParamatriHeader(w_testo);
					nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
					nriga_posizione = 790;
				}
				
//				testo = getBodyRicevuta().getProperty("dichiarazione.esattezza.dati");
//				testo = setTextParamatriDichiarazione(testo);
//				createBoxDichiarazione(testo,pdfWrite);
				
				testo = getBodyRicevuta().getProperty("datinvio");
				testo = setTextParamatriDatiInvio(testo);								
				createBoxDatiInvioText("DATEN DER EINREICHUNG DER BEWERBUNG F�R DIE AUSSCHREIBUNG \n",testo,pdfWrite); 
				
				testo = getBodyRicevuta().getProperty("nota");
				testo = setTextParamatriOggetto(testo);
				createBoxNotaText("",testo,pdfWrite);
				
				testo = getBodyRicevuta().getProperty("datianagrafici");
				testo = setTextParamatriDatiAnagraficaInvio(testo);								
				createBoxDatiAnagraficiText("PERSONENDATEN\n",testo,pdfWrite); 
				testo = getBodyRicevuta().getProperty("datiresidenza");
				testo = setTextParamatriDatiResidenza(testo);
				createBoxDatiResidenzaText("WOHNSITZ\n",testo,pdfWrite);								
				testo = getBodyRicevuta().getProperty("appartenenza");
				testo = setTextParamatriDatiAppartenenza(testo);
				createBoxDatiAppartenenzaText("DATEN ZUR INHABERKATEGORIE\n",testo,pdfWrite);						
				testo = getBodyRicevuta().getProperty("cittadinanza");
				testo = setTextParamatriDatiCittadinanza(testo);
				createBoxDatiCittadinanzaText("STAATSBURGERSCHAFT UND BURGERLICHE BZW. POLITISCHE RECHTE\n",testo,pdfWrite);				
				testo = getBodyRicevuta().getProperty("iscrizionealbo");
				testo = setTextParamatriDatiAlboFarmacisti(testo);
				createBoxDatiAlboFarmacistiText("EINTRAGUNG IN DAS BERUFSVERZEICHNIS DER APOTHEKER\n",testo,pdfWrite);
				testo = getBodyRicevuta().getProperty("pabolzano");				
				testo = setTextParamatriPaBolzano(testo);
				if (!testo.contains("<?-elimina-?>"))
				{
					createBoxPaBolzanoText("WEITEREN ERKL�RUNG \n",testo,pdfWrite);					
				}													
				testo = getBodyRicevuta().getProperty("laureaprinciale");
				testo = setTextParamatriLaureaPrinc(testo);
				createBoxLaureaPrincText("HAUPTDIPLOMSTUDIUM\n",testo,pdfWrite);					
				testo = getBodyRicevuta().getProperty("abilitazione");
				testo = setTextParamatriAbilitazione(testo);
				createBoxAbilitazioneText("STAATSEXAMEN\n",testo,pdfWrite);					
				/* ---- */				
				testo = getBodyRicevuta().getProperty("requisitimin");
				testo = setTextParamatriRequisitiMinimi(testo);
				createBoxRequisitiMinimiText("ERKL�RUNG ZU DEN MINDESTKRITERIEN\n",testo,pdfWrite);									
				if (!getEntityPDFRicevuta().getAltraLaureaF().equals(""))
				{
					testo = getBodyRicevuta().getProperty("secondalaureaF");
					testo = setTextParamatriSecondaLaureaF(testo);
					createBoxSecondaLaureaTextF("ZWEITES DIPLOMSTUDIUM IN PHARMAZIE ODER CPT (ART. 6, ABSATZ 1, BUCHSTABLE D) DPCM 298/94\n",testo,pdfWrite);					
				}					
				if (!getEntityPDFRicevuta().getAltraLaurea().equals(""))
				{
					testo = getBodyRicevuta().getProperty("secondalaurea");
					testo = setTextParamatriSecondaLaurea(testo);
					createBoxSecondaLaureaText("ZWEITES DIPLOMSTUDIUM (IM SINNE VON ART. 6, ABSATZ 1, BUCHSTABLE B) DPCM 298/94\n",testo,pdfWrite);
				}				
				if (!getEntityPDFRicevuta().getListaSpeciaUnivers().isEmpty())
				{
					testo = getBodyRicevuta().getProperty("specializzazione");
					createBoxSpecializzazioniText("UNIVERSITARE FACHAUSBILDUNGEN (IM SINNE VON ART. 6, ABSATZ 1, BUCHSTABLE C) DPCM 298/94\n",testo,pdfWrite);
					
				}
				if (!getEntityPDFRicevuta().getListaBorseDiStudio().isEmpty())
				{	
					testo = getBodyRicevuta().getProperty("borsastudio");
					createBoxBorsaDiStudioText("STUDIEN- ODER FORSCHUNGSSTIPENDIEN FUR DIE FAKULTAT PHARMAZIE ODER CPT IM SINNE VON ART. 6, ABSATZ 1, BUCHSTABLE C) DPCM 298/94 \n",testo,pdfWrite);
				}	
				if (!getEntityPDFRicevuta().getListaDottorato().isEmpty())
				{				
					testo = getBodyRicevuta().getProperty("dottorato");
					createBoxDottoratoText("DOKTORATSTUDIUM AN FAKULTATEN DER PHARMAZIE ODER CPT\n",testo,pdfWrite);					
				}
				if (!getEntityPDFRicevuta().getListaAltriTitoli().isEmpty())
				{					
					testo = getBodyRicevuta().getProperty("altrititoli");				
					createBoxAltriTitoliText("WEITERE STUDIENTITEL (MASTER UND LEHRGANGE ZUR WEITERBILDUNG)\n",testo,pdfWrite);;
				}
				if (!getEntityPDFRicevuta().getIdoneitaConseguita().equals(""))
				{				
					testo = getBodyRicevuta().getProperty("idoneita");
					testo = setTextParamatriIdoneita(testo);
					createBoxIdoneitaText("BEFAHIGUNG'\n",testo,pdfWrite);
				}	
				if (!getEntityPDFRicevuta().getRifIdoneitaNaz().equals(""))
				{					
					testo = getBodyRicevuta().getProperty("idoneitanaz");
					testo = setTextParamatriIdoneitaNaz(testo);
					createBoxIdoneitaNazText("STAATLICHE BEFAHIGUNG FUR LEITENDEN APOTHEKER\n",testo,pdfWrite);
				}
				if (!getEntityPDFRicevuta().getListaCorsiAggiornamento().isEmpty())
				{					
					testo = getBodyRicevuta().getProperty("corsoagg");				
					createBoxCorsiAggText("WEITERBILDUNGSKURSE, AUSGENOMMEN DIE STANDIGE MEDIZINISCHE WEITERBILDUNG, ABSOLVIERT AB DEM: <?-&1-?>\n",testo,pdfWrite);
				}
				if (!getEntityPDFRicevuta().getListaPubblicaScentifica().isEmpty())
				{				
					testo = getBodyRicevuta().getProperty("pubbscient");
					createBoxPubblScientText("WISSENSCHAFTLICHE PUBLIKATIONEN, VEROFFENTLICHT AB DEM: <?-&1-?>\n",testo,pdfWrite);
				}
				if (!getEntityPDFRicevuta().getListaEsercizioProfessionale().isEmpty())
				{
					testo = getBodyRicevuta().getProperty("eserprof");
					createBoxTitoloProfessionaleText("TITEL IN BEZUG AUF DIE AUSGE�BTE BERUFSTATIGKEIT IM SINNE VON ART. 5  DPCM 298/94 \n",testo,pdfWrite);
				}
				if (getEntityPDFRicevuta().getEstremiVersamento()!=null && !getEntityPDFRicevuta().getEstremiVersamento().equals("") && getEntityPDFRicevuta().getListaDocumentiVersamento().isEmpty())
				{				
					testo = getBodyRicevuta().getProperty("estremivers");
					testo = setTextParamatriEstremiVersamento(testo);						
					if (!testo.contains("<?-elimina_vers-?>"))
					{
						createBoxEstremiVersamentoText("DATEN DER EINZAHLUNG UND BEWERTUNGSUNTERLAGEN \n",testo,pdfWrite);					
					}
				}
				
				testo = getBodyRicevuta().getProperty("dichiarazione.esattezza.dati")+"\r \n"+getBodyRicevuta().getProperty("autorizzazione.trattamento.dati");
				testo = setTextParamatriDichiarazione(testo);
				createBoxSecondaDichiarazione(testo,pdfWrite);
				
				if ( (!getEntityPDFRicevuta().getListaDocumentiVersamento().isEmpty())||(getEntityPDFRicevuta().getListaDocumentiVersamento().size()>0))
				{
					nriga_posizione = POS_RIGA_SALTO_PAGINA; 
					String w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
					createBoxPaginazioneText("",w_testo,pdfWrite);
					documentoPDF.newPage();
					pdfWrite.setPageEmpty(false);
					nriga_posizione = 840;
					w_testo = getBodyRicevuta().getProperty("headerpagina");
					w_testo = setTextParamatriHeader(w_testo);
					nriga_posizione = nriga_posizione - ((int)createBoxHeaderText("",w_testo,pdfWrite).getTotalHeight() + 5);
					nriga_posizione = 790;
					testo = getBodyRicevuta().getProperty("lettaracc").toUpperCase();
					testo = setTextParamatriOggetto(testo);
					createBoxOggettoText(testo,pdfWrite);
					
//					testo = getBodyRicevuta().getProperty("nota");
//					testo = setTextParamatriOggetto(testo);
//					createBoxNotaText("NOTA\n",testo,pdfWrite);
					testo = getBodyRicevuta().getProperty("datinvio");
					testo = setTextParamatriDatiInvio(testo);
					createBoxDatiInvioText("SENDEN VON DATEN DEN ANTRAG AUF TEILNAHME AN DER CONTEST\n",testo,pdfWrite);				
					testo = getBodyRicevuta().getProperty("datianagrafici");
					testo = setTextParamatriDatiAnagraficaInvio(testo);
					createBoxDatiAnagraficiText("PERSONENDATEN\n",testo,pdfWrite);				
					testo = getBodyRicevuta().getProperty("datiresidenza");
					testo = setTextParamatriDatiResidenza(testo);
					createBoxDatiResidenzaText("WOHNSITZ\n",testo,pdfWrite);
					
					//dichiarazione invio documenti (e contributo)
					String contributo=getEntityPDFRicevuta().getContributoPartecipazione();
					if(contributo!=null && contributo.equals("1"))
					{
						testo = getBodyRicevuta().getProperty("estremiversa.contributo.si");
					}
					else
					{
						testo = getBodyRicevuta().getProperty("estremiversa.contributo.no");
					}
					
					/*
					testo = setTextParamatriEstremiDocVersamento(testo);
					createBoxEstremiDocVersamentoText("ELENCO DEI DOCUMENTI INDICATI NELLA DOMANDA DI PARTECIPAZIONE AL CONCORSO \n",testo,pdfWrite);				
					*/
					
					testo = setTextParamatriEstremiDocVersamento(testo);
					String testo1= "";
					String testo2= "";
					String testoApp = "";
					int indice = 0;
					boolean oversize = false;
					if(testo.length()>4300){
						
						oversize = true;
						testoApp = testo.substring(4300);
						indice = testoApp.indexOf(" -- ");
						testo1 = testo.substring(0 , indice+4300);
						testo2 = testo.substring(indice+4300);
					}
					
					if(!oversize){
					
						createBoxEstremiDocVersamentoText("LISTE DER IN DER BEWERBUNG F�R DIE AUSSCHREIBUNG ANGEF�HRTEN DOKUMENTE \n",testo,pdfWrite);	
					
					}else{
						
						createBoxEstremiDocVersamentoText("LISTE DER IN DER BEWERBUNG F�R DIE AUSSCHREIBUNG ANGEF�HRTEN DOKUMENTE \n",testo1,pdfWrite);	
						
						documentoPDF.newPage();
						pdfWrite.setPageEmpty(false);
						nriga_posizione = 840;
						createBoxEstremiDocVersamentoTextSecondo("LISTE DER IN DER BEWERBUNG F�R DIE AUSSCHREIBUNG ANGEF�HRTEN DOKUMENTE \n",testo2,pdfWrite);
					
					}
					
					testo = getBodyRicevuta().getProperty("finericevuta");
					testo = setTextParamatriFineRicevuta(testo);
					createBoxFineRicevutaText("",testo,pdfWrite);
					nriga_posizione = POS_RIGA_SALTO_PAGINA; 
					w_testo = "Pag. " + pdfWrite.getPageNumber() + " di " + new Integer(totale_pagine_stampate).toString();
					createBoxPaginazioneText("",w_testo,pdfWrite);					
					
				}							
				/* --- NUOVA PAGINA 5 PDF --*/	
				/*
				if (totale_pagine == 0)
				{					
					totale_pagine = (int)pdfWrite.getPageNumber();
				}	
				if (contaLepagine)
				{	
					totale_pagine_stampate = totale_pagine_stampate + totale_pagine;
				}
				*/
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				return documentoPDF;	
			}
    }
    
    public  Properties getBodyRicevuta() {
		return bodyRicevuta;
	}
	public void setBodyRicevuta(Properties bodyRicevuta) {
		this.bodyRicevuta = bodyRicevuta;
	}
	public  Date formatStrToDate(String strData)
	{
		Date date = null;
		if ( (strData!=null) && (!strData.equals("")))
		{
			try
			{
			 DateFormat formatter ; 
			 formatter = new SimpleDateFormat("dd-MM-yyyy");
			 date = (Date)formatter.parse(strData);  
			} catch (ParseException e)
			  {e.printStackTrace();}
			
		}
		return date; 
	}
	public  void rigeneraNumeroProtocolloByIdUtente(String id_utente) throws Exception{
		try		
		{
			CandidaturaHome candidaturaDAO = new CandidaturaHome();
			UtenteCandidatura utenteCandidatura = null;
			utenteCandidatura = candidaturaDAO.findByUserId(id_utente);
			RicevuteHome ricevuteDAO = new RicevuteHome();
			Ricevute ricevuta = ricevuteDAO.findByCandidatura(utenteCandidatura.getCandidatura().getIdCandidatura());
			ricevute = ricevuta;
			id_ricevuta_inserito = ricevute.getId().getIdRicevuta();
	        numero_protocollo_ricevuta = id_ricevuta_inserito + " - " + dateInvio +  " - " + login.getIdRegione();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}	
	public  boolean salvaRicevutaPDF(byte[] ricevutaPDF) throws Exception{
		boolean result = false;		
		
		try		
		{
			RicevuteHome ricevuteDAO = new RicevuteHome();
			id_ricevuta_inserito = ricevuteDAO.leggiIdSequence(login.getIdRegione().toString());
			ricevuteId = new RicevuteId();
			ricevuteId.setIdCandidatura(uteCandi.getCandidatura().getIdCandidatura()); 
			ricevuteId.setIdRicevuta(id_ricevuta_inserito);
			ricevuteId.setIdRegione(login.getIdRegione());
	        ricevute = new Ricevute();
	        ricevute.setId(ricevuteId);
	        ricevute.setContenutoFile(ricevutaPDF);
	        ricevute.setFlagInvio("N");
	        ricevute.setDataInvio(formatStrToDate(dateInvio));
	        ricevuteDAO.insertRicevute(ricevute);
	        numero_protocollo_ricevuta = id_ricevuta_inserito + " - " + dateInvio +  " - " + login.getIdRegione();
	        result = true;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;

 /*
        session.save(avatar);
 
        //Get image from database
        Avatar avatar2 = (Avatar)session.get(Avatar.class, avatar.getAvatarId());
        byte[] bAvatar = avatar2.getImage();
 
        try{
            FileOutputStream fos = new FileOutputStream("C:\\test.gif"); 
            fos.write(bAvatar);
            fos.close();
        }catch(Exception e){
            e.printStackTrace();
        }
 
        session.getTransaction().commit();		
		return result;
		*/
	}
	
	public  boolean modificaRicevutaPDF(byte[] ricevutaPDF) throws Exception{
		boolean result = false;		
		
		try
		{
			RicevuteHome ricevuteDAO = new RicevuteHome();	        
			ricevute.setContenutoFile(ricevutaPDF);	        
	        ricevuteDAO.modifyBLOB(ricevute);
	        result = true;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return result;

 /*
        session.save(avatar);
 
        //Get image from database
        Avatar avatar2 = (Avatar)session.get(Avatar.class, avatar.getAvatarId());
        byte[] bAvatar = avatar2.getImage();
 
        try{
            FileOutputStream fos = new FileOutputStream("C:\\test.gif"); 
            fos.write(bAvatar);
            fos.close();
        }catch(Exception e){
            e.printStackTrace();
        }
 
        session.getTransaction().commit();		
		return result;
		*/
	}	
	
	public  void creaRicevutaPDF() throws Exception{ 
		
		  numero_protocollo_ricevuta = "";
		  /*
		  entityPDFRicevuta = initUteCandRicev();
		  getListaEntityPDFRicevuta().add(entityPDFRicevuta);
		  getListaEntityPDFRicevuta().add(entityPDFRicevuta);
		  getListaEntityPDFRicevuta().add(entityPDFRicevuta);
		  */
		/* Obbligatorio chiamare due volte perche' 
		 * la prima volta simula per contare totale pagine
		 */
		  try 
		  { 
			  id_ricevuta_inserito = "";
			  //File f = new File("c:\\output.pdf");
			  //f.delete();		  
			  documentoPDF = new Document();				  
		  	  //PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;		 
			  int conta = 1;
			  for (EntityPDFRicevuta w_entity : getListaEntityPDFRicevuta())
			  {
				  setEntityPDFRicevuta(w_entity);
				  if (entityPDFRicevuta!=null)
				  {
					  w_entity.setNumeroProtocollo(numero_protocollo_ricevuta);
					  creaRicevuta(pdfWrite);
					  if (seOggetto)
					  {
						  seOggetto = false;
					  }
				  }
				  if (conta < getListaEntityPDFRicevuta().size())
				  {
					  documentoPDF.newPage();
					  pdfWrite.setPageEmpty(false);
				  }  
				  conta++;
			  }
			  totale_pagine_stampate = pdfWrite.getPageNumber();
			  documentoPDF.close();
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }
		  contaLepagine = false;
		  salvaRicevutaPDF(null);		  
		  try 
		  { 
			 // File f = new File("c:\\output.pdf");
			 // f.delete();		  
			  documentoPDF = new Document();	
		  	  //PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;		 
			  int conta = 1;
			  for (EntityPDFRicevuta w_entity : getListaEntityPDFRicevuta())
			  { 	
				  setEntityPDFRicevuta(w_entity);
				  if (entityPDFRicevuta!=null)
				  {
					  w_entity.setNumeroProtocollo(numero_protocollo_ricevuta);
					  creaRicevuta(pdfWrite);				   		
					  if (seOggetto)
					  {
						  seOggetto = false;
					  }
				  }	 
				  if (conta < getListaEntityPDFRicevuta().size())
				  {
					  documentoPDF.newPage();
					  pdfWrite.setPageEmpty(false);
				  }  
				  conta++;
			  }			  
			  documentoPDF.close();
			  if (getImgRicevutaPDF()==null)
			  {
				  imgRicevutaPDF = docBufferPDF.toByteArray();
			  } 
			  modificaRicevutaPDF(getImgRicevutaPDF());
			  
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }		  
	
    }
    
    public  void leggoPDFDaFile() throws Exception{ 
    	Document doc = null;  
    	/*
    	try 
    	{  
    		doc = Document.load("C:\\output.pdf" );  
    		PDPage page = (PDPage)doc.getDocumentCatalog().getAllPages().get(0);  
    		PDPageContentStream contentStream = new PDPageContentStream(doc, page, true, true);  
    		PDFont font = PDType1Font.HELVETICA_BOLD;  
    		contentStream.beginText();  
    		contentStream.setFont( font, 12 );  
    		contentStream.moveTextPositionByAmount( 260, 700 );  
    		contentStream.drawString( "!!!!!" );  
    		contentStream.endText();  
    		contentStream.close();  
    		doc.save("c:\\outputMod.pdf");  
    		doc.close();  
    	} catch (IOException e) {  
    		e.printStackTrace();  
    	} catch (COSVisitorException e) {  
    		e.printStackTrace();  
    	}  
    	*/
    }	  
    
    public  void downloadFile()
    {
    	byte[] pdfData = getImgRicevutaPDF();
    	try
    	{
            FacesContext facesContext = FacesContext.getCurrentInstance(); 
            ExternalContext externalContext = facesContext.getExternalContext(); 
            HttpServletResponse response = (HttpServletResponse) externalContext.getResponse(); 
            ServletContext servletContext = (ServletContext) externalContext.getContext(); 
            response.reset(); 
            response.setContentType(servletContext.getMimeType("ricevutaDomanda.pdf")); 
            response.setContentLength((int) pdfData.length); 
            response.setHeader("Content-disposition", "attachment; filename=\"ricevutaDomanda.pdf\"");
            ByteArrayInputStream in = null;             
            BufferedInputStream input = null; 
            BufferedOutputStream output = null; 
            final int buffersize = (int) pdfData.length; 
            try 
            { 
            	in = new ByteArrayInputStream(pdfData);
            	input = new BufferedInputStream(in); 
            	output = new BufferedOutputStream(response.getOutputStream(), buffersize); 
            	byte[] buffer = new byte[buffersize]; 
            	for (int length; (length = input.read(buffer)) > 0;) 
            	{	 
            		output.write(buffer, 0, length); 
            	}            	
            } 
            finally 
            { 
            	if (input != null) 
            		try 
            		{ 
            			input.close(); 
            			output.close();
            		} 
            		catch (IOException e) 
            		{ 
            			e.printStackTrace(); 
            		} 
            } 
            facesContext.responseComplete();                             		
    	}
    	catch (IOException e)
    	{
    		e.printStackTrace();
    	}
    }
    
    
    public  void findUtenteCandidaDAO()
    {
    	uteCandi = new UtenteCandidatura();
    	String IdUtente = "145";
    	try {
	    	candidaturaHome = new CandidaturaHome();
	    	uteCandi = candidaturaHome.findByUserId(IdUtente);
    	}
    	catch (Exception e) {
			e.printStackTrace();
		} 
    	System.out.println("ciccio");
    }
   
    
    //ricrea solo il blob pdf
    public  void creaRicevutaPDFRecovery(String id_utente) throws Exception{ 
		
		  numero_protocollo_ricevuta = "";
		  /*
		  entityPDFRicevuta = initUteCandRicev();
		  getListaEntityPDFRicevuta().add(entityPDFRicevuta);
		  getListaEntityPDFRicevuta().add(entityPDFRicevuta);
		  getListaEntityPDFRicevuta().add(entityPDFRicevuta);
		  */
		/* Obbligatorio chiamare due volte perche' 
		 * la prima volta simula per contare totale pagine
		 */
		  try 
		  { 
			  id_ricevuta_inserito = "";
			  //File f = new File("c:\\output.pdf");
			  //f.delete();		  
			  documentoPDF = new Document();				  
		  	  //PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;		 
			  int conta = 1;
			  for (EntityPDFRicevuta w_entity : getListaEntityPDFRicevuta())
			  { 	
				  setEntityPDFRicevuta(w_entity);
				  if (entityPDFRicevuta!=null)
				  {
					  w_entity.setNumeroProtocollo(numero_protocollo_ricevuta);
					  creaRicevuta(pdfWrite);				   		
					  if (seOggetto)
					  {
						  seOggetto = false;
					  }
				  }	 
				  if (conta < getListaEntityPDFRicevuta().size())
				  {
					  documentoPDF.newPage();
					  pdfWrite.setPageEmpty(false);
				  }  
				  conta++;
			  }
			  totale_pagine_stampate = pdfWrite.getPageNumber();
			  documentoPDF.close();
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }
		  contaLepagine = false;
		  rigeneraNumeroProtocolloByIdUtente(id_utente);
		  ricevute = null;		  
		  try 
		  { 
			 // File f = new File("c:\\output.pdf");
			 // f.delete();		  
			  documentoPDF = new Document();	
		  	  //PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, new FileOutputStream("c:\\output.pdf"));
		  	  ByteArrayOutputStream docBufferPDF = new ByteArrayOutputStream();
		  	  PdfWriter pdfWrite = PdfWriter.getInstance(documentoPDF, docBufferPDF);
		  	  documentoPDF.open();
			  seOggetto = true;		 
			  int conta = 1;
			  for (EntityPDFRicevuta w_entity : getListaEntityPDFRicevuta())
			  { 	
				  setEntityPDFRicevuta(w_entity);
				  if (entityPDFRicevuta!=null)
				  {
					  w_entity.setNumeroProtocollo(numero_protocollo_ricevuta);
					  creaRicevuta(pdfWrite);				   		
					  if (seOggetto)
					  {
						  seOggetto = false;
					  }
				  }	 
				  if (conta < getListaEntityPDFRicevuta().size())
				  {
					  documentoPDF.newPage();
					  pdfWrite.setPageEmpty(false);
				  }  
				  conta++;
			  }			  
			  documentoPDF.close();
			  if (getImgRicevutaPDF()==null)
			  {
				  imgRicevutaPDF = docBufferPDF.toByteArray();
			  } 
			  ristampaRicevutaIdUtentePDFRecovery(id_utente);
			  modificaRicevutaPDF(getImgRicevutaPDF());
			  
		  } catch (Exception e) {  
			  e.printStackTrace();  
		  }		  
	
  }

}
