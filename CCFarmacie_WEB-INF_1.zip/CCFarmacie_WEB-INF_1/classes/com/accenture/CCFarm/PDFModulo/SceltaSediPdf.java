package com.accenture.CCFarm.PDFModulo;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.accenture.CCFarm.DAO.AnagraficaFarm;
import com.accenture.CCFarm.Exception.GestioneErroriException;
import com.accenture.CCFarm.utility.CommonLogger;
import com.accenture.CCFarm.utility.JSFUtility;
import com.accenture.CCFarm.utility.StaticDefinitions;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

public class SceltaSediPdf {
	
	private static Logger logger = CommonLogger.getLogger("SceltaSediPdf");
	
	private static Properties properties;
	
	private static BaseFont baseFont;
	private static Font bigFontBold;
	private static Font smallFontBold;
	private static Font smallFont;
	
	private static String totalPageNumberFormat;
	
	public SceltaSediPdf() throws Exception {
		
		loadProperties();
		
		//font
		baseFont = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
		bigFontBold = new Font(baseFont, 12, Font.BOLD);
		smallFontBold = new Font(baseFont, 10, Font.BOLD);
		smallFont = new Font(baseFont, 10, Font.NORMAL);
		
		totalPageNumberFormat = "999";
	}
	
	private void loadProperties() throws Exception {
		
		try {
			
			String linguaScelta = null;
			try {
				
				linguaScelta = (String) JSFUtility.getFacesContext().getExternalContext().getSessionMap().get("linguaScelta");
			}
    		catch(Exception e) {
    			
    			System.out.println("Impossibile determinare la lingua: impostata IT per default");
    			linguaScelta = "it";//* ONLY FOR TESTING *
    		}
    		
			String path = null;
			
    		if(linguaScelta.equalsIgnoreCase("it")) {
    			
    			path = StaticDefinitions.BASE_PATH+"/WEB-INF/conf/ricevutapdf.properties";

			}
    		else {
				
    			path = StaticDefinitions.BASE_PATH+"/WEB-INF/conf/ricevutapdf_de.properties";
    		
			}
    		
			InputStream in = new FileInputStream(path);
			properties = new Properties();
			properties.load(in);
		}
		catch(Exception e) {
			
			logger.error("SceltaSediPdf - caricamento delle propriet� fallito", e);
			//e.printStackTrace();//* ONLY FOR TESTING *
			throw e;
		}
	}
	
	//inner class for managing header/footer
	class PageHelper extends PdfPageEventHelper {
		
		PdfContentByte contentByte;
		PdfTemplate totalPageNumberTemplate;
		
		public PageHelper() {
			
		}
		
		public void onOpenDocument(PdfWriter writer, Document document) {
			
			contentByte = writer.getDirectContent();
			totalPageNumberTemplate = contentByte.createTemplate(baseFont.getWidthPoint(totalPageNumberFormat, smallFont.getSize()),
																 smallFont.getSize());
        }
		
		public void onCloseDocument(PdfWriter writer, Document document) {
            
			totalPageNumberTemplate.beginText();
			totalPageNumberTemplate.setFontAndSize(baseFont, smallFont.getSize());
			totalPageNumberTemplate.setTextMatrix(0, 0);
			totalPageNumberTemplate.showText(" " + String.valueOf(writer.getPageNumber() - 1));
			totalPageNumberTemplate.endText();
        }
		
		public void onStartPage(PdfWriter writer, Document document) {
	        
	    }
		
		public void onEndPage(PdfWriter writer, Document document) {
			
			try {
				
				String footerText = properties.getProperty("sceltasedi.testo.footer")
									.replace("<numero>", String.valueOf(writer.getPageNumber()));
				
				Rectangle pageSize = document.getPageSize();
				float xPos = pageSize.getRight(pageSize.getWidth() * 0.05f);//margine 5% da destra
				float yPos = pageSize.getBottom(35);
				
				contentByte.beginText();
				contentByte.setFontAndSize(baseFont, smallFont.getSize());
				contentByte.setTextMatrix(0, 0);
				contentByte.showTextAligned(PdfContentByte.ALIGN_RIGHT, footerText, xPos, yPos, 0);
				contentByte.endText();
				contentByte.addTemplate(totalPageNumberTemplate, xPos, yPos);
			}
			catch (Exception e) {
				
				logger.error("SceltaSediPdf - composizione testo footer fallita", e);
				//e.printStackTrace();//* ONLY FOR TESTING *
			}
        }
    }
	
	public byte[] creaRicevutaPDF(SceltaSediEntityPdf entity) throws GestioneErroriException {
		
		try {
			
	        //impostazione pagina
			//composizione -> Document(Rectangle pageSize, float marginLeft, float marginRight, float marginTop, float marginBottom) 
			Document document = new Document(PageSize.A4, 10, 10, 40, 40);
	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	        
	        PdfWriter pdfWriter = PdfWriter.getInstance(document, outputStream);
	        pdfWriter.setPageEvent(new PageHelper());
	        
	        //costruzione contenuto
	        document.open();
	        
	        //intestazione
	        document.add( intestazione(entity.getDataInizioInterpello(),
	        						  (entity.getCodiceRegione().equals("041") ||
	        						   entity.getCodiceRegione().equals("042")) ? true : false,
	        						   entity.getDescRegione()) );
	        
	        //dati invio
	        document.add( datiInvio(entity.getDataInvio(),
	        						entity.getNumeroProtocollo(),
	        						entity.getPosizioneGraduatoria(),
	        						entity.getSediSelezionate()) );
	        
	        //dati anagrafici
	        document.add( datiAnagrafici(entity.getCognome(),
	        							 entity.getNome(),
	        							 entity.getCodiceFiscale(),
	        							 entity.getDataNascita(),
	        							 entity.getComuneNascita(),
	        							 entity.getProvinciaNascita(),
	        							 entity.getLuogoNascitaEstero(),
	        							 entity.getCodiceStatoNascita().equalsIgnoreCase("IT") ? true : false,
	        							 entity.getStatoNascita(),
	        							 entity.getNumeroProtocolloDomanda(),
	        							 entity.getModalitaPartecipazione()) );
	        
	        //riepilogo sedi selezionate
	        document.add( elencoSedi(entity.getSedi()) );
	        
	        document.close();
	        
	        return outputStream.toByteArray();
		}
		catch(Exception e) {
			
			logger.error("SceltaSediPdf - creazione del documento PDF fallita", e);
			//e.printStackTrace();//* ONLY FOR TESTING *
			throw new GestioneErroriException("SceltaSediPdf - creazione del documento PDF fallita");
		}
	}
	
	public PdfPTable intestazione(String dataInizioInterpello, boolean isProvinciaAutonoma, String nomeRegione) throws DocumentException {
		
		PdfPTable pdfTable = new PdfPTable(1);
		pdfTable.setWidthPercentage(95.0f);
		pdfTable.setSpacingBefore(0);
		
		String descrizioneRegione = "";
		if(isProvinciaAutonoma) {
			
			descrizioneRegione = nomeRegione;
		}
		else {
			
			descrizioneRegione = properties.getProperty("sceltasedi.testo.regione").replace("<nome_regione>", nomeRegione);
		}
		
		String intestazione = properties.getProperty("sceltasedi.intestazione")
							  .replace("<data_inizio>", dataInizioInterpello)
							  .replace("<regione>", descrizioneRegione);
		
		Phrase phrase = new Phrase(new Chunk(intestazione, bigFontBold));
		PdfPCell cell = new PdfPCell(phrase);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		return pdfTable;
	}
	
	public PdfPTable datiInvio(String dataInvio,
							   String numeroProtocollo,
							   String posizioneGraduatoria,
							   String numeroSediIndicate) throws DocumentException {
				
		PdfPTable pdfTable = new PdfPTable(2);
		pdfTable.setWidthPercentage(95.0f);
		pdfTable.setSpacingBefore(10);
		
		Phrase phrase = new Phrase(new Chunk(properties.getProperty("sceltasedi.datiInvio.intestazione"), smallFontBold));
		PdfPCell cell = new PdfPCell(phrase);
		cell.setColspan(2);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		String testoDataInvio = properties.getProperty("sceltasedi.datiInvio.dataInvio").replace("<data_invio>", dataInvio);
		
		phrase = new Phrase(new Chunk(testoDataInvio, smallFont));
		cell = new PdfPCell(phrase);
		cell.setColspan(2);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		String testoNumeroProtocollo = properties.getProperty("sceltasedi.datiInvio.numeroProtocollo").replace("<numero_protocollo>", numeroProtocollo);
		
		phrase = new Phrase(new Chunk(testoNumeroProtocollo, smallFont));
		cell = new PdfPCell(phrase);
		cell.setColspan(2);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		String testoPosizioneGraduatoria = properties.getProperty("sceltasedi.datiInvio.posizioneGraduatoria").replace("<indice_totale>", posizioneGraduatoria);
		
		phrase = new Phrase(new Chunk(testoPosizioneGraduatoria, smallFont));
		cell = new PdfPCell(phrase);
		cell.setColspan(2);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		String testoNumeroSediIndicate = properties.getProperty("sceltasedi.datiInvio.numeroSediIndicate").replace("<numero_sedi>", numeroSediIndicate);
		
		phrase = new Phrase(new Chunk(testoNumeroSediIndicate, smallFont));
		cell = new PdfPCell(phrase);
		cell.setColspan(2);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		return pdfTable;
	}
	
	public PdfPTable datiAnagrafici(String cognome, String nome,
									String codiceFiscale, String dataNascita,
									String comuneNascita, String provinciaNascita,
									String luogoNascitaEstero,
									boolean nazioneNascitaItaliana,
									String nazioneNascita,
									String numeroProtocollo,
									String modalitaPartecipazione) throws DocumentException {
		
		PdfPTable pdfTable = new PdfPTable(2);
		pdfTable.setWidthPercentage(95.0f);
		pdfTable.setSpacingBefore(10);
		
		Phrase phrase = new Phrase(new Chunk(properties.getProperty("sceltasedi.datiAnagrafici.intestazione"), smallFontBold));
		PdfPCell cell = new PdfPCell(phrase);
		cell.setColspan(2);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		String testoCognome = properties.getProperty("sceltasedi.datiAnagrafici.cognome").replace("<cognome>", cognome);
		
		phrase = new Phrase(new Chunk(testoCognome, smallFont));
		cell = new PdfPCell(phrase);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		String testoNome = properties.getProperty("sceltasedi.datiAnagrafici.nome").replace("<nome>", nome);
		
		phrase = new Phrase(new Chunk(testoNome, smallFont));
		cell = new PdfPCell(phrase);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		String testoCodiceFiscale = properties.getProperty("sceltasedi.datiAnagrafici.codiceFiscale").replace("<codice_fiscale>", codiceFiscale);
		
		phrase = new Phrase(new Chunk(testoCodiceFiscale, smallFont));
		cell = new PdfPCell(phrase);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		String testoDataNascita = properties.getProperty("sceltasedi.datiAnagrafici.dtNascita").replace("<data_nascita>", dataNascita);
		
		phrase = new Phrase(new Chunk(testoDataNascita, smallFont));
		cell = new PdfPCell(phrase);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		//se luogo di nascita italiano
		if(nazioneNascitaItaliana) {
			
			String testoComuneNascita = properties.getProperty("sceltasedi.datiAnagrafici.comuneNascita").replace("<comune_nascita>", comuneNascita);
			
			phrase = new Phrase(new Chunk(testoComuneNascita, smallFont));
			cell = new PdfPCell(phrase);
			cell.setPadding(10);
			pdfTable.addCell(cell);
			
			String testoProvinciaNascita = properties.getProperty("sceltasedi.datiAnagrafici.provinciaNascita").replace("<provincia_nascita>", provinciaNascita);
			
			phrase = new Phrase(new Chunk(testoProvinciaNascita, smallFont));
			cell = new PdfPCell(phrase);
			cell.setPadding(10);
			pdfTable.addCell(cell);
		}
		else {
			
			String testoLuogoNascitaEstero = properties.getProperty("sceltasedi.datiAnagrafici.luogoNascita").replace("<luogo_nascita>", luogoNascitaEstero);
			
			phrase = new Phrase(new Chunk(testoLuogoNascitaEstero, smallFont));
			cell = new PdfPCell(phrase);
			cell.setColspan(2);
			cell.setPadding(10);
			pdfTable.addCell(cell);
		}
		
		String testoNazioneNascita = properties.getProperty("sceltasedi.datiAnagrafici.statoNascita").replace("<stato_nascita>", nazioneNascita);
		
		phrase = new Phrase(new Chunk(testoNazioneNascita, smallFont));
		cell = new PdfPCell(phrase);
		cell.setColspan(2);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		String testoNumeroProtocollo = properties.getProperty("sceltasedi.datiAnagrafici.protocollo.domanda").replace("<numero_protocollo>", numeroProtocollo);
		
		phrase = new Phrase(new Chunk(testoNumeroProtocollo, smallFont));
		cell = new PdfPCell(phrase);
		cell.setColspan(2);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		String testoModalitaPartecipazione = properties.getProperty("sceltasedi.datiAnagrafici.modalitaPartecipazione").replace("<modalita_candidatura>", modalitaPartecipazione);
		
		phrase = new Phrase(new Chunk(testoModalitaPartecipazione, smallFont));
		cell = new PdfPCell(phrase);
		cell.setColspan(2);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		return pdfTable;
	}
	
	public PdfPTable elencoSedi(List<AnagraficaFarm> sedi) throws DocumentException {
		
		PdfPTable pdfTable = new PdfPTable(4);
		pdfTable.setWidthPercentage(95.0f);
		pdfTable.setSpacingBefore(10);
		pdfTable.setWidths(new float[] {1f, 2f, 2f, 2.5f});
		
		//header
		Phrase phrase = new Phrase(new Chunk(properties.getProperty("sceltasedi.tabellaRiepilogoSedi.intestazione"), smallFontBold));
		PdfPCell cell = new PdfPCell(phrase);
		cell.setColspan(4);
		cell.setPadding(10);
		pdfTable.addCell(cell);
		
		phrase = new Phrase(new Chunk(properties.getProperty("sceltasedi.tabellaRiepilogoSedi.preferenza"), smallFont));
		cell = new PdfPCell(phrase);
		cell.setPadding(10);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		pdfTable.addCell(cell);
		
		phrase = new Phrase(new Chunk(properties.getProperty("sceltasedi.tabellaRiepilogoSedi.provincia"), smallFont));
		cell = new PdfPCell(phrase);
		cell.setPadding(10);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		pdfTable.addCell(cell);
		
		phrase = new Phrase(new Chunk(properties.getProperty("sceltasedi.tabellaRiepilogoSedi.comune"), smallFont));
		cell = new PdfPCell(phrase);
		cell.setPadding(10);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		pdfTable.addCell(cell);
		
		phrase = new Phrase(new Chunk(properties.getProperty("sceltasedi.tabellaRiepilogoSedi.progressivo"), smallFont));
		cell = new PdfPCell(phrase);
		cell.setPadding(10);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		pdfTable.addCell(cell);
		
		//elenco
		int i = 1;
		for(AnagraficaFarm sede : sedi) {
			
			if(sede != null) {
				
				phrase = new Phrase(new Chunk(String.valueOf(i) + ".", smallFont));
				cell = new PdfPCell(phrase);
				cell.setPadding(10);
				cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
				pdfTable.addCell(cell);
				
				phrase = new Phrase(new Chunk(sede.getDescrPrvFarm(), smallFont));
				cell = new PdfPCell(phrase);
				cell.setPadding(10);
				pdfTable.addCell(cell);
				
				phrase = new Phrase(new Chunk(sede.getFrazioneFarm(), smallFont));
				cell = new PdfPCell(phrase);
				cell.setPadding(10);
				pdfTable.addCell(cell);
				
				phrase = new Phrase(new Chunk(sede.getNProgressivo(), smallFont));
				cell = new PdfPCell(phrase);
				cell.setPadding(10);
				pdfTable.addCell(cell);
				
				i++;
			}
		}
		
		return pdfTable;
	}
	
	//test method
	private void creaPDF(String filename) throws Exception {
		
		FileOutputStream outputStream = null;
		
		try {
			
			List<AnagraficaFarm> sediSelezionate = new ArrayList<AnagraficaFarm>();
			AnagraficaFarm sedeTest = new AnagraficaFarm();
			sedeTest.setDescrPrvFarm("Roma");
			sedeTest.setFrazioneFarm("Acilia");
			sedeTest.setNProgressivo("???");
			for(int i = 0; i < 15; i++) {
				sediSelezionate.add(sedeTest);
			}
			
			SceltaSediEntityPdf entity = new SceltaSediEntityPdf("1",
																 "30/12/2014",
																 "120",
																 "LAZIO", "Rossi",
																 "Mario",
																 "XXXYYYXXYXXYYYX",
																 "01/01/1990",
																 "Roma",
																 "Roma",
																 "London",
																 "IT",
																 "ITALIA",
																 "<estremi documento identit�>",
																 "01/01/2015 12:00:00",
																 "xxxxxx - 01/01/2013 - xxx",
																 "SINGOLA",
																 "xxxxxx - 01/01/2015 - xxx",
																 "45",
																 "5",
																 sediSelezionate);
			
			outputStream = new FileOutputStream(filename);
			outputStream.write(creaRicevutaPDF(entity));
		}
		catch(Exception e) {
			
			logger.error("SceltaSediPdf - scrittura su file fallita", e);
			//e.printStackTrace();//* ONLY FOR TESTING *
			throw e;
		}
		finally {
			
			if(outputStream != null) {
				outputStream.close();
			}
		}
	}
	
	public static void main(String[] args) {
		
		try {
			
			new SceltaSediPdf().creaPDF("C:\\Users\\alessandro.imperio\\Desktop\\ricevuta_test.pdf");
		}
		catch(Exception e) {
			
			logger.error("SceltaSediPdf - creazione ricevuta di test fallita", e);
			//e.printStackTrace();//* ONLY FOR TESTING *
		}
	}
	
}