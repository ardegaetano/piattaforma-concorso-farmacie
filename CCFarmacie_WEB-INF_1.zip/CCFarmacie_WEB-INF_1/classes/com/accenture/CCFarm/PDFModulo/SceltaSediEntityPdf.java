package com.accenture.CCFarm.PDFModulo;

import java.util.List;

import com.accenture.CCFarm.DAO.AnagraficaFarm;

public class SceltaSediEntityPdf {
	
	private String numeroInterpello;
	
	private String dataInizioInterpello;
	
	private String codiceRegione;
	
	private String descRegione;
	
	private String cognome;
	
	private String nome;
	
	private String codiceFiscale;
	
	private String dataNascita;
	
	private String comuneNascita;
	
	private String provinciaNascita;
	
	private String luogoNascitaEstero;
	
	private String codiceStatoNascita;
	
	private String statoNascita;
	
	private String estremiDocIdentita;
	
	private String dataInvio;
	
	private String numeroProtocolloDomanda;
	
	private String modalitaPartecipazione;
	
	private String numeroProtocollo;
	
	private String posizioneGraduatoria;
	
	private String sediSelezionate;
	
	private List<AnagraficaFarm> sedi;
	
	public SceltaSediEntityPdf() {
		
	}

	public SceltaSediEntityPdf(String numeroInterpello,
			String dataInizioInterpello, String codiceRegione,
			String descRegione, String cognome, String nome,
			String codiceFiscale, String dataNascita, String comuneNascita,
			String provinciaNascita, String luogoNascitaEstero,
			String codiceStatoNascita, String statoNascita,
			String estremiDocIdentita, String dataInvio,
			String numeroProtocolloDomanda, String modalitaPartecipazione,
			String numeroProtocollo, String posizioneGraduatoria,
			String sediSelezionate, List<AnagraficaFarm> sedi) {
		this.numeroInterpello = numeroInterpello;
		this.dataInizioInterpello = dataInizioInterpello;
		this.codiceRegione = codiceRegione;
		this.descRegione = descRegione;
		this.cognome = cognome;
		this.nome = nome;
		this.codiceFiscale = codiceFiscale;
		this.dataNascita = dataNascita;
		this.comuneNascita = comuneNascita;
		this.provinciaNascita = provinciaNascita;
		this.luogoNascitaEstero = luogoNascitaEstero;
		this.codiceStatoNascita = codiceStatoNascita;
		this.statoNascita = statoNascita;
		this.estremiDocIdentita = estremiDocIdentita;
		this.dataInvio = dataInvio;
		this.numeroProtocolloDomanda = numeroProtocolloDomanda;
		this.modalitaPartecipazione = modalitaPartecipazione;
		this.numeroProtocollo = numeroProtocollo;
		this.posizioneGraduatoria = posizioneGraduatoria;
		this.sediSelezionate = sediSelezionate;
		this.sedi = sedi;
	}

	public String getNumeroInterpello() {
		return numeroInterpello;
	}

	public void setNumeroInterpello(String numeroInterpello) {
		this.numeroInterpello = numeroInterpello;
	}

	public String getDataInizioInterpello() {
		return dataInizioInterpello;
	}

	public void setDataInizioInterpello(String dataInizioInterpello) {
		this.dataInizioInterpello = dataInizioInterpello;
	}

	public String getCodiceRegione() {
		return codiceRegione;
	}

	public void setCodiceRegione(String codiceRegione) {
		this.codiceRegione = codiceRegione;
	}

	public String getDescRegione() {
		return descRegione;
	}

	public void setDescRegione(String descRegione) {
		this.descRegione = descRegione;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCodiceFiscale() {
		return codiceFiscale;
	}

	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}

	public String getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}

	public String getComuneNascita() {
		return comuneNascita;
	}

	public void setComuneNascita(String comuneNascita) {
		this.comuneNascita = comuneNascita;
	}

	public String getProvinciaNascita() {
		return provinciaNascita;
	}

	public void setProvinciaNascita(String provinciaNascita) {
		this.provinciaNascita = provinciaNascita;
	}

	public String getLuogoNascitaEstero() {
		return luogoNascitaEstero;
	}

	public void setLuogoNascitaEstero(String luogoNascitaEstero) {
		this.luogoNascitaEstero = luogoNascitaEstero;
	}

	public String getCodiceStatoNascita() {
		return codiceStatoNascita;
	}

	public void setCodiceStatoNascita(String codiceStatoNascita) {
		this.codiceStatoNascita = codiceStatoNascita;
	}

	public String getStatoNascita() {
		return statoNascita;
	}

	public void setStatoNascita(String statoNascita) {
		this.statoNascita = statoNascita;
	}

	public String getEstremiDocIdentita() {
		return estremiDocIdentita;
	}

	public void setEstremiDocIdentita(String estremiDocIdentita) {
		this.estremiDocIdentita = estremiDocIdentita;
	}

	public String getDataInvio() {
		return dataInvio;
	}

	public void setDataInvio(String dataInvio) {
		this.dataInvio = dataInvio;
	}

	public String getPosizioneGraduatoria() {
		return posizioneGraduatoria;
	}

	public void setPosizioneGraduatoria(String posizioneGraduatoria) {
		this.posizioneGraduatoria = posizioneGraduatoria;
	}

	public String getSediSelezionate() {
		return sediSelezionate;
	}

	public void setSediSelezionate(String sediSelezionate) {
		this.sediSelezionate = sediSelezionate;
	}

	public String getNumeroProtocollo() {
		return numeroProtocollo;
	}

	public void setNumeroProtocollo(String numeroProtocollo) {
		this.numeroProtocollo = numeroProtocollo;
	}

	public String getNumeroProtocolloDomanda() {
		return numeroProtocolloDomanda;
	}

	public void setNumeroProtocolloDomanda(String numeroProtocolloDomanda) {
		this.numeroProtocolloDomanda = numeroProtocolloDomanda;
	}

	public String getModalitaPartecipazione() {
		return modalitaPartecipazione;
	}

	public void setModalitaPartecipazione(String modalitaPartecipazione) {
		this.modalitaPartecipazione = modalitaPartecipazione;
	}

	public List<AnagraficaFarm> getSedi() {
		return sedi;
	}

	public void setSedi(List<AnagraficaFarm> sedi) {
		this.sedi = sedi;
	}
	
}
