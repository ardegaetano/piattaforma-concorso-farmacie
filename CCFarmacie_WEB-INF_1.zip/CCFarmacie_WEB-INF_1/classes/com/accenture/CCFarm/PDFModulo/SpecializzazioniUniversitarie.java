package com.accenture.CCFarm.PDFModulo;

public class SpecializzazioniUniversitarie
{
	   private String denomSpecializza;
	   private String facoltaSpecializza;
	   private String univeSpecializza;
	   private String luogoSpecializza;
	   private String nazioneSpecializza;
	   private String durataSpecializza;	   
	   private String seEsteraPrivataSpecializza;

		public String getDenomSpecializza() {
			return denomSpecializza;
		}
		public void setDenomSpecializza(String denomSpecializza) {
			this.denomSpecializza = denomSpecializza;
		}
		public String getFacoltaSpecializza() {
			return facoltaSpecializza;
		}
		public void setFacoltaSpecializza(String facoltaSpecializza) {
			this.facoltaSpecializza = facoltaSpecializza;
		}
		public String getUniveSpecializza() {
			return univeSpecializza;
		}
		public void setUniveSpecializza(String univeSpecializza) {
			this.univeSpecializza = univeSpecializza;
		}
		public String getLuogoSpecializza() {
			return luogoSpecializza;
		}
		public void setLuogoSpecializza(String luogoSpecializza) {
			this.luogoSpecializza = luogoSpecializza;
		}
		public String getNazioneSpecializza() {
			return nazioneSpecializza;
		}
		public void setNazioneSpecializza(String nazioneSpecializza) {
			this.nazioneSpecializza = nazioneSpecializza;
		}
		public String getDurataSpecializza() {
			return durataSpecializza;
		}
		public void setDurataSpecializza(String durataSpecializza) {
			this.durataSpecializza = durataSpecializza;
		}
		public String getSeEsteraPrivataSpecializza() {
			return seEsteraPrivataSpecializza;
		}
		public void setSeEsteraPrivataSpecializza(String seEsteraPrivataSpecializza) {
			this.seEsteraPrivataSpecializza = seEsteraPrivataSpecializza;
		}		   
}
