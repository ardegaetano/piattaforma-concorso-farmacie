package com.accenture.CCFarm.test;

import java.io.FileInputStream;
import java.io.IOException;  

import org.apache.log4j.Level;
import org.apache.pdfbox.pdmodel.PDDocument;  
import org.apache.pdfbox.pdmodel.PDPage;  
import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;  
import org.apache.pdfbox.pdmodel.font.PDFont;  
import org.apache.pdfbox.pdmodel.font.PDType1Font; 
import org.apache.pdfbox.exceptions.COSVisitorException;

import com.accenture.CCFarm.PDFModulo.GestionePDFModuloRicevuta;
import com.accenture.CCFarm.utility.CCFarmLogger;


public class testPDF {

	/**
	 * @param args
	 */
	    public static void creatPDFConTesto() throws Exception{ 
			PDDocument doc = null;  
			try 
			{  
			  doc = new PDDocument();  
			  PDPage page = new PDPage();  
			  doc.addPage( page );  
			  PDPageContentStream contentStream = new PDPageContentStream(doc, page);  
			  PDFont font = PDType1Font.HELVETICA_BOLD;  
			  contentStream.beginText();  
			  contentStream.setFont( font, 12 );  
			  contentStream.moveTextPositionByAmount( 100, 700 );  
			  contentStream.drawString( "Prova PDF " );  
			  contentStream.endText();  
			  contentStream.close();  
			  doc.save("c:\\output.pdf");  
			  doc.close();  
			} catch (IOException e) {  
			  e.printStackTrace();  
			}  	    	
	    	
	    }
	    
	    public static void leggoPDFDaFile() throws Exception{ 
	    	PDDocument doc = null;  
	    	try 
	    	{  
	    		doc = PDDocument.load("C:\\output.pdf" );  
	    		PDPage page = (PDPage)doc.getDocumentCatalog().getAllPages().get(0);  
	    		PDPageContentStream contentStream = new PDPageContentStream(doc, page, true, true);  
	    		PDFont font = PDType1Font.HELVETICA_BOLD;  
	    		contentStream.beginText();  
	    		contentStream.setFont( font, 12 );  
	    		contentStream.moveTextPositionByAmount( 260, 700 );  
	    		contentStream.drawString( "!!!!!" );  
	    		contentStream.endText();  
	    		contentStream.close();  
	    		doc.save("c:\\outputMod.pdf");  
	    		doc.close();  
	    	} catch (IOException e) {  
	    		e.printStackTrace();  
	    	} catch (COSVisitorException e) {  
	    		e.printStackTrace();  
	    	}  
	    }	  
	    
	    
		public static void main(String[] args) throws Exception{  
			//provaChiamaUtenteCandidaDAO();
	
			try
			{ 
				GestionePDFModuloRicevuta gestionePDFModuloRicevuta = new GestionePDFModuloRicevuta();
				gestionePDFModuloRicevuta.caricaDatiDaUtentePerEntityPDF("535");
				/*
				gestionePDFModuloRicevuta.creaRicevutaPDF();
				gestionePDFModuloRicevuta.downloadFile();
				
				*/
				
				gestionePDFModuloRicevuta.creaRicevutaPDFRecovery("535");
				
				
				/*
				byte[] ricevutaPDF = gestionePDFModuloRicevuta.getImgRicevutaPDF();
				gestionePDFModuloRicevuta.salvaRicevutaPDF(ricevutaPDF);
				*/
			} catch (Exception e) { 
				
			}
		}

}
