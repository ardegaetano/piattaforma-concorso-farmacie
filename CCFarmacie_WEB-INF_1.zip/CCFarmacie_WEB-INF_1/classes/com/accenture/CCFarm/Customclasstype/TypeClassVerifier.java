package com.accenture.CCFarm.Customclasstype;


import java.lang.reflect.Constructor;

public abstract class TypeClassVerifier
{
    public static boolean verify(Class<?> classeDichiarata, String dato)
    {
	try
	{	    
	    Constructor<?> costruttore = classeDichiarata.getConstructor(String.class);
	    costruttore.newInstance(dato);
	    /*
	     * se va in errore... o non ha il costruttore con stringa oppure la stringa non � adatta
	     */
	    return true;
	}
	catch (Throwable e) 
	{
	    // TODO: handle exception
	}
	return false;
    }  
}
