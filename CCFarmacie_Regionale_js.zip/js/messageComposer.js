function messaggioDiBenvenuto()
{
	var msg=document.getElementById("msgBenvenuto").value;
	msg=msg.replace("<cognome>",document.getElementById("cognomeUtente").value);
	msg=msg.replace("<nome>",document.getElementById("nomeUtente").value);
	document.write(msg);
}

function messaggioDichiarazione(parte)
{
	var msg="";
	if(parte==0)
	{	
		msg=document.getElementById("msgRichiestaAmmissione").value;
		msg=msg.replace("<cognome>",document.getElementById("cognomeUtente").value);
		msg=msg.replace("<nome>",document.getElementById("nomeUtente").value);
		//sostituire <regione> in msg con il valore recuperato dalla sessione
		
		msg=msg+"<br>"+document.getElementById("msgConsapevolezzaResponsabilita").value;
	}
	else if(parte==1)
	{
		msg=document.getElementById("msgDichiara").value;
	}
	document.write(msg);
}